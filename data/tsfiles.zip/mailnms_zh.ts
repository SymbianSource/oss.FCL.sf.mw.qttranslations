<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailnms_setlabel_download_images_val_sat">
      <source>Sat</source>
      <translation variants="no">zh #Sat</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_read_unread_status_sync">
      <source>Sync to server</source>
      <translation variants="no">zh #Sync to server</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">zh #Refresh mail</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_username">
      <source>Username</source>
      <translation variants="no">zh #Username</translation>
    </message>
    <message numerus="no" id="txt_mailnms_button_delete_mailbox">
      <source>Delete mailbox</source>
      <translation variants="no">zh #Delete mailbox</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_download_images_val_thu">
      <source>Thu</source>
      <translation variants="no">zh #Thu</translation>
    </message>
    <message numerus="no" id="txt_mailnms_subhead_preferences">
      <source>Preferences</source>
      <translation variants="no">zh #Preferences</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_val_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="no">zh #Every 15 minutes</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_show_mail_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">zh #Show mail in inbox</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_selected_mode_val_user_defined">
      <source>User defined</source>
      <translation variants="no">zh #User defined</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_selected_mode_val_fetch_manually">
      <source>Fetch manually</source>
      <translation variants="no">zh #Fetch manually</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_day_start_time">
      <source>Day start time</source>
      <translation variants="no">zh #Day start time</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_my_name">
      <source>My name</source>
      <translation variants="no">zh #My name</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_val_every_1_hour">
      <source>Every hour</source>
      <translation variants="no">zh #Every hour</translation>
    </message>
    <message numerus="no" id="txt_mailnms_subhead_receiving_schedule">
      <source>Receiving Schedule</source>
      <translation variants="no">zh #Receiving Schedule</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">zh #Mail address</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_val_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="no">zh #Every 4 hours</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_day_end_time">
      <source>Day end time</source>
      <translation variants="no">zh #Day end time</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_val_keep_uptodate">
      <source>Keep up-to-date</source>
      <translation variants="no">zh #Keep up-to-date</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_receiving_weekdays">
      <source>Receiving days</source>
      <translation variants="no">zh #Receiving days</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_mailbox_name">
      <source>Mailbox name</source>
      <translation variants="no">zh #Mailbox name</translation>
    </message>
    <message numerus="no" id="txt_mailnms_list_the_mailbox_is_refreshed_as_defined">
      <source>The mailbox is refreshed as defined by the user</source>
      <translation variants="no">zh #The mailbox is refreshed as defined by the user</translation>
    </message>
    <message numerus="no" id="txt_mailnms_list_the_mailbox_is_uptodate_during_day">
      <source>The mailbox is up-to-date during daytime</source>
      <translation variants="no">zh #The mailbox is up-to-date during daytime</translation>
    </message>
    <message numerus="no" id="txt_mailnms_subhead_user_info">
      <source>User info</source>
      <translation variants="no">zh #User info</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_download_images_val_every_day">
      <source>Every day</source>
      <translation variants="no">zh #Every day</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_read_unread_status">
      <source>Read / unread status</source>
      <translation variants="no">zh #Read / unread status</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_password">
      <source>Password</source>
      <translation variants="no">zh #Password</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_selected_mode_val_save_energy">
      <source>Save energy</source>
      <translation variants="no">zh #Save energy</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_download_images_val_sun">
      <source>Sun</source>
      <translation variants="no">zh #Sun</translation>
    </message>
    <message numerus="no" id="txt_mailnms_list_the_mailbox_is_refreshed_every_15_mi">
      <source>The mailbox is refreshed every 15 minutes during daytime</source>
      <translation variants="no">zh #The mailbox is refreshed every 15 minutes during daytime</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_signature">
      <source>Signature</source>
      <translation variants="no">zh #Signature</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_selected_mode_val_keep_uptodat">
      <source>Keep up-to-date</source>
      <translation variants="no">zh #Keep up-to-date</translation>
    </message>
    <message numerus="no" id="txt_mailnms_list_the_mailbox_is_refreshed_only_by_use">
      <source>The mailbox is refreshed only by user request</source>
      <translation variants="no">zh #The mailbox is refreshed only by user request</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_download_images_val_tue">
      <source>Tue</source>
      <translation variants="no">zh #Tue</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_connection">
      <source>Connection</source>
      <translation variants="no">zh #Connection</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_download_images_val_mon">
      <source>Mon</source>
      <translation variants="no">zh #Mon</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_show_mail_in_other_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">zh #Show mail in other folders</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_download_images_val_fri">
      <source>Fri</source>
      <translation variants="no">zh #Fri</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_selected_mode">
      <source>Selected mode</source>
      <translation variants="no">zh #Selected mode</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_read_unread_status_dont_sync">
      <source>Don't sync to server</source>
      <translation variants="no">zh #Don't sync to server</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_download_images_val_wed">
      <source>Wed</source>
      <translation variants="no">zh #Wed</translation>
    </message>
    <message numerus="no" id="txt_mailnms_setlabel_reply_to_address">
      <source>Reply to address</source>
      <translation variants="no">zh #Reply to address</translation>
    </message>
  </context>
</TS>