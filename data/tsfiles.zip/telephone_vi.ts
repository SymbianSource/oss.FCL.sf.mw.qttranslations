<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">Không được phép</translation>
    </message>
    <message numerus="no" id="txt_phone_dblist_ongoing_call">
      <source>Ongoing call</source>
      <translation variants="no">Cuộc gọi đang diễn ra</translation>
    </message>
    <message numerus="yes" id="txt_phone_dblist_ln_missed_calls">
      <source>%Ln missed calls</source>
      <translation>
        <numerusform plurality="a">vi #%Ln missed call</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_attempting">
      <source>Attempting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đang thử gọi số khẩn cấp</lengthvariant>
        <lengthvariant priority="2">vi #Attempting emergency cl.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_not_allowed_during_resto">
      <source>Video call not allowed during restore</source>
      <translation variants="no">Không thể thực hiện cuộc gọi video trong khi đang tiến hành thao tác khôi phục</translation>
    </message>
    <message numerus="no" id="txt_phone_info_life_timer">
      <source>Life timer\n%L1</source>
      <translation variants="no">Đồng hồ thời gian:
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_call_failed">
      <source>Emergency call failed</source>
      <translation variants="no">Lỗi cuộc gọi khẩn cấp</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conference_call_active">
      <source>Conference call active</source>
      <translation variants="no">Đang tham gia cuộc gọi hội nghị</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_all_incoming_calls_diver">
      <source>Note:  all incoming calls diverted</source>
      <translation variants="no">Ghi chú: đã chuyển hướng tất cả cuộc gọi đến</translation>
    </message>
    <message numerus="no" id="txt_phone_other_on_hold">
      <source>On hold</source>
      <translation variants="no">đang giữ</translation>
    </message>
    <message numerus="no" id="txt_phone_info_activate_own_number_sending">
      <source>Activate own number sending</source>
      <translation variants="no">Kích hoạt gửi số gọi đến</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_call">
      <source>Incoming call</source>
      <translation variants="yes">
        <lengthvariant priority="1">đang gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling">
      <source>Calling</source>
      <translation variants="no">Đang gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_other_disconnected">
      <source>Disconnected</source>
      <translation variants="no">đã ngắt kết nối</translation>
    </message>
    <message numerus="no" id="txt_phone_other_waiting">
      <source>Waiting</source>
      <translation variants="no">đang chờ</translation>
    </message>
    <message numerus="no" id="txt_phone_info_called_number_has_barred_incoming">
      <source>Called number has barred incoming calls</source>
      <translation variants="no">Không thể thực hiện cuộc gọi video. Cuộc gọi đến bị chặn trên điện thoại kia.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_use">
      <source>Number not in use</source>
      <translation variants="no">Số chưa dùng</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_answer">
      <source>No answer</source>
      <translation variants="no">Không trả lời</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">Chỉ cuộc gọi khẩn cấp</translation>
    </message>
    <message numerus="no" id="txt_phone_other_private_number">
      <source>Private number</source>
      <translation variants="no">Số riêng</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_busy">
      <source>Network busy</source>
      <translation variants="no">Mạng bận</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_own_number_sending">
      <source>Check own number sending</source>
      <translation variants="no">Kiểm tra gửi số gọi đến của tôi</translation>
    </message>
    <message numerus="no" id="txt_phone_info_unable_to_make_video_call_not_supp">
      <source>Unable to make video call. Not supported by other phone or network.</source>
      <translation variants="no">Không thể thực hiện cuộc gọi video. Mạng hoặc điện thoại đầu kia không hỗ trợ.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_send_string">
      <source>Send string:\n%L1</source>
      <translation variants="no">Gửi DTMF: %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_barrings">
      <source>Note: you have active barrings</source>
      <translation variants="no">Ghi chú: kích hoạt chặn cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_info_could_not_send_own_number">
      <source>Could not send own number</source>
      <translation variants="no">Không thể gửi số gọi đến của bạn</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending">
      <source>Sending\n%L1</source>
      <translation variants="no">Đang gửi
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_other_remote_sim">
      <source>Remote SIM</source>
      <translation variants="no">SIM từ xa</translation>
    </message>
    <message numerus="no" id="txt_phone_other_unknown_number">
      <source>Unknown number</source>
      <translation variants="no">Số không biết</translation>
    </message>
    <message numerus="no" id="txt_phone_other_emergency_call">
      <source>Emergency call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi khẩn cấp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_barred">
      <source>Number barred</source>
      <translation variants="no">Số bị chặn</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_diverting">
      <source>Diverting</source>
      <translation variants="no">Đang chuyển hướng</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_end_all_calls">
      <source>End all calls</source>
      <translation variants="no">Kết thúc tất cả cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_switched_off_or_out_of_3g">
      <source>Phone switched off or out of 3G coverage</source>
      <translation variants="no">Không thể thực hiện cuộc gọi video. Điện thoại khác đã tắt hoặc ở ngoài mạng 3G.</translation>
    </message>
    <message numerus="no" id="txt_phone_other_conference_call">
      <source>Conference call</source>
      <translation variants="no">Cuộc gọi hội nghị</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_busy">
      <source>Number busy</source>
      <translation variants="no">Số bận</translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">Số điện thoại không hợp lệ</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_not_allowed_fixed_dialling">
      <source>Call not allowed, fixed dialling active</source>
      <translation variants="no">Cuộc gọi không được phép. Đang mở gọi số ấn định.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_didnt_succeed_to_called">
      <source>Video call didn't succeed to called end</source>
      <translation variants="no">Không thể thực hiện cuộc gọi video. Mạng hoặc điện thoại đầu kia không hỗ trợ.</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_no_network_coverage">
      <source>No network coverage</source>
      <translation variants="no">Ngoài vùng phủ sóng</translation>
    </message>
    <message numerus="no" id="txt_short_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">vi ##Telephone</translation>
    </message>
    <message numerus="no" id="txt_long_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">Điện thoại</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_transfer">
      <source>Transfer</source>
      <translation variants="no">Chuyển</translation>
    </message>
    <message numerus="no" id="txt_phone_title_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_network_services">
      <source>Check network services</source>
      <translation variants="no">Kiểm tra dịch vụ mạng</translation>
    </message>
    <message numerus="no" id="txt_phone_info_videocall_only_possible_under_3g">
      <source>Videocall only possible under 3G coverage</source>
      <translation variants="no">Cuộc gọi video không được hỗ trợ bên ngoài mạng 3G</translation>
    </message>
    <message numerus="no" id="txt_phone_info_serial_no">
      <source>Serial No.\n%L1</source>
      <translation variants="no">Số sê-ri:
%1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected_to_1">
      <source>Connected to %L1</source>
      <translation variants="no">Đã kết nối %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_error_in_connection">
      <source>Error in connection</source>
      <translation variants="no">Lỗi kết nối</translation>
    </message>
  </context>
</TS>