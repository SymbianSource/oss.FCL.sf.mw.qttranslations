<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_opt_transfer">
      <source>Transfer</source>
      <translation variants="no">Chuyển</translation>
    </message>
    <message numerus="no" id="txt_phone_title_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">Điện thoại</translation>
    </message>
    <message numerus="no" id="txt_phone_other_private_number">
      <source>Private number</source>
      <translation variants="no">Số riêng</translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling">
      <source>Calling</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đang gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_on_hold">
      <source>On hold</source>
      <translation variants="yes">
        <lengthvariant priority="1">đang giữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_call">
      <source>Incoming call</source>
      <translation variants="yes">
        <lengthvariant priority="1">đang gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_disconnected">
      <source>Disconnected</source>
      <translation variants="yes">
        <lengthvariant priority="1">đã ngắt kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_waiting">
      <source>Waiting</source>
      <translation variants="yes">
        <lengthvariant priority="1">đang chờ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_opt_end_all_calls">
      <source>End all calls</source>
      <translation variants="no">Kết thúc tất cả cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_other_emergency_call">
      <source>Emergency call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi khẩn cấp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_attempting">
      <source>Attempting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đang thử gọi số khẩn cấp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_remote_sim">
      <source>Remote SIM</source>
      <translation variants="no">SIM từ xa</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_busy">
      <source>Number busy %L1</source>
      <translation variants="no">Số bận %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending">
      <source>Sending\n%L1</source>
      <translation variants="no">Đang gửi
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_could_not_send_own_number">
      <source>Could not send own number %L1</source>
      <translation variants="no">Không thể gửi số gọi đến của bạn %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_videocall_only_possible_under_3g">
      <source>Videocall only possible under 3G coverage %L1</source>
      <translation variants="no">Cuộc gọi video không được hỗ trợ bên ngoài mạng 3G %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_no_network_coverage">
      <source>No network coverage %L1</source>
      <translation variants="no">Ngoài vùng phủ sóng %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_serial_no">
      <source>Serial No.\n%L1</source>
      <translation variants="no">Số sê-ri:
%1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected_to_1">
      <source>Connected to %L1</source>
      <translation variants="no">Đã kết nối %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_network_services">
      <source>Check network services %L1</source>
      <translation variants="no">Kiểm tra dịch vụ mạng %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_error_in_connection">
      <source>Error in connection %L1</source>
      <translation variants="no">Lỗi kết nối %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_use">
      <source>Number not in use %L1</source>
      <translation variants="no">Số chưa dùng %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_answer">
      <source>No answer %L1</source>
      <translation variants="no">Không trả lời %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_called_number_has_barred_incoming">
      <source>Called number has barred incoming calls %L1</source>
      <translation variants="no">Số đã gọi có cuộc gọi đến bị chặn %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_unable_to_make_video_call_not_supp">
      <source>Unable to make video call. Not supported by other phone or network. %L1</source>
      <translation variants="no">Không thể thực hiện cuộc gọi video %L1. Mạng hoặc thiết bị kia không hỗ trợ.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_calls_only">
      <source>Emergency calls only %L1</source>
      <translation variants="no">Chỉ cuộc gọi khẩn cấp %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_busy">
      <source>Network busy %L1</source>
      <translation variants="no">Mạng bận %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_send_string">
      <source>Send string:\n%L1</source>
      <translation variants="no">Gửi DTMF: %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_barrings">
      <source>Note: you have active barrings</source>
      <translation variants="no">Ghi chú: kích hoạt chặn cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_switched_off_or_out_of_3g">
      <source>Phone switched off or out of 3G coverage %L1</source>
      <translation variants="no">Không thể thực hiện cuộc gọi video %L1. Thiết bị khác đã tắt hoặc ở ngoài mạng 3G.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_own_number_sending">
      <source>Check own number sending %L1</source>
      <translation variants="no">Kiểm tra gửi số gọi đến của tôi %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_all_incoming_calls_diver">
      <source>Note:  all incoming calls diverted</source>
      <translation variants="no">Lưu ý: đã chuyển hướng tất cả cuộc gọi đến</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_not_allowed">
      <source>Not allowed %L1</source>
      <translation variants="no">Không được phép %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_diverting">
      <source>Diverting</source>
      <translation variants="no">Đang chuyển hướng</translation>
    </message>
    <message numerus="no" id="txt_phone_info_activate_own_number_sending">
      <source>Activate own number sending %L1</source>
      <translation variants="no">Kích hoạt gửi số gọi đến %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_life_timer">
      <source>Life timer\n%L1</source>
      <translation variants="no">Đồng hồ thời gian:
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conference_call_active">
      <source>Conference call active</source>
      <translation variants="no">Đang tham gia cuộc gọi hội nghị</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_barred">
      <source>Number barred %L1</source>
      <translation variants="no">Số bị chặn %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_not_allowed_during_resto">
      <source>Video call not allowed during restore %L1</source>
      <translation variants="no">Không thể thực hiện cuộc gọi video trong khi đang khôi phục %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_call_failed">
      <source>Emergency call failed %L1</source>
      <translation variants="no">Lỗi cuộc gọi khẩn cấp %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_share_video">
      <source>Share content</source>
      <translation variants="no">Chia sẻ video</translation>
    </message>
    <message numerus="no" id="txt_short_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">vi ##Telephone</translation>
    </message>
    <message numerus="no" id="txt_phone_other_conference_call">
      <source>Conference call</source>
      <translation variants="no">Cuộc gọi hội nghị</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_closed_group">
      <source>Number not in closed group %L1</source>
      <translation variants="no">Số không có trong nhóm nội bộ %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_on_hold">
      <source>On hold</source>
      <translation variants="no">Giữ máy</translation>
    </message>
    <message numerus="no" id="txt_phone_info_smartchip_not_allowed_mm_3">
      <source>Smartchip not allowed MM #3 </source>
      <translation variants="no">Không cho phép SmartChip MM #3</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_failed_mm_4">
      <source>Call Failed MM #4 </source>
      <translation variants="no">Không thực hiện được cuộc gọi MM #4</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sim_unaccepted">
      <source>Sim unaccepted %L1</source>
      <translation variants="no">Thẻ SIM không được chấp nhận %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected">
      <source>Connected</source>
      <translation variants="no">Đã kết nối</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_rejected">
      <source>Call rejected %L1</source>
      <translation variants="no">Đã từ chối cuộc gọi %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_request_rejected_l1">
      <source>Request rejected %L1 </source>
      <translation variants="no">Đã từ chối yêu cầu %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_smartchip_not_provisioned_mm_2">
      <source>Smartchip not provisioned MM #2 </source>
      <translation variants="no">Không cung cấp SmartChip MM #2</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sim_invalid">
      <source>Sim invalid %L1</source>
      <translation variants="no">Thẻ SIM không hợp lệ %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_l1_call">
      <source>Incoming %1 call</source>
      <translation variants="no">Cuộc gọi %[19]1 đến</translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling_1_call">
      <source>Calling %1 call</source>
      <translation variants="no">Đang gọi (cuộc gọi %[12]1)</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sim_rejected">
      <source>Sim rejected %L1</source>
      <translation variants="no">Thẻ SIM bị từ chối %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling_video_call">
      <source>Calling video call</source>
      <translation variants="no">Đang gọi (cuộc gọi video)</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_invalid_phone_number_l1">
      <source>Invalid phone number %L1</source>
      <translation variants="no">vi #Invalid phone number %L1</translation>
    </message>
    <message numerus="yes" id="txt_phone_dblist_ln_missed_calls">
      <source>%Ln missed calls</source>
      <translation>
        <numerusform plurality="a">%Ln cuộc gọi nhỡ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_sim_removed">
      <source>Sim removed %L1</source>
      <translation variants="no">Đã tháo thẻ SIM %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_grid_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_not_allowed_mm_6">
      <source>Phone not allowed MM #6 </source>
      <translation variants="no">Không cho phép thiết bị MM #6</translation>
    </message>
    <message numerus="no" id="txt_phone_other_unknown_number">
      <source>Unknown number</source>
      <translation variants="no">Số không biết</translation>
    </message>
    <message numerus="no" id="txt_phone_dblist_ongoing_call">
      <source>Ongoing call</source>
      <translation variants="no">Cuộc gọi đang diễn ra</translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_reboot_required">
      <source>Phone reboot required %L1</source>
      <translation variants="no">Yêu cầu khởi động lại thiết bị %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_didnt_succeed_to_called">
      <source>Video call didn't succeed to called end %L1</source>
      <translation variants="no">Không thể thực hiện cuộc gọi video %L1. Mạng hoặc thiết bị kia không hỗ trợ.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_not_allowed_fixed_dialling">
      <source>Call not allowed, fixed dialling active %L1</source>
      <translation variants="no">C.gọi ko được phép %L1. Đang mở gọi số ấn định.</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_video_call">
      <source>Incoming video call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi video đến</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_not_allowed_mm_5">
      <source>Phone not allowed MM #5 </source>
      <translation variants="no">Không cho phép thiết bị MM #5</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_l1">
      <source>Call %L1?</source>
      <translation variants="no">Gọi %L1?</translation>
    </message>
    <message numerus="no" id="txt_phone_other_payphone">
      <source>Payphone</source>
      <translation variants="no">Điện thoại thẻ</translation>
    </message>
  </context>
</TS>