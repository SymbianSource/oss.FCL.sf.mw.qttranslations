<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_sounds">
      <source>Sound files</source>
      <translation variants="no">聲音</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_others">
      <source>Others</source>
      <translation variants="no">其他</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_install">
      <source>Install files</source>
      <translation variants="no">已安裝的檔案</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_pres_logos">
      <source>Presence logos</source>
      <translation variants="no">線上狀態標誌</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_digital_tones">
      <source>Sound clips</source>
      <translation variants="no">聲音檔</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_images">
      <source>Images</source>
      <translation variants="no">影像</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_games">
      <source>Games</source>
      <translation variants="no">遊戲</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_mms_bc">
      <source>Wallpapers</source>
      <translation variants="no">桌面圖案</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_gms_pict">
      <source>Picture messages</source>
      <translation variants="no">圖片訊息</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_videos">
      <source>Video clips</source>
      <translation variants="no">影片</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_simple_tones">
      <source>Ringing tones</source>
      <translation variants="no">鈴聲</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_contacts">
      <source>Contats</source>
      <translation variants="no">通訊錄</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_links">
      <source>Links</source>
      <translation variants="no">連結</translation>
    </message>
  </context>
</TS>