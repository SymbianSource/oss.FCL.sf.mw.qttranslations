<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_others">
      <source>Others</source>
      <translation variants="no">zh_tw #Other</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_gms_pict">
      <source>Picture messages</source>
      <translation variants="no">zh_tw #Picture messages</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_contacts">
      <source>Contats</source>
      <translation variants="no">zh_tw #Contacts</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_sounds">
      <source>Sound files</source>
      <translation variants="no">zh_tw #Sound files</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_mms_bc">
      <source>Wallpapers</source>
      <translation variants="no">zh_tw #Wallpapers</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_videos">
      <source>Video clips</source>
      <translation variants="no">zh_tw #Video clips</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_digital_tones">
      <source>Sound clips</source>
      <translation variants="no">zh_tw #Sound clips</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_images">
      <source>Images</source>
      <translation variants="no">zh_tw #Images</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_links">
      <source>Links</source>
      <translation variants="no">zh_tw #Links</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_pres_logos">
      <source>Presence logos</source>
      <translation variants="no">zh_tw #Presence logos</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_games">
      <source>Games</source>
      <translation variants="no">zh_tw #Games</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_simple_tones">
      <source>Ringing tones</source>
      <translation variants="no">zh_tw #Ringtones</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_install">
      <source>Install files</source>
      <translation variants="no">zh_tw #Installed files</translation>
    </message>
  </context>
</TS>