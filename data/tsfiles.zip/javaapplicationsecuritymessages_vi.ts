<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_secur_info_error_jar_not_found_details">
      <source>Possible reasons for the missing files: the files might reside on a memory card which is not currently present or has been formatted.</source>
      <translation variants="no">vi #Possible reasons for the missing files: the files might reside on a memory card which is not currently present or has been formatted.</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_net_restr_violation_details">
      <source>The application is not allowed to be executed within the current network. This is due to roaming or SIM change. </source>
      <translation variants="no">vi #The application is not allowed to be executed within the current network. This is due to roaming or SIM change. </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_sms_receiving">
      <source>Allow this application to receive SMSs?</source>
      <translation variants="no">vi #Allow this application to receive SMSs?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_app_cannot_start">
      <source>Application start-up failed. </source>
      <translation variants="no">vi #Application start-up failed. </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_ocsp_settings">
      <source>The online revocation checking of the certificate used to sign the application could not be conducted. Check your settings. </source>
      <translation variants="no">vi #The online revocation checking of the certificate used to sign the application could not be conducted. Check your settings. </translation>
    </message>
    <message numerus="yes" id="txt_java_secur_info_sms_sending">
      <source>Allow this application to send %Ln SMSs to %1?</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_smartcard">
      <source>Allow this application to access the smart card?</source>
      <translation variants="no">vi #Allow this application to access the smart card?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_local_connectivity">
      <source>Allow this application to use local connectivity services? </source>
      <translation variants="no">vi #Allow this application to use local connectivity services? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_jar_tampered_details">
      <source>The application’s deployment package has been modified, Application is not trusted anymore therefore it can not be used. You may want to uninstall the application. </source>
      <translation variants="no">vi #The application’s deployment package has been modified, Application is not trusted anymore therefore it can not be used. You may want to uninstall the application. </translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_prompt_deny">
      <source>Deny</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Deny</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_drm_rights_not_valid">
      <source>No digital rights to launch application.</source>
      <translation variants="no">vi #No digital rights to launch application.</translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_prompt_allow">
      <source>Allow </source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Allow </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_ocsp_warning">
      <source>Unable to verify supplier. Continue installation anyway?</source>
      <translation variants="no">vi #Unable to verify supplier. Continue installation anyway?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_push_registration_dynamic">
      <source>Registration for automatic start needed.</source>
      <translation variants="no">vi #Registration for automatic start needed.</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_bluetooth_usage">
      <source>Allow this application to be activated by a Bluetooth device %1?</source>
      <translation variants="no">vi #Allow this application to be activated by a Bluetooth device %1?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_mms_single_sending">
      <source>Allow this application to send MMS? </source>
      <translation variants="no">vi #Allow this application to send MMS? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cbs_opening">
      <source>Allow this application to open a CBS connection?</source>
      <translation variants="no">vi #Allow this application to open a CBS connection?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_url_start">
      <source>Allow this application to be started? </source>
      <translation variants="no">vi #Allow this application to be started? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_positioning_data_usage">
      <source>Allow this application to use positioning data?</source>
      <translation variants="no">vi #Allow this application to use positioning data?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_deleting_category">
      <source>Allow this application to delete category %1 from %2? </source>
      <translation variants="no">vi #Allow this application to delete category %1 from %2? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_receive_send_messages">
      <source>Allow this application to receive and send messages?</source>
      <translation variants="no">vi #Allow this application to receive and send messages?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_sms_opening">
      <source>Allow this application to open a SMS connection? </source>
      <translation variants="no">vi #Allow this application to open a SMS connection? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_network_usage">
      <source>Allow this application to use network for sending/receiving data?</source>
      <translation variants="no">vi #Allow this application to use network for sending/receiving data?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_landmark_data">
      <source>Allow this application to access landmark data?</source>
      <translation variants="no">vi #Allow this application to access landmark data?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_ocsp_revoked">
      <source>Online certificate check failed. The certificate used to sign the application has been revoked either permanently or temporarily (on hold). </source>
      <translation variants="no">vi #Online certificate check failed. The certificate used to sign the application has been revoked either permanently or temporarily (on hold). </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_modifying_contacts">
      <source>Allow this application to modify contacts?</source>
      <translation variants="no">vi #Allow this application to modify contacts?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_jar_tampered">
      <source>The application has been tampered. </source>
      <translation variants="no">vi #The application has been tampered. </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_updating_category">
      <source>Allow this application to update category %1 in %2?</source>
      <translation variants="no">vi #Allow this application to update category %1 in %2?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_modifying_todos">
      <source>Allow this application to modify to-dos?</source>
      <translation variants="no">vi #Allow this application to modify to-dos?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_orientation_data_usage">
      <source>Allow this application to use orientation data?</source>
      <translation variants="no">vi #Allow this application to use orientation data?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cbs_receiving">
      <source>Allow this application to receive CBSs?</source>
      <translation variants="no">vi #Allow this application to receive CBSs?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_deleting_item">
      <source>Allow this application to delete this item from %1?</source>
      <translation variants="no">vi #Allow this application to delete this item from %1?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_contacts">
      <source>Allow this application to read contacts? </source>
      <translation variants="no">vi #Allow this application to read contacts? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_prompt_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Ok</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_adding_calendar">
      <source>Allow this application to create a new calendar?</source>
      <translation variants="no">vi #Allow this application to create a new calendar?</translation>
    </message>
    <message numerus="yes" id="txt_java_secur_info_mms_single_send_multiple_dest">
      <source>Allow this application to send MMS to %Ln recipients?</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cert_disabled">
      <source>The certificate used to authenticate the application has been disabled. You may want to enable the certificate or uninstall the application. </source>
      <translation variants="no">vi #The certificate used to authenticate the application has been disabled. You may want to enable the certificate or uninstall the application. </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_sms_single_sending">
      <source>Allow this application to send SMS to %1?</source>
      <translation variants="no">vi #Allow this application to send SMS to %1?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_user_data">
      <source>Allow this application to read user data?</source>
      <translation variants="no">vi #Allow this application to read user data?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_unexpected_error">
      <source>Unexpected error. </source>
      <translation variants="no">vi #Unexpected error. </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cert_deleted">
      <source>The certificate used to authenticate the application has been deleted therefore the application cannot be used anymore.  You should uninstall the application.</source>
      <translation variants="no">vi #The certificate used to authenticate the application has been deleted therefore the application cannot be used anymore.  You should uninstall the application.</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_file">
      <source>Allow this application to open %1?</source>
      <translation variants="no">vi #Allow this application to open %1?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_updating_item">
      <source>Allow this application to update this item in %1?</source>
      <translation variants="no">vi #Allow this application to update this item in %1?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_auth_services_usage">
      <source>Allow this application to access authentication services?</source>
      <translation variants="no">vi #Allow this application to access authentication services?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_listing_calendars">
      <source>Allow this application to list the calendars available on phone?</source>
      <translation variants="no">vi #Allow this application to list the calendars available on phone?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_unidentified_application">
      <source>The application can not be identified. You may want to uninstall the application. </source>
      <translation variants="no">vi #The application can not be identified. You may want to uninstall the application. </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_unhandled">
      <source>Application error. Application will be closed. </source>
      <translation variants="no">vi #Application error. Application will be closed. </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_updating_unnamed_item">
      <source>Allow this application to update unnamed item in %1? </source>
      <translation variants="no">vi #Allow this application to update unnamed item in %1? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_deleting_unnamed_item">
      <source>Allow this application to delete unnamed item from %1?</source>
      <translation variants="no">vi #Allow this application to delete unnamed item from %1?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_landmarks_data_usage">
      <source>Allow this application to use landmarks data?</source>
      <translation variants="no">vi #Allow this application to use landmarks data?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_net_restr_violation">
      <source>Network restriction violation. </source>
      <translation variants="no">vi #Network restriction violation. </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_tv_broadcast_user_data_access">
      <source>Allow this application to access TV broadcast user data? </source>
      <translation variants="no">vi #Allow this application to access TV broadcast user data? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_modifying_events">
      <source>Allow this application to modify events?</source>
      <translation variants="no">vi #Allow this application to modify events?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_error_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Details</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_network_usage_via_plat_req">
      <source>Allow this application to use network for sending/receiving data? </source>
      <translation variants="no">vi #Allow this application to use network for sending/receiving data? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_app_launch_via_plat_req">
      <source>Allow this application to start an application?</source>
      <translation variants="no">vi #Allow this application to start an application?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_ocsp_general_details">
      <source>Online certificate check failed. The revocation state of the certificate used to sign the application could not be determined. </source>
      <translation variants="no">vi #Online certificate check failed. The revocation state of the certificate used to sign the application could not be determined. </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_sim_changed">
      <source>The certificate used to authenticate the application resides on a SIM which is not currently available.  You may want to reinsert the correct SIM or uninstall the application.</source>
      <translation variants="no">vi #The certificate used to authenticate the application resides on a SIM which is not currently available.  You may want to reinsert the correct SIM or uninstall the application.</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_mms_receiving">
      <source>Allow this application to receive MMSs?</source>
      <translation variants="no">vi #Allow this application to receive MMSs?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_proximity_listener_reg">
      <source>Allow this application to register a proximity listener? </source>
      <translation variants="no">vi #Allow this application to register a proximity listener? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cert_not_available">
      <source>The certificate is not available.</source>
      <translation variants="no">vi #The certificate is not available.</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_audio_video_recording">
      <source>Allow this application to access camera, video player or audio features?</source>
      <translation variants="no">vi #Allow this application to access camera, video player or audio features?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_nfc_ndef_ag_write">
      <source>Allow this application to write into a tag?</source>
      <translation variants="no">vi #Allow this application to write into a tag?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_modifying_file">
      <source>Allow this application to modify %1?</source>
      <translation variants="no">vi #Allow this application to modify %1?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_jar_not_found">
      <source>Application's deployment package not found.</source>
      <translation variants="no">vi #Application's deployment package not found.</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_todos">
      <source>Allow this application to read to-dos? </source>
      <translation variants="no">vi #Allow this application to read to-dos? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_writing_user_data">
      <source>Allow this application to write user data?</source>
      <translation variants="no">vi #Allow this application to write user data?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_unhandled_details">
      <source>Unhandled error. %1</source>
      <translation variants="no">vi #Unhandled error. %1</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_mms_opening">
      <source>Allow this application to open a MMS connection? </source>
      <translation variants="no">vi #Allow this application to open a MMS connection? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_auto_invocation">
      <source>Allow this application to be started automatically?</source>
      <translation variants="no">vi #Allow this application to be started automatically?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_manage_user_data">
      <source>Allow this application to manage user data?</source>
      <translation variants="no">vi #Allow this application to manage user data?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_deleting_calendar">
      <source>Allow this application to delete the calendar file %1? </source>
      <translation variants="no">vi #Allow this application to delete the calendar file %1? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_location_data">
      <source>Allow this application to access location information? </source>
      <translation variants="no">vi #Allow this application to access location information? </translation>
    </message>
    <message numerus="no" id="txt_java_secur_title_app_name">
      <source>%1</source>
      <translation variants="no">vi #%1</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_events">
      <source>Allow this application to read events?</source>
      <translation variants="no">vi #Allow this application to read events?</translation>
    </message>
  </context>
</TS>