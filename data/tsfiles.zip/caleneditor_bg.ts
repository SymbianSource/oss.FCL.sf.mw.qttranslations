<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="bg">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">Отхвърляне на промени</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event ?</source>
      <translation variants="no">Изтриване на запис за цял ден?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_at_the_start">
      <source>At the start</source>
      <translation variants="no">В началото</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_end_time">
      <source>End time</source>
      <translation variants="no">Краен час</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_workdays">
      <source>Workdays</source>
      <translation variants="no">Работни дни</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_start_time">
      <source>Start time</source>
      <translation variants="no">Начален час</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Променяне:</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Всички събития</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Monthly</source>
      <translation variants="no">Ежемесечно</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_time">
      <source>Reminder time</source>
      <translation variants="no">Час за алармата</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Бележка за задача</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_off">
      <source>Off</source>
      <translation variants="no">Изключенa</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_2_days_before">
      <source>2 days before</source>
      <translation variants="no">2 дни преди</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Daily</source>
      <translation variants="no">Ежедневно</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Repeat</source>
      <translation variants="no">Повторение</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Reminder</source>
      <translation variants="no">Аларма</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Only once</source>
      <translation variants="no">Без повторение</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_description">
      <source>Description</source>
      <translation variants="no">Описание</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_30_minutes_befo">
      <source>30 minutes before</source>
      <translation variants="no">30 минути преди</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">Повтаряне до</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Weekly</source>
      <translation variants="no">Седмично</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Изтриване на повторен запис:</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>All day event</source>
      <translation variants="no">Запис за цял ден</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">Добавяне на описание</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_15_minutes_befo">
      <source>15 minutes before</source>
      <translation variants="no">15 минути преди</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_5_minutes_befor">
      <source>5 minutes before</source>
      <translation variants="no">5 минути преди</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_day_before">
      <source>1 day before</source>
      <translation variants="no">1 ден преди</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Start date</source>
      <translation variants="no">Начална дата</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Start time</source>
      <translation variants="no">Начален час</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_hour_before">
      <source>1 hour before</source>
      <translation variants="no">1 час преди</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entry">
      <source>Delete entry?</source>
      <translation variants="no">Изтриване на запис?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_on_event_day">
      <source>On event day</source>
      <translation variants="no">В деня на събитието</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>End date</source>
      <translation variants="no">Крайна дата</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_meeting_saved">
      <source>New meeting saved</source>
      <translation variants="no">Новата среща е запаметена</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Location</source>
      <translation variants="no">Местоположение</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_fortnightly">
      <source>Fortnightly</source>
      <translation variants="no">На 2 седмици</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Delete entries ?</source>
      <translation variants="no">Изтриване на записите?</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">Тема</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_event">
      <source>New event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Нов запис</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Yearly</source>
      <translation variants="no">Ежегодно</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">Остраняв. на описание</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_all_day_event_updated">
      <source>All day event updated</source>
      <translation variants="no">Записът за цял ден е актуализиран</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Среща</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">Изтриване на среща?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">Повтаряне до</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_meeting_updated">
      <source>Meeting updated</source>
      <translation variants="no">Срещата е актуализирана</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_all_day_event_saved">
      <source>New All day event saved</source>
      <translation variants="no">Новият запис за цял ден е запаметен</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Само това събитие</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>End time</source>
      <translation variants="no">Краен час</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_all_day_event">
      <source>All day event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Запис за цял ден</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_location_updated_keep_existing">
      <source>Location updated. Keep existing location on map ?</source>
      <translation variants="no">Местоположението е актуализирано. Запаз­ване на съществува­що местоположение в картата?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Календар</lengthvariant>
      </translation>
    </message>
  </context>
</TS>