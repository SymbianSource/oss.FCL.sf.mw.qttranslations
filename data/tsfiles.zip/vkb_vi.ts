<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_iti_setlabel_itut">
      <source>ITU-T</source>
      <translation variants="no">vi #ITU-T</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_very_slow">
      <source>Very slow</source>
      <translation variants="no">vi #Very slow</translation>
    </message>
    <message numerus="no" id="txt_iti_input_methods">
      <source>Input methods</source>
      <translation variants="no">vi #Input methods</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_handwriting_speed">
      <source>Handwriting speed</source>
      <translation variants="no">vi #Handwriting speed</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_best_prediction">
      <source>Best prediction</source>
      <translation variants="no">vi #Best prediction</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_normal">
      <source>Normal</source>
      <translation variants="no">vi #Normal</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_fast">
      <source>Fast</source>
      <translation variants="no">vi #Fast</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_typing_correction">
      <source>Typing correction</source>
      <translation variants="no">vi #Typing correction</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_portrait_input_method">
      <source>Portrait input method</source>
      <translation variants="no">vi #Portrait input method</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_word_autocompletion">
      <source>Word autocompletion</source>
      <translation variants="no">vi #Word autocompletion</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_default_mode_for_val_english">
      <source>English</source>
      <translation variants="no">vi #English</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_pinyin">
      <source>Pinyin</source>
      <translation variants="no">vi #Pinyin</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_word_autocompletion_val_off">
      <source>Off</source>
      <translation variants="no">vi #Off</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_chinese_input_settings_hk">
      <source>Chinese input settings (HK)</source>
      <translation variants="no">vi #Chinese input settings (HK)</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">vi #Secondary writing language</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_qwerty">
      <source>Qwerty</source>
      <translation variants="no">vi #Qwerty</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_stroke">
      <source>Stroke</source>
      <translation variants="no">vi #Stroke</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_default_mode_for_keyboard_input">
      <source>Default mode for keyboard input</source>
      <translation variants="no">vi #Default mode for keyboard input</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_medium">
      <source>Medium</source>
      <translation variants="no">vi #Medium</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_landscape_input_method">
      <source>Landscape input method</source>
      <translation variants="no">vi #Landscape input method</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_high">
      <source>High</source>
      <translation variants="no">vi #High</translation>
    </message>
    <message numerus="no" id="txt_iti_list_number_keypad">
      <source>Number keypad</source>
      <translation variants="no">vi #Number keypad</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_writing_language">
      <source>Writing language</source>
      <translation variants="no">vi #Writing language</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">vi #Off</translation>
    </message>
    <message numerus="no" id="txt_iti_handwriting">
      <source>Handwriting</source>
      <translation variants="no">vi #Handwriting</translation>
    </message>
    <message numerus="no" id="txt_iti_spell">
      <source>Spell</source>
      <translation variants="no">vi #Spell</translation>
    </message>
    <message numerus="no" id="txt_iti_language">
      <source>Language</source>
      <translation variants="no">vi #Language</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_on">
      <source>On</source>
      <translation variants="no">vi #On</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_primary_candidate">
      <source>Primary candidate</source>
      <translation variants="no">vi #Primary candidate</translation>
    </message>
    <message numerus="no" id="txt_iti_title_word">
      <source>Word:</source>
      <translation variants="no">vi #Word:</translation>
    </message>
    <message numerus="no" id="txt_iti_prediction">
      <source>Prediction</source>
      <translation variants="no">vi #Prediction</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_zhuyin">
      <source>Zhuyin</source>
      <translation variants="no">vi #Zhuyin</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_advanced">
      <source>Advanced</source>
      <translation variants="no">vi #Advanced</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_character_bubble">
      <source>Character bubble</source>
      <translation variants="no">vi #Character bubble</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_normal_chinese">
      <source>Normal</source>
      <translation variants="no">vi #Normal</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_slow">
      <source>Slow</source>
      <translation variants="no">vi #Slow</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_off_typing_corr">
      <source>Off</source>
      <translation variants="no">vi #Off</translation>
    </message>
    <message numerus="no" id="txt_iti_list_letter_keypad">
      <source>Letter keypad</source>
      <translation variants="no">vi #Letter keypad</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_cangjie">
      <source>Cangjie</source>
      <translation variants="no">vi #Cangjie</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_exact_typing">
      <source>Exact typing</source>
      <translation variants="no">vi #Exact typing</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_cangjie_mode">
      <source>Cangjie mode  </source>
      <translation variants="no">vi #Cangjie mode  </translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_hwr">
      <source>HWR</source>
      <translation variants="no">vi #HWR</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_chinese_input_settings_taiwan">
      <source>Chinese input settings (Taiwan)</source>
      <translation variants="no">vi #Chinese input settings (Taiwan)</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_word_autocompletion_val_on">
      <source>On</source>
      <translation variants="no">vi #On</translation>
    </message>
    <message numerus="no" id="txt_iti_prediction_not_supported">
      <source>Prediction not supported</source>
      <translation variants="no">vi #Prediction not supported</translation>
    </message>
    <message numerus="no" id="txt_iti_input_settings">
      <source>Input settings</source>
      <translation variants="no">vi #Input settings</translation>
    </message>
    <message numerus="no" id="txt_iti_on">
      <source>On</source>
      <translation variants="no">vi #On</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_language">
      <source>Language</source>
      <translation variants="no">vi #Language</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_prediction_val_none">
      <source>None</source>
      <translation variants="no">vi #None</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_very_fast">
      <source>Very fast</source>
      <translation variants="no">vi #Very fast</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_keyboard">
      <source>Keyboard</source>
      <translation variants="no">vi #Keyboard</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_on">
      <source>On</source>
      <translation variants="no">vi #On</translation>
    </message>
    <message numerus="no" id="txt_iti_off">
      <source>Off</source>
      <translation variants="no">vi #Off</translation>
    </message>
    <message numerus="no" id="txt_iti_swype">
      <source>Swype</source>
      <translation variants="no">vi #Swype</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_chinese_input_settings_simplified">
      <source>Chinese input settings (Simplified)</source>
      <translation variants="no">vi #Chinese input settings (Simplified)</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_keypress_timeout">
      <source>Keypress timeout</source>
      <translation variants="no">vi #Keypress timeout</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_prediction">
      <source>Prediction</source>
      <translation variants="no">vi #Prediction</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_default_mode_for_val_chinese">
      <source>Chinese</source>
      <translation variants="no">vi #Chinese</translation>
    </message>
    <message numerus="no" id="txt_iti_subhead_prediction_settings">
      <source>Prediction settings</source>
      <translation variants="no">vi #Prediction settings</translation>
    </message>
    <message numerus="no" id="txt_iti_subhead_swype_settings">
      <source>Swype settings</source>
      <translation variants="no">vi #Swype settings</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">vi #Off</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">vi #Primary writing language</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_easy">
      <source>Easy</source>
      <translation variants="no">vi #Easy</translation>
    </message>
  </context>
</TS>