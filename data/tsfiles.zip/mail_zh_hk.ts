<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_viewer_no_subject">
      <source>(No Subject)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(沒有主題)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_cannot_download_attachment_1">
      <source>Cannot download attachment: %[]1 </source>
      <translation variants="no">無法下載附件：%1</translation>
    </message>
    <message numerus="no" id="txt_mail_button_new_mail">
      <source>New</source>
      <translation variants="yes">
        <lengthvariant priority="1">新增</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_title_control_panel">
      <source>Mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">電郵</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_mail_connection_error">
      <source>Mail connection error.</source>
      <translation variants="no">電郵連接錯誤</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority">
      <source>Add priority</source>
      <translation variants="no">加入優先順序</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_to">
      <source>To:</source>
      <translation variants="no">zh_hk #To:</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_remove_all">
      <source>Remove all</source>
      <translation variants="no">全部移除</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_send_via">
      <source>Send via</source>
      <translation variants="no">通過此郵箱傳送</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_cc">
      <source>Cc:</source>
      <translation variants="no">zh_hk #Cc:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_sending_mail">
      <source>Sending mail</source>
      <translation variants="no">電郵傳送中</translation>
    </message>
    <message numerus="no" id="txt_mail_list_cc">
      <source>Cc:</source>
      <translation variants="no">副本：</translation>
    </message>
    <message numerus="yes" id="txt_mail_dialog_you_can_not_send_more_than_l1_att">
      <source>You can not send more than %Ln attachments at a time </source>
      <translation>
        <numerusform plurality="a">zh_hk #Unable to send more than %Ln attachment at a time</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">zh_hk ##Delete</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_attachments_should_be_smaller_than">
      <source>Attachments should be smaller than %L1 Mb</source>
      <translation variants="no">附件必須小於%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_mail_list_to">
      <source>To:</source>
      <translation variants="no">接收者：</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_bcc">
      <source>Bcc:</source>
      <translation variants="no">zh_hk #Bcc:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_you_can_not_send_more_than_l1_kb">
      <source>You can not send more than %L1 Mb as attachments </source>
      <translation variants="no">無法傳送總大小超過%L1 MB的附件</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_subject">
      <source>Subject:</source>
      <translation variants="no">zh_hk #Subject:</translation>
    </message>
    <message numerus="no" id="txt_mail_title_mail">
      <source>Mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">電郵</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no_mailboxes_defined">
      <source>No mailboxes defined</source>
      <translation variants="no">zh_hk #No mailboxes defined</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_opening_mail_editor">
      <source>Opening mail editor</source>
      <translation variants="no">正在開啟電郵編輯器</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_mark_as_read">
      <source>Mark as read</source>
      <translation variants="no">標記為已讀取</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_complete_command">
      <source>Unable to complete the command</source>
      <translation variants="no">不能執行操作</translation>
    </message>
    <message numerus="no" id="txt_short_caption_mail">
      <source>Mail</source>
      <translation variants="no">zh_hk ##Mail</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_open_attachment_file_ty">
      <source>Unable to open. Attachment file type not supported</source>
      <translation variants="no">無法開啟。不支援附件檔案類型。</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_val_no_subject">
      <source>(No Subject)</source>
      <translation variants="no">zh_hk #(no subject)</translation>
    </message>
    <message numerus="no" id="txt_mail_button_attach">
      <source>Attach</source>
      <translation variants="yes">
        <lengthvariant priority="1">附加</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">zh_hk ##Open</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_send_and_receive_now">
      <source>Refresh</source>
      <translation variants="no">重新整理</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_low">
      <source>Low</source>
      <translation variants="no">低</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_add_attachment">
      <source>Unable to add attachment </source>
      <translation variants="no">無法加入附件</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_mark_as_unread">
      <source>Mark as unread</source>
      <translation variants="no">標記為未讀取</translation>
    </message>
    <message numerus="no" id="txt_common_opt_settings">
      <source>Settings</source>
      <translation variants="no">zh_hk ##Settings</translation>
    </message>
    <message numerus="no" id="txt_mail_list_l1_mb">
      <source>(%L1 Mb)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_from">
      <source>From:</source>
      <translation variants="no">傳送者：</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_delete_mail">
      <source>Delete mail?</source>
      <translation variants="no">是否刪除電郵？</translation>
    </message>
    <message numerus="no" id="txt_mail_text_attachment">
      <source>attachment</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #attachment</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_subject">
      <source>Subject:</source>
      <translation variants="no">主題：</translation>
    </message>
    <message numerus="no" id="txt_mail_subhead_inbox">
      <source>Inbox </source>
      <translation variants="no">zh_hk #Inbox </translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_cc">
      <source>Cc:</source>
      <translation variants="no">副本：</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_sent">
      <source>Sent:</source>
      <translation variants="no">已傳送：</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_from">
      <source>From:</source>
      <translation variants="no">傳送者：</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_still_sending">
      <source>Still sending mail %[]1. Please wait operation to complete</source>
      <translation variants="no">仍在傳送電郵%[55]1。請等候操作完成。</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance_low">
      <source>Low</source>
      <translation variants="no">低</translation>
    </message>
    <message numerus="no" id="txt_mail_reply_subject_prefix">
      <source>Re:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #RE:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_select_file">
      <source>Select file</source>
      <translation variants="no">zh_hk #Select file</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_loading_mail_content">
      <source>Loading mail content</source>
      <translation variants="no">正在載入電郵內容</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance">
      <source>Importance:</source>
      <translation variants="no">重要性：</translation>
    </message>
    <message numerus="no" id="txt_mail_select_contacts">
      <source>Select contacts</source>
      <translation variants="no">zh_hk #Select contacts</translation>
    </message>
    <message numerus="no" id="txt_mail_status_menu_new_mail">
      <source>New Mail</source>
      <translation variants="no">zh_hk #New mail</translation>
    </message>
    <message numerus="no" id="txt_mail_forward_subject_prefix">
      <source>Fw:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #FW:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_reply_all">
      <source>Reply all</source>
      <translation variants="no">全部回覆</translation>
    </message>
    <message numerus="no" id="txt_mail_status_menu_waiting_to_send">
      <source>Waiting to send (%L1)</source>
      <translation variants="no">zh_hk #Waiting to send (%L1)</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_sending_failed">
      <source>Sending mail %[]1 failed. Try to send it again or press back to cancel</source>
      <translation variants="no">傳送失敗：
%[27]1。
請嘗試再次傳送，或按"返回"以取消。</translation>
    </message>
    <message numerus="no" id="txt_mail_dpophead_1_deleted">
      <source>Mailbox deleted. </source>
      <translation variants="no">郵箱已刪除</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_invalid_mail_address_send">
      <source>Invalid mail address: %[]1. Send anyway?</source>
      <translation variants="no">電郵地址無效：
%[41]1。
是否仍要傳送？</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_original_msg">
      <source>---- Original message ----</source>
      <translation variants="no">---- 原始訊息 ----</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_mail_address_incorrect">
      <source>Your mail address is incorrect. Check the mail address settings?</source>
      <translation variants="no">zh_hk #Incorrect mail address. Check mail address settings?</translation>
    </message>
    <message numerus="no" id="txt_mail_shareui_sending_please_wait">
      <source>Sending, please wait</source>
      <translation variants="no">傳送中</translation>
    </message>
    <message numerus="no" id="txt_mail_shareui_send_as_mail">
      <source>Send as new mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Send as new mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_server_settings_incorrect">
      <source>Server settings are incorrect. Do you want to check the settings?</source>
      <translation variants="no">伺服器設定不正確。是否檢查設定？</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no">
      <source>No</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_reply">
      <source>Reply</source>
      <translation variants="no">回覆</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_drafts">
      <source>Drafts</source>
      <translation variants="no">草稿</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_deleted">
      <source>Deleted items</source>
      <translation variants="no">已刪除項目</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_yes">
      <source>Yes</source>
      <translation variants="no">是</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_inbox">
      <source>Inbox </source>
      <translation variants="no">收件匣</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_sent">
      <source>Sent</source>
      <translation variants="no">寄件備份</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_show_cc_bcc">
      <source>Show cc / bcc</source>
      <translation variants="no">顯示副本/密件副本</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_address_or_password_incorrect">
      <source>Username or password is incorrect. Do you want to check the settings?</source>
      <translation variants="no">電郵地址或密碼不正確。是否檢查設定？</translation>
    </message>
    <message numerus="no" id="txt_mail_list_new_video">
      <source>New video</source>
      <translation variants="yes">
        <lengthvariant priority="1">新短片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_do_you_want_to_delete_the_mailbox">
      <source>Do you want to delete the mailbox and all mail messages?</source>
      <translation variants="no">是否刪除郵箱和其中的所有訊息？</translation>
    </message>
    <message numerus="no" id="txt_mail_list_searching">
      <source>Seaching</source>
      <translation variants="no">zh_hk #Searching</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_do_you_want_to_delete_mfe">
      <source>Do you want to delete all mail, calendar, contacts and tasks data related to this account?</source>
      <translation variants="no">是否刪除所有與此帳號相關的電郵、日曆、聯絡人和工作數據？</translation>
    </message>
    <message numerus="no" id="txt_mail_list_photo">
      <source>Photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">圖像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_deleting_mailbox">
      <source>Deleting mailbox</source>
      <translation variants="no">正在刪除郵箱</translation>
    </message>
    <message numerus="no" id="txt_common_menu_remove">
      <source>Remove</source>
      <translation variants="no">zh_hk ##Remove</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_downloading_canceled">
      <source>Not enough memory - downloading canceled</source>
      <translation variants="no">下載已取消。記憶體不足。</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_hide_cc_bcc">
      <source>Hide cc / bcc</source>
      <translation variants="no">隱藏副本/密件副本</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_1_deleted">
      <source>%[]1 deleted.</source>
      <translation variants="no">已刪除：
%1</translation>
    </message>
    <message numerus="no" id="txt_mail_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">其他</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_new_photo">
      <source>New photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">新圖像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_normal">
      <source>Normal</source>
      <translation variants="no">中</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_high">
      <source>High</source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_no_messages">
      <source>(No messages)</source>
      <translation variants="no">zh_hk #(no messages)</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mail">
      <source>Mail</source>
      <translation variants="no">電郵</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_save_message_to_drafts">
      <source>Do you want to save this message to drafts?</source>
      <translation variants="no">zh_hk #Save this message to Drafts?</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_to">
      <source>To:</source>
      <translation variants="no">接收者：</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance_high">
      <source>High</source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_forward">
      <source>Forward</source>
      <translation variants="no">轉發</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_no_messages_matched_your_search">
      <source>No messages matched your search. Try another search term. </source>
      <translation variants="no">zh_hk #No search results found. Redefine search criteria. </translation>
    </message>
    <message numerus="no" id="txt_mail_dpophead_loading_mail_content">
      <source>Loading mail content</source>
      <translation variants="no">正在載入電郵內容</translation>
    </message>
    <message numerus="no" id="txt_mail_list_video">
      <source>Video</source>
      <translation variants="yes">
        <lengthvariant priority="1">短片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_delete">
      <source>Delete</source>
      <translation variants="no">刪除</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_outbox">
      <source>Outbox</source>
      <translation variants="no">送件匣</translation>
    </message>
    <message numerus="yes" id="txt_mail_list_search_results">
      <source>%Ln results</source>
      <translation>
        <numerusform plurality="a">zh_hk #%Ln result</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_invalid_mail_address">
      <source>Invalid mail address: %[]1</source>
      <translation variants="no">電郵地址無效：
%1</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no_mailboxes_create_new">
      <source>No mailboxes have been defined. Would you like to create a new mailbox?</source>
      <translation variants="no">尚未定義郵箱。是否新增郵箱？</translation>
    </message>
  </context>
</TS>