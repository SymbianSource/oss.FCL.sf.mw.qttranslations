<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_widget_info_no_messages">
      <source>(No messages)</source>
      <translation variants="no">zh #(no messages)</translation>
    </message>
    <message numerus="no" id="txt_mail_widget_list_l1">
      <source>(%L1)</source>
      <translation variants="no">zh #(%L1)</translation>
    </message>
  </context>
</TS>