<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_software_setlabel_val_on">
      <source>On</source>
      <translation variants="no">开</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_downloading_1">
      <source>Downloading %1</source>
      <translation variants="no">正在下载%1</translation>
    </message>
    <message numerus="no" id="txt_software_info_application_update_is_available">
      <source>Application update is available from Nokia. Update?</source>
      <translation variants="no">诺基亚提供应用程序更新。更新？</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_recommended_mb">
      <source>Recommended (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">推荐(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_refreshing_failed_try_agai">
      <source>Refreshing failed. Try again later.</source>
      <translation variants="no">刷新失败。稍后再试。</translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_network_connection">
      <source>Network connection</source>
      <translation variants="no">网络连接</translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_refreshing_updates_list">
      <source>Refreshing updates list</source>
      <translation variants="no">正在刷新更新列表</translation>
    </message>
    <message numerus="no" id="txt_software_info_this_application_allows_you_to_d">
      <source>This application allows you to download and use applications and services provided by Nokia or third parties. Service Terms and Privacy Policy will apply. Nokia will not assume any liability or responsibility for the availability or third party applications or services. Before using the third party application or service, read the applicable terms of use. Use of this application involves transmission of data.&lt;br /&gt;Contact your network service provider for information about data transmission charges.&lt;br /&gt;(c) %L1-%L2 Nokia. All rights reserved.</source>
      <translation variants="no">此应用程序允许您下载和使用由诺基亚或第三方提供的应用程序和服务。须遵守服务条款和隐私策略。诺基亚不对第三方应用程序或服务的可用性承担任何责任。在使用第三方应用程序或服务前，请阅读适用的使用条款。使用此应用程序涉及数据传输。&lt;br /&gt;联系您的网络服务提供商来了解有关数据传输费用的信息。&lt;br /&gt;(c) %L1-%L2 诺基亚。保留所有权利。 </translation>
    </message>
    <message numerus="no" id="txt_software_dpopinfo_tap_to_view">
      <source>Tap to view</source>
      <translation variants="no">点击查看</translation>
    </message>
    <message numerus="no" id="txt_software_info_device_restart_is_needed_restar">
      <source>Device restart is needed. Restart now?</source>
      <translation variants="no">需要重启设备。马上重启？</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_application_updates">
      <source>Application updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">应用程序更新</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_subhead_selected_1l_2l_3l_kb">
      <source>Selected %L1/%L2 (%L3 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">已选：%L1/%L2 (%L3 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">关</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_size">
      <source>Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">大小：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_update_checking">
      <source>Update checking</source>
      <translation variants="no">更新检查</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_name">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">名称：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_this_required_update_cannot_be_o">
      <source>This required update cannot be omitted.</source>
      <translation variants="no">必需更新 - 不能省略</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_device_software_available">
      <source>Device software available</source>
      <translation variants="yes">
        <lengthvariant priority="1">设备软件可用</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_software_update">
      <source>Software update</source>
      <translation variants="yes">
        <lengthvariant priority="1">软件更新</lengthvariant>
        <lengthvariant priority="2">zh #SW update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_val_on_in_home_network">
      <source>On in home network</source>
      <translation variants="no">在注册网络中打开</translation>
    </message>
    <message numerus="no" id="txt_software_info_insufficient_memory_free_some_m">
      <source>Insufficient memory. Free some memory and try again.</source>
      <translation variants="no">存储不足。释放一些存储后再试。</translation>
    </message>
    <message numerus="no" id="txt_software_opt_cancel_update">
      <source>Cancel update</source>
      <translation variants="no">取消更新</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_required_kb">
      <source>Required (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">必需(%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_subhead_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_selected_update_also_needs_updat">
      <source>Selected update also needs updates "%1" to work</source>
      <translation variants="no">选择的更新还需要有这些更新才能工作：
%1</translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_update_available">
      <source>Update available</source>
      <translation variants="no">更新可用</translation>
    </message>
    <message numerus="no" id="txt_software_info_selected_update_also_needs_1">
      <source>Selected update also needs "%1" to work</source>
      <translation variants="no">选择的更新还需要有此更新才能工作：
%1</translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_updates_available">
      <source>Updates available</source>
      <translation variants="no">更新可用</translation>
    </message>
    <message numerus="no" id="txt_software_info_this_update_improves_your_device">
      <source>This update improves your device performance and brings you latest features.</source>
      <translation variants="no">此更新将改善您的设备性能并带来最新功能。</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_recommended_kb">
      <source>Recommended (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">推荐(%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_applications_are_up_to_date">
      <source>Applications are up to date</source>
      <translation variants="no">应用程序为最新版</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_device_software">
      <source>Device software</source>
      <translation variants="yes">
        <lengthvariant priority="1">设备软件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_version_1l_2l_3l">
      <source>%L1.%L2 (%L3)</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1.%L2 (%L3)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_version">
      <source>Version:</source>
      <translation variants="yes">
        <lengthvariant priority="1">版本：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_allow_automatic_update_checks">
      <source>Allow automatic update checks?</source>
      <translation variants="no">允许自动更新检查?</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_installing_1">
      <source>Installing %1</source>
      <translation variants="no">正在安装%1</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_required_mb">
      <source>Required (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">必需(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_opt_disclaimer">
      <source>Disclaimer</source>
      <translation variants="no">免责声明</translation>
    </message>
    <message numerus="no" id="txt_software_opt_settings">
      <source>Settings</source>
      <translation variants="no">设置</translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_autocheck_for_updates">
      <source>Auto-check for updates</source>
      <translation variants="no">自动检查更新</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">说明：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_subhead_selected_1l_2l_3l_mb">
      <source>Selected %L1/%L2 (%L3 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">已选：%L1/%L2 (%L3 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_accept">
      <source>Accept</source>
      <translation variants="yes">
        <lengthvariant priority="1">接受</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_decline">
      <source>Decline</source>
      <translation variants="yes">
        <lengthvariant priority="1">拒绝</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_later">
      <source>Later</source>
      <translation variants="yes">
        <lengthvariant priority="1">稍后</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_now">
      <source>Now</source>
      <translation variants="yes">
        <lengthvariant priority="1">马上</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_iaupdatelauncher">
      <source>Software update</source>
      <translation variants="no">软件更新</translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_successful">
      <source>%Ln updates successful</source>
      <translation>
        <numerusform plurality="a">%Ln个成功更新</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_important_kb">
      <source>Important (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">重要(%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_optional_mb">
      <source>Optional (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">可选(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_updates_1_need_deselected_upd">
      <source>Updates "%1" need deselected update to work</source>
      <translation variants="no">更新"%[57]1"必需此更新才能工作</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_optional_kb">
      <source>Optional (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">可选(%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_l_mb">
      <source>%L MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_update_1_needs_deselected_upd">
      <source>Update "%1" needs deselected update to work</source>
      <translation variants="no">更新"%[59]1"必需此更新才能工作</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_important_mb">
      <source>Important (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">重要(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_cancelled">
      <source>%Ln updates cancelled</source>
      <translation>
        <numerusform plurality="a">%Ln个已取消更新</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_l_kb">
      <source>%L kB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 kB</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_failed">
      <source>%Ln updates failed</source>
      <translation>
        <numerusform plurality="a">%Ln个失败更新</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_installing_1">
      <source>Installing 1%</source>
      <translation variants="no">正在安装%1</translation>
    </message>
    <message numerus="no" id="txt_software_title_dependencies">
      <source>Dependencies</source>
      <translation variants="yes">
        <lengthvariant priority="1">依赖关系</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_update_results">
      <source>Update results</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新结果</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_disclaimer">
      <source>Disclaimer</source>
      <translation variants="yes">
        <lengthvariant priority="1">免责声明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_downloaded">
      <source>Downloaded</source>
      <translation variants="yes">
        <lengthvariant priority="1">已下载</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_cancel">
      <source>Cancel</source>
      <translation variants="no">zh #Cancel</translation>
    </message>
    <message numerus="no" id="txt_software_info_please_use_your_pc_to_update_the">
      <source>Use your PC to update the device software ([version %L])  from address www.nokia.com/softwareupdate</source>
      <translation variants="no">zh #Use your PC to update your device's software (version %[]1)  from web address &lt;a href=http://www.nokia.com/softwareupdate”&gt;http://www.nokia.com/softwareupdate&lt;/a&gt;</translation>
    </message>
    <message numerus="yes" id="txt_software_dblist_val_ln_update">
      <source>%Ln updates</source>
      <translation>
        <numerusform plurality="a">%Ln个更新</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_val_not_activated">
      <source>Not activated</source>
      <translation variants="no">未启动</translation>
    </message>
    <message numerus="no" id="txt_software_button_update">
      <source>Update</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_available">
      <source>Update available</source>
      <translation variants="no">更新可用</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_checking">
      <source>Update checking</source>
      <translation variants="no">更新检查</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_updates_available">
      <source>Updates available</source>
      <translation variants="no">更新可用</translation>
    </message>
    <message numerus="no" id="txt_short_caption_iaupdate">
      <source>Software update</source>
      <translation variants="no">zh #Softw. update</translation>
    </message>
    <message numerus="no" id="txt_short_caption_iaupdatelauncher">
      <source>Software update</source>
      <translation variants="no">zh #Softw. update</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_failed">
      <source>Failed</source>
      <translation variants="yes">
        <lengthvariant priority="1">失败</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_updated">
      <source>Updated</source>
      <translation variants="yes">
        <lengthvariant priority="1">已更新</lengthvariant>
      </translation>
    </message>
  </context>
</TS>