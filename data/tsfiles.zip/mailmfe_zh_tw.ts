<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailmfe_list_version_l1">
      <source>Version: %[]1</source>
      <translation variants="no">zh_tw #Version: %[512]1</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_calendar">
      <source>Calendar</source>
      <translation variants="no">行事曆</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_1_month_back">
      <source>1 month back</source>
      <translation variants="no">1個月</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_username">
      <source>Username</source>
      <translation variants="no">使用者名稱</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_my_name">
      <source>My name</source>
      <translation variants="no">我的名稱</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_password">
      <source>Password</source>
      <translation variants="no">密碼</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_3_days_back">
      <source>3 days back</source>
      <translation variants="no">3天</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_show_mail_in_other_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">在其他資料夾中顯示郵件</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_1_week_back">
      <source>1 week back</source>
      <translation variants="no">1週</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_fri">
      <source>Fri</source>
      <translation variants="no">星期五</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_as_defined">
      <source>The mailbox is refreshed as defined by the user</source>
      <translation variants="no">信箱內容會依照使用者的定義重新整理</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_every_15_mi">
      <source>The mailbox is refreshed every 15 minutes during daytime</source>
      <translation variants="no">信箱內容在白天會每隔15分鐘重新整理一次</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_secure_connection">
      <source>Secure connection</source>
      <translation variants="no">安全連線</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_tasks">
      <source>Tasks</source>
      <translation variants="no">待辦事項</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_only_by_use">
      <source>The mailbox is refreshed only by user request</source>
      <translation variants="no">信箱內容只會在使用者自行啟動時重新整理</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_server_info">
      <source>Server info</source>
      <translation variants="no">伺服器設定</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_day_end_time">
      <source>Day end time</source>
      <translation variants="no">白天結束時間</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_during_daytime_val_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_receiving_schedule">
      <source>Receiving Schedule</source>
      <translation variants="no">擷取排程</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_preferences">
      <source>Preferences</source>
      <translation variants="no">帳號設定</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_contacts">
      <source>Contacts</source>
      <translation variants="no">通訊錄</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="no">每4小時</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">重新整理信箱</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_keep_uptodat">
      <source>Keep up-to-date</source>
      <translation variants="no">保持最新狀態</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_sun">
      <source>Sun</source>
      <translation variants="no">星期日</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_receiving_weekdays">
      <source>Receiving weekdays</source>
      <translation variants="no">擷取日</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_every_day">
      <source>Every day</source>
      <translation variants="no">每天</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_user_defined">
      <source>User defined</source>
      <translation variants="no">使用者自訂</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_connection">
      <source>Connection</source>
      <translation variants="no">連線</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_3_months_back">
      <source>3 months back</source>
      <translation variants="no">3個月</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_tue">
      <source>Tue</source>
      <translation variants="no">星期二</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_6_months_back">
      <source>6 months back</source>
      <translation variants="no">6個月</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_day_start_time">
      <source>Day start time</source>
      <translation variants="no">白天開始時間</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_button_delete_mailbox">
      <source>Delete mailbox</source>
      <translation variants="no">刪除信箱</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_port">
      <source>Port</source>
      <translation variants="no">通訊埠</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_notes">
      <source>Notes</source>
      <translation variants="no">記事本</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_fetch_manually">
      <source>Fetch manually</source>
      <translation variants="no">手動擷取郵件</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode">
      <source>Selected mode</source>
      <translation variants="no">使用中的重新整理選項</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_mailbox_name">
      <source>Mailbox name</source>
      <translation variants="no">信箱名稱</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_keep_uptodate">
      <source>Keep up-to-date</source>
      <translation variants="no">保持最新狀態</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">郵件位址</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_during_daytime_val_on">
      <source>On</source>
      <translation variants="no">開</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_server">
      <source>Server</source>
      <translation variants="no">伺服器</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_received_items">
      <source>Received items</source>
      <translation variants="no">要同步處理的項目</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_sat">
      <source>Sat</source>
      <translation variants="no">星期六</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_1_hour">
      <source>Every 1 hour</source>
      <translation variants="no">zh_tw #Every 1 hour</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_mon">
      <source>Mon</source>
      <translation variants="no">星期一</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_user_info">
      <source>User info</source>
      <translation variants="no">使用者設定</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_thu">
      <source>Thu</source>
      <translation variants="no">星期四</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_show_mail_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">在收件匣中顯示郵件</translation>
    </message>
    <message numerus="no" id="txt_mailnmfe_setlabel_signature">
      <source>Signature</source>
      <translation variants="no">zh_tw #Signature</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_domain">
      <source>Domain</source>
      <translation variants="no">網域</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_save_energy">
      <source>Save energy</source>
      <translation variants="no">省電</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_mail">
      <source>Mail</source>
      <translation variants="no">郵件</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_uptodate_during_day">
      <source>The mailbox is up-to-date during daytime</source>
      <translation variants="no">信箱內容在白天會保持最新狀態</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="no">每15分鐘</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_wed">
      <source>Wed</source>
      <translation variants="no">星期三</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_when_i_open_mailbox">
      <source>When I open mailbox</source>
      <translation variants="no">當我開啟信箱時</translation>
    </message>
  </context>
</TS>