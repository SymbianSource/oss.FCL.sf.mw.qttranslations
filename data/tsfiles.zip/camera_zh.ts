<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cam_list_night_portrait">
      <source>Night portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Night portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sports">
      <source>Sports</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Sport</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_portrait">
      <source>Portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer">
      <source>Self timer</source>
      <translation variants="no">自动定时器</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos">
      <source>Go to Photos</source>
      <translation variants="no">照片</translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode">
      <source>Camera in stand-by mode</source>
      <translation variants="no">照相机处于待机状态</translation>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">曝光补偿</translation>
    </message>
    <message numerus="no" id="txt_cam_list_landscape">
      <source>Landscape</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Landscape</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings">
      <source>Camera settings</source>
      <translation variants="no">照相/摄像机设置</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_stabilization">
      <source>Video stabilization</source>
      <translation variants="no">防抖功能</translation>
    </message>
    <message numerus="no" id="txt_short_caption_camera">
      <source>Camera</source>
      <translation variants="no">zh #Camera</translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">zh #Exposure compensation</translation>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone">
      <source>Color tone</source>
      <translation variants="no">zh #Colour tone</translation>
    </message>
    <message numerus="no" id="txt_cam_title_memory_in_use">
      <source>Memory in use</source>
      <translation variants="no">使用的存储</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_video">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_video">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">夜间</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_43">
      <source>VGA 4:3</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA 4:3</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_memory_in_use">
      <source>Memory in use</source>
      <translation variants="no">使用的存储</translation>
    </message>
    <message numerus="no" id="txt_cam_button_cancel">
      <source>Cancel</source>
      <translation variants="no">取消</translation>
    </message>
    <message numerus="no" id="txt_cam_other_please_type_here">
      <source>Please type here</source>
      <translation variants="no">在此键入</translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_image_name">
      <source>Default image name</source>
      <translation variants="no">预设图像名称</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_qcif_sharing">
      <source>QCIF Sharing</source>
      <translation variants="yes">
        <lengthvariant priority="1">QCIF共享</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_memory_card">
      <source>Memory card</source>
      <translation variants="yes">
        <lengthvariant priority="1">存储卡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_face">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">用户自定义</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_sound">
      <source>Video sound</source>
      <translation variants="no">视频声音</translation>
    </message>
    <message numerus="no" id="txt_cam_other_default_image_name">
      <source>Default image name</source>
      <translation variants="no">预设图像名称</translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">连续</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga">
      <source>VGA</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance">
      <source>White balance</source>
      <translation variants="no">zh #White balance</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">显示拍摄的图像</translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image">
      <source>Delete image?</source>
      <translation variants="no">删除图像？</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_image">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_lightsens">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自动</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">显示拍摄的视频</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_stabil">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus">
      <source>+%L1</source>
      <translation variants="no">+%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_list_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode">
      <source>Flash mode</source>
      <translation variants="no">闪光灯</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_video">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound">
      <source>Video sound</source>
      <translation variants="no">视频声音</translation>
    </message>
    <message numerus="no" id="txt_cam_title_change_mode">
      <source>Change mode</source>
      <translation variants="no">更改模式</translation>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camcorder">
      <source>Secondary camcorder</source>
      <translation variants="yes">
        <lengthvariant priority="1">辅助摄像机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip">
      <source>Delete video clip?</source>
      <translation variants="no">删除视频片段？</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_flash">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_flash">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds">
      <source>%Ln seconds</source>
      <translation>
        <numerusform plurality="a">%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_start">
      <source>Start</source>
      <translation variants="no">开始</translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_stabilization">
      <source>Video stabilization</source>
      <translation variants="no">防抖功能</translation>
    </message>
    <message numerus="no" id="txt_cam_list_reduce_red_eye">
      <source>Reduce red eye</source>
      <translation variants="yes">
        <lengthvariant priority="1">消除红眼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_set_as_default_scene_mode">
      <source>Set as default scene mode</source>
      <translation variants="no">设为预设场景模式</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_geotagging">
      <source>Geotagging</source>
      <translation variants="no">标记位置</translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_rotation">
      <source>Image rotation</source>
      <translation variants="no">图像旋转</translation>
    </message>
    <message numerus="no" id="txt_cam_list_incandescent">
      <source>Incandescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">白炽灯</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">连续</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_white">
      <source>Black and white</source>
      <translation variants="yes">
        <lengthvariant priority="1">黑白色</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">照相/摄像机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_contrast">
      <source>Contrast</source>
      <translation variants="no">zh #Contrast</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_scene">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality">
      <source>Image quality</source>
      <translation variants="no">图像质量</translation>
    </message>
    <message numerus="no" id="txt_cam_other_restore_settings">
      <source>Restore settings?</source>
      <translation variants="no">恢复设置？</translation>
    </message>
    <message numerus="no" id="txt_cam_button_geotagging">
      <source>Geotagging</source>
      <translation variants="no">zh #Geotagging</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_rotation">
      <source>Image rotation</source>
      <translation variants="no">图像旋转</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">夜间</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left">
      <source>%Ln images left</source>
      <translation>
        <numerusform plurality="a">剩余%Ln个图像</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_low_light">
      <source>Low light</source>
      <translation variants="yes">
        <lengthvariant priority="1">光线较弱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_video">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">是</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">拍摄音</translation>
    </message>
    <message numerus="no" id="txt_long_caption_camera ">
      <source>Camera</source>
      <translation variants="no">照相/摄像机</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_phone_memory">
      <source>Phone memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机存储</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_face_tracking">
      <source>Face tracking</source>
      <translation variants="no">人脸检测</translation>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer">
      <source>Self timer</source>
      <translation variants="no">自动定时器</translation>
    </message>
    <message numerus="no" id="txt_cam_list_negative">
      <source>Negative</source>
      <translation variants="yes">
        <lengthvariant priority="1">负片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_no_memory_card_in_device_please_inse">
      <source>No memory card in device. Please insert memory card in order to capture images.</source>
      <translation variants="no">未插入存储卡。插入存储卡以拍摄图像。</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings">
      <source>General settings</source>
      <translation variants="no">设置</translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_rotate">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">是</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_169_widescreen">
      <source>HD 720p 16:9 widescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">高清720p 16:9宽屏</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity">
      <source>Light sensitivity</source>
      <translation variants="no">感光度</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_video">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_image">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">是</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_rotate">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_stabil">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_iso">
      <source>ISO</source>
      <translation variants="no">zh #ISO</translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use">
      <source>Camera already in use</source>
      <translation variants="no">照相机已被另一个应用程序使用</translation>
    </message>
    <message numerus="no" id="txt_cam_list_closeup">
      <source>Close-up</source>
      <translation variants="yes">
        <lengthvariant priority="1">特写</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name">
      <source>Default video name</source>
      <translation variants="no">预设视频名称</translation>
    </message>
    <message numerus="no" id="txt_cam_caption_camera">
      <source>Camera</source>
      <translation variants="no">zh #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_face">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance">
      <source>White balance</source>
      <translation variants="no">白平衡</translation>
    </message>
    <message numerus="no" id="txt_cam_list_camcorder">
      <source>Camcorder</source>
      <translation variants="yes">
        <lengthvariant priority="1">摄像机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_whitebal">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自动</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality">
      <source>Video quality</source>
      <translation variants="no">视频质量</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_timer">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality">
      <source>Video quality</source>
      <translation variants="no">视频质量</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_flash">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自动</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_settings">
      <source>Settings</source>
      <translation variants="no">设置</translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode">
      <source>Scene mode</source>
      <translation variants="no">场景模式</translation>
    </message>
    <message numerus="no" id="txt_cam_list_not">
      <source>Not specified</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_cam_info_error">
      <source>Unexpected error occurred. Power off the device and restart</source>
      <translation variants="no">发生意外错误。重新启动手机。</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_val_ln_recording_time_left">
      <source>Recording time left: %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">剩余录制时间：%L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_restore_settings">
      <source>Restore settings</source>
      <translation variants="no">恢复设置</translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined_scene">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">用户自定义</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">显示拍摄的图像</translation>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camera">
      <source>Secondary camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">辅助摄像机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_fluorescent">
      <source>Fluorescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">荧光灯</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_white_balance">
      <source>White balance</source>
      <translation variants="no">白平衡</translation>
    </message>
    <message numerus="no" id="txt_cam_list_not_video">
      <source>Not</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_captured_photos_and_videos_will_be_ta">
      <source>Captured photos and videos will be tagged with your location. If photos or videos are shared, the location data may also be visible to third parties. Phone will use network to get the location data. Data transfer charges may apply. Location recording can be disabled in settings.</source>
      <translation variants="no">拍摄的照片和视频上将标出您的位置。如果照片或视频将被共享，第三方也能看到位置数据。手机将通过网络获取位置数据。可能收取数据传输费。可以在设置中关闭位置记录。</translation>
    </message>
    <message numerus="no" id="txt_cam_title_contrast">
      <source>Contrast</source>
      <translation variants="no">对比度</translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">显示拍摄的视频</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_mass_memory">
      <source>Mass memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">大容量存储</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_scene">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking">
      <source>Face tracking</source>
      <translation variants="no">zh #Face detection</translation>
    </message>
    <message numerus="no" id="txt_cam_list_vivid">
      <source>Vivid</source>
      <translation variants="yes">
        <lengthvariant priority="1">鲜艳</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus">
      <source>-%L1</source>
      <translation variants="no">-%L1</translation>
    </message>
    <message numerus="yes" id="txt_cam_other_delete_n_items">
      <source>Delete %Ln items?</source>
      <translation>
        <numerusform plurality="a">删除%Ln项？</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_cloudy">
      <source>Cloudy</source>
      <translation variants="yes">
        <lengthvariant priority="1">阴天</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">拍摄音</translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_video_name">
      <source>Default video name</source>
      <translation variants="no">预设视频名称</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sunny">
      <source>Sunny</source>
      <translation variants="yes">
        <lengthvariant priority="1">晴天</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name">
      <source>Default image name</source>
      <translation variants="no">预设图像名称</translation>
    </message>
    <message numerus="no" id="txt_cam_title_set_as_default_scene_mode">
      <source>Set as default scene mode</source>
      <translation variants="no">设为预设场景模式</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality">
      <source>Image quality</source>
      <translation variants="no">图像质量</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sepia">
      <source>Sepia</source>
      <translation variants="yes">
        <lengthvariant priority="1">棕褐色</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos">
      <source>Go to 'Videos'</source>
      <translation variants="no">视频片段</translation>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone">
      <source>Color tone</source>
      <translation variants="no">色调</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_upload_settings">
      <source>Upload settings</source>
      <translation variants="no">上传设置</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自动</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">照相/摄像机</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix">
      <source>%Ln Mpix</source>
      <translation>
        <numerusform plurality="a">%Ln万像素</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">曝光补偿</translation>
    </message>
    <message numerus="no" id="txt_cam_list_normal">
      <source>Normal</source>
      <translation variants="yes">
        <lengthvariant priority="1">普通</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix_widescreen">
      <source>%Ln Mpix widescreen</source>
      <translation>
        <numerusform plurality="a">%Ln万像素宽屏</numerusform>
      </translation>
    </message>
  </context>
</TS>