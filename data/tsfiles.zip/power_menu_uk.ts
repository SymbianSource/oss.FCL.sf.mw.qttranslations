<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_pm_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">uk #Ringing volume</translation>
    </message>
    <message numerus="no" id="txt_pm_list_meeting">
      <source>Meeting</source>
      <translation variants="no">uk #Meeting</translation>
    </message>
    <message numerus="no" id="txt_pm_list_general">
      <source>General</source>
      <translation variants="no">uk #General</translation>
    </message>
    <message numerus="no" id="txt_pm_list_switch_off">
      <source>Switch off</source>
      <translation variants="no">uk #Switch off</translation>
    </message>
    <message numerus="no" id="txt_pm_list_change_profile">
      <source>Change profile</source>
      <translation variants="no">uk #Change profile</translation>
    </message>
    <message numerus="no" id="txt_pm_list_go_to_online">
      <source>Go to online</source>
      <translation variants="no">uk #Go to online</translation>
    </message>
    <message numerus="no" id="txt_pm_list_lock_device">
      <source>Lock device</source>
      <translation variants="no">uk #Lock device</translation>
    </message>
    <message numerus="no" id="txt_pm_list_go_to_offline">
      <source>Go to offline</source>
      <translation variants="no">uk #Go to offline</translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="no">uk #Accessory</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">uk #Wired carkit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_loopset">
      <source>Loopset</source>
      <translation variants="no">uk #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">uk #Accessory type</translation>
    </message>
    <message numerus="no" id="txt_pm_button_power_off">
      <source>Power Off</source>
      <translation variants="no">uk #Switch
off!</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headphones">
      <source>Headphones</source>
      <translation variants="no">uk #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">uk #Wired carkit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights">
      <source>Lights</source>
      <translation variants="no">uk #Lights</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_on">
      <source>On</source>
      <translation variants="no">uk #On</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="no">uk #16:9</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_loopse">
      <source>Loopset</source>
      <translation variants="no">uk #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_music_stand">
      <source>Music stand</source>
      <translation variants="no">uk #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_music_stand">
      <source>Music stand</source>
      <translation variants="no">uk #Music stand</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume">
      <source>Volume</source>
      <translation variants="no">uk #Volume</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume_val_med">
      <source>Med</source>
      <translation variants="no">uk #Medium</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headset">
      <source>Headset</source>
      <translation variants="no">uk #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="no">uk #TTY</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">uk #Wireless carkit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_tty">
      <source>TTY</source>
      <translation variants="no">uk #TTY</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_loopset">
      <source>Loopset</source>
      <translation variants="no">uk #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="no">uk #4:3</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">uk #Wired carkit</translation>
    </message>
    <message numerus="no" id="txt_pm_button_silence">
      <source>Silence</source>
      <translation variants="no">uk #Silence</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume_val_soft">
      <source>Soft</source>
      <translation variants="no">uk #Soft</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_automatic">
      <source>Automatic</source>
      <translation variants="no">uk #Automatic</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headphones">
      <source>Headphones</source>
      <translation variants="no">uk #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headphones">
      <source>Headphones</source>
      <translation variants="no">uk #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">uk #Wireless carkit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headph">
      <source>Headphones</source>
      <translation variants="no">uk #Headphones</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume_val_loud">
      <source>Loud</source>
      <translation variants="no">uk #Loud</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headse">
      <source>Headset</source>
      <translation variants="no">uk #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">uk #Wireless carkit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_wired">
      <source>Wired carkit</source>
      <translation variants="no">uk #Wired carkit</translation>
    </message>
    <message numerus="no" id="txt_pm_list_offline_airplane_mode">
      <source>Offline (Airplane Mode)</source>
      <translation variants="no">uk #Offline mode</translation>
    </message>
    <message numerus="no" id="txt_pm_list_silent">
      <source>Silent</source>
      <translation variants="no">uk #Silent</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="no">uk #TTY</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_music_stand">
      <source>Music stand</source>
      <translation variants="no">uk #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="no">uk #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_tty">
      <source>TTY</source>
      <translation variants="no">uk #TTY</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_loopset">
      <source>Loopset</source>
      <translation variants="no">uk #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_music">
      <source>Music stand</source>
      <translation variants="no">uk #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">uk #TV aspect ratio</translation>
    </message>
    <message numerus="no" id="txt_pm_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">uk #Touch screen vibration</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headset">
      <source>Headset</source>
      <translation variants="no">uk #Headset</translation>
    </message>
  </context>
</TS>