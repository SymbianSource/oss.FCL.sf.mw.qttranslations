<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_ir_list_internet_radio">
      <source>Internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">互聯網收音機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_iradhswidget_list_internet_radio_widget">
      <source>Internet radio widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">互聯網收音機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_iradhswidget_list_quick_access_for_internet_radio">
      <source>Quick access for internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">在首頁畫面快速接入互聯網收音機</lengthvariant>
        <lengthvariant priority="2">在首頁畫面接入互聯網收音機</lengthvariant>
      </translation>
    </message>
  </context>
</TS>