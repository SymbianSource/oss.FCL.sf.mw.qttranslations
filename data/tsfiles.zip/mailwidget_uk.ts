<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_widget_list_l1">
      <source>(L%1)</source>
      <translation variants="no">uk #(L%1)</translation>
    </message>
    <message numerus="no" id="txt_mail_widget_dblist_preview_of_recent_mail">
      <source>Preview of recent mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Preview of recent mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_widget_list_no_mail">
      <source>(No mail)</source>
      <translation variants="no">uk #(No mail)</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mail_widget">
      <source>Mail widget</source>
      <translation variants="no">uk #Mail widget</translation>
    </message>
    <message numerus="no" id="txt_short_caption_mail_widget">
      <source>Mail widget</source>
      <translation variants="no">uk #Mail widget</translation>
    </message>
  </context>
</TS>