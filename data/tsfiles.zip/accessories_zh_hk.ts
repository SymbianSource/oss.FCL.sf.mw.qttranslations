<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="yes">
        <lengthvariant priority="1">16:9</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="yes">
        <lengthvariant priority="1">聽障通訊器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="yes">
        <lengthvariant priority="1">聽障通訊器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="yes">
        <lengthvariant priority="1">4:3</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">配件設定</lengthvariant>
        <lengthvariant priority="2">zh_hk #Accessory sett.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">電視畫面大小</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="yes">
        <lengthvariant priority="1">耳機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">配件類型</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">配件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headset">
      <source>Headset</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Headset</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_info_accessory_not_supported">
      <source>Accessory not supported.</source>
      <translation variants="no">zh_hk #Accessory not supported.</translation>
    </message>
  </context>
</TS>