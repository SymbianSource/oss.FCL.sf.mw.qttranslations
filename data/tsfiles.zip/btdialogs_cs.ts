<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="cs">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_info_delete_all_paired_devices_some_device">
      <source>Delete all paired devices? Some devices may be disconnected.</source>
      <translation variants="no">Odstranit všechny spárované přístroje? Některé přístroje mohou být odpojeny.</translation>
    </message>
    <message numerus="no" id="txt_bt_title_unable_to_enter_sim_access_profile">
      <source>Unable to enter SIM access profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nelze aktivovat režim vzdálené SIM</lengthvariant>
        <lengthvariant priority="2">Nelze akt. režim vzdál. SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_connected">
      <source>Connected</source>
      <translation variants="no">Připojen k</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_devices_some_devices_may_b">
      <source>Delete all devices? Some devices may be disconnected.</source>
      <translation variants="no">Odstranit všechny přístroje? Některé přístroje mohou být odpojeny.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unsupported_device_1">
      <source>Unsupported device: %1</source>
      <translation variants="no">Nepodporovaný přístroj:
%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_waiting_the_other_device">
      <source>Waiting for the other device</source>
      <translation variants="no">Čeká se na druhý přístroj</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to">
      <source>Connect to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Připojit k:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_there_seems_to_be_a_lot_of_pairing_que">
      <source>There seems to be uncommonly lot of pairing queries. Turn Bluetooth off to protect your device?</source>
      <translation variants="no">Zjištěn nezvyklý počet párovacích dotazů. Ochránit tento přístroj deaktivací Bluetooth?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_other_files_received">
      <source>N other files received</source>
      <translation variants="no">cs ##N other files received</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_on_ini_offline_mode">
      <source>Trun Bluetooth on in offline mode?</source>
      <translation variants="no">Aktivovat Bluetooth v off-line režimu?</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_with_1_failed_either_the_pas">
      <source>Pairing with %1 failed. Either the passcodes didn’t match or the other device is turned off.</source>
      <translation variants="no">Chyba párování s přístrojem %[14]1. Buď se neshodují kódy, nebo je druhý přístroj vypnutý.</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_use">
      <source>in use</source>
      <translation variants="no">aktivní</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_off">
      <source>is now off</source>
      <translation variants="no">je nyní vypnutý</translation>
    </message>
    <message numerus="no" id="txt_bt_info_enter_the_following_code_to_the_1">
      <source>Enter the following code to the %1:</source>
      <translation variants="no">Zadejte následující kód v přístroji %[40]1:</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth_used">
      <source>Bluetooth used</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">Režim vzdálené SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_info_not_possible_during_a_call">
      <source>Not possible during a call</source>
      <translation variants="no">V průběhu hovoru nelze vytvořit připojení Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_paired_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dialog_please_enter_the_passcode_for_1">
      <source>Please enter the passcode for %1:</source>
      <translation variants="no">Zadejte kód pro %[57]1:</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_on">
      <source>is now on</source>
      <translation variants="no">je nyní zapnutý</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pairing_with_1">
      <source>Pairing with %1</source>
      <translation variants="no">Páruje se s %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_failed_remote_device_is_pairi">
      <source>Pairing failed. Remote device is pairing with another device.</source>
      <translation variants="no">Chyba párování. Vzdálený přístroj se páruje s jiným přístrojem.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_blocked_devices">
      <source>Delete all blocked devices?</source>
      <translation variants="no">Odstranit všechny blokované přístroje?</translation>
    </message>
    <message numerus="no" id="txt_bt_button_more_devices">
      <source>More devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Další přístroje</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_bluetooth_not_allowed_to_be_turned_on">
      <source>Bluetooth not allowed to be turned on in offline mode</source>
      <translation variants="no">Nelze aktivovat Bluetooth v off-line režimu</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_cancelled_from_1">
      <source>from %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_connected_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_entering_sim_access_profile">
      <source>Entering SIM access profile</source>
      <translation variants="no">Aktivuje se režim vzdálené SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_title_received_from_1">
      <source>Received from %1</source>
      <translation variants="no">Přijato z přístroje %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_exited">
      <source>exited</source>
      <translation variants="no">neaktivní</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_disconnected">
      <source>Disconnected</source>
      <translation variants="no">Odpojen od</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_unpaired">
      <source>Unpaired</source>
      <translation variants="no">Zrušeno spárování s</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_receiving_failed">
      <source>Receiving failed</source>
      <translation variants="no">Chyba přijetí</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from">
      <source>Receive messages from:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Přijímat zprávy od:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_disconnected_from_1">
      <source>from %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_hidden">
      <source>is now hidden</source>
      <translation variants="no">je nyní skrytý</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_paired">
      <source>Paired</source>
      <translation variants="no">Spárován</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sending_cancelled">
      <source>Sending cancelled</source>
      <translation variants="no">Odeslání zrušeno</translation>
    </message>
    <message numerus="no" id="txt_bt_info_do_you_still_want_to_enable_sim_access">
      <source>Do you still want to enable SIM access profile?</source>
      <translation variants="no">Aktivovat režim vzdálené SIM?</translation>
    </message>
    <message numerus="no" id="txt_bt_title_sending_file_l1l2_to_3">
      <source>Sending file %L1/%L2 to %3</source>
      <translation variants="no">Odesílá se soubor %L1/%L2 do přístroje %3</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_off_there_is_an_active">
      <source>Trun Bluetooth off? There is an active connection.</source>
      <translation variants="no">Existuje aktivní připojení Bluetooth. Chcete přesto aktivovat nové připojení?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_battery_low">
      <source>Battery low</source>
      <translation variants="no">Baterie je vybitá v</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pair_with">
      <source>Pair with:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Spárovat s:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_try_again">
      <source>Try again</source>
      <translation variants="yes">
        <lengthvariant priority="1">Opakujte akci</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_disable_sim_access_profile">
      <source>Exit SIM access profile?</source>
      <translation variants="no">Deaktivovat režim vzdálené SIM?</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to_paired_device">
      <source>Connect to paired device:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Připojit ke spárovanému přístroji:</lengthvariant>
        <lengthvariant priority="2">Připojit ke spárov. přístroji:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_sim_access_profile_is_used_next_time_t">
      <source>SIM access profile is used next time the car kit connects to this device and the Bluetooth is turned on.</source>
      <translation variants="no">Režim vzdálené SIM se aktivuje při příštím připojení sady do auta k tomuto přístroji a následném zapnutí Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_pair_with_1">
      <source>Unable to pair with %1</source>
      <translation variants="no">Nelze se spárovat s přístrojem %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_bluetooth_device_address_1">
      <source>Bluetooth device address: %1</source>
      <translation variants="no">Adresa přístroje Bluetooth:
%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_perform_bluetooth_operation">
      <source>Unable to perform Bluetooth operation</source>
      <translation variants="no">Nelze provést operaci Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_title_operation_not_possible_when_sim_acces">
      <source>Operation not possible when SIM access profile is in use</source>
      <translation variants="yes">
        <lengthvariant priority="1">Operaci nelze provést</lengthvariant>
        <lengthvariant priority="2">cs #Operation not possible in remote SIM mode</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from_paired_device">
      <source>Receive messages from paired device:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Přijímat zprávy od:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_connect_with_bluetooth">
      <source>Unable to connect with %1</source>
      <translation variants="no">Nelze se připojit k přístroji %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_all_files_sent">
      <source>All files sent</source>
      <translation variants="no">Vš. soub. odeslány do</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receiving_files_from_1">
      <source>Receiving from %1</source>
      <translation variants="no">Přijímá se z přístroje %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_with_1">
      <source>with %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_title_send_to">
      <source>Send to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Odeslat do:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_does_this_code_match_the_code_on_1">
      <source>Does this code match the code on %1?</source>
      <translation variants="no">Odpovídá následující kód kódu v přístroji %[34]1?</translation>
    </message>
    <message numerus="no" id="txt_bt_list_dont_ask_again_with_this_device">
      <source>Don't ask again with this device</source>
      <translation variants="no">U tohoto přístroje se již nedotazovat</translation>
    </message>
    <message numerus="no" id="txt_bt_title_no_sim_card_in_the_device">
      <source>No SIM card in the device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chybí SIM karta</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpinfo_as_web_connection">
      <source>as web connection</source>
      <translation variants="no">slouží jako webové připojení</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_1">
      <source>in %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_to_connect_1_2_needs_to_be_disconnec">
      <source>To connect %1 %2 needs to be disconnected first.</source>
      <translation variants="no">K přístroji %[33]1 se nelze připojit. Nejprve se odpojte od přístroje %[33]2.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_files_already_received">
      <source>N files already received</source>
      <translation variants="no">cs ##N files already received</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_sent_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_try_entering_the_sim_access_profile_ag">
      <source>Try entering the SIM access profile again?</source>
      <translation variants="no">Pokusit se znovu aktivovat režim vzdálené SIM?</translation>
    </message>
  </context>
</TS>