<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="mr">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_list_start_end_time">
      <source>%1 -%2</source>
      <translation variants="no">%1 -%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_main_view">
      <source>Calendar main view</source>
      <translation variants="no">Calendar main view</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_friday">
      <source>Friday</source>
      <translation variants="no">Friday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">Wednesday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">mr #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">mr #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_settings">
      <source>Settings</source>
      <translation variants="no">Settings</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">mr #Unnamed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">mr #Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">Due on %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_all_entries">
      <source>All entries</source>
      <translation variants="no">All entries</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_mo">
      <source>Mo</source>
      <translation variants="no">Mo</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Delete repeated entry :</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_date">
      <source>Go to date</source>
      <translation variants="no">Go to date</translation>
    </message>
    <message numerus="no" id="txt_calendar_empty_list_no_entries">
      <source>No entries for today</source>
      <translation variants="no">No entries for today</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_we">
      <source>We</source>
      <translation variants="no">We</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_lunar_calendar">
      <source>Show lunar calendar</source>
      <translation variants="no">Show lunar calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_su">
      <source>Su</source>
      <translation variants="no">Su</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_sa">
      <source>Sa</source>
      <translation variants="no">Sa</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_15">
      <source>15 minutes</source>
      <translation variants="no">15 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">Delete meeting?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_10">
      <source>10 minutes</source>
      <translation variants="no">10 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">mr #Settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_tu">
      <source>Tu</source>
      <translation variants="no">Tu</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Edit :</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_all_calendar_entries">
      <source>Delete all calendar entries?</source>
      <translation variants="no">Delete all calendar entries?</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_wk">
      <source>Wk</source>
      <translation variants="no">Wk</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">Delete To-do note?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_monday">
      <source>Monday</source>
      <translation variants="no">Monday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on">
      <source>Week starts on</source>
      <translation variants="no">Week starts on</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_thursday">
      <source>Thursday</source>
      <translation variants="no">Thursday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">mr #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_unnamed">
      <source>Unnamed</source>
      <translation variants="no">Unnamed</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_switch_to_day_view">
      <source>Switch to Day view</source>
      <translation variants="no">Switch to Day view</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_5_m">
      <source>5 minutes</source>
      <translation variants="no">5 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event?</source>
      <translation variants="no">Delete All-day event?</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">%1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">This occurrence only</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_entries">
      <source>Delete entries</source>
      <translation variants="no">Delete entries</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">All occurences</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_fr">
      <source>Fr</source>
      <translation variants="no">Fr</translation>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_snooze_time_val_ln">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">mr #%Ln minute</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">mr #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_show_lunar_data">
      <source>Show lunar data</source>
      <translation variants="no">Show lunar data</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_event">
      <source>New event</source>
      <translation variants="no">New event</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_before_date">
      <source>Before date</source>
      <translation variants="no">Before date</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_th">
      <source>Th</source>
      <translation variants="no">Th</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_buddhist_year">
      <source>Show buddhist year</source>
      <translation variants="no">Show buddhist year</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time">
      <source>Reminder snooze time</source>
      <translation variants="no">Reminder snooze time</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_week_numbers">
      <source>Show week numbers</source>
      <translation variants="no">Show week numbers</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_no_entries">
      <source>No entries for today</source>
      <translation variants="no">No entries for today</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Mark as done</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_today">
      <source>Go to today</source>
      <translation variants="no">Go to today</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_switch_to_agenda_view">
      <source>Switch to Agenda view</source>
      <translation variants="no">Switch to Agenda view</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_30">
      <source>30 minutes</source>
      <translation variants="no">30 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_saturday">
      <source>Saturday</source>
      <translation variants="no">Saturday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_sunday">
      <source>Sunday</source>
      <translation variants="no">Sunday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">Tuesday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">mr #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">mr #Yes</lengthvariant>
      </translation>
    </message>
  </context>
</TS>