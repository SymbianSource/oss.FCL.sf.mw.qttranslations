<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailmfe_list_version_l1">
      <source>Version: %[]1</source>
      <translation variants="no">ur #Version: %[512]1</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_calendar">
      <source>Calendar</source>
      <translation variants="no">کیلنڈر</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_1_month_back">
      <source>1 month back</source>
      <translation variants="no">۱ مہینہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_username">
      <source>Username</source>
      <translation variants="no">صارف نام</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_my_name">
      <source>My name</source>
      <translation variants="no">میرا نام</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_password">
      <source>Password</source>
      <translation variants="no">لفظ شناخت</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_3_days_back">
      <source>3 days back</source>
      <translation variants="no">۳ دن</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_show_mail_in_other_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">فولڈر میں میل دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_1_week_back">
      <source>1 week back</source>
      <translation variants="no">۱ ہفتہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_fri">
      <source>Fri</source>
      <translation variants="no">جمعہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_as_defined">
      <source>The mailbox is refreshed as defined by the user</source>
      <translation variants="no">صارف کی وضاحت کے مطابق میل باکس مشمولات کی تازہ کاری ہوتی ہے</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_every_15_mi">
      <source>The mailbox is refreshed every 15 minutes during daytime</source>
      <translation variants="no">دن کے دوران ہر ۱۵ منٹ پر میل باکس مشمولات کی تازہ کاری ہوتی ہے</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_secure_connection">
      <source>Secure connection</source>
      <translation variants="no">محفوظ اتصال</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_tasks">
      <source>Tasks</source>
      <translation variants="no">اہم کام نوٹس</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_only_by_use">
      <source>The mailbox is refreshed only by user request</source>
      <translation variants="no">صرف استعمال کنندہ کے آغاز کرنے پر میل باکس مشمولات کو تازہ کیا جاتا ہے</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_server_info">
      <source>Server info</source>
      <translation variants="no">سرور کی ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_day_end_time">
      <source>Day end time</source>
      <translation variants="no">دن کے خاتمے کا وقت</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_during_daytime_val_off">
      <source>Off</source>
      <translation variants="no">بند</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_receiving_schedule">
      <source>Receiving Schedule</source>
      <translation variants="no">بازیافتگی کا نظام اوقات</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_preferences">
      <source>Preferences</source>
      <translation variants="no">اکاؤنٹ کی ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_contacts">
      <source>Contacts</source>
      <translation variants="no">رابطے</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="no">ہر ۴ گھنٹے پر</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">میل باکس کی تازہ کاری</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_keep_uptodat">
      <source>Keep up-to-date</source>
      <translation variants="no">مکمل بنائے رکھیں</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_sun">
      <source>Sun</source>
      <translation variants="no">یک شنبہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_receiving_weekdays">
      <source>Receiving weekdays</source>
      <translation variants="no">بازیافتگی ایام</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_every_day">
      <source>Every day</source>
      <translation variants="no">روزانہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_user_defined">
      <source>User defined</source>
      <translation variants="no">صارف کا وضاحت کردہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_connection">
      <source>Connection</source>
      <translation variants="no">اتصال</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_3_months_back">
      <source>3 months back</source>
      <translation variants="no">۳ مہینے</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_tue">
      <source>Tue</source>
      <translation variants="no">سہ شنبہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_6_months_back">
      <source>6 months back</source>
      <translation variants="no">۶ مہینے</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_day_start_time">
      <source>Day start time</source>
      <translation variants="no">دن کے آغاز کا وقت</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_button_delete_mailbox">
      <source>Delete mailbox</source>
      <translation variants="no">میل باکس مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_port">
      <source>Port</source>
      <translation variants="no">پورٹ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_notes">
      <source>Notes</source>
      <translation variants="no">نوٹس</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_fetch_manually">
      <source>Fetch manually</source>
      <translation variants="no">میل دستی بازیابی</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode">
      <source>Selected mode</source>
      <translation variants="no">تازہ. اختیار استعمال میں</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_mailbox_name">
      <source>Mailbox name</source>
      <translation variants="no">میل باکس کا نام</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_keep_uptodate">
      <source>Keep up-to-date</source>
      <translation variants="no">جدید تر بنائے رکھیں</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">میل پتہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_during_daytime_val_on">
      <source>On</source>
      <translation variants="no">چالو </translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_server">
      <source>Server</source>
      <translation variants="no">سرور</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_received_items">
      <source>Received items</source>
      <translation variants="no">ہمزمانگی کیے جانے والے  آئیٹمز</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_sat">
      <source>Sat</source>
      <translation variants="no">سنیچر</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_1_hour">
      <source>Every 1 hour</source>
      <translation variants="no">ur #Every 1 hour</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_mon">
      <source>Mon</source>
      <translation variants="no">دو شنبہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_user_info">
      <source>User info</source>
      <translation variants="no">صارف ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_thu">
      <source>Thu</source>
      <translation variants="no">پنج شنبہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_show_mail_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">ان باکس میں میل دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_mailnmfe_setlabel_signature">
      <source>Signature</source>
      <translation variants="no">ur #Signature</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_domain">
      <source>Domain</source>
      <translation variants="no">ڈومین</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_save_energy">
      <source>Save energy</source>
      <translation variants="no">توانائی کی بچت</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_mail">
      <source>Mail</source>
      <translation variants="no">میل</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_uptodate_during_day">
      <source>The mailbox is up-to-date during daytime</source>
      <translation variants="no">دن کے دوران میل باکس مشمولات کو جدید تر رکھا جاتا ہے</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="no">ہر ۱۵ منٹ پر</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_wed">
      <source>Wed</source>
      <translation variants="no">چہار شنبہ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_when_i_open_mailbox">
      <source>When I open mailbox</source>
      <translation variants="no">جب میں میل باکس کھولوں</translation>
    </message>
  </context>
</TS>