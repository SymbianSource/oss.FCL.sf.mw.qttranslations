<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_loe_list_up_every_l1_minutes_and_l2_sec">
      <source>Updates every %L1 minutes and %L2 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 منٹ %L2 سیکنڈ</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 منٹ %L2 سیکنڈ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_unknown_requestor">
      <source>Unknown requestor</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_hours">
      <source>Updates every %Ln hours</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_months">
      <source>Updates every %Ln months</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_loe_list_upd_every_l1_hour_and_l2_minute">
      <source>Updates every %L1 hour and %L2 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 گھنٹے %L2 منٹ</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 گھنٹے %L2 منٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_upd_every_l1_minute_and_l2_seco">
      <source>Updates every %L1 minute and %L2 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 منٹ %L2 سیکنڈ</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 منٹ %L2 سیکنڈ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_timedate">
      <source>&lt;Time&gt;&lt;Date&gt;</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_loe_button_advanced">
      <source>Advanced</source>
      <translation variants="no">برتر ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_advanced_positioning_settings">
      <source>Advanced positioning settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقام کے تعین کی برتر ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_accuracy_ln_kilometers">
      <source>Accuracy: %Ln kilometers</source>
      <translation>
        <numerusform plurality="a">ur #Accuracy: %Ln kilometre</numerusform>
        <numerusform plurality="b">ur #Accuracy: %Ln kilometres</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_background_positioning">
      <source>Background positioning</source>
      <translation variants="no">پس منظری مقام کا تعین</translation>
    </message>
    <message numerus="no" id="txt_loe_info_location_was_requested_by">
      <source>Location was requested by : </source>
      <translation variants="no">آپ کے مقام کی درخواست کی گئی تھی از:</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_positioning_settings">
      <source>Positioning settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقام کے تعین کی ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_be_shared_with">
      <source>Your location will be shared with :</source>
      <translation variants="no">آپ کے محل وقوع میں شراکت کی جائے گی ہمراہ:</translation>
    </message>
    <message numerus="no" id="txt_loe_dblist_positioning">
      <source>Positioning</source>
      <translation variants="no">مقام کا تعین</translation>
    </message>
    <message numerus="no" id="txt_loe_info_you_location_will_be_shared_periodica">
      <source>You location will be shared periodically with :</source>
      <translation variants="no">بطور آغازی، آپ کے مقام میں وقتاً فوقتاً شراکت کی جائے گی ہمراہ:</translation>
    </message>
    <message numerus="no" id="txt_loe_list_time">
      <source>&lt;Time&gt;</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="yes" id="txt_loe_list_accuracy_ln_meters">
      <source>Accuracy: %Ln meters</source>
      <translation>
        <numerusform plurality="a">ur #Accuracy: %Ln metre</numerusform>
        <numerusform plurality="b">ur #Accuracy: %Ln metres</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_your_location_sent_to_1">
      <source>Your location sent to : %1</source>
      <translation variants="no">آپ کا مقام ارسال کیا گیا تھا برائے: %1</translation>
    </message>
    <message numerus="no" id="txt_loe_info_enable_applications_and_services_upda">
      <source>Enable applications and services update and retrieve location information</source>
      <translation variants="no">پس منظر میں مقام سے متعلق معلومات کی تجدید و بازیافت کرنے کے لیے پروگراموں اور خدمات کو فعال کریں</translation>
    </message>
    <message numerus="no" id="txt_loe_info_stop_service_1">
      <source>Stop service %1</source>
      <translation variants="no">خدمت روکیں؟
%1 </translation>
    </message>
    <message numerus="no" id="txt_loe_list_gps">
      <source>GPS</source>
      <translation variants="no">GPS</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_days_and_l2_hour">
      <source>Updates every %L1 days and %L2 hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 دن %L2 گھنٹہ</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 دن %L2 گھنٹہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_button_clear_logs">
      <source>Clear logs</source>
      <translation variants="no">ur #Clear logs</translation>
    </message>
    <message numerus="no" id="txt_loe_title_positioning">
      <source>Positioning</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقام کا تعین</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_not_be_shared_peri">
      <source>Your location will not be shared periodically by default if you don't respond</source>
      <translation variants="no">اگر آپ جواب نہیں دیتے تو، طور آغازی، آپ کے محل وقوع میں وقتاً فوقتاً شراکت نہیں کی جائے گی۔</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_positioning_servers">
      <source>Positioning servers</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقام کے تعین کے سرورز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4w">
      <source>L1%˚L2%'L3%.L4%"W</source>
      <translation variants="no">ur #%L1˚%L2'%L3.%L4"W</translation>
    </message>
    <message numerus="no" id="txt_loe_list_bluetooth_gps">
      <source>Bluetooth GPS</source>
      <translation variants="no">Bluetooth GPS</translation>
    </message>
    <message numerus="yes" id="txt_loe_dblist_ln_location_notifications">
      <source>%Ln Location notifications</source>
      <translation>
        <numerusform plurality="a">%Ln مقام اطلاع نامہ</numerusform>
        <numerusform plurality="b">%Ln مقام اطلاع نامے</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_button_settings">
      <source>Settings</source>
      <translation variants="no">ur #Settings</translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4e">
      <source>L1%˚L2%'L3%.L4%"E</source>
      <translation variants="no">ur #%L1˚%L2'%L3.%L4"E</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_day_and_l2_hour">
      <source>Updates every %L1 day and %L2 hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 دن %L2 گھنٹہ</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 دن %L2 گھنٹہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_wifi">
      <source>Wi-Fi</source>
      <translation variants="no">WLAN</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_minutes_and_l2_sec">
      <source>Updates every %L1 minutes and %L2 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 منٹ %L2 سیکنڈ</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 منٹ %L2 سیکنڈ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4n">
      <source>L1%˚L2%'L3%.L4%"N</source>
      <translation variants="no">ur #%L1˚%L2'%L3.%L4"N</translation>
    </message>
    <message numerus="no" id="txt_loe_button_accept">
      <source>Accept</source>
      <translation variants="no">قبول کریں</translation>
    </message>
    <message numerus="no" id="txt_loe_list_cellular_network">
      <source>Cellular network</source>
      <translation variants="no">سیلولر نیٹ ورک</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_positioning_methods">
      <source>Positioning methods</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقام کے تعین کے طریقے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_days_and_l2_hours">
      <source>Updates every %L1 days and %L2 hours</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 دن %L2 گھنٹے</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 دن %L2 گھنٹے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_internal_gps">
      <source>Internal GPS</source>
      <translation variants="no">داخلی GPS</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_positioning">
      <source>Positioning</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقام کا تعین</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_background_positioning">
      <source>Background positioning</source>
      <translation variants="yes">
        <lengthvariant priority="1">پس منظری مقام کا تعین</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_be_shared_by_defau">
      <source>Your location will be shared by default if you don’t respond</source>
      <translation variants="no">اگر آپ جواب نہیں دیتے تو، بطور آغازی، آپ کے مقام میں شراکت کی جائے گی۔</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_months_and_l2_day">
      <source>Updates every %L1 months and %L2 day</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 مہینے %L2 دن</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 مہینے %L2 دن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_enable_for_most_accurate_positioning">
      <source>Enable for most accurate positioning</source>
      <translation variants="no">GPS درست ترین طریقہ ہے</translation>
    </message>
    <message numerus="no" id="txt_loe_list_assisted_gps">
      <source>Assisted GPS</source>
      <translation variants="no">امداد یافتہ GPS</translation>
    </message>
    <message numerus="no" id="txt_loe_dpophead_your_location_not_sent_to">
      <source>Your location not sent to :</source>
      <translation variants="no">آپ کا مقام ارسال نہیں کیا گیا تھا برائے:</translation>
    </message>
    <message numerus="no" id="txt_loe_button_save">
      <source>Save</source>
      <translation variants="no">ur #Save</translation>
    </message>
    <message numerus="no" id="txt_loe_title_location_request">
      <source>Location request</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقام سے متعلق درخواستیں</lengthvariant>
        <lengthvariant priority="2">مقام درخواستیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_days">
      <source>Updates every %Ln days</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_days">
      <source>Updates every %Ln days</source>
      <translation>
        <numerusform plurality="a">وقفہ کی تجدید کریں: %Ln دن</numerusform>
        <numerusform plurality="b">وقفہ کی تجدید کریں: %Ln دن</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_dblist_positioning_val_acquiring_position">
      <source>Acquiring position</source>
      <translation variants="no">محل وقوع کا حصول</translation>
    </message>
    <message numerus="yes" id="txt_loe_info_ln_unknown_requestors">
      <source>%Ln Unknown requestors</source>
      <translation>
        <numerusform plurality="a">%Ln نامعلوم درخواست کرنے والے</numerusform>
        <numerusform plurality="b">%Ln نامعلوم درخواست کنندہ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_minutes">
      <source>Updates every %Ln minutes</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_hours_and_l2_minut">
      <source>Updates every %L1 hours and %L2 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 گھنٹے %L2 منٹ</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 گھنٹے %L2 منٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_months_and_l2_days">
      <source>Updates every %L1 months and %L2 days</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 مہینے %L2 دن</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 مہینے %L2 دن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_subhead_logs">
      <source>Logs</source>
      <translation variants="yes">
        <lengthvariant priority="1">لاگز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_valid_until_1">
      <source>Valid until %1</source>
      <translation variants="no">%[46]1 تک کارآمد</translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_not_be_shared_by_d">
      <source>Your location will not be shared by default if you don’t respond</source>
      <translation variants="no">اگر آپ جواب نہیں دیتے تو، بطور آغازی،آپ کے مقام میں شراکت نہیں کی جائے گی۔</translation>
    </message>
    <message numerus="no" id="txt_loe_title_save_as">
      <source>Save as</source>
      <translation variants="yes">
        <lengthvariant priority="1">حفظ کریں بطور</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_hour_and_l2_minute">
      <source>Updates every %L1 hour and %L2 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 گھنٹہ %L2 منٹ</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 گھنٹہ %L2 منٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_title_location_notifications">
      <source>Location notifications</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقام سے متعلق اطلاع نامے</lengthvariant>
        <lengthvariant priority="2">م. اطلاع نامے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_wireless_networks">
      <source>Wireless networks</source>
      <translation variants="no">وائرلیس نیٹ ورکس</translation>
    </message>
    <message numerus="no" id="txt_loe_list_use_1">
      <source>Use %1</source>
      <translation variants="no">%[99]1 استعمال کریں</translation>
    </message>
    <message numerus="no" id="txt_loe_list_up_every_l1_hours_and_l2_minut">
      <source>Updates every %L1 hours and %L2 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 گھنٹے %L2 منٹ</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 گھنٹے %L2 منٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_seconds">
      <source>Updates every %L1 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Update interval: %L1 seconds</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_positioning_val_change_positioning_s">
      <source>Change positioning settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقام کے تعین کی ترتیبات تبدیل کریں</lengthvariant>
        <lengthvariant priority="2">م. تعین ترتیبات تبدیل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4s">
      <source>L1%˚L2%'L3%.L4%"S</source>
      <translation variants="no">ur #%L1˚%L2'%L3.%L4"S</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_minute_and_l2_seco">
      <source>Updates every %L1 minute and %L2 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 منٹ %L2 سیکنڈ</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 منٹ %L2 سیکنڈ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_your_location_not_sent_to_1">
      <source>Your location not sent to: %1</source>
      <translation variants="no">آپ کا مقام ارسال نہیں کیا گیا تھا برائے: %1</translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_minutes">
      <source>Updates every %Ln minutes</source>
      <translation>
        <numerusform plurality="a">وقفہ کی تجدید کریں: %Ln منٹ</numerusform>
        <numerusform plurality="b">وقفہ تجدید کریں: %Ln منٹ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_month_and_l2_days">
      <source>Updates every %L1 month and %L2 days</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 مہینہ %L2 دن</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 مہینہ %L2 دن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_select_server_to_delete">
      <source>Select server to delete</source>
      <translation variants="no">مٹانے کے لیے سرور کا انتخاب کریں:</translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_months">
      <source>Updates every %Ln months</source>
      <translation>
        <numerusform plurality="a">وقفہ کی تجدید کریں: %Ln مہینے</numerusform>
        <numerusform plurality="b">وقفہ کی تجدید کریں: %Ln مہینہ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_button_done">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">انجام دیا گیا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_use_wifi_and_mobile_networks_to_get">
      <source>Use WI-FI and mobile networks to get position information</source>
      <translation variants="no">WLAN اور سیلولر نیٹ ورک بھی آپ کے مقام کا تعین کر سکتے ہیں</translation>
    </message>
    <message numerus="yes" id="txt_loe_list_your_location_sent_to_1_ln_times">
      <source>Your location sent to %1 %Ln times</source>
      <translation>
        <numerusform plurality="a">آپ کا مقام %[17]1 کو %Ln دفعہ ارسال کیا گیا تھا</numerusform>
        <numerusform plurality="b">آپ کا مقام %[17]1 کو %Ln دفعہ ارسال کیا گیا تھا</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_opt_delete_server">
      <source>Delete server</source>
      <translation variants="no">سرور مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_be_shared_periodic">
      <source>Your location will be shared periodically by default if you don’t respond.</source>
      <translation variants="no">اگر آپ جواب نہیں دیتے تو، بطور آغازی، آپ کے مقام میں وقتاً فوقتاً شراکت کی جائے گی۔</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_day_and_l2_hours">
      <source>Updates every %L1 day and %L2 hours</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 دن %L2 گھنٹے</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 دن %L2 گھنٹے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_month_and_l2_day">
      <source>Updates every %L1 month and %L2 day</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقفہ کی تجدید کریں: %L1 مہینہ %L2 دن</lengthvariant>
        <lengthvariant priority="2">وقفہ تجدید: %L1 مہینہ %L2 دن</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_hours">
      <source>Updates every %Ln hours</source>
      <translation>
        <numerusform plurality="a">وقفہ کی تجدید کریں: %Ln گھنٹے</numerusform>
        <numerusform plurality="b">وقفہ کی تجدید کریں: %Ln گھنٹے</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_dpophead_your_location_sent_to">
      <source>Your location sent to :</source>
      <translation variants="no">آپ کا مقام ارسال کیا گیا تھا برائے:</translation>
    </message>
  </context>
</TS>