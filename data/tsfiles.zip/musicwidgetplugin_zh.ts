<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_muwidget_dblist_val_quick_access_to_music">
      <source>Quick access to music</source>
      <translation variants="yes">
        <lengthvariant priority="1">从主屏幕快速访问音乐</lengthvariant>
        <lengthvariant priority="2">zh #Quick access to music</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_muwidget_dblist_music_player">
      <source>Music player</source>
      <translation variants="yes">
        <lengthvariant priority="1">音乐播放器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_muwidget_other_unknown_1">
      <source>Unknown - %1</source>
      <translation variants="no">未知 - %1</translation>
    </message>
  </context>
</TS>