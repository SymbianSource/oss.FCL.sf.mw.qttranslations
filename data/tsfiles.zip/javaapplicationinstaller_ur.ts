<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_inst_dpopinfo_installation_complete">
      <source>Installation complete</source>
      <translation variants="no">تنصیب مکمل</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_mb">
      <source>%1: Phone Memory (%L2 MB) </source>
      <translation variants="no">%[99]1: آلہ حافظہ (%L2 م ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_app_suite_name_version">
      <source>%1 (%2)</source>
      <translation variants="no">%[99]1 (%[99]2)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_downloading">
      <source>Downloading</source>
      <translation variants="no">ڈاؤن لوڈنگ جاری</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_serial_number">
      <source>Serial number: %1</source>
      <translation variants="no">نمبر سلسلہ: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_inst_pkg_not_cert">
      <source>Application %1 is from an unknown source. </source>
      <translation variants="no">پروگرام '%[99]1' ایک نامعلوم ذریعے سے ہے۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_kb">
      <source>%1: Memory card (%L2 kB) </source>
      <translation variants="no">%[99]1: حافظہ کارڈ (%L2 ک ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_mb">
      <source>%1: Unknown (%L2 MB)</source>
      <translation variants="no">%[99]1: نامعلوم (%L2 م ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_gb">
      <source>%1: Phone Memory (%L2 GB) </source>
      <translation variants="no">%[99]1: آلہ حافظہ (%L2 گ ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_installation_complete">
      <source>Installed</source>
      <translation variants="no">نصب کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_show">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">دکھائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_dialog_username">
      <source>Username:</source>
      <translation variants="yes">
        <lengthvariant priority="1">صارف نام:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_hide">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">چھپائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_manufacturer">
      <source>Manufacturer</source>
      <translation variants="no">تیار کنندہ</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_downloading">
      <source>Downloading</source>
      <translation variants="no">ur #Downloading</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_app_name">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_valid_until">
      <source>Valid until: %1</source>
      <translation variants="no">کارآمد تا: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_install">
      <source>Install?</source>
      <translation variants="no">نصب کریں؟</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_cancel_installing">
      <source>Cancel installing</source>
      <translation variants="no">تنصیب منسوخ کریں</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_perm_query">
      <source>Access to protected functionality needed.</source>
      <translation variants="no">تحفظ شدہ فعالیت تک رسائی درکار ہے۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_size_mb">
      <source>%L1 MB</source>
      <translation variants="no">%L1 م ب</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_organization">
      <source>Organization: %1</source>
      <translation variants="no">تنظیم: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installation_complete">
      <source>Installation complete</source>
      <translation variants="no">ur #Installation complete</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_mb">
      <source>%1: Internal Mass Storage (%L2 MB)</source>
      <translation variants="no">%[99]1: وسیع حافظہ (%L2 م ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_gb">
      <source>%1: Memory card (%L2 GB) </source>
      <translation variants="no">%[99]1: حافظہ کارڈ (%L2 گ ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹھیک ہے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem">
      <source>%1: Internal Mass Storage</source>
      <translation variants="no">%[99]1: وسیع حافظہ</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_ask_me_later">
      <source>Ask me later</source>
      <translation variants="no">مجھ سے بعد میں دریافت کریں</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_app_cert">
      <source>Application is certified.</source>
      <translation variants="no">ur #Application is certified.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_back_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹھیک ہے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_ocsp_check_progress">
      <source>Checking certificate validity</source>
      <translation variants="no">سند کی صلاحیت کی جانچ جاری</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_operator_pref">
      <source>Operator preferred</source>
      <translation variants="no">آپریٹر ترجیحی</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_kb">
      <source>%1: Phone Memory (%L2 kB) </source>
      <translation variants="no">%[99]1: آلہ حافظہ (%L2 ک ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_ocsp_check_progress">
      <source>Checking certificate validity</source>
      <translation variants="no">ur #Checking validity</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_inst_failed">
      <source>Installation failed</source>
      <translation variants="no">تنصیب ناکام</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_update_query">
      <source>Update?</source>
      <translation variants="no">تجدید کریں؟</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_auth_query">
      <source>Connect to</source>
      <translation variants="no">ur #Connect to server?</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_issuer">
      <source>Issuer: %1</source>
      <translation variants="no">جاری کنندہ: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_vendor">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_kb">
      <source>%1: Unknown (%L2 kB)</source>
      <translation variants="no">%[99]1: نامعلوم (%L2 ک ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_dpopinfo_preparing_installation">
      <source>Preparing installation</source>
      <translation variants="no">تنصیب کی تیاری کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem">
      <source>%1: Phone memory</source>
      <translation variants="no">%[99]1: آلہ حافظہ</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_valid_from">
      <source>Valid from: %1</source>
      <translation variants="no">کارآمد از: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_kb">
      <source>%1: Internal Mass Storage (%L2 kB)</source>
      <translation variants="no">%[99]1: وسیع حافظہ (%L2 ک ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_view_perm_details">
      <source>Details</source>
      <translation variants="no">تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_operator">
      <source>Operator</source>
      <translation variants="no">آپریٹر</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_untrusted_third_party">
      <source>Untrusted 3rd party</source>
      <translation variants="no">غیر معتبر فریق ثالث</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_listl_mem_card">
      <source>%1: Memory card</source>
      <translation variants="no">%[99]1: حافظہ کارڈ</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain">
      <source>Domain: %1</source>
      <translation variants="no">ڈومین: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_perm_view_details">
      <source>Application asks permissions for:</source>
      <translation variants="no">ur #Application asks permissions for:</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_update_query">
      <source>%1 from %2 to %3?</source>
      <translation variants="no">%[99]1 سے %[99]2 تک %[99]3؟</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_installing">
      <source>Installing</source>
      <translation variants="no">نصب کیا جا رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installing">
      <source>Installing</source>
      <translation variants="no">ur #Installing</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_trusted_third_party">
      <source>Trusted 3rd party</source>
      <translation variants="no">معتبر فریق ثالث</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_auth_yourself">
      <source>To download %1 you need to authenticate yourself</source>
      <translation variants="no">%[99]1' ڈاؤن لوڈ کرنے کے لیے سائن ان کریں۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown">
      <source>%1: Unknown</source>
      <translation variants="no">%[99]1: نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_allow_always">
      <source>Allow always</source>
      <translation variants="no">ہمیشہ اجازت دیں</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_push_registration_static">
      <source>Registration for automatic start needed. Note that installation will fail if not allowed.</source>
      <translation variants="no">ur #Application will be registered for auto-start otherwise installation will fail.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_gb">
      <source>%1: Internal Mass Storage (%L2 GB)</source>
      <translation variants="no">%[99]1: وسیع حافظہ (%L2 گ ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_gb">
      <source>%1: Unknown (%L2 GB)</source>
      <translation variants="no">%[99]1: نامعلوم (%L2 گ ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_preparing_installation">
      <source>Preparing installation</source>
      <translation variants="no">ur #Preparing</translation>
    </message>
    <message numerus="no" id="txt_java_inst_dialog_password">
      <source>Password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">لفظ شناخت:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_update_retain_user_data">
      <source>Retain application data</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروگرام ڈیٹا برقرار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_size_kb">
      <source>%L1 kB</source>
      <translation variants="no">%L1 ک ب</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_mb">
      <source>%1: Memory card (%L2 MB) </source>
      <translation variants="no">%[99]1: حافظہ کارڈ (%L2 م ب)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_app_not_cert">
      <source>Application is not certified.</source>
      <translation variants="no">ur #Application is not certified.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installing_progress">
      <source>%1 (%2 %)</source>
      <translation variants="no">ur #%[08]1 (%[08]2%)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">منسوخ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_subject">
      <source>Subject: %1</source>
      <translation variants="no">موضوع: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_fingerprint">
      <source>Fingerprint (SHA1): %1</source>
      <translation variants="no">نشان انگشت (SHA1): %1</translation>
    </message>
  </context>
</TS>