<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_applib_list_silent_widget">
      <source>Silent widget</source>
      <translation variants="no">zh_tw #Silent widget</translation>
    </message>
    <message numerus="no" id="txt_applib_grid_silent_widget">
      <source>Silent widget</source>
      <translation variants="no">zh_tw #Silent widget</translation>
    </message>
  </context>
</TS>