<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">تمام آلات</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Paired, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">جوڑی بنائے گئے، متصل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>International US</source>
      <translation variants="no">امریکہ بین الاقوامی</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Italian</source>
      <translation variants="no">اطالوی</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Finnish/Swedish</source>
      <translation variants="no">فِنِش، سویڈش</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_paired_devices">
      <source>No other paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">دیگر جوڑے گئے آلات نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">بلاک کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Paired devices</source>
      <translation variants="no">جوڑے گئے آلات</translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Computer</source>
      <translation variants="yes">
        <lengthvariant priority="1">کمپیوٹر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">متصل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>US Dvorak</source>
      <translation variants="no">امریکی ڈوورَک</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Connect</source>
      <translation variants="no">متصل کریں</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Bluetooth - Paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - جوڑے گئے آلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_audio_devices">
      <source>Bluetooth - Audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - آڈیو آلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Pair</source>
      <translation variants="no">ur #Pair</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Dutch</source>
      <translation variants="no">ولندیزی</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_phones">
      <source>No phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی فون نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_1">
      <source>Bluetooth - %1</source>
      <translation variants="no">Bluetooth - %1</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Blocked devices</source>
      <translation variants="no">بلاک کردہ آلات</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>%1 details</source>
      <translation variants="no">%[13]1 تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">دیگر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_phones">
      <source>Bluetooth - Paired phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - جوڑے گئے فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Russian</source>
      <translation variants="no">روسی</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Paired, trusted</source>
      <translation variants="yes">
        <lengthvariant priority="1">جوڑی بنائے گئے، معتبر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Connect</source>
      <translation variants="no">ur #Connect</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Keyboard settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">تختۂ کلید ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>UK</source>
      <translation variants="no">مملکت متحدہ</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Visible for %Ln min</source>
      <translation>
        <numerusform plurality="a">ur #Visible for %Ln minute</numerusform>
        <numerusform plurality="b">ur #Visible for %Ln minutes</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_devices">
      <source>No other devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی دیگر آلات نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Searching…</source>
      <translation variants="no">ur #Searching</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">SIM تک رسائی کا پروفائل</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Visible</source>
      <translation variants="no">ur #Shown to all</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Always ask</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہمیشہ پوچھیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Audio device</source>
      <translation variants="yes">
        <lengthvariant priority="1">آڈیو آلہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Disabled</source>
      <translation variants="no">غیر فعال کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>No found devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی پائے گئے آلات نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Search done</source>
      <translation variants="no">ur #Search completed</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Bluetooth - Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - برتر ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">ur #Disconnect</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو (ظاہر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Bluetooth - Found devices</source>
      <translation variants="no">ur #Bluetooth devices found</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">متصل (مخفی)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>No paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی جوڑے گئے آلات نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Change visibility time</source>
      <translation variants="no">نظر آنے کی مدت بدلیں</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_input_devices">
      <source>Bluetooth - Input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - ان پٹ آلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Paired</source>
      <translation variants="yes">
        <lengthvariant priority="1">جوڑی بنائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_phones">
      <source>Bluetooth - Phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>%1 connected</source>
      <translation variants="no">%[18]1متصل</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_devices">
      <source>Bluetooth - Other devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - دیگر آلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Bluetooth - All devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - تمام آلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Danish</source>
      <translation variants="no">ڈینِش</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو (مخفی)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>German</source>
      <translation variants="no">جرمن</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Portuguese</source>
      <translation variants="no">پرتگیزی</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_computers">
      <source>No computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی کمپیوٹرز نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Spanish</source>
      <translation variants="no">ہسپانوی </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_computers">
      <source>Bluetooth - Computers</source>
      <translation variants="yes">
        <lengthvariant priority="1"> Bluetooth - کمپیوٹرز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_audio_devices">
      <source>No paired audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">جوڑے گئے آڈیو آلات نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_audio_devices">
      <source>Bluetooth - Paired audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - جوڑے گئے آڈیو آلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Mouse settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ماؤس ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">متصل (ظاہر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">اتصال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>No devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی آلات نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Enabled</source>
      <translation variants="no">فعال کیا گيا</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Hidden</source>
      <translation variants="no">ur #Hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_input_devices">
      <source>No input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی ان پٹ آلات نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">برتر ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_input_devices">
      <source>Only input devices</source>
      <translation variants="no">صرف ان پٹ آلات</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_computers">
      <source>only computers</source>
      <translation variants="no">صرف کمپیوٹرز</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_other_devices">
      <source>Only other devices</source>
      <translation variants="no">صرف دیگر آلات</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show">
      <source>Show</source>
      <translation variants="no">دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">تمام آلات</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_input_devices">
      <source>Bluetooth - Paired input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - جوڑے گئے ان پٹ آلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Paired, trusted, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">جوڑی بنائے گئے، معتبر، متصل</lengthvariant>
        <lengthvariant priority="2">ج. بنائے گئے، معت.، متصل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_input_devices">
      <source>No paired input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی جوڑے گئے آلات نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Unpair</source>
      <translation variants="no">ur #Remove pairing</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">بلاک کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_paired_devices">
      <source>Bluetooth - Other paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - دیگر جوڑے گئے آلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_phones">
      <source>No paired phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی جوڑے گئے فون نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Remove paired devices</source>
      <translation variants="no">جوڑے گئے آلات نکالیں</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Device details</source>
      <translation variants="no">ur #Device details</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_computers">
      <source>No paired computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی جوڑے گئے کمپیوٹرز نہیں</lengthvariant>
        <lengthvariant priority="2">جوڑے گئے کمپیوٹرز نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_slidervalue_l1_min">
      <source>%L1 min</source>
      <translation variants="no">%L1</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_phones">
      <source>Only phones</source>
      <translation variants="no">صرف فون</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_audio_devices">
      <source>only audio devices</source>
      <translation variants="no">صرف آڈیو آلات</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Belgian</source>
      <translation variants="no">بیلجیئن فرنچ</translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Input device</source>
      <translation variants="yes">
        <lengthvariant priority="1">ان پٹ آلہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Norwegian</source>
      <translation variants="no">نارویائی</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Keyboard layout</source>
      <translation variants="no">تختہ کلید لے آؤٹ</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_audio_devices">
      <source>No audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی آڈیو آلات نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>French</source>
      <translation variants="no">فرانسیسی</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Remove</source>
      <translation variants="no">نکالیں</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>US</source>
      <translation variants="no">امریکی انگریزی</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">منقطع کریں</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_computers">
      <source>Bluetooth - Paired computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - جوڑے گئے کمپیوٹرز</lengthvariant>
      </translation>
    </message>
  </context>
</TS>