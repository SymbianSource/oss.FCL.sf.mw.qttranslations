<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_opt_sub_all_entries">
      <source>All entries</source>
      <translation variants="no">所有日历项</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Not specified</source>
      <translation variants="no">每年</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Not specified</source>
      <translation variants="no">重复</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Not specified</source>
      <translation variants="no">每月</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Not specified</source>
      <translation variants="no">每周</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Not specified</source>
      <translation variants="no">位置</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>Not specified</source>
      <translation variants="no">全天日历项</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>Not specified</source>
      <translation variants="no">结束日期</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Not specified</source>
      <translation variants="no">增加说明</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Not specified</source>
      <translation variants="no">不重复</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Not specified</source>
      <translation variants="no">开始日期</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Not specified</source>
      <translation variants="no">每天</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>Not specified</source>
      <translation variants="no">结束时间</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Not specified</source>
      <translation variants="no">主题</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_entries">
      <source>Delete entries</source>
      <translation variants="no">删除日历项</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">标记为已完成</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Not specified</source>
      <translation variants="no">重复结束日期</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_event">
      <source>New event</source>
      <translation variants="no">新日历项</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_date">
      <source>Go to date</source>
      <translation variants="no">转至其他日期</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">删除会议？</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_calendar_settings">
      <source>Calendar settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_meeting">
      <source>New meeting</source>
      <translation variants="no">新会议</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_mo">
      <source>Mo</source>
      <translation variants="no">zh ##Mo</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[14]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Delete entries?</source>
      <translation variants="no">zh #Delete entries?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_30">
      <source>30 minutes</source>
      <translation variants="no">30分钟</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_regional_information">
      <source>Regional information</source>
      <translation variants="yes">
        <lengthvariant priority="1">区域信息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_10">
      <source>10 minutes</source>
      <translation variants="no">10分钟</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_yes">
      <source>Yes</source>
      <translation variants="no">是</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_set_date">
      <source>Set date</source>
      <translation variants="yes">
        <lengthvariant priority="1">设置日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_sa">
      <source>Sa</source>
      <translation variants="no">zh ##Sa</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_today">
      <source>Go to today</source>
      <translation variants="no">转至今日</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_su">
      <source>Su</source>
      <translation variants="no">zh ##Su</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">仅此次</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_yes">
      <source>Yes</source>
      <translation variants="no">是</translation>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_snooze_time_val_ln">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">zh #%Ln minutes</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">所有各次重复</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_all_calendar_entries">
      <source>Delete all calendar entries?</source>
      <translation variants="no">删除所有日历项？</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_no">
      <source>No</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">zh ##Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_yes">
      <source>Yes</source>
      <translation variants="no">是</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Delete anniversary?</source>
      <translation variants="no">删除纪念日？</translation>
    </message>
    <message numerus="no" id="txt_calendar_month_label_title_12">
      <source>%1%2</source>
      <translation variants="no">zh ##%1%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_tu">
      <source>Tu</source>
      <translation variants="no">zh ##Tu</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_5_m">
      <source>5 minutes</source>
      <translation variants="no">5分钟</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_lunar_calendar">
      <source>Show lunar calendar</source>
      <translation variants="no">显示农历</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_no">
      <source>No</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_short_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">zh #Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_settings">
      <source>Settings</source>
      <translation variants="no">设置</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Not specified</source>
      <translation variants="no">开始时间</translation>
    </message>
    <message numerus="no" id="txt_calendar_empty_list_no_entries">
      <source>No entries for today</source>
      <translation variants="no">zh ##No entries for today</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_no">
      <source>No</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_main_view">
      <source>Calendar main view</source>
      <translation variants="no">转至日历主视图</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">删除待办事项？</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_th">
      <source>Th</source>
      <translation variants="no">zh ##Th</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">关闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">日历</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">截止日期：%1</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">日历</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_unnamed">
      <source>Unnamed</source>
      <translation variants="no">zh ##Unnamed</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_1_2">
      <source>%1 -%2</source>
      <translation variants="no">%[10]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_no_entries">
      <source>No entries for today</source>
      <translation variants="no">zh ##No entries for today</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_before_date">
      <source>Before date</source>
      <translation variants="no">选定日期以前日历项</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_fr">
      <source>Fr</source>
      <translation variants="no">zh ##Fr</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Not specified</source>
      <translation variants="no">闹铃</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time">
      <source>Reminder snooze time</source>
      <translation variants="no">闹铃重响时间</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">未命名</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_event">
      <source>Event</source>
      <translation variants="yes">
        <lengthvariant priority="1">日历项</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除重复日历项：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_anniversary">
      <source>New anniversary</source>
      <translation variants="no">新纪念日</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_we">
      <source>We</source>
      <translation variants="no">zh ##We</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_wk">
      <source>Wk</source>
      <translation variants="no">zh ##Wk</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_15">
      <source>15 minutes</source>
      <translation variants="no">15分钟</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_week_numbers">
      <source>Show week numbers</source>
      <translation variants="no">周数</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_buddhist_year">
      <source>Show buddhist year</source>
      <translation variants="no">显示佛教年份</translation>
    </message>
  </context>
</TS>