<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_applib_dialog_delete_1">
      <source>Delete %1?</source>
      <translation variants="no">Xóa bộ sưu tập '%[13]1'?</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sort_by">
      <source>Sort by</source>
      <translation variants="no">Sắp xếp theo</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sort_by_sub_oldest_on_top">
      <source>Oldest on top</source>
      <translation variants="no">Cũ nhất trên cùng</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_custom">
      <source>Custom</source>
      <translation variants="no">Thứ tự tùy chỉnh</translation>
    </message>
    <message numerus="no" id="txt_applib_list_new_collection">
      <source>New collection</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #New collection</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_new_collection">
      <source>New collection</source>
      <translation variants="no">Bộ sưu tập mới</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_remove_1_from_collection">
      <source>Remove %1 from collection?</source>
      <translation variants="no">vi #Remove %1 from collection?</translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_downloaded_val_empty">
      <source>Empty</source>
      <translation variants="yes">
        <lengthvariant priority="1">(không có ứng dụng)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_entry_collectionl1">
      <source>Collection(%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bộ sưu tập %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_ascending">
      <source>Ascending</source>
      <translation variants="no">Tên (tăng dần)</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_resume">
      <source>Resume</source>
      <translation variants="no">Tiếp tục tải về</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_latest_on_top">
      <source>Latest on top</source>
      <translation variants="no">Mới nhất trên cùng</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sort_by_sub_latest_on_top">
      <source>Latest on top</source>
      <translation variants="no">Mới nhất trên cùng</translation>
    </message>
    <message numerus="no" id="txt_applib_title_applications">
      <source>Applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ứng dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_button_add_to_homescreen">
      <source>Add to Homescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thêm vào Màn hình chính</lengthvariant>
        <lengthvariant priority="2">Th. vào M.h.ch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_title_arrange">
      <source>Arrange</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sắp xếp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_menu_cancel_installing">
      <source>Cancel installing</source>
      <translation variants="no">Hủy cài đặt</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_installation_time">
      <source>Installation time</source>
      <translation variants="no">Thời gian cài đặt</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_arrange">
      <source>Arrange</source>
      <translation variants="no">Sắp xếp</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_view_installed_applications">
      <source>View installed applications</source>
      <translation variants="no">Xem ứ.dụng đã cài đặt</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_file_corrupted_unable_to_use_wi">
      <source>File corrupted, unable to use widget. Delete widget? </source>
      <translation variants="no">vi #File corrupted, unable to use widget. Delete widget? </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_installed">
      <source>Installed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_menu_remove_from_collection">
      <source>Remove from collection</source>
      <translation variants="no">Xóa khỏi bộ sưu tập</translation>
    </message>
    <message numerus="no" id="txt_applib_title_select_applications">
      <source>Select applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn các ứng dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_will_be_removed_from_phone_c">
      <source>%1 will be removed from phone. Continue?</source>
      <translation variants="no">vi #%1 will be removed from phone. Continue?</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_add_to_home_screen">
      <source>Add to Home Screen</source>
      <translation variants="no">Thêm vào M.hình chính</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_entry_collection">
      <source>Collection</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bộ sưu tập</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_task_switcher">
      <source>Task Switcher</source>
      <translation variants="no">Bộ chuyển tác vụ</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_add_content">
      <source>Add content</source>
      <translation variants="no">Thêm nội dung</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_uninstalls_1_and_deletes_all_sh">
      <source>%1 and all its shortcuts will be removed from phone. Continue?</source>
      <translation variants="no">vi #%1 and all its shortcuts will be removed from phone. Continue?</translation>
    </message>
    <message numerus="no" id="txt_applib_dpopinfo_added_to_collection_1">
      <source>Added to collection %1</source>
      <translation variants="no">Đã thêm vào bộ sưu tập '%[61]1'</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_add_to_collection">
      <source>Add to collection</source>
      <translation variants="no">Thêm vào bộ sưu tập</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_must_be_closed_before_deletin">
      <source>%1 must be closed before deleting. Close %1? </source>
      <translation variants="no">vi #%1 must be closed before deleting. Close %1? </translation>
    </message>
    <message numerus="no" id="txt_applib_menu_add_to_home_screen">
      <source>Add to Home Screen</source>
      <translation variants="no">Thêm vào M.hình chính</translation>
    </message>
    <message numerus="no" id="txt_applib_button_add_to_collection">
      <source>Add to Collection</source>
      <translation variants="no">vi #Add to Collection</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_description">
      <source>Description:</source>
      <translation variants="no">vi #Description:</translation>
    </message>
    <message numerus="no" id="txt_applib_formlabel_empty">
      <source>Empty</source>
      <translation variants="no">vi #Empty</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="no">vi #%1 Memory card</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_memory_in_use">
      <source>Memory in use:</source>
      <translation variants="no">vi #Memory in use:</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_version">
      <source>Version:</source>
      <translation variants="no">vi #Version:</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="no">vi #%1 Mass storage</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_installation_log">
      <source>Installation log</source>
      <translation variants="no">vi #Installation log</translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_uninstalling_1">
      <source>Uninstalling %1</source>
      <translation variants="no">vi #Uninstalling %1</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_removed">
      <source>Removed</source>
      <translation variants="no">vi #Removed</translation>
    </message>
    <message numerus="no" id="txt_applib_title_installation_logs">
      <source>Installation logs</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Installation logs</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_title_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Details</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_installed">
      <source>Installed</source>
      <translation variants="no">vi #Installed</translation>
    </message>
    <message numerus="no" id="txt_applib_formlabel_no_search_results">
      <source>No search results</source>
      <translation variants="no">vi #No search results</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_size">
      <source>Size:</source>
      <translation variants="no">vi #Size:</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_name">
      <source>Name:</source>
      <translation variants="no">vi #Name:</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_partially_installed">
      <source>Partially installed</source>
      <translation variants="no">vi #Partially installed</translation>
    </message>
    <message numerus="no" id="txt_applib_dpophead_added_to_homescreen">
      <source>Added to Homescreen</source>
      <translation variants="no">vi #Added to Homescreen</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_format">
      <source>Format:</source>
      <translation variants="no">vi #Format:</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_oldest_on_top">
      <source>Oldest on top</source>
      <translation variants="no">Cũ nhất trên cùng</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_deletes_1_also_from_home_screen">
      <source>Deletes %1 also from Home Screen. Continue?</source>
      <translation variants="no">vi #Deletes %1 also from Home Screen. Continue?</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_check_software_updates">
      <source>Check software updates</source>
      <translation variants="no">K.tra bản c.nhật p.mềm</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_add_to_collection">
      <source>Add to collection...</source>
      <translation variants="no">Thêm vào bộ sưu tập</translation>
    </message>
    <message numerus="yes" id="txt_applib_dblist_val_ln_new_applications">
      <source>%Ln new applications</source>
      <translation>
        <numerusform plurality="a">%Ln ứng dụng mới</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_supplier">
      <source>Supplier:</source>
      <translation variants="no">vi #Supplier:</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_descending">
      <source>Descending</source>
      <translation variants="no">Tên (giảm dần)</translation>
    </message>
    <message numerus="no" id="txt_applib_title_collection_name">
      <source>Collection name:</source>
      <translation variants="no">Tên bộ sưu tập</translation>
    </message>
    <message numerus="no" id="txt_applib_title_add_to">
      <source>Add to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thêm vào bộ sưu tập:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_menu_send_to_friend">
      <source>Send to friend</source>
      <translation variants="no">Gửi địa chỉ web</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="no">vi #%1 Device memory</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_2">
      <source>%1 %2</source>
      <translation variants="no">vi #%1 %2</translation>
    </message>
  </context>
</TS>