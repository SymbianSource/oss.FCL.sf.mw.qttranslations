<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_other_call_ln">
      <source>Call %L1</source>
      <translation variants="no">zh_tw #Call %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_button_drop">
      <source>Drop</source>
      <translation variants="no">zh_tw #Drop</translation>
    </message>
    <message numerus="no" id="txt_phone_other_attempting">
      <source>Attempting</source>
      <translation variants="no">zh_tw #Attempting</translation>
    </message>
    <message numerus="no" id="txt_phone_other_on_hold">
      <source>On hold</source>
      <translation variants="no">zh_tw #On hold</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_call">
      <source>Incoming call</source>
      <translation variants="no">zh_tw #Incoming call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_swap">
      <source>Swap</source>
      <translation variants="no">zh_tw #Swap</translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling">
      <source>Calling</source>
      <translation variants="no">zh_tw #Calling</translation>
    </message>
    <message numerus="no" id="txt_phone_other_waiting">
      <source>Waiting</source>
      <translation variants="no">zh_tw #Waiting</translation>
    </message>
    <message numerus="no" id="txt_phone_other_swipe_down_to_answer">
      <source>Swipe down to answer</source>
      <translation variants="no">zh_tw #Swipe down to answer</translation>
    </message>
    <message numerus="no" id="txt_long_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">電話</translation>
    </message>
    <message numerus="no" id="txt_phone_button_replace_active_call">
      <source>Replace active call</source>
      <translation variants="no">zh_tw #Replace active call</translation>
    </message>
    <message numerus="no" id="txt_phone_other_private_number">
      <source>Private number</source>
      <translation variants="no">zh_tw #Private number</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_transfer">
      <source>Transfer</source>
      <translation variants="no">轉接</translation>
    </message>
    <message numerus="no" id="txt_phone_title_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_opt_share_video">
      <source>Share video</source>
      <translation variants="no">分享影片</translation>
    </message>
    <message numerus="no" id="txt_phone_other_conference_call">
      <source>Conference call</source>
      <translation variants="no">zh_tw #Conference call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_end_call">
      <source>End call</source>
      <translation variants="no">zh_tw #End call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_hold">
      <source>Hold</source>
      <translation variants="no">zh_tw #Hold</translation>
    </message>
    <message numerus="no" id="txt_phone_button_send_message">
      <source>Send message</source>
      <translation variants="yes">
        <lengthvariant priority="1">傳送訊息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_button_join">
      <source>Join</source>
      <translation variants="no">zh_tw #Join</translation>
    </message>
    <message numerus="no" id="txt_phone_other_disconnected">
      <source>Disconnected</source>
      <translation variants="no">zh_tw #Disconnected</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_ended">
      <source>Call ended</source>
      <translation variants="no">通話已中斷</translation>
    </message>
    <message numerus="no" id="txt_phone_info_called_number_has_barred_incoming">
      <source>Called number has barred incoming calls</source>
      <translation variants="no">無法撥打視訊電話。對方手機限制來電。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_use">
      <source>Number not in use</source>
      <translation variants="no">號碼未使用</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_own_number_sending">
      <source>Check own number sending</source>
      <translation variants="no">請檢查本機號碼傳送設定</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_terminated">
      <source>Call Terminated</source>
      <translation variants="no">通話摘要</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_answer">
      <source>No answer</source>
      <translation variants="no">對方無應答</translation>
    </message>
    <message numerus="no" id="txt_phone_other_call">
      <source>Call</source>
      <translation variants="no">zh_tw #Call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_send_string">
      <source>Send string:\n%L1</source>
      <translation variants="no">傳送DTMF： %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_barred_in_closed_group">
      <source>Call barred in closed group</source>
      <translation variants="no">僅限定撥給特定分組號碼</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending_file_to_1">
      <source>Sending file to %L1</source>
      <translation variants="no">正在傳送訊息至%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_barrings">
      <source>Note: you have active barrings</source>
      <translation variants="no">注意：已啟動通話限制</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">只能進行緊急通話</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_busy">
      <source>Network busy</source>
      <translation variants="no">系統忙線</translation>
    </message>
    <message numerus="no" id="txt_phone_info_unable_to_make_video_call_not_supp">
      <source>Unable to make video call. Not supported by other phone or network.</source>
      <translation variants="no">無法撥打視訊電話。對方手機或系統不支援。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_transfer_in_progress">
      <source>Transfer in progress</source>
      <translation variants="no">轉接中</translation>
    </message>
    <message numerus="no" id="txt_phone_info_could_not_send_own_number">
      <source>Could not send own number</source>
      <translation variants="no">無法傳送您的本機號碼</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_rf_loopback_enabled">
      <source>Bluetooth RF loopback enabled</source>
      <translation variants="no">藍牙測試模式</translation>
    </message>
    <message numerus="no" id="txt_phone_info_closed_group_unknown">
      <source>Closed group unknown</source>
      <translation variants="no">無法識別的特定分組</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected">
      <source>Connected</source>
      <translation variants="no">已連線</translation>
    </message>
    <message numerus="no" id="txt_phone_info_wlan_mac_address_1">
      <source>WLAN MAC address: %L1</source>
      <translation variants="no">WLAN MAC位址：%1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_select_closed_group">
      <source>Select closed group</source>
      <translation variants="no">選取特定分組</translation>
    </message>
    <message numerus="no" id="txt_phone_info_time">
      <source>Time</source>
      <translation variants="no">時間：</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_diverts">
      <source>Note:  you have active diverts</source>
      <translation variants="no">注意：已啟動來電轉接</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_not_allowed_during_resto">
      <source>Video call not allowed during restore</source>
      <translation variants="no">還原期間無法撥打視訊電話</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_network_services">
      <source>Check network services</source>
      <translation variants="no">請檢查系統服務</translation>
    </message>
    <message numerus="no" id="txt_phone_info_transferred">
      <source>Transferred</source>
      <translation variants="no">已轉接</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending">
      <source>Sending\n%L1</source>
      <translation variants="no">正在傳送 〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃</translation>
    </message>
    <message numerus="no" id="txt_phone_other_remote_sim">
      <source>Remote SIM</source>
      <translation variants="no">zh_tw #Remote SIM</translation>
    </message>
    <message numerus="no" id="txt_phone_info_videocall_only_possible_under_3g">
      <source>Videocall only possible under 3G coverage</source>
      <translation variants="no">在3G系統以外的地區不支援視訊電話</translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">電話號碼無效</translation>
    </message>
    <message numerus="no" id="txt_phone_info_life_timer">
      <source>Life timer\n%L1</source>
      <translation variants="no">總通話計時器： 〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃</translation>
    </message>
    <message numerus="no" id="txt_phone_info_serial_no">
      <source>Serial No.\n%L1</source>
      <translation variants="no">序號： 〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_rejected">
      <source>Call rejected</source>
      <translation variants="no">通話被拒絕</translation>
    </message>
    <message numerus="no" id="txt_phone_info_closed_group_1_in_use">
      <source>Closed group %L1 in use</source>
      <translation variants="no">特定分組%L1使用中</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_number_stored_in_location_1">
      <source>No number stored in location %L1</source>
      <translation variants="no">未將號碼儲存至SIM卡位置%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_not_allowed_fixed_dialling">
      <source>Call not allowed, fixed dialling active</source>
      <translation variants="no">不允許通話。固定撥號已啟動。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_closed_user_group">
      <source>Check closed user group</source>
      <translation variants="no">請檢查特定分組</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_in_progress">
      <source>Call in progress</source>
      <translation variants="no">通話中</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_call_failed">
      <source>Emergency call failed</source>
      <translation variants="no">無法進行緊急通話</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected_to_1">
      <source>Connected to %L1</source>
      <translation variants="no">已連線至%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_didnt_succeed_to_called">
      <source>Video call didn't succeed to called end</source>
      <translation variants="no">無法撥打視訊電話。對方手機或系統不支援。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conference_call_active">
      <source>Conference call active</source>
      <translation variants="no">會議通話已啟動</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_network_support_for_video_call">
      <source>No network support for video call</source>
      <translation variants="no">視訊電話不受系統支援</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_no_network_coverage">
      <source>No network coverage</source>
      <translation variants="no">zh_tw #No network coverage</translation>
    </message>
    <message numerus="no" id="txt_phone_button_silence">
      <source>Silence</source>
      <translation variants="no">zh_tw #Silence</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_end_all_calls">
      <source>End all calls</source>
      <translation variants="no">結束所有通話</translation>
    </message>
    <message numerus="no" id="txt_phone_title_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">離線</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_switched_off_or_out_of_3g">
      <source>Phone switched off or out of 3G coverage</source>
      <translation variants="no">無法撥打視訊電話。對方手機關機或不在3G系統內。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_rf_loopback_disabled">
      <source>Bluetooth RF loopback disabled</source>
      <translation variants="no">藍牙測試模式</translation>
    </message>
    <message numerus="no" id="txt_phone_info_error_in_connection">
      <source>Error in connection</source>
      <translation variants="no">連線錯誤</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_busy">
      <source>Number busy</source>
      <translation variants="no">號碼忙線中</translation>
    </message>
    <message numerus="no" id="txt_short_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">zh_tw #Telephone</translation>
    </message>
    <message numerus="no" id="txt_phone_info_end_gprs_connection_first">
      <source>End GPRS connection first</source>
      <translation variants="no">請先關閉封包數據連線</translation>
    </message>
    <message numerus="no" id="txt_phone_other_emergency_call">
      <source>Emergency call</source>
      <translation variants="no">zh_tw #Emergency call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_setup_failed">
      <source>Video call setup failed</source>
      <translation variants="no">無法撥打視訊電話</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_barred">
      <source>Number barred</source>
      <translation variants="no">號碼已被限制</translation>
    </message>
    <message numerus="no" id="txt_phone_button_private">
      <source>Private</source>
      <translation variants="no">zh_tw #Private</translation>
    </message>
    <message numerus="no" id="txt_phone_button_unlock">
      <source>Unlock</source>
      <translation variants="no">zh_tw #Unlock</translation>
    </message>
    <message numerus="no" id="txt_phone_button_unhold">
      <source>Unhold</source>
      <translation variants="no">zh_tw #Unhold</translation>
    </message>
    <message numerus="no" id="txt_phone_other_diverted_call">
      <source>Diverted call</source>
      <translation variants="no">zh_tw #Diverted call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_closed_group">
      <source>Number not in closed group</source>
      <translation variants="no">號碼不在特定分組</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_possible_in_this_group">
      <source>Service not possible in this group</source>
      <translation variants="no">特定分組內無此服務</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_all_incoming_calls_diver">
      <source>Note:  all incoming calls diverted</source>
      <translation variants="no">注意：轉接所有來電</translation>
    </message>
    <message numerus="no" id="txt_phone_info_tty_call_active_volume_control_not">
      <source>TTY call active. Volume control not available</source>
      <translation variants="no">使用聽障通訊器通話期間無法控制音量</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_device_address_1">
      <source>Bluetooth device address: %L1</source>
      <translation variants="no">藍牙裝置位址：%1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_activate_own_number_sending">
      <source>Activate own number sending</source>
      <translation variants="no">啟動本機號碼傳送</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">zh_tw #Not allowed</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_diverting">
      <source>Diverting</source>
      <translation variants="no">轉接中</translation>
    </message>
  </context>
</TS>