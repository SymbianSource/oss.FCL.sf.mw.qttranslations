<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_common_button_yes_toolbar">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok_toolbar">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_hide_toolbar">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Hide</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_send_toolbar">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel_toolbar">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_answer_toolbar">
      <source>Answer</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Answer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_opening">
      <source>Opening</source>
      <translation variants="no">Đang mở</translation>
    </message>
    <message numerus="no" id="txt_common_title_details">
      <source>Details:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_undo">
      <source>Undo</source>
      <translation variants="no">Hoàn tác</translation>
    </message>
    <message numerus="no" id="txt_common_opt_internet_call">
      <source>Internet call</source>
      <translation variants="no">Thực hiện c.gọi net</translation>
    </message>
    <message numerus="no" id="txt_common_opt_go_to_web_address">
      <source>Go to web address</source>
      <translation variants="no">Chuyển đến địa chỉ web</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_expires">
      <source>Expires:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hết hạn:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Ngắt kết nối</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gửi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_unmark">
      <source>Unmark</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hủy dấu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_define">
      <source>Define</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xác định</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đóng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_uninstall">
      <source>Uninstall</source>
      <translation variants="no">Gỡ bỏ cài đặt</translation>
    </message>
    <message numerus="no" id="txt_common_opt_rename_people">
      <source>Rename</source>
      <translation variants="no">Đổi tên</translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_object">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích hoạt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_collapse">
      <source>Collapse</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thu hẹp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_exit">
      <source>Exit</source>
      <translation variants="no">Thoát</translation>
    </message>
    <message numerus="no" id="txt_common_opt_move">
      <source>Move</source>
      <translation variants="no">Chuyển</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone1">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn nhạc chuông:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_web_address">
      <source>Web address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ web:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_folder">
      <source>Add to folder</source>
      <translation variants="no">Thêm vào thư mục</translation>
    </message>
    <message numerus="no" id="txt_common_opt_move_to_folder">
      <source>Move to folder</source>
      <translation variants="no">Chuyển đến thư mục</translation>
    </message>
    <message numerus="no" id="txt_common_opt_play_music">
      <source>Play</source>
      <translation variants="no">Phát</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">Thêm chi tiết</translation>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_off">
      <source>Automatic find off</source>
      <translation variants="no">Tắt tìm tự động</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_time">
      <source>Time:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giờ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_bookmark_name">
      <source>Bookmark name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên bookmark:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_connecting">
      <source>Connecting</source>
      <translation variants="no">Đang kết nối</translation>
    </message>
    <message numerus="no" id="txt_common_button_deactivate">
      <source>Deactivate</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_preview_audio">
      <source>Preview</source>
      <translation variants="no">Xem trước</translation>
    </message>
    <message numerus="no" id="txt_common_menu_settings">
      <source>Settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_common_opt_install">
      <source>Install</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_common_info_copying">
      <source>Copying</source>
      <translation variants="no">Đang sao chép</translation>
    </message>
    <message numerus="no" id="txt_common_menu_preview_video">
      <source>Preview</source>
      <translation variants="no">Xem trước</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_from_contacts">
      <source>Add from Contacts</source>
      <translation variants="no">Thêm từ Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_folder">
      <source>Select folder:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn thư mục:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_forward">
      <source>Forward</source>
      <translation variants="no">Chuyển tiếp</translation>
    </message>
    <message numerus="no" id="txt_common_button_clear">
      <source>Clear</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_insert">
      <source>Insert</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chèn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_requesting">
      <source>Requesting</source>
      <translation variants="no">Đang yêu cầu</translation>
    </message>
    <message numerus="no" id="txt_common_menu_install">
      <source>Install</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_common_info_saving">
      <source>Saving</source>
      <translation variants="no">Đang lưu lại</translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Có</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_first_name">
      <source>Last name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Họ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_image">
      <source>Add image</source>
      <translation variants="no">Thêm hình ảnh</translation>
    </message>
    <message numerus="no" id="txt_common_menu_find">
      <source>Find</source>
      <translation variants="no">Tìm</translation>
    </message>
    <message numerus="no" id="txt_common_opt_print">
      <source>Print</source>
      <translation variants="no">In</translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate">
      <source>Activate</source>
      <translation variants="no">Kích hoạt</translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_video">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xem trước</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_help">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hướng dẫn sử dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_bookmark">
      <source>Add bookmark</source>
      <translation variants="no">Lưu dạng bookmark</translation>
    </message>
    <message numerus="no" id="txt_common_opt_exit">
      <source>Exit</source>
      <translation variants="no">Thoát</translation>
    </message>
    <message numerus="no" id="txt_common_opt_help">
      <source>Help</source>
      <translation variants="no">Hướng dẫn sử dụng</translation>
    </message>
    <message numerus="no" id="txt_common_button_answer">
      <source>Answer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trả lời</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_start">
      <source>Start</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bắt đầu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_unmute">
      <source>Unmute</source>
      <translation variants="no">Bật tiếng</translation>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_off">
      <source>Automatic find off</source>
      <translation variants="no">Tắt tìm tự động</translation>
    </message>
    <message numerus="no" id="txt_common_menu_replace">
      <source>Replace</source>
      <translation variants="no">Thay thế</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_date">
      <source>Date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_connect">
      <source>Connect</source>
      <translation variants="no">Kết nối</translation>
    </message>
    <message numerus="no" id="txt_common_opt_video_call">
      <source>Video call</source>
      <translation variants="no">Thực hiện cuộc gọi video</translation>
    </message>
    <message numerus="no" id="txt_common_info_inserting">
      <source>Inserting</source>
      <translation variants="no">Đang chèn</translation>
    </message>
    <message numerus="no" id="txt_common_info_moving">
      <source>Moving</source>
      <translation variants="no">Đang chuyển</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_address">
      <source>Address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">Mở</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_title">
      <source>Title:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tiêu đề:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_move_to_folder">
      <source>Move to folder</source>
      <translation variants="no">Chuyển đến thư mục</translation>
    </message>
    <message numerus="no" id="txt_common_opt_chat">
      <source>Chat</source>
      <translation variants="no">Trò chuyện</translation>
    </message>
    <message numerus="no" id="txt_common_opt_additional_details">
      <source>Additional details</source>
      <translation variants="no">Thông tin thêm</translation>
    </message>
    <message numerus="no" id="txt_common_title_writing_language">
      <source>Writing language:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngôn ngữ soạn thảo:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_resume">
      <source>Resume</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tiếp tục lại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_memory">
      <source>Select memory:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn bộ nhớ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_voice_call">
      <source>Voice call</source>
      <translation variants="no">Thực hiện cuộc gọi thoại</translation>
    </message>
    <message numerus="no" id="txt_common_opt_call_verb">
      <source>Call</source>
      <translation variants="no">Cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_common_menu_paste">
      <source>Paste</source>
      <translation variants="no">Dán</translation>
    </message>
    <message numerus="no" id="txt_common_info_registering">
      <source>Registering</source>
      <translation variants="no">Đang đăng ký</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hủy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_recipient">
      <source>Add recipient</source>
      <translation variants="no">Thêm người nhận</translation>
    </message>
    <message numerus="no" id="txt_common_menu_enable">
      <source>Enable</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone3">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn nhạc chuông:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_address">
      <source>Select address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn địa chỉ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_buffering">
      <source>Buffering</source>
      <translation variants="no">Đang đệm</translation>
    </message>
    <message numerus="no" id="txt_common_button_select">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_hide">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ẩn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_cut">
      <source>Cut</source>
      <translation variants="no">Cắt</translation>
    </message>
    <message numerus="no" id="txt_common_opt_save">
      <source>Save</source>
      <translation variants="no">Lưu lại</translation>
    </message>
    <message numerus="no" id="txt_common_button_reply">
      <source>Reply</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trả lời</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_play_music">
      <source>Play</source>
      <translation variants="no">Phát</translation>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_in">
      <source>Zoom in</source>
      <translation variants="no">Phóng to</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name1">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_rename_item">
      <source>Rename</source>
      <translation variants="no">Đổi tên</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_recipient">
      <source>Add recipient</source>
      <translation variants="no">Thêm người nhận</translation>
    </message>
    <message numerus="no" id="txt_common_menu_cut">
      <source>Cut</source>
      <translation variants="no">Cắt</translation>
    </message>
    <message numerus="no" id="txt_common_menu_disable">
      <source>Disable</source>
      <translation variants="no">Vô hiệu</translation>
    </message>
    <message numerus="no" id="txt_common_menu_cancel_download">
      <source>Cancel download</source>
      <translation variants="no">Hủy tải về</translation>
    </message>
    <message numerus="no" id="txt_common_button_connect">
      <source>Connect</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_out">
      <source>Zoom out</source>
      <translation variants="no">Thu nhỏ</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_duration">
      <source>Duration:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời lượng:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_continue">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tiếp tục</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_additional_details">
      <source>Additional details</source>
      <translation variants="no">Chi tiết bổ sung</translation>
    </message>
    <message numerus="no" id="txt_common_menu_voice_call">
      <source>Voice call</source>
      <translation variants="no">Thực hiện cuộc gọi thoại</translation>
    </message>
    <message numerus="no" id="txt_common_info_initialising">
      <source>Initialising</source>
      <translation variants="no">Đang khởi chạy</translation>
    </message>
    <message numerus="no" id="txt_common_opt_mark">
      <source>Mark</source>
      <translation variants="no">Đánh dấu</translation>
    </message>
    <message numerus="no" id="txt_common_opt_details">
      <source>Details</source>
      <translation variants="no">Chi tiết</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_current_password">
      <source>Current password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mật khẩu hiện tại:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_insert">
      <source>Insert</source>
      <translation variants="no">Chèn</translation>
    </message>
    <message numerus="no" id="txt_common_button_reject">
      <source>Reject</source>
      <translation variants="yes">
        <lengthvariant priority="1">Từ chối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_audio">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xem trước</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Cài đặt nâng cao</translation>
    </message>
    <message numerus="no" id="txt_common_opt_replace">
      <source>Replace</source>
      <translation variants="no">Thay thế</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_new_password">
      <source>Verify new password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xác minh mật khẩu mới:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_undo">
      <source>Undo</source>
      <translation variants="no">Hoàn tác</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_bookmark">
      <source>Add bookmark</source>
      <translation variants="no">Lưu dạng bookmark</translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_message">
      <source>Send message</source>
      <translation variants="no">Gửi tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_common_menu_internet_call">
      <source>Internet call</source>
      <translation variants="no">Thực hiện c.gọi net</translation>
    </message>
    <message numerus="no" id="txt_common_opt_play_video">
      <source>Play</source>
      <translation variants="no">Phát</translation>
    </message>
    <message numerus="no" id="txt_common_button_play_audio">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">Phát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_attachments">
      <source>Attachments</source>
      <translation variants="no">Phần đính kèm</translation>
    </message>
    <message numerus="no" id="txt_common_opt_remove">
      <source>Remove</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_common_button_save">
      <source>Save</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lưu lại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_install">
      <source>Install</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_video_call">
      <source>Video call</source>
      <translation variants="no">Thực hiện cuộc gọi video</translation>
    </message>
    <message numerus="no" id="txt_common_button_retry">
      <source>Retry</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thử lại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_to">
      <source>To:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đến:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_create_message">
      <source>Create message</source>
      <translation variants="no">Tạo tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_common_button_paste">
      <source>Paste</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dán</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_user_id">
      <source>User ID:</source>
      <translation variants="yes">
        <lengthvariant priority="1">ID người dùng:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_about_application">
      <source>About application</source>
      <translation variants="no">Giới thiệu ứng dụng</translation>
    </message>
    <message numerus="no" id="txt_common_menu_remove">
      <source>Remove</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_common_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Ngắt kết nối</translation>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate">
      <source>Deactivate</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_common_opt_edit">
      <source>Edit</source>
      <translation variants="no">Chỉnh sửa</translation>
    </message>
    <message numerus="no" id="txt_common_menu_continue">
      <source>Continue</source>
      <translation variants="no">Tiếp tục</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_thumbnail">
      <source>Add thumbnail</source>
      <translation variants="no">Thêm hình thu nhỏ</translation>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_in">
      <source>Zoom in</source>
      <translation variants="no">Phóng to</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_image">
      <source>Add image</source>
      <translation variants="no">Thêm hình ảnh</translation>
    </message>
    <message numerus="no" id="txt_common_opt_fit_to_screen">
      <source>Fit to screen</source>
      <translation variants="no">Vừa màn hình</translation>
    </message>
    <message numerus="no" id="txt_common_button_unmute">
      <source>Unmute</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bật âm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_file_name">
      <source>File name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên tập tin:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_forward">
      <source>Forward</source>
      <translation variants="no">Chuyển tiếp</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_detail">
      <source>Add detail</source>
      <translation variants="no">Thêm chi tiết</translation>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">Tắt loa</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_folder">
      <source>Add to folder</source>
      <translation variants="no">Thêm vào thư mục</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="no">Thêm vào Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_common_opt_call_noun">
      <source>Call</source>
      <translation variants="no">Cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmark">
      <source>Unmark</source>
      <translation variants="no">Hủy dấu</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_phone_number">
      <source>Phone number:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số điện thoại:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_go_to_web_address">
      <source>Go to web address</source>
      <translation variants="no">Chuyển đến địa chỉ web</translation>
    </message>
    <message numerus="no" id="txt_common_button_show">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hiển thị</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_copy_to_folder">
      <source>Copy to folder</source>
      <translation variants="no">Sao chép vào thư mục</translation>
    </message>
    <message numerus="no" id="txt_common_menu_chat">
      <source>Chat</source>
      <translation variants="no">Trò chuyện</translation>
    </message>
    <message numerus="no" id="txt_common_button_handset">
      <source>Handset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích hoạt điện thoại cầm tay</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate">
      <source>Activate</source>
      <translation variants="no">Kích hoạt</translation>
    </message>
    <message numerus="no" id="txt_common_menu_unmark">
      <source>Unmark</source>
      <translation variants="no">Hủy dấu</translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate_handsfree">
      <source>Activate handset</source>
      <translation variants="no">Kích hoạt đ.thoại cầm tay</translation>
    </message>
    <message numerus="no" id="txt_common_button_record_video">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_join">
      <source>Join</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tham gia</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_mute">
      <source>Mute</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt tiếng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_pause">
      <source>Pause</source>
      <translation variants="no">Tạm dừng</translation>
    </message>
    <message numerus="no" id="txt_common_info_closing">
      <source>Closing</source>
      <translation variants="no">Đang đóng</translation>
    </message>
    <message numerus="no" id="txt_common_menu_connect">
      <source>Connect</source>
      <translation variants="no">Kết nối</translation>
    </message>
    <message numerus="no" id="txt_common_menu_play_video">
      <source>Play</source>
      <translation variants="no">Phát</translation>
    </message>
    <message numerus="no" id="txt_common_menu_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">Lưu vào Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_common_button_copy">
      <source>Copy</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sao chép</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_cancelling">
      <source>Cancelling</source>
      <translation variants="no">Đang hủy</translation>
    </message>
    <message numerus="no" id="txt_common_button_play_video">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">Phát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_read">
      <source>Read</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đọc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_common_button_options">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tùy chọn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_language">
      <source>Select language:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn ngôn ngữ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">Kích hoạt loa</translation>
    </message>
    <message numerus="no" id="txt_common_button_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xác lập lại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_pause">
      <source>Pause</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tạm dừng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_password">
      <source>Password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mật khẩu:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_select">
      <source>Select</source>
      <translation variants="no">Chọn</translation>
    </message>
    <message numerus="no" id="txt_common_button_quit">
      <source>Quit</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thoát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_insert">
      <source>Insert</source>
      <translation variants="no">Chèn</translation>
    </message>
    <message numerus="no" id="txt_common_menu_copy">
      <source>Copy</source>
      <translation variants="no">Sao chép</translation>
    </message>
    <message numerus="no" id="txt_common_opt_copy_to_folder">
      <source>Copy to folder</source>
      <translation variants="no">Sao chép vào thư mục</translation>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate">
      <source>Deactivate</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_common_opt_enable">
      <source>Enable</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_common_info_adding">
      <source>Adding</source>
      <translation variants="no">Đang thêm</translation>
    </message>
    <message numerus="no" id="txt_common_menu_call_noun">
      <source>Call</source>
      <translation variants="no">Cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_common_info_disconnecting">
      <source>Disconnecting</source>
      <translation variants="no">Đang ngắt kết nối</translation>
    </message>
    <message numerus="no" id="txt_common_menu_uninstall">
      <source>Uninstall</source>
      <translation variants="no">Gỡ bỏ cài đặt</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_file">
      <source>Select file:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn tập tin:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_rename_people">
      <source>Rename</source>
      <translation variants="no">Đổi tên</translation>
    </message>
    <message numerus="no" id="txt_common_button_call">
      <source>Call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_out">
      <source>Zoom out</source>
      <translation variants="no">Thu nhỏ</translation>
    </message>
    <message numerus="no" id="txt_common_menu_create_message">
      <source>Create message</source>
      <translation variants="no">Tạo tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_folder_name">
      <source>Folder name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên thư mục:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmute">
      <source>Unmute</source>
      <translation variants="no">Bật tiếng</translation>
    </message>
    <message numerus="no" id="txt_common_opt_disable">
      <source>Disable</source>
      <translation variants="no">Vô hiệu</translation>
    </message>
    <message numerus="no" id="txt_common_opt_cancel_download">
      <source>Cancel download</source>
      <translation variants="no">Hủy tải về</translation>
    </message>
    <message numerus="no" id="txt_common_info_searching">
      <source>Searching</source>
      <translation variants="no">Đang tìm kiếm</translation>
    </message>
    <message numerus="no" id="txt_common_button_back">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trở về</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_user_name">
      <source>User name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên người dùng:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Cài đặt nâng cao</translation>
    </message>
    <message numerus="no" id="txt_common_menu_call_verb">
      <source>Call</source>
      <translation variants="no">Cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_common_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">Kích hoạt loa</translation>
    </message>
    <message numerus="no" id="txt_common_menu_organise">
      <source>Organise</source>
      <translation variants="no">Sắp xếp</translation>
    </message>
    <message numerus="no" id="txt_common_opt_change">
      <source>Change</source>
      <translation variants="no">Thay đổi</translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate_handsfree">
      <source>Activate handset</source>
      <translation variants="no">Kích hoạt đ.thoại cầm tay</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_member">
      <source>Add member</source>
      <translation variants="no">Thêm thành viên</translation>
    </message>
    <message numerus="no" id="txt_common_opt_preview_video">
      <source>Preview</source>
      <translation variants="no">Xem trước</translation>
    </message>
    <message numerus="no" id="txt_common_title_web_address">
      <source>Web address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn địa chỉ web:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name2">
      <source>New name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên mới:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_find">
      <source>Find</source>
      <translation variants="no">Tìm</translation>
    </message>
    <message numerus="no" id="txt_common_info_removing">
      <source>Removing</source>
      <translation variants="no">Đang xóa</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_member">
      <source>Add member</source>
      <translation variants="no">Thêm thành viên</translation>
    </message>
    <message numerus="no" id="txt_common_button_change">
      <source>Change</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thay đổi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from">
      <source>From:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Từ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_listen">
      <source>Listen</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nghe</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_reject_toolbar">
      <source>Reject</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Reject</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_fit_to_screen">
      <source>Fit to screen</source>
      <translation variants="no">Vừa màn hình</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_password">
      <source>New password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mật khẩu mới:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_on">
      <source>Automatic find on</source>
      <translation variants="no">Bật tìm tự động</translation>
    </message>
    <message numerus="no" id="txt_common_button_add">
      <source>Add</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thêm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_stop">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngừng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_copy">
      <source>Copy</source>
      <translation variants="no">Sao chép</translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_process">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích hoạt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_installing">
      <source>Installing</source>
      <translation variants="no">Đang cài đặt</translation>
    </message>
    <message numerus="no" id="txt_common_opt_back">
      <source>Back</source>
      <translation variants="no">Trở về</translation>
    </message>
    <message numerus="no" id="txt_common_button_expand">
      <source>Expand</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mở rộng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_open">
      <source>Open</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mở</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name2">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_edit">
      <source>Edit</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_enable">
      <source>Enable</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bật</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_organise">
      <source>Organise</source>
      <translation variants="no">Sắp xếp</translation>
    </message>
    <message numerus="no" id="txt_common_opt_open">
      <source>Open</source>
      <translation variants="no">Mở</translation>
    </message>
    <message numerus="no" id="txt_common_button_finish">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kết thúc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_retrieving">
      <source>Retrieving</source>
      <translation variants="no">Đang tải</translation>
    </message>
    <message numerus="no" id="txt_common_info_deleting">
      <source>Deleting</source>
      <translation variants="no">Đang xóa</translation>
    </message>
    <message numerus="no" id="txt_common_button_replace">
      <source>Replace</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thay thế</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_attachments">
      <source>Attachments</source>
      <translation variants="no">Phần đính kèm</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_thumbnail">
      <source>Add thumbnail</source>
      <translation variants="no">Thêm hình thu nhỏ</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="no">Lưu vào Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_common_menu_details">
      <source>Details</source>
      <translation variants="no">Chi tiết</translation>
    </message>
    <message numerus="no" id="txt_common_button_find">
      <source>Find</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tìm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name1">
      <source>New name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên mới:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_no_toolbar">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_menu">
      <source>Menu</source>
      <translation variants="yes">
        <lengthvariant priority="1">Menu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">Tắt loa</translation>
    </message>
    <message numerus="no" id="txt_common_opt_pause">
      <source>Pause</source>
      <translation variants="no">Tạm dừng</translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_item">
      <source>Send</source>
      <translation variants="no">Gửi</translation>
    </message>
    <message numerus="no" id="txt_common_opt_continue">
      <source>Continue</source>
      <translation variants="no">Tiếp tục</translation>
    </message>
    <message numerus="no" id="txt_common_button_delete_toolbar">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_uninstall">
      <source>Uninstall</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gỡ bỏ cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_message">
      <source>Send message</source>
      <translation variants="no">Gửi tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_common_opt_settings">
      <source>Settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_on">
      <source>Automatic find on</source>
      <translation variants="no">Bật tìm tự động</translation>
    </message>
    <message numerus="no" id="txt_common_info_processing">
      <source>Processing</source>
      <translation variants="no">Đang xử lý</translation>
    </message>
    <message numerus="no" id="txt_common_menu_save">
      <source>Save</source>
      <translation variants="no">Lưu lại</translation>
    </message>
    <message numerus="no" id="txt_common_button_disconnect">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngắt kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone2">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn nhạc chuông:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_on">
      <source>Loudsp. on</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bật loa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_about_application">
      <source>About application</source>
      <translation variants="no">Giới thiệu ứng dụng</translation>
    </message>
    <message numerus="no" id="txt_common_menu_edit">
      <source>Edit</source>
      <translation variants="no">Chỉnh sửa</translation>
    </message>
    <message numerus="no" id="txt_common_menu_move">
      <source>Move</source>
      <translation variants="no">Chuyển</translation>
    </message>
    <message numerus="no" id="txt_common_opt_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">Lưu vào Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_from_contacts">
      <source>Add from Contacts</source>
      <translation variants="no">Thêm từ Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_common_menu_mark">
      <source>Mark</source>
      <translation variants="no">Đánh dấu</translation>
    </message>
    <message numerus="no" id="txt_common_button_record_audio">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_mark">
      <source>Mark</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đánh dấu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xác minh mật khẩu:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_rename_item">
      <source>Rename</source>
      <translation variants="no">Đổi tên</translation>
    </message>
    <message numerus="no" id="txt_common_opt_select">
      <source>Select</source>
      <translation variants="no">Chọn</translation>
    </message>
    <message numerus="no" id="txt_common_menu_preview_audio">
      <source>Preview</source>
      <translation variants="no">Xem trước</translation>
    </message>
    <message numerus="no" id="txt_common_button_remove">
      <source>Remove</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_loading">
      <source>Loading</source>
      <translation variants="no">Đang tải</translation>
    </message>
    <message numerus="no" id="txt_common_opt_delete">
      <source>Delete</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_common_button_exit">
      <source>Exit</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thoát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_clear_toolbar">
      <source>Clear</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Clear</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_move">
      <source>Move</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chuyển</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_paste">
      <source>Paste</source>
      <translation variants="no">Dán</translation>
    </message>
    <message numerus="no" id="txt_common_menu_print">
      <source>Print</source>
      <translation variants="no">In</translation>
    </message>
    <message numerus="no" id="txt_common_info_unistalling">
      <source>Uninstalling</source>
      <translation variants="no">Đang gỡ bỏ cài đặt</translation>
    </message>
    <message numerus="no" id="txt_common_button_disable">
      <source>Disable</source>
      <translation variants="yes">
        <lengthvariant priority="1">Vô hiệu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_item">
      <source>Send</source>
      <translation variants="no">Gửi</translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_off">
      <source>Loudsp. off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt loa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_end_date">
      <source>End date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày kết thúc:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_change">
      <source>Change</source>
      <translation variants="no">Thay đổi</translation>
    </message>
  </context>
</TS>