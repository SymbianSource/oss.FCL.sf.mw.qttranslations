<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_loe_info_enable_for_most_accurate_positioning">
      <source>Enable for most accurate positioning</source>
      <translation variants="no">uk #Enable for most accurate positioning</translation>
    </message>
    <message numerus="no" id="txt_loe_list_assisted_gps">
      <source>Assisted GPS</source>
      <translation variants="no">uk #Assisted GPS</translation>
    </message>
    <message numerus="no" id="txt_loe_button_done">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Done</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_dpophead_your_location_not_sent_to">
      <source>Your location not sent to :</source>
      <translation variants="no">uk #Your location not sent to :</translation>
    </message>
    <message numerus="no" id="txt_loe_info_use_wifi_and_mobile_networks_to_get">
      <source>Use WI-FI and mobile networks to get position information</source>
      <translation variants="no">uk #Use WI-FI and mobile networks to get position information</translation>
    </message>
    <message numerus="no" id="txt_loe_button_save">
      <source>Save</source>
      <translation variants="no">uk #Save</translation>
    </message>
    <message numerus="no" id="txt_loe_title_location_request">
      <source>Location request</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Location request</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_background_positioning">
      <source>Background positioning</source>
      <translation variants="no">uk #Background positioning</translation>
    </message>
    <message numerus="no" id="txt_loe_list_your_location_sent_to_1">
      <source>Your location sent to : %1</source>
      <translation variants="no">uk #Your location sent to : %1</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_month_and_l2_days">
      <source>Updates every %L1 month and %L2 days</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 month and %L2 days</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_select_server_to_delete">
      <source>Select server to delete</source>
      <translation variants="no">uk #Select server to delete</translation>
    </message>
    <message numerus="no" id="txt_loe_title_positioning">
      <source>Positioning</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Positioning</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_not_be_shared_peri">
      <source>Your location will not be shared periodically by default if you don't respond</source>
      <translation variants="no">uk #Your location will not be shared periodically by default if you don't respond</translation>
    </message>
    <message numerus="yes" id="txt_loe_dblist_ln_location_notifications">
      <source>%Ln Location notifications</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_day_and_l2_hour">
      <source>Updates every %L1 day and %L2 hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 day and %L2 hour</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_wifi">
      <source>Wi-Fi</source>
      <translation variants="no">uk #Wi-Fi</translation>
    </message>
    <message numerus="no" id="txt_loe_button_accept">
      <source>Accept</source>
      <translation variants="no">uk #Accept</translation>
    </message>
    <message numerus="no" id="txt_loe_list_cellular_network">
      <source>Cellular network</source>
      <translation variants="no">uk #Cellular network</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_positioning_methods">
      <source>Positioning methods</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Positioning methods</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_internal_gps">
      <source>Internal GPS</source>
      <translation variants="no">uk #Internal GPS</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_positioning">
      <source>Positioning</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Positioning</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4s">
      <source>L1%˚L2%'L3%.L4%"S</source>
      <translation variants="no">uk #L1%˚L2%'L3%.L4%"S</translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_days">
      <source>Updates every %Ln days</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_dblist_positioning_val_acquiring_position">
      <source>Acquiring position</source>
      <translation variants="no">uk #Acquiring position</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_hour_and_l2_minute">
      <source>Updates every %L1 hour and %L2 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 hour and %L2 minutes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_location_was_requested_by">
      <source>Location was requested by : </source>
      <translation variants="no">uk #Location was requested by : </translation>
    </message>
    <message numerus="no" id="txt_loe_info_you_location_will_be_shared_periodica">
      <source>You location will be shared periodically with :</source>
      <translation variants="no">uk #You location will be shared periodically with :</translation>
    </message>
    <message numerus="no" id="txt_loe_list_time">
      <source>&lt;Time&gt;</source>
      <translation variants="no">uk #&lt;Time&gt;</translation>
    </message>
    <message numerus="yes" id="txt_loe_list_accuracy_ln_meters">
      <source>Accuracy: %Ln meters</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_title_location_notifications">
      <source>Location notifications</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Location notifications</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_gps">
      <source>GPS</source>
      <translation variants="no">uk #GPS</translation>
    </message>
    <message numerus="no" id="txt_loe_list_wireless_networks">
      <source>Wireless networks</source>
      <translation variants="no">uk #Wireless networks</translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_minutes">
      <source>Updates every %Ln minutes</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_timedate">
      <source>&lt;Time&gt;&lt;Date&gt;</source>
      <translation variants="no">uk #&lt;Time&gt;&lt;Date&gt;</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_seconds">
      <source>Updates every %L1 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 seconds</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_button_advanced">
      <source>Advanced</source>
      <translation variants="no">uk #Advanced</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_advanced_positioning_settings">
      <source>Advanced positioning settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Advanced positioning settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_be_shared_with">
      <source>Your location will be shared with :</source>
      <translation variants="no">uk #Your location will be shared with :</translation>
    </message>
    <message numerus="no" id="txt_loe_info_enable_applications_and_services_upda">
      <source>Enable applications and services update and retrieve location information</source>
      <translation variants="no">uk #Enable applications and services update and retrieve location information</translation>
    </message>
    <message numerus="no" id="txt_loe_info_unknown_requestor">
      <source>Unknown requestor</source>
      <translation variants="no">uk #Unknown requestor</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_minute_and_l2_seco">
      <source>Updates every %L1 minute and %L2 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 minute and %L2 seconds</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_your_location_not_sent_to_1">
      <source>Your location not sent to: %1</source>
      <translation variants="no">uk #Your location not sent to: %1</translation>
    </message>
    <message numerus="yes" id="txt_loe_list_your_location_sent_to_1_ln_times">
      <source>Your location sent to %1 %Ln times</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_opt_delete_server">
      <source>Delete server</source>
      <translation variants="no">uk #Delete server</translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_be_shared_periodic">
      <source>Your location will be shared periodically by default if you don’t respond.</source>
      <translation variants="no">uk #Your location will be shared periodically by default if you don’t respond.</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_day_and_l2_hours">
      <source>Updates every %L1 day and %L2 hours</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 day and %L2 hours</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_month_and_l2_day">
      <source>Updates every %L1 month and %L2 day</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 month and %L2 day</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_hours">
      <source>Updates every %Ln hours</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_up_every_l1_hours_and_l2_minut">
      <source>Updates every %L1 hours and %L2 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 hours and %L2 minutes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_up_every_l1_minutes_and_l2_sec">
      <source>Updates every %L1 minutes and %L2 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 minutes and %L2 seconds</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_accuracy_ln_kilometers">
      <source>Accuracy: %Ln kilometers</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_positioning_settings">
      <source>Positioning settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Positioning settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_dblist_positioning">
      <source>Positioning</source>
      <translation variants="no">uk #Positioning</translation>
    </message>
    <message numerus="no" id="txt_loe_info_stop_service_1">
      <source>Stop service %1</source>
      <translation variants="no">uk #Stop service %1</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_days_and_l2_hour">
      <source>Updates every %L1 days and %L2 hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 days and %L2 hour</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_button_clear_logs">
      <source>Clear logs</source>
      <translation variants="no">uk #Clear logs</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_positioning_servers">
      <source>Positioning servers</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Positioning servers</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4w">
      <source>L1%˚L2%'L3%.L4%"W</source>
      <translation variants="no">uk #L1%˚L2%'L3%.L4%"W</translation>
    </message>
    <message numerus="no" id="txt_loe_list_bluetooth_gps">
      <source>Bluetooth GPS</source>
      <translation variants="no">uk #Bluetooth GPS</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_days">
      <source>Updates every %Ln days</source>
      <translation variants="no">uk #Updates every %Ln days</translation>
    </message>
    <message numerus="no" id="txt_loe_title_save_as">
      <source>Save as</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Save as</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_months">
      <source>Updates every %Ln months</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_valid_until_1">
      <source>Valid until %1</source>
      <translation variants="no">uk #Valid until %1</translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_not_be_shared_by_d">
      <source>Your location will not be shared by default if you don’t respond</source>
      <translation variants="no">uk #Your location will not be shared by default if you don’t respond</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_hours_and_l2_minut">
      <source>Updates every %L1 hours and %L2 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 hours and %L2 minutes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_months_and_l2_days">
      <source>Updates every %L1 months and %L2 days</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 months and %L2 days</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_subhead_logs">
      <source>Logs</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Logs</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_info_ln_unknown_requestors">
      <source>%Ln Unknown requestors</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_minutes">
      <source>Updates every %Ln minutes</source>
      <translation variants="no">uk #Updates every %Ln minutes</translation>
    </message>
    <message numerus="no" id="txt_loe_dpophead_your_location_sent_to">
      <source>Your location sent to :</source>
      <translation variants="no">uk #Your location sent to :</translation>
    </message>
    <message numerus="no" id="txt_loe_button_settings">
      <source>Settings</source>
      <translation variants="no">uk #Settings</translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4e">
      <source>L1%˚L2%'L3%.L4%"E</source>
      <translation variants="no">uk #L1%˚L2%'L3%.L4%"E</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_minutes_and_l2_sec">
      <source>Updates every %L1 minutes and %L2 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 minutes and %L2 seconds</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4n">
      <source>L1%˚L2%'L3%.L4%"N</source>
      <translation variants="no">uk #L1%˚L2%'L3%.L4%"N</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_days_and_l2_hours">
      <source>Updates every %L1 days and %L2 hours</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 days and %L2 hours</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_background_positioning">
      <source>Background positioning</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Background positioning</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_be_shared_by_defau">
      <source>Your location will be shared by default if you don’t respond</source>
      <translation variants="no">uk #Your location will be shared by default if you don’t respond</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_months_and_l2_day">
      <source>Updates every %L1 months and %L2 day</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 months and %L2 day</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_hours">
      <source>Updates every %Ln hours</source>
      <translation variants="no">uk #Updates every %Ln hours</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_months">
      <source>Updates every %Ln months</source>
      <translation variants="no">uk #Updates every %Ln months</translation>
    </message>
    <message numerus="no" id="txt_loe_list_upd_every_l1_hour_and_l2_minute">
      <source>Updates every %L1 hour and %L2 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 hour and %L2 minutes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_upd_every_l1_minute_and_l2_seco">
      <source>Updates every %L1 minute and %L2 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updates every %L1 minute and %L2 seconds</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_use_1">
      <source>Use %1</source>
      <translation variants="no">uk #Use %1</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_positioning_val_change_positioning_s">
      <source>Change positioning settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Change positioning settings</lengthvariant>
      </translation>
    </message>
  </context>
</TS>