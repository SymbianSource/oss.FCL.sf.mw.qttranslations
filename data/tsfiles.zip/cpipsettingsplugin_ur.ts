<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_subhead_network_settings">
      <source>Network settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیٹ ورک ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_settings">
      <source>Network settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیٹ ورک ترتیبات</lengthvariant>
      </translation>
    </message>
  </context>
</TS>