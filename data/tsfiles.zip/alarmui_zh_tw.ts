<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_date">
      <source>%1</source>
      <translation variants="no">zh_tw ##%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_date">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_dialog_snooze">
      <source>Stop</source>
      <translation variants="no">停止</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snooxed_for_ln_minute">
      <source>Alarm snooxed for %Ln minutes</source>
      <translation>
        <numerusform plurality="a">鬧鈴於%Ln分鐘後重響</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Snooze</source>
      <translation variants="no">重響</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_time">
      <source>%2</source>
      <translation variants="no">zh_tw ##%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Switch phone on ?</source>
      <translation variants="no">是否將裝置開機？</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_time">
      <source>%2</source>
      <translation variants="no">%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>To-do note</source>
      <translation variants="no">待辦事項鬧鈴</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_slide_down_to_stop">
      <source>Slide down to stop</source>
      <translation variants="no">zh_tw ##Slide down to stop</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Clock alarm</source>
      <translation variants="no">時鐘鬧鈴</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_snooze">
      <source>Snooze</source>
      <translation variants="no">zh_tw ##Snooze</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_silence">
      <source>Silence</source>
      <translation variants="no">zh_tw ##Silence</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Silence</source>
      <translation variants="no">靜音</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Calendar alarm</source>
      <translation variants="no">行事曆鬧鈴</translation>
    </message>
  </context>
</TS>