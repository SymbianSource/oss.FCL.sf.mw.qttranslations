<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mus_other_unknown7">
      <source>Unknown </source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_select_a_song">
      <source>Select a song</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择歌曲：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown1">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown5">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_info_no_music">
      <source>(No music)</source>
      <translation variants="no">(无音乐)</translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_share">
      <source>Share</source>
      <translation variants="no">共享</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_complete">
      <source>Refresh complete</source>
      <translation variants="no">刷新完毕</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">爵士音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_out_of_disk_space">
      <source>Out of disk space.</source>
      <translation variants="no">已取消刷新。存储不足。</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_electronic">
      <source>Electronic</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_quick_access_to_your_music">
      <source>Quick access to your music</source>
      <translation variants="yes">
        <lengthvariant priority="1">快速访问您的音乐</lengthvariant>
        <lengthvariant priority="2">zh #Quick access to music</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_info_ln_songs_found">
      <source>%Ln songs found</source>
      <translation>
        <numerusform plurality="a">找到%Ln首歌曲</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_removing_songs">
      <source>Removing songs…</source>
      <translation variants="no">正在删除歌曲</translation>
    </message>
    <message numerus="no" id="txt_mus_info_adding_songs">
      <source>Adding songs...</source>
      <translation variants="no">正在添加歌曲</translation>
    </message>
    <message numerus="no" id="txt_mus_info_music_may_need_to_be_refreshed">
      <source>Music may need to be refreshed due to recent USB sync. Refresh now?</source>
      <translation variants="no">由于最近执行了USB同步，所以可能需要刷新音乐。立即刷新？</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_mb">
      <source>%Ln MB</source>
      <translation>
        <numerusform plurality="a">%Ln MB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">摇滚音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown8">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_licences">
      <source>Licences</source>
      <translation variants="yes">
        <lengthvariant priority="1">许可证</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_metal">
      <source>Metal</source>
      <translation variants="yes">
        <lengthvariant priority="1">金属音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_refreshingnln_songs_added">
      <source>Refreshing…</source>
      <translation variants="yes">
        <lengthvariant priority="1">正在刷新</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_music_player">
      <source>Music player</source>
      <translation variants="yes">
        <lengthvariant priority="1">音乐播放器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_file_name">
      <source>File name</source>
      <translation variants="yes">
        <lengthvariant priority="1">文件名</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_song_number">
      <source>Song number</source>
      <translation variants="yes">
        <lengthvariant priority="1">歌曲编号</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_latin">
      <source>Latin</source>
      <translation variants="yes">
        <lengthvariant priority="1">拉丁</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_arrange">
      <source>Arrange</source>
      <translation variants="yes">
        <lengthvariant priority="1">排列</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_remove_songs">
      <source>Remove songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除歌曲：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_cancelled">
      <source>Refresh cancelled</source>
      <translation variants="no">已取消刷新</translation>
    </message>
    <message numerus="no" id="txt_mus_info_deleting">
      <source>Deleting..</source>
      <translation variants="no">正在删除</translation>
    </message>
    <message numerus="no" id="txt_mus_info_please_note_that_using_media_transfer">
      <source>Please note that using Media Transfer mode to transfer your music will optimize your music experience. To learn more, please go to %1. Remind me later?</source>
      <translation variants="no">注意，使用多媒体传送模式传送音乐可以优化音乐体验。更多详情，请转至%[99]1。以后再提醒我？</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_rap">
      <source>Rap</source>
      <translation variants="yes">
        <lengthvariant priority="1">说唱音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_usb_conn_in_progress">
      <source>USB connection in progress</source>
      <translation variants="no">正在进行USB连接</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_send_via_bluetooth">
      <source>Send via Bluetooth</source>
      <translation variants="no">经蓝牙发送</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_soundtrack">
      <source>Soundtrack</source>
      <translation variants="yes">
        <lengthvariant priority="1">原声碟</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_folk">
      <source>Folk</source>
      <translation variants="yes">
        <lengthvariant priority="1">民谣</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_dance">
      <source>Dance</source>
      <translation variants="yes">
        <lengthvariant priority="1">舞曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_an_error_occurred">
      <source>An error occurred. Sharing is not currently available.</source>
      <translation variants="no">发生错误。共享目前不可用。</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_kb">
      <source>%Ln kB</source>
      <translation>
        <numerusform plurality="a">%Ln kB</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_bitrate_val_ln_kbps">
      <source>%Ln Kbps</source>
      <translation>
        <numerusform plurality="a">%Ln kbps</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_web_site">
      <source>Web site</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_alternative">
      <source>Alternative</source>
      <translation variants="yes">
        <lengthvariant priority="1">另类音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_hiphop">
      <source>Hip-Hop</source>
      <translation variants="yes">
        <lengthvariant priority="1">嘻哈音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_rb">
      <source>R&amp;B</source>
      <translation variants="yes">
        <lengthvariant priority="1">节奏蓝调</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_year">
      <source>Year</source>
      <translation variants="yes">
        <lengthvariant priority="1">年份</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_bitrate">
      <source>Bitrate</source>
      <translation variants="yes">
        <lengthvariant priority="1">比特率</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_world">
      <source>World</source>
      <translation variants="yes">
        <lengthvariant priority="1">世界音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown10">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre">
      <source>Genre</source>
      <translation variants="yes">
        <lengthvariant priority="1">流派</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_format">
      <source>Format</source>
      <translation variants="yes">
        <lengthvariant priority="1">格式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_file_is_corrupt">
      <source>File is corrupt. Operation cancelled.</source>
      <translation variants="no">文件损坏。已取消操作。</translation>
    </message>
    <message numerus="no" id="txt_mus_info_unable_to_play_selection">
      <source>Unable to play selection. Operation cancelled.</source>
      <translation variants="no">无法播放所选歌曲。已取消操作。</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_duration">
      <source>Duration</source>
      <translation variants="yes">
        <lengthvariant priority="1">时长</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_there_are_no_recommendations">
      <source>There are no recommendations for this track</source>
      <translation variants="no">此乐曲无推荐信息</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_sampling_rate_val_ln_hz">
      <source>%Ln hz</source>
      <translation>
        <numerusform plurality="a">%Ln赫兹</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_gb">
      <source>%Ln GB</source>
      <translation>
        <numerusform plurality="a">%Ln GB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_spoken">
      <source>Spoken</source>
      <translation variants="yes">
        <lengthvariant priority="1">演说音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_modified">
      <source>Modified</source>
      <translation variants="yes">
        <lengthvariant priority="1">修改日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">古典音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_easy_listening">
      <source>Easy Listening</source>
      <translation variants="yes">
        <lengthvariant priority="1">轻音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_licences_val_click_for_details">
      <source>Click for details</source>
      <translation variants="yes">
        <lengthvariant priority="1">单击查看详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown_1">
      <source>Unknown - %1</source>
      <translation variants="no">未知：%1</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_audio_effects">
      <source>Audio effects</source>
      <translation variants="yes">
        <lengthvariant priority="1">音频效果</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_mark_all">
      <source>Mark all</source>
      <translation variants="no">标记全部</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_acoustic">
      <source>Acoustic</source>
      <translation variants="yes">
        <lengthvariant priority="1">原声音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_new_age">
      <source>New Age</source>
      <translation variants="yes">
        <lengthvariant priority="1">新世纪音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown4">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_equalizer">
      <source>Equalizer</source>
      <translation variants="no">均衡器</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown_all">
      <source>Unknown - All</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知 - 全部</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">爵士音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_refresh_library">
      <source>Refresh library</source>
      <translation variants="no">刷新库</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_composer">
      <source>Composer</source>
      <translation variants="yes">
        <lengthvariant priority="1">作曲家</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近增加的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_all_songs">
      <source>All songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">全部歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_audio_effects">
      <source>Audio effects</source>
      <translation variants="no">音频效果</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">最常播放的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">增加至播放列表</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown2">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_title_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_new_playlist">
      <source>New playlist</source>
      <translation variants="no">新建播放列表</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name_entry_playlist_l1">
      <source>Playlist %L1</source>
      <translation variants="no">播放列表%L1</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown5">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">摇滚音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_on">
      <source>Repeat on</source>
      <translation variants="no">打开重复</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown4">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_blues">
      <source>Blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">蓝调</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_copyright">
      <source>Copyright</source>
      <translation variants="yes">
        <lengthvariant priority="1">版权</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_sampling_rate">
      <source>Sampling rate</source>
      <translation variants="yes">
        <lengthvariant priority="1">采样率</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown3">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_list_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">古典音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_shuffle">
      <source>Shuffle</source>
      <translation variants="no">随机</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_inspire_me">
      <source>Inspire me</source>
      <translation variants="yes">
        <lengthvariant priority="1">启示</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_songs">
      <source>Select songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择歌曲：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_music">
      <source>Music</source>
      <translation variants="no">音乐</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_1_all">
      <source>%1 - All</source>
      <translation variants="no">%[27]1 - 全部</translation>
    </message>
    <message numerus="no" id="txt_mus_menu_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">增加至播放列表</translation>
    </message>
    <message numerus="no" id="txt_mus_list_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">流行音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown3">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_off">
      <source>Repeat off</source>
      <translation variants="no">关闭重复</translation>
    </message>
    <message numerus="yes" id="txt_mus_subhead_ln_songs">
      <source>%Ln songs</source>
      <translation>
        <numerusform plurality="a">%Ln首歌曲</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_on">
      <source>On</source>
      <translation variants="no">开</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近增加的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">全部取消标记</translation>
    </message>
    <message numerus="no" id="txt_mus_list_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">最常播放的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_menu_view_details">
      <source>View details</source>
      <translation variants="no">查看详情</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_playlist">
      <source>Delete playlist?</source>
      <translation variants="no">删除播放列表？</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name">
      <source>Enter name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">名称：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_song">
      <source>Delete song?</source>
      <translation variants="no">删除歌曲？</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_album">
      <source>Delete album?</source>
      <translation variants="no">删除专辑？</translation>
    </message>
    <message numerus="no" id="txt_mus_list_ovi_music">
      <source>Ovi music store</source>
      <translation variants="yes">
        <lengthvariant priority="1">音乐商店</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_button_new">
      <source>New</source>
      <translation variants="yes">
        <lengthvariant priority="1">新建</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_balance">
      <source>Balance</source>
      <translation variants="no">平衡</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_preset">
      <source>Select preset:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择预设：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown6">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">流行音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">其他</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_refresh_cancelled">
      <source>Refresh cancelled</source>
      <translation variants="yes">
        <lengthvariant priority="1">已取消刷新</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_music">
      <source>Music</source>
      <translation variants="no">音乐</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_b">
      <source>%Ln B</source>
      <translation>
        <numerusform plurality="a">%Ln B</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_size">
      <source>Size</source>
      <translation variants="yes">
        <lengthvariant priority="1">大小</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_country">
      <source>Country</source>
      <translation variants="yes">
        <lengthvariant priority="1">乡村音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown9">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_reggae">
      <source>Reggae</source>
      <translation variants="yes">
        <lengthvariant priority="1">雷鬼音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_song_details">
      <source>Song details </source>
      <translation variants="yes">
        <lengthvariant priority="1">歌曲详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_playlist">
      <source>Select playlist:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择播放列表</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness">
      <source>Loudness</source>
      <translation variants="no">响度</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_shuffle">
      <source>Shuffle</source>
      <translation variants="yes">
        <lengthvariant priority="1">随机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_off">
      <source>Off</source>
      <translation variants="no">关</translation>
    </message>
    <message numerus="no" id="txt_mus_list_bass_booster">
      <source>Bass booster</source>
      <translation variants="yes">
        <lengthvariant priority="1">超重低音</lengthvariant>
      </translation>
    </message>
  </context>
</TS>