<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_language_en">
      <source>English</source>
      <translation variants="no">vi #English</translation>
    </message>
    <message numerus="no" id="txt_language_tl">
      <source>Pilipino</source>
      <translation variants="no">vi #Pilipino</translation>
    </message>
    <message numerus="no" id="txt_language_fr">
      <source>Français</source>
      <translation variants="no">vi #Français</translation>
    </message>
    <message numerus="no" id="txt_language_de">
      <source>Deutsch</source>
      <translation variants="no">vi #Deutsch</translation>
    </message>
    <message numerus="no" id="txt_language_es">
      <source>Español</source>
      <translation variants="no">vi #Español</translation>
    </message>
    <message numerus="no" id="txt_language_it">
      <source>Italiano</source>
      <translation variants="no">vi #Italiano</translation>
    </message>
    <message numerus="no" id="txt_language_sv">
      <source>Svenska</source>
      <translation variants="no">vi #Svenska</translation>
    </message>
    <message numerus="no" id="txt_language_da">
      <source>Dansk</source>
      <translation variants="no">vi #Dansk</translation>
    </message>
    <message numerus="no" id="txt_language_no">
      <source>Norsk</source>
      <translation variants="no">vi #Norsk</translation>
    </message>
    <message numerus="no" id="txt_language_fi">
      <source>Suomi</source>
      <translation variants="no">vi #Suomi</translation>
    </message>
    <message numerus="no" id="txt_language_en_US">
      <source>English</source>
      <translation variants="no">vi #English</translation>
    </message>
    <message numerus="no" id="txt_language_pt">
      <source>Português</source>
      <translation variants="no">vi #Português</translation>
    </message>
    <message numerus="no" id="txt_language_tr">
      <source>Türkçe</source>
      <translation variants="no">vi #Türkçe</translation>
    </message>
    <message numerus="no" id="txt_language_is">
      <source>Íslenska</source>
      <translation variants="no">vi #Íslenska</translation>
    </message>
    <message numerus="no" id="txt_language_ru">
      <source>Русский</source>
      <translation variants="no">vi #Русский</translation>
    </message>
    <message numerus="no" id="txt_language_hu">
      <source>Magyar</source>
      <translation variants="no">vi #Magyar</translation>
    </message>
    <message numerus="no" id="txt_language_nl">
      <source>Nederlands</source>
      <translation variants="no">vi #Nederlands</translation>
    </message>
    <message numerus="no" id="txt_language_cs">
      <source>Čeština</source>
      <translation variants="no">vi #Čeština</translation>
    </message>
    <message numerus="no" id="txt_language_sk">
      <source>Slovenčina</source>
      <translation variants="no">vi #Slovenčina</translation>
    </message>
    <message numerus="no" id="txt_language_pl">
      <source>Polski</source>
      <translation variants="no">vi #Polski</translation>
    </message>
    <message numerus="no" id="txt_language_sl">
      <source>Slovenščina</source>
      <translation variants="no">vi #Slovenščina</translation>
    </message>
    <message numerus="no" id="txt_language_zh_TW">
      <source>繁體中文(台灣)</source>
      <translation variants="no">vi #繁體中文(台灣)</translation>
    </message>
    <message numerus="no" id="txt_language_zh_HK">
      <source>繁體中文(香港)</source>
      <translation variants="no">vi #繁體中文(香港)</translation>
    </message>
    <message numerus="no" id="txt_language_zh">
      <source>简体中文</source>
      <translation variants="no">vi #简体中文</translation>
    </message>
    <message numerus="no" id="txt_language_ja">
      <source>日本語</source>
      <translation variants="no">vi #日本語</translation>
    </message>
    <message numerus="no" id="txt_language_th">
      <source>ภาษาไทย</source>
      <translation variants="no">vi #ภาษาไทย</translation>
    </message>
    <message numerus="no" id="txt_language_ar">
      <source>العربية</source>
      <translation variants="no">vi #العربية</translation>
    </message>
    <message numerus="no" id="txt_language_bg">
      <source>Български</source>
      <translation variants="no">vi #Български</translation>
    </message>
    <message numerus="no" id="txt_language_ca">
      <source>Català</source>
      <translation variants="no">vi #Català</translation>
    </message>
    <message numerus="no" id="txt_language_hr">
      <source>Hrvatski</source>
      <translation variants="no">vi #Hrvatski</translation>
    </message>
    <message numerus="no" id="txt_language_et">
      <source>Eesti</source>
      <translation variants="no">vi #Eesti</translation>
    </message>
    <message numerus="no" id="txt_language_fa">
      <source>فارسى</source>
      <translation variants="no">vi #فارسى</translation>
    </message>
    <message numerus="no" id="txt_language_fr_CA">
      <source>Français</source>
      <translation variants="no">vi #Français</translation>
    </message>
    <message numerus="no" id="txt_language_el">
      <source>Ελληνικά</source>
      <translation variants="no">vi #Ελληνικά</translation>
    </message>
    <message numerus="no" id="txt_language_he">
      <source>עברית</source>
      <translation variants="no">vi #עברית</translation>
    </message>
    <message numerus="no" id="txt_language_hi">
      <source>हिन्दी</source>
      <translation variants="no">vi #हिन्दी</translation>
    </message>
    <message numerus="no" id="txt_language_id">
      <source>Indonesia</source>
      <translation variants="no">vi #Indonesia</translation>
    </message>
    <message numerus="no" id="txt_language_ko">
      <source>한국어</source>
      <translation variants="no">vi #한국어</translation>
    </message>
    <message numerus="no" id="txt_language_lv">
      <source>Latviešu</source>
      <translation variants="no">vi #Latviešu</translation>
    </message>
    <message numerus="no" id="txt_language_lt">
      <source>Lietuvių</source>
      <translation variants="no">vi #Lietuvių</translation>
    </message>
    <message numerus="no" id="txt_language_ms">
      <source>Melayu</source>
      <translation variants="no">vi #Melayu</translation>
    </message>
    <message numerus="no" id="txt_language_mr">
      <source>मराठी</source>
      <translation variants="no">vi #मराठी</translation>
    </message>
    <message numerus="no" id="txt_language_pt_BR">
      <source>Português</source>
      <translation variants="no">vi #Português</translation>
    </message>
    <message numerus="no" id="txt_language_ro">
      <source>Română</source>
      <translation variants="no">vi #Română</translation>
    </message>
    <message numerus="no" id="txt_language_sr">
      <source>Srpski</source>
      <translation variants="no">vi #Srpski</translation>
    </message>
    <message numerus="no" id="txt_language_es_419">
      <source>Español</source>
      <translation variants="no">vi #Español</translation>
    </message>
    <message numerus="no" id="txt_language_uk">
      <source>Українська</source>
      <translation variants="no">vi #Українська</translation>
    </message>
    <message numerus="no" id="txt_language_ur">
      <source>اردو</source>
      <translation variants="no">vi #اردو</translation>
    </message>
    <message numerus="no" id="txt_language_vi">
      <source>Tiếng Việt</source>
      <translation variants="no">vi #Tiếng Việt</translation>
    </message>
    <message numerus="no" id="txt_language_eu">
      <source>Euskara</source>
      <translation variants="no">vi #Euskara</translation>
    </message>
    <message numerus="no" id="txt_language_gl">
      <source>Galego</source>
      <translation variants="no">vi #Galego</translation>
    </message>
  </context>
</TS>