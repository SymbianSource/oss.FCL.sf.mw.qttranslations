<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_user_guide_dialog_search_device">
      <source>Enter search word</source>
      <translation variants="no">尋找裝置</translation>
    </message>
    <message numerus="no" id="txt_short_caption_userguide">
      <source>User guide</source>
      <translation variants="no">zh_hk #User guide</translation>
    </message>
    <message numerus="no" id="txt_user_guide_title_user_guide">
      <source>User guide</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶指南</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_collapse_all">
      <source>Collapse all</source>
      <translation variants="no">摺疊全部</translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_clear">
      <source>Clear</source>
      <translation variants="no">清除</translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_no_match_found_2">
      <source>No Matches</source>
      <translation variants="no">(沒有相符項目)</translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_no_match_found_1">
      <source>No Matches</source>
      <translation variants="no">(沒有相符項目)</translation>
    </message>
    <message numerus="no" id="txt_long_caption_userguide">
      <source>User guide</source>
      <translation variants="no">用戶指南</translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_applications">
      <source>Applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">應用程式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_expand_all">
      <source>Expand all</source>
      <translation variants="no">展開全部</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_user_guide">
      <source>User guide</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶指南</lengthvariant>
      </translation>
    </message>
  </context>
</TS>