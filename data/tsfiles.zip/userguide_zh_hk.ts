<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_user_guide_opt_stop">
      <source>Stop</source>
      <translation variants="no">停止</translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_clear">
      <source>Clear</source>
      <translation variants="no">清除</translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_expand_all">
      <source>Expand all</source>
      <translation variants="no">展開全部</translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_applications">
      <source>Applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">應用程式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_user_guide">
      <source>User guide</source>
      <translation variants="yes">
        <lengthvariant priority="1">說明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_title_user_guide">
      <source>User guide</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶指南</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_setlabel_search">
      <source>Search</source>
      <translation variants="yes">
        <lengthvariant priority="1">尋找</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_setlabel_search_results">
      <source>Search results</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜尋結果</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_button_link_to_nokiacomsupport">
      <source>Link to nokia.com/support</source>
      <translation variants="yes">
        <lengthvariant priority="1">連結至nokia.com/support</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_setlabel_searching">
      <source>Searching</source>
      <translation variants="yes">
        <lengthvariant priority="1">尋找中</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_button_all">
      <source>All</source>
      <translation variants="yes">
        <lengthvariant priority="1">全部</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_user_guide">
      <source>User guide</source>
      <translation variants="no">zh_hk ##User guide</translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_no_match_found">
      <source>No Match found</source>
      <translation variants="no">zh_hk ##No Match found</translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_collapse_all">
      <source>Collapse all</source>
      <translation variants="no">摺疊全部</translation>
    </message>
    <message numerus="no" id="txt_short_caption_userguide">
      <source>User guide</source>
      <translation variants="no">zh_hk ##User guide</translation>
    </message>
    <message numerus="no" id="txt_user_guide_dialog_search_device">
      <source>Search device</source>
      <translation variants="no">尋找裝置</translation>
    </message>
  </context>
</TS>