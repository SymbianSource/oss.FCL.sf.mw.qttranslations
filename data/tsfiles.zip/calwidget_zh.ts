<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_l1_events">
      <source>L%1 events overlapping</source>
      <translation variants="no">%Ln个重叠项</translation>
    </message>
    <message numerus="no" id="txt_short_caption_calendar_widget">
      <source>Calendar widget</source>
      <translation variants="no">zh #Calendar</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar_widget">
      <source>Calendar widget</source>
      <translation variants="no">日历</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_no_events_ox">
      <source>No events in next 7 days</source>
      <translation variants="no">随后7天无日历项</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_no_events_tod">
      <source>No events today</source>
      <translation variants="no">今天无日历项</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_applib">
      <source>Shows calendar events</source>
      <translation variants="yes">
        <lengthvariant priority="1">在主屏幕上查看日历项</lengthvariant>
        <lengthvariant priority="2">zh #See calendar entries</lengthvariant>
      </translation>
    </message>
  </context>
</TS>