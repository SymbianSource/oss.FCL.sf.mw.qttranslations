<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_power_saving_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Вимкнено</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_join_wlan_networks">
      <source>Join WLAN networks</source>
      <translation variants="no">Переключатися на WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_scan_for_networks_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Автоматично</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_join_wlan_networks_val_manual">
      <source>Manual</source>
      <translation variants="no">Вручну</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_power_saving">
      <source>Power saving</source>
      <translation variants="no">Збереження енергії</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_scan_for_networks">
      <source>Scan for networks</source>
      <translation variants="no">Пошук мереж</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_scan_interval_minutes">
      <source>Scan interval (minutes)</source>
      <translation variants="no">Інтервал пошуку (хвилини)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_join_wlan_networks_val_known">
      <source>Known</source>
      <translation variants="no">Відомі</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_power_saving_val_enabled">
      <source>Enabled</source>
      <translation variants="no">Увімкнено</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_wlan_settings">
      <source>WLAN settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки WLAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_scan_for_networks_val_userdefine">
      <source>User-defined interval</source>
      <translation variants="no">Інтервал, визн. корист.</translation>
    </message>
  </context>
</TS>