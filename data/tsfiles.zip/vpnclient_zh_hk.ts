<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_ap">
      <source>Policy installation failed. Unable to create VPN access point.</source>
      <translation variants="no">規則安裝失敗。無法建立VPN接入點。</translation>
    </message>
    <message numerus="no" id="txt_occ_button_download">
      <source>Download</source>
      <translation variants="no">下載</translation>
    </message>
    <message numerus="no" id="txt_occ_incorrect_password">
      <source>Incorrect password</source>
      <translation variants="no">密碼不正確。</translation>
    </message>
    <message numerus="no" id="txt_vpn_button_disconnect_vpn">
      <source>Disconnect VPN</source>
      <translation variants="no">中斷VPN連接</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_delete_vp">
      <source>Policy installation failed. Delete VPN policies from settings and try again.</source>
      <translation variants="no">規則安裝失敗。請先刪除一個規則然後再重試。</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_cert">
      <source>Policy installation failed. Unable to store certificates.</source>
      <translation variants="no">規則安裝失敗。無法儲存證書。</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn_val_when_needed">
      <source>When needed</source>
      <translation variants="no">當需要時</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_policy_fi">
      <source>Policy installation failed. Policy file error.</source>
      <translation variants="no">規則安裝失敗。規則檔錯誤。</translation>
    </message>
    <message numerus="no" id="txt_occ_info_delete_vpn_policy">
      <source>Delete VPN policy '%1'?</source>
      <translation variants="no">是否刪除VPN規則？
%1</translation>
    </message>
    <message numerus="no" id="txt_occ_list_no_vpn_policies_installed">
      <source>No VPN policies installed.</source>
      <translation variants="no">尚未安裝VPN規則</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_installing_vpn_policy">
      <source>Installing VPN policy</source>
      <translation variants="no">正在安裝VPN規則</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_password">
      <source>Password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn_val_always">
      <source>Always</source>
      <translation variants="no">長期啟動</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed">
      <source>Policy installation failed</source>
      <translation variants="no">規則安裝失敗</translation>
    </message>
    <message numerus="no" id="txt_occ_list_tap_on_a_policy_to_set_a_default">
      <source>Tap on a policy to set a default.</source>
      <translation variants="no">點擊某個規則以將其設定為預設規則：</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_vpn">
      <source>VPN</source>
      <translation variants="yes">
        <lengthvariant priority="1">VPN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_downloading_vpn_policy">
      <source>Downloading VPN policy</source>
      <translation variants="no">正在下載VPN規則</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_vpn_user_name">
      <source>VPN user name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">VPN用戶名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_policy_server_address">
      <source>Policy server address</source>
      <translation variants="no">規則伺服器位址：</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_vpn_policy_download">
      <source>VPN policy download</source>
      <translation variants="yes">
        <lengthvariant priority="1">VPN規則下載</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_vpn_connection">
      <source>VPN connection</source>
      <translation variants="no">VPN連接</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_download_failed">
      <source>Download failed</source>
      <translation variants="no">下載失敗。</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn">
      <source>VPN</source>
      <translation variants="no">VPN</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_securid_pin">
      <source>SecurID PIN:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #SecurID PIN:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_pkcs12_password">
      <source>PKCS#12 password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">PKCS#12密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_service_not_available">
      <source>Policy server not available</source>
      <translation variants="no">無法使用規則伺服器。</translation>
    </message>
    <message numerus="no" id="txt_vpn_dblist_vpn_val_show_vpn_status">
      <source>Show VPN status</source>
      <translation variants="yes">
        <lengthvariant priority="1">在首頁畫面上顯示VPN狀態</lengthvariant>
        <lengthvariant priority="2">zh_hk #Show VPN status</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_install_policy_1_installing_wil">
      <source>Install policy '%1'? Installing will force device lock.</source>
      <translation variants="no">zh_hk #Install policy '%[99]1'? Use of device lock will then be required.</translation>
    </message>
    <message numerus="no" id="txt_long_caption_vpn">
      <source>VPN</source>
      <translation variants="no">VPN</translation>
    </message>
  </context>
</TS>