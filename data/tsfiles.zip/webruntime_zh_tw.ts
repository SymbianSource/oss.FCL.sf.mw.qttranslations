<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_wrt_info_media">
      <source>Media</source>
      <translation variants="no">zh_tw #Media</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_signature_invalid">
      <source>Signature invalid</source>
      <translation variants="no">zh_tw #Signature invalid</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_uninstall">
      <source>Uninstall</source>
      <translation variants="no">zh_tw #Uninstall</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_videoplayer">
      <source>VideoPlayer</source>
      <translation variants="no">zh_tw #VideoPlayer</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_messaging">
      <source>Messaging</source>
      <translation variants="no">zh_tw #Messaging</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_widget_uninstall">
      <source>Widget uninstall</source>
      <translation variants="no">zh_tw #Widget uninstall</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_install_failure">
      <source>Install Failure</source>
      <translation variants="no">zh_tw #Install Failure</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_widget_successfully_installed">
      <source>Widget successfully installed</source>
      <translation variants="no">zh_tw #Widget successfully installed</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_audioplayer">
      <source>AudioPlayer</source>
      <translation variants="no">zh_tw #AudioPlayer</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_widget_install_error">
      <source>Widget install error</source>
      <translation variants="no">zh_tw #Widget install error</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_sensor">
      <source>Sensor</source>
      <translation variants="no">zh_tw #Sensor</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_to_access">
      <source>to access:</source>
      <translation variants="no">zh_tw #to access:</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_telephony">
      <source>Telephony</source>
      <translation variants="no">zh_tw #Telephony</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_sysinfo">
      <source>Sysinfo</source>
      <translation variants="no">zh_tw #Sysinfo</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_calendar">
      <source>Calendar</source>
      <translation variants="no">zh_tw #Calendar</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_uninstall_successful">
      <source>Uninstall Successful</source>
      <translation variants="no">zh_tw #Uninstall Successful</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_uninstall_failed">
      <source>Uninstall Failed</source>
      <translation variants="no">zh_tw #Uninstall Failed</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_camera">
      <source>Camera</source>
      <translation variants="no">zh_tw #Camera</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_install_cancelation">
      <source>Install Cancelation</source>
      <translation variants="no">zh_tw #Install Cancelation</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_installation_failed">
      <source>Installation failed</source>
      <translation variants="no">zh_tw #Installation failed</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_landmark">
      <source>Landmark</source>
      <translation variants="no">zh_tw #Landmark</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_uninstall_error">
      <source>Uninstall Error</source>
      <translation variants="no">zh_tw #Uninstall Error</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_do_you_want_to_remove_1">
      <source>Do you want to remove %1?</source>
      <translation variants="no">zh_tw #Do you want to remove %1?</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_contact">
      <source>Contact</source>
      <translation variants="no">zh_tw #Contact</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_communication_logs">
      <source>Communication Logs</source>
      <translation variants="no">zh_tw #Communication Logs</translation>
    </message>
    <message numerus="no" id="txt_wrt_button_allow">
      <source>Allow</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Allow</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_wrt_info_do_you_want_to_install_1">
      <source>Do you want to install %1?</source>
      <translation variants="no">zh_tw #Do you want to install %1?</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_filesystem">
      <source>Filesystem</source>
      <translation variants="no">zh_tw #Filesystem</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_unknown_error">
      <source>Unknown error</source>
      <translation variants="no">zh_tw #Unknown error</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_do_you_still_want_to_install">
      <source>Do you still want to install?</source>
      <translation variants="no">zh_tw #Do you still want to install?</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_replace_existing_widget">
      <source>Replace existing widget?</source>
      <translation variants="no">zh_tw #Replace existing widget?</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_security_warning">
      <source>Security Warning</source>
      <translation variants="no">zh_tw #Security Warning</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_location">
      <source>Location</source>
      <translation variants="no">zh_tw #Location</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_installation_cancelled">
      <source>Installation cancelled</source>
      <translation variants="no">zh_tw #Installation cancelled</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_widget_install">
      <source>Widget install</source>
      <translation variants="no">zh_tw #Widget install</translation>
    </message>
    <message numerus="no" id="txt_widgetmanager_info_do_you_want_to_install_thi">
      <source>Do you want to install %1? This application is from an un-trusted source and can be harmful</source>
      <translation variants="no">zh_tw #Do you want to install %1? This application is from an un-trusted source and can be harmful</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_allow">
      <source>Allow</source>
      <translation variants="no">zh_tw #Allow</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_install_error">
      <source>Install Error</source>
      <translation variants="no">zh_tw #Install Error</translation>
    </message>
  </context>
</TS>