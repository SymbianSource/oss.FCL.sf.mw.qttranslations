<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_widget_l_dblist_preview_of_recent_mail">
      <source>Preview of recent mail</source>
      <translation variants="no">uk #Preview of recent mail</translation>
    </message>
    <message numerus="no" id="txt_mail_widget_dblist_preview_of_recent_mail">
      <source>Preview of recent mail</source>
      <translation variants="no">uk #Preview of recent mail</translation>
    </message>
  </context>
</TS>