<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_mail_authentication">
      <source>Outgoing mail authentication</source>
      <translation variants="no">برآمدی میل کی تصدیق</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_reply_to_address">
      <source>Reply to address</source>
      <translation variants="no">جواب کا پتہ:</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_mail_server">
      <source>Incoming mail server</source>
      <translation variants="no">آنے والی میل کا سرور</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_my_name">
      <source>My name</source>
      <translation variants="no">میرا نام:</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_preferences">
      <source>Preferences</source>
      <translation variants="no">ترجیحات</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_day_end_time">
      <source>Day end time</source>
      <translation variants="no">دن کے خاتمے کا وقت:</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_every_day">
      <source>Every day</source>
      <translation variants="no">ہر دن</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_tue">
      <source>Tue</source>
      <translation variants="no">منگل</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_1_hour">
      <source>Every 1 hour</source>
      <translation variants="no">ہر گھنٹے</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_mail_server">
      <source>Outgoing mail server</source>
      <translation variants="no">جانے والی میل کا سرور</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_save_energy">
      <source>Save energy</source>
      <translation variants="no">توانائی کی بچت</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_as_defin">
      <source>The mailbox is refreshed as defined by the user</source>
      <translation variants="no">صارف کی وضاحت کے مطابق میل باکس مشمولات کی تازہ کاری ہوتی ہے</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_sat">
      <source>Sat</source>
      <translation variants="no">سنیچر</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_wed">
      <source>Wed</source>
      <translation variants="no">بدھ</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_sun">
      <source>Sun</source>
      <translation variants="no">اتوار</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_show_mail_in_other_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">فولڈر میں میل دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_username">
      <source>Username</source>
      <translation variants="no">صارف نام:</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_receiving_weekdays">
      <source>Receiving days</source>
      <translation variants="no">بازیافتگی ایام</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">میل باکس کی تازہ کاری</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">میل پتہ:</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_mailbox_name">
      <source>Mailbox name</source>
      <translation variants="no">میل باکس کا نام</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_connection">
      <source>Connection</source>
      <translation variants="no">اتصال</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_mon">
      <source>Mon</source>
      <translation variants="no">پیر</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_receiving_schedule">
      <source>Receiving Schedule</source>
      <translation variants="no">بازیافتگی کا نظام اوقات</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_thu">
      <source>Thu</source>
      <translation variants="no">جمعرات</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_server_info">
      <source>Server info</source>
      <translation variants="no">سرور کی تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_when_i_open_mailbox">
      <source>When I open mailbox</source>
      <translation variants="no">جب میں میل باکس کھولوں</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_every_15">
      <source>The mailbox is refreshed every 15 minutes during daytime</source>
      <translation variants="no">دن کے دوران ہر ۱۵ منٹ پر میل باکس مشمولات کی تازہ کاری ہوتی ہے</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_user_define">
      <source>User defined</source>
      <translation variants="no">صارف کا وضاحت کردہ</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_fri">
      <source>Fri</source>
      <translation variants="no">جمعہ</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="no">ہر ۴ گھنٹے پر</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_keep_uptodate">
      <source>Keep up-to-date</source>
      <translation variants="no">جدید تر بنائے رکھیں</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_keep_upto">
      <source>Keep up-to-date</source>
      <translation variants="no">مکمل بنائے رکھیں</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_uptodate_during">
      <source>The mailbox is up-to-date during daytime</source>
      <translation variants="no">دن کے دوران میل باکس مشمولات کو جدید تر رکھا جاتا ہے</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_password">
      <source>Password</source>
      <translation variants="no">لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_fetch_manua">
      <source>Fetch manually</source>
      <translation variants="no">میل دستی بازیابی</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_only_by">
      <source>The mailbox is refreshed only by user request</source>
      <translation variants="no">صرف صارف کے شروع کرنے پر میل باکس مشمولات کی تازہ کاری ہوتی ہے</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="no">ہر ۱۵ منٹ پر</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_day_start_time">
      <source>Day start time</source>
      <translation variants="no">دن کے آغاز کا وقت:</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_user_info">
      <source>User info</source>
      <translation variants="no">صارف ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_all">
      <source>All</source>
      <translation variants="no">سب</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_version_l1">
      <source>Version: %[]1</source>
      <translation variants="no">ورژن: %1</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_show_mail_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">ان باکس میں میل دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode">
      <source>Selected mode</source>
      <translation variants="no">تازہ. اختیار استعمال میں</translation>
    </message>
    <message numerus="no" id="txt_mailips_button_delete_mailbox">
      <source>Delete mailbox</source>
      <translation variants="no">میل باکس مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_on_starttls">
      <source>On (StartTLS)</source>
      <translation variants="no">چالو (StartTLS)</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mailips">
      <source>Mail</source>
      <translation variants="no">میل</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port">
      <source>Incoming port</source>
      <translation variants="no">درآمدی پورٹ</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port_default">
      <source>Default</source>
      <translation variants="no">آغازی</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_port">
      <source>Outgoing port</source>
      <translation variants="no">برآمدی پورٹ</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_off">
      <source>Off</source>
      <translation variants="no">بند</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_security">
      <source>Incoming secure connection</source>
      <translation variants="no">درآمدی محفوظ اتصال</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port_user_defined">
      <source>User defined</source>
      <translation variants="no">صارف واضح کردہ</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_on_ssltls">
      <source>On (SLL/TLS)</source>
      <translation variants="no">چالو (SSL/TLS)</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_security">
      <source>Outgoing secure connection</source>
      <translation variants="no">برآمدی محفوظ اتصال</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path_val_default">
      <source>Default</source>
      <translation variants="no">آغازی</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path_user_defined">
      <source>User defined</source>
      <translation variants="no">صارف واضح کردہ</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path">
      <source>Folder path</source>
      <translation variants="no">فولڈر کا طریقہ</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_same">
      <source>Same as for incoming</source>
      <translation variants="no">جیسا درآمدی کے لیے</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_user">
      <source>User authentication</source>
      <translation variants="no">صارف کی تصدیق</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_none">
      <source>None</source>
      <translation variants="no">کوئی نہیں</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">میل باکس کی تازہ کاری کریں</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_connection">
      <source>Connection</source>
      <translation variants="no">اتصال</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_show_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">ان باکس میں میل دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_thursday">
      <source>Thu</source>
      <translation variants="yes">
        <lengthvariant priority="1">جمعرات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_on_ssltls">
      <source>On (SSL/TLS)</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو (SSL/TLS)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہر ۴ گھنٹے پر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہر ۱۵ منٹ پر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_wednesday">
      <source>Wed</source>
      <translation variants="yes">
        <lengthvariant priority="1">بدھ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_all">
      <source>All</source>
      <translation variants="yes">
        <lengthvariant priority="1">تمام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_saturday">
      <source>Sat</source>
      <translation variants="yes">
        <lengthvariant priority="1">سنیچر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_outgoing_authentication">
      <source>Outgoing mail authentication</source>
      <translation variants="no">برآمدی میل کی تصدیق کاری</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_no_authentication">
      <source>No authentication</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_keep_up_to_date">
      <source>Keep up-to-date</source>
      <translation variants="yes">
        <lengthvariant priority="1">تجدید شدہ رکھیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_user_authentication">
      <source>User authentication</source>
      <translation variants="yes">
        <lengthvariant priority="1">صارف کی تصدیق کاری</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_end_time">
      <source>Day end time</source>
      <translation variants="no">دن کے خاتمے کا وقت:</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_outgoing_connection">
      <source>Outgoing secure connection</source>
      <translation variants="no">برآمدی محفوظ اتصال</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_every_hour">
      <source>Every hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہر گھنٹے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_friday">
      <source>Fri</source>
      <translation variants="yes">
        <lengthvariant priority="1">جمعہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_on_starttls">
      <source>On (StartTLS)</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو (StartTLS)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_sunday">
      <source>Sun</source>
      <translation variants="yes">
        <lengthvariant priority="1">اتوار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_tuesday">
      <source>Tue</source>
      <translation variants="yes">
        <lengthvariant priority="1">منگل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_same_as_for_incoming">
      <source>Same as for incoming</source>
      <translation variants="yes">
        <lengthvariant priority="1">جیسا درآمدی کے لیے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_monday">
      <source>Mon</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_show_in_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">دیگر فولڈروں میں میل دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_incoming_connection">
      <source>Incoming secure connection</source>
      <translation variants="no">درآمدی محفوظ اتصال</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_receiving_days">
      <source>Receiving days</source>
      <translation variants="no">ایام بازیافتگی</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_start_time">
      <source>Day start time</source>
      <translation variants="no">دن کے آغاز کا وقت:</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_none">
      <source>None</source>
      <translation variants="no">کوئی نہیں</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_every_hour">
      <source>The mailbox is refreshed every hour during daytime</source>
      <translation variants="no">دن کے دوران میل باکس کے مشمولات کی ہر گھنٹے پر تازہ کاری ہوتی ہے</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_folder_path_val_default">
      <source>Default</source>
      <translation variants="yes">
        <lengthvariant priority="1">آغازی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_folder_path_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">صارف وضاحت کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_folder_path">
      <source>Folder path</source>
      <translation variants="no">فولڈر راستہ</translation>
    </message>
  </context>
</TS>