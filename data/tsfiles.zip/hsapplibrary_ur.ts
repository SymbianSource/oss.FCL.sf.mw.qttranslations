<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_applib_opt_sub_custom">
      <source>Custom</source>
      <translation variants="no">کسٹم آرڈر</translation>
    </message>
    <message numerus="no" id="txt_applib_list_new_collection">
      <source>New collection</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا ذخیرہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_entry_collectionl1">
      <source>Collection(%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">مجموعے %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_title_select_applications">
      <source>Select applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروگرام منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_will_be_removed_from_phone_c">
      <source>%1 will be removed from phone. Continue?</source>
      <translation variants="no">%[89]1 آلے پر سے ہٹ جائے گا۔ جاری رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_uninstalls_1_and_deletes_all_sh">
      <source>%1 and all its shortcuts will be removed from phone. Continue?</source>
      <translation variants="no">%[65]1 اور اس کے تمام شارٹ کٹس آلے سے ہٹ جائیں گے۔ جاری رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_ascending">
      <source>Ascending</source>
      <translation variants="no">نام (بڑھتی ترتیب)</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_latest_on_top">
      <source>Latest on top</source>
      <translation variants="no">نیا سب سے اوپر</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sort_by_sub_latest_on_top">
      <source>Latest on top</source>
      <translation variants="no">نیا سب سے اوپر</translation>
    </message>
    <message numerus="no" id="txt_applib_button_add_to_homescreen">
      <source>Add to Homescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہوم اسکرین میں شامل</lengthvariant>
        <lengthvariant priority="2">ہوم ا. م. شامل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_title_arrange">
      <source>Arrange</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_installation_time">
      <source>Installation time</source>
      <translation variants="no">تنصیب کا وقت</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_arrange">
      <source>Arrange</source>
      <translation variants="no">ترتیب دیں</translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_installed">
      <source>Installed</source>
      <translation variants="yes">
        <lengthvariant priority="1">نصب</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dpopinfo_added_to_collection_1">
      <source>Added to collection %1</source>
      <translation variants="no">ذخیرہ %[99]1 میں شامل کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_view_installed_applications">
      <source>View installed applications</source>
      <translation variants="no">نصب پروگرام دیکھیں</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_add_to_home_screen">
      <source>Add to Home Screen</source>
      <translation variants="no">ہوم اسکرین میں شامل</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_task_switcher">
      <source>Task Switcher</source>
      <translation variants="no">مبدل افعال</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_add_to_collection">
      <source>Add to collection</source>
      <translation variants="no">مجموعے میں شاملکریں</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_add_to_home_screen">
      <source>Add to Home Screen</source>
      <translation variants="no">ہوم اسکرین میں شامل</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_descending">
      <source>Descending</source>
      <translation variants="no">نام (گھٹتی ترتیب)</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_delete_1">
      <source>Delete %1?</source>
      <translation variants="no">ذخیرہ %[99]1 مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_applib_title_collection_name">
      <source>Collection name:</source>
      <translation variants="no">مجموعے کا نام</translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_uninstalling_1">
      <source>Uninstalling %1</source>
      <translation variants="no">%[21]1 کی تنصیب رد ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sort_by">
      <source>Sort by</source>
      <translation variants="no">سے چھانٹیں</translation>
    </message>
    <message numerus="no" id="txt_applib_title_add_to">
      <source>Add to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">مجموعے میں شامل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_removed">
      <source>Removed</source>
      <translation variants="no">ہٹایا گیا</translation>
    </message>
    <message numerus="no" id="txt_applib_title_installation_logs">
      <source>Installation logs</source>
      <translation variants="yes">
        <lengthvariant priority="1">تنصیب کاری لاگز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sort_by_sub_oldest_on_top">
      <source>Oldest on top</source>
      <translation variants="no">پرانا سب سے اوپر</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_send_to_friend">
      <source>Send to friend</source>
      <translation variants="no">ویب پتہ بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_remove_1_from_collection">
      <source>Remove %1 from collection?</source>
      <translation variants="no">ذخیرے سے %[99]1 ہٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_applib_dpophead_added_to_homescreen">
      <source>Added to Homescreen</source>
      <translation variants="no">ہوم اسکرین میں شامل کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_format">
      <source>Format:</source>
      <translation variants="no">فارمیٹ:</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_installed">
      <source>Installed</source>
      <translation variants="no">نصب شدہ</translation>
    </message>
    <message numerus="no" id="txt_applib_formlabel_no_search_results">
      <source>No search results</source>
      <translation variants="no">(کوئی نتیجہ نہیں ملا)</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="no">%1: وسیع حافظہ</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_size">
      <source>Size:</source>
      <translation variants="no">سائز:</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_l1_kb">
      <source>%L1 KB</source>
      <translation variants="no">ur #%L1 KB</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_installation_log">
      <source>Installation log</source>
      <translation variants="no">تنصیب کاری لاگ</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_add_to_collection">
      <source>Add to collection...</source>
      <translation variants="no">مجموعے میں شاملکریں</translation>
    </message>
    <message numerus="no" id="txt_applib_formlabel_empty">
      <source>Empty</source>
      <translation variants="no">(کوئی پروگرام نہیں)</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="no">%1: حافظہ کارڈ</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_version">
      <source>Version:</source>
      <translation variants="no">ورژن:</translation>
    </message>
    <message numerus="no" id="txt_applib_button_add_to_collection">
      <source>Add to Collection</source>
      <translation variants="no">ذخیرے میں شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_deletes_1_also_from_home_screen">
      <source>Deletes %1 also from Home Screen. Continue?</source>
      <translation variants="no">%[79]1 بھی ہوم اسکرین سے مٹ جائے گا۔ جاری رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_description">
      <source>Description:</source>
      <translation variants="no">تفصیل:</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="no">%1: آلے کا حافظہ</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_check_software_updates">
      <source>Check software updates</source>
      <translation variants="no">سافٹویئر تجدید جانچ</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_l1_mb">
      <source>%L1 MB</source>
      <translation variants="no">ur #%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_downloaded_val_empty">
      <source>Empty</source>
      <translation variants="yes">
        <lengthvariant priority="1">(کوئی پروگرام نہیں)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_entry_collection">
      <source>Collection</source>
      <translation variants="yes">
        <lengthvariant priority="1">مجموعہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_oldest_on_top">
      <source>Oldest on top</source>
      <translation variants="no">پرانا سب سے اوپر</translation>
    </message>
    <message numerus="no" id="txt_applib_title_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_add_content">
      <source>Add content</source>
      <translation variants="no">مشمولات شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_file_corrupted_unable_to_use_wi">
      <source>File corrupted, unable to use widget. Delete widget? </source>
      <translation variants="no">آلہ استعمال کرنے سے قاصر۔ فائل خراب ہے۔ آلہ مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_2">
      <source>%1 %2</source>
      <translation variants="no">ur ##%1 %2</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_must_be_closed_before_deletin">
      <source>%1 must be closed before deleting. Close %1? </source>
      <translation variants="no">مٹانے سے پہلے %[39]1 بند کیا جانا چاہیے۔ %[38]1 کو بند کریں؟</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_memory_in_use">
      <source>Memory in use:</source>
      <translation variants="no">حافظہ زیر استعمال:</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_new_collection">
      <source>New collection</source>
      <translation variants="no">نیا مجموعہ</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_resume">
      <source>Resume</source>
      <translation variants="no">ڈاؤن لوڈ بحال کریں</translation>
    </message>
    <message numerus="no" id="txt_applib_title_applications">
      <source>Applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروگرامز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_menu_cancel_installing">
      <source>Cancel installing</source>
      <translation variants="no">تنصیب منسوخ کریں</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_remove_from_collection">
      <source>Remove from collection</source>
      <translation variants="no">مجموعے سے ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_partially_installed">
      <source>Partially installed</source>
      <translation variants="no">جزوی طور پر نصب شدہ</translation>
    </message>
    <message numerus="yes" id="txt_applib_dblist_val_ln_new_applications">
      <source>%Ln new applications</source>
      <translation>
        <numerusform plurality="a">%Ln نیا پروگرام</numerusform>
        <numerusform plurality="b">%Ln نئے پروگرام</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_supplier">
      <source>Supplier:</source>
      <translation variants="no">فراہم کار:</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_name">
      <source>Name:</source>
      <translation variants="no">نام:</translation>
    </message>
  </context>
</TS>