<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_rad_info_clear_recently_played_songs_list">
      <source>Clear Recently played songs list?</source>
      <translation variants="no">是否清除最近播放過的歌曲清單？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_recently_played_songs_collects_song2">
      <source>Recently played songs collects song information from radio stations which send the song information using RDS+ technology.</source>
      <translation variants="no">zh_hk #Recently played songs collects song information from radio stations which send the song information using RDS+ technology.</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_val_l1_mhz">
      <source>%L1 MHz</source>
      <translation variants="no">%L1兆赫</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_all_stations_list">
      <source>Clear All stations list?</source>
      <translation variants="no">是否清除電台清單？將會移除所有電台。</translation>
    </message>
    <message numerus="no" id="txt_fmradio_info_fm_radio_could_not_be_started">
      <source>FM Radio could not be started. </source>
      <translation variants="no">無法開啟收音機</translation>
    </message>
    <message numerus="no" id="txt_rad_list_seeking">
      <source>Seeking</source>
      <translation variants="no">zh_hk #Scanning</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_favourite_stations_list">
      <source>Clear Favourite stations list?</source>
      <translation variants="no">是否從我的最愛移除所有電台？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_you_can_add_song_to_the_tagged_songs">
      <source>You can add song to the tagged songs list from Recently played songs or from main view if song is identified by FM Radio. </source>
      <translation variants="no">zh_hk #Son can be added to favourites from 'Recently played songs' of from main view if song is identified by Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_tagged_songs_list">
      <source>Clear Tagged songs list?</source>
      <translation variants="no">是否從我的最愛移除所有歌曲？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_connect_wired_headset1">
      <source>Connect wired headset.</source>
      <translation variants="no">zh_hk #Connect wired headset</translation>
    </message>
    <message numerus="no" id="txt_rad_dialog_new_name">
      <source>New name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">新名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_opt_play_history">
      <source>Play history</source>
      <translation variants="no">播放記錄</translation>
    </message>
    <message numerus="no" id="txt_rad_info_remove_song_from_tagged_songs">
      <source>Remove song from tagged songs?</source>
      <translation variants="no">是否從我的最愛移除歌曲？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm_hs">
      <source>Alarm</source>
      <translation variants="no">zh_hk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_rad_info_light_classical_hs">
      <source>Light classical</source>
      <translation variants="no">zh_hk #Light classical</translation>
    </message>
    <message numerus="no" id="txt_rad_info_rhythm_and_blues">
      <source>Rhythm and blues</source>
      <translation variants="no">zh_hk #Rhythm and blues</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religious_talk">
      <source>Religious talk</source>
      <translation variants="yes">
        <lengthvariant priority="1">宗教談話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_weather">
      <source>Weather</source>
      <translation variants="yes">
        <lengthvariant priority="1">天氣</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_drama">
      <source>Drama</source>
      <translation variants="yes">
        <lengthvariant priority="1">戲劇</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_varied">
      <source>Varied</source>
      <translation variants="no">zh_hk #Varied</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_music_hs">
      <source>Religious music</source>
      <translation variants="no">zh_hk #Religious music</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religion">
      <source>Religion</source>
      <translation variants="yes">
        <lengthvariant priority="1">宗教</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_talk">
      <source>Talk</source>
      <translation variants="yes">
        <lengthvariant priority="1">談話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_finance">
      <source>Finance</source>
      <translation variants="yes">
        <lengthvariant priority="1">財務金融</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_all_stations_in_stations_list_will_be">
      <source>Stations in station list will be replaced. Favourite stations won't be touched. Continue?</source>
      <translation variants="no">電台清單中的所有預設電台將會被取代。我的最愛將不會更換。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_stations_search_stations_automat">
      <source>Search stations automatically by tapping here.</source>
      <translation variants="no">zh_hk #Scan stations automatically by tapping here</translation>
    </message>
    <message numerus="no" id="txt_rad_info_news_hs">
      <source>News</source>
      <translation variants="no">zh_hk #News</translation>
    </message>
    <message numerus="no" id="txt_rad_info_rock_music_hs">
      <source>Rock Music</source>
      <translation variants="no">zh_hk #Rock music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_oldies_music_hs">
      <source>Oldies Music</source>
      <translation variants="no">zh_hk #Oldies music</translation>
    </message>
    <message numerus="no" id="txt_rad_button_tagged_songs">
      <source>Tagged songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">清除清單</translation>
    </message>
    <message numerus="no" id="txt_rad_info_other_music_hs">
      <source>Other Music</source>
      <translation variants="no">zh_hk #Other music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_finance_hs">
      <source>Finance</source>
      <translation variants="no">zh_hk #Finance</translation>
    </message>
    <message numerus="no" id="txt_rad_info_rock_music">
      <source>Rock Music</source>
      <translation variants="no">zh_hk #Rock music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_news">
      <source>News</source>
      <translation variants="no">zh_hk #News</translation>
    </message>
    <message numerus="no" id="txt_long_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">收音機</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_nostalgia">
      <source>Nostalgia</source>
      <translation variants="yes">
        <lengthvariant priority="1">懷舊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_language">
      <source>Language</source>
      <translation variants="no">zh_hk #Language</translation>
    </message>
    <message numerus="no" id="txt_rad_info_science">
      <source>Science</source>
      <translation variants="no">zh_hk #Science</translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm">
      <source>Alarm</source>
      <translation variants="no">zh_hk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_rad_info_childrens_programmes">
      <source>Children’s programmes</source>
      <translation variants="no">zh_hk #Children's programmes</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_remove_favourite">
      <source>Remove from favourites</source>
      <translation variants="no">從我的最愛移除</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rock_hs">
      <source>Soft rock</source>
      <translation variants="no">zh_hk #Soft rock</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_culture">
      <source>Culture</source>
      <translation variants="yes">
        <lengthvariant priority="1">文化</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rhythm_and_blues_hs">
      <source>Soft rhythm and blues</source>
      <translation variants="no">zh_hk #Soft rhythm and blues</translation>
    </message>
    <message numerus="no" id="txt_rad_list_searching_all_available_stations_ple">
      <source>Searching all available stations. Please wait.</source>
      <translation variants="no">zh_hk #Scanning available stations</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_information">
      <source>Information</source>
      <translation variants="yes">
        <lengthvariant priority="1">資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_country_music_hs">
      <source>Country Music</source>
      <translation variants="no">zh_hk #Country music</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_search_via_shazam">
      <source>Search via Shazam</source>
      <translation variants="no">使用Shazam辨識歌曲</translation>
    </message>
    <message numerus="no" id="txt_rad_info_talk">
      <source>Talk</source>
      <translation variants="no">zh_hk #Talk</translation>
    </message>
    <message numerus="no" id="txt_rad_info_documentary_hs">
      <source>Documentary</source>
      <translation variants="no">zh_hk #Documentary</translation>
    </message>
    <message numerus="no" id="txt_rad_info_social_affairs_hs">
      <source>Social Affairs</source>
      <translation variants="no">zh_hk #Social affairs</translation>
    </message>
    <message numerus="no" id="txt_fmradio_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">zh_hk #Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_public">
      <source>Public</source>
      <translation variants="yes">
        <lengthvariant priority="1">公眾</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_classical">
      <source>Classical</source>
      <translation variants="no">zh_hk #Classical</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">警報</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_drama">
      <source>Drama</source>
      <translation variants="no">zh_hk #Drama</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz2">
      <source>%L1 MHz</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1兆赫</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_phone_in_hs">
      <source>Phone In</source>
      <translation variants="no">zh_hk #Phone in</translation>
    </message>
    <message numerus="no" id="txt_rad_info_serious_classical">
      <source>Serious classical</source>
      <translation variants="no">zh_hk #Serious classical</translation>
    </message>
    <message numerus="no" id="txt_short_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">zh_hk #Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_college">
      <source>College</source>
      <translation variants="yes">
        <lengthvariant priority="1">學院</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_classic_rock_hs">
      <source>Classic rock</source>
      <translation variants="no">zh_hk #Classic rock</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_language">
      <source>Language</source>
      <translation variants="yes">
        <lengthvariant priority="1">語言</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_weather">
      <source>Weather</source>
      <translation variants="no">zh_hk #Weather</translation>
    </message>
    <message numerus="no" id="txt_rad_info_country_music">
      <source>Country Music</source>
      <translation variants="no">zh_hk #Country music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_social_affairs">
      <source>Social Affairs</source>
      <translation variants="no">zh_hk #Social affairs</translation>
    </message>
    <message numerus="no" id="txt_rad_info_education">
      <source>Education</source>
      <translation variants="no">zh_hk #Education</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_favourite_stations">
      <source>(No favourite stations)</source>
      <translation variants="no">zh_hk #(no favourites)</translation>
    </message>
    <message numerus="no" id="txt_rad_info_drama_hs">
      <source>Drama</source>
      <translation variants="no">zh_hk #Drama</translation>
    </message>
    <message numerus="no" id="txt_rad_info_continue_using_the_radio_in_offline">
      <source>Continue using the Radio in off-line mode?</source>
      <translation variants="no">是否繼續在離線模式下使用收音機？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rock">
      <source>Soft rock</source>
      <translation variants="no">zh_hk #Soft rock</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rhythm_and_blues">
      <source>Soft rhythm and blues</source>
      <translation variants="no">zh_hk #Soft rhythm and blues</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_favourites_add_favourites_to_see">
      <source>You can mark your favourite stations in All stations view by long tapping the station and selecting Add favourite. You can also tap the favourite icon in main view to mark it as a favorite.</source>
      <translation variants="no">zh_hk #You can add a station to favourites by selecting and holding the station and selecting 'Add to favourites'. You can also tap the star icon in main view to add a station to favourites.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_adult_hits">
      <source>Adult hits</source>
      <translation variants="no">zh_hk #Adult hits</translation>
    </message>
    <message numerus="no" id="txt_rad_info_phone_in">
      <source>Phone In</source>
      <translation variants="no">zh_hk #Phone in</translation>
    </message>
    <message numerus="no" id="txt_rad_info_rhythm_and_blues_hs">
      <source>Rhythm and blues</source>
      <translation variants="no">zh_hk #Rhythm and blues</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_travel">
      <source>Travel</source>
      <translation variants="yes">
        <lengthvariant priority="1">旅遊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_varied">
      <source>Varied</source>
      <translation variants="yes">
        <lengthvariant priority="1">多變化的</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">古典</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_top_40_hs">
      <source>Top 40</source>
      <translation variants="no">zh_hk #Top 40</translation>
    </message>
    <message numerus="no" id="txt_rad_info_nostalgia_hs">
      <source>Nostalgia</source>
      <translation variants="no">zh_hk #Nostalgia</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_alarm_test">
      <source>Alarm Test</source>
      <translation variants="yes">
        <lengthvariant priority="1">警報測試</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_jazz_music_hs">
      <source>Jazz Music</source>
      <translation variants="no">zh_hk #Jazz music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_remove_station_from_favorites">
      <source>Remove station from favorites?</source>
      <translation variants="no">是否從我的最愛移除電台？</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_education">
      <source>Education</source>
      <translation variants="yes">
        <lengthvariant priority="1">教育</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_easy_listening">
      <source>Easy Listening</source>
      <translation variants="no">zh_hk #Easy listening</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_jazz_music">
      <source>Jazz Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">爵士樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_culture">
      <source>Culture</source>
      <translation variants="no">zh_hk #Culture</translation>
    </message>
    <message numerus="no" id="txt_rad_button_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">zh_hk #Activate</translation>
    </message>
    <message numerus="no" id="txt_rad_list_l1_mhz">
      <source>%L1 Mhz</source>
      <translation variants="no">zh_hk #%L1 MHz</translation>
    </message>
    <message numerus="no" id="txt_rad_info_culture_hs">
      <source>Culture</source>
      <translation variants="no">zh_hk #Culture</translation>
    </message>
    <message numerus="no" id="txt_rad_button_cancel">
      <source>Cancel</source>
      <translation variants="no">zh_hk #Cancel</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_current_affairs">
      <source>Current affairs</source>
      <translation variants="yes">
        <lengthvariant priority="1">時事</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft">
      <source>Soft</source>
      <translation variants="no">zh_hk #Soft</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_song_was_added_to_favorite_songs">
      <source>Song was added to Tagged songs.</source>
      <translation variants="no">歌曲已加至我的最愛</translation>
    </message>
    <message numerus="no" id="txt_rad_info_college">
      <source>College</source>
      <translation variants="no">zh_hk #College</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_delete_station">
      <source>Delete station</source>
      <translation variants="no">刪除</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_1_2">
      <source>%1 - %2</source>
      <translation variants="no">zh_hk #kkkkkkkkkk - kkkkkkkkkk</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_remove_tag">
      <source>Remove tag</source>
      <translation variants="no">從我的最愛移除</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_unknown">
      <source>(Unknown)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(未知)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_classic_rock">
      <source>Classic rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">經典搖滾</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_light_classical">
      <source>Light classical</source>
      <translation variants="no">zh_hk #Light classical</translation>
    </message>
    <message numerus="no" id="txt_rad_info_current_affairs_hs">
      <source>Current affairs</source>
      <translation variants="no">zh_hk #Current affairs</translation>
    </message>
    <message numerus="no" id="txt_rad_info_childrens_programmes_hs">
      <source>Children’s programmes</source>
      <translation variants="no">zh_hk #Children's programmes</translation>
    </message>
    <message numerus="no" id="txt_rad_info_varied_hs">
      <source>Varied</source>
      <translation variants="no">zh_hk #Varied</translation>
    </message>
    <message numerus="no" id="txt_rad_info_science_hs">
      <source>Science</source>
      <translation variants="no">zh_hk #Science</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_science">
      <source>Science</source>
      <translation variants="yes">
        <lengthvariant priority="1">科學</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_information">
      <source>Information</source>
      <translation variants="no">zh_hk #Information</translation>
    </message>
    <message numerus="no" id="txt_rad_info_play_history_is_empty">
      <source>(No songs)</source>
      <translation variants="no">zh_hk #(no songs)</translation>
    </message>
    <message numerus="no" id="txt_rad_info_public_hs">
      <source>Public</source>
      <translation variants="no">zh_hk #Public</translation>
    </message>
    <message numerus="no" id="txt_rad_info_serious_classical_hs">
      <source>Serious classical</source>
      <translation variants="no">zh_hk #Serious classical</translation>
    </message>
    <message numerus="no" id="txt_rad_info_language_hs">
      <source>Language</source>
      <translation variants="no">zh_hk #Language</translation>
    </message>
    <message numerus="no" id="txt_rad_list_l1_mhz_small">
      <source>%L1 MHz</source>
      <translation variants="no">zh_hk #%L1 MHz</translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_all_stations">
      <source>All stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">所有電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_childrens_programmes">
      <source>Children’s programmes</source>
      <translation variants="yes">
        <lengthvariant priority="1">兒童節目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_public">
      <source>Public</source>
      <translation variants="no">zh_hk #Public</translation>
    </message>
    <message numerus="no" id="txt_rad_info_connect_wired_headset">
      <source>Connect wired headset.</source>
      <translation variants="no">zh_hk #Connect wired headset</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_talk">
      <source>Religious talk</source>
      <translation variants="no">zh_hk #Religious talk</translation>
    </message>
    <message numerus="no" id="txt_rad_info_folk_music">
      <source>Folk Music</source>
      <translation variants="no">zh_hk #Folk music</translation>
    </message>
    <message numerus="no" id="txt_rad_button_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">zh_hk #Deactivate loudspeaker</translation>
    </message>
    <message numerus="no" id="txt_rad_info_travel">
      <source>Travel</source>
      <translation variants="no">zh_hk #Travel</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_country_music">
      <source>Country Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">鄉村音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_favourites">
      <source>Favourite stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_leisure">
      <source>Leisure</source>
      <translation variants="yes">
        <lengthvariant priority="1">消閒</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_news">
      <source>News</source>
      <translation variants="yes">
        <lengthvariant priority="1">新聞</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_weather_hs">
      <source>Weather</source>
      <translation variants="no">zh_hk #Weather</translation>
    </message>
    <message numerus="no" id="txt_rad_info_personality_hs">
      <source>Personality</source>
      <translation variants="no">zh_hk #Personality</translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_favorite_stations">
      <source>Favorite stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_easy_listening_hs">
      <source>Easy Listening</source>
      <translation variants="no">zh_hk #Easy listening</translation>
    </message>
    <message numerus="no" id="txt_rad_info_folk_music_hs">
      <source>Folk Music</source>
      <translation variants="no">zh_hk #Folk music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_jazz_music">
      <source>Jazz Music</source>
      <translation variants="no">zh_hk #Jazz music</translation>
    </message>
    <message numerus="no" id="txt_rad_button_identify_song">
      <source>Identify song</source>
      <translation variants="no">zh_hk #Identify song</translation>
    </message>
    <message numerus="no" id="txt_rad_info_college_hs">
      <source>College</source>
      <translation variants="no">zh_hk #College</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_easy_listening">
      <source>Easy Listening</source>
      <translation variants="yes">
        <lengthvariant priority="1">輕音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_talk_hs">
      <source>Talk</source>
      <translation variants="no">zh_hk #Talk</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_light_classical">
      <source>Light classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">輕古典</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_searching_local_stations_please_wait">
      <source>Searching local stations. Please wait.</source>
      <translation variants="no">當地電台掃描中</translation>
    </message>
    <message numerus="no" id="txt_rad_button_stations">
      <source>Stations</source>
      <translation variants="no">zh_hk #Station list</translation>
    </message>
    <message numerus="no" id="txt_rad_info_activate_radio_in_offline_mode">
      <source>Activate Fm Radio in off-line mode?</source>
      <translation variants="no">是否在離線模式下開啟收音機？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_sport">
      <source>Sport</source>
      <translation variants="no">zh_hk #Sport</translation>
    </message>
    <message numerus="no" id="txt_rad_list_l1_mhz_big">
      <source>%L1 MHz</source>
      <translation variants="no">zh_hk #%L1 MHz</translation>
    </message>
    <message numerus="no" id="txt_rad_info_education_hs">
      <source>Education</source>
      <translation variants="no">zh_hk #Education</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_hs">
      <source>Soft</source>
      <translation variants="no">zh_hk #Soft</translation>
    </message>
    <message numerus="no" id="txt_rad_button_local_stations">
      <source>All stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">所有電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_recently_played_songs_collects_song_i">
      <source>Recently played songs collects song information from radio stations which send the song information using RDS+ technology.
Also songs which are identified with ”Identify song” functionality in main view are displayed here.</source>
      <translation variants="no">zh_hk #Recently played songs collects song information from radio stations which send the song information using RDS+ technology.
Also songs which are identified with ”Identify song” functionality in main view are displayed here.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_oldies_music">
      <source>Oldies Music</source>
      <translation variants="no">zh_hk #Oldies music</translation>
    </message>
    <message numerus="no" id="txt_rad_button_recently_played_songs">
      <source>Recently played songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">zh_hk #Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_info_pop_music">
      <source>Pop Music</source>
      <translation variants="no">zh_hk #Pop music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_current_affairs">
      <source>Current affairs</source>
      <translation variants="no">zh_hk #Current affairs</translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm_test">
      <source>Alarm Test</source>
      <translation variants="no">zh_hk #Alarm test</translation>
    </message>
    <message numerus="no" id="txt_rad_info_pop_music_hs">
      <source>Pop Music</source>
      <translation variants="no">zh_hk #Pop music</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_documentary">
      <source>Documentary</source>
      <translation variants="yes">
        <lengthvariant priority="1">紀錄節目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_sport_hs">
      <source>Sport</source>
      <translation variants="no">zh_hk #Sport</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft_rhythm_and_blues">
      <source>Soft rhythm and blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">抒情節奏藍調</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm_test_hs">
      <source>Alarm Test</source>
      <translation variants="no">zh_hk #Alarm test</translation>
    </message>
    <message numerus="no" id="txt_rad_info_delete_station">
      <source>Delete station?</source>
      <translation variants="no">是否刪除電台？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_talk_hs">
      <source>Religious talk</source>
      <translation variants="no">zh_hk #Religious talk</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_stations">
      <source>(No stations)</source>
      <translation variants="no">zh_hk #(no stations)</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religion">
      <source>Religion</source>
      <translation variants="no">zh_hk #Religion</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_social_affairs">
      <source>Social Affairs</source>
      <translation variants="yes">
        <lengthvariant priority="1">社會動態</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft_rock">
      <source>Soft rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">抒情搖滾</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religious_music">
      <source>Religious music</source>
      <translation variants="yes">
        <lengthvariant priority="1">宗教音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_leisure">
      <source>Leisure</source>
      <translation variants="no">zh_hk #Leisure</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_connect_wired_headset">
      <source>Connect wired headset.</source>
      <translation variants="no">請連接有線耳機</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_adult_hits">
      <source>Adult hits</source>
      <translation variants="yes">
        <lengthvariant priority="1">成人熱門</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_finance">
      <source>Finance</source>
      <translation variants="no">zh_hk #Finance</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_rhythm_and_blues">
      <source>Rhythm and blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">節奏藍調</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz">
      <source>%L1 MHz</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1兆赫</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_other_music">
      <source>Other Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">其他音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_music">
      <source>Religious music</source>
      <translation variants="no">zh_hk #Religious music</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_no_stations_found_try_searching">
      <source>No stations found. Try searching stations by scrolling the frequency strip.</source>
      <translation variants="no">找不到電台。請再試一次使用頻率列。</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_folk_music">
      <source>Folk Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">民俗音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_documentary">
      <source>Documentary</source>
      <translation variants="no">zh_hk #Documentary</translation>
    </message>
    <message numerus="no" id="txt_rad_info_national_music_hs">
      <source>National Music</source>
      <translation variants="no">zh_hk #National music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_national_music">
      <source>National Music</source>
      <translation variants="no">zh_hk #National music</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_tag_song">
      <source>Tag song</source>
      <translation variants="no">加至我的最愛</translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_play_history">
      <source>Play history</source>
      <translation variants="yes">
        <lengthvariant priority="1">播放記錄</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_tag_song">
      <source>Tag song</source>
      <translation variants="no">zh_hk #Add to favourites</translation>
    </message>
    <message numerus="no" id="txt_rad_info_travel_hs">
      <source>Travel</source>
      <translation variants="no">zh_hk #Travel</translation>
    </message>
    <message numerus="no" id="txt_rad_info_nostalgia">
      <source>Nostalgia</source>
      <translation variants="no">zh_hk #Nostalgia</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_top_40">
      <source>Top 40</source>
      <translation variants="yes">
        <lengthvariant priority="1">金榜前40名</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_search_all_stations">
      <source>Search all stations</source>
      <translation variants="no">zh_hk #Scan stations</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_rock_music">
      <source>Rock Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">搖滾樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_classical_hs">
      <source>Classical</source>
      <translation variants="no">zh_hk #Classical</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religion_hs">
      <source>Religion</source>
      <translation variants="no">zh_hk #Religion</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_national_music">
      <source>National Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">民族音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_oldies_music">
      <source>Oldies Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">老歌</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dialog_long_press_arrow_keys_to_search_str">
      <source>Mark favourite stations by pressing the star icon to enable navigation with short arrow presses. You can also swipe here to navigate between all stations. Long press arrow keys to search strong signal stations. </source>
      <translation variants="no">zh_hk #Add stations to favourites by selecting and holding the start icon. You can also swipe here to navigate between all stations. Select and hold arrow keys to scan strong signal stations.</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_add_to_favourites">
      <source>Add to favourites</source>
      <translation variants="no">加至我的最愛</translation>
    </message>
    <message numerus="no" id="txt_rad_list_unknown">
      <source>(Unknown) - %1</source>
      <translation variants="no">(未知)%1</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_pop_music">
      <source>Pop Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">流行音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_sport">
      <source>Sport</source>
      <translation variants="yes">
        <lengthvariant priority="1">運動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_personality">
      <source>Personality</source>
      <translation variants="yes">
        <lengthvariant priority="1">性格</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_serious_classical">
      <source>Serious classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">嚴肅古典音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_information_hs">
      <source>Information</source>
      <translation variants="no">zh_hk #Information</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_search_from_music_store">
      <source>Search from Ovi Music</source>
      <translation variants="no">前往Ovi音樂</translation>
    </message>
    <message numerus="no" id="txt_rad_info_top_40">
      <source>Top 40</source>
      <translation variants="no">zh_hk #Top 40</translation>
    </message>
    <message numerus="no" id="txt_rad_info_personality">
      <source>Personality</source>
      <translation variants="no">zh_hk #Personality</translation>
    </message>
    <message numerus="no" id="txt_rad_info_adult_hits_hs">
      <source>Adult hits</source>
      <translation variants="no">zh_hk #Adult hits</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_phone_in">
      <source>Phone In</source>
      <translation variants="yes">
        <lengthvariant priority="1">烽煙節目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_opt_search_all_stations">
      <source>Search all stations</source>
      <translation variants="no">掃描電台</translation>
    </message>
    <message numerus="no" id="txt_rad_title_fm_radio">
      <source>FM Radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">收音機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft">
      <source>Soft</source>
      <translation variants="yes">
        <lengthvariant priority="1">軟調音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_other_music">
      <source>Other Music</source>
      <translation variants="no">zh_hk #Other music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_leisure_hs">
      <source>Leisure</source>
      <translation variants="no">zh_hk #Leisure</translation>
    </message>
    <message numerus="no" id="txt_rad_info_classic_rock">
      <source>Classic rock</source>
      <translation variants="no">zh_hk #Classic rock</translation>
    </message>
  </context>
</TS>