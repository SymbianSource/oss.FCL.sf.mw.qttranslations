<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">主題</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="no">響鬧時間</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_db_conflict_info_delete">
      <source>This entry has been deleted by another application</source>
      <translation variants="no">此項目已由其他應用程式刪除</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_low">
      <source>Low</source>
      <translation variants="no">低</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_todo">
      <source>New To-do</source>
      <translation variants="no">新增待辦事項</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">到期日</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="no">響鬧日期</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_time">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">放棄變更</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">加入內容說明</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_high">
      <source>High</source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_todo">
      <source>To-do</source>
      <translation variants="no">待辦事項</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="no">響鬧時間和日期</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_date">
      <source>%2</source>
      <translation variants="no">%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_normal">
      <source>Normal</source>
      <translation variants="no">中</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_due_date">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">移除內容說明</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">響鬧</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_database_conflict">
      <source>Database conflict</source>
      <translation variants="no">日曆數據庫衝突</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_due_date">
      <source>Due date</source>
      <translation variants="no">到期日</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_description">
      <source>Description</source>
      <translation variants="no">內容說明</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_db_conflict_info_modify">
      <source>This entry has been modified by another application</source>
      <translation variants="no">此項目已由其他應用程式修改</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_priority">
      <source>Priority</source>
      <translation variants="no">優先順序</translation>
    </message>
  </context>
</TS>