<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_button_alarm_date">
      <source>%2</source>
      <translation variants="no">zh_hk #%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_time">
      <source>%1</source>
      <translation variants="no">zh_hk #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_due_date">
      <source>%1</source>
      <translation variants="no">zh_hk #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">zh_hk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="no">zh_hk #Alarm time and date</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_description">
      <source>Description</source>
      <translation variants="no">zh_hk #Description</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">zh_hk #Due date</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">zh_hk #Subject</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_db_conflict_info_delete">
      <source>This entry has been deleted by another application</source>
      <translation variants="no">zh_hk #This entry has been deleted by another application</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_db_conflict_info_modify">
      <source>This entry has been modified by another application</source>
      <translation variants="no">zh_hk #This entry has been modified by another application</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">zh_hk #Add description</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">zh_hk #Discard changes</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">zh_hk #Remove description</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_priority">
      <source>Priority</source>
      <translation variants="no">zh_hk #Priority</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_high">
      <source>High</source>
      <translation variants="no">zh_hk #High</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_low">
      <source>Low</source>
      <translation variants="no">zh_hk #Low</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_normal">
      <source>Normal</source>
      <translation variants="no">zh_hk #Normal</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_todo">
      <source>New To-do</source>
      <translation variants="no">zh_hk #New to-do note</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_todo">
      <source>To-do</source>
      <translation variants="no">zh_hk #To-do note</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="no">zh_hk #Alarm date</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="no">zh_hk #Alarm time</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_database_conflict">
      <source>Database conflict</source>
      <translation variants="no">zh_hk #Calendar database conflict</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_due_date">
      <source>Due date</source>
      <translation variants="no">zh_hk #Due date</translation>
    </message>
  </context>
</TS>