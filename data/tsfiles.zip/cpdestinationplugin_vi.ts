<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_info_invalid_input">
      <source>Invalid input</source>
      <translation variants="no">vi #Invalid input</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_uncategorized">
      <source>Uncategorized</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Uncategorized</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_delete_snap">
      <source>Delete destination '%1'?</source>
      <translation variants="no">vi ##Delete destination '%1'?</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_arrange">
      <source>Arrange</source>
      <translation variants="no">vi ##Arrange</translation>
    </message>
    <message numerus="no" id="txt_occ_menu_move_to_other_destination">
      <source>Move to other destination</source>
      <translation variants="no">vi ##Move to other destination</translation>
    </message>
    <message numerus="no" id="txt_occ_menu_share_to_other_destination">
      <source>Share to other destination</source>
      <translation variants="no">vi ##Share to other destination</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_internet_val_no_access_points">
      <source>No access points</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##No access points</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_incomplete_details_return_without_sa">
      <source>Incomplete details. Return without saving?</source>
      <translation variants="no">vi #Incomplete details. Return without saving?</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_val_priority_l1">
      <source>Priority: %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Priority: %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_button_add_destination">
      <source>Add destination</source>
      <translation variants="no">vi ##Add destination</translation>
    </message>
    <message numerus="no" id="txt_occ_info_name_already_in_use">
      <source>Name already in use</source>
      <translation variants="no">vi ##Name already in use</translation>
    </message>
    <message numerus="no" id="txt_occ_info_unable_to_save_setting">
      <source>Unable to save setting</source>
      <translation variants="no">vi ##Unable to save setting</translation>
    </message>
    <message numerus="no" id="txt_occ_info_incorrect_password_msg_box">
      <source>Incorrect password</source>
      <translation variants="no">vi #Incorrect password</translation>
    </message>
    <message numerus="yes" id="txt_occ_dblist_internet_val_ln_access_points">
      <source>%Ln access points</source>
      <translation>
        <numerusform plurality="a">vi ##%Ln access points</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_button_arrange">
      <source>Arrange</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Arrange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_delete_access_point_1">
      <source>Delete access point '%1'?</source>
      <translation variants="no">vi ##Delete access point '%1'?</translation>
    </message>
    <message numerus="no" id="txt_occ_info_unable_to_read_settings">
      <source>Unable to read settings</source>
      <translation variants="no">vi ##Unable to read settings</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_destination_name">
      <source>Destination name:</source>
      <translation variants="no">vi ##Destination name:</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_destinations_access_points">
      <source>Destinations &amp; access points</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Destinations &amp; access points</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_invalid_name">
      <source>Invalid name</source>
      <translation variants="no">vi ##Invalid name</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_select_network_destination_to_be_ac">
      <source>Select network destination to be accessed using this access point:</source>
      <translation variants="no">vi ##Select network destination to be accessed using this access point:</translation>
    </message>
    <message numerus="no" id="txt_occ_info_passwords_do_not_match_try_again">
      <source>Passwords do not match. Try again.</source>
      <translation variants="no">vi #Passwords do not match. Try again.</translation>
    </message>
  </context>
</TS>