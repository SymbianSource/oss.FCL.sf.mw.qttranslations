<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="yes" id="txt_occ_dblist_internet_val_ln_access_points">
      <source>%Ln access points</source>
      <translation>
        <numerusform plurality="a">%Ln điểm truy cập</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_destinations_access_points">
      <source>Destinations &amp; access points</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đích &amp; điểm truy cập</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_menu_share_to_other_destination">
      <source>Share to other destination</source>
      <translation variants="no">Sao chép điểm truy cập</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_internet_val_no_access_points">
      <source>No access points</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có điểm truy cập</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_uncategorized">
      <source>Uncategorized</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chưa xếp loại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_delete_snap">
      <source>Delete destination '%1'?</source>
      <translation variants="no">Xóa đích '%[47]1'?</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_arrange">
      <source>Arrange</source>
      <translation variants="no">Sắp xếp lại điểm truy cập</translation>
    </message>
    <message numerus="no" id="txt_occ_menu_move_to_other_destination">
      <source>Move to other destination</source>
      <translation variants="no">Chuyển điểm truy cập</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_destination_name">
      <source>Destination name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên đích:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_delete_access_point_1">
      <source>Delete access point '%1'?</source>
      <translation variants="no">Xóa điểm truy cập '%[39]1'?</translation>
    </message>
    <message numerus="no" id="txt_occ_button_add_destination">
      <source>Add destination</source>
      <translation variants="no">Thêm đích</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_val_priority_l1">
      <source>Priority: %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mức ưu tiên: %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_incomplete_details_return_without_sa">
      <source>Incomplete details. Return without saving?</source>
      <translation variants="no">Chi tiết chưa hoàn chỉnh. Quay lại mà không lưu?</translation>
    </message>
    <message numerus="no" id="txt_occ_info_unable_to_save_setting">
      <source>Unable to save setting</source>
      <translation variants="no">Không thể lưu lại cài đặt</translation>
    </message>
    <message numerus="no" id="txt_occ_info_invalid_input">
      <source>Invalid input</source>
      <translation variants="no">Mục nhập không hợp lệ.</translation>
    </message>
    <message numerus="no" id="txt_occ_info_incorrect_password_msg_box">
      <source>Incorrect password</source>
      <translation variants="no">Mật khẩu sai</translation>
    </message>
    <message numerus="no" id="txt_occ_info_name_already_in_use">
      <source>Name already in use</source>
      <translation variants="no">Tên đã được dùng.</translation>
    </message>
    <message numerus="no" id="txt_occ_info_unable_to_read_settings">
      <source>Unable to read settings</source>
      <translation variants="no">Không thể đọc cài đặt</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_select_network_destination_to_be_ac">
      <source>Select network destination to be accessed using this access point:</source>
      <translation variants="no">Chọn đích mạng bạn muốn truy cập bằng cách sử dụng điểm truy cập này:</translation>
    </message>
    <message numerus="no" id="txt_occ_info_passwords_do_not_match_try_again">
      <source>Passwords do not match. Try again.</source>
      <translation variants="no">Mật khẩu không khớp. Thử lại.</translation>
    </message>
    <message numerus="no" id="txt_occ_info_invalid_name">
      <source>Invalid name</source>
      <translation variants="no">Tên không hợp lệ.</translation>
    </message>
  </context>
</TS>