<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_rad_info_phone_in">
      <source>Phone In</source>
      <translation variants="no">zh_tw #Phone-in</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_alarm_test">
      <source>Alarm Test</source>
      <translation variants="yes">
        <lengthvariant priority="1">警報測試</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_jazz_music">
      <source>Jazz Music</source>
      <translation variants="no">zh_tw #Jazz music</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_classic_rock">
      <source>Classic rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">經典搖滾</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_light_classical">
      <source>Light classical</source>
      <translation variants="no">zh_tw #Light classical</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_science">
      <source>Science</source>
      <translation variants="yes">
        <lengthvariant priority="1">科學</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_information">
      <source>Information</source>
      <translation variants="no">zh_tw #Information</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_1_2">
      <source>%1 - %2</source>
      <translation variants="no">zh_tw #%[10]1 - %2</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_rhythm_and_blues">
      <source>Rhythm and blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">節奏藍調</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_play_history_is_empty">
      <source>(No songs)</source>
      <translation variants="no">zh_tw #(no songs)</translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_favorite_stations">
      <source>Favorite stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_unknown">
      <source>(Unknown)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(不明)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_adult_hits">
      <source>Adult hits</source>
      <translation variants="yes">
        <lengthvariant priority="1">成人熱門</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_recently_played_songs_list">
      <source>Clear Recently played songs list?</source>
      <translation variants="no">是否清除最近播放過的歌曲清單？</translation>
    </message>
    <message numerus="no" id="txt_rad_dialog_new_name">
      <source>New name:</source>
      <translation variants="no">新名稱：</translation>
    </message>
    <message numerus="no" id="txt_rad_opt_play_history">
      <source>Play history</source>
      <translation variants="no">播放記錄</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_search_from_music_store">
      <source>Search from Ovi Music</source>
      <translation variants="no">移至Ovi音樂</translation>
    </message>
    <message numerus="no" id="txt_rad_info_top_40">
      <source>Top 40</source>
      <translation variants="no">zh_tw #Top 40</translation>
    </message>
    <message numerus="no" id="txt_rad_info_remove_song_from_tagged_songs">
      <source>Remove song from tagged songs?</source>
      <translation variants="no">是否從我的最愛移除歌曲？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_you_can_add_song_to_the_tagged_songs">
      <source>You can add song to the tagged songs list from Recently played songs or from main view if song information is available. </source>
      <translation variants="no">zh_tw #Songs can be added to tagged songs from 'Recently played' only if they have been identified</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_tagged_songs_list">
      <source>Clear Tagged songs list?</source>
      <translation variants="no">是否從我的最愛移除所有歌曲？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_favourite_stations_list">
      <source>Clear Favourite stations list?</source>
      <translation variants="no">是否從我的最愛移除所有電台？</translation>
    </message>
    <message numerus="no" id="txt_rad_button_recently_played_songs">
      <source>Recently played songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_all_stations_list">
      <source>Clear All stations list?</source>
      <translation variants="no">是否清除電台清單？將會移除所有電台。</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">zh_tw #Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_info_station_list_is_full_please_remove_s">
      <source>Station list is full. Please remove some stations and try again.</source>
      <translation variants="no">zh_tw #Station list is full. Remove some stations and try again.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_talk">
      <source>Religious talk</source>
      <translation variants="no">zh_tw #Religious talk</translation>
    </message>
    <message numerus="no" id="txt_rad_info_folk_music">
      <source>Folk Music</source>
      <translation variants="no">zh_tw #Folk music</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_easy_listening">
      <source>Easy Listening</source>
      <translation variants="yes">
        <lengthvariant priority="1">輕音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_list_l1_mhz_small">
      <source>%L1 MHz</source>
      <translation variants="no">zh_tw #%L1 MHz</translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_all_stations">
      <source>All stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">所有電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">zh_tw #Deactivate loudspeaker</translation>
    </message>
    <message numerus="no" id="txt_rad_info_travel">
      <source>Travel</source>
      <translation variants="no">zh_tw #Travel</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_light_classical">
      <source>Light classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">輕古典</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_country_music">
      <source>Country Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">鄉村音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_add_to_favourites">
      <source>Add to favourites</source>
      <translation variants="no">zh_tw #Add to favourites</translation>
    </message>
    <message numerus="no" id="txt_rad_info_song_information_is_collected_automat">
      <source>Song information is collected automatically from radio stations which send the song information using the RDS+ technology.</source>
      <translation variants="no">zh_tw #Song information is collected automatically from radio stations which send the song information using the RDS+ technology.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_finance">
      <source>Finance</source>
      <translation variants="no">zh_tw #Finance</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_childrens_programmes">
      <source>Children’s programmes</source>
      <translation variants="yes">
        <lengthvariant priority="1">兒童節目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_public">
      <source>Public</source>
      <translation variants="no">zh_tw #Public</translation>
    </message>
    <message numerus="no" id="txt_rad_info_rhythm_and_blues">
      <source>Rhythm and blues</source>
      <translation variants="no">zh_tw #Rhythm and blues</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religious_talk">
      <source>Religious talk</source>
      <translation variants="yes">
        <lengthvariant priority="1">宗教談話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_weather">
      <source>Weather</source>
      <translation variants="yes">
        <lengthvariant priority="1">天氣</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_drama">
      <source>Drama</source>
      <translation variants="yes">
        <lengthvariant priority="1">戲劇</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_varied">
      <source>Varied</source>
      <translation variants="no">zh_tw #Varied</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religion">
      <source>Religion</source>
      <translation variants="yes">
        <lengthvariant priority="1">宗教</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_talk">
      <source>Talk</source>
      <translation variants="yes">
        <lengthvariant priority="1">談話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_finance">
      <source>Finance</source>
      <translation variants="yes">
        <lengthvariant priority="1">財務金融</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_all_stations_in_stations_list_will_be">
      <source>Stations in station list will be replaced. Favourite stations won't be touched. Continue?</source>
      <translation variants="no">電台清單中的所有預設電台將會被取代。我的最愛將不會變更。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_stations_search_stations_automat">
      <source>Search stations automatically by tapping here.</source>
      <translation variants="no">zh_tw #Scan stations automatically by tapping here</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rock">
      <source>Soft rock</source>
      <translation variants="no">zh_tw #Soft rock</translation>
    </message>
    <message numerus="no" id="txt_rad_info_nostalgia">
      <source>Nostalgia</source>
      <translation variants="no">zh_tw #Nostalgia</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rhythm_and_blues">
      <source>Soft rhythm and blues</source>
      <translation variants="no">zh_tw #Soft rhythm and blues</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_favourites_add_favourites_to_see">
      <source>Tap the star icon or Add to favourite button in main view to mark currently playing station as a favorite.</source>
      <translation variants="no">zh_tw #You can add a station to favourites by selecting and holding the station and selecting 'Add to favourites'. You can also tap the star icon in the main view to add a station to favourites.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_adult_hits">
      <source>Adult hits</source>
      <translation variants="no">zh_tw #Adult hits</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_varied">
      <source>Varied</source>
      <translation variants="yes">
        <lengthvariant priority="1">多變化的</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_education">
      <source>Education</source>
      <translation variants="yes">
        <lengthvariant priority="1">教育</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_jazz_music">
      <source>Jazz Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">爵士樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_top_40">
      <source>Top 40</source>
      <translation variants="yes">
        <lengthvariant priority="1">排行前40名</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_current_affairs">
      <source>Current affairs</source>
      <translation variants="yes">
        <lengthvariant priority="1">時事</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft">
      <source>Soft</source>
      <translation variants="no">zh_tw #Soft</translation>
    </message>
    <message numerus="no" id="txt_fmradio_button_remove_from_favourites">
      <source>Remove from favourites</source>
      <translation variants="no">zh_tw #Remove from favourites</translation>
    </message>
    <message numerus="no" id="txt_rad_button_tagged_songs">
      <source>Tagged songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">清除清單</translation>
    </message>
    <message numerus="no" id="txt_long_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">收音機</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_remove_favourite">
      <source>Remove from favourites</source>
      <translation variants="no">從我的最愛移除</translation>
    </message>
    <message numerus="no" id="txt_rad_list_searching_all_available_stations_ple">
      <source>Searching all available stations. Please wait.</source>
      <translation variants="no">zh_tw #Scanning available stations</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_public">
      <source>Public</source>
      <translation variants="yes">
        <lengthvariant priority="1">公眾</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_classical">
      <source>Classical</source>
      <translation variants="no">zh_tw #Classical</translation>
    </message>
    <message numerus="no" id="txt_rad_info_culture">
      <source>Culture</source>
      <translation variants="no">zh_tw #Culture</translation>
    </message>
    <message numerus="no" id="txt_rad_button_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">zh_tw #Activate loudspeaker</translation>
    </message>
    <message numerus="no" id="txt_rad_info_national_music">
      <source>National Music</source>
      <translation variants="no">zh_tw #National music</translation>
    </message>
    <message numerus="no" id="txt_rad_button_cancel">
      <source>Cancel</source>
      <translation variants="no">zh_tw #Cancel</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_song_was_added_to_favorite_songs">
      <source>Song was added to Tagged songs.</source>
      <translation variants="no">歌曲已加入至我的最愛</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_tag_song">
      <source>Tag song</source>
      <translation variants="no">加入至我的最愛</translation>
    </message>
    <message numerus="no" id="txt_rad_info_college">
      <source>College</source>
      <translation variants="no">zh_tw #College</translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_play_history">
      <source>Play history</source>
      <translation variants="yes">
        <lengthvariant priority="1">播放記錄</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_rock_music">
      <source>Rock Music</source>
      <translation variants="no">zh_tw #Rock music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_news">
      <source>News</source>
      <translation variants="no">zh_tw #News</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_remove_tag">
      <source>Remove tag</source>
      <translation variants="no">從我的最愛移除</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_nostalgia">
      <source>Nostalgia</source>
      <translation variants="yes">
        <lengthvariant priority="1">懷舊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_language">
      <source>Language</source>
      <translation variants="no">zh_tw #Language</translation>
    </message>
    <message numerus="no" id="txt_rad_info_science">
      <source>Science</source>
      <translation variants="no">zh_tw #Science</translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm">
      <source>Alarm</source>
      <translation variants="no">zh_tw #Alarm</translation>
    </message>
    <message numerus="no" id="txt_rad_info_childrens_programmes">
      <source>Children’s programmes</source>
      <translation variants="no">zh_tw #Children's programmes</translation>
    </message>
    <message numerus="no" id="txt_rad_info_leisure">
      <source>Leisure</source>
      <translation variants="no">zh_tw #Leisure</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_information">
      <source>Information</source>
      <translation variants="yes">
        <lengthvariant priority="1">資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz2">
      <source>%L1 MHz</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1兆赫</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_college">
      <source>College</source>
      <translation variants="yes">
        <lengthvariant priority="1">學院</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_language">
      <source>Language</source>
      <translation variants="yes">
        <lengthvariant priority="1">語言</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_weather">
      <source>Weather</source>
      <translation variants="no">zh_tw #Weather</translation>
    </message>
    <message numerus="no" id="txt_fmradio_info_local_frequency_band_automaticall">
      <source>Local frequency band automatically set for radio.</source>
      <translation variants="no">zh_tw #Local frequency band autom. set for radio</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_culture">
      <source>Culture</source>
      <translation variants="yes">
        <lengthvariant priority="1">文化</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_talk">
      <source>Talk</source>
      <translation variants="no">zh_tw #Talk</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">警報</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_social_affairs">
      <source>Social Affairs</source>
      <translation variants="yes">
        <lengthvariant priority="1">社會動態</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz">
      <source>%L1 MHz</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1兆赫</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religious_music">
      <source>Religious music</source>
      <translation variants="yes">
        <lengthvariant priority="1">宗教音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_drama">
      <source>Drama</source>
      <translation variants="no">zh_tw #Drama</translation>
    </message>
    <message numerus="no" id="txt_rad_info_serious_classical">
      <source>Serious classical</source>
      <translation variants="no">zh_tw #Serious classical</translation>
    </message>
    <message numerus="no" id="txt_short_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">zh_tw #Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_stations">
      <source>(No stations)</source>
      <translation variants="no">zh_tw #(no stations)</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religion">
      <source>Religion</source>
      <translation variants="no">zh_tw #Religion</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft_rock">
      <source>Soft rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">抒情搖滾</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_sport">
      <source>Sport</source>
      <translation variants="no">zh_tw #Sport</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_folk_music">
      <source>Folk Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">民俗音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_favourites">
      <source>Favourite stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_leisure">
      <source>Leisure</source>
      <translation variants="yes">
        <lengthvariant priority="1">休閒</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft_rhythm_and_blues">
      <source>Soft rhythm and blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">抒情節奏藍調</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_delete_station">
      <source>Delete station?</source>
      <translation variants="no">是否刪除電台？</translation>
    </message>
    <message numerus="no" id="txt_rad_button_stations">
      <source>Stations</source>
      <translation variants="no">zh_tw #Station list</translation>
    </message>
    <message numerus="no" id="txt_rad_info_activate_radio_in_offline_mode">
      <source>Activate Fm Radio in off-line mode?</source>
      <translation variants="no">是否在離線模式下開啟收音機？</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_news">
      <source>News</source>
      <translation variants="yes">
        <lengthvariant priority="1">新聞</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_searching_local_stations_please_wait">
      <source>Searching local stations. Please wait.</source>
      <translation variants="no">當地電台掃描中</translation>
    </message>
    <message numerus="no" id="txt_rad_info_connect_wired_headset1">
      <source>Connect wired headset.</source>
      <translation variants="no">zh_tw #Connect wired headset</translation>
    </message>
    <message numerus="no" id="txt_rad_info_oldies_music">
      <source>Oldies Music</source>
      <translation variants="no">zh_tw #Oldies music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_personality">
      <source>Personality</source>
      <translation variants="no">zh_tw #Personality</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_phone_in">
      <source>Phone In</source>
      <translation variants="yes">
        <lengthvariant priority="1">Call-in節目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_classic_rock">
      <source>Classic rock</source>
      <translation variants="no">zh_tw #Classic rock</translation>
    </message>
    <message numerus="no" id="txt_rad_button_local_stations">
      <source>All stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">所有電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_val_l1_mhz">
      <source>%L1 MHz</source>
      <translation variants="no">%L1兆赫</translation>
    </message>
    <message numerus="no" id="txt_fmradio_info_fm_radio_could_not_be_started">
      <source>FM Radio could not be started. </source>
      <translation variants="no">無法開啟收音機</translation>
    </message>
    <message numerus="no" id="txt_rad_list_seeking">
      <source>Seeking</source>
      <translation variants="no">zh_tw #Scanning</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_connect_wired_headset">
      <source>Connect wired headset.</source>
      <translation variants="no">請連接有線耳機</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_rock_music">
      <source>Rock Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">搖滾樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_national_music">
      <source>National Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">民族音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_oldies_music">
      <source>Oldies Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">老歌</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_other_music">
      <source>Other Music</source>
      <translation variants="no">zh_tw #Other music</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_add_to_favourites">
      <source>Add to favourites</source>
      <translation variants="no">加入至我的最愛</translation>
    </message>
    <message numerus="no" id="txt_rad_list_unknown">
      <source>(Unknown) - %1</source>
      <translation variants="no">(不明)%1</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_pop_music">
      <source>Pop Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">流行音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_sport">
      <source>Sport</source>
      <translation variants="yes">
        <lengthvariant priority="1">運動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_personality">
      <source>Personality</source>
      <translation variants="yes">
        <lengthvariant priority="1">人格</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_serious_classical">
      <source>Serious classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">嚴肅古典音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">zh_tw #FM Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_search_from_other_store">
      <source>Search from %1</source>
      <translation variants="no">zh_tw #Search from %1</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft">
      <source>Soft</source>
      <translation variants="yes">
        <lengthvariant priority="1">軟調音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_opt_search_all_stations">
      <source>Search all stations</source>
      <translation variants="no">掃描電台</translation>
    </message>
    <message numerus="no" id="txt_rad_title_fm_radio">
      <source>FM Radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">收音機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_documentary">
      <source>Documentary</source>
      <translation variants="no">zh_tw #Documentary</translation>
    </message>
    <message numerus="no" id="txt_rad_info_country_music">
      <source>Country Music</source>
      <translation variants="no">zh_tw #Country music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_social_affairs">
      <source>Social Affairs</source>
      <translation variants="no">zh_tw #Social affairs</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_other_music">
      <source>Other Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">其他音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_music">
      <source>Religious music</source>
      <translation variants="no">zh_tw #Religious music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_education">
      <source>Education</source>
      <translation variants="no">zh_tw #Education</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_favourite_stations">
      <source>(No favourite stations)</source>
      <translation variants="no">zh_tw #(no favourites)</translation>
    </message>
    <message numerus="no" id="txt_rad_info_continue_using_the_radio_in_offline">
      <source>Continue using the Radio in off-line mode?</source>
      <translation variants="no">是否繼續在離線模式下使用收音機？</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_travel">
      <source>Travel</source>
      <translation variants="yes">
        <lengthvariant priority="1">旅遊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">古典</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_easy_listening">
      <source>Easy Listening</source>
      <translation variants="no">zh_tw #Easy listening</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_no_stations_found_try_searching">
      <source>No stations found. Try searching stations by scrolling the frequency strip.</source>
      <translation variants="no">找不到電台。請再試一次使用頻率列。</translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm_test">
      <source>Alarm Test</source>
      <translation variants="no">zh_tw #Alarm test</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_documentary">
      <source>Documentary</source>
      <translation variants="yes">
        <lengthvariant priority="1">紀錄節目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_pop_music">
      <source>Pop Music</source>
      <translation variants="no">zh_tw #Pop music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_current_affairs">
      <source>Current affairs</source>
      <translation variants="no">zh_tw #Current affairs</translation>
    </message>
  </context>
</TS>