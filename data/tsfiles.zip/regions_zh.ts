<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_region_GB">
      <source>United Kingdom</source>
      <translation variants="no">zh #United Kingdom</translation>
    </message>
    <message numerus="no" id="txt_region_FR">
      <source>France</source>
      <translation variants="no">zh #France</translation>
    </message>
    <message numerus="no" id="txt_region_DE">
      <source>Deutschland</source>
      <translation variants="no">zh #Deutschland</translation>
    </message>
    <message numerus="no" id="txt_region_ES">
      <source>España</source>
      <translation variants="no">zh #España</translation>
    </message>
    <message numerus="no" id="txt_region_IT">
      <source>Italia</source>
      <translation variants="no">zh #Italia</translation>
    </message>
    <message numerus="no" id="txt_region_SE">
      <source>Sverige</source>
      <translation variants="no">zh #Sverige</translation>
    </message>
    <message numerus="no" id="txt_region_DK">
      <source>Danmark</source>
      <translation variants="no">zh #Danmark</translation>
    </message>
    <message numerus="no" id="txt_region_NO">
      <source>Norge</source>
      <translation variants="no">zh #Norge</translation>
    </message>
    <message numerus="no" id="txt_region_FI">
      <source>Suomi</source>
      <translation variants="no">zh #Suomi</translation>
    </message>
    <message numerus="no" id="txt_region_US">
      <source>United States</source>
      <translation variants="no">zh #United States</translation>
    </message>
    <message numerus="no" id="txt_region_PT">
      <source>Portugal</source>
      <translation variants="no">zh #Portugal</translation>
    </message>
    <message numerus="no" id="txt_region_TR">
      <source>Türkiye</source>
      <translation variants="no">zh #Türkiye</translation>
    </message>
    <message numerus="no" id="txt_region_IS">
      <source>Ísland</source>
      <translation variants="no">zh #Ísland</translation>
    </message>
    <message numerus="no" id="txt_region_RU">
      <source>Россия</source>
      <translation variants="no">zh #Россия</translation>
    </message>
    <message numerus="no" id="txt_region_HU">
      <source>Magyarország</source>
      <translation variants="no">zh #Magyarország</translation>
    </message>
    <message numerus="no" id="txt_region_NL">
      <source>Nederland</source>
      <translation variants="no">zh #Nederland</translation>
    </message>
    <message numerus="no" id="txt_region_CZ">
      <source>Český</source>
      <translation variants="no">zh #Český</translation>
    </message>
    <message numerus="no" id="txt_region_SK">
      <source>Slovensko</source>
      <translation variants="no">zh #Slovensko</translation>
    </message>
    <message numerus="no" id="txt_region_PL">
      <source>Polska</source>
      <translation variants="no">zh #Polska</translation>
    </message>
    <message numerus="no" id="txt_region_SI">
      <source>Slovenija</source>
      <translation variants="no">zh #Slovenija</translation>
    </message>
    <message numerus="no" id="txt_region_TW">
      <source>台灣</source>
      <translation variants="no">zh #台灣</translation>
    </message>
    <message numerus="no" id="txt_region_HK">
      <source>香港</source>
      <translation variants="no">zh #香港</translation>
    </message>
    <message numerus="no" id="txt_region_CN">
      <source>中国</source>
      <translation variants="no">zh #中国</translation>
    </message>
    <message numerus="no" id="txt_region_JP">
      <source>日本</source>
      <translation variants="no">zh #日本</translation>
    </message>
    <message numerus="no" id="txt_region_TH">
      <source>ประเทศไทย</source>
      <translation variants="no">zh #ประเทศไทย</translation>
    </message>
    <message numerus="no" id="txt_region_AE">
      <source>الإمارات العربية المتحدة</source>
      <translation variants="no">zh #الإمارات العربية المتحدة</translation>
    </message>
    <message numerus="no" id="txt_region_PH">
      <source>Pilipinas</source>
      <translation variants="no">zh #Pilipinas</translation>
    </message>
    <message numerus="no" id="txt_region_BG">
      <source>България</source>
      <translation variants="no">zh #България</translation>
    </message>
    <message numerus="no" id="txt_region_HR">
      <source>Hrvatska</source>
      <translation variants="no">zh #Hrvatska</translation>
    </message>
    <message numerus="no" id="txt_region_EE">
      <source>Eesti</source>
      <translation variants="no">zh #Eesti</translation>
    </message>
    <message numerus="no" id="txt_region_IR">
      <source>ایران</source>
      <translation variants="no">zh #ایران</translation>
    </message>
    <message numerus="no" id="txt_region_CA">
      <source>Canada</source>
      <translation variants="no">zh #Canada</translation>
    </message>
    <message numerus="no" id="txt_region_GR">
      <source>Ελλάδα</source>
      <translation variants="no">zh #Ελλάδα</translation>
    </message>
    <message numerus="no" id="txt_region_IL">
      <source>ישראל</source>
      <translation variants="no">zh #ישראל</translation>
    </message>
    <message numerus="no" id="txt_region_IN">
      <source>भारत</source>
      <translation variants="no">zh #भारत</translation>
    </message>
    <message numerus="no" id="txt_region_ID">
      <source>Indonesia</source>
      <translation variants="no">zh #Indonesia</translation>
    </message>
    <message numerus="no" id="txt_region_KR">
      <source>한국</source>
      <translation variants="no">zh #한국</translation>
    </message>
    <message numerus="no" id="txt_region_LV">
      <source>Latvija</source>
      <translation variants="no">zh #Latvija</translation>
    </message>
    <message numerus="no" id="txt_region_LT">
      <source>Lietuva</source>
      <translation variants="no">zh #Lietuva</translation>
    </message>
    <message numerus="no" id="txt_region_MY">
      <source>Malaysia</source>
      <translation variants="no">zh #Malaysia</translation>
    </message>
    <message numerus="no" id="txt_region_BR">
      <source>Brasil</source>
      <translation variants="no">zh #Brasil</translation>
    </message>
    <message numerus="no" id="txt_region_RO">
      <source>România</source>
      <translation variants="no">zh #România</translation>
    </message>
    <message numerus="no" id="txt_region_RS">
      <source>Srbija</source>
      <translation variants="no">zh #Srbija</translation>
    </message>
    <message numerus="no" id="txt_region_UA">
      <source>Україна</source>
      <translation variants="no">zh #Україна</translation>
    </message>
    <message numerus="no" id="txt_region_PK">
      <source>Pakistan</source>
      <translation variants="no">zh #Pakistan</translation>
    </message>
    <message numerus="no" id="txt_region_VN">
      <source>Việt Nam</source>
      <translation variants="no">zh #Việt Nam</translation>
    </message>
  </context>
</TS>