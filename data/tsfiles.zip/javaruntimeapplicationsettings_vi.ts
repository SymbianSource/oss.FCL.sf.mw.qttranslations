<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_sett_setlabel_permission">
      <source>Permission type</source>
      <translation variants="no">Truy cập ứng dụng</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_blanket">
      <source>Blanket</source>
      <translation variants="yes">
        <lengthvariant priority="1">Luôn cho phép</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_net_access">
      <source>Net access</source>
      <translation variants="no">Truy cập mạng</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_auth">
      <source>Authentication</source>
      <translation variants="no">Xác thực</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_url_start">
      <source>URL start</source>
      <translation variants="no">Truy cập web</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_app_auto_invoc">
      <source>Application auto invocation</source>
      <translation variants="no">Tự động khởi động ứng dụng</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_no">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk">
      <source>On-screen-keypad</source>
      <translation variants="no">Bàn phím</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_smartcard">
      <source>Smart card communication</source>
      <translation variants="no">Thẻ thông minh</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_write_data">
      <source>Write user data</source>
      <translation variants="no">Người dùng viết</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_restricted_messaging">
      <source>Restricted messaging</source>
      <translation variants="no">H.chế t.nhắn</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_call_control">
      <source>Call control</source>
      <translation variants="no">Kiểm soát cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_oneshot">
      <source>Oneshot</source>
      <translation variants="yes">
        <lengthvariant priority="1">Luôn hỏi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_nfc_write_access">
      <source>NFC Write access</source>
      <translation variants="no">Phát NFC</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_landmarks">
      <source>Landmarks</source>
      <translation variants="no">Cột mốc</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_messaging">
      <source>Messaging</source>
      <translation variants="no">Nhắn tin</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_navigation">
      <source>Navigation keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">Các phím di chuyển</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_game">
      <source>Game keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">Các phím trò chơi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_mm_record">
      <source>Multimedia recording</source>
      <translation variants="no">Đa phương tiện</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_low_level_net_access">
      <source>Low level network access</source>
      <translation variants="no">Truy cập mạng cấp thấp</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_broadcast">
      <source>Broadcast</source>
      <translation variants="no">Dữ liệu người dùng TV</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_session">
      <source>Session</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉ hỏi lần đầu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_user_defined">
      <source>User defined</source>
      <translation variants="no">Người dùng xác định</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level">
      <source>Security warnings</source>
      <translation variants="no">Cảnh báo</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_read_data">
      <source>Read user data</source>
      <translation variants="no">Người dùng đọc</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_local_conn">
      <source>Local connectivity</source>
      <translation variants="no">Kết nối</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_location">
      <source>Location</source>
      <translation variants="no">Định vị</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_default">
      <source>Default</source>
      <translation variants="no">Mặc định</translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hủy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_note_security_warn">
      <source>Security warning</source>
      <translation variants="no">Cảnh báo bảo mật</translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_warn">
      <source>Changing this setting item will cause changes in other settings. Continue? </source>
      <translation variants="no">Thay đổi cài đặt này sẽ gây ra các thay đổi trong cài đặt khác. Tiếp tục?</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_sec">
      <source>Choosing this item may cause your privacy to be compromised. Continue? </source>
      <translation variants="no">Cài đặt đã chọn có thể dẫn đến việc quyền riêng tư của bạn bị xâm hại. Tiếp tục?</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_net">
      <source>Choosing this item may result in compromised privacy or increased network usage costs. Continue? </source>
      <translation variants="no">Cài đặt đã chọn có thể dẫn đến việc quyền riêng tư bị xâm hại hoặc cước phí sử dụng mạng tăng. Tiếp tục?</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_net">
      <source>Allowing these permissions may result in compromised privacy or increased network usage costs.</source>
      <translation variants="no">Cho phép những quyền này có thể dẫn đến việc quyền riêng tư bị xâm hại hoặc cước phí sử dụng mạng tăng.</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_sec">
      <source>Allowing these permissions may result in compromised privacy.</source>
      <translation variants="no">Cho phép những quyền này có thể dẫn đến việc quyền riêng tư bị xâm hại</translation>
    </message>
    <message numerus="no" id="txt_java_sett_subhead_security">
      <source>Security</source>
      <translation variants="no">Bảo mật</translation>
    </message>
    <message numerus="no" id="txt_java_sett_subhead_general">
      <source>General</source>
      <translation variants="no">Bình thường</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_settings_not_available">
      <source>Settings not available</source>
      <translation variants="no">vi #(settings unavailable)</translation>
    </message>
  </context>
</TS>