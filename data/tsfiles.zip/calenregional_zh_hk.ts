<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_info_lunar_year">
      <source>%1 %2</source>
      <translation variants="no">zh_hk #%1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_dog">
      <source>Year of the Dog</source>
      <translation variants="no">zh_hk #Year of the Dog</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_reng">
      <source>Reng</source>
      <translation variants="no">zh_hk #Reng</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_cale_separator">
      <source>, </source>
      <translation variants="no">zh_hk #, </translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_qiu_fen">
      <source>Qiu Fen</source>
      <translation variants="no">zh_hk #Qiu Fen</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_chun">
      <source>Li Chun</source>
      <translation variants="no">zh_hk #Li Chun</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_pig">
      <source>Year of the Pig</source>
      <translation variants="no">zh_hk #Year of the Pig</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_ding">
      <source>Ding</source>
      <translation variants="no">zh_hk #Ding</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_man">
      <source>Xiao Man</source>
      <translation variants="no">zh_hk #Xiao Man</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_gui">
      <source>Gui</source>
      <translation variants="no">zh_hk #Gui</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xing">
      <source>Xing</source>
      <translation variants="no">zh_hk #Xing</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_chou">
      <source>Chou</source>
      <translation variants="no">zh_hk #Chou</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_dragon">
      <source>Year of the Dragon</source>
      <translation variants="no">zh_hk #Year of the Dragon</translation>
    </message>
    <message numerus="no" id="txt_calendar_gregorian_date">
      <source>Gregorian date:</source>
      <translation variants="no">zh_hk #Gregorian date:</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_double_fest">
      <source>Double ninth festival</source>
      <translation variants="no">zh_hk #Double ninth festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_tiger">
      <source>Year of the Tiger</source>
      <translation variants="no">zh_hk #Year of the Tiger</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_rat">
      <source>Year of the Rat</source>
      <translation variants="no">zh_hk #Year of the Rat</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_jia">
      <source>Jia</source>
      <translation variants="no">zh_hk #Jia</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_rooster">
      <source>Year of the Rooster</source>
      <translation variants="no">zh_hk #Year of the Rooster</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_rabbit">
      <source>Year of the Rabbit</source>
      <translation variants="no">zh_hk #Year of the Rabbit</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_bing">
      <source>Bing</source>
      <translation variants="no">zh_hk #Bing</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_eigth_day_fest">
      <source>Eighth day of twelfth month festival</source>
      <translation variants="no">zh_hk #Eighth day of twelfth month festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_si">
      <source>Si</source>
      <translation variants="no">zh_hk #Si</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_han_lu">
      <source>Han Lu</source>
      <translation variants="no">zh_hk #Han Lu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_bai_lu">
      <source>Bai Lu</source>
      <translation variants="no">zh_hk #Bai Lu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_geng">
      <source>Geng</source>
      <translation variants="no">zh_hk #Geng</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_da_shu">
      <source>Da Shu</source>
      <translation variants="no">zh_hk #Da Shu</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_full_date">
      <source>%1%2</source>
      <translation variants="no">zh_hk #%1%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_qiu">
      <source>Li Qiu</source>
      <translation variants="no">zh_hk #Li Qiu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_mid_autumn_fest">
      <source>Mid autumn festival</source>
      <translation variants="no">zh_hk #Mid autumn festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_yi">
      <source>Yi</source>
      <translation variants="no">zh_hk #Yi</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_dong_zhi">
      <source>Dong Zhi</source>
      <translation variants="no">zh_hk #Dong Zhi</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_ghost_fest">
      <source>Ghost festival</source>
      <translation variants="no">zh_hk #Ghost festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_snake">
      <source>Year of the Snake</source>
      <translation variants="no">zh_hk #Year of the Snake</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_han">
      <source>Xiao Han</source>
      <translation variants="no">zh_hk #Xiao Han</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_ox">
      <source>Year of the Ox</source>
      <translation variants="no">zh_hk #Year of the Ox</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_xue">
      <source>Xiao Xue</source>
      <translation variants="no">zh_hk #Xiao Xue</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_shaung_jiang">
      <source>Shaung Jiang</source>
      <translation variants="no">zh_hk #Shaung Jiang</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_leap_date">
      <source>%1%2</source>
      <translation variants="no">zh_hk #%1%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_yin">
      <source>Yin</source>
      <translation variants="no">zh_hk #Yin</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_shen">
      <source>Shen</source>
      <translation variants="no">zh_hk #Shen</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xia_zhi">
      <source>Xia Zhi</source>
      <translation variants="no">zh_hk #Xia Zhi</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_date">
      <source>%1%2</source>
      <translation variants="no">zh_hk #%1%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_xia">
      <source>Li Xia</source>
      <translation variants="no">zh_hk #Li Xia</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_gu_yu">
      <source>Gu Yu</source>
      <translation variants="no">zh_hk #Gu Yu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_sheep">
      <source>Year of the Sheep</source>
      <translation variants="no">zh_hk #Year of the Sheep</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_mao">
      <source>Mao</source>
      <translation variants="no">zh_hk #Mao</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_you">
      <source>You</source>
      <translation variants="no">zh_hk #You</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_zi">
      <source>Zi</source>
      <translation variants="no">zh_hk #Zi</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_qing_ming">
      <source>Qing Ming</source>
      <translation variants="no">zh_hk #Qing Ming</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_festival">
      <source>Festival:</source>
      <translation variants="no">zh_hk #Festival:</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_lunar_calendar">
      <source>Lunar calendar</source>
      <translation variants="no">zh_hk #Lunar calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_da_xue">
      <source>Da Xue</source>
      <translation variants="no">zh_hk #Da Xue</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_mang_zhong">
      <source>Mang Zhong</source>
      <translation variants="no">zh_hk #Mang Zhong</translation>
    </message>
    <message numerus="no" id="txt_calendar_solar_term">
      <source>Solar term:</source>
      <translation variants="no">zh_hk #Solar term:</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_yu_shui">
      <source>Yu Shui</source>
      <translation variants="no">zh_hk #Yu Shui</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_ji">
      <source>Ji</source>
      <translation variants="no">zh_hk #Ji</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_lantern_fest">
      <source>Lantern festival</source>
      <translation variants="no">zh_hk #Lantern festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_seventh_night_fest">
      <source>Seventh night festival</source>
      <translation variants="no">zh_hk #Seventh night festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_animal_year">
      <source>Animal year:</source>
      <translation variants="no">zh_hk #Animal year:</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_wu">
      <source>Wu</source>
      <translation variants="no">zh_hk #Wu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_monkey">
      <source>Year of the Monkey</source>
      <translation variants="no">zh_hk #Year of the Monkey</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_new_year_fest">
      <source>New year's eve</source>
      <translation variants="no">zh_hk #New year's eve</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_da_han">
      <source>Da Han</source>
      <translation variants="no">zh_hk #Da Han</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_horse">
      <source>Year of the Horse</source>
      <translation variants="no">zh_hk #Year of the Horse</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_wei">
      <source>Wei</source>
      <translation variants="no">zh_hk #Wei</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_dong">
      <source>Li Dong</source>
      <translation variants="no">zh_hk #Li Dong</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_spring_fest">
      <source>Spring festival</source>
      <translation variants="no">zh_hk #Spring festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_123242526">
      <source>%1%2%3%2%4%2%5%2%6</source>
      <translation variants="no">zh_hk #%1%2%3%2%4%2%5%2%6</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_shu">
      <source>Xiao Shu</source>
      <translation variants="no">zh_hk #Xiao Shu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_chen">
      <source>Chen</source>
      <translation variants="no">zh_hk #Chen</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_hai">
      <source>Hai</source>
      <translation variants="no">zh_hk #Hai</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_xu">
      <source>Xu</source>
      <translation variants="no">zh_hk #Xu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_jing_zhe">
      <source>Jing Zhe</source>
      <translation variants="no">zh_hk #Jing Zhe</translation>
    </message>
    <message numerus="no" id="txt_calendar_lunar_date">
      <source>Lunar date:</source>
      <translation variants="no">zh_hk #Lunar date:</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_chu_shu">
      <source>Chu Shu</source>
      <translation variants="no">zh_hk #Chu Shu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_dragon_fest">
      <source>Dragon boat festival</source>
      <translation variants="no">zh_hk #Dragon boat festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_wu">
      <source>Wu</source>
      <translation variants="no">zh_hk #Wu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_chun_fen">
      <source>Chun Fen</source>
      <translation variants="no">zh_hk #Chun Fen</translation>
    </message>
  </context>
</TS>