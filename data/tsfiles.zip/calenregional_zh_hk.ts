<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_rabbit">
      <source>Year of the Rabbit</source>
      <translation variants="no">兔年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_gui">
      <source>Gui</source>
      <translation variants="no">癸</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_seventh_night_fest">
      <source>Seventh night festival</source>
      <translation variants="no">七夕</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xing">
      <source>Xing</source>
      <translation variants="no">辛</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_wu">
      <source>Wu</source>
      <translation variants="no">午</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_mid_autumn_fest">
      <source>Mid autumn festival</source>
      <translation variants="no">中秋節</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_eigth_day_fest">
      <source>Eighth day of twelfth month festival</source>
      <translation variants="no">臘八節</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_shu">
      <source>Xiao Shu</source>
      <translation variants="no">小暑</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_monkey">
      <source>Year of the Monkey</source>
      <translation variants="no">猴年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_chou">
      <source>Chou</source>
      <translation variants="no">丑</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_new_year_fest">
      <source>New year's eve</source>
      <translation variants="no">除夕</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_wu">
      <source>Wu</source>
      <translation variants="no">午</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_reng">
      <source>Reng</source>
      <translation variants="no">壬</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_shaung_jiang">
      <source>Shaung Jiang</source>
      <translation variants="no">霜降</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_leap_date">
      <source>%1L%2</source>
      <translation variants="no">%[33]1月(閏)，%[32]2日</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_mao">
      <source>Mao</source>
      <translation variants="no">卯</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_you">
      <source>You</source>
      <translation variants="no">酉</translation>
    </message>
    <message numerus="no" id="txt_calendar_gregorian_date">
      <source>Gregorian date:</source>
      <translation variants="no">陽曆日期：</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_bai_lu">
      <source>Bai Lu</source>
      <translation variants="no">白露</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_shen">
      <source>Shen</source>
      <translation variants="no">申</translation>
    </message>
    <message numerus="no" id="txt_calendar_solar_term">
      <source>Solar term:</source>
      <translation variants="no">節氣：</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_chun">
      <source>Li Chun</source>
      <translation variants="no">立春</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_ghost_fest">
      <source>Ghost festival</source>
      <translation variants="no">中元節</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_horse">
      <source>Year of the Horse</source>
      <translation variants="no">馬年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_jing_zhe">
      <source>Jing Zhe</source>
      <translation variants="no">驚蟄</translation>
    </message>
    <message numerus="no" id="txt_calendar_lunar_date">
      <source>Lunar date:</source>
      <translation variants="no">農曆日期：</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_qing_ming">
      <source>Qing Ming</source>
      <translation variants="no">清明</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_rat">
      <source>Year of the Rat</source>
      <translation variants="no">鼠年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_da_shu">
      <source>Da Shu</source>
      <translation variants="no">大暑</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_dragon_fest">
      <source>Dragon boat festival</source>
      <translation variants="no">端午節</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_wei">
      <source>Wei</source>
      <translation variants="no">未</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_pig">
      <source>Year of the Pig</source>
      <translation variants="no">豬年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_lantern_fest">
      <source>Lantern festival</source>
      <translation variants="no">元宵節</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_festival">
      <source>Festival:</source>
      <translation variants="no">節日：</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_jia">
      <source>Jia</source>
      <translation variants="no">甲</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_rooster">
      <source>Year of the Rooster</source>
      <translation variants="no">雞年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_spring_fest">
      <source>Spring festival</source>
      <translation variants="no">春節</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_date">
      <source>%1%2</source>
      <translation variants="no">%[34]1月，%[33]2日</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_xia">
      <source>Li Xia</source>
      <translation variants="no">立夏</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_han">
      <source>Xiao Han</source>
      <translation variants="no">小寒</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_mang_zhong">
      <source>Mang Zhong</source>
      <translation variants="no">芒種</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_gu_yu">
      <source>Gu Yu</source>
      <translation variants="no">穀雨</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_ox">
      <source>Year of the Ox</source>
      <translation variants="no">牛年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_bing">
      <source>Bing</source>
      <translation variants="no">丙</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_xue">
      <source>Xiao Xue</source>
      <translation variants="no">小雪</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_qiu">
      <source>Li Qiu</source>
      <translation variants="no">立秋</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_year">
      <source>%1 %2</source>
      <translation variants="no">%[35]1%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_dog">
      <source>Year of the Dog</source>
      <translation variants="no">狗年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_sheep">
      <source>Year of the Sheep</source>
      <translation variants="no">羊年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_chen">
      <source>Chen</source>
      <translation variants="no">辰</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_dragon">
      <source>Year of the Dragon</source>
      <translation variants="no">龍年</translation>
    </message>
    <message numerus="no" id="txt_calendar_animal_year">
      <source>Animal year:</source>
      <translation variants="no">生肖：</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_hai">
      <source>Hai</source>
      <translation variants="no">亥</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_si">
      <source>Si</source>
      <translation variants="no">巳</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_xu">
      <source>Xu</source>
      <translation variants="no">戌</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_yi">
      <source>Yi</source>
      <translation variants="no">乙</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_dong_zhi">
      <source>Dong Zhi</source>
      <translation variants="no">冬至</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_cale_separator">
      <source>, </source>
      <translation variants="no">、</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_han_lu">
      <source>Han Lu</source>
      <translation variants="no">寒露</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_da_han">
      <source>Da Han</source>
      <translation variants="no">大寒</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_double_fest">
      <source>Double ninth festival</source>
      <translation variants="no">重陽節</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_yin">
      <source>Yin</source>
      <translation variants="no">寅</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_123242526">
      <source>%1%2%3%2%4%2%5%2%6</source>
      <translation variants="no">%[38]1%[38]2%[38]3%[38]2%[38]4%[38]2%[37]5%[37]2%6</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_qiu_fen">
      <source>Qiu Fen</source>
      <translation variants="no">秋分</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_chun_fen">
      <source>Chun Fen</source>
      <translation variants="no">春分</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_geng">
      <source>Geng</source>
      <translation variants="no">庚</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_zi">
      <source>Zi</source>
      <translation variants="no">子</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_tiger">
      <source>Year of the Tiger</source>
      <translation variants="no">虎年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_chu_shu">
      <source>Chu Shu</source>
      <translation variants="no">處暑</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_yu_shui">
      <source>Yu Shui</source>
      <translation variants="no">雨水</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_ding">
      <source>Ding</source>
      <translation variants="no">丁</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_snake">
      <source>Year of the Snake</source>
      <translation variants="no">蛇年</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_ji">
      <source>Ji</source>
      <translation variants="no">己</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xia_zhi">
      <source>Xia Zhi</source>
      <translation variants="no">夏至</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_dong">
      <source>Li Dong</source>
      <translation variants="no">立冬</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_da_xue">
      <source>Da Xue</source>
      <translation variants="no">大雪</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_man">
      <source>Xiao Man</source>
      <translation variants="no">小滿</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_full_date">
      <source>%1%2</source>
      <translation variants="no">%[35]1，%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_lunar_calendar">
      <source>Lunar calendar</source>
      <translation variants="no">農曆</translation>
    </message>
  </context>
</TS>