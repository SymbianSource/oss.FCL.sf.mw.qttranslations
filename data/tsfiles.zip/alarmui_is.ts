<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="is">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Snooze</source>
      <translation variants="yes">
        <lengthvariant priority="1">Blunda</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Clock alarm</source>
      <translation variants="no">Vekjaraklukka</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snoozed_for_ln_minute">
      <source>Alarm snoozed for %Ln minutes</source>
      <translation>
        <numerusform plurality="a">Vekjarinn blundar í %Ln mínútu</numerusform>
        <numerusform plurality="b">Vekjarinn blundar í %Ln mínútur</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hljóð af</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Switch phone on ?</source>
      <translation variants="no">Kveikja á tæki?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Calendar alarm</source>
      <translation variants="no">Dagbókaráminning</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_stop">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">Stöðva</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>To-do note</source>
      <translation variants="no">Verkefnisáminning</translation>
    </message>
  </context>
</TS>