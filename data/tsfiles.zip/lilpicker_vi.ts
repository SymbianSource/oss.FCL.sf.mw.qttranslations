<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_lint_list_no_location_entries_present">
      <source>No Location entries present</source>
      <translation variants="yes">
        <lengthvariant priority="1">(không có vị trí)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_title_select_location">
      <source>Select location</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn vị trí</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_places">
      <source>Places</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa điểm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_button_done">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xong</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ liên hệ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_results">
      <source>No results</source>
      <translation variants="yes">
        <lengthvariant priority="1">(không có kết quả phù hợp)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by_sub_type">
      <source>Type</source>
      <translation variants="no">Loại</translation>
    </message>
    <message numerus="no" id="txt_lint_opt_arrange">
      <source>Arrange</source>
      <translation variants="no">Sắp xếp</translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by">
      <source>Sort by </source>
      <translation variants="no">Sắp xếp theo</translation>
    </message>
    <message numerus="no" id="txt_lint_menu_details">
      <source>Details</source>
      <translation variants="no">Chi tiết</translation>
    </message>
    <message numerus="no" id="txt_lint_dblist_places_val_no_items">
      <source>No items</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có mục</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_calendar_locations">
      <source>Calendar locations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Vị trí trên lịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_lint_list_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">%Ln mục</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by_sub_ascending">
      <source>Ascending</source>
      <translation variants="no">Tăng dần</translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by_sub_descending">
      <source>Descending</source>
      <translation variants="no">Giảm dần</translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_places">
      <source>Places</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa điểm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_map_searches">
      <source>Map searches</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tìm kiếm trên bản đồ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_menu_select">
      <source>Select</source>
      <translation variants="no">Chọn</translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_calendar_event_locations">
      <source>Calendar locations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Vị trí trên lịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_recent_map_searches">
      <source>Map searches</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tìm kiếm trên bản đồ</lengthvariant>
      </translation>
    </message>
  </context>
</TS>