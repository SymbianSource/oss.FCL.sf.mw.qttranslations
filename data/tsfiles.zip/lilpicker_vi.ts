<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_lint_button_done">
      <source>Done</source>
      <translation variants="no">Xong</translation>
    </message>
    <message numerus="no" id="txt_lint_list_descending">
      <source>Descending</source>
      <translation variants="no">Giảm dần</translation>
    </message>
    <message numerus="no" id="txt_lint_list_sort_by">
      <source>Sort by </source>
      <translation variants="no">Sắp xếp theo</translation>
    </message>
    <message numerus="no" id="txt_lint_list_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="no">Địa chỉ liên hệ</translation>
    </message>
    <message numerus="no" id="txt_lint_list_remove_thumbnail">
      <source>Remove thumbnail</source>
      <translation variants="no">Xóa hình thu nhỏ</translation>
    </message>
    <message numerus="no" id="txt_lint_list_arrange">
      <source>Arrange</source>
      <translation variants="no">Sắp xếp</translation>
    </message>
    <message numerus="no" id="txt_lint_list_ascending">
      <source>Ascending</source>
      <translation variants="no">Tăng dần</translation>
    </message>
    <message numerus="no" id="txt_lint_list_type">
      <source>Type</source>
      <translation variants="no">Loại</translation>
    </message>
    <message numerus="no" id="txt_lint_list_places">
      <source>Places</source>
      <translation variants="no">Vị trí</translation>
    </message>
    <message numerus="no" id="txt_lint_list_recent_map_searches">
      <source>Recent map searches</source>
      <translation variants="no">Tìm kiếm bản đồ gần đây</translation>
    </message>
    <message numerus="no" id="txt_lint_list_details">
      <source>Details</source>
      <translation variants="no">Chi tiết</translation>
    </message>
    <message numerus="no" id="txt_lint_list_calendar_event_locations">
      <source>Calendar event locations</source>
      <translation variants="no">Vị trí mục lịch</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_results">
      <source>No results</source>
      <translation variants="no">(không có kết quả)</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_location_entries_present">
      <source>No Location entries present</source>
      <translation variants="no">(không có vị trí)</translation>
    </message>
    <message numerus="no" id="txt_lint_title_select_location">
      <source>Select location</source>
      <translation variants="no">Chọn vị trí</translation>
    </message>
  </context>
</TS>