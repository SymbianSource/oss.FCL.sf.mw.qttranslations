<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_list_reminder_time_date">
      <source>%1 %2</source>
      <translation variants="no">zh #%[23]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_fortnightly">
      <source>Repeats fortnightly</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Repeats fortnightly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_subject">
      <source>Subject:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Subject:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Delete repeated entry :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_meeting_date">
      <source>%1</source>
      <translation variants="no">zh #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_anniversary">
      <source>Anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Anniversary</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_until_1">
      <source>Until %1</source>
      <translation variants="no">zh #Until %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_monthly">
      <source>Repeats monthly</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Repeats monthly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_workdays">
      <source>Repeats workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Repeats on workdays</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_delete">
      <source>Delete</source>
      <translation variants="no">zh #Delete</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_start_time_date">
      <source>%1 %2</source>
      <translation variants="no">zh #%[23]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Delete anniversary?</source>
      <translation variants="no">zh #Delete anniversary?</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_reminder_time">
      <source>%1</source>
      <translation variants="no">zh #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_weekly">
      <source>Repeats weekly</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Repeats weekly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_from_1">
      <source>From %1</source>
      <translation variants="no">zh #From %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily">
      <source>Repeats daily</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Repeats daily</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Description:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Edit :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">zh #All occurences</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_event">
      <source>Event</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Entry</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_occasion">
      <source>Occasion:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Occasion:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_edit">
      <source>Edit</source>
      <translation variants="no">zh #Edit</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Unnamed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">zh #Delete meeting?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Completed date:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">zh #Mark as done</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #To-do note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_send">
      <source>Send</source>
      <translation variants="no">zh #Send</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_save_to_calendar">
      <source>Save to calendar</source>
      <translation variants="no">zh #Save to Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Meeting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">zh #Delete to-do note?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_end_time_date">
      <source>- %1 %2</source>
      <translation variants="no">zh #- %[98]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">zh #Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_start_end_time">
      <source>%1 - %2</source>
      <translation variants="no">zh #%[22]1 - %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">zh #This occurrence only</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_yearly">
      <source>Repeats Yearly</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Repeats yearly</lengthvariant>
      </translation>
    </message>
  </context>
</TS>