<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="de">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Snooze</source>
      <translation variants="yes">
        <lengthvariant priority="1">Spät. erinnern</lengthvariant>
        <lengthvariant priority="2">Später erinnern</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Clock alarm</source>
      <translation variants="no">Weckton</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snoozed_for_ln_minute">
      <source>Alarm snoozed for %Ln minutes</source>
      <translation>
        <numerusform plurality="a">Erinnerung für %Ln Minute abgestellt</numerusform>
        <numerusform plurality="b">Erinnerung für %Ln Minuten abgestellt</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lautlos</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Switch phone on ?</source>
      <translation variants="no">Gerät einschalten?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Calendar alarm</source>
      <translation variants="no">Kalendererinnerung</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_stop">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">Stopp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>To-do note</source>
      <translation variants="no">Aufgabenerinnerung</translation>
    </message>
  </context>
</TS>