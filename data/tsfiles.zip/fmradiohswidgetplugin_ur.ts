<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_rad_info_country_music_hs">
      <source>Country Music</source>
      <translation variants="no">ur #Country music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_easy_listening_hs">
      <source>Easy Listening</source>
      <translation variants="no">ur #Easy listening</translation>
    </message>
    <message numerus="no" id="txt_rad_info_drama_hs">
      <source>Drama</source>
      <translation variants="no">ur #Drama</translation>
    </message>
    <message numerus="no" id="txt_rad_info_serious_classical_hs">
      <source>Serious classical</source>
      <translation variants="no">ur #Serious classical</translation>
    </message>
    <message numerus="no" id="txt_rad_info_talk_hs">
      <source>Talk</source>
      <translation variants="no">ur #Talk</translation>
    </message>
    <message numerus="no" id="txt_rad_info_activate_radio_in_offline_mode_hs">
      <source>Activate Fm Radio in off-line mode?</source>
      <translation variants="no">ur #Activate Radio in offline mode?</translation>
    </message>
    <message numerus="no" id="txt_rad_info_information_hs">
      <source>Information</source>
      <translation variants="no">ur #Information</translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm_hs">
      <source>Alarm</source>
      <translation variants="no">ur #Alarm</translation>
    </message>
    <message numerus="no" id="txt_rad_info_national_music_hs">
      <source>National Music</source>
      <translation variants="no">ur #National music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_science_hs">
      <source>Science</source>
      <translation variants="no">ur #Science</translation>
    </message>
    <message numerus="no" id="txt_rad_info_language_hs">
      <source>Language</source>
      <translation variants="no">ur #Language</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_hs">
      <source>Soft</source>
      <translation variants="no">ur #Soft</translation>
    </message>
    <message numerus="no" id="txt_rad_info_childrens_programmes_hs">
      <source>Children’s programmes</source>
      <translation variants="no">ur #Children’s programmes</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religion_hs">
      <source>Religion</source>
      <translation variants="no">ur #Religion</translation>
    </message>
    <message numerus="no" id="txt_rad_info_connect_wired_headset">
      <source>Connect wired headset.</source>
      <translation variants="no">ur #Connect wired headset.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_classic_rock_hs">
      <source>Classic rock</source>
      <translation variants="no">ur #Classic rock</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_talk_hs">
      <source>Religious talk</source>
      <translation variants="no">ur #Religious talk</translation>
    </message>
    <message numerus="no" id="txt_rad_info_news_hs">
      <source>News</source>
      <translation variants="no">ur #News</translation>
    </message>
    <message numerus="no" id="txt_rad_info_adult_hits_hs">
      <source>Adult hits</source>
      <translation variants="no">ur #Adult hits</translation>
    </message>
    <message numerus="no" id="txt_rad_info_rock_music_hs">
      <source>Rock Music</source>
      <translation variants="no">ur #Rock music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_finance_hs">
      <source>Finance</source>
      <translation variants="no">ur #Finance</translation>
    </message>
    <message numerus="no" id="txt_rad_info_travel_hs">
      <source>Travel</source>
      <translation variants="no">ur #Travel</translation>
    </message>
    <message numerus="no" id="txt_rad_info_social_affairs_hs">
      <source>Social Affairs</source>
      <translation variants="no">ur #Social affairs</translation>
    </message>
    <message numerus="no" id="txt_rad_info_personality_hs">
      <source>Personality</source>
      <translation variants="no">ur #Personality</translation>
    </message>
    <message numerus="no" id="txt_rad_info_rhythm_and_blues_hs">
      <source>Rhythm and blues</source>
      <translation variants="no">ur #Rhythm and blues</translation>
    </message>
    <message numerus="no" id="txt_rad_info_leisure_hs">
      <source>Leisure</source>
      <translation variants="no">ur #Leisure</translation>
    </message>
    <message numerus="no" id="txt_rad_info_light_classical_hs">
      <source>Light classical</source>
      <translation variants="no">ur #Light classical</translation>
    </message>
    <message numerus="no" id="txt_rad_info_oldies_music_hs">
      <source>Oldies Music</source>
      <translation variants="no">ur #Oldies music</translation>
    </message>
    <message numerus="no" id="txt_rad_list_l1_mhz">
      <source>%L1 Mhz</source>
      <translation variants="no">ur #%L1 MHz</translation>
    </message>
    <message numerus="no" id="txt_rad_info_culture_hs">
      <source>Culture</source>
      <translation variants="no">ur #Culture</translation>
    </message>
    <message numerus="no" id="txt_rad_info_phone_in_hs">
      <source>Phone In</source>
      <translation variants="no">ur #Phone-in</translation>
    </message>
    <message numerus="no" id="txt_rad_info_current_affairs_hs">
      <source>Current affairs</source>
      <translation variants="no">ur #Current affairs</translation>
    </message>
    <message numerus="no" id="txt_rad_info_classical_hs">
      <source>Classical</source>
      <translation variants="no">ur #Classical</translation>
    </message>
    <message numerus="no" id="txt_rad_info_jazz_music_hs">
      <source>Jazz Music</source>
      <translation variants="no">ur #Jazz music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_education_hs">
      <source>Education</source>
      <translation variants="no">ur #Education</translation>
    </message>
    <message numerus="no" id="txt_rad_info_sport_hs">
      <source>Sport</source>
      <translation variants="no">ur #Sport</translation>
    </message>
    <message numerus="no" id="txt_rad_list_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">ur #FM Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_info_pop_music_hs">
      <source>Pop Music</source>
      <translation variants="no">ur #Pop music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_top_40_hs">
      <source>Top 40</source>
      <translation variants="no">ur #Top 40</translation>
    </message>
    <message numerus="no" id="txt_rad_info_college_hs">
      <source>College</source>
      <translation variants="no">ur #College</translation>
    </message>
    <message numerus="no" id="txt_rad_info_weather_hs">
      <source>Weather</source>
      <translation variants="no">ur #Weather</translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm_test_hs">
      <source>Alarm Test</source>
      <translation variants="no">ur #Alarm test</translation>
    </message>
    <message numerus="no" id="txt_rad_info_varied_hs">
      <source>Varied</source>
      <translation variants="no">ur #Varied</translation>
    </message>
    <message numerus="no" id="txt_rad_info_other_music_hs">
      <source>Other Music</source>
      <translation variants="no">ur #Other music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rhythm_and_blues_hs">
      <source>Soft rhythm and blues</source>
      <translation variants="no">ur #Soft rhythm and blues</translation>
    </message>
    <message numerus="no" id="txt_rad_info_documentary_hs">
      <source>Documentary</source>
      <translation variants="no">ur #Documentary</translation>
    </message>
    <message numerus="no" id="txt_rad_info_public_hs">
      <source>Public</source>
      <translation variants="no">ur #Public</translation>
    </message>
    <message numerus="no" id="txt_rad_info_nostalgia_hs">
      <source>Nostalgia</source>
      <translation variants="no">ur #Nostalgia</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_music_hs">
      <source>Religious music</source>
      <translation variants="no">ur #Religious music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_folk_music_hs">
      <source>Folk Music</source>
      <translation variants="no">ur #Folk music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rock_hs">
      <source>Soft rock</source>
      <translation variants="no">ur #Soft rock</translation>
    </message>
  </context>
</TS>