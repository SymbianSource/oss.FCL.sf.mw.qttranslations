<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_connection_name_val_connection">
      <source>Connection</source>
      <translation variants="no">vi #Connection</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_operator_services">
      <source>Operator services</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dịch vụ nhà điều hành</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_intranet">
      <source>Intranet</source>
      <translation variants="yes">
        <lengthvariant priority="1">Intranet</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_internet">
      <source>Internet</source>
      <translation variants="yes">
        <lengthvariant priority="1">Internet</lengthvariant>
      </translation>
    </message>
  </context>
</TS>