<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_notes_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">zh_hk #Subject</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">zh_hk #Remove from favorites</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_saved">
      <source>Note saved</source>
      <translation variants="no">zh_hk #Note saved</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_note">
      <source>Delete note?</source>
      <translation variants="no">zh_hk #Delete note?</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">zh_hk #Delete To-do note?</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_new_note">
      <source>New note</source>
      <translation variants="no">zh_hk #New note</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">zh_hk #Remove description</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_new_todo">
      <source>New To-do</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #New To-do</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_dialog_delete">
      <source>Delete</source>
      <translation variants="no">zh_hk #Delete</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_todo">
      <source>To-do</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #To-do</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_title_due_date">
      <source>Due date</source>
      <translation variants="no">zh_hk #Due date</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">zh_hk #Due date</translation>
    </message>
    <message numerus="no" id="txt_notes_button_alarm_date">
      <source>0.02</source>
      <translation variants="no">zh_hk #0.02</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">zh_hk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="no">zh_hk #Mark as favorite</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_add_description">
      <source>Add description</source>
      <translation variants="no">zh_hk #Add description</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_todo_note_saved">
      <source>To-do note saved</source>
      <translation variants="no">zh_hk #To-do note saved</translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_normal">
      <source>Normal</source>
      <translation variants="no">zh_hk #Normal</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_note">
      <source>Note</source>
      <translation variants="no">zh_hk #Note</translation>
    </message>
    <message numerus="no" id="txt_notes_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="no">zh_hk #Alarm time</translation>
    </message>
    <message numerus="no" id="txt_notes_button_alarm_time">
      <source>0.01</source>
      <translation variants="no">zh_hk #0.01</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_val_description">
      <source>Description</source>
      <translation variants="no">zh_hk #Description</translation>
    </message>
    <message numerus="no" id="txt_notes_button_add_to_calendar">
      <source>Add to Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Add to Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="no">zh_hk #Make it as To-do note</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_new_note">
      <source>New note</source>
      <translation variants="no">zh_hk #New note</translation>
    </message>
    <message numerus="no" id="txt_notes_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_edit_time">
      <source>%1 %2</source>
      <translation variants="no">zh_hk #%1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_high">
      <source>High</source>
      <translation variants="no">zh_hk #High</translation>
    </message>
    <message numerus="no" id="txt_notes_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="no">zh_hk #Alarm date</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="no">zh_hk #Alarm date and time</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_new_todo_note_saved">
      <source>New To-do note saved</source>
      <translation variants="no">zh_hk #New To-do note saved</translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_low">
      <source>Low</source>
      <translation variants="no">zh_hk #Low</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_new_note_saved">
      <source>New note saved</source>
      <translation variants="no">zh_hk #New note saved</translation>
    </message>
    <message numerus="no" id="txt_notes_button_due_date">
      <source>0.01</source>
      <translation variants="no">zh_hk #0.01</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">zh_hk #Discard changes</translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority">
      <source>Priority</source>
      <translation variants="no">zh_hk #Priority</translation>
    </message>
  </context>
</TS>