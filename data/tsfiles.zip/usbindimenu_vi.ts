<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dblist_usb_disconnecting">
      <source>USB disconnecting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đang ngắt k.nối USB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem">
      <source>USB problem</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lỗi kết nối USB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_media_transfer">
      <source>as media transfer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chế độ truyền media</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_phone_as_modem">
      <source>as web connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kết nối PC vào internet</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_ovi_suite">
      <source>to OVI suite</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nokia Ovi Suite</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_mass_storage">
      <source>as mass storage</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chế độ ổ đĩa chung</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_click_to_eject">
      <source>Click to eject</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tháo thiết bị USB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connecting">
      <source>USB connecting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đang tạo kết nối USB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem_val_not_enough_memory">
      <source>Not enough memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không đủ bộ nhớ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected">
      <source>USB connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã kết nối USB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem_val_connection_type_not">
      <source>Connection type not supported</source>
      <translation variants="yes">
        <lengthvariant priority="1">Loại k.nối ko được h.trợ</lengthvariant>
      </translation>
    </message>
  </context>
</TS>