<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_info_no_active_connections">
      <source>No active connections</source>
      <translation variants="no">(沒有使用中的連接)</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_connection_details">
      <source>Connection details</source>
      <translation variants="yes">
        <lengthvariant priority="1">連接資料</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">中斷連接</translation>
    </message>
    <message numerus="no" id="txt_occ_list_name">
      <source>Name</source>
      <translation variants="no">名稱：</translation>
    </message>
    <message numerus="no" id="txt_occ_button_disconnect_all">
      <source>Disconnect all</source>
      <translation variants="yes">
        <lengthvariant priority="1">中斷全部連接</lengthvariant>
      </translation>
    </message>
  </context>
</TS>