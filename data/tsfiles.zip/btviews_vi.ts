<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Paired</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>%1 connected</source>
      <translation variants="no">Đã kết nối %[16]1</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tự động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_devices">
      <source>Bluetooth - Other devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Thiết bị khác</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bật (ẩn)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Always ask</source>
      <translation variants="yes">
        <lengthvariant priority="1">Luôn hỏi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>German</source>
      <translation variants="no">Tiếng Đức</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Spanish</source>
      <translation variants="no">Tiếng Tây Ban Nha</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Đã vô hiệu</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_computers">
      <source>Bluetooth - Computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Máy vi tính</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>No found devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không tìm thấy thiết bị</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Search done</source>
      <translation variants="no">vi #Search completed</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_audio_devices">
      <source>No paired audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có thiết bị âm thanh ghép nối</lengthvariant>
        <lengthvariant priority="2">Ko có t.bị âm thanh ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Bluetooth - Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Cài đặt nâng cao</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">vi #Disconnect</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bật (hiển thị)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Bluetooth - Found devices</source>
      <translation variants="no">vi #Bluetooth devices found</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Enabled</source>
      <translation variants="no">Đã bật</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Hidden</source>
      <translation variants="no">vi #Hidden</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã kết nối (ẩn)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_input_devices">
      <source>No input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có thiết bị nhập</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Cài đặt nâng cao</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>No paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có thiết bị ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">Tất cả thiết bị</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Paired, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã ghép nối, đã kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>International US</source>
      <translation variants="no">Tiếng Mỹ-Quốc tế</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Finnish/Swedish</source>
      <translation variants="no">Tiếng Phần Lan, Thụy Điển</translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bị chặn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Connect</source>
      <translation variants="no">Kết nối</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Dutch</source>
      <translation variants="no">Tiếng Hà Lan</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Change visibility time</source>
      <translation variants="no">T.đổi t.gian cho tất cả xem</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_input_devices">
      <source>Bluetooth - Input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Thiết bị nhập</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_phones">
      <source>Bluetooth - Phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Bluetooth - All devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Tất cả thiết bị</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_phones">
      <source>No phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Danish</source>
      <translation variants="no">Tiếng Đan Mạch</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_phones">
      <source>Bluetooth - Paired phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Điện thoại ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Portuguese</source>
      <translation variants="no">Tiếng Bồ Đào Nha</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Keyboard settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt bàn phím</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>UK</source>
      <translation variants="no">Vương Quốc Anh</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Visible for %Ln min</source>
      <translation>
        <numerusform plurality="a">vi #Visible for %Ln minute</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_computers">
      <source>No computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có máy vi tính</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_devices">
      <source>No other devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có thiết bị khác</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Searching…</source>
      <translation variants="no">vi #Searching</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Mouse settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt chuột</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Audio device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thiết bị âm thanh</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã kết nối (hiển thị)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>No devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có thiết bị</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_slidervalue_l1_min">
      <source>%L1 min</source>
      <translation variants="no">%L1</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_phones">
      <source>Only phones</source>
      <translation variants="no">Chỉ điện thoại</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Italian</source>
      <translation variants="no">Tiếng Ý</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Paired devices</source>
      <translation variants="no">Thiết bị ghép nối</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>US Dvorak</source>
      <translation variants="no">Tiếng Dvorak Mỹ</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_audio_devices">
      <source>Bluetooth - Audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Thiết bị âm thanh</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Pair</source>
      <translation variants="no">vi #Pair</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_1">
      <source>Bluetooth - %1</source>
      <translation variants="no">Bluetooth - %1</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Russian</source>
      <translation variants="no">Tiếng Nga</translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Connect</source>
      <translation variants="no">vi #Connect</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_input_devices">
      <source>Only input devices</source>
      <translation variants="no">Chỉ thiết bị nhập</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_computers">
      <source>only computers</source>
      <translation variants="no">Chỉ máy vi tính</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_other_devices">
      <source>Only other devices</source>
      <translation variants="no">Chỉ thiết bị kia</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show">
      <source>Show</source>
      <translation variants="no">Hiển thị</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>%1 details</source>
      <translation variants="no">Chi tiết %[17]1</translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khác</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">Profile truy cập SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Visible</source>
      <translation variants="no">vi #Shown to all</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Bluetooth - Paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Thiết bị ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_audio_devices">
      <source>Bluetooth - Paired audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Thiết bị âm thanh ghép nối</lengthvariant>
        <lengthvariant priority="2">Bluetooth - T.bị âm thanh ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_paired_devices">
      <source>No other paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có thiết bị ghép nối khác</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Computer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Máy vi tính</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Blocked devices</source>
      <translation variants="no">Thiết bị bị chặn</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Paired, trusted</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã ghép nối, tin cậy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">Tất cả thiết bị</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_input_devices">
      <source>Bluetooth - Paired input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Thiết bị nhập ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_input_devices">
      <source>No paired input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có thiết bị ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Unpair</source>
      <translation variants="no">vi #Remove pairing</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bị chặn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_paired_devices">
      <source>Bluetooth - Other paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Thiết bị ghép nối khác</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_phones">
      <source>No paired phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có điện thoại ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Remove paired devices</source>
      <translation variants="no">Xóa thiết bị ghép nối</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Device details</source>
      <translation variants="no">vi #Device details</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_computers">
      <source>No paired computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có máy vi tính ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_audio_devices">
      <source>only audio devices</source>
      <translation variants="no">Chỉ thiết bị âm thanh</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Paired, trusted, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã ghép nối, tin cậy, đã kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Belgian</source>
      <translation variants="no">Tiếng Pháp Bỉ</translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Input device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thiết bị nhập</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Keyboard layout</source>
      <translation variants="no">Bố cục bàn phím</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>French</source>
      <translation variants="no">Tiếng Pháp</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Remove</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>US</source>
      <translation variants="no">Tiếng Anh Mỹ</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Ngắt kết nối</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_computers">
      <source>Bluetooth - Paired computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Máy vi tính ghép nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Norwegian</source>
      <translation variants="no">Tiếng Na Uy</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_audio_devices">
      <source>No audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có thiết bị âm thanh</lengthvariant>
      </translation>
    </message>
  </context>
</TS>