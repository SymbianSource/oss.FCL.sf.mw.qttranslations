<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_device_update_dpophead_trust_established">
      <source>Trust Established</source>
      <translation variants="no">uk #Trust Established</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_language_set">
      <source>Language set</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Language set</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_gprs">
      <source>GPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #GPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_WCDMA">
      <source>WCDMA</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #WCDMA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_advanced">
      <source>Advanced</source>
      <translation variants="no">uk #Advanced</translation>
    </message>
    <message numerus="no" id="txt_device_update_dpopinfo_with_1">
      <source>Trust establised with %1</source>
      <translation variants="no">uk #Trust establised with %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_sw_version_date">
      <source>SW version date</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #SW version date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_custom_version_date">
      <source>Custom version date</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Custom version date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_new_server_profile">
      <source>New server profile</source>
      <translation variants="no">uk #New server profile</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BF">
      <source>1900MHz on Band F</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #1900MHz on Band F</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_phone_was_not_updated">
      <source>The phone was not updated. The update package was not compatible with the phone. Please contact your service provider.</source>
      <translation variants="no">uk #The phone was not updated. The update package was not compatible with the phone. Please contact your service provider.</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_device_updated">
      <source>Device updated</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Device updated</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_during_the_installation_the">
      <source>During the installation the phone can not be used even for emergency.</source>
      <translation variants="no">uk #During the installation the phone can not be used even for emergency.</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_update">
      <source>Update</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_set_the_received_settings">
      <source> "Set the received settings as default?</source>
      <translation variants="no">uk # "Set the received settings as default?</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_access_point">
      <source>Access point</source>
      <translation variants="no">uk #Access point</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_resume_later">
      <source>Resume later</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Resume later</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_download_and_install">
      <source>Download and install?</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Download and install?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_8pskul">
      <source>8PSK-UL</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #8PSK-UL</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code">
      <source>Product code</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Product code</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_install_later">
      <source>Install later</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Install later</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__800BA">
      <source>800MHz on Band A</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #800MHz on Band A</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_update_incomplete_dwnld_kb">
      <source>The last update %1 (%2),%L3 kb was not completed. You can download it now </source>
      <translation variants="no">uk #The last update %1 (%2),%L3 kb was not completed. You can download it now </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_multimedia_access_pts">
      <source>Multimedia access pts</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Multimedia access pts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_network_band_supported">
      <source>Network Band supported</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Network Band supported</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_service_supported">
      <source>Data service supported</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Data service supported</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_server_password">
      <source>Server Password </source>
      <translation variants="no">uk #Server Password </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_server_profile_not_created">
      <source>Mandatory fields missing</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Mandatory fields missing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_no_access_points_found_in_t">
      <source>No access points found in the message. Settings cannot be saved." </source>
      <translation variants="no">uk #No access points found in the message. Settings cannot be saved." </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_destination_networks">
      <source>Destination networks</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Destination networks</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wcdma_bands">
      <source>WCDMA bands </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #WCDMA bands </lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_device_update_dialog_enter_the_config_trial">
      <source>Enter the Configuration Pin .&lt;%Ln&gt; tries left.</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_model">
      <source>Model</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Model</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_device_update_services">
      <source>Device update services</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Device update services</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_update_cmd">
      <source>Update</source>
      <translation variants="no">uk #Update</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_advanced_device_updates">
      <source>Advanced: Device updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Advanced: Device updates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_service_recomended">
      <source>Service recomended</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Service recomended</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BE">
      <source>1900MHz on Band E</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #1900MHz on Band E</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_type">
      <source>Type</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Type</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_network_auth_val_yes">
      <source>Yes</source>
      <translation variants="no">uk #Yes</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_warning_device_memory_is_b">
      <source>Warning! Device memory is busy. Try installation later.</source>
      <translation variants="no">uk #Warning! Device memory is busy. Try installation later.</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_to_update_your_val_inter">
      <source>Internet</source>
      <translation variants="no">uk #Internet</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_sender_of_the_message_is_unt">
      <source>Sender of the message is untrusted. Continue?"</source>
      <translation variants="no">uk #Sender of the message is untrusted. Continue?"</translation>
    </message>
    <message numerus="no" id="txt_device_update_menu_set_as_default">
      <source>Set as default</source>
      <translation variants="no">uk #Set as default</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_download_complete">
      <source>Download complete!</source>
      <translation variants="no">uk #Download complete!</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_session_mode">
      <source>Session mode</source>
      <translation variants="no">uk #Session mode</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_streaming_settings">
      <source>Streaming settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Streaming settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_installa">
      <source>Installation %1 Complete</source>
      <translation variants="no">uk #Installation %1 Complete</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_device_updates">
      <source>Device updates</source>
      <translation variants="no">uk #Device updates</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_security_information">
      <source>Security Information</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Security Information</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_browser_settings">
      <source>Browser settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Browser settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_de_info_l1_Mb_free_memory_needed_for_update">
      <source>%L1 MB free memory needed for update. Delete some data now or update later </source>
      <translation variants="no">uk #%L1 MB free memory needed for update. Delete some data now or update later </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_after_the_installation_the">
      <source>After the installation the phone will restart.</source>
      <translation variants="no">uk #After the installation the phone will restart.</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_none">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #None</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_recommended_update_is_avail">
      <source>Recommended update is available from %1.  Downloading requires connection to the internet</source>
      <translation variants="no">uk #Recommended update is available from %1.  Downloading requires connection to the internet</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_server_not_responding">
      <source>Server not responding </source>
      <translation variants="no">uk #Server not responding </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_network_auth_val_no">
      <source>No</source>
      <translation variants="no">uk #No</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BD">
      <source>1900MHz on Band D</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #1900MHz on Band D</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_GSM">
      <source>GSM</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #GSM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_server_view_l2">
      <source>Not configured</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Not configured</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_network_security_level">
      <source>Network security level</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Network security level</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_external_memory_card">
      <source>External Memory card</source>
      <translation variants="no">uk #External Memory card</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_java_version">
      <source>Java version</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Java version</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_new_device_software_availab_Kb">
      <source>New device software available %1 %2 % L3 Kb</source>
      <translation variants="no">uk #New device software available %1 %2 % L3 Kb</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_file_1_2">
      <source>file: %1 %2</source>
      <translation variants="no">uk #file: %1 %2</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_1_recommends_a_service_for">
      <source>%1 recommends a service for your phone. It requires connection to the internet.</source>
      <translation variants="no">uk #%1 recommends a service for your phone. It requires connection to the internet.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_device_memory_is_busy_try">
      <source>Device memory is busy. Try installation later.</source>
      <translation variants="no">uk #Device memory is busy. Try installation later.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_no_server_configured_to_get">
      <source>No server configured to get the updates. Please call customer care</source>
      <translation variants="no">uk #No server configured to get the updates. Please call customer care</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_during_the_installation_the">
      <source>During the installation the phone can not be used even for emergency.</source>
      <translation variants="no">uk #During the installation the phone can not be used even for emergency.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_your_phone_is_now_updated_w">
      <source>Your phone is now updated with the latest device software</source>
      <translation variants="no">uk #Your phone is now updated with the latest device software</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_wlan">
      <source>WLAN</source>
      <translation variants="no">uk #WLAN</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_enter_first_4_characters_of">
      <source>Enter first 4 characters of the %1 PIN code </source>
      <translation variants="no">uk #Enter first 4 characters of the %1 PIN code </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_update_incomp_instal_kb">
      <source>The last update %1 (%2),%L3 kb was not completed. You can install it now </source>
      <translation variants="no">uk #The last update %1 (%2),%L3 kb was not completed. You can install it now </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_camera">
      <source>Camera</source>
      <translation variants="no">uk #Camera</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_saving_settings">
      <source>Saving settings</source>
      <translation variants="no">uk #Saving settings</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading_of_1_Mb_failed">
      <source>Downloading of %1 (%2), %L3 Mb failed</source>
      <translation variants="no">uk #Downloading of %1 (%2), %L3 Mb failed</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BA">
      <source>1900MHz on Band A</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #1900MHz on Band A</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_menu_delete">
      <source>Delete</source>
      <translation variants="no">uk #Delete</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wlan_mac_address">
      <source>WLAN MAC address </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #WLAN MAC address </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_software_version">
      <source>Software version</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Software version</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading_of_1_Kb_failed">
      <source>Downloading of %1 (%2), %L3 Kb failed</source>
      <translation variants="no">uk #Downloading of %1 (%2), %L3 Kb failed</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_HSUPA">
      <source>HSUPA</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #HSUPA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_new_device_software_availab_Mb">
      <source>New device software available %1 %2 % L3 Mb</source>
      <translation variants="no">uk #New device software available %1 %2 % L3 Mb</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_error_in_communication_with">
      <source>Error in communication with the server, try again later" </source>
      <translation variants="no">uk #Error in communication with the server, try again later" </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_installation_complete">
      <source>Installation complete</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Installation complete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_installation_failed">
      <source>Installation failed</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Installation failed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_button_delete">
      <source>delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_installation_will_proceed_n">
      <source>Installation will proceed now</source>
      <translation variants="no">uk #Installation will proceed now</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_install_to_val_1_2_Mb">
      <source>%1( %2) Mb</source>
      <translation variants="no">uk #%1( %2) Mb</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_size_1_kb">
      <source>Size: %1 Kb</source>
      <translation variants="no">uk #Size: %1 Kb</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_later">
      <source>Later</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Later</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dialog_enter_the_configuration_p">
      <source>Enter the Configuration Pin </source>
      <translation variants="no">uk #Enter the Configuration Pin </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_to_update_your_val_bluet">
      <source>Bluetooth</source>
      <translation variants="no">uk #Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_verification_failed_and_mes">
      <source>Verification failed and message was deleted. Contact your service provider</source>
      <translation variants="no">uk #Verification failed and message was deleted. Contact your service provider</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">uk #Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_an_error_occurred_during_do">
      <source>An error occurred during download. Device will try resuming the download after some time.</source>
      <translation variants="no">uk #An error occurred during download. Device will try resuming the download after some time.</translation>
    </message>
    <message numerus="yes" id="txt_device_update_info_security_information_did_no">
      <source>Security Information did not Match . %Ln tries left.
Enter first 4 characters of the %1 PIN code </source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_install_to_val_1_2_kb">
      <source>%1( %2) Kb</source>
      <translation variants="no">uk #%1( %2) Kb</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_mandatory_fields_not_filled">
      <source>Mandatory fields not filled, server profile will not be created, exit anyway?</source>
      <translation variants="no">uk #Mandatory fields not filled, server profile will not be created, exit anyway?</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wireless_village_settings">
      <source>Wireless Village settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Wireless Village settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_bookmark">
      <source>Bookmark</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Bookmark</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_port">
      <source>Port</source>
      <translation variants="no">uk #Port</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_GPRS">
      <source>GPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #GPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_settings_are_already_saved">
      <source>Settings are already saved. Save again?" </source>
      <translation variants="no">uk #Settings are already saved. Save again?" </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_phone_uptodate_popup">
      <source>Phone Up-to-date</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Phone Up-to-date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_size_1_mb">
      <source>Size: %1 Mb</source>
      <translation variants="no">uk #Size: %1 Mb</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_ready">
      <source>Ready</source>
      <translation variants="no">uk #Ready</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_password">
      <source>Password</source>
      <translation variants="no">uk #Password</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_mailbox_settings">
      <source>Mailbox Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Mailbox Settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_details_not_available">
      <source>Details not available</source>
      <translation variants="no">uk #Details not available</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">uk #%1 %2</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_unable_to_open_message_f">
      <source> "Unable to open. Message format not supported" </source>
      <translation variants="no">uk # "Unable to open. Message format not supported" </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_new_wv_server">
      <source>New WV Server</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #New WV Server</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_list_from_l2">
      <source>From: %2</source>
      <translation variants="no">uk #From: %2</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_device_updates">
      <source>Device updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Device updates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_HSDPA">
      <source>HSDPA</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #HSDPA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading">
      <source>Downloading</source>
      <translation variants="no">uk #Downloading</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_unable_to_add_access_point">
      <source>Unable to add access point to protected access point settings</source>
      <translation variants="no">uk #Unable to add access point to protected access point settings</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wap_access_point">
      <source>WAP access point</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #WAP access point</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dpopinfo_your_phone_is_already_u">
      <source>Your phone is already updated with the latest Nokia OS</source>
      <translation variants="no">uk #Your phone is already updated with the latest Nokia OS</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_network_password">
      <source>network password</source>
      <translation variants="no">uk #network password</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_after_the_installation_the">
      <source>After the installation the phone will restart.</source>
      <translation variants="no">uk #After the installation the phone will restart.</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_host_address">
      <source>Host address*</source>
      <translation variants="no">uk #Host address*</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_flash_version">
      <source>Flash version </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Flash version </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_settings_could_not_be_saved">
      <source>Settings could not be saved properly. Configuration might not be usable. Check with service provider” for any partial of incomplete settings saved</source>
      <translation variants="no">uk #Settings could not be saved properly. Configuration might not be usable. Check with service provider” for any partial of incomplete settings saved</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_updte_incomp_dwnld_Mb">
      <source>The last update %1 (%2),%L3 Mb was not completed. You can download it now </source>
      <translation variants="no">uk #The last update %1 (%2),%L3 Mb was not completed. You can download it now </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_desktop_sync">
      <source>Desktop Sync</source>
      <translation variants="no">uk #Desktop Sync</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_dtm_mscs">
      <source>DTM MSCs</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #DTM MSCs</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_server_name">
      <source>Server name *</source>
      <translation variants="no">uk #Server name *</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_it_is_recommended_to_connec">
      <source>It is recommended to connect to the charger.</source>
      <translation variants="no">uk #It is recommended to connect to the charger.</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_resume_update">
      <source>Resume update</source>
      <translation variants="no">uk #Resume update</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_access_points">
      <source>Access Points</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Access Points</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_language_variant_version">
      <source>Language variant version</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Language variant version</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_connecting">
      <source>connecting</source>
      <translation variants="no">uk #connecting</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_server_id">
      <source>Server ID *</source>
      <translation variants="no">uk #Server ID *</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_firmware_update">
      <source>Firmware Update</source>
      <translation variants="no">uk #Firmware Update</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_enabled_by_the_system_admi">
      <source>Enabled by the system admin</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Enabled by the system admin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_to_proceed_with_installatio">
      <source>To proceed with installation connect to the charger now</source>
      <translation variants="no">uk #To proceed with installation connect to the charger now</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_EGPRS">
      <source>EGPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #EGPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_continue">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Continue</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__800BC">
      <source>800MHz on Band C</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #800MHz on Band C</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_you_will_be_notified_once_t">
      <source>You will be notified once the charging level reaches acceptable level.</source>
      <translation variants="no">uk #You will be notified once the charging level reaches acceptable level.</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_server_message">
      <source>Server Message</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Server Message</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_new_server_profile">
      <source>New server profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #New server profile</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_configuration_message">
      <source>Configuration Message  </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Configuration Message  </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_messaging">
      <source>Messaging</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Messaging</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_other_details">
      <source>Other details</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Other details</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_de_info_l1_kb_free_memory_needed_for_update_">
      <source>%L1 kB free memory needed for update. Delete some data now or update later </source>
      <translation variants="no">uk #%L1 kB free memory needed for update. Delete some data now or update later </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_title_delete">
      <source>Delete?</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Delete?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_network_authentication">
      <source>Network authentication</source>
      <translation variants="no">uk #Network authentication</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_update_available">
      <source>Update available</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Update available</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_system_error_try_again_l">
      <source> System Error . Try again later </source>
      <translation variants="no">uk # System Error . Try again later </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_its_recommended_to_connec">
      <source>It is recommended to connect to the charger</source>
      <translation variants="no">uk #It is recommended to connect to the charger</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__800BB">
      <source>800MHz on Band B</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #800MHz on Band B</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_downloading">
      <source>Downloading</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Downloading</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_imei">
      <source>IMEI</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #IMEI</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wcdma_cipherings">
      <source>WCDMA cipherings </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #WCDMA cipherings </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_CDMA">
      <source>CDMA</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #CDMA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_device_update">
      <source>Device Update</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Device Update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_installation_of_1_kb_failed">
      <source>Installation of %1(%2) , %L3 Kb failed.</source>
      <translation variants="no">uk #Installation of %1(%2) , %L3 Kb failed.</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_browser_version">
      <source>Browser version </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Browser version </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_set_as_default">
      <source>Set as default</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Set as default</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_connecti">
      <source>connecting</source>
      <translation variants="no">uk #connecting</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_user_name">
      <source>User name*</source>
      <translation variants="no">uk #User name*</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_install">
      <source>Install</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Install</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_menu_connect">
      <source>Connect </source>
      <translation variants="no">uk #Connect </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_to_update_your_device_s">
      <source>To update your device software to the latest available device software</source>
      <translation variants="no">uk #To update your device software to the latest available device software</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_egprs">
      <source>EGPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #EGPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val_unknown">
      <source>Band Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Band Unknown</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_duplicate_server_id">
      <source>Duplicate server Id.
</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Duplicate server Id.
</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_uninstalling_application">
      <source>Uninstalling application</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Uninstalling application</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_invalid_host_address">
      <source>Invalid host address </source>
      <translation variants="no">uk #Invalid host address </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_installing">
      <source>Installing</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Installing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_install_to">
      <source>Install to:</source>
      <translation variants="no">uk #Install to:</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_downloading_failed">
      <source>Downloading failed</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Downloading failed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_change_the_id_to_save_the_p">
      <source>Change the ID to save the profile.</source>
      <translation variants="no">uk #Change the ID to save the profile.</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_001">
      <source>%1</source>
      <translation variants="no">uk #%1</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_removing">
      <source>Removing</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Removing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_access_point_val_default">
      <source>Default</source>
      <translation variants="no">uk #Default</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_connection_lost_while_do">
      <source>Internet connection lost.Device will try resuming the download once the connection is available</source>
      <translation variants="no">uk #Internet connection lost.Device will try resuming the download once the connection is available</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_installation_of_1_Mb failed">
      <source>Installation of %1(%2) , %L3 Mb failed.</source>
      <translation variants="no">uk #Installation of %1(%2) , %L3 Mb failed.</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BB">
      <source>1900MHz on Band B</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #1900MHz on Band B</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_new_device_software_availabl">
      <source>New device software available</source>
      <translation variants="no">uk #New device software available</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_download">
      <source>Download</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Download</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_hide">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Hide</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_1_server_wants_to_contro">
      <source>%1 server wants to control data on your device. Accept control?</source>
      <translation variants="no">uk #%1 server wants to control data on your device. Accept control?</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_bt_mac_address">
      <source>BT MAC address </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #BT MAC address </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_hide_popup">
      <source>hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #hide</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_Unknow">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Unknown</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_configuration_message">
      <source>Configuration Message  </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Configuration Message  </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dpophead_device_update">
      <source>Device Update</source>
      <translation variants="no">uk #Device Update</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_installi">
      <source>Installing %1</source>
      <translation variants="no">uk #Installing %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_the_last_update_1_2_mb">
      <source> The last update %1 %2 %L3 Mb was not completed. </source>
      <translation variants="no">uk # The last update %1 %2 %L3 Mb was not completed. </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BC">
      <source>1900MHz on Band C</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #1900MHz on Band C</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_updating_phone">
      <source>Updating phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Updating phone</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_disabled_by_the_system_adm">
      <source>Disabled by the system admin</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Disabled by the system admin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_save_to">
      <source>Save to configure the settings  </source>
      <translation variants="no">uk #Save to configure the settings  </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_save">
      <source>save</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #save</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_popup_device_update_">
      <source>Device Update</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Device Update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_delete_server_profile_for">
      <source>Delete server profile for %1?</source>
      <translation variants="no">uk #Delete server profile for %1?</translation>
    </message>
    <message numerus="no" id="txt_device_update_list_from_1_2">
      <source>From: %1</source>
      <translation variants="no">uk #From: %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_update_incomp_instal_Mb">
      <source>The last update %1 (%2),%L3 Mb was not completed. You can install it now </source>
      <translation variants="no">uk #The last update %1 (%2),%L3 Mb was not completed. You can install it now </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_are_you_sure_you_want_to_del">
      <source>Are you sure you want to delete %1</source>
      <translation variants="no">uk #Are you sure you want to delete %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_network_username">
      <source>network username</source>
      <translation variants="no">uk #network username</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_download">
      <source>Downloading %1</source>
      <translation variants="no">uk #Downloading %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_security_info_access_denied">
      <source>Security Information did not match. Access denied </source>
      <translation variants="no">uk #Security Information did not match. Access denied </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_the_last_update_1_2_kb">
      <source> The last update %1 %2 %L3 kb was not completed. </source>
      <translation variants="no">uk # The last update %1 %2 %L3 kb was not completed. </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_invalid_user_name_or_passwo">
      <source>Invalid user name or password  </source>
      <translation variants="no">uk #Invalid user name or password  </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_release">
      <source>Product Release</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Product Release</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_custom_version">
      <source>Custom version</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Custom version</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_update_serverpush_informative">
      <source>Updating device from server %1  </source>
      <translation variants="no">uk #Updating device from server %1  </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_phone_uptodate">
      <source>Phone Up-to-date</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Phone Up-to-date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_authentication_failed_chec">
      <source>Authentication failed, check server ID and password </source>
      <translation variants="no">uk #Authentication failed, check server ID and password </translation>
    </message>
  </context>
</TS>