<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clk_main_view_list_no_alarms_set">
      <source>No alarms set</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی الارم مرتب نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_settings">
      <source>Settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_title_clock">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">گھڑی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy">
      <source>dd mm yyyy</source>
      <translation variants="yes">
        <lengthvariant priority="1">دن مہینہ سال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_menu_delete_alarm">
      <source>Delete alarm</source>
      <translation variants="no">الارم مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy">
      <source>mm dd yyyy</source>
      <translation variants="yes">
        <lengthvariant priority="1">مہینہ دن سال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd">
      <source>yyyy mm dd</source>
      <translation variants="yes">
        <lengthvariant priority="1">سال مہینہ دن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_menu_delete">
      <source>Delete</source>
      <translation variants="no">مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_show_on_homescreen">
      <source>Show on homescreen</source>
      <translation variants="no">ہوم اسک. پر دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_set_as_current_location">
      <source>Set as current location</source>
      <translation variants="no">موجودہ مقام مرتب کریں</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_every_1">
      <source>Every %1</source>
      <translation variants="no">ہر  %1</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_today">
      <source>Today</source>
      <translation variants="no">آج</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hr_2_mins">
      <source>%1 hr %2 mins</source>
      <translation variants="no">%1 گھنٹہ %2 منٹ</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_gmt">
      <source>GMT</source>
      <translation variants="no">GMT</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_inactive">
      <source>Inactive</source>
      <translation variants="no">غیر کارآمد</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2mins">
      <source>In %1hr %2mins</source>
      <translation variants="no">%1 گھنٹہ %2 منٹ میں</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_activated">
      <source>Alarm Activated</source>
      <translation variants="no">الارم کارآمد کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2mins">
      <source>In %1hrs %2mins</source>
      <translation variants="no">%1 گھ. %2 منٹ میں</translation>
    </message>
    <message numerus="yes" id="txt_clock_dblist_daily_val_ln_mins">
      <source>%Ln mins</source>
      <translation>
        <numerusform plurality="a">%Ln منٹ</numerusform>
        <numerusform plurality="b">%Ln منٹ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_deactivated">
      <source>Alarm Deactivated</source>
      <translation variants="no">الارم غیرکارآمد کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_short_caption_clock">
      <source>Clock</source>
      <translation variants="no">گھڑی</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hrs_2_mins">
      <source>%1 hrs %2 mins</source>
      <translation variants="no">%1 گھنٹے %2 منٹ</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1days">
      <source>In %1days</source>
      <translation variants="no">%[99]1دنوں میں</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2min">
      <source>In %1hr %2min</source>
      <translation variants="no">%1 گھنٹہ %2 منٹ میں</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_add_city">
      <source>Add city</source>
      <translation variants="no">شہر شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_workdays">
      <source>Workdays</source>
      <translation variants="no">ایام کار</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_world_clock">
      <source>World Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">عالمی گھڑی</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_clock_dblist_daily_val_ln_hr">
      <source>%Ln hr</source>
      <translation>
        <numerusform plurality="a">%Ln گھنٹے</numerusform>
        <numerusform plurality="b">%Ln گھنٹہ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hr_2_min">
      <source>%1 hr %2 min</source>
      <translation variants="no">%1 گھنٹہ %2 منٹ</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hrs_2_min">
      <source>%1 hrs %2 min</source>
      <translation variants="no">%1 گھنٹے %2 منٹ</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily">
      <source>Daily</source>
      <translation variants="no">یومیہ</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2min">
      <source>In %1hrs %2min</source>
      <translation variants="no">%1 گھنٹے %2 منٹ میں</translation>
    </message>
    <message numerus="no" id="txt_long_caption_clock">
      <source>Clock</source>
      <translation variants="no">گھڑی</translation>
    </message>
  </context>
</TS>