<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_religious_talk_hs">
      <source>Religious talk</source>
      <translation variants="no">Cuộc nói chuyện về tôn giáo</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_documentary_hs">
      <source>Documentary</source>
      <translation variants="no">Phim tài liệu</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_leisure_hs">
      <source>Leisure</source>
      <translation variants="no">Giải trí</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_talk_hs">
      <source>Talk</source>
      <translation variants="no">Trò chuyện</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_alarm_hs">
      <source>Alarm</source>
      <translation variants="no">Âm báo</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_public_hs">
      <source>Public</source>
      <translation variants="no">Chung</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_list_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">Radio FM</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_finance_hs">
      <source>Finance</source>
      <translation variants="no">Tài chính</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_adult_hits_hs">
      <source>Adult hits</source>
      <translation variants="no">Adult hits</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_classical_hs">
      <source>Classical</source>
      <translation variants="no">Cổ điển</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_college_hs">
      <source>College</source>
      <translation variants="no">Đoàn thể</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_list_fm_radio_homescreen_widget">
      <source>FM Radio homescreen widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">Radio FM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_sport_hs">
      <source>Sport</source>
      <translation variants="no">Thể thao</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_oldies_music_hs">
      <source>Oldies Music</source>
      <translation variants="no">Nhạc xưa</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_current_affairs_hs">
      <source>Current affairs</source>
      <translation variants="no">Công việc hiện tại</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_classic_rock_hs">
      <source>Classic rock</source>
      <translation variants="no">Rock cổ điển</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_connect_wired_headset">
      <source>Connect wired headset.</source>
      <translation variants="no">Kết nối tai nghe có dây</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_country_music_hs">
      <source>Country Music</source>
      <translation variants="no">Nhạc đồng quê</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_folk_music_hs">
      <source>Folk Music</source>
      <translation variants="no">Nhạc dân gian</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_travel_hs">
      <source>Travel</source>
      <translation variants="no">Du lịch</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_phone_in_hs">
      <source>Phone In</source>
      <translation variants="no">Hộp thư truyền hình</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_social_affairs_hs">
      <source>Social Affairs</source>
      <translation variants="no">Các vấn đề về xã hội</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_other_music_hs">
      <source>Other Music</source>
      <translation variants="no">Nhạc khác</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_information_hs">
      <source>Information</source>
      <translation variants="no">Thông tin</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_top_40_hs">
      <source>Top 40</source>
      <translation variants="no">Top 40</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_soft_rhythm_and_blues_hs">
      <source>Soft rhythm and blues</source>
      <translation variants="no">R&amp;B nhẹ</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_varied_hs">
      <source>Varied</source>
      <translation variants="no">Loại khác</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_serious_classical_hs">
      <source>Serious classical</source>
      <translation variants="no">Cổ điển nghiêm túc</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_childrens_programmes_hs">
      <source>Children’s programmes</source>
      <translation variants="no">Chương trình dành cho trẻ em</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_light_classical_hs">
      <source>Light classical</source>
      <translation variants="no">Nhạc cổ điển nhẹ</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_soft_hs">
      <source>Soft</source>
      <translation variants="no">Nhẹ nhàng</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_language_hs">
      <source>Language</source>
      <translation variants="no">Ngôn ngữ</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_weather_hs">
      <source>Weather</source>
      <translation variants="no">Thời tiết</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_religious_music_hs">
      <source>Religious music</source>
      <translation variants="no">Nhạc tôn giáo</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_jazz_music_hs">
      <source>Jazz Music</source>
      <translation variants="no">Nhạc jazz</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_soft_rock_hs">
      <source>Soft rock</source>
      <translation variants="no">Rock nhẹ</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_pop_music_hs">
      <source>Pop Music</source>
      <translation variants="no">Nhạc pop</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_rhythm_and_blues_hs">
      <source>Rhythm and blues</source>
      <translation variants="no">Nhạc R&amp;B</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_alarm_test_hs">
      <source>Alarm Test</source>
      <translation variants="no">Thử nghiệm âm báo</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_culture_hs">
      <source>Culture</source>
      <translation variants="no">Văn hóa</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_list_l1_mhz">
      <source>%L1 Mhz</source>
      <translation variants="no">%L1 MHz</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_education_hs">
      <source>Education</source>
      <translation variants="no">Giáo dục</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_national_music_hs">
      <source>National Music</source>
      <translation variants="no">Nhạc dân tộc</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_nostalgia_hs">
      <source>Nostalgia</source>
      <translation variants="no">Hoài cổ</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_science_hs">
      <source>Science</source>
      <translation variants="no">Khoa học</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_easy_listening_hs">
      <source>Easy Listening</source>
      <translation variants="no">Dễ nghe</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_drama_hs">
      <source>Drama</source>
      <translation variants="no">Kịch</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_news_hs">
      <source>News</source>
      <translation variants="no">Tin tức</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_rock_music_hs">
      <source>Rock Music</source>
      <translation variants="no">Nhạc rock</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_personality_hs">
      <source>Personality</source>
      <translation variants="no">Nhân vật nổi tiếng</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_activate_radio_in_offline_mode_hs">
      <source>Activate Fm Radio in off-line mode?</source>
      <translation variants="no">Bắt đầu radio FM ở chế độ offline?</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_rad_info_religion_hs">
      <source>Religion</source>
      <translation variants="no">Tôn giáo</translation>
    </message>
    <message numerus="no" id="txt_fmradiohswidget_list_quick_access_for_fm_radio_in_your">
      <source>Quick access for FM radio in your homescreen.</source>
      <translation variants="yes">
        <lengthvariant priority="1">Truy cập nhanh vào radio FM từ Màn hình chính</lengthvariant>
        <lengthvariant priority="2">T.c.n vào rad. FM từ M.h.chính</lengthvariant>
      </translation>
    </message>
  </context>
</TS>