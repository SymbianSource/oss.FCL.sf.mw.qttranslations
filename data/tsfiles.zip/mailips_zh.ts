<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_mail_authentication">
      <source>Outgoing mail authentication</source>
      <translation variants="no">传出电子邮件鉴定</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_reply_to_address">
      <source>Reply to address</source>
      <translation variants="no">回复地址：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_mail_server">
      <source>Incoming mail server</source>
      <translation variants="no">邮件接收服务器</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_my_name">
      <source>My name</source>
      <translation variants="no">我的名称：</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_preferences">
      <source>Preferences</source>
      <translation variants="no">首选项</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_day_end_time">
      <source>Day end time</source>
      <translation variants="no">一天结束时间：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_every_day">
      <source>Every day</source>
      <translation variants="no">每天</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_tue">
      <source>Tue</source>
      <translation variants="no">周二</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_1_hour">
      <source>Every 1 hour</source>
      <translation variants="no">每小时</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_mail_server">
      <source>Outgoing mail server</source>
      <translation variants="no">电子邮件发送服务器</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_save_energy">
      <source>Save energy</source>
      <translation variants="no">节能</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_as_defin">
      <source>The mailbox is refreshed as defined by the user</source>
      <translation variants="no">按用户的规定刷新信箱内容</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_sat">
      <source>Sat</source>
      <translation variants="no">周六</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_wed">
      <source>Wed</source>
      <translation variants="no">周三</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_sun">
      <source>Sun</source>
      <translation variants="no">周日</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_show_mail_in_other_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">在其他文件夹中显示电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_username">
      <source>Username</source>
      <translation variants="no">用户名：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_receiving_weekdays">
      <source>Receiving days</source>
      <translation variants="no">提取日</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">刷新信箱</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">电子邮件地址：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_mailbox_name">
      <source>Mailbox name</source>
      <translation variants="no">信箱名称</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_connection">
      <source>Connection</source>
      <translation variants="no">连接</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_mon">
      <source>Mon</source>
      <translation variants="no">周一</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_receiving_schedule">
      <source>Receiving Schedule</source>
      <translation variants="no">提取日程表</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_thu">
      <source>Thu</source>
      <translation variants="no">周四</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_server_info">
      <source>Server info</source>
      <translation variants="no">服务器详情</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_when_i_open_mailbox">
      <source>When I open mailbox</source>
      <translation variants="no">当我打开信箱时</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_every_15">
      <source>The mailbox is refreshed every 15 minutes during daytime</source>
      <translation variants="no">信箱内容在白天每隔15分钟刷新一次</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_user_define">
      <source>User defined</source>
      <translation variants="no">用户自定义</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_fri">
      <source>Fri</source>
      <translation variants="no">周五</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="no">每隔4小时</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_keep_uptodate">
      <source>Keep up-to-date</source>
      <translation variants="no">保持最新</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_keep_upto">
      <source>Keep up-to-date</source>
      <translation variants="no">保持最新</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_uptodate_during">
      <source>The mailbox is up-to-date during daytime</source>
      <translation variants="no">白天信箱始终保持最新内容</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_password">
      <source>Password</source>
      <translation variants="no">密码：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_fetch_manua">
      <source>Fetch manually</source>
      <translation variants="no">手动提取电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_only_by">
      <source>The mailbox is refreshed only by user request</source>
      <translation variants="no">仅当用户启动刷新时才刷新信箱内容</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="no">每隔15分钟</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_day_start_time">
      <source>Day start time</source>
      <translation variants="no">一天开始时间：</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_user_info">
      <source>User info</source>
      <translation variants="no">用户设置</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_all">
      <source>All</source>
      <translation variants="no">全部</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_version_l1">
      <source>Version: %[]1</source>
      <translation variants="no">版本：%1</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_show_mail_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">在收件箱中显示电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode">
      <source>Selected mode</source>
      <translation variants="no">使用的刷新选项</translation>
    </message>
    <message numerus="no" id="txt_mailips_button_delete_mailbox">
      <source>Delete mailbox</source>
      <translation variants="no">删除信箱</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_on_starttls">
      <source>On (StartTLS)</source>
      <translation variants="no">开(StartTLS)</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mailips">
      <source>Mail</source>
      <translation variants="no">电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port">
      <source>Incoming port</source>
      <translation variants="no">传入端口</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port_default">
      <source>Default</source>
      <translation variants="no">预设</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_port">
      <source>Outgoing port</source>
      <translation variants="no">传出端口</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_off">
      <source>Off</source>
      <translation variants="no">关</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_security">
      <source>Incoming secure connection</source>
      <translation variants="no">传入安全连接</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port_user_defined">
      <source>User defined</source>
      <translation variants="no">用户自定义</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_on_ssltls">
      <source>On (SLL/TLS)</source>
      <translation variants="no">开(SSL/TLS)</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_security">
      <source>Outgoing secure connection</source>
      <translation variants="no">传出安全连接</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path_val_default">
      <source>Default</source>
      <translation variants="no">预设</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path_user_defined">
      <source>User defined</source>
      <translation variants="no">用户自定义</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path">
      <source>Folder path</source>
      <translation variants="no">文件夹路径</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_same">
      <source>Same as for incoming</source>
      <translation variants="no">与接收设置相同</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_user">
      <source>User authentication</source>
      <translation variants="no">用户鉴定</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_none">
      <source>None</source>
      <translation variants="no">无</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">刷新信箱</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_connection">
      <source>Connection</source>
      <translation variants="no">连接</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_show_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">在收件箱中显示电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_thursday">
      <source>Thu</source>
      <translation variants="yes">
        <lengthvariant priority="1">周四</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_on_ssltls">
      <source>On (SSL/TLS)</source>
      <translation variants="yes">
        <lengthvariant priority="1">开(SSL/TLS)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="yes">
        <lengthvariant priority="1">每隔4小时</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">每隔15分钟</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_wednesday">
      <source>Wed</source>
      <translation variants="yes">
        <lengthvariant priority="1">周三</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_all">
      <source>All</source>
      <translation variants="yes">
        <lengthvariant priority="1">全部</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_saturday">
      <source>Sat</source>
      <translation variants="yes">
        <lengthvariant priority="1">周六</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_outgoing_authentication">
      <source>Outgoing mail authentication</source>
      <translation variants="no">传出电子邮件鉴定</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_no_authentication">
      <source>No authentication</source>
      <translation variants="yes">
        <lengthvariant priority="1">无</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_keep_up_to_date">
      <source>Keep up-to-date</source>
      <translation variants="yes">
        <lengthvariant priority="1">保持最新</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_user_authentication">
      <source>User authentication</source>
      <translation variants="yes">
        <lengthvariant priority="1">用户鉴定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_end_time">
      <source>Day end time</source>
      <translation variants="no">一天结束时间：</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_outgoing_connection">
      <source>Outgoing secure connection</source>
      <translation variants="no">传出安全连接</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_every_hour">
      <source>Every hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">每小时</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_friday">
      <source>Fri</source>
      <translation variants="yes">
        <lengthvariant priority="1">周五</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_on_starttls">
      <source>On (StartTLS)</source>
      <translation variants="yes">
        <lengthvariant priority="1">开(StartTLS)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_sunday">
      <source>Sun</source>
      <translation variants="yes">
        <lengthvariant priority="1">周日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_tuesday">
      <source>Tue</source>
      <translation variants="yes">
        <lengthvariant priority="1">周二</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_same_as_for_incoming">
      <source>Same as for incoming</source>
      <translation variants="yes">
        <lengthvariant priority="1">与邮件接收设置同</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_monday">
      <source>Mon</source>
      <translation variants="yes">
        <lengthvariant priority="1">周一</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_show_in_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">在其他文件夹中显示电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_incoming_connection">
      <source>Incoming secure connection</source>
      <translation variants="no">传入安全连接</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_receiving_days">
      <source>Receiving days</source>
      <translation variants="no">提取日</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_start_time">
      <source>Day start time</source>
      <translation variants="no">一天开始时间：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_none">
      <source>None</source>
      <translation variants="no">无</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_every_hour">
      <source>The mailbox is refreshed every hour during daytime</source>
      <translation variants="no">白天信箱内容每小时刷新一次</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_folder_path_val_default">
      <source>Default</source>
      <translation variants="yes">
        <lengthvariant priority="1">预设</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_folder_path_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">用户自定义</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_folder_path">
      <source>Folder path</source>
      <translation variants="no">文件夹路径</translation>
    </message>
  </context>
</TS>