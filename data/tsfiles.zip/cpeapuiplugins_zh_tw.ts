<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_user_certificate">
      <source>User certificate</source>
      <translation variants="no">個人憑證</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_certificate_val_not_in_use">
      <source>(not in use)</source>
      <translation variants="no">未使用</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_provisioning_enabled">
      <source>Enabled</source>
      <translation variants="no">啟用</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_realm_val_generate_automatically">
      <source>Generate automatically</source>
      <translation variants="no">自動產生</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_cipher_suites">
      <source>Cipher suites</source>
      <translation variants="yes">
        <lengthvariant priority="1">加密套件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password">
      <source>PAC store password</source>
      <translation variants="no">PAC儲存密碼</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authenticated_provisioning">
      <source>Authenticated provisioning</source>
      <translation variants="no">安全佈建</translation>
    </message>
    <message numerus="no" id="txt_occ_info_remove_pac_store_all_credentials_wil">
      <source>Remove PAC store? All credentials will be lost.</source>
      <translation variants="no">是否移除PAC儲存？所有認證都將會失去。</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_realm">
      <source>Realm</source>
      <translation variants="no">網域</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unauthenticated_provisioning">
      <source>Unauthenticated provisioning</source>
      <translation variants="no">不安全佈建</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv1">
      <source>PEAPv1</source>
      <translation variants="no">PEAPv1</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_inner_eap_type">
      <source>Inner EAP type</source>
      <translation variants="no">內部EAP類型</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_generate_automatica">
      <source>Generate automatically</source>
      <translation variants="no">自動產生</translation>
    </message>
    <message numerus="no" id="txt_occ_button_reset_pac_store">
      <source>Reset PAC store</source>
      <translation variants="no">zh_tw #Reset PAC store</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy">
      <source>TLS privacy</source>
      <translation variants="no">TLS加密</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy_val_on">
      <source>On</source>
      <translation variants="no">開</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_pac_store">
      <source>PAC store</source>
      <translation variants="yes">
        <lengthvariant priority="1">PAC儲存</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_eap_module_settings">
      <source>%1 settings</source>
      <translation variants="no">%[22]1設定</translation>
    </message>
    <message numerus="no" id="txt_occ_button_inner_eap_type">
      <source>Configure inner EAP type</source>
      <translation variants="no">zh_tw #Configure inner EAP type</translation>
    </message>
    <message numerus="no" id="txt_occ_info_pac_store_password_will_no_longer_be">
      <source>PAC store password will no longer be stored in phone and should be memorised. Continue?</source>
      <translation variants="no">PAC儲存密碼將不再儲存於裝置中，您必須自行記住。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_occ_info_existing_password_cannot_be_changed">
      <source>Existing password cannot be changed. Select 'Reset PAC store' to reset the store and password.</source>
      <translation variants="no">無法變更現有的密碼。請選取"移除PAC儲存"以移除儲存和密碼。</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version">
      <source>PEAP version</source>
      <translation variants="no">PEAP版本</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate_val_select">
      <source>Select automatically</source>
      <translation variants="no">自動選取</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password_val_user_defin">
      <source>User defined</source>
      <translation variants="no">使用者自訂</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv0_or_peapv1">
      <source>PEAPv0 or PEAPv1</source>
      <translation variants="no">PEAPv0或PEAPv1</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy_val_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password_val_prompt">
      <source>Prompt</source>
      <translation variants="no">通知</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv0">
      <source>PEAPv0</source>
      <translation variants="no">PEAPv0</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate_val_not_in">
      <source>(not in use)</source>
      <translation variants="no">未使用</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate">
      <source>Authority certificate</source>
      <translation variants="no">授權憑證</translation>
    </message>
  </context>
</TS>