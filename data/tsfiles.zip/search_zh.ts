<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_search_list_device">
      <source>Device</source>
      <translation variants="no">设备</translation>
    </message>
    <message numerus="no" id="txt_search_title_search">
      <source>Search</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜索</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_all_other_files">
      <source>All other files</source>
      <translation variants="no">所有其他文件</translation>
    </message>
    <message numerus="no" id="txt_short_caption_search">
      <source>Search</source>
      <translation variants="no">搜索</translation>
    </message>
    <message numerus="no" id="txt_search_list_internet">
      <source>Internet</source>
      <translation variants="no">互联网</translation>
    </message>
    <message numerus="no" id="txt_search_info_select_search_scope">
      <source>Select search scope:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择搜索范围：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_search">
      <source>Search</source>
      <translation variants="no">搜索</translation>
    </message>
    <message numerus="no" id="txt_long_caption_search">
      <source>Search</source>
      <translation variants="no">搜索</translation>
    </message>
    <message numerus="no" id="txt_search_list_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">书签</translation>
    </message>
    <message numerus="no" id="txt_search_list_applications">
      <source>Applications</source>
      <translation variants="no">应用程序</translation>
    </message>
    <message numerus="no" id="txt_search_list_no_match_found">
      <source>No Match Found</source>
      <translation variants="yes">
        <lengthvariant priority="1">(无匹配)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_search_for_1">
      <source>Search for "%1" </source>
      <translation variants="no">搜索"%[21]1"</translation>
    </message>
    <message numerus="no" id="txt_search_list_select_all">
      <source>Select all</source>
      <translation variants="no">全选</translation>
    </message>
    <message numerus="no" id="txt_search_list_media">
      <source>Media</source>
      <translation variants="no">影音工具</translation>
    </message>
    <message numerus="no" id="txt_search_list_calendarnotes">
      <source>Calendar &amp; Notes</source>
      <translation variants="no">日历和记事本</translation>
    </message>
    <message numerus="no" id="txt_search_list_messagemail">
      <source>Message &amp; Mail</source>
      <translation variants="no">信息和电子邮件</translation>
    </message>
    <message numerus="no" id="txt_search_title_search_scope">
      <source>Search scope</source>
      <translation variants="no">搜索范围</translation>
    </message>
    <message numerus="no" id="txt_search_list_contatcs">
      <source>Contacts</source>
      <translation variants="no">名片夹</translation>
    </message>
    <message numerus="no" id="txt_search_dialog_search_internet">
      <source>Search internet</source>
      <translation variants="no">搜索互联网</translation>
    </message>
    <message numerus="no" id="txt_search_dialog_search_device">
      <source>Search device</source>
      <translation variants="no">搜索设备</translation>
    </message>
  </context>
</TS>