<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_notes_formlabel_val_description">
      <source>Description</source>
      <translation variants="yes">
        <lengthvariant priority="1">內容說明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="yes">
        <lengthvariant priority="1">主旨</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_add_to_calendar">
      <source>Add to Calendar</source>
      <translation variants="no">zh_tw #Add to Calendar</translation>
    </message>
    <message numerus="no" id="txt_notes_button_send">
      <source>Send</source>
      <translation variants="no">zh_tw #Send</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_todo">
      <source>To-do</source>
      <translation variants="yes">
        <lengthvariant priority="1">待辦事項</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_new_note">
      <source>New note</source>
      <translation variants="no">zh_tw #New note</translation>
    </message>
    <message numerus="no" id="txt_notes_title_due_date">
      <source>Due date</source>
      <translation variants="yes">
        <lengthvariant priority="1">到期日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_note">
      <source>Note</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_low">
      <source>Low</source>
      <translation variants="yes">
        <lengthvariant priority="1">低</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_new_note_saved">
      <source>New note saved</source>
      <translation variants="yes">
        <lengthvariant priority="1">新記事本已儲存</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="yes">
        <lengthvariant priority="1">鬧鈴時間</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_due_date">
      <source>Due date</source>
      <translation variants="yes">
        <lengthvariant priority="1">到期日：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_description">
      <source>Remove description</source>
      <translation variants="yes">
        <lengthvariant priority="1">移除內容說明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_alarm_date">
      <source>%2</source>
      <translation variants="yes">
        <lengthvariant priority="1">%2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="yes">
        <lengthvariant priority="1">鬧鈴日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Change to to-do note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Remove from favourites</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_new_note">
      <source>New note</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #New note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_saved">
      <source>Note saved</source>
      <translation variants="yes">
        <lengthvariant priority="1">記事本已儲存</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_new_todo">
      <source>New To-do</source>
      <translation variants="yes">
        <lengthvariant priority="1">新增待辦事項</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Add to favourites</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="yes">
        <lengthvariant priority="1">鬧鈴時間和日期：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_add_description">
      <source>Add description</source>
      <translation variants="yes">
        <lengthvariant priority="1">加入內容說明：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_due_date">
      <source>%1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_alarm_time">
      <source>%1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_high">
      <source>High</source>
      <translation variants="yes">
        <lengthvariant priority="1">高</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Discard changes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority">
      <source>Priority</source>
      <translation variants="yes">
        <lengthvariant priority="1">優先順序：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_new_todo_note_saved">
      <source>New To-do note saved</source>
      <translation variants="yes">
        <lengthvariant priority="1">新待辦事項已儲存</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_todo_note_saved">
      <source>To-do note saved</source>
      <translation variants="yes">
        <lengthvariant priority="1">待辦事項已儲存</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_dialog_delete">
      <source>Delete</source>
      <translation variants="no">zh_tw #Delete</translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_normal">
      <source>Normal</source>
      <translation variants="yes">
        <lengthvariant priority="1">中</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_delete">
      <source>Delete</source>
      <translation variants="no">zh_tw #Delete</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_note">
      <source>Delete note?</source>
      <translation variants="yes">
        <lengthvariant priority="1">是否刪除記事本？</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_edit_time">
      <source>%1 %2</source>
      <translation variants="no">%[99]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="yes">
        <lengthvariant priority="1">是否刪除待辦事項？</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">鬧鈴</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">zh_tw #Open</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="no">zh_tw #Cancel</translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_item">
      <source>Send</source>
      <translation variants="no">zh_tw #Send</translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">zh_tw #Delete</translation>
    </message>
    <message numerus="no" id="txt_common_menu_edit">
      <source>Edit</source>
      <translation variants="no">zh_tw #Edit</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="no">zh_tw #Unnamed</translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_item">
      <source>Send</source>
      <translation variants="no">zh_tw #Send</translation>
    </message>
    <message numerus="no" id="txt_common_opt_delete">
      <source>Delete</source>
      <translation variants="no">zh_tw #Delete</translation>
    </message>
  </context>
</TS>