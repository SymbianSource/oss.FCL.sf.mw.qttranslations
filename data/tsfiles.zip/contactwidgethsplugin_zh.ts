<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_friend_widget_info_you_can_not_use_this_widge">
      <source>You can not use this  widget, because your phonebook is empty. Open Phonebook to add contacts?</source>
      <translation variants="no">无法使用袖珍名片夹，因为名片夹应用程序中不含名片。打开名片夹应用程序？</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget_val_quickly">
      <source>Home screen contacts widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">从主屏幕快速联系朋友</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_friend">
      <source>Contacts</source>
      <translation variants="no">名片夹</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_title_select_contact">
      <source>Select contact:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_friend_widget_contact_unnamed">
      <source>Unnamed</source>
      <translation variants="no">(未命名)</translation>
    </message>
  </context>
</TS>