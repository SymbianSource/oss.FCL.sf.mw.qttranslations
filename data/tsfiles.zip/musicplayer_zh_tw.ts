<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mus_title_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown_all">
      <source>Unknown - All</source>
      <translation variants="yes">
        <lengthvariant priority="1">不明 - 全部</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近加入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_audio_effects">
      <source>Audio effects</source>
      <translation variants="no">聲音效果</translation>
    </message>
    <message numerus="no" id="txt_mus_list_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">爵士</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_audio_effects">
      <source>Audio effects</source>
      <translation variants="yes">
        <lengthvariant priority="1">聲音效果</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_song_details">
      <source>Song details </source>
      <translation variants="yes">
        <lengthvariant priority="1">歌曲詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_bass_booster">
      <source>Bass booster</source>
      <translation variants="yes">
        <lengthvariant priority="1">超重低音</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_playlist">
      <source>Select playlist</source>
      <translation variants="yes">
        <lengthvariant priority="1">選取播放清單</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness">
      <source>Loudness</source>
      <translation variants="no">響度</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_played">
      <source>Recently played (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">不明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown6">
      <source>Unknown</source>
      <translation variants="no">不明</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_on">
      <source>Repeat on</source>
      <translation variants="no">開啟重複</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown5">
      <source>Unknown</source>
      <translation variants="no">不明</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">加入至播放清單</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name_entry_playlist_l1">
      <source>New playlist name</source>
      <translation variants="no">播放清單%L1</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_new_playlist">
      <source>New playlist</source>
      <translation variants="no">新增播放清單</translation>
    </message>
    <message numerus="no" id="txt_mus_list_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">搖滾</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown7">
      <source>Unknown </source>
      <translation variants="no">不明</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown1">
      <source>Unknown</source>
      <translation variants="no">不明</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">不明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_equalizer">
      <source>Equalizer</source>
      <translation variants="no">平衡器</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_all_songs">
      <source>All songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">所有歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown4">
      <source>Unknown</source>
      <translation variants="no">不明</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_refresh_library">
      <source>Refresh library</source>
      <translation variants="no">重新整理資料庫</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown2">
      <source>Unknown</source>
      <translation variants="no">不明</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_most_played">
      <source>Most played (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">最常播放</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_share">
      <source>Share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_mus_menu_view_details">
      <source>View details</source>
      <translation variants="no">檢視詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">不明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_complete">
      <source>Refresh complete</source>
      <translation variants="no">重新整理已完成</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_added">
      <source>Recently added (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近加入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">最常播放</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_1_all">
      <source>%1 - All</source>
      <translation variants="no">%[27]1-全部</translation>
    </message>
    <message numerus="no" id="txt_mus_list_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">流行</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_music">
      <source>Music</source>
      <translation variants="no">音樂</translation>
    </message>
    <message numerus="no" id="txt_mus_list_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">古典</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_inspire_me">
      <source>Inspire me</source>
      <translation variants="yes">
        <lengthvariant priority="1">啟發我</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_menu_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">加入至播放清單</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_off">
      <source>Repeat off</source>
      <translation variants="no">關閉重複</translation>
    </message>
    <message numerus="no" id="txt_mus_list_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_songs">
      <source>Select songs</source>
      <translation variants="no">選取歌曲：</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">不明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_no_music">
      <source>(No music)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(無音樂)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown3">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">不明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown3">
      <source>Unknown</source>
      <translation variants="no">不明</translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">不明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown">
      <source>Unknown</source>
      <translation variants="no">不明</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_playlist">
      <source>Delete playlist?</source>
      <translation variants="no">是否刪除播放清單？</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_album">
      <source>Delete album?</source>
      <translation variants="no">是否刪除專輯？</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_balance">
      <source>Balance</source>
      <translation variants="no">平衡</translation>
    </message>
    <message numerus="no" id="txt_mus_button_new">
      <source>New</source>
      <translation variants="yes">
        <lengthvariant priority="1">新增</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_song">
      <source>Delete song?</source>
      <translation variants="no">是否刪除歌曲？</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name">
      <source>Enter name</source>
      <translation variants="yes">
        <lengthvariant priority="1">名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_select_song">
      <source>Select song</source>
      <translation variants="yes">
        <lengthvariant priority="1">選取歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_size">
      <source>Size</source>
      <translation variants="yes">
        <lengthvariant priority="1">大小</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_new_playlist_created">
      <source>New playlist created</source>
      <translation variants="no">新播放清單已建立</translation>
    </message>
    <message numerus="no" id="txt_mus_title_add_songs">
      <source>Add songs</source>
      <translation variants="no">zh_tw #Add songs</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_songs_added_to_1">
      <source>Songs added to %1</source>
      <translation variants="no">歌曲已加入至%1</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown9">
      <source>Unknown</source>
      <translation variants="no">不明</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_song_is_protected">
      <source>Song is protected. Unable to play over Bluetooth headset.</source>
      <translation variants="no">zh_tw #Unable to play over Bluetooth headset. Protected song.</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_b">
      <source>%Ln B</source>
      <translation>
        <numerusform plurality="a">%Ln B</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_note_that_using_nokia_ovi_suite_mode">
      <source>Note that using Nokia Ovi Suite mode to transfer your music will optimize your music experience. To learn more, go to %1. Remind me later?</source>
      <translation variants="no">注意，使用影音傳輸模式來傳輸音樂可讓您獲得最佳的音樂體驗。要想進一步了解，請瀏覽%[99]1。稍後再提醒我？</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_cancelled">
      <source>Refresh cancelled</source>
      <translation variants="no">重新整理已取消</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_kb">
      <source>%Ln kB</source>
      <translation>
        <numerusform plurality="a">%Ln kB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_arrange">
      <source>Arrange</source>
      <translation variants="no">排列</translation>
    </message>
    <message numerus="no" id="txt_mus_info_an_error_occurred">
      <source>An error occurred. Sharing is not currently available.</source>
      <translation variants="no">發生錯誤。目前無法使用分享。</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_mb">
      <source>%Ln MB</source>
      <translation>
        <numerusform plurality="a">%Ln MB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subhead_playlists_1l">
      <source>Playlists (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">播放清單(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_file_name">
      <source>File name</source>
      <translation variants="yes">
        <lengthvariant priority="1">檔案名稱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown8">
      <source>Unknown</source>
      <translation variants="no">不明</translation>
    </message>
    <message numerus="no" id="txt_short_caption_music">
      <source>Music</source>
      <translation variants="no">zh_tw #Music</translation>
    </message>
    <message numerus="no" id="txt_mus_info_licence_expired">
      <source>Licence expired. Unable to play selection.</source>
      <translation variants="no">zh_tw #Unable to play selection. Licence expired.</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_music_player">
      <source>Music player</source>
      <translation variants="yes">
        <lengthvariant priority="1">音樂播放機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_song_number">
      <source>Song number</source>
      <translation variants="yes">
        <lengthvariant priority="1">歌曲編號</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_licences">
      <source>Licences</source>
      <translation variants="yes">
        <lengthvariant priority="1">授權</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_usb_conn_in_progress">
      <source>USB connection in progress</source>
      <translation variants="no">正在進行USB連線</translation>
    </message>
    <message numerus="no" id="txt_mus_info_unable_to_create_playlist">
      <source>Unable to create playlist. Name is already in use.</source>
      <translation variants="no">無法建立播放清單。名稱已存在。</translation>
    </message>
    <message numerus="no" id="txt_mus_button_create_new">
      <source>Create new</source>
      <translation variants="yes">
        <lengthvariant priority="1">新增</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subhead_albums_1l">
      <source>Albums (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">專輯(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_web_site">
      <source>Web site</source>
      <translation variants="yes">
        <lengthvariant priority="1">網站</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_bitrate_val_ln_kbps">
      <source>%Ln Kbps</source>
      <translation>
        <numerusform plurality="a">%Ln kbps</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_unable_to_delete_file">
      <source>Unable to delete file. File is currently in use.</source>
      <translation variants="no">無法刪除檔案。檔案使用中。</translation>
    </message>
    <message numerus="no" id="txt_mus_info_unable_to_play_selection">
      <source>Unable to play selection. Operation cancelled.</source>
      <translation variants="no">無法播放所選項目。作業已取消。</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_there_are_no_recommendations">
      <source>There are no recommendations for this track</source>
      <translation variants="no">沒有與此曲目相關的推薦</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_sampling_rate_val_ln_hz">
      <source>%Ln hz</source>
      <translation>
        <numerusform plurality="a">%Ln Hz</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subhead_songs_l1">
      <source>All songs (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">所有歌曲(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_shuffle">
      <source>Shuffle</source>
      <translation variants="no">隨機播放</translation>
    </message>
    <message numerus="no" id="txt_mus_subhead_1_2l">
      <source>%1 (%L2)</source>
      <translation variants="no">%[29]1 (%L2)</translation>
    </message>
    <message numerus="no" id="txt_mus_button_rename">
      <source>Rename</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Rename</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre">
      <source>Genre</source>
      <translation variants="yes">
        <lengthvariant priority="1">類型</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_file_is_corrupt">
      <source>File is corrupt. Operation cancelled.</source>
      <translation variants="no">檔案已損毀。作業已取消。</translation>
    </message>
    <message numerus="no" id="txt_mus_info_licence_missing">
      <source>Licence missing. Unable to play selection.</source>
      <translation variants="no">zh_tw #Unable to play selection. Licence missing.</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_year">
      <source>Year</source>
      <translation variants="yes">
        <lengthvariant priority="1">年份</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_duration">
      <source>Duration</source>
      <translation variants="yes">
        <lengthvariant priority="1">時間</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_licences_val_click_for_details">
      <source>Click for details</source>
      <translation variants="yes">
        <lengthvariant priority="1">按一下以取得詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_bitrate">
      <source>Bitrate</source>
      <translation variants="yes">
        <lengthvariant priority="1">位元速率</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_format">
      <source>Format</source>
      <translation variants="yes">
        <lengthvariant priority="1">格式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_modified">
      <source>Modified</source>
      <translation variants="yes">
        <lengthvariant priority="1">修改於</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_gb">
      <source>%Ln GB</source>
      <translation>
        <numerusform plurality="a">%Ln GB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown_1">
      <source>Unknown - %1</source>
      <translation variants="no">不明：%1</translation>
    </message>
    <message numerus="no" id="txt_mus_info_out_of_disk_space">
      <source>Refresh cancelled. Out of disk space.</source>
      <translation variants="no">重新整理已取消。記憶體不足。</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_quick_access_to_your_music">
      <source>Quick access to music</source>
      <translation variants="yes">
        <lengthvariant priority="1">快速存取您的音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_removing_songs">
      <source>Removing songs</source>
      <translation variants="no">正在移除歌曲</translation>
    </message>
    <message numerus="no" id="txt_mus_info_adding_songs">
      <source>Adding songs</source>
      <translation variants="no">正在加入歌曲</translation>
    </message>
    <message numerus="yes" id="txt_mus_info_ln_songs_found">
      <source>%Ln songs found</source>
      <translation>
        <numerusform plurality="a">找到%Ln首歌曲</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_send_via_bluetooth">
      <source>Send via Bluetooth</source>
      <translation variants="no">透過藍牙傳送</translation>
    </message>
    <message numerus="no" id="txt_mus_title_remove_songs">
      <source>Remove songs</source>
      <translation variants="no">移除歌曲：</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_preset">
      <source>Select preset</source>
      <translation variants="yes">
        <lengthvariant priority="1">選取預設效果：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_composer">
      <source>Composer</source>
      <translation variants="yes">
        <lengthvariant priority="1">作曲者</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_sampling_rate">
      <source>Sampling rate</source>
      <translation variants="yes">
        <lengthvariant priority="1">取樣率</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown4">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">不明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_refreshing">
      <source>Refreshing</source>
      <translation variants="yes">
        <lengthvariant priority="1">重新整理中</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subhead_artist_1l">
      <source>Artists (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">演出者(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_copyright">
      <source>Copyright</source>
      <translation variants="yes">
        <lengthvariant priority="1">版權</lengthvariant>
      </translation>
    </message>
  </context>
</TS>