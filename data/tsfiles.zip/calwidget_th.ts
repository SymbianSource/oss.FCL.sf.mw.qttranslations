<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="th">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_short_caption_calendar_widget">
      <source>Source 0</source>
      <translation variants="no">th #Calendar widget</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar_widget">
      <source>Source 1</source>
      <translation variants="no">th #Calendar widget</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_no_events_ox">
      <source>Source 2</source>
      <translation variants="no">th #No events in next 7 days</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_l1_events">
      <source>Source 3</source>
      <translation variants="no">th #L%1 events overlapping</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_no_events_tod">
      <source>Source 4</source>
      <translation variants="no">th #No events today</translation>
    </message>
  </context>
</TS>