<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_error_info_there_is_not_enough_memory_currentl">
      <source>There is not enough memory currently.</source>
      <translation variants="no">zh_tw #There is not enough memory currently.</translation>
    </message>
    <message numerus="no" id="txt_error_info_client_or_server_certificate_not_va">
      <source>Client or Server certificate not valid</source>
      <translation variants="no">zh_tw #Client or Server certificate not valid</translation>
    </message>
    <message numerus="no" id="txt_error_info_memory_full_delete_data_from_memory_card">
      <source>Memory full. Delete or move some data from %1: Memory card.</source>
      <translation variants="no">zh_tw #Memory full. Delete or move some data from %1: Memory card.</translation>
    </message>
    <message numerus="no" id="txt_error_info_client_certificate_not_supported">
      <source>Client certificate not supported</source>
      <translation variants="no">zh_tw #Client certificate not supported</translation>
    </message>
    <message numerus="no" id="txt_error_info_expectation_failed">
      <source>Expectation failed</source>
      <translation variants="no">zh_tw #Expectation failed</translation>
    </message>
    <message numerus="no" id="txt_error_info_there_is_a_problem_with_the_server">
      <source>There is a problem with the server. Please try again later.</source>
      <translation variants="no">zh_tw #There is a problem with the server. Please try again later.</translation>
    </message>
    <message numerus="no" id="txt_error_info_application_not_deleted">
      <source>Application not deleted. </source>
      <translation variants="no">zh_tw #Application not deleted. </translation>
    </message>
    <message numerus="no" id="txt_error_info_file_format_unknown">
      <source>File format unknown</source>
      <translation variants="no">zh_tw #File format unknown</translation>
    </message>
    <message numerus="no" id="txt_error_info_an_unexpected_error_occurred">
      <source>An unexpected error occurred.</source>
      <translation variants="no">zh_tw #An unexpected error occurred.</translation>
    </message>
    <message numerus="no" id="txt_error_info_memory_full_delete_data">
      <source>Memory full. Delete or move some data from %1: %2</source>
      <translation variants="no">zh_tw #Memory full. Delete or move some data from %1: %2</translation>
    </message>
    <message numerus="no" id="txt_error_info_memory_low_delete_data">
      <source>Memory low. Delete or move some data from %1: %2</source>
      <translation variants="no">zh_tw #Memory low. Delete or move some data from %1: %2</translation>
    </message>
    <message numerus="no" id="txt_error_info_application_cannot_be_deleted">
      <source>Application cannot be deleted.</source>
      <translation variants="no">zh_tw #Application cannot be deleted.</translation>
    </message>
    <message numerus="no" id="txt_error_info_no_server_access">
      <source>No server access</source>
      <translation variants="no">zh_tw #No server access</translation>
    </message>
    <message numerus="no" id="txt_error_info_personal_certificate_not_found">
      <source>Personal certificate not found</source>
      <translation variants="no">zh_tw #Personal certificate not found</translation>
    </message>
    <message numerus="no" id="txt_error_info_reply_unknown">
      <source>Reply unknown</source>
      <translation variants="no">zh_tw #Reply unknown</translation>
    </message>
    <message numerus="no" id="txt_error_info_application_is_not_compatible_with">
      <source>Application is not compatible with this device.</source>
      <translation variants="no">zh_tw #Application is not compatible with this device.</translation>
    </message>
    <message numerus="no" id="txt_error_info_page_not_available">
      <source>Page not available</source>
      <translation variants="no">zh_tw #Page not available</translation>
    </message>
    <message numerus="no" id="txt_error_info_end_call_first">
      <source>End call first</source>
      <translation variants="no">zh_tw #End call first</translation>
    </message>
    <message numerus="no" id="txt_error_info_server_timeout">
      <source>Server time-out</source>
      <translation variants="no">zh_tw #Server time-out</translation>
    </message>
    <message numerus="no" id="txt_error_info_network_is_unavailable_currently">
      <source>Network  is unavailable currently.</source>
      <translation variants="no">zh_tw #Network  is unavailable currently.</translation>
    </message>
    <message numerus="no" id="txt_error_info_memory_low_delete_data_from_mass_storage">
      <source>Memory low. Delete or move some data from %1: Mass storage.</source>
      <translation variants="no">zh_tw #Memory low. Delete or move some data from %1: Mass storage.</translation>
    </message>
    <message numerus="no" id="txt_error_info_connection_timeout">
      <source>Connection time-out</source>
      <translation variants="no">zh_tw #Connection time-out</translation>
    </message>
    <message numerus="no" id="txt_error_info_memory_low_delete_data_from_memory_card">
      <source>Memory low. Delete or move some data from %1: Memory card.</source>
      <translation variants="no">zh_tw #Memory low. Delete or move some data from %1: Memory card.</translation>
    </message>
    <message numerus="no" id="txt_error_info_page_does_not_exist">
      <source>Page does not exist</source>
      <translation variants="no">zh_tw #Page does not exist</translation>
    </message>
    <message numerus="no" id="txt_error_info_there_is_not_enough_space_currently">
      <source>There is not enough space currently in this drive.</source>
      <translation variants="no">zh_tw #There is not enough space currently in this drive.</translation>
    </message>
    <message numerus="no" id="txt_error_info_installation_package_is_corrupted">
      <source>Installation package is corrupted. You may want to try again.</source>
      <translation variants="no">zh_tw #Installation package is corrupted. You may want to try again.</translation>
    </message>
    <message numerus="no" id="txt_error_info_entered_text_too_long">
      <source>Entered text too long</source>
      <translation variants="no">zh_tw #Entered text too long</translation>
    </message>
    <message numerus="no" id="txt_error_info_memory_full">
      <source>Memory full</source>
      <translation variants="no">zh_tw #Memory full</translation>
    </message>
    <message numerus="no" id="txt_error_info_server_busy">
      <source>Server busy</source>
      <translation variants="no">zh_tw #Server busy</translation>
    </message>
    <message numerus="no" id="txt_error_info_there_is_a_security_issue_with_this">
      <source>There is a security issue with this application.</source>
      <translation variants="no">zh_tw #There is a security issue with this application.</translation>
    </message>
    <message numerus="no" id="txt_error_info_memory_full_delete_data_device_memory">
      <source>Memory full. Delete or move some data from %1: Device memory.</source>
      <translation variants="no">zh_tw #Memory full. Delete or move some data from %1: Device memory.</translation>
    </message>
    <message numerus="no" id="txt_installer_info_uninstallation_failed">
      <source>Uninstallation failed.</source>
      <translation variants="no">zh_tw #Uninstallation failed.</translation>
    </message>
    <message numerus="no" id="txt_error_info_bad_content_encountered">
      <source>Bad content encountered</source>
      <translation variants="no">zh_tw #Bad content encountered</translation>
    </message>
    <message numerus="no" id="txt_error_info_page_cannot_be_accessed">
      <source>Page cannot be accessed</source>
      <translation variants="no">zh_tw #Page cannot be accessed</translation>
    </message>
    <message numerus="no" id="txt_error_info_installer_is_busy_currently">
      <source>Installer is busy currently.</source>
      <translation variants="no">zh_tw #Installer is busy currently.</translation>
    </message>
    <message numerus="no" id="txt_error_info_restarting">
      <source>Restarting</source>
      <translation variants="no">zh_tw #Restarting</translation>
    </message>
    <message numerus="no" id="txt_error_info_memory_full_delete_data_from_mass_storage">
      <source>Memory full. Delete or move some data from %1: Mass storage.</source>
      <translation variants="no">zh_tw #Memory full. Delete or move some data from %1: Mass storage.</translation>
    </message>
    <message numerus="no" id="txt_error_info_installation_package_is_invalid">
      <source>Installation package is invalid.</source>
      <translation variants="no">zh_tw #Installation package is invalid.</translation>
    </message>
    <message numerus="no" id="txt_error_info_client_certificate_rewoked_by_serve">
      <source>Client certificate rewoked by server</source>
      <translation variants="no">zh_tw #Client certificate rewoked by server</translation>
    </message>
    <message numerus="no" id="txt_error_info_secure_connection_failure">
      <source>Secure connection failure</source>
      <translation variants="no">zh_tw #Secure connection failure</translation>
    </message>
    <message numerus="no" id="txt_error_info_no_gateway_reply">
      <source>No gateway reply</source>
      <translation variants="no">zh_tw #No gateway reply</translation>
    </message>
    <message numerus="no" id="txt_error_info_requested_range_not_satisfiable">
      <source>Requested range not satisfiable</source>
      <translation variants="no">zh_tw #Requested range not satisfiable</translation>
    </message>
    <message numerus="no" id="txt_error_info_application_not_installed">
      <source>Application not installed.</source>
      <translation variants="no">zh_tw #Application not installed.</translation>
    </message>
    <message numerus="no" id="txt_error_info_file_could_not_be_created">
      <source>File could not be created</source>
      <translation variants="no">zh_tw #File could not be created</translation>
    </message>
    <message numerus="no" id="txt_error_info_certificate_authority_unknown">
      <source>Certificate authority unknown</source>
      <translation variants="no">zh_tw #Certificate authority unknown</translation>
    </message>
    <message numerus="no" id="txt_error_info_memory_low_delete_data_device_memory">
      <source>Memory low. Delete or move some data from %1: Device memory.</source>
      <translation variants="no">zh_tw #Memory low. Delete or move some data from %1: Device memory.</translation>
    </message>
  </context>
</TS>