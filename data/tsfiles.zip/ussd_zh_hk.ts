<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_ussd_info_there_are_still_unread_notifications">
      <source>There are still unread notifications. Exit anyway?</source>
      <translation variants="no">仍有未讀的訊息。是否仍要退出？</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_exit">
      <source>Exit </source>
      <translation variants="yes">
        <lengthvariant priority="1">退出</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_not_completed">
      <source>Request not completed</source>
      <translation variants="no">要求未完成</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_no_service">
      <source>No service</source>
      <translation variants="no">無服務</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">不允許</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_done">
      <source>Done</source>
      <translation variants="no">完成</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_next">
      <source>Next</source>
      <translation variants="yes">
        <lengthvariant priority="1">下一個</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_sending">
      <source>Sending</source>
      <translation variants="no">正在傳送服務指令</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_reply">
      <source>Reply </source>
      <translation variants="yes">
        <lengthvariant priority="1">回覆</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_service_commands">
      <source>Service commands</source>
      <translation variants="no">服務指令</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_not_done">
      <source>Not done</source>
      <translation variants="no">未完成</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_message">
      <source>Message:</source>
      <translation variants="no">已收訊息：</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_not_confirmed">
      <source>Request not confirmed</source>
      <translation variants="no">要求未確認</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_unable_to_use_network_phone_is">
      <source>Unable to use network. Phone is currently in offline mode.</source>
      <translation variants="no">無法在離線模式使用網絡</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_reply">
      <source>Reply:</source>
      <translation variants="no">回覆：</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_completed">
      <source>Request completed</source>
      <translation variants="no">要求已完成</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_result_unknown">
      <source>Result unknown</source>
      <translation variants="no">不明的回應</translation>
    </message>
  </context>
</TS>