<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_power_management_dpopinfo_psm_activated_automa">
      <source>Power Save Mode activated</source>
      <translation variants="no">省電模式已開</translation>
    </message>
    <message numerus="no" id="txt_power_setlabel_val_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_dpopinfo_unplug_charger_to_save_energy">
      <source>Unplug charger to save energy</source>
      <translation variants="no">請拔掉充電器</translation>
    </message>
    <message numerus="no" id="txt_power_list_activate_power_save_mode_automatica">
      <source>Activate power save mode automatically when low power. Turns off automatically when charger is connected.</source>
      <translation variants="no">是否在電量不足時自動啟動省電模式？為裝置充電會自動停用此模式。</translation>
    </message>
    <message numerus="no" id="txt_power_list_activating_power_save_mode_will_con">
      <source>Activating power save mode will consumes minimal power. Turns off all power consuming operations/features like Bluetooth, WLAN, Vibra, Tactile feedback, Key tones, Screensaver, Wallpapers and also dimming screen brightness, Switching Network from 3G to 2G.Turns off automatically when charger is connected.</source>
      <translation variants="no">啟動省電模式可以延長電池使用時間。它會關閉所有非必要的功能，例如藍牙、WLAN、觸控螢幕震動提示和觸覺回饋、鍵盤音和螢幕保護。它也會將螢幕調暗並讓裝置使用2G網絡。為裝置充電會自動停用此模式。</translation>
    </message>
    <message numerus="no" id="txt_power_management_dpophead_100_full">
      <source>100% Full</source>
      <translation variants="no">100%已滿</translation>
    </message>
    <message numerus="no" id="txt_power_list_power_save_mode">
      <source>Power Save Mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">省電模式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_management_dpopinfo_low_battery">
      <source>Low Battery</source>
      <translation variants="no">電量不足</translation>
    </message>
    <message numerus="no" id="txt_power_setlabel_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_management_subhead_power_management">
      <source>Power Management</source>
      <translation variants="yes">
        <lengthvariant priority="1">電源管理</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_powermgt_dblist_charging">
      <source>Charging</source>
      <translation variants="no">zh_hk #Charging</translation>
    </message>
  </context>
</TS>