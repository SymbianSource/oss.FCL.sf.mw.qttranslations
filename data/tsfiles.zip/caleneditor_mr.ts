<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="mr">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Source 0</source>
      <translation variants="no">Monthly</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_anniversary_saved">
      <source>Source 1</source>
      <translation variants="no">New anniversary saved</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_time">
      <source>Source 2</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_event">
      <source>Source 3</source>
      <translation variants="yes">
        <lengthvariant priority="1">New event</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Source 4</source>
      <translation variants="yes">
        <lengthvariant priority="1">Start date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Source 5</source>
      <translation variants="no">Yearly</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>Source 6</source>
      <translation variants="yes">
        <lengthvariant priority="1">To do</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Source 7</source>
      <translation variants="no">Repeat</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_off">
      <source>Source 8</source>
      <translation variants="no">Off</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_anniversary_updated">
      <source>Source 9</source>
      <translation variants="no">Anniversary updated</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Source 10</source>
      <translation variants="no">Remove description</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Source 11</source>
      <translation variants="yes">
        <lengthvariant priority="1">Start time</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_hours">
      <source>Source 12</source>
      <translation variants="no">Before %Ln hours</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_anniv_default_date">
      <source>Source 13</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_days">
      <source>Source 14</source>
      <translation variants="no">Before %Ln days</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_date">
      <source>Source 15</source>
      <translation variants="no">%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Source 16</source>
      <translation variants="no">Only once</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Source 17</source>
      <translation variants="yes">
        <lengthvariant priority="1">Meeting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_description">
      <source>Source 18</source>
      <translation variants="no">Description</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_anniversary">
      <source>Source 19</source>
      <translation variants="yes">
        <lengthvariant priority="1">Anniversary</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_event">
      <source>Source 20</source>
      <translation variants="no">Delete event</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Source 21</source>
      <translation variants="no">Daily</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Source 22</source>
      <translation variants="no">Delete meeting?</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Source 23</source>
      <translation variants="no">Discard changes</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>Source 24</source>
      <translation variants="yes">
        <lengthvariant priority="1">End date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_date">
      <source>Source 25</source>
      <translation variants="yes">
        <lengthvariant priority="1">Alarm date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_minutes">
      <source>Source 26</source>
      <translation variants="no">Before %Ln minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Source 27</source>
      <translation variants="no">Delete anniversary?</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_occasion">
      <source>Source 28</source>
      <translation variants="no">Occasion</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_weeks">
      <source>Source 29</source>
      <translation variants="no">Before %Ln weeks</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_alarm_date_and_time">
      <source>Source 30</source>
      <translation variants="no">Alarm date and time</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Source 31</source>
      <translation variants="no">Repeat until</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_repeat_until">
      <source>Source 32</source>
      <translation variants="yes">
        <lengthvariant priority="1">Repeat until</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_date">
      <source>Source 33</source>
      <translation variants="no">Date</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_meeting_updated">
      <source>Source 34</source>
      <translation variants="no">Meeting updated</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Source 35</source>
      <translation variants="no">Weekly</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_anniversary">
      <source>Source 36</source>
      <translation variants="yes">
        <lengthvariant priority="1">New anniversary</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_meeting_saved">
      <source>Source 37</source>
      <translation variants="no">New meeting saved</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Source 38</source>
      <translation variants="yes">
        <lengthvariant priority="1">Delete repeated entry :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>Source 39</source>
      <translation variants="no">This occurrence only</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Source 40</source>
      <translation variants="no">Location</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>Source 41</source>
      <translation variants="no">All day event</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm">
      <source>Source 42</source>
      <translation variants="no">Alarm</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_end_time">
      <source>Source 43</source>
      <translation variants="no">End time</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_fortnightly">
      <source>Source 44</source>
      <translation variants="no">Fortnightly</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Source 45</source>
      <translation variants="no">Add description</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>Source 46</source>
      <translation variants="yes">
        <lengthvariant priority="1">End time</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_on_alarm">
      <source>Source 47</source>
      <translation variants="no">Alarm</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_start_time">
      <source>Source 48</source>
      <translation variants="no">Start time</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Source 49</source>
      <translation variants="no">Subject</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_time">
      <source>Source 50</source>
      <translation variants="yes">
        <lengthvariant priority="1">Alarm time</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Source 51</source>
      <translation variants="yes">
        <lengthvariant priority="1">Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Source 52</source>
      <translation variants="yes">
        <lengthvariant priority="1">Edit :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Source 53</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>Source 54</source>
      <translation variants="no">All occurences</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Source 55</source>
      <translation variants="yes">
        <lengthvariant priority="1">Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_meeting">
      <source>Source 56</source>
      <translation variants="yes">
        <lengthvariant priority="1">New meeting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_day_before">
      <source>Source 57</source>
      <translation variants="no">1 day before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_off">
      <source>Source 58</source>
      <translation variants="no">Off</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_hour_before">
      <source>Source 59</source>
      <translation variants="no">1 hour before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_2_days_before">
      <source>Source 60</source>
      <translation variants="no">2 days before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_at_the_start">
      <source>Source 61</source>
      <translation variants="no">At the start</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_15_minutes_befo">
      <source>Source 62</source>
      <translation variants="no">15 minutes before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_5_minutes_befor">
      <source>Source 63</source>
      <translation variants="no">5 minutes before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_time">
      <source>Source 64</source>
      <translation variants="no">Reminder time</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Source 65</source>
      <translation variants="no">Reminder</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_30_minutes_befo">
      <source>Source 66</source>
      <translation variants="no">30 minutes before</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entry">
      <source>Source 67</source>
      <translation variants="no">Delete entry?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_on_event_day">
      <source>Source 68</source>
      <translation variants="no">On event day</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_workdays">
      <source>Source 69</source>
      <translation variants="no">Workdays</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Source 70</source>
      <translation variants="no">Delete entries ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_reminder_time">
      <source>Source 71</source>
      <translation variants="no">%1</translation>
    </message>
  </context>
</TS>