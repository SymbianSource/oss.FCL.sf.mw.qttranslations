<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="id">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_info_delete_all_paired_devices_some_device">
      <source>Delete all paired devices? Some devices may be disconnected.</source>
      <translation variants="no">Hapus semua perangkat pasangan? Sambungan beberapa perangkat mungkin telah terputus.</translation>
    </message>
    <message numerus="no" id="txt_bt_title_unable_to_enter_sim_access_profile">
      <source>Unable to enter SIM access profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tidak dapat mengaktifkan modus SIM jauh</lengthvariant>
        <lengthvariant priority="2">Tdk dpt m'aktfkn mds SIM jh</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_connected">
      <source>Connected</source>
      <translation variants="no">Tersambung ke</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_devices_some_devices_may_b">
      <source>Delete all devices? Some devices may be disconnected.</source>
      <translation variants="no">Hapus semua perangkat? Sambungan beberapa perangkat mungkin telah terputus.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unsupported_device_1">
      <source>Unsupported device: %1</source>
      <translation variants="no">Perangkat tidak didukung:
%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_waiting_the_other_device">
      <source>Waiting for the other device</source>
      <translation variants="no">Menunggu perangkat lain</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to">
      <source>Connect to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sambungkan ke:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_there_seems_to_be_a_lot_of_pairing_que">
      <source>There seems to be uncommonly lot of pairing queries. Turn Bluetooth off to protect your device?</source>
      <translation variants="no">Jml p'mintaan pema­sangan yg tdk biasa tlh t'deteksi. Nonaktif­kan Bluetooth untuk melin­dungi perangkat Anda?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_other_files_received">
      <source>N other files received</source>
      <translation variants="no">id ##N other files received</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_on_ini_offline_mode">
      <source>Trun Bluetooth on in offline mode?</source>
      <translation variants="no">Aktifkan Bluetooth dalam modus offline?</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_with_1_failed_either_the_pas">
      <source>Pairing with %1 failed. Either the passcodes didn’t match or the other device is turned off.</source>
      <translation variants="no">Pemasangan dengan %[16]1 gagal. Kode akses tidak cocok atau perangkat lain dinonaktifkan.</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_use">
      <source>in use</source>
      <translation variants="no">aktif</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_off">
      <source>is now off</source>
      <translation variants="no">sekarang tidak aktif</translation>
    </message>
    <message numerus="no" id="txt_bt_info_enter_the_following_code_to_the_1">
      <source>Enter the following code to the %1:</source>
      <translation variants="no">Masukkan kode akses berikut di %[38]1:</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth_used">
      <source>Bluetooth used</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">Modus SIM jauh</translation>
    </message>
    <message numerus="no" id="txt_bt_info_not_possible_during_a_call">
      <source>Not possible during a call</source>
      <translation variants="no">Tidak dapat membuat sambungan Bluetooth selama panggilan</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_paired_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dialog_please_enter_the_passcode_for_1">
      <source>Please enter the passcode for %1:</source>
      <translation variants="no">Masukkan kode akses untuk %[47]1:</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_on">
      <source>is now on</source>
      <translation variants="no">sekarang aktif</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pairing_with_1">
      <source>Pairing with %1</source>
      <translation variants="no">Memasangkan dengan %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_failed_remote_device_is_pairi">
      <source>Pairing failed. Remote device is pairing with another device.</source>
      <translation variants="no">Pemasangan gagal. Perangkat jauh sedang terpasang dengan perangkat lain.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_blocked_devices">
      <source>Delete all blocked devices?</source>
      <translation variants="no">Hapus semua perangkat yang diblokir?</translation>
    </message>
    <message numerus="no" id="txt_bt_button_more_devices">
      <source>More devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Perangkat lainnya</lengthvariant>
        <lengthvariant priority="2">Perangkat lain</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_bluetooth_not_allowed_to_be_turned_on">
      <source>Bluetooth not allowed to be turned on in offline mode</source>
      <translation variants="no">Tidak dapat mengaktifkan Bluetooth dalam modus offline</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_cancelled_from_1">
      <source>from %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_connected_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_entering_sim_access_profile">
      <source>Entering SIM access profile</source>
      <translation variants="no">Mengaktifkan modus SIM jauh</translation>
    </message>
    <message numerus="no" id="txt_bt_title_received_from_1">
      <source>Received from %1</source>
      <translation variants="no">Diterima dari %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_exited">
      <source>exited</source>
      <translation variants="no">tidak aktif</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_disconnected">
      <source>Disconnected</source>
      <translation variants="no">Samb. terputus dari</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_unpaired">
      <source>Unpaired</source>
      <translation variants="no">Pasangn dibtlkn dgn</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_receiving_failed">
      <source>Receiving failed</source>
      <translation variants="no">Penerimaan gagal</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from">
      <source>Receive messages from:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Terima pesan dari:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_disconnected_from_1">
      <source>from %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_hidden">
      <source>is now hidden</source>
      <translation variants="no">sekarang tersembunyi</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_paired">
      <source>Paired</source>
      <translation variants="no">Dipasangkan dengan</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sending_cancelled">
      <source>Sending cancelled</source>
      <translation variants="no">Pengiriman dibtlkan</translation>
    </message>
    <message numerus="no" id="txt_bt_info_do_you_still_want_to_enable_sim_access">
      <source>Do you still want to enable SIM access profile?</source>
      <translation variants="no">Aktifkan modus SIM jauh?</translation>
    </message>
    <message numerus="no" id="txt_bt_title_sending_file_l1l2_to_3">
      <source>Sending file %L1/%L2 to %3</source>
      <translation variants="no">Mengirim file %L1/%L2 ke %3</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_off_there_is_an_active">
      <source>Trun Bluetooth off? There is an active connection.</source>
      <translation variants="no">Sambungan Bluetooth aktif sudah ada. Tetap aktifkan sambungan baru?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_battery_low">
      <source>Battery low</source>
      <translation variants="no">Baterai akan hbs dlm</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pair_with">
      <source>Pair with:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dipasangkan dengan:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_try_again">
      <source>Try again</source>
      <translation variants="yes">
        <lengthvariant priority="1">Coba lagi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_disable_sim_access_profile">
      <source>Exit SIM access profile?</source>
      <translation variants="no">Nonaktifkan modus SIM jauh?</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to_paired_device">
      <source>Connect to paired device:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sambungkan ke perangkat pasangan:</lengthvariant>
        <lengthvariant priority="2">Samb. ke prgkt pasangan:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_sim_access_profile_is_used_next_time_t">
      <source>SIM access profile is used next time the car kit connects to this device and the Bluetooth is turned on.</source>
      <translation variants="no">Modus SIM jauh diaktifkan saat berikutnya car kit disambungkan ke perangkat ini dan Bluetooth diaktifkan</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_pair_with_1">
      <source>Unable to pair with %1</source>
      <translation variants="no">Tidak dapat dipasangkan dengan %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_bluetooth_device_address_1">
      <source>Bluetooth device address: %1</source>
      <translation variants="no">Alamat perangkat Bluetooth:
%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_perform_bluetooth_operation">
      <source>Unable to perform Bluetooth operation</source>
      <translation variants="no">Tidak dapat mengoperasikan Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_title_operation_not_possible_when_sim_acces">
      <source>Operation not possible when SIM access profile is in use</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tidak dapat menjalankan operasi</lengthvariant>
        <lengthvariant priority="2">Tdk dpt m'jalankan operasi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from_paired_device">
      <source>Receive messages from paired device:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Terima pesan dari:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_connect_with_bluetooth">
      <source>Unable to connect with %1</source>
      <translation variants="no">Tidak dapat tersambung dengan %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_all_files_sent">
      <source>All files sent</source>
      <translation variants="no">Semua file dikirim ke</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receiving_files_from_1">
      <source>Receiving from %1</source>
      <translation variants="no">Menerima dari %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_with_1">
      <source>with %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_title_send_to">
      <source>Send to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kirim ke:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_does_this_code_match_the_code_on_1">
      <source>Does this code match the code on %1?</source>
      <translation variants="no">Apakah kode akses berikut cocok dengan kode di %[28]1?</translation>
    </message>
    <message numerus="no" id="txt_bt_list_dont_ask_again_with_this_device">
      <source>Don't ask again with this device</source>
      <translation variants="no">Jangan tanya lagi dengan perangkat ini</translation>
    </message>
    <message numerus="no" id="txt_bt_title_no_sim_card_in_the_device">
      <source>No SIM card in the device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tidak ada Kartu SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpinfo_as_web_connection">
      <source>as web connection</source>
      <translation variants="no">digunakan sebagai sambungan Web</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_1">
      <source>in %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_to_connect_1_2_needs_to_be_disconnec">
      <source>To connect %1 %2 needs to be disconnected first.</source>
      <translation variants="no">Tidak dapat tersambung ke %[35]1. Putuskan dulu sambungan dari %[35]2.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_files_already_received">
      <source>N files already received</source>
      <translation variants="no">id ##N files already received</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_sent_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_try_entering_the_sim_access_profile_ag">
      <source>Try entering the SIM access profile again?</source>
      <translation variants="no">Coba aktifkan modus SIM jauh lagi?</translation>
    </message>
  </context>
</TS>