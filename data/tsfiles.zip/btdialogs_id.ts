<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="id">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_info_bluetooth_device_address_1">
      <source>Source 0</source>
      <translation variants="no">id #Bluetooth device address: %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_paired_devices_some_device">
      <source>Source 1</source>
      <translation variants="no">id #Delete all paired devices? Some devices may be disconnected.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_not_possible_during_a_call">
      <source>Source 2</source>
      <translation variants="no">id #Not possible during a call</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_perform_bluetooth_operation">
      <source>Source 3</source>
      <translation variants="no">id #Unable to perform Bluetooth operation</translation>
    </message>
    <message numerus="no" id="txt_bt_title_unable_to_enter_sim_access_profile">
      <source>Source 4</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #Unable to enter SIM access profile</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_paired_to_1">
      <source>Source 5</source>
      <translation variants="no">id #to %1</translation>
    </message>
    <message numerus="no" id="txt_bt_title_operation_not_possible_when_sim_acces">
      <source>Source 6</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #Operation not possible when SIM access profile is in use</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from">
      <source>Source 7</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #Receive messages from:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dialog_please_enter_the_passcode_for_1">
      <source>Source 8</source>
      <translation variants="no">id #Please enter the passcode for %1:</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from_paired_device">
      <source>Source 9</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #Receive messages from paired device:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_disconnected_from_1">
      <source>Source 10</source>
      <translation variants="no">id #from %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_on">
      <source>Source 11</source>
      <translation variants="no">id #is now on</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_connected">
      <source>Source 12</source>
      <translation variants="no">id #Connected</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_hidden">
      <source>Source 13</source>
      <translation variants="no">id #is now hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pairing_with_1">
      <source>Source 14</source>
      <translation variants="no">id #Pairing with %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_devices_some_devices_may_b">
      <source>Source 15</source>
      <translation variants="no">id #Delete all devices? Some devices may be disconnected.</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_paired">
      <source>Source 16</source>
      <translation variants="no">id #Paired</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_connect_with_bluetooth">
      <source>Source 17</source>
      <translation variants="no">id #Unable to connect with %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unsupported_device_1">
      <source>Source 18</source>
      <translation variants="no">id #Unsupported device: %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sending_cancelled">
      <source>Source 19</source>
      <translation variants="no">id #Sending cancelled</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_all_files_sent">
      <source>Source 20</source>
      <translation variants="no">id #All files sent</translation>
    </message>
    <message numerus="no" id="txt_bt_info_waiting_the_other_device">
      <source>Source 21</source>
      <translation variants="no">id #Waiting for the other device</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_failed_remote_device_is_pairi">
      <source>Source 22</source>
      <translation variants="no">id #Pairing failed. Remote device is pairing with another device.</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receiving_files_from_1">
      <source>Source 23</source>
      <translation variants="no">id #Receiving from %1</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to">
      <source>Source 24</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #Connect to:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_blocked_devices">
      <source>Source 25</source>
      <translation variants="no">id #Delete all blocked devices?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_with_1">
      <source>Source 26</source>
      <translation variants="no">id #with %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_do_you_still_want_to_enable_sim_access">
      <source>Source 27</source>
      <translation variants="no">id #Do you still want to enable SIM access profile?</translation>
    </message>
    <message numerus="no" id="txt_bt_button_more_devices">
      <source>Source 28</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #More devices</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_title_send_to">
      <source>Source 29</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #Send to:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_title_sending_file_l1l2_to_3">
      <source>Source 30</source>
      <translation variants="no">id #Sending file %L1/%L2 to %3</translation>
    </message>
    <message numerus="no" id="txt_bt_info_there_seems_to_be_a_lot_of_pairing_que">
      <source>Source 31</source>
      <translation variants="no">id #There seems to be uncommonly lot of pairing queries. Turn Bluetooth off to protect your device?</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_off_there_is_an_active">
      <source>Source 32</source>
      <translation variants="no">id #Trun Bluetooth off? There is an active connection.</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth">
      <source>Source 33</source>
      <translation variants="no">id #Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_battery_low">
      <source>Source 34</source>
      <translation variants="no">id #Battery low</translation>
    </message>
    <message numerus="no" id="txt_bt_info_does_this_code_match_the_code_on_1">
      <source>Source 35</source>
      <translation variants="no">id #Does this code match the code on %1?</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_other_files_received">
      <source>Source 36</source>
      <translation variants="no">id #N other files received</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pair_with">
      <source>Source 37</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #Pair with:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_dont_ask_again_with_this_device">
      <source>Source 38</source>
      <translation variants="no">id #Don't ask again with this device</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_on_ini_offline_mode">
      <source>Source 39</source>
      <translation variants="no">id #Trun Bluetooth on in offline mode?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_connected_to_1">
      <source>Source 40</source>
      <translation variants="no">id #to %1</translation>
    </message>
    <message numerus="no" id="txt_bt_title_no_sim_card_in_the_device">
      <source>Source 41</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #No SIM card in the device</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_with_1_failed_either_the_pas">
      <source>Source 42</source>
      <translation variants="no">id #Pairing with %1 failed. Either the passcodes didn’t match or the other device is turned off.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_entering_sim_access_profile">
      <source>Source 43</source>
      <translation variants="no">id #Entering SIM access profile</translation>
    </message>
    <message numerus="no" id="txt_bt_dpinfo_as_web_connection">
      <source>Source 44</source>
      <translation variants="no">id #as web connection</translation>
    </message>
    <message numerus="no" id="txt_bt_button_try_again">
      <source>Source 45</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #Try again</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_title_received_from_1">
      <source>Source 46</source>
      <translation variants="no">id #Received from %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_1">
      <source>Source 47</source>
      <translation variants="no">id #in %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_disable_sim_access_profile">
      <source>Source 48</source>
      <translation variants="no">id #Exit SIM access profile?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_exited">
      <source>Source 49</source>
      <translation variants="no">id #exited</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_use">
      <source>Source 50</source>
      <translation variants="no">id #in use</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to_paired_device">
      <source>Source 51</source>
      <translation variants="yes">
        <lengthvariant priority="1">id #Connect to paired device:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_disconnected">
      <source>Source 52</source>
      <translation variants="no">id #Disconnected</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_off">
      <source>Source 53</source>
      <translation variants="no">id #is now off</translation>
    </message>
    <message numerus="no" id="txt_bt_info_sim_access_profile_is_used_next_time_t">
      <source>Source 54</source>
      <translation variants="no">id #SIM access profile is used next time the car kit connects to this device and the Bluetooth is turned on.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_to_connect_1_2_needs_to_be_disconnec">
      <source>Source 55</source>
      <translation variants="no">id #To connect %1 %2 needs to be disconnected first.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_enter_the_following_code_to_the_1">
      <source>Source 56</source>
      <translation variants="no">id #Enter the following code to the %1:</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_pair_with_1">
      <source>Source 57</source>
      <translation variants="no">id #Unable to pair with %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_files_already_received">
      <source>Source 58</source>
      <translation variants="no">id #N files already received</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_unpaired">
      <source>Source 59</source>
      <translation variants="no">id #Unpaired</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth_used">
      <source>Source 60</source>
      <translation variants="no">id #Bluetooth used</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_sent_to_1">
      <source>Source 61</source>
      <translation variants="no">id #to %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sim_access_profile">
      <source>Source 62</source>
      <translation variants="no">id #SIM access profile</translation>
    </message>
    <message numerus="no" id="txt_bt_info_try_entering_the_sim_access_profile_ag">
      <source>Source 63</source>
      <translation variants="no">id #Try entering the SIM access profile again?</translation>
    </message>
  </context>
</TS>