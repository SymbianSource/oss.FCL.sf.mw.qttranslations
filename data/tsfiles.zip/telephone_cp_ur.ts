<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_title_if_not_answered">
      <source>If not answered:</source>
      <translation variants="yes">
        <lengthvariant priority="1">اگر جواب نہیں دیا گیا:</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_phone_setlabel_divert_delay_ln_seconds">
      <source>Divert delay %Ln seconds</source>
      <translation>
        <numerusform plurality="a">منتقلی میں تاخیر: %Ln سیکنڈ</numerusform>
        <numerusform plurality="b">منتقلی میں تاخیر: %Ln سیکنڈ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">غیر کارآمد فون نمبر</translation>
    </message>
    <message numerus="no" id="txt_phone_list_to_voice_mailbox">
      <source>To voice mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">صوتی میل باکس کو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_list_enter_number_manually">
      <source>Enter number manually</source>
      <translation variants="yes">
        <lengthvariant priority="1">نمبر داخل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_busy">
      <source>If busy:</source>
      <translation variants="yes">
        <lengthvariant priority="1">اگر مصروف ہیں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_diverts_deactivated">
      <source>Diverts deactivated</source>
      <translation variants="no">منتقلیاں غیر کارآمد کی گئیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number">
      <source>Number:</source>
      <translation variants="no">نمبر:</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_out_of_reach">
      <source>If out of reach:</source>
      <translation variants="yes">
        <lengthvariant priority="1">اگر پہنچ سے باہر ہے:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_diverts_activated">
      <source>Diverts activated</source>
      <translation variants="no">منتقلیاں کارآمد کی گئیں</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_not_available">
      <source>If not available:</source>
      <translation variants="yes">
        <lengthvariant priority="1">اگر دستیاب نہیں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_not_answered">
      <source>If not answered</source>
      <translation variants="no">اگر جواب نہیں دیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_ask_first">
      <source>Ask first</source>
      <translation variants="no">پہلے دریافت کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_title_delay">
      <source>Delay:</source>
      <translation variants="yes">
        <lengthvariant priority="1">تاخیر کی مدت:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_list_international_calls_except_to_home">
      <source>International calls except to home country</source>
      <translation variants="no">اصل وطن کے علاوہ بین الاقوامی کالیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_video">
      <source>Video</source>
      <translation variants="no">ویڈیو میل باکس</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_activated">
      <source>Barring activated</source>
      <translation variants="no">کال بندش کارآمد کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_password">
      <source>Barring password</source>
      <translation variants="no">بندشی لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conflict_error">
      <source>Conflict error</source>
      <translation variants="no">تصادم کی غلطی</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹیلی فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_divert_deactivated">
      <source>Divert deactivated</source>
      <translation variants="no">منتقلی غیر کارآمد کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_divert_not_active">
      <source>Divert not active</source>
      <translation variants="no">ur #Divert not active</translation>
    </message>
    <message numerus="no" id="txt_phone_info_to_numbernl1">
      <source>To number:\n%L1</source>
      <translation variants="no">ur #To number:
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_edit_barring_password_val_edit">
      <source>Edit</source>
      <translation variants="no">ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting">
      <source>Call waiting</source>
      <translation variants="no">کال انتظار میں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_password_blocked">
      <source>Barring password blocked</source>
      <translation variants="no">بندشی لفظ شناخت بلاک کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting_val_off">
      <source>Off</source>
      <translation variants="no">کارآمد نہیں کیا گيا</translation>
    </message>
    <message numerus="no" id="txt_phone_list_incoming_call_when_abroad">
      <source>Incoming call when abroad</source>
      <translation variants="no">رومنگ میں درآمدی کالیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_send_my_caller_id">
      <source>Send my caller id</source>
      <translation variants="no">کال کنندہ شناخت بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_waiting_activated">
      <source>Call waiting activated</source>
      <translation variants="no">کال انتظار کارآمد کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_waiting_deactivated">
      <source>Call waiting deactivated</source>
      <translation variants="no">کال انتظار غیر کارآمد کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_out_of_reach">
      <source>If out of reach</source>
      <translation variants="no">اگر پہنچ سے دور ہو</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_barring">
      <source>Call barring</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال پر بندش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_current_password">
      <source>Current password</source>
      <translation variants="no">موجودہ لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_phone_info_password_changed">
      <source>Password changed</source>
      <translation variants="no">لفظ شناخت بدل گیا</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_rejected">
      <source>Request rejected</source>
      <translation variants="no">درخواست مسترد کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_not_confirmed">
      <source>Request not confirmed</source>
      <translation variants="no">درخواست کی تصدیق نہیں کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phone_title_all_calls">
      <source>All calls:</source>
      <translation variants="yes">
        <lengthvariant priority="1">تمام کالیں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_title_active_for">
      <source>Active for</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Active for:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting_val_on">
      <source>On</source>
      <translation variants="no">کارآمد کیا گيا</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_val_line_2">
      <source>Line 2</source>
      <translation variants="no">لائن ۲</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_calls">
      <source>Video calls</source>
      <translation variants="no">ur #Video calls</translation>
    </message>
    <message numerus="no" id="txt_phone_info_fax">
      <source>Fax</source>
      <translation variants="no">ur #Fax</translation>
    </message>
    <message numerus="no" id="txt_phone_list_incoming_calls">
      <source>Incoming calls</source>
      <translation variants="no">آنے والی کالیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_voice_calls">
      <source>Voice calls</source>
      <translation variants="no">ur #Voice calls</translation>
    </message>
    <message numerus="no" id="txt_phone_formlabel_show_call_duration">
      <source>Show call duration</source>
      <translation variants="no">کال کی مدت دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_deactivated">
      <source>Barring deactivated</source>
      <translation variants="no">کال بندش غیر کارآمد کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_divert">
      <source>Call divert</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال منتقلی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_yes">
      <source>Yes</source>
      <translation variants="no">ہاں</translation>
    </message>
    <message numerus="no" id="txt_phone_list_outgoing_calls">
      <source>Outgoing calls</source>
      <translation variants="no">برآمدی کالیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_show_automatic">
      <source>Show automatically</source>
      <translation variants="no">خودکار طور پر دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_soft_reject">
      <source>Reject call with message</source>
      <translation variants="no">کال مع پیغام مسترد کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_video_mbx">
      <source>Video mailbox</source>
      <translation variants="no">ویڈیو میل باکس</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_off">
      <source>Off</source>
      <translation variants="no">کارآمد نہیں کیا گيا</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_val_user_defined">
      <source>User defined</source>
      <translation variants="no">صارف واضح کردہ</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_ip_mbx">
      <source>%1 mailbox</source>
      <translation variants="no">ur #%[17]1 mailbox</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_val_line_1">
      <source>Line 1</source>
      <translation variants="no">لائن ۱</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx">
      <source>Default mailbox</source>
      <translation variants="no">آغازی</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_no">
      <source>No</source>
      <translation variants="no">نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking_val_off">
      <source>Off</source>
      <translation variants="no">غیر فعال کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_busy">
      <source>If busy</source>
      <translation variants="no">اگر مصروف ہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹیلی فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_list_international_calls">
      <source>International calls</source>
      <translation variants="no">بین الاقوامی کالیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_not_available">
      <source>If not available</source>
      <translation variants="no">اگر دستیاب نہ ہو</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_voice">
      <source>Voice</source>
      <translation variants="no">صوتی میل باکس</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_show_call_duration_val_off">
      <source>Off</source>
      <translation variants="no">بند</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_show_call_duration_val_on">
      <source>On</source>
      <translation variants="no">چالو</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_received_call">
      <source>Own video in received call</source>
      <translation variants="no">موصول کال میں اپنا ویڈیو</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service_val_video_divert">
      <source>Video divert</source>
      <translation variants="no">ویڈیو کال منتقلی</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting">
      <source>Internet call waiting</source>
      <translation variants="no">انٹرنیٹ کال انتظار</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_all_calls">
      <source>All calls</source>
      <translation variants="no">سب کالیں</translation>
    </message>
    <message numerus="no" id="txt_phone_dblist_active_diverts">
      <source>Active diverts</source>
      <translation variants="no">کارآمد منتقلیاں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_available_in_current_lo">
      <source>Not specified</source>
      <translation variants="no">حالیہ مقام پر خدمت دستیاب نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_edit_barring_password">
      <source>Edit barring password</source>
      <translation variants="no">بندشی لفظ شنا. ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_dont_show">
      <source>Don't show</source>
      <translation variants="no">نہ دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_check_status">
      <source>Check status</source>
      <translation variants="no">حیثیت کی جانچ کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_voice_mbx">
      <source>Voice mailbox</source>
      <translation variants="no">صوتی میل باکس</translation>
    </message>
    <message numerus="no" id="txt_phone_info_divert_activated">
      <source>Divert activated</source>
      <translation variants="no">منتقلی کارآمد کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_available_in_curren">
      <source>Service not available in current location</source>
      <translation variants="no">موجودہ مقام پر خدمت دستیاب نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_on">
      <source>On</source>
      <translation variants="no">فعال کیا گيا</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service_val_voice_divert">
      <source>Voice divert</source>
      <translation variants="no">ویڈیو کال منتقلی</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_operation_not_successful">
      <source>Barring operation not successful. Contact your service provider</source>
      <translation variants="no">بندشی عمل کامیاب نہیں ہوا۔ اپنے خدمت فراہم کار سے رابطہ کریں۔</translation>
    </message>
    <message numerus="no" id="txt_phone_info_new_password">
      <source>New password</source>
      <translation variants="no">نیا لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_not_completed">
      <source>Request not completed</source>
      <translation variants="no">درخواست مکمل شدہ نہیں</translation>
    </message>
    <message numerus="yes" id="txt_phone_info_delay_timenln_seconds">
      <source>Delay time:\n%Ln seconds</source>
      <translation>
        <numerusform plurality="a">ur #Delay time:
%Ln second</numerusform>
        <numerusform plurality="b">ur #Delay time:
%Ln seconds</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking_val_on">
      <source>On</source>
      <translation variants="no">فعال کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_settings">
      <source>Call settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_mbx">
      <source>Call mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال میل باکس</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_call">
      <source>Image in video call</source>
      <translation variants="no">ویڈیو کال میں شبیہہ</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_soft_reject_val_default_text">
      <source>Hi, I’m busy at the moment, but I contact you a bit later.</source>
      <translation variants="no">معاف کیجیے، میں ابھی مصروف ہوں۔ میں آپ کو بعد میں فون کروں گا۔</translation>
    </message>
    <message numerus="yes" id="txt_phone_list_ln_seconds">
      <source>%Ln seconds</source>
      <translation>
        <numerusform plurality="a">%Ln سیکنڈ</numerusform>
        <numerusform plurality="b">%Ln سیکنڈ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_val_none">
      <source>None</source>
      <translation variants="no">کوئی نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking">
      <source>Phone line blocking</source>
      <translation variants="no">لائن کی تبدیلی</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_voice_mbx_line_2">
      <source>Voice mailbox line 2</source>
      <translation variants="no">صوتی میل باکس لائن ۲</translation>
    </message>
    <message numerus="no" id="txt_phone_info_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">اجازت نہیں دی گئی</translation>
    </message>
    <message numerus="no" id="txt_phone_info_result_unknown">
      <source>Result unknown</source>
      <translation variants="no">نتیجہ معلوم نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_default">
      <source>Default</source>
      <translation variants="no">ur #Set by network</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als">
      <source>Phone line in use</source>
      <translation variants="no">لائن استعمال میں ہے</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_voice_line_2">
      <source>Voice line 2</source>
      <translation variants="no">صوتی لائن ۲</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service">
      <source>Service</source>
      <translation variants="no">خدمت</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_lost_select_network">
      <source>Network lost. Select network?</source>
      <translation variants="no">نیٹ ورک ضائع ہو گیا۔ دستیاب نیٹ ورکس کی تلاش کریں؟</translation>
    </message>
    <message numerus="no" id="txt_phone_info_verify_new_password">
      <source>Verify new password</source>
      <translation variants="no">نئے لفظ شناخت کی توثیق:</translation>
    </message>
  </context>
</TS>