<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="de">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_dblist_receiving_files">
      <source>Receiving files</source>
      <translation variants="no">Dateien werden empfangen</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_paired">
      <source>%1 paired</source>
      <translation variants="no">%[11]1 gekoppelt</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="no">Ein (sichtbar)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="no">Ein (verborgen)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_computer">
      <source>Computer</source>
      <translation variants="no">Computer</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_phone">
      <source>Phone</source>
      <translation variants="no">Telefon</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="no">Verbunden (verborgen)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="no">Aus</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_connected">
      <source>%1 connected</source>
      <translation variants="no">%[11]1 verbunden</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_other_device">
      <source>Other device</source>
      <translation variants="no">Anderes Gerät</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_usign_sim_access_profi">
      <source>usign SIM access profile</source>
      <translation variants="no">Externer SIM-Modus</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="no">Verbunden (sichtbar)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_sending_files">
      <source>Sending files</source>
      <translation variants="no">Dateien senden</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_audio_device">
      <source>Audio device</source>
      <translation variants="no">Audiogerät</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_input_device">
      <source>Input device</source>
      <translation variants="no">Eingabegerät</translation>
    </message>
  </context>
</TS>