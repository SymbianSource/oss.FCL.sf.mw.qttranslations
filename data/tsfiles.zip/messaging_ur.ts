<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_messaging_list_time">
      <source>&lt;time&gt;</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_delete_message">
      <source>Delete message</source>
      <translation variants="no">پیغام مٹائیں</translation>
    </message>
    <message numerus="yes" id="txt_messaging_dpophead_ln_outgoing_messages">
      <source>%Ln Outgoing messages </source>
      <translation>
        <numerusform plurality="a">ur ##%Ln Outgoing messages </numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_outgoing_message">
      <source>Outgoing message </source>
      <translation variants="yes">
        <lengthvariant priority="1">پیغام ارسال کیا جا رہا ہے </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add">
      <source>Add   </source>
      <translation variants="no">شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_sound">
      <source>Sound </source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Sound </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_open_link">
      <source>Open link</source>
      <translation variants="no">ربط کھولیں</translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_cc">
      <source>Cc:</source>
      <translation variants="no">نقل اول:</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_business_card">
      <source>Business Card </source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Business Card </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_more">
      <source>More...</source>
      <translation variants="no">دیگر</translation>
    </message>
    <message numerus="yes" id="txt_messaging_dpophead_ln_failed_messages">
      <source>%Ln Failed messages </source>
      <translation>
        <numerusform plurality="a">ur ##%Ln Failed messages </numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority_val_normal">
      <source>Normal </source>
      <translation variants="no">عام</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_new_message">
      <source>New Message </source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_message_sending_failed">
      <source>Message sending failed </source>
      <translation variants="yes">
        <lengthvariant priority="1">پیغام کی ارسالگی ناکام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_item_file">
      <source>Unable to attach item! File type not supported </source>
      <translation variants="no">من. شامل سے قاصر۔ فائل تائید نہیں۔</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_conversation">
      <source>Delete Conversation ? </source>
      <translation variants="no">گفتگو مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_landmarks">
      <source>Save to landmarks</source>
      <translation variants="no">نمایاں علامات میں حفظ</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_copy_link">
      <source>Copy link</source>
      <translation variants="no">ربط کی نقل کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_receive_read_report">
      <source>Receive read report </source>
      <translation variants="no">پڑھے گئے کی رپورٹ وصول کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_attach">
      <source>Attach</source>
      <translation variants="no">منسلکہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_ringing_tone">
      <source>Ringing tone </source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_deleted">
      <source>Message deleted </source>
      <translation variants="no">پیغام مٹا دیا گیا</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority_val_high">
      <source>High </source>
      <translation variants="no">زیادہ</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_l1">
      <source>(%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_photo">
      <source>Photo </source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Photo </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_conversation_deleted">
      <source>Conversation Deleted</source>
      <translation variants="no">گفتگو مٹا دی گئی</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_video">
      <source>Video </source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority_val_low">
      <source>Low </source>
      <translation variants="no">کم</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_l1_of_l2">
      <source>Unable to attach %L1 of %L2 items ! Maximum size exceeded  </source>
      <translation variants="no">ur ##Unable to attach %L1 of %L2 items. Maximum size exceeded  </translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_bcc">
      <source>Bcc:</source>
      <translation variants="no">مخفی نقل:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_message_date">
      <source>&lt;message date&gt;</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_receive_delivery_report">
      <source>Receive delivery report</source>
      <translation variants="no">پہنچنے کی رپورٹ وصول کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_subject">
      <source>Subject</source>
      <translation variants="no">موضوع</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_from">
      <source>From:</source>
      <translation variants="no">از:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_calendar_event">
      <source>Calendar event </source>
      <translation variants="no">ur ##Calendar event </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_more">
      <source>More...</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##More...</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_attach_to_new_message">
      <source>Attach to new message</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Attach to new message</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_cc_bcc">
      <source>Cc / Bcc</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_sending_options_for_this_messa">
      <source>Sending Options for this message</source>
      <translation variants="no">اس پیغام کے لیے اختیارات ارسالگی</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_message_time">
      <source>&lt;message time&gt;</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_business_card">
      <source>Business Card </source>
      <translation variants="no">بزنس کارڈ</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_high">
      <source>High </source>
      <translation variants="no">ur ##High </translation>
    </message>
    <message numerus="yes" id="txt_messaging_list_ln_new_messages">
      <source>%Ln New Messages </source>
      <translation>
        <numerusform plurality="a">ur ##%Ln New Messages </numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_deleting_will_remove_some_mul">
      <source>Deleting will remove some multimedia messages displayed in other conversations too. Delete conversation?</source>
      <translation variants="no">ur ##Deleting will remove some multimedia messages displayed in other conversations too. Delete conversation?</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">ur ##Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_business_card">
      <source>Ringing tone</source>
      <translation variants="no">ur ##Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">ur ##Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delate_all_drafts">
      <source>Delate all drafts ?</source>
      <translation variants="no">ur ##Delate all drafts ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_fwd">
      <source>FWD: </source>
      <translation variants="no">ur ##FWD: </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_drafts">
      <source>Drafts</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Drafts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_same_message_exists_in_multip">
      <source>Same message exists in multiple conversations. Delete all ? </source>
      <translation variants="no">ur ##Same message exists in multiple conversations. Delete all ? </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_attached_photo_size_is_l1">
      <source>Attached photo size is %L1 * %L2 pixels  </source>
      <translation variants="no">ur ##Attached photo size is %L1 * %L2 pixels  </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_listview_resend_at_time">
      <source>Resend at &lt;time&gt;</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Resend at &lt;time&gt;</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_forward">
      <source>Forward</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Forward</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_all_drafts">
      <source>Delete all drafts ?</source>
      <translation variants="no">ur ##Delete all drafts ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">ur ##Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_priority">
      <source>Priority</source>
      <translation variants="no">ur ##Priority</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_message_centre_does_not_e">
      <source>SMS Message centre does not exist. Create New  ?</source>
      <translation variants="no">ur ##SMS Message centre does not exist. Create New  ?</translation>
    </message>
    <message numerus="no" id="txt_conversations_list_message_cannot_be_shown_exa">
      <source>Message cannot be shown exactly as the sender intended. Open to see included objects</source>
      <translation variants="no">ur ##Message cannot be shown exactly as the sender intended. Open to see included objects</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_unable_to_delete_conversation">
      <source>Unable to delete conversation as it contains messages being sent. Try again later.  </source>
      <translation variants="no">ur ##Unable to delete conversation as it contains messages being sent. Try again later.  </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_advertisement">
      <source>Advertisement</source>
      <translation variants="no">ur ##Advertisement</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_class">
      <source>Class: </source>
      <translation variants="no">ur ##Class: </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_personal">
      <source>Personal</source>
      <translation variants="no">ur ##Personal</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_message_centre">
      <source>Delete message centre?</source>
      <translation variants="no">ur ##Delete message centre?</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_loading">
      <source>Loading...</source>
      <translation variants="no">ur ##Loading...</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_re">
      <source>RE: </source>
      <translation variants="no">ur ##RE: </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_slide_l1l2">
      <source>Slide %L1/%L2</source>
      <translation variants="no">ur ##Slide %L1/%L2</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_unknown_bluetooth_device">
      <source>Unknown Bluetooth Device </source>
      <translation variants="no">ur ##Unknown Bluetooth Device </translation>
    </message>
    <message numerus="no" id="txt_conversations_list_1_2">
      <source>%1 %2</source>
      <translation variants="no">ur ##%1 %2</translation>
    </message>
    <message numerus="yes" id="txt_messaging_title_ln_other_recipients">
      <source>%Ln Other recipients</source>
      <translation>
        <numerusform plurality="a">ur ##%Ln Other recipients</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_manual">
      <source>Manual</source>
      <translation variants="no">ur ##Manual</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_contact_info">
      <source>Contact info </source>
      <translation variants="no">ur ##Contact info </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_message_cannot_be_shown_ex">
      <source>Message cannot be shown exactly as the sender intended. Included objects shown as attachments:</source>
      <translation variants="no">ur ##Message cannot be shown exactly as the sender intended. Included objects shown as attachments:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_expiry_date">
      <source>Expiry date: </source>
      <translation variants="no">ur ##Expiry date: </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_resend_at_time">
      <source>Resend at &lt;time&gt;</source>
      <translation variants="no">ur ##Resend at &lt;time&gt;</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_messaging_settings">
      <source>Messaging settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Messaging settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receiving_service_messages">
      <source>Receiving service messages</source>
      <translation variants="no">ur ##Receiving service messages</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">ur ##Messaging</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_conversations">
      <source>Conversations</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Conversations</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_conversations">
      <source>Conversations</source>
      <translation variants="no">ur ##Conversations</translation>
    </message>
    <message numerus="no" id="txt_conversations_dialog_save_ringing_tone">
      <source>Save ringing tone ?</source>
      <translation variants="no">ur ##Save ringing tone ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_delete_all">
      <source>Delete all </source>
      <translation variants="no">ur ##Delete all </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_received_files">
      <source>Received files</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Received files</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_pending">
      <source>(Pending)</source>
      <translation variants="no">(زیر التوا)</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sending_options">
      <source>Sending options </source>
      <translation variants="no">بھیجنے کے اختیارات</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_others">
      <source>Not specified</source>
      <translation variants="no">ur #Other</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receive_service_messages">
      <source>Not specified</source>
      <translation variants="no">ur #Receive service messages</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_enter_message_here">
      <source>Enter message here </source>
      <translation variants="no">متن کا اندراج کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_message_centre_number">
      <source>Message centre number </source>
      <translation variants="no">پیغام کے مرکز کا نمبر</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_contacts_sub_add_to_exi">
      <source>Add to Existing </source>
      <translation variants="no">موجودہ کی تجدید کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_from">
      <source>Not specified</source>
      <translation variants="no">ur #From:</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_download">
      <source>Download</source>
      <translation variants="no">ڈاؤن لوڈ کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_sound">
      <source>Sound</source>
      <translation variants="no">صوتی کلیپ</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_advanced">
      <source>Advanced</source>
      <translation variants="no">بہتر ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_edit_sms_message_centre">
      <source>Edit SMS message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">ترمیم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_sms_email_settings">
      <source>Not specified</source>
      <translation variants="no">ur #SMS mail settings</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_free">
      <source>Free</source>
      <translation variants="no">خالی</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_mannual">
      <source>Mannual</source>
      <translation variants="no">دستی</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_always_automatic">
      <source>Always automatic </source>
      <translation variants="no">ہر وقت چالو</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_open_contact_info">
      <source>Open contact info </source>
      <translation variants="no">روابط کی تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority_sub_normal">
      <source>Not specified</source>
      <translation variants="no">ur #Normal</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_subject">
      <source>Subject:</source>
      <translation variants="no">موضوع:</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_creation_mode">
      <source>MMS creation mode </source>
      <translation variants="no">MMS تشکیل وضع</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority_sub_high">
      <source>Not specified</source>
      <translation variants="no">ur #High</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_ln">
      <source>(%Ln )</source>
      <translation variants="no">ur #(%Ln)</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_settings">
      <source>Settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_advanced_settings_messaging">
      <source>Advanced settings : Messaging </source>
      <translation variants="no">بہتر ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_sms_message_centre_settings">
      <source>SMS message centre settings </source>
      <translation variants="yes">
        <lengthvariant priority="1">SMS پیغام کے مرکز کی ترتیبات</lengthvariant>
        <lengthvariant priority="2">SMS پیغام مرکز ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_val_yes">
      <source>Yes</source>
      <translation variants="no">اجازت ہے</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_type_changed_to_tex">
      <source>Message type changed to text message</source>
      <translation variants="no">پیغام قسم متن میں تبدیل</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_type_changed_to_mul">
      <source>Message type changed to multimedia </source>
      <translation variants="no">پیغام قسم ملٹیمیڈیا میں تبدیل</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_message">
      <source>Allow anonymous MMS messages </source>
      <translation variants="no">نامعلوم ملٹیمیڈ. پیغامات</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_remove_attachment">
      <source>Remove attachment</source>
      <translation variants="no">ur #Remove attachment</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_cc">
      <source>Cc:</source>
      <translation variants="no">نقل اول:</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_full_support">
      <source>Full support </source>
      <translation variants="no">مکمل تائید</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">روابط میں حفظ</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_messaging">
      <source>Messaging</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیغام رسانی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_bcc">
      <source>Bcc: </source>
      <translation variants="no">مخفی نقل:</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_access_point_in_use">
      <source>MMS access point in use </source>
      <translation variants="no">ملٹی میڈیا نقطہ رسائی</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_delete_conversation">
      <source>Delete Conversation</source>
      <translation variants="no">گفتگو مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_email_gateway">
      <source>Not specified</source>
      <translation variants="no">ur #Mail gateway</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_character_encoding">
      <source>Character encoding </source>
      <translation variants="no">حروف رمز نگاری</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receive_mms_adverts">
      <source>Receive MMS adverts </source>
      <translation variants="no">اشتہارات کی وصولیابی</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">بند</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_auto_home_network">
      <source>Automatic in home network </source>
      <translation variants="no">ہوم نیٹ ورک میں خودکار</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_mms_settings">
      <source>MMS settings </source>
      <translation variants="yes">
        <lengthvariant priority="1">MMS ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_delete_message_centre">
      <source>Delete message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">مٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_select_attachment_type">
      <source>Select attachment type</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Select attachment type:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority">
      <source>Not specified</source>
      <translation variants="no">ur #Message priority</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_photo">
      <source>Photo</source>
      <translation variants="no">شبیہ</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_sms_message_centre_in_use">
      <source>SMS message centre in use </source>
      <translation variants="no">SMS پیغام کا مرکز</translation>
    </message>
    <message numerus="no" id="txt_common_opt_ln_new_messages">
      <source>%Ln New Messages </source>
      <translation variants="no">ur #%Ln new message</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_add_to_bookmarks">
      <source>Add to bookmarks</source>
      <translation variants="no">نشان کتاب میں حفظ</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority_sub_low">
      <source>Not specified</source>
      <translation variants="no">ur #Low</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_others">
      <source>Not specified</source>
      <translation variants="no">ur #Other</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_play_message">
      <source>Not specified</source>
      <translation variants="no">ur #Play</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_location">
      <source>Not specified</source>
      <translation variants="no">ur #Location</translation>
    </message>
    <message numerus="no" id="txt_short_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">ur ##Messaging</translation>
    </message>
    <message numerus="no" id="txt_long_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">پیغام رسانی</translation>
    </message>
    <message numerus="no" id="txt_task_switcher_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_sending_failed">
      <source>Sending Failed</source>
      <translation variants="no">ur ##Sending Failed</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_informational">
      <source>Informational</source>
      <translation variants="no">ur ##Informational</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_send_selected_item">
      <source>Send selected item </source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Send selected item</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_create_mail">
      <source>Create mail </source>
      <translation variants="no">میل تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_character_count_excee">
      <source>SMS character count exceeded. Convert to multimedia message ? </source>
      <translation variants="no">بہت زیادہ حروف۔ MMS میں بدلیں؟</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_recipients">
      <source>Recipients</source>
      <translation variants="no">وصول کنندہ</translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_to">
      <source>To:  </source>
      <translation variants="no">تا:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_received_files">
      <source>Received files </source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Received files </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_reduced_support">
      <source>Reduced support </source>
      <translation variants="no">کمتر تائید</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_mms_access_point_not_defined">
      <source>MMS Access point not defined. Define now  ?</source>
      <translation variants="no">ur ##MMS Access point not defined. Define now  ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_drafts">
      <source>Drafts</source>
      <translation variants="no">ur ##Drafts</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_note_as_attachment">
      <source>Not specified</source>
      <translation variants="no">ur #Note (as attachment)</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_email_service_centre_numbe">
      <source>Not specified</source>
      <translation variants="no">ur #Mail message centre number</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach">
      <source>Attach</source>
      <translation variants="no">منسلکہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_business_card">
      <source>Business card</source>
      <translation variants="no">ur ##Business card</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_delivery_failed">
      <source>(Delivery Failed !)</source>
      <translation variants="no">(ارسالگی ناکام)</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_message">
      <source>Delete message ? </source>
      <translation variants="no">پیغام مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_item_avai">
      <source>Unable to attach item! Available space is %L1kb</source>
      <translation variants="no">ur ##Unable to attach item. Available space is %L1kb</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_invalid_recipient_found">
      <source>Invalid recipient found: </source>
      <translation variants="no">ur ##Invalid recipient found: </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority">
      <source>Priority</source>
      <translation variants="no">ترجیح</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">ur ##Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_number_of_recipients_exceeded">
      <source>Number of recipients exceeded.Convert to multimedia message ? </source>
      <translation variants="no">تع. وصول. حد سے تجاوز۔ MMS میں بدلیں؟</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_val_no">
      <source>No</source>
      <translation variants="no">اجازت نہیں ہے</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_delivered_date_time">
      <source>(Delivered &lt;date&gt; &lt;time&gt;) </source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_wireframe_list_multimedia_message_waiting">
      <source>Multimedia message waiting...</source>
      <translation variants="no">ur ##Multimedia message waiting…</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_character_count_exceeded">
      <source>SMS character count exceeded. Convert to multimedia message?</source>
      <translation variants="no">حروف تعداد حد سے تجاوز۔ MMS میں بدلیں؟</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_merge_contacts">
      <source>Merge Contacts </source>
      <translation variants="no">رابطوں کو مخلوط کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_to">
      <source>To: </source>
      <translation variants="no">تا:</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_subject">
      <source>Not specified</source>
      <translation variants="no">ur #Add Subject field</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_recipients">
      <source>Add recipients</source>
      <translation variants="no">ur ##Add recipients</translation>
    </message>
    <message numerus="no" id="txt_conversations_list_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">ur ##Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_message_sending_failed">
      <source>Message Sending failed !</source>
      <translation variants="no">ur ##Message Sending failed !</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_add_more_content">
      <source>Unable to add more content. Maximum size exceeded</source>
      <translation variants="no">ur ##Unable to add more content. Maximum size exceeded</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_listview_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Unsupported message type</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_add_more_recipien">
      <source>Unable to add more recipients. Maximum limit exceeded</source>
      <translation variants="no">ur ##Unable to add more recipients. Maximum limit exceeded</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_message_centre_name">
      <source>Message centre name </source>
      <translation variants="no">پیغام کے مرکز کا نام</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_add_new">
      <source>Add New </source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا پیغام ارسالگی مرکز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_centre_saved">
      <source>Message centre saved</source>
      <translation variants="no">ur ##Message centre saved</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_contacts_sub_create_new">
      <source>Create New </source>
      <translation variants="no">نئے کی تشکیل کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_guided">
      <source>Guided</source>
      <translation variants="no">رہنمائی یافتہ</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_delivery_reports">
      <source>Delivery reports</source>
      <translation variants="no">میل رسانی کی رپورٹیں</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_restricted">
      <source>Restricted </source>
      <translation variants="no">محدود</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_business_card">
      <source>Business card </source>
      <translation variants="no">ur #Business card</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_normal">
      <source>Normal </source>
      <translation variants="no">ur ##Normal </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_other_recipients">
      <source>Other recipients</source>
      <translation variants="no">ur ##Other recipients</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_resend_at_time">
      <source>Resend at &lt;time&gt;</source>
      <translation variants="no">ur ##Resend at &lt;time&gt;</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_saved_to_drafts">
      <source>Saved to drafts</source>
      <translation variants="no">ur ##Saved to drafts</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_size">
      <source>Size:  </source>
      <translation variants="no">ur ##Size:  </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_clear_conversation">
      <source>Not specified</source>
      <translation variants="no">ur #Remove messages</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_retrieval">
      <source>MMS retrieval </source>
      <translation variants="no">MMS بازیافتگی</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_update">
      <source>Update </source>
      <translation variants="no">ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_new_sms_message_centre">
      <source>New  SMS message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا SMS پیغام کا مرکز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_full_screen">
      <source>Full screen </source>
      <translation variants="no">مکمل اسکرین</translation>
    </message>
    <message numerus="yes" id="txt_messaging_group_title_ln_other_recipients">
      <source>%Ln Other recipients</source>
      <translation>
        <numerusform plurality="a">ur #%Ln other recipient</numerusform>
        <numerusform plurality="b">ur #%Ln other recipients</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_on">
      <source>On</source>
      <translation variants="no">چالو </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">ur ##Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_video">
      <source>Video</source>
      <translation variants="no">ویڈیو کلپ</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_cc_bcc">
      <source>Not specified</source>
      <translation variants="no">ur #Add Cc and Bcc fields</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_date_time">
      <source>&lt;date&gt; &lt;time&gt;</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_low">
      <source>Low </source>
      <translation variants="no">ur ##Low </translation>
    </message>
  </context>
</TS>