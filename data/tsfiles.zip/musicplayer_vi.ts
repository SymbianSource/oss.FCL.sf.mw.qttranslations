<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mus_other_unknown5">
      <source>Unknown</source>
      <translation variants="no">vi #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown6">
      <source>Unknown</source>
      <translation variants="no">vi #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown7">
      <source>Unknown </source>
      <translation variants="no">vi #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown1">
      <source>Unknown</source>
      <translation variants="no">vi #Unknown</translation>
    </message>
    <message numerus="yes" id="txt_mus_info_ln_songs_added">
      <source>%Ln songs added</source>
      <translation>
        <numerusform plurality="a">Đã thêm %Ln bài hát</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_remove_songs">
      <source>Remove songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa bài hát:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_send_via_bluetooth">
      <source>Send via Bluetooth</source>
      <translation variants="no">Gửi qua Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_complete">
      <source>Refresh complete</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã làm mới xong</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_no_music">
      <source>(No music)</source>
      <translation variants="no">vi #(no music)</translation>
    </message>
    <message numerus="no" id="txt_mus_other_more_recommendations">
      <source>More recommendations</source>
      <translation variants="no">vi #More recommendations</translation>
    </message>
    <message numerus="yes" id="txt_mus_dpopinfo_ln_songs_added">
      <source>%Ln songs added</source>
      <translation>
        <numerusform plurality="a">Đã thêm %Ln bài hát</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_refreshing">
      <source>Refreshing...</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đang làm mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_share">
      <source>Share</source>
      <translation variants="no">vi #Share</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_stopped">
      <source>Refresh stopped</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã ngừng làm mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_to_get_music_visit_ovi_music">
      <source>To get music, visit Ovi Music.</source>
      <translation variants="no">vi #To get music, visit Music store.</translation>
    </message>
    <message numerus="no" id="txt_mus_button_shuffle">
      <source>Shuffle</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngẫu nhiên</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_audio_effects">
      <source>Audio effects</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hiệu ứng âm thanh</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_subhead_ln_songs">
      <source>%Ln songs</source>
      <translation>
        <numerusform plurality="a">%Ln bài hát</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_mus_title_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã thêm gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">vi #Unmark all</translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_left">
      <source>Left</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trái</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Phát nhiều nhất</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown_all">
      <source>Unknown - All</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết - Tất cả</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_menu_view_details">
      <source>View details</source>
      <translation variants="no">Xem chi tiết</translation>
    </message>
    <message numerus="no" id="txt_mus_list_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">Jazz</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã thêm gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_audio_effects">
      <source>Audio effects</source>
      <translation variants="no">HIệu ứng âm thanh</translation>
    </message>
    <message numerus="no" id="txt_mus_caption_music">
      <source>Music</source>
      <translation variants="no">vi #Music</translation>
    </message>
    <message numerus="no" id="txt_mus_title_music">
      <source>Music</source>
      <translation variants="no">Âm nhạc</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_mark_all">
      <source>Mark all</source>
      <translation variants="no">vi #Mark all</translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_left_l1">
      <source>Left %L1%</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Left %L1%</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown4">
      <source>Unknown</source>
      <translation variants="no">vi #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_song_details">
      <source>Song details </source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết bài hát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_equalizer">
      <source>Equalizer</source>
      <translation variants="no">HIệu ứng âm thanh</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_all_songs">
      <source>All songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tất cả bài hát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">Thêm vào d.sách bài hát</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_playlist">
      <source>Select playlist:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn danh sách bài hát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Phát nhiều nhất</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown2">
      <source>Unknown</source>
      <translation variants="no">vi #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_new_playlist">
      <source>New playlist</source>
      <translation variants="no">Danh sách bài hát mới</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name_entry_playlist_l1">
      <source>Playlist %L1</source>
      <translation variants="no">vi #Playlist %L1</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Rock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_centre">
      <source>Centre</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giữa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_on">
      <source>Repeat on</source>
      <translation variants="no">Bật lặp lại</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_shuffle">
      <source>Shuffle</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngẫu nhiên</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_music">
      <source>Music</source>
      <translation variants="no">vi #Music</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_mus_list_bass_booster">
      <source>Bass booster</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bộ tăng âm bass</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_shuffle">
      <source>Shuffle</source>
      <translation variants="no">vi #Shuffle</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown">
      <source>Unknown</source>
      <translation variants="no">vi #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_right_l1">
      <source>Right %L1%</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Right %L1%</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_1_all">
      <source>%1 - All</source>
      <translation variants="no">%1 - Tất cả</translation>
    </message>
    <message numerus="no" id="txt_mus_list_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">Pop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_playlist">
      <source>Delete playlist?</source>
      <translation variants="no">Xóa danh sách bài hát?</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name">
      <source>Enter name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_album">
      <source>Delete album?</source>
      <translation variants="no">Xóa album?</translation>
    </message>
    <message numerus="no" id="txt_mus_list_ovi_music">
      <source>Ovi Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cửa hàng nhạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_button_new">
      <source>New</source>
      <translation variants="no">Mới</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_balance">
      <source>Balance</source>
      <translation variants="no">Cân bằng</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_preset">
      <source>Select preset:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn cài sẵn:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_stereo_widening">
      <source>Stereo widening</source>
      <translation variants="no">Tăng âm thanh nổi</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_select_a_song">
      <source>Select a song:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn bài hát:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_right">
      <source>Right</source>
      <translation variants="yes">
        <lengthvariant priority="1">Phải</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_refresh_library">
      <source>Refresh library</source>
      <translation variants="no">Làm mới thư viện</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness">
      <source>Loudness</source>
      <translation variants="no">To</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown3">
      <source>Unknown</source>
      <translation variants="no">vi #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_song">
      <source>Delete song?</source>
      <translation variants="no">Xóa bài hát?</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown3">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cổ điển</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_inspire_me">
      <source>Inspire me</source>
      <translation variants="yes">
        <lengthvariant priority="1">Truyền cảm hứng cho tôi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_music">
      <source>Music</source>
      <translation variants="no">Âm nhạc</translation>
    </message>
    <message numerus="no" id="txt_mus_menu_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">Thêm vào d.sách bài hát</translation>
    </message>
    <message numerus="no" id="txt_mus_list_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_off">
      <source>Repeat off</source>
      <translation variants="no">Tắt lặp lại</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_songs">
      <source>Select songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn bài hát:</lengthvariant>
      </translation>
    </message>
  </context>
</TS>