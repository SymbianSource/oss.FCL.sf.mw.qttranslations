<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mus_title_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm nhạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown_all">
      <source>Unknown - All</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết - Tất cả</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã thêm gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_audio_effects">
      <source>Audio effects</source>
      <translation variants="no">HIệu ứng âm thanh</translation>
    </message>
    <message numerus="no" id="txt_mus_list_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">Jazz</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_audio_effects">
      <source>Audio effects</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hiệu ứng âm thanh</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_song_details">
      <source>Song details </source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết bài hát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_bass_booster">
      <source>Bass booster</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bộ tăng âm bass</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_playlist">
      <source>Select playlist</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn danh sách bài hát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness">
      <source>Loudness</source>
      <translation variants="no">To</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_played">
      <source>Recently played (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown6">
      <source>Unknown</source>
      <translation variants="no">Không biết</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_on">
      <source>Repeat on</source>
      <translation variants="no">Bật lặp lại</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown5">
      <source>Unknown</source>
      <translation variants="no">Không biết</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">Thêm vào d.sách bài hát</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name_entry_playlist_l1">
      <source>New playlist name</source>
      <translation variants="no">Danh sách bài hát %L1</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_new_playlist">
      <source>New playlist</source>
      <translation variants="no">Danh sách bài hát mới</translation>
    </message>
    <message numerus="no" id="txt_mus_list_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Rock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown7">
      <source>Unknown </source>
      <translation variants="no">Không biết</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown1">
      <source>Unknown</source>
      <translation variants="no">Không biết</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_equalizer">
      <source>Equalizer</source>
      <translation variants="no">HIệu ứng âm thanh</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_all_songs">
      <source>All songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tất cả bài hát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown4">
      <source>Unknown</source>
      <translation variants="no">Không biết</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_refresh_library">
      <source>Refresh library</source>
      <translation variants="no">Làm mới thư viện</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown2">
      <source>Unknown</source>
      <translation variants="no">Không biết</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_most_played">
      <source>Most played (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Phát nhiều nhất</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_share">
      <source>Share</source>
      <translation variants="no">Chia sẻ</translation>
    </message>
    <message numerus="no" id="txt_mus_menu_view_details">
      <source>View details</source>
      <translation variants="no">Xem chi tiết</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bật</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_complete">
      <source>Refresh complete</source>
      <translation variants="no">Đã làm mới xong</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_added">
      <source>Recently added (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã thêm gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Phát nhiều nhất</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_1_all">
      <source>%1 - All</source>
      <translation variants="no">%[23]1 - Tất cả</translation>
    </message>
    <message numerus="no" id="txt_mus_list_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">Pop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_music">
      <source>Music</source>
      <translation variants="no">Âm nhạc</translation>
    </message>
    <message numerus="no" id="txt_mus_list_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cổ điển</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_inspire_me">
      <source>Inspire me</source>
      <translation variants="yes">
        <lengthvariant priority="1">Truyền cảm hứng cho tôi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_menu_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">Thêm vào d.sách bài hát</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_off">
      <source>Repeat off</source>
      <translation variants="no">Tắt lặp lại</translation>
    </message>
    <message numerus="no" id="txt_mus_list_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_songs">
      <source>Select songs</source>
      <translation variants="no">Chọn bài hát:</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_no_music">
      <source>(No music)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(không có nhạc)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown3">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown3">
      <source>Unknown</source>
      <translation variants="no">Không biết</translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown">
      <source>Unknown</source>
      <translation variants="no">Không biết</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_playlist">
      <source>Delete playlist?</source>
      <translation variants="no">Xóa danh sách bài hát?</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_album">
      <source>Delete album?</source>
      <translation variants="no">Xóa album?</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_balance">
      <source>Balance</source>
      <translation variants="no">Cân bằng</translation>
    </message>
    <message numerus="no" id="txt_mus_button_new">
      <source>New</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_song">
      <source>Delete song?</source>
      <translation variants="no">Xóa bài hát?</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name">
      <source>Enter name</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_select_song">
      <source>Select song</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn bài hát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_size">
      <source>Size</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích cỡ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_new_playlist_created">
      <source>New playlist created</source>
      <translation variants="no">Đã tạo danh sách bài hát mới</translation>
    </message>
    <message numerus="no" id="txt_mus_title_add_songs">
      <source>Add songs</source>
      <translation variants="no">vi #Add songs</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_songs_added_to_1">
      <source>Songs added to %1</source>
      <translation variants="no">Đã thêm bài hát vào %1</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown9">
      <source>Unknown</source>
      <translation variants="no">Không biết</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm nhạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_song_is_protected">
      <source>Song is protected. Unable to play over Bluetooth headset.</source>
      <translation variants="no">vi #Unable to play over Bluetooth headset. Protected song.</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_b">
      <source>%Ln B</source>
      <translation>
        <numerusform plurality="a">%Ln B</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_note_that_using_nokia_ovi_suite_mode">
      <source>Note that using Nokia Ovi Suite mode to transfer your music will optimize your music experience. To learn more, go to %1. Remind me later?</source>
      <translation variants="no">Lưu ý rằng việc sử dụng chế độ truyền media để truyền nhạc sẽ tối ưu hóa trải nghiệm âm nhạc của bạn. Để tìm hiểu thêm, hãy chuyển đến %[99]1. Nhắc tôi sau?</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_cancelled">
      <source>Refresh cancelled</source>
      <translation variants="no">Đã hủy làm mới</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_kb">
      <source>%Ln kB</source>
      <translation>
        <numerusform plurality="a">%Ln kB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_arrange">
      <source>Arrange</source>
      <translation variants="no">Sắp xếp</translation>
    </message>
    <message numerus="no" id="txt_mus_info_an_error_occurred">
      <source>An error occurred. Sharing is not currently available.</source>
      <translation variants="no">Đã xảy ra lỗi. Chia sẻ hiện không có sẵn.</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_mb">
      <source>%Ln MB</source>
      <translation>
        <numerusform plurality="a">%Ln MB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subhead_playlists_1l">
      <source>Playlists (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Danh sách bài hát (%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_file_name">
      <source>File name</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên tập tin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown8">
      <source>Unknown</source>
      <translation variants="no">Không biết</translation>
    </message>
    <message numerus="no" id="txt_short_caption_music">
      <source>Music</source>
      <translation variants="no">vi #Music</translation>
    </message>
    <message numerus="no" id="txt_mus_info_licence_expired">
      <source>Licence expired. Unable to play selection.</source>
      <translation variants="no">vi #Unable to play selection. Licence expired.</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_music_player">
      <source>Music player</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trình phát nhạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_song_number">
      <source>Song number</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số bài hát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_licences">
      <source>Licences</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giấy phép</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_usb_conn_in_progress">
      <source>USB connection in progress</source>
      <translation variants="no">Đang kết nối USB</translation>
    </message>
    <message numerus="no" id="txt_mus_info_unable_to_create_playlist">
      <source>Unable to create playlist. Name is already in use.</source>
      <translation variants="no">Không thể tạo danh sách bài hát. Tên đã được sử dụng.</translation>
    </message>
    <message numerus="no" id="txt_mus_button_create_new">
      <source>Create new</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tạo mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subhead_albums_1l">
      <source>Albums (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Album (%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_web_site">
      <source>Web site</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ web</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_bitrate_val_ln_kbps">
      <source>%Ln Kbps</source>
      <translation>
        <numerusform plurality="a">%Ln kbps</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_unable_to_delete_file">
      <source>Unable to delete file. File is currently in use.</source>
      <translation variants="no">Không thể xóa tập tin. Tập tin đang được sử dụng.</translation>
    </message>
    <message numerus="no" id="txt_mus_info_unable_to_play_selection">
      <source>Unable to play selection. Operation cancelled.</source>
      <translation variants="no">Không thể phát lựa chọn. Đã hủy thao tác.</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_there_are_no_recommendations">
      <source>There are no recommendations for this track</source>
      <translation variants="no">Không có giới thiệu cho bài hát này</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_sampling_rate_val_ln_hz">
      <source>%Ln hz</source>
      <translation>
        <numerusform plurality="a">%Ln Hz</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subhead_songs_l1">
      <source>All songs (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tất cả bài hát (%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_shuffle">
      <source>Shuffle</source>
      <translation variants="no">Ngẫu nhiên</translation>
    </message>
    <message numerus="no" id="txt_mus_subhead_1_2l">
      <source>%1 (%L2)</source>
      <translation variants="no">%[25]1 (%L2)</translation>
    </message>
    <message numerus="no" id="txt_mus_button_rename">
      <source>Rename</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Rename</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre">
      <source>Genre</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thể loại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_file_is_corrupt">
      <source>File is corrupt. Operation cancelled.</source>
      <translation variants="no">Tập tin bị lỗi. Đã hủy thao tác.</translation>
    </message>
    <message numerus="no" id="txt_mus_info_licence_missing">
      <source>Licence missing. Unable to play selection.</source>
      <translation variants="no">vi #Unable to play selection. Licence missing.</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_year">
      <source>Year</source>
      <translation variants="yes">
        <lengthvariant priority="1">Năm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_duration">
      <source>Duration</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời lượng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_licences_val_click_for_details">
      <source>Click for details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhấp vào để biết chi tiết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_bitrate">
      <source>Bitrate</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tốc độ bit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_format">
      <source>Format</source>
      <translation variants="yes">
        <lengthvariant priority="1">Định dạng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_modified">
      <source>Modified</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã sửa đổi</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_gb">
      <source>%Ln GB</source>
      <translation>
        <numerusform plurality="a">%Ln GB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown_1">
      <source>Unknown - %1</source>
      <translation variants="no">Không biết: %1</translation>
    </message>
    <message numerus="no" id="txt_mus_info_out_of_disk_space">
      <source>Refresh cancelled. Out of disk space.</source>
      <translation variants="no">Đã hủy làm mới. Không đủ bộ nhớ.</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_quick_access_to_your_music">
      <source>Quick access to music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Truy cập nhanh vào nhạc của bạn</lengthvariant>
        <lengthvariant priority="2">Tr.c.nhanh vào nhạc của bạn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_removing_songs">
      <source>Removing songs</source>
      <translation variants="no">Đang xóa bài hát</translation>
    </message>
    <message numerus="no" id="txt_mus_info_adding_songs">
      <source>Adding songs</source>
      <translation variants="no">Đang thêm bài hát</translation>
    </message>
    <message numerus="yes" id="txt_mus_info_ln_songs_found">
      <source>%Ln songs found</source>
      <translation>
        <numerusform plurality="a">Đã tìm thấy %Ln bài hát</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_send_via_bluetooth">
      <source>Send via Bluetooth</source>
      <translation variants="no">Gửi qua Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_mus_title_remove_songs">
      <source>Remove songs</source>
      <translation variants="no">Xóa bài hát:</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_preset">
      <source>Select preset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn cài sẵn:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_composer">
      <source>Composer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tác giả</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_sampling_rate">
      <source>Sampling rate</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tỷ lệ lấy mẫu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown4">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_refreshing">
      <source>Refreshing</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đang làm mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subhead_artist_1l">
      <source>Artists (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nghệ sĩ (%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_copyright">
      <source>Copyright</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bản quyền</lengthvariant>
      </translation>
    </message>
  </context>
</TS>