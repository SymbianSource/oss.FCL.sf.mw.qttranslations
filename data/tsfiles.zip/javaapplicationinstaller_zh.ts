<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_inst_dpopinfo_installation_complete">
      <source>Installation complete</source>
      <translation variants="no">安装完成</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_mb">
      <source>%1: Phone Memory (%L2 MB) </source>
      <translation variants="no">%[99]1：手机存储(%L2 MB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_app_suite_name_version">
      <source>%1 (%2)</source>
      <translation variants="no">%[99]1(%[99]2)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_downloading">
      <source>Downloading</source>
      <translation variants="no">正在下载</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_serial_number">
      <source>Serial number: %1</source>
      <translation variants="no">序列号： %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_inst_pkg_not_cert">
      <source>Application %1 is from an unknown source. </source>
      <translation variants="no">应用程序"%[99]1"来自未知源。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_kb">
      <source>%1: Memory card (%L2 kB) </source>
      <translation variants="no">%[99]1：存储卡(%L2 kB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_mb">
      <source>%1: Unknown (%L2 MB)</source>
      <translation variants="no">%[99]1：未知(%L2 MB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_gb">
      <source>%1: Phone Memory (%L2 GB) </source>
      <translation variants="no">%[99]1：手机存储(%L2 GB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_installation_complete">
      <source>Installed</source>
      <translation variants="no">已安装</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_show">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">显示</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_dialog_username">
      <source>Username:</source>
      <translation variants="yes">
        <lengthvariant priority="1">用户名：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_hide">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">隐藏</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_manufacturer">
      <source>Manufacturer</source>
      <translation variants="no">制造商</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_downloading">
      <source>Downloading</source>
      <translation variants="no">zh #Downloading</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_app_name">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_valid_until">
      <source>Valid until: %1</source>
      <translation variants="no">有效期至：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_install">
      <source>Install?</source>
      <translation variants="no">安装？</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_cancel_installing">
      <source>Cancel installing</source>
      <translation variants="no">取消安装</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_perm_query">
      <source>Access to protected functionality needed.</source>
      <translation variants="no">需要访问受保护功能。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_size_mb">
      <source>%L1 MB</source>
      <translation variants="no">%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_organization">
      <source>Organization: %1</source>
      <translation variants="no">组织：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installation_complete">
      <source>Installation complete</source>
      <translation variants="no">zh #Installation complete</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_mb">
      <source>%1: Internal Mass Storage (%L2 MB)</source>
      <translation variants="no">%[99]1：海量存储器(%L2 MB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_gb">
      <source>%1: Memory card (%L2 GB) </source>
      <translation variants="no">%[99]1：存储卡(%L2 GB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">确认</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem">
      <source>%1: Internal Mass Storage</source>
      <translation variants="no">%[99]1：海量存储器</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_ask_me_later">
      <source>Ask me later</source>
      <translation variants="no">稍后询问我</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_app_cert">
      <source>Application is certified.</source>
      <translation variants="no">zh #Application is certified.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_back_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">确认</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_ocsp_check_progress">
      <source>Checking certificate validity</source>
      <translation variants="no">正在检查证书有效性</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_operator_pref">
      <source>Operator preferred</source>
      <translation variants="no">首选运营商</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_kb">
      <source>%1: Phone Memory (%L2 kB) </source>
      <translation variants="no">%[99]1：手机存储(%L2 kB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_ocsp_check_progress">
      <source>Checking certificate validity</source>
      <translation variants="no">zh #Checking validity</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_inst_failed">
      <source>Installation failed</source>
      <translation variants="no">安装失败</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_update_query">
      <source>Update?</source>
      <translation variants="no">更新？</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_auth_query">
      <source>Connect to</source>
      <translation variants="no">zh #Connect to server?</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_issuer">
      <source>Issuer: %1</source>
      <translation variants="no">发行者：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_vendor">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_kb">
      <source>%1: Unknown (%L2 kB)</source>
      <translation variants="no">%[99]1：未知(%L2 kB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_dpopinfo_preparing_installation">
      <source>Preparing installation</source>
      <translation variants="no">正在准备安装</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem">
      <source>%1: Phone memory</source>
      <translation variants="no">%[99]1：手机存储</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_valid_from">
      <source>Valid from: %1</source>
      <translation variants="no">有效期自：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_kb">
      <source>%1: Internal Mass Storage (%L2 kB)</source>
      <translation variants="no">%[99]1：海量存储器(%L2 kB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_view_perm_details">
      <source>Details</source>
      <translation variants="no">详情</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_operator">
      <source>Operator</source>
      <translation variants="no">运营商</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_untrusted_third_party">
      <source>Untrusted 3rd party</source>
      <translation variants="no">不可信第三方</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">关闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_listl_mem_card">
      <source>%1: Memory card</source>
      <translation variants="no">%[99]1：存储卡</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain">
      <source>Domain: %1</source>
      <translation variants="no">域：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_perm_view_details">
      <source>Application asks permissions for:</source>
      <translation variants="no">zh #Application asks permissions for:</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_update_query">
      <source>%1 from %2 to %3?</source>
      <translation variants="no">将%[99]1从%[99]2更新为%[99]3？</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_installing">
      <source>Installing</source>
      <translation variants="no">正在安装</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installing">
      <source>Installing</source>
      <translation variants="no">zh #Installing</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_trusted_third_party">
      <source>Trusted 3rd party</source>
      <translation variants="no">可信第三方</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_auth_yourself">
      <source>To download %1 you need to authenticate yourself</source>
      <translation variants="no">登录以下载"%[99]1"。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown">
      <source>%1: Unknown</source>
      <translation variants="no">%[99]1：未知</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_allow_always">
      <source>Allow always</source>
      <translation variants="no">总是允许</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_push_registration_static">
      <source>Registration for automatic start needed. Note that installation will fail if not allowed.</source>
      <translation variants="no">zh #Application will be registered for auto-start otherwise installation will fail.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_gb">
      <source>%1: Internal Mass Storage (%L2 GB)</source>
      <translation variants="no">%[99]1：海量存储器(%L2 GB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_gb">
      <source>%1: Unknown (%L2 GB)</source>
      <translation variants="no">%[99]1：未知(%L2 GB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_preparing_installation">
      <source>Preparing installation</source>
      <translation variants="no">zh #Preparing</translation>
    </message>
    <message numerus="no" id="txt_java_inst_dialog_password">
      <source>Password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_update_retain_user_data">
      <source>Retain application data</source>
      <translation variants="yes">
        <lengthvariant priority="1">保留应用程序数据</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_size_kb">
      <source>%L1 kB</source>
      <translation variants="no">%L1 kB</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_mb">
      <source>%1: Memory card (%L2 MB) </source>
      <translation variants="no">%[99]1：存储卡(%L2 MB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_app_not_cert">
      <source>Application is not certified.</source>
      <translation variants="no">zh #Application is not certified.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installing_progress">
      <source>%1 (%2 %)</source>
      <translation variants="no">zh #%[08]1 (%[08]2%)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_subject">
      <source>Subject: %1</source>
      <translation variants="no">主题：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_fingerprint">
      <source>Fingerprint (SHA1): %1</source>
      <translation variants="no">指纹(SHA1)：%1</translation>
    </message>
  </context>
</TS>