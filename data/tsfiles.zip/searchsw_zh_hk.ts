<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_search_title_select_search_scope">
      <source>Select search scope</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Select search scope</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_search_for_1">
      <source>Search for "%1" </source>
      <translation variants="no">zh_hk ##Search for "%1" </translation>
    </message>
    <message numerus="no" id="txt_short_caption_search">
      <source>Search</source>
      <translation variants="no">zh_hk ##Search</translation>
    </message>
    <message numerus="no" id="txt_search_list_internet">
      <source>Internet</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Internet</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_messagemail">
      <source>Message &amp; Mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Message &amp; Mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_search_for_1_on_2">
      <source>Search for "%1" on %2</source>
      <translation variants="no">zh_hk ##Search for "%1" on %2</translation>
    </message>
    <message numerus="no" id="txt_search_list_calendarnotes">
      <source>Calendar &amp; Notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Calendar &amp; Notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_search">
      <source>Search</source>
      <translation variants="no">zh_hk ##Search</translation>
    </message>
    <message numerus="no" id="txt_search_list_device">
      <source>Device</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Device</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_contatcs">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Contacts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_applications">
      <source>Applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Applications</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_results_no_match_found">
      <source>No Match Found</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##No Match Found</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_task_switcher_caption_search">
      <source>Search</source>
      <translation variants="no">zh_hk ##Search</translation>
    </message>
    <message numerus="no" id="txt_search_list_all_other_files">
      <source>All other files</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##All other files</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_qtl_dialog_pri_heading_delimiter">
      <source>Delimiter</source>
      <translation variants="no">zh_hk ##Delimiter</translation>
    </message>
    <message numerus="no" id="txt_search_list_no_match_found">
      <source>No Match Found</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##No Match Found</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_title_search">
      <source>Search</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Search</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_media">
      <source>Media</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Media</lengthvariant>
      </translation>
    </message>
  </context>
</TS>