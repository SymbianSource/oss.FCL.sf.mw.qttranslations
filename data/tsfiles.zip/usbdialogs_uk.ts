<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dpinfo_mass_storage">
      <source>as mass storage</source>
      <translation variants="no">Режим накопичувача</translation>
    </message>
    <message numerus="no" id="txt_usb_info_error_in_usb_connection_disconnect_d">
      <source>Error in USB connection. Disconnect device.</source>
      <translation variants="no">Помилка з’єднання USB. Від’єднайте пристрій.</translation>
    </message>
    <message numerus="no" id="txt_usb_info_memory_full_close_some_applications">
      <source>Memory full. Close some applications and try to connect USB cable again.</source>
      <translation variants="no">Пам’ять повна. Закрийте деякі програми та знову приєднайте кабель USB.</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_safe_to_remove">
      <source>Safe to remove</source>
      <translation variants="no">Можна безпечно від’єднати</translation>
    </message>
    <message numerus="no" id="txt_usb_info_partially_supported_usb_device_connec">
      <source>Partially supported USB device connected. All functionality might not work.</source>
      <translation variants="no">Приєднано пристрій USB із частковою підтримкою. Не всі функції можуть працювати.</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unsupported_usb_device_disconnect_de">
      <source>Unsupported USB device. Disconnect device.</source>
      <translation variants="no">Непідтримуваний пристрій USB. Від’єднайте пристрій.</translation>
    </message>
    <message numerus="no" id="txt_usb_dpophead_usb_disconnected">
      <source>USB disconnected</source>
      <translation variants="no">USB від’єднано</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_media_transfer">
      <source>as media transfer</source>
      <translation variants="no">Режим передачі мультимедіа</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_eject_the_usb_device_some">
      <source>Unable to eject the USB device. Some of the applications may still be using it.</source>
      <translation variants="no">Неможливо від’єднати пристрій USB. Можливо, він використовується якимись програмами.</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unknown_file_system_disconnect_devic">
      <source>Unknown file system. Disconnect device.</source>
      <translation variants="no">Невідома файлова система. Від’єднайте пристрій.</translation>
    </message>
    <message numerus="no" id="txt_usb_dpophead_usb_connected">
      <source>USB connected</source>
      <translation variants="no">USB з’єднано</translation>
    </message>
    <message numerus="no" id="txt_usb_info_remove_usb_cable_or_connect_a_device">
      <source>Remove USB cable or connect a device.</source>
      <translation variants="no">Від’єднайте кабель USB або приєднайте пристрій.</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_headset_in_use">
      <source>headset in use</source>
      <translation variants="no">Використовується гарнітура</translation>
    </message>
    <message numerus="no" id="txt_usb_info_hubs_are_not_supported_disconnect_us">
      <source>Hubs are not supported. Disconnect device.</source>
      <translation variants="no">Концентратори не підтримуються. Від’єднайте пристрій.</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_show_a_memory_to_other_devi">
      <source>Unable to show a memory to other device.</source>
      <translation variants="no">Неможливо показати пам’ять іншому пристрою</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_phone_as_modem">
      <source>as web connection</source>
      <translation variants="no">Режим з’єднання комп’ютера з Інтернетом</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_ovi_suite">
      <source>to OVI suite</source>
      <translation variants="no">Nokia Ovi Suite</translation>
    </message>
    <message numerus="no" id="txt_usb_info_disk_full_remove_some_files_and_try">
      <source>Disk full. Remove some files and try connect USB cable again</source>
      <translation variants="no">Диск заповнено. Видаліть деякі файли та знову приєднайте кабель USB.</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_use_file_system_in_device">
      <source>Unable to use file system in device. Disconnect device.</source>
      <translation variants="no">Неможливо використати файлову систему у пристрої. Від’єднайте кабель.</translation>
    </message>
  </context>
</TS>