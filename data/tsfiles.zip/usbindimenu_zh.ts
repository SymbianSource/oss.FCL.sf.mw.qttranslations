<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dblist_usb_disconnecting">
      <source>USB disconnecting</source>
      <translation variants="yes">
        <lengthvariant priority="1">正在断开USB连接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem">
      <source>USB problem</source>
      <translation variants="yes">
        <lengthvariant priority="1">USB连接存在错误</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_media_transfer">
      <source>as media transfer</source>
      <translation variants="yes">
        <lengthvariant priority="1">多媒体传送模式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_phone_as_modem">
      <source>as web connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">将PC连至网络</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_ovi_suite">
      <source>to OVI suite</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nokia Ovi Suite</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_mass_storage">
      <source>as mass storage</source>
      <translation variants="yes">
        <lengthvariant priority="1">大容量存储模式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_click_to_eject">
      <source>Click to eject</source>
      <translation variants="yes">
        <lengthvariant priority="1">拔掉USB设备</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connecting">
      <source>USB connecting</source>
      <translation variants="yes">
        <lengthvariant priority="1">正在创建USB连接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem_val_not_enough_memory">
      <source>Not enough memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">存储不足</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected">
      <source>USB connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">USB已连接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem_val_connection_type_not">
      <source>Connection type not supported</source>
      <translation variants="yes">
        <lengthvariant priority="1">不支持此连接类型</lengthvariant>
      </translation>
    </message>
  </context>
</TS>