<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dblist_usb_connected">
      <source>USB connected</source>
      <translation variants="no">USB已连接</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connecting">
      <source>USB connecting</source>
      <translation variants="no">创建USB连接</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem">
      <source>USB problem</source>
      <translation variants="no">USB连接存在错误</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_phone_as_modem">
      <source>as web connection</source>
      <translation variants="no">连接PC与互联网</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_click_to_eject">
      <source>Click to eject</source>
      <translation variants="no">拔掉USB设备</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem_val_not_enough_memory">
      <source>Not enough memory</source>
      <translation variants="no">存储空间不足</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_disconnecting">
      <source>USB disconnecting</source>
      <translation variants="no">正在断开USB连接</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem_val_connection_type_not">
      <source>Connection type not supported</source>
      <translation variants="no">连接类型不受支持</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_ovi_suite">
      <source>to OVI suite</source>
      <translation variants="no">Nokia Ovi Suite</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_media_transfer">
      <source>as media transfer</source>
      <translation variants="no">多媒体传送模式</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_mass_storage">
      <source>as mass storage</source>
      <translation variants="no">大容量存储模式</translation>
    </message>
  </context>
</TS>