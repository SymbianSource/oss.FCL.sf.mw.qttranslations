<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_applib_opt_sub_custom">
      <source>Custom</source>
      <translation variants="no">自訂順序</translation>
    </message>
    <message numerus="no" id="txt_applib_list_new_collection">
      <source>New collection</source>
      <translation variants="yes">
        <lengthvariant priority="1">新收藏集</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_entry_collectionl1">
      <source>Collection(%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏集%L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_title_select_applications">
      <source>Select applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">選取應用程式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_will_be_removed_from_phone_c">
      <source>%1 will be removed from phone. Continue?</source>
      <translation variants="no">%[52]1將會從裝置移除。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_uninstalls_1_and_deletes_all_sh">
      <source>%1 and all its shortcuts will be removed from phone. Continue?</source>
      <translation variants="no">%[39]1及其所有捷徑都將從裝置移除。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_ascending">
      <source>Ascending</source>
      <translation variants="no">名稱(遞增)</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_latest_on_top">
      <source>Latest on top</source>
      <translation variants="no">最新的在頂端</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sort_by_sub_latest_on_top">
      <source>Latest on top</source>
      <translation variants="no">最新的在頂端</translation>
    </message>
    <message numerus="no" id="txt_applib_button_add_to_homescreen">
      <source>Add to Homescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">加入至首頁畫面</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_title_arrange">
      <source>Arrange</source>
      <translation variants="yes">
        <lengthvariant priority="1">排列</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_installation_time">
      <source>Installation time</source>
      <translation variants="no">安裝時間</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_arrange">
      <source>Arrange</source>
      <translation variants="no">排列</translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_installed">
      <source>Installed</source>
      <translation variants="yes">
        <lengthvariant priority="1">已安裝</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dpopinfo_added_to_collection_1">
      <source>Added to collection %1</source>
      <translation variants="no">已加入至收藏集%[65]1</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_view_installed_applications">
      <source>View installed applications</source>
      <translation variants="no">檢視已安裝的應用程式</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_add_to_home_screen">
      <source>Add to Home Screen</source>
      <translation variants="no">加入至首頁畫面</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_task_switcher">
      <source>Task Switcher</source>
      <translation variants="no">工作切換程式</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_add_to_collection">
      <source>Add to collection</source>
      <translation variants="no">加入至收藏集</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_add_to_home_screen">
      <source>Add to Home Screen</source>
      <translation variants="no">加入至首頁畫面</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_descending">
      <source>Descending</source>
      <translation variants="no">名稱(遞減)</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_delete_1">
      <source>Delete %1?</source>
      <translation variants="no">是否刪除收藏集%[64]1？</translation>
    </message>
    <message numerus="no" id="txt_applib_title_collection_name">
      <source>Collection name:</source>
      <translation variants="no">收藏集名稱</translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_uninstalling_1">
      <source>Uninstalling %1</source>
      <translation variants="no">正在解除安裝%1</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sort_by">
      <source>Sort by</source>
      <translation variants="no">排序依據</translation>
    </message>
    <message numerus="no" id="txt_applib_title_add_to">
      <source>Add to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">加入至收藏集：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_removed">
      <source>Removed</source>
      <translation variants="no">已移除</translation>
    </message>
    <message numerus="no" id="txt_applib_title_installation_logs">
      <source>Installation logs</source>
      <translation variants="yes">
        <lengthvariant priority="1">安裝記錄</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sort_by_sub_oldest_on_top">
      <source>Oldest on top</source>
      <translation variants="no">最舊的在頂端</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_send_to_friend">
      <source>Send to friend</source>
      <translation variants="no">傳送網址</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_remove_1_from_collection">
      <source>Remove %1 from collection?</source>
      <translation variants="no">是否從收藏集中移除%[55]1？</translation>
    </message>
    <message numerus="no" id="txt_applib_dpophead_added_to_homescreen">
      <source>Added to Homescreen</source>
      <translation variants="no">加入至首頁畫面</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_format">
      <source>Format:</source>
      <translation variants="no">格式：</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_installed">
      <source>Installed</source>
      <translation variants="no">已安裝</translation>
    </message>
    <message numerus="no" id="txt_applib_formlabel_no_search_results">
      <source>No search results</source>
      <translation variants="no">(找不到結果)</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="no">%[08]1：大型記憶體</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_size">
      <source>Size:</source>
      <translation variants="no">大小：</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_l1_kb">
      <source>%L1 KB</source>
      <translation variants="no">zh_tw #%L1 KB</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_installation_log">
      <source>Installation log</source>
      <translation variants="no">安裝記錄</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_add_to_collection">
      <source>Add to collection...</source>
      <translation variants="no">加入至收藏集</translation>
    </message>
    <message numerus="no" id="txt_applib_formlabel_empty">
      <source>Empty</source>
      <translation variants="no">(無應用程式)</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="no">%[10]1：記憶卡</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_version">
      <source>Version:</source>
      <translation variants="no">版本：</translation>
    </message>
    <message numerus="no" id="txt_applib_button_add_to_collection">
      <source>Add to Collection</source>
      <translation variants="no">加入至收藏集</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_deletes_1_also_from_home_screen">
      <source>Deletes %1 also from Home Screen. Continue?</source>
      <translation variants="no">%[39]1也將從首頁畫面刪除。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_description">
      <source>Description:</source>
      <translation variants="no">內容說明：</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="no">%[08]1：裝置記憶體</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_check_software_updates">
      <source>Check software updates</source>
      <translation variants="no">檢查軟體更新</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_l1_mb">
      <source>%L1 MB</source>
      <translation variants="no">zh_tw #%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_downloaded_val_empty">
      <source>Empty</source>
      <translation variants="yes">
        <lengthvariant priority="1">(無應用程式)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_entry_collection">
      <source>Collection</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏集</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_sub_oldest_on_top">
      <source>Oldest on top</source>
      <translation variants="no">最舊的在頂端</translation>
    </message>
    <message numerus="no" id="txt_applib_title_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_opt_add_content">
      <source>Add content</source>
      <translation variants="no">加入內容</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_file_corrupted_unable_to_use_wi">
      <source>File corrupted, unable to use widget. Delete widget? </source>
      <translation variants="no">無法使用Widget。是否刪除Widget？</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_2">
      <source>%1 %2</source>
      <translation variants="no">zh_tw ##%1 %2</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_1_must_be_closed_before_deletin">
      <source>%1 must be closed before deleting. Close %1? </source>
      <translation variants="no">刪除前必須先關閉%[26]1。是否關閉%1？ </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_memory_in_use">
      <source>Memory in use:</source>
      <translation variants="no">使用中的記憶體：</translation>
    </message>
    <message numerus="no" id="txt_applib_opt_new_collection">
      <source>New collection</source>
      <translation variants="no">新收藏集</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_resume">
      <source>Resume</source>
      <translation variants="no">恢復下載</translation>
    </message>
    <message numerus="no" id="txt_applib_title_applications">
      <source>Applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">應用程式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_menu_cancel_installing">
      <source>Cancel installing</source>
      <translation variants="no">取消安裝</translation>
    </message>
    <message numerus="no" id="txt_applib_menu_remove_from_collection">
      <source>Remove from collection</source>
      <translation variants="no">從收藏集移除</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_partially_installed">
      <source>Partially installed</source>
      <translation variants="no">已部分安裝</translation>
    </message>
    <message numerus="yes" id="txt_applib_dblist_val_ln_new_applications">
      <source>%Ln new applications</source>
      <translation>
        <numerusform plurality="a">%Ln個新應用程式</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_supplier">
      <source>Supplier:</source>
      <translation variants="no">供應商：</translation>
    </message>
    <message numerus="no" id="txt_applib_dialog_name">
      <source>Name:</source>
      <translation variants="no">名稱：</translation>
    </message>
  </context>
</TS>