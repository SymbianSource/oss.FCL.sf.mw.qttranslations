<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="hu">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_browser_error_dialog_close_some">
      <source>Close some browser windows or applications.</source>
      <translation variants="no">hu #Close some browser windows or applications.</translation>
    </message>
    <message numerus="no" id="txt_long_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">Böngésző</translation>
    </message>
    <message numerus="no" id="txt_browser_tag_error_tag_file_could_not_be_downloaded">
      <source>Error: %1 could not be downloaded</source>
      <translation variants="no">A(z) „%[99]1” elem nem tölthető le.</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_save_forms_passwords">
      <source>Save Forms/Passwords</source>
      <translation variants="no">Űrlapok és jelszavak mentése</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding_unicode">
      <source>Unicode</source>
      <translation variants="no">Unicode</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_about">
      <source>About Browser</source>
      <translation variants="no">Böngésző névjegye</translation>
    </message>
    <message numerus="no" id="txt_browser_offline">
      <source>Offline</source>
      <translation variants="no">Offline</translation>
    </message>
    <message numerus="no" id="txt_browser_input_dial_add_bm">
      <source>Add Bookmark</source>
      <translation variants="no">Könyvjelző hozzáadása</translation>
    </message>
    <message numerus="no" id="txt_browser_history_this_week">
      <source>This Week</source>
      <translation variants="no">Ezen a héten</translation>
    </message>
    <message numerus="no" id="txt_browser_history_delete_are_you_sure">
      <source>Are you sure you want to permanently delete your history?</source>
      <translation variants="no">Végleg törli az előzményeket?</translation>
    </message>
    <message numerus="no" id="txt_browser_error_generic_error_msg">
      <source>Network error</source>
      <translation variants="no">Hálózati hiba</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_page">
      <source>Page</source>
      <translation variants="no">Oldal</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_settings">
      <source>Settings</source>
      <translation variants="no">Beállítások</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">Könyvjelzők</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_browser">
      <source>Browser</source>
      <translation variants="no">Böngésző</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_cancel">
      <source>Cancel</source>
      <translation variants="no">Mégse</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection_no">
      <source>No</source>
      <translation variants="no">Nem</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_navigation">
      <source>Navigation</source>
      <translation variants="no">hu #Navigation</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_all">
      <source>Clear All</source>
      <translation variants="no">hu #Clear all</translation>
    </message>
    <message numerus="no" id="txt_short_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">Böngésző</translation>
    </message>
    <message numerus="no" id="txt_browser_windows_new_window">
      <source>New Window</source>
      <translation variants="no">Új ablak</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding_automatic">
      <source>Automatic</source>
      <translation variants="no">Automatikus</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings">
      <source>General Settings</source>
      <translation variants="no">Általános beállítások</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_cookies">
      <source>Cookies</source>
      <translation variants="no">Cookie-k</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data">
      <source>Clear Data</source>
      <translation variants="no">Adatok törlése</translation>
    </message>
    <message numerus="no" id="txt_browser_input_dial_edit_bm">
      <source>Edit Bookmark</source>
      <translation variants="no">Könyvjelző szerkesztése</translation>
    </message>
    <message numerus="no" id="txt_browser_history_today">
      <source>Today</source>
      <translation variants="no">Ma</translation>
    </message>
    <message numerus="no" id="txt_browser_downloading_file">
      <source>Downloading %1</source>
      <translation variants="no">Letöltés folyamatban %1</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_link_image">
      <source>Link/Image</source>
      <translation variants="no">Képhivatkozások</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_block_popups">
      <source>Block Popups</source>
      <translation variants="no">Előugró ablakok blokkolása</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_windows">
      <source>Windows</source>
      <translation variants="no">Ablakok</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_exit">
      <source>Exit Browser</source>
      <translation variants="no">Kilépés a Böngészőből</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">Könyvjelzők</translation>
    </message>
    <message numerus="no" id="txt_browser_most_visited_title_most_visited">
      <source>Most Visited</source>
      <translation variants="no">Leggyakrabban látogatott</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_share">
      <source>Share</source>
      <translation variants="no">hu #Share</translation>
    </message>
    <message numerus="no" id="txt_browser_error_dialog_device_low">
      <source>Device Low On Memory</source>
      <translation variants="no">hu #Device memory low.</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">Böngésző</translation>
    </message>
    <message numerus="no" id="txt_browser_windows_windows">
      <source>Windows</source>
      <translation variants="no">Ablakok</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_settings">
      <source>Settings</source>
      <translation variants="no">Beállítások</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_save_browser_history">
      <source>Save Browser History</source>
      <translation variants="no">Előzmények mentése</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_form_data">
      <source>Form Data</source>
      <translation variants="no">Űrlapadatok</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">Könyvjelzők</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection">
      <source>%1 is now in range.  Switch connection?</source>
      <translation variants="no">%[99]1 elérhetővé vált. Átvált a kapcsolatra?</translation>
    </message>
    <message numerus="no" id="txt_browser_history_yesterday">
      <source>Yesterday</source>
      <translation variants="no">Tegnap</translation>
    </message>
    <message numerus="no" id="txt_browser_history_this_month">
      <source>This Month</source>
      <translation variants="no">Ebben a hónapban</translation>
    </message>
    <message numerus="no" id="txt_browser_file_has_finished_downloading">
      <source>%1 has finished downloading</source>
      <translation variants="no">Letöltés befejezve: %1</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_image">
      <source>Image</source>
      <translation variants="no">Kép</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_add_bookmark">
      <source>Add Bookmark</source>
      <translation variants="no">Könyvjelző hozzáadása</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_history">
      <source>History</source>
      <translation variants="no">Előzmények</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_link_open_link">
      <source>Open Link in New Window</source>
      <translation variants="no">Hivatkozás megnyitása új ablakban</translation>
    </message>
    <message numerus="no" id="txt_browser_chrome_suggests_search_for">
      <source>Search for %1</source>
      <translation variants="no">%1 keresése</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_link_share_link">
      <source>Share Link</source>
      <translation variants="no">hu #Share link</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_yes">
      <source>Yes</source>
      <translation variants="no">Igen</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_no">
      <source>No</source>
      <translation variants="no">Nem</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_history">
      <source>History</source>
      <translation variants="no">Előzmények</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding">
      <source>Character Encoding</source>
      <translation variants="no">Karakterkódolás</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_cache">
      <source>Cache</source>
      <translation variants="no">Cache</translation>
    </message>
    <message numerus="no" id="txt_browser_history_history">
      <source>History</source>
      <translation variants="no">Előzmények</translation>
    </message>
    <message numerus="no" id="txt_browser_error_page_load_failed">
      <source>Unable to load page</source>
      <translation variants="no">Az oldalt nem sikerült betölteni</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_new_window">
      <source>New Window</source>
      <translation variants="no">Új ablak</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_link">
      <source>Link</source>
      <translation variants="no">Hivatkozás</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_allow_popups">
      <source>Allow Pop-ups</source>
      <translation variants="no">Előugró ablakok engedélyezése</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_image_save_image">
      <source>Save Image</source>
      <translation variants="no">Kép mentése</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_done">
      <source>Done</source>
      <translation variants="no">Kész</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection_yes">
      <source>Yes</source>
      <translation variants="no">Igen</translation>
    </message>
  </context>
</TS>