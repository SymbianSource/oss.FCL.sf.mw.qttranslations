<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_photos_subtitle_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mục ưa thích</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_medium">
      <source>Medium</source>
      <translation variants="no">Trung bình</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_remove_from_album">
      <source>Remove from album</source>
      <translation variants="no">Xóa khỏi album</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_settings">
      <source>Settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect">
      <source>Transistion effect</source>
      <translation variants="no">Hiệu ứng chuyển tiếp</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_share">
      <source>Share</source>
      <translation variants="no">Chia sẻ</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_play">
      <source>Play</source>
      <translation variants="no">Phát</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_share">
      <source>Share</source>
      <translation variants="no">Chia sẻ</translation>
    </message>
    <message numerus="no" id="txt_photos_title_photos">
      <source>Photos</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hình ảnh</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">Hủy dấu tất cả</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_slideshow">
      <source>Slideshow</source>
      <translation variants="no">Trình chiếu</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_slow">
      <source>Slow</source>
      <translation variants="no">Chậm</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_mark_all">
      <source>Mark all</source>
      <translation variants="no">Đánh dấu tất cả</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ảnh đã chụp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_fast">
      <source>Fast</source>
      <translation variants="no">Nhanh</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ảnh đã chụp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mục ưa thích</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_wave">
      <source>Wave</source>
      <translation variants="no">Gợn sóng</translation>
    </message>
    <message numerus="no" id="txt_long_caption_photos">
      <source>photos</source>
      <translation variants="no">Hình ảnh</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_smooth">
      <source>Smooth Fade</source>
      <translation variants="no">Fading phẳng</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_slideshow">
      <source>Slideshow</source>
      <translation variants="no">Bản chiếu</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_add_to_album">
      <source>Add to album</source>
      <translation variants="no">Thêm vào album</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay">
      <source>Transistion delay</source>
      <translation variants="no">T.độ ch.tiếp</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_add_to_album">
      <source>Add to album</source>
      <translation variants="no">Thêm vào album</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album">
      <source>Album</source>
      <translation variants="no">Album</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_use_image">
      <source>Use image</source>
      <translation variants="no">Sử dụng ảnh</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_description">
      <source>Description</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mô tả:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_info_delete_l1_the_files_will_not_be">
      <source>Delete %1? (The files will not be deleted.)</source>
      <translation variants="no">Xóa %[09]1? Các mục đã lưu sẽ không bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_photos_title_enter_name">
      <source>Enter name :</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên album:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_info_remove_l1_from_album_the_file_w">
      <source>Remove %1 from album? (The file will not be deleted.)</source>
      <translation variants="no">Xóa %[28]1 khỏi album?</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_new_album">
      <source>New album</source>
      <translation variants="no">Album mới</translation>
    </message>
    <message numerus="no" id="txt_photos_info_unable_to_open_image">
      <source>Unable to open image</source>
      <translation variants="no">Không thể mở ảnh</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_photos">
      <source>Photos</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hình</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_title_image_viewer">
      <source>Image viewer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trình xem hình ảnh</lengthvariant>
        <lengthvariant priority="2">Trình xem h.ả</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_zoom_an">
      <source>Zoom and Pan</source>
      <translation variants="no">Zoom và pan</translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_kb">
      <source>Size: %Ln kB</source>
      <translation>
        <numerusform plurality="a">Kích cỡ: %Ln kB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_dpopinfo_images_added_to_1">
      <source>Images added to %1</source>
      <translation variants="no">Đã thêm vào %1</translation>
    </message>
    <message numerus="no" id="txt_photos_info_delete_1">
      <source>Delete %1?</source>
      <translation variants="no">Xóa %[99]1?</translation>
    </message>
    <message numerus="no" id="txt_photos_list_mark_all">
      <source>Mark all</source>
      <translation variants="no">Đánh dấu tất cả</translation>
    </message>
    <message numerus="no" id="txt_photos_info_unable_to_play_slideshow">
      <source>Unable to play slideshow</source>
      <translation variants="no">Không thể phát trình chiếu</translation>
    </message>
    <message numerus="no" id="txt_photos_subhead_select_image">
      <source>Select image:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn hình ảnh:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_select_album">
      <source>Select Album:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn album:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_rotate_sub_90ccw">
      <source>90°CCW</source>
      <translation variants="no">90° ngược chiều kim đ.hồ</translation>
    </message>
    <message numerus="no" id="txt_photos_list_date_1">
      <source>Date: %1</source>
      <translation variants="no">Ngày: %1</translation>
    </message>
    <message numerus="yes" id="txt_photos_info_delete_ln_images">
      <source>Delete %Ln images?</source>
      <translation>
        <numerusform plurality="a">Xóa %Ln ảnh?</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_wallpaper">
      <source>Wallpaper</source>
      <translation variants="no">Hình nền</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_90cw">
      <source>90°CW</source>
      <translation variants="no">90° theo chiều kim đ.hồ</translation>
    </message>
    <message numerus="no" id="txt_photos_subhead_all_l1">
      <source>All (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #All (%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_list_favorite">
      <source>Favorite</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mục ưa thích</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_grid">
      <source>Grid</source>
      <translation variants="no">Dạng lưới</translation>
    </message>
    <message numerus="no" id="txt_photos_info_no_content">
      <source>No content</source>
      <translation variants="yes">
        <lengthvariant priority="1">(không có nội dung)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_list_time_1">
      <source>Time: %1</source>
      <translation variants="no">Thời gian: %1</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album_l1">
      <source>Album (%L1)</source>
      <translation variants="no">Album (%L1)</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_image_name">
      <source>Image name :</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Photo name:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_flip_in">
      <source>Flip In</source>
      <translation variants="no">Lật</translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_gb">
      <source>Size: %Ln Gb </source>
      <translation>
        <numerusform plurality="a">Kích cỡ: %Ln GB</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_sizeln_bytes">
      <source>Size:%Ln Bytes</source>
      <translation>
        <numerusform plurality="a">Kích cỡ:%Ln B</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_subhead_select_images">
      <source>Select images:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn ảnh:</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_mb">
      <source>Size: %Ln Mb</source>
      <translation>
        <numerusform plurality="a">Kích cỡ: %Ln MB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_photos_info_removing_images">
      <source>Removing images...</source>
      <translation variants="no">Đang xóa ảnh</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_rotate">
      <source>Rotate</source>
      <translation variants="no">Xoay</translation>
    </message>
    <message numerus="yes" id="txt_photos_info_remove_ln_images_from_album_the">
      <source>Remove %Ln images from album? (The files will not be deleted.)</source>
      <translation>
        <numerusform plurality="a">Xóa %Ln ảnh khỏi album? Ảnh sẽ không bị xóa khỏi thiết bị.</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_description">
      <source>Description :</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Description:</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_dblist_my_camera_val_ln_images">
      <source>%Ln images</source>
      <translation>
        <numerusform plurality="a">%Ln ảnh</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_info_refreshing_your_media">
      <source>Refreshing your media...</source>
      <translation variants="no">Đang làm mới</translation>
    </message>
    <message numerus="no" id="txt_photos_info_delete_selected_images">
      <source>Delete selected images?</source>
      <translation variants="no">vi #Delete selected photos?</translation>
    </message>
    <message numerus="no" id="txt_photos_button_share">
      <source>Share</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Share</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_dblist_val_ln_images">
      <source>%Ln images</source>
      <translation>
        <numerusform plurality="a">vi #%Ln photo</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_list_name">
      <source>Name:</source>
      <translation variants="no">vi #Name:</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view">
      <source>View</source>
      <translation variants="no">Xem</translation>
    </message>
    <message numerus="no" id="txt_photos_info_no_images_to_play_slide_show">
      <source>No images to play slide show</source>
      <translation variants="no">Không thể phát trình chiếu. Không có ảnh.</translation>
    </message>
    <message numerus="no" id="txt_photos_info_adding_images">
      <source>Adding images...</source>
      <translation variants="no">Đang thêm ảnh</translation>
    </message>
    <message numerus="no" id="txt_photos_list_description">
      <source>Description:</source>
      <translation variants="no">vi #Description:</translation>
    </message>
    <message numerus="no" id="txt_home_caption_photos">
      <source>Photos</source>
      <translation variants="no">vi #Photos</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_crop">
      <source>Crop</source>
      <translation variants="no">Cắt</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_zoom_in">
      <source>Zoom in/Zoom out</source>
      <translation variants="no">Phóng to/thu nhỏ</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_photos_button_new_album">
      <source>New album</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #New album</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_3d_effect">
      <source>3D Effect</source>
      <translation variants="no">Hiệu ứng 3-D</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_media_wall">
      <source>Media wall</source>
      <translation variants="no">Tường media</translation>
    </message>
    <message numerus="no" id="txt_photos_subhead_1_l2">
      <source>%1 (%L2)</source>
      <translation variants="no">%[25]1 (%L2)</translation>
    </message>
    <message numerus="no" id="txt_photos_info_name_1_already_in_use">
      <source>Name '%1' already in use</source>
      <translation variants="no">Tên '%[99]1' đã được sử dụng</translation>
    </message>
    <message numerus="no" id="txt_photos_list_l1l2">
      <source>%L1/%L2</source>
      <translation variants="no">%L1/%L2</translation>
    </message>
  </context>
</TS>