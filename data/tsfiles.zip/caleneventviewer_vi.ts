<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">Xóa ghi chú công việc?</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc họp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_delete">
      <source>Delete</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_weekly">
      <source>Repeats weekly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lặp lại hàng tuần</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_from_1">
      <source>From %1</source>
      <translation variants="no">Từ %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">Đánh dấu chưa xong</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily">
      <source>Repeats daily</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lặp lại hàng ngày</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_until_1">
      <source>Until %1</source>
      <translation variants="no">Cho đến %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mô tả:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Chỉnh sửa:</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_monthly">
      <source>Repeats monthly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lặp lại hàng tháng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Tất cả sự kiện</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chưa đặt tên</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">Xóa cuộc họp?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày hoàn tất:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Đánh dấu xong</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Chỉ sự kiện này</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_edit">
      <source>Edit</source>
      <translation variants="no">Chỉnh sửa</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú công việc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_send">
      <source>Send</source>
      <translation variants="no">Gửi</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_yearly">
      <source>Repeats Yearly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lặp lại hàng năm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_save_to_calendar">
      <source>Save to calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lưu vào Lịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_find_location_on_map">
      <source>Find location on map</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Find location on map</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_select_location">
      <source>Select location :</source>
      <translation variants="no">vi #Select location :</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_finding_location_on_m">
      <source>Finding location on map…</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Finding location on map…</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event ?</source>
      <translation variants="no">vi #Delete All-day event ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_location_not_found_on">
      <source>Location not found on map</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Location not found on map</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_select_location_from">
      <source>Select location from search results</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Select location from search results</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_fortnightly">
      <source>Repeats fortnightly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lặp lại hai tuần một lần</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_subject">
      <source>Subject</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chủ đề:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Xóa mục lịch lặp lại:</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_workdays">
      <source>Repeats workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lặp lại vào các ngày làm việc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location">
      <source>%1</source>
      <translation variants="no">vi #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_all_day_event">
      <source>All day event</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #All day event</lengthvariant>
      </translation>
    </message>
  </context>
</TS>