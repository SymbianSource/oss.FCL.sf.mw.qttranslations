<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="th">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">ยกเลิก​การ​เปลี่ยนแปลง</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event ?</source>
      <translation variants="no">th #Delete all-day entry?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_at_the_start">
      <source>At the start</source>
      <translation variants="no">เมื่อเริ่มต้น</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_end_time">
      <source>End time</source>
      <translation variants="no">เวลา​สิ้นสุด</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_workdays">
      <source>Workdays</source>
      <translation variants="no">วันทำงาน</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_start_time">
      <source>Start time</source>
      <translation variants="no">เวลา​เริ่มต้น</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">แก้ไข :</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">เหตุการณ์ทั้งหมด</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Monthly</source>
      <translation variants="no">รายเดือน</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_time">
      <source>Reminder time</source>
      <translation variants="no">เวลาเตือน</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">บันทึกสิ่งที่ต้องทำ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_off">
      <source>Off</source>
      <translation variants="no">ปิด</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_2_days_before">
      <source>2 days before</source>
      <translation variants="no">ก่อน 2 วัน</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Daily</source>
      <translation variants="no">รายวัน</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Repeat</source>
      <translation variants="no">เตือนซ้ำ</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Reminder</source>
      <translation variants="no">การเตือน</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Only once</source>
      <translation variants="no">ไม่​เตือน​ซ้ำ</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_description">
      <source>Description</source>
      <translation variants="no">ราย​ละเอียด</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_30_minutes_befo">
      <source>30 minutes before</source>
      <translation variants="no">ก่อน 30 นาที</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">เตือนซ้ำ​จนถึง</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Weekly</source>
      <translation variants="no">รายสัปดาห์</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">ลบรายการที่เตือนซ้ำ:</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>All day event</source>
      <translation variants="no">รายการแบบทั้งวัน</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">เพิ่ม​รายละเอียด</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_15_minutes_befo">
      <source>15 minutes before</source>
      <translation variants="no">ก่อน 15 นาที</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_5_minutes_befor">
      <source>5 minutes before</source>
      <translation variants="no">ก่อน 5 นาที</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_day_before">
      <source>1 day before</source>
      <translation variants="no">ก่อน 1 วัน</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Start date</source>
      <translation variants="no">วันที่​เริ่มต้น</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Start time</source>
      <translation variants="no">เวลา​เริ่มต้น</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_hour_before">
      <source>1 hour before</source>
      <translation variants="no">ก่อน 1 ชั่วโมง</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entry">
      <source>Delete entry?</source>
      <translation variants="no">ลบรายการ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_on_event_day">
      <source>On event day</source>
      <translation variants="no">ในวันที่มีเหตุการณ์</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>End date</source>
      <translation variants="no">วันที่​สิ้นสุด</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_meeting_saved">
      <source>New meeting saved</source>
      <translation variants="no">จัดเก็บ​การ​ประชุม​ใหม่แล้ว</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Location</source>
      <translation variants="no">ที่ตั้ง</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_fortnightly">
      <source>Fortnightly</source>
      <translation variants="no">รายปักษ์</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Delete entries ?</source>
      <translation variants="no">ลบรายการ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">หัวข้อ</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_event">
      <source>New event</source>
      <translation variants="yes">
        <lengthvariant priority="1">รายการใหม่</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Yearly</source>
      <translation variants="no">รายปี</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">นำรายละเอียดออก</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_all_day_event_updated">
      <source>All day event updated</source>
      <translation variants="no">th #All-day entry updated</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">การประชุม</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">ลบการประชุม?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">เตือนซ้ำ​จนถึง</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_meeting_updated">
      <source>Meeting updated</source>
      <translation variants="no">อัพเดต​การ​ประชุมแล้ว</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_all_day_event_saved">
      <source>New All day event saved</source>
      <translation variants="no">th #New all-day entry saved</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">การ​ประชุมนี้​เท่านั้น</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>End time</source>
      <translation variants="no">เวลา​สิ้นสุด</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_all_day_event">
      <source>All day event</source>
      <translation variants="yes">
        <lengthvariant priority="1">th #All-day entry</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_location_updated_keep_existing">
      <source>Location updated. Keep existing location on map ?</source>
      <translation variants="no">th #Location updated. Keep existing location on map?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">ปฏิทิน</lengthvariant>
      </translation>
    </message>
  </context>
</TS>