<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_dialer_ui_dblist_call_duration">
      <source>Call duration</source>
      <translation variants="yes">
        <lengthvariant priority="1">通话时间</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_info_call_event_will_be_removed_from">
      <source>Call event will be removed from the list. Continue?</source>
      <translation variants="no">将从列表中删除通话相关项。继续？</translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_dialled_calls">
      <source>Dialled calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">已拨电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_dialled">
      <source>Dialled</source>
      <translation variants="yes">
        <lengthvariant priority="1">已拨电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_call_service_sub_cellular">
      <source>Cellular</source>
      <translation variants="no">语音/视频通话</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type">
      <source>Call type</source>
      <translation variants="yes">
        <lengthvariant priority="1">通话类型</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_title_dialer">
      <source>Dialer</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨号程序</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_received">
      <source>Received</source>
      <translation variants="yes">
        <lengthvariant priority="1">已接电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_no_history_of_calls">
      <source>No history of calls</source>
      <translation variants="no">(无最近通话)</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_service_val_cellular">
      <source>Cellular</source>
      <translation variants="yes">
        <lengthvariant priority="1">语音/视频通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_menu_open_contact">
      <source>Open contact</source>
      <translation variants="no">打开名片</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_id">
      <source>Caller ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">本机号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_recent">
      <source>Recent</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_missed_calls">
      <source>Missed calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">未接电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_id_val_privat_number">
      <source>Privat number</source>
      <translation variants="yes">
        <lengthvariant priority="1">私人号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_date_and_time">
      <source>Date and time</source>
      <translation variants="yes">
        <lengthvariant priority="1">时间和日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_change_call_service_sub_cellul">
      <source>Cellular</source>
      <translation variants="no">语音/视频通话</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_menu_call_details">
      <source>Call details</source>
      <translation variants="no">通话详情</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_change_call_service">
      <source>Change call service</source>
      <translation variants="no">更改通话服务</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_info_all_call_events_will_be_remo">
      <source>All call events will be removed from the list. Continue?</source>
      <translation variants="no">将清除通话相关项列表。继续？</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_missed">
      <source>Missed</source>
      <translation variants="yes">
        <lengthvariant priority="1">未接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_no_matches_found">
      <source>No matches found</source>
      <translation variants="no">(无对应项)</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_service">
      <source>Call service</source>
      <translation variants="yes">
        <lengthvariant priority="1">通话服务</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">清除列表</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_voice_call">
      <source>Voice call</source>
      <translation variants="yes">
        <lengthvariant priority="1">语音通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_subhead_matches">
      <source>Matches</source>
      <translation variants="yes">
        <lengthvariant priority="1">对应项</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_missed">
      <source>Missed</source>
      <translation variants="yes">
        <lengthvariant priority="1">未接电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_title_clear_list">
      <source>Clear list</source>
      <translation variants="no">清除列表</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_video_call">
      <source>Video call</source>
      <translation variants="yes">
        <lengthvariant priority="1">视频通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_contact_search_on">
      <source>Contact search on</source>
      <translation variants="no">打开名片搜索</translation>
    </message>
    <message numerus="no" id="txt_dial_subhead_received_calls">
      <source>Received calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">已接电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_open_contact">
      <source>Open contact</source>
      <translation variants="no">打开名片</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_voip_call">
      <source>VoiP call</source>
      <translation variants="yes">
        <lengthvariant priority="1">互联网通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_dialled">
      <source>Dialled</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨出</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_recent_calls">
      <source>Recent calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_contact_search_off">
      <source>Contact search off</source>
      <translation variants="no">关闭名片搜索</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction">
      <source>Call direction</source>
      <translation variants="yes">
        <lengthvariant priority="1">通话方向</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_id_val_unknown_number">
      <source>Unknown number</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_call_using">
      <source>Call using</source>
      <translation variants="no">通话方式</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_received">
      <source>Received</source>
      <translation variants="yes">
        <lengthvariant priority="1">接入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_title_delete_event">
      <source>Delete event</source>
      <translation variants="no">从列表删除通话</translation>
    </message>
    <message numerus="no" id="txt_short_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">拨号程序</translation>
    </message>
    <message numerus="no" id="txt_long_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">拨号程序</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_callee_id">
      <source>Callee ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">收信人ID</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_last_call_event">
      <source>Last call event</source>
      <translation variants="yes">
        <lengthvariant priority="1">最后通话相关项</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_outgoing_line_1">
      <source>Change outgoing line 1</source>
      <translation variants="no">改为线路1</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_line_id_val_line_1">
      <source>%L1, line 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1，线路1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_line_id_val_line_2">
      <source>%L1, line 2</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1，线路2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_line_id">
      <source>Line ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">线路ID</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_outgoing_line_2">
      <source>Change outgoing line 2</source>
      <translation variants="no">改为线路2</translation>
    </message>
    <message numerus="no" id="txt_dial_title_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="no">存入名片夹</translation>
    </message>
    <message numerus="no" id="txt_dial_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">新建名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新现有名片</lengthvariant>
        <lengthvariant priority="2">zh #Update existing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_dialer">
      <source>Dialer</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨号程序</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_no_saved_number_for_this_contact">
      <source>No saved number for this contact. Call not possible</source>
      <translation variants="no">无法通话。缺少手机号码。</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_val_dialer_enable_access_to_recent">
      <source>Dialer enable access to recent calls and dialpad</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打电话和查看最近通话</lengthvariant>
        <lengthvariant priority="2">zh #Make and see recent calls</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_dpopinfo_silent_mode_activated">
      <source>Sounds on</source>
      <translation variants="no">声音已关</translation>
    </message>
    <message numerus="no" id="txt_dialer_dpopinfo_silent_mode_deactivated">
      <source>Sounds off</source>
      <translation variants="no">声音已开</translation>
    </message>
    <message numerus="no" id="txt_dialer_opt_copy_number">
      <source>Copy number</source>
      <translation variants="no">复制号码</translation>
    </message>
    <message numerus="no" id="txt_dialer_dpopinfo_number_copied">
      <source>Number copied</source>
      <translation variants="no">号码已复制</translation>
    </message>
    <message numerus="no" id="txt_dialer_menu_open_group">
      <source>Open group</source>
      <translation variants="no">打开通话组</translation>
    </message>
    <message numerus="no" id="txt_dialer_list_open_group">
      <source>Open group</source>
      <translation variants="no">打开通话组</translation>
    </message>
  </context>
</TS>