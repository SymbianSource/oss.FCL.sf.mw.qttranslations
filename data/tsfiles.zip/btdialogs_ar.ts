<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ar">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_info_delete_all_paired_devices_some_device">
      <source>Delete all paired devices? Some devices may be disconnected.</source>
      <translation variants="no">مسح كل الأجهزة المقترنة؟ قد يتم فصل بعض الأجهزة.</translation>
    </message>
    <message numerus="no" id="txt_bt_title_unable_to_enter_sim_access_profile">
      <source>Unable to enter SIM access profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">غير قادر على تنشيط وضع استخدام SIM عن بعد</lengthvariant>
        <lengthvariant priority="2">يتعذر تنشيط SIM عن بعد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_connected">
      <source>Connected</source>
      <translation variants="no">متصل مع</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_devices_some_devices_may_b">
      <source>Delete all devices? Some devices may be disconnected.</source>
      <translation variants="no">مسح كل الأجهزة؟ قد يتم فصل بعض الأجهزة.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unsupported_device_1">
      <source>Unsupported device: %1</source>
      <translation variants="no">جهاز غير مدعوم:
%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_waiting_the_other_device">
      <source>Waiting for the other device</source>
      <translation variants="no">قيد انتظار الجهاز الآخر</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to">
      <source>Connect to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">اتصال مع:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_there_seems_to_be_a_lot_of_pairing_que">
      <source>There seems to be uncommonly lot of pairing queries. Turn Bluetooth off to protect your device?</source>
      <translation variants="no">تم اكتشاف عدد غير معتاد من طلبات الاقتران. إلغاء تنشيط Bluetooth لحماية جهازك؟</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">‏Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_other_files_received">
      <source>N other files received</source>
      <translation variants="no">ar ##N other files received</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_on_ini_offline_mode">
      <source>Trun Bluetooth on in offline mode?</source>
      <translation variants="no">تنشيط Bluetooth في وضع عدم الاتصال؟</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_with_1_failed_either_the_pas">
      <source>Pairing with %1 failed. Either the passcodes didn’t match or the other device is turned off.</source>
      <translation variants="no">فشل الاقتران مع %[27]1. إما أن رمزي المرور غير متوافقين أو أن الجهاز الآخر لا يعمل.</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_use">
      <source>in use</source>
      <translation variants="no">نشط</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_off">
      <source>is now off</source>
      <translation variants="no">لا يعمل الآن</translation>
    </message>
    <message numerus="no" id="txt_bt_info_enter_the_following_code_to_the_1">
      <source>Enter the following code to the %1:</source>
      <translation variants="no">أدخل رمز المرور التالي على %[47]1:</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth_used">
      <source>Bluetooth used</source>
      <translation variants="no">‏Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">استخدام SIM عن بعد</translation>
    </message>
    <message numerus="no" id="txt_bt_info_not_possible_during_a_call">
      <source>Not possible during a call</source>
      <translation variants="no">غير قادر على إنشاء اتصال Bluetooth أثناء مكالمة</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_paired_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dialog_please_enter_the_passcode_for_1">
      <source>Please enter the passcode for %1:</source>
      <translation variants="no">أدخل رمز المرور لـ %[56]1:</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_on">
      <source>is now on</source>
      <translation variants="no">يعمل الآن</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pairing_with_1">
      <source>Pairing with %1</source>
      <translation variants="no">جار الاقتران مع %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_failed_remote_device_is_pairi">
      <source>Pairing failed. Remote device is pairing with another device.</source>
      <translation variants="no">فشل الاقتران. الجهاز البعيد قيد الاقتران مع جهاز آخر.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_blocked_devices">
      <source>Delete all blocked devices?</source>
      <translation variants="no">مسح كل الأجهزة المحظورة؟</translation>
    </message>
    <message numerus="no" id="txt_bt_button_more_devices">
      <source>More devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">أجهزة أخرى</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_bluetooth_not_allowed_to_be_turned_on">
      <source>Bluetooth not allowed to be turned on in offline mode</source>
      <translation variants="no">غير قادر على تنشيط Bluetooth في وضع عدم الاتصال</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_cancelled_from_1">
      <source>from %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_connected_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_entering_sim_access_profile">
      <source>Entering SIM access profile</source>
      <translation variants="no">جار تنشيط وضع استخدام SIM عن بعد</translation>
    </message>
    <message numerus="no" id="txt_bt_title_received_from_1">
      <source>Received from %1</source>
      <translation variants="no">تم الاستلام من %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_exited">
      <source>exited</source>
      <translation variants="no">غير نشط</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_disconnected">
      <source>Disconnected</source>
      <translation variants="no">مفصول عن</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_unpaired">
      <source>Unpaired</source>
      <translation variants="no">غير مقترن مع</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_receiving_failed">
      <source>Receiving failed</source>
      <translation variants="no">فشل الاستلام</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from">
      <source>Receive messages from:</source>
      <translation variants="yes">
        <lengthvariant priority="1">استلام رسائل من:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_disconnected_from_1">
      <source>from %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_hidden">
      <source>is now hidden</source>
      <translation variants="no">مخفي الآن</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_paired">
      <source>Paired</source>
      <translation variants="no">مقترن مع</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sending_cancelled">
      <source>Sending cancelled</source>
      <translation variants="no">تم إلغاء الإرسال</translation>
    </message>
    <message numerus="no" id="txt_bt_info_do_you_still_want_to_enable_sim_access">
      <source>Do you still want to enable SIM access profile?</source>
      <translation variants="no">تنشيط وضع استخدام SIM عن بعد؟</translation>
    </message>
    <message numerus="no" id="txt_bt_title_sending_file_l1l2_to_3">
      <source>Sending file %L1/%L2 to %3</source>
      <translation variants="no">جار إرسال الملف %L1/%L2 إلى %3</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_off_there_is_an_active">
      <source>Trun Bluetooth off? There is an active connection.</source>
      <translation variants="no">يوجد اتصال Bluetooth نشط. تنشيط اتصال جديد على أية حال؟</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_battery_low">
      <source>Battery low</source>
      <translation variants="no">ضعف البطارية في</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pair_with">
      <source>Pair with:</source>
      <translation variants="yes">
        <lengthvariant priority="1">اقتران مع:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_try_again">
      <source>Try again</source>
      <translation variants="yes">
        <lengthvariant priority="1">محاولة أخرى</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_disable_sim_access_profile">
      <source>Exit SIM access profile?</source>
      <translation variants="no">إلغاء تنشيط وضع استخدام SIM عن بعد؟</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to_paired_device">
      <source>Connect to paired device:</source>
      <translation variants="yes">
        <lengthvariant priority="1">اتصال مع الجهاز المقترن:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_sim_access_profile_is_used_next_time_t">
      <source>SIM access profile is used next time the car kit connects to this device and the Bluetooth is turned on.</source>
      <translation variants="no">سيتم تنشيط وضع استخدام SIM عن بعد في المرة التالية عندما يتم توصيل طقم السيارة بهذا الجهاز وتشغيل Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_pair_with_1">
      <source>Unable to pair with %1</source>
      <translation variants="no">غير قادر على الاقتران مع %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_bluetooth_device_address_1">
      <source>Bluetooth device address: %1</source>
      <translation variants="no">عنوان جهاز Bluetooth:
%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_perform_bluetooth_operation">
      <source>Unable to perform Bluetooth operation</source>
      <translation variants="no">غير قادر على إجراء عملية عبر Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_title_operation_not_possible_when_sim_acces">
      <source>Operation not possible when SIM access profile is in use</source>
      <translation variants="yes">
        <lengthvariant priority="1">غير قادر على إجراء العملية</lengthvariant>
        <lengthvariant priority="2">ar #Operation not possible in remote SIM mode</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from_paired_device">
      <source>Receive messages from paired device:</source>
      <translation variants="yes">
        <lengthvariant priority="1">استلام رسائل من:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_connect_with_bluetooth">
      <source>Unable to connect with %1</source>
      <translation variants="no">غير قادر على الاتصال مع %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_all_files_sent">
      <source>All files sent</source>
      <translation variants="no">تم إرسال الكل إلى</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receiving_files_from_1">
      <source>Receiving from %1</source>
      <translation variants="no">جار الاستلام من %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_with_1">
      <source>with %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_title_send_to">
      <source>Send to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">إرسال إلى:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_does_this_code_match_the_code_on_1">
      <source>Does this code match the code on %1?</source>
      <translation variants="no">هل يتوافق رمز المرور التالي مع الرمز الموجود على %[19]1؟</translation>
    </message>
    <message numerus="no" id="txt_bt_list_dont_ask_again_with_this_device">
      <source>Don't ask again with this device</source>
      <translation variants="no">عدم السؤال مرة أخرى مع هذا الجهاز</translation>
    </message>
    <message numerus="no" id="txt_bt_title_no_sim_card_in_the_device">
      <source>No SIM card in the device</source>
      <translation variants="yes">
        <lengthvariant priority="1">لا توجد بطاقة SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpinfo_as_web_connection">
      <source>as web connection</source>
      <translation variants="no">يستخدم كاتصال ويب</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_1">
      <source>in %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_to_connect_1_2_needs_to_be_disconnec">
      <source>To connect %1 %2 needs to be disconnected first.</source>
      <translation variants="no">غير قادر على الاتصال مع %[41]1. يجب فصل %[41]2 أولاً.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_files_already_received">
      <source>N files already received</source>
      <translation variants="no">ar ##N files already received</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_sent_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_try_entering_the_sim_access_profile_ag">
      <source>Try entering the SIM access profile again?</source>
      <translation variants="no">محاولة تنشيط وضع استخدام SIM عن بعد مرة أخرى؟</translation>
    </message>
  </context>
</TS>