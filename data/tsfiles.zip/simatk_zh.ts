<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_simatk_dialog_sim_services">
      <source>SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">SIM服务</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">SIM服务</translation>
    </message>
    <message numerus="no" id="txt_simatk_title_sim_services">
      <source>SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">SIM服务</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_simatk_dblist_val_sim_service_information_on_h">
      <source>Sim service information on Homescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">主屏幕上的SIM卡服务信息</lengthvariant>
        <lengthvariant priority="2">zh #SIM servs. on Home screen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_entern1_digit_09">
      <source>Enter:\n(1 digit 0-9) </source>
      <translation variants="no">输入(0-9之间的1个数字)： </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">zh ##SIM Services</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_enternnumber">
      <source>Enter:\n(number)</source>
      <translation variants="no">输入(号码)：</translation>
    </message>
    <message numerus="no" id="txt_simatk_titlw_cmcc_sim_services">
      <source>CMCC SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">CMCC SIM服务</lengthvariant>
        <lengthvariant priority="2">zh #CMCC SIM servs.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">zh ##SIM Services</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_entern1_character">
      <source>Enter:\n(1 character) </source>
      <translation variants="no">输入(1个字符)：</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_request_not_allowed">
      <source>Request not allowed</source>
      <translation variants="no">请求不被允许</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_enter">
      <source>Enter:</source>
      <translation variants="no">输入：</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_sending">
      <source>Sending</source>
      <translation variants="no">正在发送数据</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_1_about_to_call">
      <source>%1 about to call</source>
      <translation variants="no">%[46]1准备通话</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_sim_services_not_available">
      <source>SIM services not available</source>
      <translation variants="no">SIM服务不可用</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_open_connection">
      <source>Open connection?</source>
      <translation variants="no">连接？</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_request_modified">
      <source>Request modified</source>
      <translation variants="no">请求已修改</translation>
    </message>
  </context>
</TS>