<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="sr">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="no">Tekst telefon</translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">Podešavanja pribora</lengthvariant>
        <lengthvariant priority="2">Podešav.pribora</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">Pribor</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Slušalice sa mikrofonom</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="no">4:3</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headse">
      <source>Headset</source>
      <translation variants="no">Slušalice sa mikrofonom</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">Razmera TV-a</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tekst telefon</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="no">16:9</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">Tip pribora</translation>
    </message>
  </context>
</TS>