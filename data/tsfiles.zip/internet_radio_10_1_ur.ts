<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_irad_opt_go_to_station">
      <source>Go to station</source>
      <translation variants="no">اسٹیشن پر جائیں</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_search_in_music_store">
      <source>Search in music store</source>
      <translation variants="no">میو. اسٹور میں تلاش</translation>
    </message>
    <message numerus="no" id="txt_irad_info_downloading_logos">
      <source>Downloading logos</source>
      <translation variants="no">لوگوز ڈاؤن لوڈ ہو رہے ہیں</translation>
    </message>
    <message numerus="no" id="txt_irad_title_internet_radio">
      <source>Internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">انٹرنیٹ ریڈیو</lengthvariant>
        <lengthvariant priority="2">نیٹ ریڈیو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_internetradio">
      <source>Internetradio</source>
      <translation variants="no">انٹرنیٹ ریڈیو</translation>
    </message>
    <message numerus="no" id="txt_irad_info_connecting_to_server">
      <source>Connecting to server</source>
      <translation variants="no">سرور سے اتصال کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_irad_info_click_the_song_and_find_it_in_music_store">
      <source>Click the song and find it in music store</source>
      <translation variants="no">ur #Click the song and find it in music store</translation>
    </message>
    <message numerus="no" id="txt_irad_info_not_allowed_by_this_station">
      <source>Not allowed by this station</source>
      <translation variants="no">ur #Not allowed by this station</translation>
    </message>
    <message numerus="no" id="txt_irad_info_insufficient_disk_space">
      <source>Insufficient disk space  </source>
      <translation variants="no">ur #Insufficient disk space  </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by_val_descending">
      <source>Descending</source>
      <translation variants="no">ur #Descending</translation>
    </message>
    <message numerus="no" id="txt_irad_info_failed_to_connect">
      <source>Connecting failed</source>
      <translation variants="no">اتصال سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by_val_custom">
      <source>Custom</source>
      <translation variants="no">ur #Custom</translation>
    </message>
    <message numerus="no" id="txt_irad_info_search">
      <source>Search</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Search</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_visualization">
      <source>Visualization</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Visualization</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_disclaimer_and_liability_content_2">
      <source>NO WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF TITLE OR NON-INFRINGEMENT OR IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, IS MADE IN RELATION TO THE AVAILABILITY, ACCURACY, RELIABILITY OR CONTENT OF THE SERVICE. NOKIA SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR FOR BUSINESS INTERRUPTION ARISING OUT OF THE USE OF OR INABILITY TO USE THE SERVICE, EVEN IF NOKIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. SOME JURISDICTIONS DO NOT ALLOW EXCLUSION OF CERTAIN WARRANTIES OR LIMITATIONS OF LIABILITY, SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. THE LIABILITY OF NOKIA WOULD IN SUCH CASE BE LIMITED TO THE GREATEST EXTENT PERMITTED BY LAW.\n\nNothing contained herein shall prejudice the statutory rights of any party dealing as a consumer. Nothing contained herein limits Nokia's liability in the event of death or personal injury resulting from Nokia's negligence.</source>
      <translation variants="no">ur #NO WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF TITLE OR NON-INFRINGEMENT OR IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, IS MADE IN RELATION TO THE AVAILABILITY, ACCURACY, RELIABILITY OR CONTENT OF THE SERVICE. NOKIA SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR FOR BUSINESS INTERRUPTION ARISING OUT OF THE USE OF OR INABILITY TO USE THE SERVICE, EVEN IF NOKIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. SOME JURISDICTIONS DO NOT ALLOW EXCLUSION OF CERTAIN WARRANTIES OR LIMITATIONS OF LIABILITY, SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. THE LIABILITY OF NOKIA WOULD IN SUCH CASE BE LIMITED TO THE GREATEST EXTENT PERMITTED BY LAW.\n\nNothing contained herein shall prejudice the statutory rights of any party dealing as a consumer. Nothing contained herein limits Nokia's liability in the event of death or personal injury resulting from Nokia's negligence.</translation>
    </message>
    <message numerus="no" id="txt_irad_button_accept">
      <source>Accept</source>
      <translation variants="no">قبول کریں</translation>
    </message>
    <message numerus="yes" id="txt_irad_subtitle_stations">
      <source>%Ln stations</source>
      <translation>
        <numerusform plurality="a">ur #%Ln station</numerusform>
        <numerusform plurality="b">ur #%Ln stations</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_select_items_to_delete">
      <source>Select items to delete</source>
      <translation variants="no">ur #Select items to delete</translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_station_address">
      <source>Station address</source>
      <translation variants="no">اسٹیشن ویب پتہ</translation>
    </message>
    <message numerus="no" id="txt_irad_info_can_not_add_more">
      <source>Can't add more</source>
      <translation variants="no">مشمولات کے لیے کافی حافظہ نہیں</translation>
    </message>
    <message numerus="no" id="txt_irad_info_station_with_new_name_exists">
      <source>Station with new name exists</source>
      <translation variants="no">اس نام کا اسٹ. پہلے سے موجود</translation>
    </message>
    <message numerus="no" id="txt_irad_info_nokia_internet_radio">
      <source>Nokia Internet Radio service (“Service”) enables you to discover and experience the content of Internet radio stations. YOU AGREE THAT YOUR USE OF THE SERVICE ACKNOWLEDGES THAT YOU HAVE READ THIS AGREEMENT, YOU HAVE UNDERSTOOD IT AND YOU AGREE TO BE BOUND BY ITS TERMS AND CONDITIONS. If you do not agree, please note that you will not be allowed to use the Service.</source>
      <translation variants="no">Nokia‏ انٹرنیٹ ریڈیو خدمت (“خدمت”) انٹرنیٹ ریڈیو اسٹیشن کے مشمولات دریافت کرنے اور ان سے لطف اندوز ہونے میں مدد دیتا ہے۔ آپ اس سے اتفاق کرتے ہیں کہ آپ کے ذریعے خدمت کا استعمال اس کا اعتراف ہے کہ آپ نے یہ معاہدہ پڑھ لیا ہے، اسے سمجھ لیا ہے اور آپ اس کے شرائط و ضوابط کے پابند ہیں۔ اگر آپ اتفاق نہیں کرتے تو براہ کرم یاد رکھیں کہ آپ کو خدمت کا استعمال نہیں کرنے دیا جائے گا۔</translation>
    </message>
    <message numerus="no" id="txt_irad_info_clear_song_list">
      <source>Clear song list?</source>
      <translation variants="no">گانا فہرست صاف کریں؟ گانے ہٹا ئے جائیںگے۔</translation>
    </message>
    <message numerus="no" id="txt_irad_info_share_not_available">
      <source>Share not available</source>
      <translation variants="no">شراکتی اسٹیشن دستیاب نہیں</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_song_p">
      <source>Unknown song</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم گانا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by">
      <source>Sort by</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Sort by</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_rename">
      <source>Rename</source>
      <translation variants="no">ur #Rename</translation>
    </message>
    <message numerus="no" id="txt_irad_info_song_recognition_not_available">
      <source>Song recognition not available</source>
      <translation variants="no">گانے کی شناخت دستیاب نہیں</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_search_results">
      <source>Search results</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Search results</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_songs_recently_played">
      <source>Songs recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Songs recently played</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_settings">
      <source>Settings</source>
      <translation variants="no">ur #Settings</translation>
    </message>
    <message numerus="no" id="txt_irad_info_station_not_find">
      <source>Station not found</source>
      <translation variants="no">ur #Station not found</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_l">
      <source>Unknown artist - %1</source>
      <translation variants="no">ur #Unknown artist - %1</translation>
    </message>
    <message numerus="no" id="txt_irad_info_definitions_content">
      <source>Internet radio stations are entities that generally produce and distribute audio content and related metadata over the Internet in a stream.\n\nThe link to the Internet radio station is a resource locator or a set of resource locators that enable the user to access the content streamed by the Internet radio station.
</source>
      <translation variants="no">انٹرنیٹ ریڈیو اسٹیشنز وہ شناختیں ہیں جو عموماً ایک تسلسل میں آڈیو مشمولات اور متعلقہ میٹا ڈیٹا، تشکیل دیتے اور تقسیم کرتے ہیں۔

انٹرنیٹ ریڈیو اسٹیشن کا ربط وسیلے کا ایسا نشاندہندہ یا وسیلے کے نشاندہندہ کا نظام ہیں جو انٹرنیٹ ریڈیو اسٹیشن کے جاری کردہ مشمولات تک رسائی میں صارف کی مدد کرتے ہیں۔</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_definitions">
      <source>DEFINITIONS</source>
      <translation variants="no">تشریحات</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_identify_song">
      <source>Identify song</source>
      <translation variants="no">گانا کی شناخت کریں</translation>
    </message>
    <message numerus="no" id="txt_irad_info_delete_station">
      <source>Delete station?</source>
      <translation variants="no">اسٹیشن مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_irad_info_service_availability_content">
      <source>The Service is provided as a convenience to you. It is provided "as is" and on an "as available" basis. Nokia does not guarantee that the Service shall be uninterrupted or error-free. Nokia reserves the right to revise the Service or withdraw access to it at any time.\n\nNokia may provide upgrades for software applications related to the Service at its sole discretion.
</source>
      <translation variants="no">یہ خدمت آپ کو ایک سہولت کے طور پر فراہم کی جارہی ہے۔ یہ "جیسی ہے" اور "جیسی دستیاب ہے" کی بنیاد پر فراہم کی جاتی ہے۔ Nokia اس کی ضمانت نہیں دیتا کہ اس خدمت میں کوئی رکاوٹ نہیں آئے گی اور کوئی غلطی نہیں ہوگی۔ Nokia خدمت پر نظرثانی یا اس تک رسائی کو کسی بھی وقت واپس لینے کا حق محفوظ رکھتا ہے۔

Nokia خدمت سے متعلق سافٹ ویئر پروگراموں کے برتر درجات فراہم کرنے کا کلی اختیار رکھتا ہے۔</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_use_of_the_service">
      <source>USE OF THE SERVICE</source>
      <translation variants="no">خدمت کا استعمال</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_privacy">
      <source>PRIVACY</source>
      <translation variants="no">رازداری</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_stations_recently_played">
      <source>Stations recently played</source>
      <translation variants="no">ur #Stations recently played</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_matching_station_found">
      <source>No matching station found</source>
      <translation variants="no">ur #No matching station found</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by_val_ascending">
      <source>Ascending </source>
      <translation variants="no">ur #Ascending </translation>
    </message>
    <message numerus="no" id="txt_irad_info_max_reached_delete_station_before_adding_new_favorite">
      <source>Max reached. Delete station before adding new favorite</source>
      <translation variants="no">ur #Max reached. Delete station before adding new favorite</translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_recently_played">
      <source>Stations recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Stations recently played</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Favorites</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_max_limit_reached">
      <source>Max limit reached</source>
      <translation variants="no">ur #Max limit reached</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_songs_recently_played">
      <source>Songs recently played</source>
      <translation variants="no">ur #Songs recently played</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_internet_radio">
      <source>Internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Internet radio</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_service_availability">
      <source>SERVICE AVAILABILITY</source>
      <translation variants="no">خدمت کی دستیابی</translation>
    </message>
    <message numerus="no" id="txt_irad_info_clear_station_list">
      <source>Clear station list?</source>
      <translation variants="no">اسٹیشن فہرست صاف کریں؟ ہٹا ئے جائیںگے۔</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_add_to_favorites">
      <source>Add to favorites</source>
      <translation variants="no">پسندیدہ میں شامل</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_unknown_song">
      <source>Unknown artist - Unknown song</source>
      <translation variants="no">نامعلوم گانا اور فنکار</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_governing_law">
      <source>GOVERNING LAW</source>
      <translation variants="no">قابل اطلاق قانون</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_terms_conditions">
      <source>Terms &amp; Conditions</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Terms &amp; Conditions</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_privacy_content">
      <source>Nokia is committed to protecting user privacy, and thus implements strict confidentiality policies.\n\n In order to monitor the use of and to improve the Service, Nokia may collect usage data including, but not limited to, information about the Internet radio stations accessed, the time spent on each station and the items rated as favourites.\n\nNokia does not collect any information that allows identification of the user of the Service.
</source>
      <translation variants="no">نوکیا صارف کی رازداری کے تحفظ کا پابند ہے اور اس طرح رازداری کے سخت اصولوں کا نفاذ کرتا ہے۔

خدمت کے استعمال کی نگرانی اور اسے بہتر بنانے کے لیے Nokia استعمال سے متعلق ڈیٹا جمع کرسکتا ہے جس میں استعمال کیے گئے ریڈیو اسٹیشنوں، ہر اسٹیشن پر گزارے گئے وقت اور پسندیدہ قرار دیے گئے آئیٹموں سے متعلق معلومات شامل ہیں لیکن جو ان تک ہی محدود نہیں ہے۔

Nokia ایسی کوئی معلومات جمع نہیں کرتا جس سے خدمت کے صارف کی شناخت ہونے میں مدد مل سکے۔</translation>
    </message>
    <message numerus="no" id="txt_irad_button_decline">
      <source>Decline</source>
      <translation variants="no">انکار کریں</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_p">
      <source>Unknown artist</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم فنکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_use_of_the_service_content">
      <source>Use of the Service is only permitted for your private and non-commercial use. Nokia shall own all intellectual property rights relating to the Service.\n\nNokia reserves the right to change these terms and conditions by informing you of such change.
</source>
      <translation variants="no">اس خدمت کے استعمال کی اجازت صرف آپ کے ذاتی اور غیر تجارتی کاموں کے لیے ہے۔ Nokia خدمت سے متعلق تمام ذہنی ملکیت کے حقوق اپنی تحویل میں رکھے گا۔ 

Nokia آپ کو اطلاع دے کر ان شرائط و ضوابط کو تبدیل کرنے کا حق محفوظ رکھتا ہے۔</translation>
    </message>
    <message numerus="no" id="txt_irad_info_the_service_content">
      <source>The Service enables the following:\n\n1. browsing of links to Internet radio stations;\n\n2. accessing the content of Internet radio stations;
</source>
      <translation variants="no">یہ خدمت مندرجہ ذیل کاموں میں مدد دیتی ہے:

۱۔ انٹرنیٹ ریڈیو اسٹیشنوں تک ربطوں کی براؤزنگ؛

۲۔ انٹرنیٹ ریڈیو اسٹیشنوں تک مشمولات کی رسائی؛</translation>
    </message>
    <message numerus="no" id="txt_irad_info_invalid_station_address">
      <source>Invalid station address</source>
      <translation variants="no">ur #Invalid station address</translation>
    </message>
    <message numerus="no" id="txt_irad_info_hi_this_is_my_favorite_station_hope_you_like_it">
      <source>Hi, this is my favorite station. Hope you like it</source>
      <translation variants="no">ur #Hi, this is my favorite station. Hope you like it</translation>
    </message>
    <message numerus="no" id="txt_irad_connecting_failed_try_next_address">
      <source>Connecting failed, try next address</source>
      <translation variants="no">ur #Connecting failed, try next address</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_song_l">
      <source>%1 - Unknown song</source>
      <translation variants="no">ur #%1 - Unknown song</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_the_services">
      <source>THE SERVICE</source>
      <translation variants="no">خدمت</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">فہرست صاف کریں</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_policy_copyright">
      <source>POLICY REGARDING ALLEGATIONS OF COPYRIGHT INFRINGEMENT</source>
      <translation variants="no">حق اشاعت کی خلاف ورزی کے الزامات سے متعلق پالیسی</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_network_connection">
      <source>No network connection</source>
      <translation variants="no">(کوئی نیٹ ورک اتصال نہیں)</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_songs">
      <source>Songs recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">تازہ ترین چلائے گئے گانے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_menu_share">
      <source>Share</source>
      <translation variants="no">شرکت کریں</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_language">
      <source>Stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">زبان کے اعتبار سے اسٹیشن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_country_region">
      <source>Stations by country/region</source>
      <translation variants="yes">
        <lengthvariant priority="1">ملک/خطے کے اعتبار سے اسٹیشن</lengthvariant>
        <lengthvariant priority="2">اسٹیشن بہ اعتبار ملک/علاقہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_station_name">
      <source>Station name</source>
      <translation variants="no">اسٹیشن کا نام</translation>
    </message>
    <message numerus="yes" id="txt_irad_setlabel_bit_rate">
      <source>Bit rate: %Ln kbps</source>
      <translation>
        <numerusform plurality="a">بٹ ریٹ: %Ln ک بائٹ فی سیکنڈ</numerusform>
        <numerusform plurality="b">بٹ ریٹ: %Ln ک بائٹ فی سیکنڈ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_country_region">
      <source>Stations by country/region</source>
      <translation variants="yes">
        <lengthvariant priority="1">ملک/خطے کے اعتبار سے اسٹیشن</lengthvariant>
        <lengthvariant priority="2">اسٹ. بہ اعتبار ملک/علاقہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_share">
      <source>Share</source>
      <translation variants="no">شرکت کریں</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_stations">
      <source>Stations recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">تازہ ترین چلائے گئے اسٹیشن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_network_setting">
      <source>Network setting</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیٹورک ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_high">
      <source>High</source>
      <translation variants="no">اعلی</translation>
    </message>
    <message numerus="no" id="txt_irad_info_music_store_not_available">
      <source>Music store not available</source>
      <translation variants="no">میوزک اسٹور دستیاب نہیں</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality">
      <source>Download quality</source>
      <translation variants="yes">
        <lengthvariant priority="1">ڈاؤن لوڈ کا معیار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_from_play_list">
      <source>Stations from play list</source>
      <translation variants="yes">
        <lengthvariant priority="1">پلے فہرست کے اسٹیشن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_connecting_timout">
      <source>Connecting timeout</source>
      <translation variants="no">اتصال کا وقت ختم</translation>
    </message>
    <message numerus="no" id="txt_irad_info_favorite_updated">
      <source>Favorite updated</source>
      <translation variants="no">پسندیدہ چینل کی تجدید کی گئی</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_search">
      <source>Search</source>
      <translation variants="no">تلاش کریں</translation>
    </message>
    <message numerus="no" id="txt_irad_info_hi_these_are_my_favorite_stations_hope_you_like_them">
      <source>Hi, these are my favorite stations. Hope you like them</source>
      <translation variants="no">ہیلو، یہ میرے پسندیدہ اسٹیشن ہیں۔ امید ہے کہ آپ انہیں پسند کریں گے!</translation>
    </message>
    <message numerus="no" id="txt_irad_info_added_to_favorites">
      <source>Added to Favorites</source>
      <translation variants="no">پسندیدہ میں شامل کیا گيا</translation>
    </message>
    <message numerus="no" id="txt_irad_info_details_not_available">
      <source>Details not available</source>
      <translation variants="no">ur #Details not available</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_delete_stations">
      <source>Delete stations</source>
      <translation variants="no">ur #Delete stations</translation>
    </message>
    <message numerus="no" id="txt_irad_info_disclaimer_and_liability_content_1">
      <source>For your ease of accessibility, Nokia may include links to Internet radio stations that are owned or operated by third parties. Nokia does not guarantee that the links to Internet radio stations will be operational. In addition, the content that is not related to Nokia does not imply whatsoever that Nokia endorses the content as such or the products or services referenced in such content.\n\nYou must review and agree to each station's rules of use, if any, before accessing it. You also agree that Nokia has no control over the content of third-party services and cannot assume any responsibility for the content provided by Internet radio stations.\n\nAccessing the content of Internet radio stations using the Service may involve the transmission of large amounts of data through your service provider's network. Contact your service provider for information about data transmission charges. Note that using the Service with Internet radio stations that are delivering higher bit rate streams to you may incur higher costs associated with data traffic.\n\nThe data traffic associated with the usage of the Service may include the following at least: updating the content of the stations’ directory, streaming data from the Internet radio station, collecting statistical data and upgrading the Internet radio application.\n\nNokia is not liable for the costs of data traffic associated with your use of the Service.\n\n</source>
      <translation variants="no">ur #For your ease of accessibility, Nokia may include links to Internet radio stations that are owned or operated by third parties. Nokia does not guarantee that the links to Internet radio stations will be operational. In addition, the content that is not related to Nokia does not imply whatsoever that Nokia endorses the content as such or the products or services referenced in such content.\n\nYou must review and agree to each station's rules of use, if any, before accessing it. You also agree that Nokia has no control over the content of third-party services and cannot assume any responsibility for the content provided by Internet radio stations.\n\nAccessing the content of Internet radio stations using the Service may involve the transmission of large amounts of data through your service provider's network. Contact your service provider for information about data transmission charges. Note that using the Service with Internet radio stations that are delivering higher bit rate streams to you may incur higher costs associated with data traffic.\n\nThe data traffic associated with the usage of the Service may include the following at least: updating the content of the stations’ directory, streaming data from the Internet radio station, collecting statistical data and upgrading the Internet radio application.\n\nNokia is not liable for the costs of data traffic associated with your use of the Service.\n\n</translation>
    </message>
    <message numerus="no" id="txt_irad_info_governing_law_content">
      <source>As used in these terms and conditions, "Nokia" means Nokia Corporation. Nokia operates and controls the Service from locations within Finland. As such, the information contained on the Service hereby is deemed to be provided in Finland.\n\nExcept where prohibited by applicable law, these terms and conditions shall be governed by the laws of Finland without regard to conflict of law provisions. For US residents: These terms and conditions shall be governed by the laws of Texas.\n\nCopyright © Nokia Corporation 2006. All rights reserved.
</source>
      <translation variants="no">جیسا کہ ان شرائط و ضوابط میں استعمال کیا گیا ہے، "Nokia" کا مطلب "Nokia Corporation" ہے۔ Nokia فنلینڈ کے اندر کے مقامات سے خدمات کو چلاتا اور ان کو کنٹرول کرتا ہے۔ اس طرح، اس خدمت میں شامل معلومات فنلینڈ میں فراہم شدہ تصور کی جاتی ہیں۔

 علاوہ ان مقامات کے جہاں قانوناً ممنوع ہیں، یہ شرائط و ضوابط قانونی دفعات سے تصادم سے قطع نظر فنلینڈ کے قوانین کی پابند ہوں گی۔ امریکی شہریوں کے لیے: یہ شرائط و ضوابط ٹکساس کے قوانین کے تحت آئیں گے۔

حق اشاعت © Nokia Corporation ۲۰۰۶۔ جملہ حقوق محفوظ۔</translation>
    </message>
    <message numerus="no" id="txt_irad_info_unnamed_station">
      <source>Unnamed station</source>
      <translation variants="yes">
        <lengthvariant priority="1">بے نام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_policy_copyright_content">
      <source>If you believe that your copyrighted work has been handled in a way that constitutes copyright infringement, you may notify Nokia by providing a notification including the following:\n\n(1) A physical or electronic signature of a person authorised to act on behalf of the owner of the exclusive right that is allegedly infringed;\n\n(2) Identification or description of the copyrighted work claimed to have been infringed;\n\n(3) Identification or description of the material that is claimed to be infringing and information reasonably sufficient to locate the material;\n\n(4) Your name, address, telephone number, e-mail address and any other information that will permit Nokia to contact you;\n\n(5) A statement that you believe, in good faith, that use of the material in the manner on which this complaint is based is not authorised by the copyright owner, its agent or the law; and\n\n(6) A statement that the information in the notification is accurate and, under penalty of perjury, that you are authorised to act on behalf of the owner of an exclusive right that is allegedly infringed.\n\nThe notification must be sent to our Designated Agent address at:\n\nCopyright.Notices@nokia.com
</source>
      <translation variants="no">اگر آپ سمجھتے ہیں کہ آپ کے حق اشاعت کا کام اس انداز میں سرانجام دیا گیا ہے جس سے حق اشاعت کی خلاف ورزی ہوئی ہے تو آپ ایک اطلاع نامے کے ذریعے Nokia کو آگاہ کر سکتے ہیں جس میں مندرجہ ذیل شامل ہیں:

(۱)اس شخص کا ذاتی یا برقی دستخط جو اس حق کے مخصوص مالک کی طرف سے کارروائی کرنے کا مجاز ہو جس کی خلاف ورزی ہوئی ہے؛

(۲)حق اشاعت سے متعلق اس کام کی شناخت اور تفصیل جس کی خلاف ورزی کا دعوی کیا جارہا ہے؛

(۳)اس مواد کی شناخت اور تفصیل جس کی خلاف ورزی کا دعوی کیا جارہا ہے اور مواد کی معقول نشاندہی والی معلومات؛

(۴)آپ کا نام، پتہ، ٹیلیفون، ای-میل پتہ اور کوئی دیگر معلومات جس سے Nokia کو آپ سے رابطے میں آسانی ہو؛

(۵)یہ بیان کہ آپ نیک نیتی سے یہ سمجھتے ہیں کہ اس انداز میں مواد کا استعمال جس پر یہ شکایت مبنی ہے حق اشاعت کے مالک سے، اس کے کارندے سے یا قانوناً، مجاز شدہ نہیں ہے اور؛

(۶)یہ بیان کہ آپ اس مخصوص حق کے مالک کی طرف سے جس کی خلاف ورزی مبینہ طور پر ہوئی ہے، کارروائی کرنے کے لیے مجاز شدہ ہیں۔</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_disclaimer_and_liability">
      <source>DISCLAIMER AND LIABILITY</source>
      <translation variants="no">اعلان عدم ذمہ داری اور جواب دہی</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_standard">
      <source>Standard</source>
      <translation variants="no">معیاری</translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_language">
      <source>Stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">زبان کے اعتبار سے اسٹیشن</lengthvariant>
        <lengthvariant priority="2">اسٹیشن بہ اعتبار زبان</lengthvariant>
      </translation>
    </message>
  </context>
</TS>