<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_pimcm_formlabel_company">
      <source>Company</source>
      <translation variants="no">ur ##Company</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_location">
      <source>Location</source>
      <translation variants="no">ur ##Location</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_priority">
      <source>Priority</source>
      <translation variants="no">ur ##Priority</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_fax">
      <source>Fax</source>
      <translation variants="no">ur ##Fax</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">ur ##Prefix</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_address">
      <source>Address</source>
      <translation variants="no">ur ##Address</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_title_to_do_notes">
      <source>To-do notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##To-do notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">ur ##Subject</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">ur ##Revision</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_synchronization">
      <source>Synchronisation</source>
      <translation variants="no">ur ##Synchronisation</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_push_to_talk">
      <source>Push to talk</source>
      <translation variants="no">ur ##Push to talk</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">ur ##First name</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">ur ##Due date</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_suffix">
      <source>Suffix</source>
      <translation variants="no">ur ##Suffix</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_sms">
      <source>SMS</source>
      <translation variants="no">ur ##SMS</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_synchronisation">
      <source>Synchronisation</source>
      <translation variants="no">ur ##Synchronisation</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">ur ##Alarm</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_assistant_name">
      <source>Assistant's name</source>
      <translation variants="no">ur ##Assistant's name</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_department">
      <source>Department</source>
      <translation variants="no">ur ##Department</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">ur ##Anniversary</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_occasion">
      <source>Occasion</source>
      <translation variants="no">ur ##Occasion</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">ur ##Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_name">
      <source>Name</source>
      <translation variants="no">ur ##Name</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_anniversaries">
      <source>Anniversaries</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Anniversaries</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_start_date">
      <source>Start date</source>
      <translation variants="no">ur ##Start date</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_picture">
      <source>Picture</source>
      <translation variants="no">ur ##Picture</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_first_name_reading">
      <source>First name reading</source>
      <translation variants="no">ur ##First name reading</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_home">
      <source>Home</source>
      <translation variants="no">ur ##Home</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_state">
      <source>State</source>
      <translation variants="no">ur ##State</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_momos">
      <source>Memos</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Memos</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_assistant_phone">
      <source>Assistant's phone</source>
      <translation variants="no">ur ##Assistant's phone</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">ur ##Middle name</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_country">
      <source>Country</source>
      <translation variants="no">ur ##Country</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_borthday">
      <source>Birthday</source>
      <translation variants="no">ur ##Birthday</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_default">
      <source>Default</source>
      <translation variants="no">ur ##Default</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_title_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Contacts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_business">
      <source>Business</source>
      <translation variants="no">ur ##Business</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_dtmf">
      <source>DTMF</source>
      <translation variants="no">ur ##DTMF</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_city">
      <source>City</source>
      <translation variants="no">ur ##City</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_children">
      <source>Children</source>
      <translation variants="no">ur ##Children</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">ur ##Revision</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_completed">
      <source>Completed</source>
      <translation variants="no">ur ##Completed</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_wv_user_id">
      <source>WV User ID</source>
      <translation variants="no">ur ##WV User ID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_postalcode">
      <source>Postal code</source>
      <translation variants="no">ur ##Postal code</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_formatted_name">
      <source>Name</source>
      <translation variants="no">ur ##Name</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_street">
      <source>Street</source>
      <translation variants="no">ur ##Street</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_url">
      <source>URL address</source>
      <translation variants="no">ur ##URL address</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_uid">
      <source>UID</source>
      <translation variants="no">ur ##UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_pager">
      <source>Pager</source>
      <translation variants="no">ur ##Pager</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_email">
      <source>E-Mail</source>
      <translation variants="no">ur ##E-Mail</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_other">
      <source>Other</source>
      <translation variants="no">ur ##Other</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_uid">
      <source>UID</source>
      <translation variants="no">ur ##UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_description">
      <source>Description</source>
      <translation variants="no">ur ##Description</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">ur ##Job title</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_nickname">
      <source>Nickname</source>
      <translation variants="no">ur ##Nickname</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">ur ##Subject</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_last_name_reading">
      <source>Last name reading</source>
      <translation variants="no">ur ##Last name reading</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_pobox">
      <source>P.O. Box</source>
      <translation variants="no">ur ##P.O. Box</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_start_time_and_date">
      <source>Start time and date</source>
      <translation variants="no">ur ##Start time and date</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">ur ##SIP</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_synchronization">
      <source>Synchronisation</source>
      <translation variants="no">ur ##Synchronisation</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_share_view">
      <source>Share view</source>
      <translation variants="no">ur ##Share view</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_note">
      <source>Note</source>
      <translation variants="no">ur ##Note</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_tel_internet">
      <source>Tel. Internet</source>
      <translation variants="no">ur ##Tel. Internet</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_mobile">
      <source>Mobile</source>
      <translation variants="no">ur ##Mobile</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_end_date">
      <source>End date</source>
      <translation variants="no">ur ##End date</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_telephone">
      <source>Telephone</source>
      <translation variants="no">ur ##Telephone</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_completion_date">
      <source>Completion date</source>
      <translation variants="no">ur ##Completion date</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">ur ##Last name</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Alarm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_video_number">
      <source>Video number</source>
      <translation variants="no">ur ##Video number</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_date">
      <source>Date</source>
      <translation variants="no">ur ##Date</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_car_phone">
      <source>Car phone</source>
      <translation variants="no">ur ##Car phone</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">ur ##Extension</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_end_time_and_date">
      <source>End time and date</source>
      <translation variants="no">ur ##End time and date</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_appointments">
      <source>Appointments</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Appointments</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_description">
      <source>Description</source>
      <translation variants="no">ur ##Description</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_uid">
      <source>UID</source>
      <translation variants="no">ur ##UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">ur ##Revision</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">ur ##Spouse</translation>
    </message>
  </context>
</TS>