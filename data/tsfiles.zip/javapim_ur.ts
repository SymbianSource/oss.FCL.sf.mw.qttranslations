<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_pimtodo_formlabel_synchronization">
      <source>Synchronisation</source>
      <translation variants="no">ہمزمانگی</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_pobox">
      <source>P.O. Box</source>
      <translation variants="no">پی او باکس</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">گزشتہ ترمیم شدہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_borthday">
      <source>Birthday</source>
      <translation variants="no">یوم پیدائش</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">ملازمت کا عنوان</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_default">
      <source>Default</source>
      <translation variants="no">آغازی</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_date">
      <source>Date</source>
      <translation variants="no">تاریخ</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">موضوع</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_uid">
      <source>UID</source>
      <translation variants="no">UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_company">
      <source>Company</source>
      <translation variants="no">کمپنی</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">آخری نام</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_location">
      <source>Location</source>
      <translation variants="no">مقام</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">الارم</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">گزشتہ ترمیم شدہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_assistant_name">
      <source>Assistant's name</source>
      <translation variants="no">معاون کا نام</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_picture">
      <source>Picture</source>
      <translation variants="no">تصویر</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_video_number">
      <source>Video number</source>
      <translation variants="no">ویڈیو ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_completed">
      <source>Completed</source>
      <translation variants="no">مکمل شدہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_push_to_talk">
      <source>Push to talk</source>
      <translation variants="no">دبائیں بولیں</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">پہلا نام</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_car_phone">
      <source>Car phone</source>
      <translation variants="no">کار فون</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_department">
      <source>Department</source>
      <translation variants="no">شعبہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_first_name_reading">
      <source>First name reading</source>
      <translation variants="no">ur ##First name reading</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">سالگرہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_last_name_reading">
      <source>Last name reading</source>
      <translation variants="no">ur ##Last name reading</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_pager">
      <source>Pager</source>
      <translation variants="no">پیجر</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_priority">
      <source>Priority</source>
      <translation variants="no">اولیت</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_synchronization">
      <source>Synchronisation</source>
      <translation variants="no">ہمزمانگی</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_title_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">روابط</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_home">
      <source>Home</source>
      <translation variants="no">ur ##Home</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_telephone">
      <source>Telephone</source>
      <translation variants="no">ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">توسیع</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">مقررہ تاریخ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_mobile">
      <source>Mobile</source>
      <translation variants="no">موبائل</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_wv_user_id">
      <source>WV User ID</source>
      <translation variants="no">WV صارف شناخت</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_postalcode">
      <source>Postal code</source>
      <translation variants="no">پوسٹل/زپ کوڈ</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_end_date">
      <source>End date</source>
      <translation variants="no">تاریخ اختتام</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_business">
      <source>Business</source>
      <translation variants="no">ur ##Business</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_end_time_and_date">
      <source>End time and date</source>
      <translation variants="no">وقت اور تاریخ اختتام</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_dtmf">
      <source>DTMF</source>
      <translation variants="no">DTMF</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_state">
      <source>State</source>
      <translation variants="no">ریاست/صوبہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_fax">
      <source>Fax</source>
      <translation variants="no">فیکس</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_email">
      <source>E-Mail</source>
      <translation variants="no">میل پتہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">عنوان</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_share_view">
      <source>Share view</source>
      <translation variants="no">ویڈیو شراکت</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_appointments">
      <source>Appointments</source>
      <translation variants="yes">
        <lengthvariant priority="1">میٹنگیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_occasion">
      <source>Occasion</source>
      <translation variants="no">موقع</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_nickname">
      <source>Nickname</source>
      <translation variants="no">لقب</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">گھنٹی کی آواز</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_formatted_name">
      <source>Name</source>
      <translation variants="no">نام</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_start_time_and_date">
      <source>Start time and date</source>
      <translation variants="no">وقت اور تاریخ آغاز</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_suffix">
      <source>Suffix</source>
      <translation variants="no">لاحقہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_street">
      <source>Street</source>
      <translation variants="no">سڑک</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_tel_internet">
      <source>Tel. Internet</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_momos">
      <source>Memos</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Reminders</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_name">
      <source>Name</source>
      <translation variants="no">نام</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">شوہر/بیوی</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_anniversaries">
      <source>Anniversaries</source>
      <translation variants="yes">
        <lengthvariant priority="1">سالگرہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_address">
      <source>Address</source>
      <translation variants="no">پتہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_other">
      <source>Other</source>
      <translation variants="no">دیگر</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_title_to_do_notes">
      <source>To-do notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">اہم کام نوٹس</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_uid">
      <source>UID</source>
      <translation variants="no">UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_city">
      <source>City</source>
      <translation variants="no">شہر</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_description">
      <source>Description</source>
      <translation variants="no">تفصیل</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_assistant_phone">
      <source>Assistant's phone</source>
      <translation variants="no">معاون کا نمبر</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_url">
      <source>URL address</source>
      <translation variants="no">ویب پتہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_note">
      <source>Note</source>
      <translation variants="no">نوٹ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_sms">
      <source>SMS</source>
      <translation variants="no">متنی پیغام</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_synchronisation">
      <source>Synchronisation</source>
      <translation variants="no">ہمزمانگی</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_uid">
      <source>UID</source>
      <translation variants="no">UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_children">
      <source>Children</source>
      <translation variants="no">بچے</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">درمیانی نام</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_completion_date">
      <source>Completion date</source>
      <translation variants="no">مکمل شدہ تاریخ</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_description">
      <source>Description</source>
      <translation variants="no">تفصیل</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">موضوع</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">الارم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">گزشتہ ترمیم شدہ</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_start_date">
      <source>Start date</source>
      <translation variants="no">تاریخ آغاز</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_country">
      <source>Country</source>
      <translation variants="no">ملک/خطہ</translation>
    </message>
  </context>
</TS>