<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_videos_dblist_recently_watched_val_no_videos">
      <source>(No videos)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(không có video)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_protected_clip_can_not_be_played">
      <source>Protected clip, can not be played through TV-Out</source>
      <translation variants="no">Video clip được bảo vệ. Không thể sử dụng cáp TV-Out.</translation>
    </message>
    <message numerus="no" id="txt_videos_menu_play">
      <source>Play</source>
      <translation variants="no">Phát</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_connect">
      <source>Unable to connect</source>
      <translation variants="no">Không thể kết nối</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_connect_connection_time">
      <source>Unable to connect: Connection timeout</source>
      <translation variants="no">Không thể kết nối với máy chủ. Hết giờ kết nối.</translation>
    </message>
    <message numerus="no" id="txt_videos_info_license_has_expired_or_it_is_missi">
      <source>License has expired or it is missing</source>
      <translation variants="no">Giấy phép đã hết hạn hoặc bị thiếu</translation>
    </message>
    <message numerus="no" id="txt_videos_info_video_playback_is_not_allowed_duri">
      <source>Video playback is not allowed during video call</source>
      <translation variants="no">Không thể phát video clip trong khi có cuộc gọi video</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_connect_file_not_found">
      <source>Unable to connect: File not found</source>
      <translation variants="no">Không thể kết nối với máy chủ. Không tìm thấy tập tin.</translation>
    </message>
    <message numerus="no" id="txt_videos_info_invalid_clip_operation_canceled">
      <source>Invalid Clip. Operation canceled</source>
      <translation variants="no">Video clip không hợp lệ. Đã hủy thao tác.</translation>
    </message>
    <message numerus="yes" id="txt_videos_dblist_val_ln_videos">
      <source>%Ln videos</source>
      <translation>
        <numerusform plurality="a">%Ln video</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_video_play_not_allowed_during_voic">
      <source>Video play not allowed during voice call over 2G network</source>
      <translation variants="no">Không thể phát video clip trong khi cuộc gọi thoại ở mạng 2G</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_remove_videos">
      <source>Remove videos…</source>
      <translation variants="no">Xóa video</translation>
    </message>
    <message numerus="no" id="txt_videos_list_copyright">
      <source>Copyright:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bản quyền:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_drm">
      <source>DRM</source>
      <translation variants="yes">
        <lengthvariant priority="1">DRM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_downloaded">
      <source>Downloaded</source>
      <translation variants="yes">
        <lengthvariant priority="1">Video tải về</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_subtitle_1_l2">
      <source>%1 (%L2)</source>
      <translation variants="no">%[25]1 (%L2)</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_recently_watched">
      <source>Recently watched</source>
      <translation variants="no">Được xem gần đây</translation>
    </message>
    <message numerus="no" id="txt_videos_list_format">
      <source>Format:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Định dạng:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_title_videos">
      <source>Videos</source>
      <translation variants="yes">
        <lengthvariant priority="1">Video</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_no_videos">
      <source>(No videos)</source>
      <translation variants="no">vi ##(No videos)</translation>
    </message>
    <message numerus="no" id="txt_videos_subtitle_recently_watched">
      <source>Recently watched</source>
      <translation variants="yes">
        <lengthvariant priority="1">Video được xem gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mô tả:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_size">
      <source>Size</source>
      <translation variants="no">Kích cỡ</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_recently_watched">
      <source>Recently watched</source>
      <translation variants="yes">
        <lengthvariant priority="1">Được xem gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by">
      <source>Sort by:</source>
      <translation variants="no">Sắp xếp theo:</translation>
    </message>
    <message numerus="no" id="txt_videos_info_to_get_videos_visit_ovi_store">
      <source>To get videos, visit OVI store.</source>
      <translation variants="no">vi ##To get videos, visit OVI store.</translation>
    </message>
    <message numerus="no" id="txt_videos_menu_remove_from_collection">
      <source>Remove from collection</source>
      <translation variants="no">Xóa khỏi bộ sưu tập</translation>
    </message>
    <message numerus="no" id="txt_videos_list_language">
      <source>Language:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngôn ngữ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_no_video">
      <source>(No video)</source>
      <translation variants="no">vi ##(No video)</translation>
    </message>
    <message numerus="no" id="txt_long_caption_videos">
      <source>Videos</source>
      <translation variants="no">Video</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_rating">
      <source>Rating</source>
      <translation variants="no">Đánh giá</translation>
    </message>
    <message numerus="no" id="txt_videos_list_location">
      <source>Location:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Vị trí:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_collection_name">
      <source>Collection name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên bộ sưu tập:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_opt_add_to_collection">
      <source>Add to collection</source>
      <translation variants="no">Thêm vào bộ sưu tập</translation>
    </message>
    <message numerus="no" id="txt_videos_list_modified">
      <source>Modified:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sửa đổi:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured">
      <source>Captured</source>
      <translation variants="yes">
        <lengthvariant priority="1">Video đã ghi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_file_size">
      <source>File Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích cỡ tập tin:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_menu_share">
      <source>Share</source>
      <translation variants="no">Chia sẻ</translation>
    </message>
    <message numerus="yes" id="txt_videos_subtitle_ln_videos">
      <source>%Ln videos</source>
      <translation>
        <numerusform plurality="a">%Ln video</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_resolution">
      <source>Resolution:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Độ phân giải:</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_videos_dpopinfo_ln_videos_added_to_1">
      <source>"%Ln videos added to %1"</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_menu_attach">
      <source>Attach</source>
      <translation variants="no">vi #Attach</translation>
    </message>
    <message numerus="no" id="txt_videos_slidervalue_l1l2">
      <source>%L1:%L2</source>
      <translation variants="no">vi #%L1:%L2</translation>
    </message>
    <message numerus="no" id="txt_videos_info_resource_lost">
      <source>Resource Lost</source>
      <translation variants="no">Mất tài nguyên</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_connect_not_enough_band">
      <source>Unable to connect: Not enough bandwidth</source>
      <translation variants="no">Không thể kết nối với máy chủ. Không đủ băng thông.</translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1l2l3">
      <source>%L1:%L2:%L3</source>
      <translation variants="no">%L1:%L2:%L3</translation>
    </message>
    <message numerus="no" id="txt_common_menu_rename_item">
      <source>Rename</source>
      <translation variants="no">Đổi tên</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1_l2_kb">
      <source>%L1:%L2:%L3, %L4 kB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1:%L2:%L3, %L4 kB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_kb">
      <source>%L1 kB</source>
      <translation variants="no">%L1 kB</translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_mbps">
      <source>%L1 Mbps</source>
      <translation variants="no">%L1 MB/s</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_delete_some_videos_which">
      <source>Unable to delete some videos which are currently open.</source>
      <translation variants="no">Không thể xóa một số video. Đóng các video đang mở và thử lại.</translation>
    </message>
    <message numerus="no" id="txt_videos_dialog_entry_new_collection">
      <source>New collection</source>
      <translation variants="no">vi ##New collection</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_videos">
      <source>Videos</source>
      <translation variants="no">vi ##Videos</translation>
    </message>
    <message numerus="no" id="txt_videos_setlabel_mark_all">
      <source>Mark all</source>
      <translation variants="no">Đánh dấu tất cả</translation>
    </message>
    <message numerus="no" id="txt_videos_info_do_you_want_to_delete_1">
      <source>Do you want to delete %1?</source>
      <translation variants="no">Xóa %[95]1?</translation>
    </message>
    <message numerus="no" id="txt_videos_info_all_videos_already_added_to_this_c">
      <source>All videos already added to this collection.</source>
      <translation variants="no">Tất cả video đã được thêm vào bộ sưu tập này</translation>
    </message>
    <message numerus="no" id="txt_videos_info_do_you_want_to_remove_collection">
      <source>Do you want to remove collection %1?</source>
      <translation variants="no">Xóa bộ sưu tập %[85]1?</translation>
    </message>
    <message numerus="no" id="txt_videos_list_belongs_to_collections">
      <source>Belongs to collections:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thuộc về bộ sưu tập:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_delete_1_it_is_current">
      <source>Do you want to delete %1?</source>
      <translation variants="no">Không thể xóa. Tập tin '%[71]1' đang mở.</translation>
    </message>
    <message numerus="yes" id="txt_videos_dpopinfo_ln_videos_are_being_deleted">
      <source>%Ln videos are being deleted.</source>
      <translation>
        <numerusform plurality="a">vi #Deleting %Ln video</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_title_select_videos">
      <source>Select videos:</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Select videos:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1_l2_gb">
      <source>%L1:%L2:%L3, %L4 GB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1:%L2:%L3, %L4 GB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_proxy_host_name">
      <source>Proxy host name</source>
      <translation variants="no">vi #Proxy host name</translation>
    </message>
    <message numerus="no" id="txt_videos_list_audio_type">
      <source>Audio type:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Loại âm thanh:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_remove_collection_1">
      <source>Unable to remove collection %1.</source>
      <translation variants="no">Không thể xóa bộ sưu tập %1</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_remove_some_collections">
      <source>Unable to remove some collections.</source>
      <translation variants="no">vi #Unable to remove some collections</translation>
    </message>
    <message numerus="no" id="txt_videos_menu_remove_collection">
      <source>Remove collection</source>
      <translation variants="no">Xóa bộ sưu tập</translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1l2">
      <source>%L1×%L2</source>
      <translation variants="no">%L1×%L2</translation>
    </message>
    <message numerus="no" id="txt_videos_title_select_collection">
      <source>Select collection:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn bộ sưu tập:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_title_enter_name">
      <source>Collection name</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên bộ sưu tập</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_service">
      <source>Service:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dịch vụ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_button_attach">
      <source>Attach</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Attach</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1l2l3">
      <source>%L1:%L2:%L3</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #%L1:%L2:%L3</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_none">
      <source>None</source>
      <translation variants="no">vi #None</translation>
    </message>
    <message numerus="no" id="txt_videos_subhead_video_streaming_settings">
      <source>Video streaming settings</source>
      <translation variants="no">vi #Video streaming settings</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_val_l1l2">
      <source>%L1/%L2</source>
      <translation variants="no">vi #%L1/%L2</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1_kb">
      <source>%L1 kB</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #%L1 kB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_connect_invalid_url">
      <source>Unable to connect: Invalid URL</source>
      <translation variants="no">Không thể kết nối với máy chủ. Địa chỉ web không hợp lệ.</translation>
    </message>
    <message numerus="no" id="txt_videos_list_author">
      <source>Author:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tác giả:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_menu_add_to_collection">
      <source>Add to collection</source>
      <translation variants="no">Thêm vào bộ sưu tập</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_number_of_items">
      <source>Number of items</source>
      <translation variants="no">Số mục</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_total_length">
      <source>Total length</source>
      <translation variants="no">Tổng độ dài</translation>
    </message>
    <message numerus="no" id="txt_videos_subtitle_captured_l1">
      <source>Captured (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã ghi (%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_proxy_port">
      <source>Proxy port</source>
      <translation variants="no">vi #Proxy port</translation>
    </message>
    <message numerus="no" id="txt_videos_list_bitrate">
      <source>Bitrate:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tốc độ bit:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_gb">
      <source>%L1 GB</source>
      <translation variants="no">vi #%L1 GB</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_min_udp_port">
      <source>Min UDP port</source>
      <translation variants="no">vi #Min UDP port</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_share">
      <source>Share</source>
      <translation variants="no">vi #Share</translation>
    </message>
    <message numerus="no" id="txt_videos_slidervalue_l1">
      <source>%L1</source>
      <translation variants="no">vi #%L1</translation>
    </message>
    <message numerus="no" id="txt_videos_slidervalue_l1l2l3_2">
      <source>%L1:%L2:%L3</source>
      <translation variants="no">%L1:%L2:%L3</translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_gbps">
      <source>%L1 Gbps</source>
      <translation variants="no">%L1 GB/s</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1_l2_mb">
      <source>%L1:%L2:%L3, %L4 MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1:%L2:%L3, %L4 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_mb">
      <source>%L1 MB</source>
      <translation variants="no">%L1 MB</translation>
    </message>
    <message numerus="yes" id="txt_videos_subtitle_ln_collections">
      <source>%Ln collections</source>
      <translation>
        <numerusform plurality="a">%Ln bộ sưu tập</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_max_udp_port">
      <source>Max UDP port</source>
      <translation variants="no">vi #Max UDP port</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_access_point">
      <source>Access point</source>
      <translation variants="no">vi #Access point</translation>
    </message>
    <message numerus="no" id="txt_videos_list_date">
      <source>Creation date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_opt_create_new_collection">
      <source>Create new collection</source>
      <translation variants="no">Tạo bộ sưu tập mới</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_name">
      <source>Name</source>
      <translation variants="no">Tên</translation>
    </message>
    <message numerus="no" id="txt_videos_subtitle_downloaded_l1">
      <source>Downloaded (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã tải về (%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_duration">
      <source>Duration:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời lượng:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sub_date">
      <source>Date</source>
      <translation variants="no">Ngày</translation>
    </message>
    <message numerus="no" id="txt_videos_list_keywords">
      <source>Keywords:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tag:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_details">
      <source>Details</source>
      <translation variants="no">Chi tiết</translation>
    </message>
    <message numerus="no" id="txt_videos_button_new">
      <source>New</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_kbps">
      <source>%L1 kbps</source>
      <translation variants="no">%L1 kB/s</translation>
    </message>
    <message numerus="no" id="txt_videos_formlabel_proxy_in_use">
      <source>Proxy in use</source>
      <translation variants="no">vi #Proxy in use</translation>
    </message>
    <message numerus="no" id="txt_videos_list_title">
      <source>Title:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tiêu đề:</lengthvariant>
      </translation>
    </message>
  </context>
</TS>