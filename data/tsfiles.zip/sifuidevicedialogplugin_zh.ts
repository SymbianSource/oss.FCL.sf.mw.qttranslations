<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_installer_title_items_to_install">
      <source>Items to install:</source>
      <translation variants="no">要安装的项目：</translation>
    </message>
    <message numerus="no" id="txt_installer_title_install">
      <source>Install?</source>
      <translation variants="no">安装?</translation>
    </message>
    <message numerus="no" id="txt_installer_list_unknown_language">
      <source>Unknown language</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知语言</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_installer_list_appname_version">
      <source>%1 (v %2)</source>
      <translation variants="no">%[99]1(%[99]2版)</translation>
    </message>
    <message numerus="no" id="txt_installer_button_show">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">显示</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_installer_title_select_language">
      <source>Select language:</source>
      <translation variants="no">选择语言：</translation>
    </message>
    <message numerus="no" id="txt_installer_info_installation_failed">
      <source>Installation failed</source>
      <translation variants="no">安装失败</translation>
    </message>
    <message numerus="no" id="txt_installer_list_appsize_mb">
      <source>%L1 MB</source>
      <translation variants="no">%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_installer_list_appsize_kb">
      <source>%L1 kB</source>
      <translation variants="no">%L1 kB</translation>
    </message>
    <message numerus="no" id="txt_installer_list_appsize_b">
      <source>%L1 B</source>
      <translation variants="no">%L1字节</translation>
    </message>
    <message numerus="no" id="txt_installer_title_installed">
      <source>Installed</source>
      <translation variants="no">已安装</translation>
    </message>
    <message numerus="no" id="txt_installer_title_installing">
      <source>Installing</source>
      <translation variants="no">正在安装</translation>
    </message>
    <message numerus="no" id="txt_installer_button_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">详情</lengthvariant>
      </translation>
    </message>
  </context>
</TS>