<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_common_button_call">
      <source>Call</source>
      <translation variants="no">zh_tw #Call</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_must_include_letters_and_nu">
      <source>Must include letters and numbers</source>
      <translation variants="no">必須包含字母與數字</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_new_lock_code">
      <source>New lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">輸入新鎖定密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_lock_code_created">
      <source>Lock code created</source>
      <translation variants="no">鎖定密碼已建立</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_remote_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_code_must_not_contain_conse">
      <source>Code must not contain consecutive characters</source>
      <translation variants="no">密碼不能包含連續字元</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="no">zh_tw #OK</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_30_minutes">
      <source>30 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">30分鐘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_characters_cannot_be_repeat">
      <source>Characters cannot be repeated</source>
      <translation variants="no">字元不能重複</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_subhead_remote_locking">
      <source>Remote locking</source>
      <translation variants="no">遠端鎖定</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_lock_code">
      <source>Lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">鎖定密碼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_dialog_retype_locking_message">
      <source>Retype locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">確認新鎖定訊息：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_devicelocking_info_lock_code_cannot_be_same_as">
      <source>Lock code cannot be same as previous  %Ln lock codes</source>
      <translation>
        <numerusform plurality="a">此鎖定密碼已在前%Ln次密碼中使用過。請再試一次。</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_remote_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_locking_message_created">
      <source>Locking message created</source>
      <translation variants="no">鎖定訊息已建立</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_lock_when_sim_changed">
      <source>Lock when SIM changed</source>
      <translation variants="yes">
        <lengthvariant priority="1">當更換SIM卡時鎖定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_lock_code_unlock">
      <source>Not specified</source>
      <translation variants="no">鎖定密碼</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_wrong_lock_code">
      <source>Wrong lock code</source>
      <translation variants="no">鎖定密碼錯誤。</translation>
    </message>
    <message numerus="no" id="txt_device_dialog_new_locking_message">
      <source>New locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">輸入新鎖定訊息：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_more_than_two_consecutive_n">
      <source>More than two consecutive numbers not allowed</source>
      <translation variants="no">不允許使用兩個以上的連續數字</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_60_minutes">
      <source>60 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">60分鐘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_lock_code_can_be_changed_l">
      <source>Lock code can be changed %L1n times in %L2n hours</source>
      <translation variants="no">zh_tw #Security code can be changed %[99]1 times in %[99]2 hours</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_automatic_locking">
      <source>Automatic locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動鎖定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_5_minutes">
      <source>5 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">5分鐘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_lock_code_is_expired">
      <source>Lock code is expired.</source>
      <translation variants="no">鎖定密碼已逾期。</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_must_be_at_least_l1_charac">
      <source>Must be at least %L1 characters</source>
      <translation variants="no">鎖定密碼必須至少包含%Ln個字元</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_the_locking_message_and_the">
      <source>The locking message and the lock code should not be equal</source>
      <translation variants="no">鎖定訊息與鎖定密碼必須不同</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_subhead_device_locking">
      <source>Device Locking</source>
      <translation variants="no">裝置鎖定</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_code_must_contain_at_least">
      <source>Code must contain at least %L1 special characters</source>
      <translation variants="no">鎖定密碼必須至少包含%Ln個特殊字元</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_code_must_not_contain_singl">
      <source>Code must not contain single repeated character</source>
      <translation variants="no">個別的字元不能連續重複多次</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_create_lock_code">
      <source>Create lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">建立鎖定密碼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_cannot_contain_more_than_l">
      <source>Cannot contain more than %L1 characters</source>
      <translation variants="no">鎖定密碼無法包含超過%Ln個字元</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_lock_code">
      <source>Lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">輸入目前的鎖定密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_messages_do_not_match">
      <source>Messages do not match</source>
      <translation variants="no">訊息不符</translation>
    </message>
    <message numerus="no" id="txt_remotelocking_button_sim_changed_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_sim_changed_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">僅能撥打緊急電話</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpopinfo_try_again">
      <source>Try again</source>
      <translation variants="no">請再試一次。</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_the_security_code_must_be_a">
      <source>The security code must be alphanumeric</source>
      <translation variants="no">鎖定密碼必須為英文字母與數字</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_lock_code_is_blocked">
      <source>Lock code is blocked</source>
      <translation variants="no">鎖定密碼已鎖。</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_lock_code_can_be_used_for_p">
      <source>Lock code can be used for protecting the device from unauthorized use</source>
      <translation variants="no">鎖定密碼可以用來保護您的裝置，以免他人未經授權使用</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_remote_locking">
      <source>Remote locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">遠端鎖定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_information_included_in_the">
      <source>Information included in the lock code is not allowed</source>
      <translation variants="no">zh_tw #New code contains characters that are not permitted</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_locking_message">
      <source>Locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">鎖定訊息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_retype_new_lock_code">
      <source>Retype new lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">確認新鎖定密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_characters_cannot_be_rep_no">
      <source>Characters cannot be repeated more than %L1 times</source>
      <translation variants="no">zh_tw #Characters cannot be repeated more than %Ln time</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_when_keys_screen">
      <source>When keys &amp; screen locked</source>
      <translation variants="yes">
        <lengthvariant priority="1">當按鍵和螢幕鎖定時</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="no">zh_tw #Cancel</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_device_lock">
      <source>Device lock</source>
      <translation variants="yes">
        <lengthvariant priority="1">裝置鎖</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_codes_do_not_match">
      <source>Codes do not match</source>
      <translation variants="no">密碼不符</translation>
    </message>
    <message numerus="yes" id="txt_devicelocking_dpopinfo_wait_ln_minutes">
      <source>Wait %Ln minutes</source>
      <translation>
        <numerusform plurality="a">等待%Ln分鐘。</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_device_locking">
      <source>Device locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">裝置鎖定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_must_include_upper_and_lowe">
      <source>Must include upper and lower case characters</source>
      <translation variants="no">必須包含大小寫字母</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_incorrect_lock_code_one_at">
      <source>Incorrect lock code. One attempt left before data is erased.</source>
      <translation variants="no">鎖定密碼不正確。刪除資料以前剩下一次機會輸入。</translation>
    </message>
  </context>
</TS>