<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_devicelocking_formlabel_remote_locking">
      <source>Remote locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">遠端鎖定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_locking_message">
      <source>Locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">鎖定訊息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_when_keys_screen">
      <source>When keys &amp; screen locked</source>
      <translation variants="no">當按鍵和螢幕鎖定時</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_retype_new_lock_code">
      <source>Retype new lock code</source>
      <translation variants="no">確認新鎖定密碼：</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_messages_do_not_match">
      <source>Messages do not match</source>
      <translation variants="no">訊息不符</translation>
    </message>
    <message numerus="no" id="txt_remotelocking_button_sim_changed_on">
      <source>On</source>
      <translation variants="no">開</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_on">
      <source>On</source>
      <translation variants="no">開</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpopinfo_try_again">
      <source>Try again</source>
      <translation variants="no">請再試一次。</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">僅能撥打緊急電話</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_locking_message_created">
      <source>Locking message created</source>
      <translation variants="no">鎖定訊息已建立</translation>
    </message>
    <message numerus="no" id="txt_device_dialog_retype_locking_message">
      <source>Retype locking message</source>
      <translation variants="no">確認新鎖定訊息：</translation>
    </message>
    <message numerus="no" id="txt_device_dialog_new_locking_message">
      <source>New locking message</source>
      <translation variants="no">輸入新鎖定訊息：</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_lock_code_is_blocked">
      <source>Lock code is blocked</source>
      <translation variants="no">鎖定密碼已鎖。</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_sim_changed_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_subhead_remote_locking">
      <source>Remote locking</source>
      <translation variants="no">遠端鎖定</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_wrong_lock_code">
      <source>Wrong lock code</source>
      <translation variants="no">鎖定密碼錯誤。</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_lock_code">
      <source>Lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">鎖定密碼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_lock_when_sim_changed">
      <source>Lock when SIM changed</source>
      <translation variants="yes">
        <lengthvariant priority="1">當更換SIM卡時鎖定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_remote_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_lock_code">
      <source>Lock code</source>
      <translation variants="no">輸入目前的鎖定密碼：</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_30_minutes">
      <source>30 minutes</source>
      <translation variants="no">30分鐘</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_new_lock_code">
      <source>New lock code</source>
      <translation variants="no">輸入新鎖定密碼：</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_lock_code_created">
      <source>Lock code created</source>
      <translation variants="no">鎖定密碼已建立</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_60_minutes">
      <source>60 minutes</source>
      <translation variants="no">60分鐘</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_remote_on">
      <source>On</source>
      <translation variants="no">開</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_device_lock">
      <source>Device lock</source>
      <translation variants="yes">
        <lengthvariant priority="1">裝置鎖</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_devicelocking_dpopinfo_wait_ln_minutes">
      <source>Wait %Ln minutes</source>
      <translation>
        <numerusform plurality="a">等待%Ln分鐘。</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_codes_do_not_match">
      <source>Codes do not match</source>
      <translation variants="no">密碼不符</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_device_locking">
      <source>Device locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">裝置鎖定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_subhead_device_locking">
      <source>Device Locking</source>
      <translation variants="no">裝置鎖定</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_automatic_locking">
      <source>Automatic locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動鎖定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_5_minutes">
      <source>5 minutes</source>
      <translation variants="no">5分鐘</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_the_locking_message_and_the">
      <source>The locking message and the lock code should not be equal</source>
      <translation variants="no">鎖定訊息與鎖定密碼必須不同</translation>
    </message>
  </context>
</TS>