<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_list_dedicated_access_point">
      <source>Dedicated access point</source>
      <translation variants="yes">
        <lengthvariant priority="1">专用接入点</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_title_access_point">
      <source>Access point</source>
      <translation variants="no">接入点</translation>
    </message>
    <message numerus="no" id="txt_occ_title_network_connection">
      <source>Network connection</source>
      <translation variants="no">网络连接</translation>
    </message>
  </context>
</TS>