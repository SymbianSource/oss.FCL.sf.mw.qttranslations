<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_widget_l_dblist_preview_of_recent_mail">
      <source>Preview of recent mail</source>
      <translation variants="no">vi #Preview of recent mail</translation>
    </message>
    <message numerus="no" id="txt_mail_widget_dblist_preview_of_recent_mail">
      <source>Preview of recent mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Preview of recent mail</lengthvariant>
      </translation>
    </message>
  </context>
</TS>