<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_qtwrtins_info_communication_logs">
      <source>Communication Logs</source>
      <translation variants="no">vi #Communication logs</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_contact">
      <source>Contact</source>
      <translation variants="no">vi #Contacts</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_allow_1_to_access">
      <source>Allow %1 to access:</source>
      <translation variants="no">vi #Allow %[99]1 to access:</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_sensor">
      <source>Sensor</source>
      <translation variants="no">vi #Sensors</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_sysinfo">
      <source>Sysinfo</source>
      <translation variants="no">vi #System info</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_calendar">
      <source>Calendar</source>
      <translation variants="no">vi #Calendar</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_videoplayer">
      <source>VideoPlayer</source>
      <translation variants="no">vi #Video player</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_messaging">
      <source>Messaging</source>
      <translation variants="no">vi #Messaging</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_replace_existing_widget_1">
      <source>Replace existing widget %1?</source>
      <translation variants="no">vi #Replace existing widget?
%1</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_audioplayer">
      <source>AudioPlayer</source>
      <translation variants="no">vi #Music player</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_signature_invaliddo_you_still_w">
      <source>Signature invalid.Do you still want to install?</source>
      <translation variants="no">vi #Invalid signature. Install anyway?</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_unknown_errordo_you_still_want">
      <source>Unknown error.Do you still want to install?</source>
      <translation variants="no">vi #Unknown error. Continue?</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_landmark">
      <source>Landmark</source>
      <translation variants="no">vi #Places</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_camera">
      <source>Camera</source>
      <translation variants="no">vi #Camera</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_filesystem">
      <source>Filesystem</source>
      <translation variants="no">vi #File system</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_telephony">
      <source>Telephony</source>
      <translation variants="no">vi #Telephony</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_uninstall_successful">
      <source>Uninstall successful</source>
      <translation variants="no">vi #Installation removed succesfully</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_button_allow">
      <source>Allow</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Allow</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_location">
      <source>Location</source>
      <translation variants="no">vi #Position data</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_media">
      <source>Media</source>
      <translation variants="no">vi ##Media</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_installation_failed">
      <source>Installation failed</source>
      <translation variants="no">vi #Installation failed</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_title_security_warning">
      <source>Security Warning</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Security warnings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_uninstall_failed">
      <source>Uninstall failed</source>
      <translation variants="no">vi #Installation removal failed</translation>
    </message>
  </context>
</TS>