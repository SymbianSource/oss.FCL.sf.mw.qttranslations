<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headse">
      <source>Headset</source>
      <translation variants="no">话务式耳机</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">电视画面纵横比</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="no">聋哑人通讯器</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">附件类型</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="yes">
        <lengthvariant priority="1">聋哑人通讯器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="yes">
        <lengthvariant priority="1">话务式耳机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="no">4:3</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">附件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">附件设置</lengthvariant>
        <lengthvariant priority="2">zh #Accessory sett.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="no">16:9</translation>
    </message>
  </context>
</TS>