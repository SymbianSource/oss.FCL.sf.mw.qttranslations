<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_title_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Wireless LAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_wlansniffer">
      <source>Wireless LAN</source>
      <translation variants="no">zh_tw ##Wireless LAN</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_switch_wlan_on">
      <source>Switch WLAN on</source>
      <translation variants="no">zh_tw ##Switch WLAN on</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_switch_wlan_off">
      <source>Switch WLAN off</source>
      <translation variants="no">zh_tw ##Switch WLAN off</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_connecting_to_1">
      <source>Connecting to '%1'</source>
      <translation variants="no">zh_tw ##Connecting to '%1'</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_not_connected">
      <source>Not connected</source>
      <translation variants="no">zh_tw ##Not connected</translation>
    </message>
    <message numerus="no" id="txt_occ_info_activate_wlan_in_airplane_mode">
      <source>Allow WLAN connections during this offline session?</source>
      <translation variants="no">zh_tw #Allow WLAN connections during this offline session?</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_wlan_is_switched_off">
      <source>WLAN is switched off</source>
      <translation variants="no">zh_tw ##WLAN is switched off</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Wireless LAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_opt_add_new_wlan">
      <source>Add new WLAN</source>
      <translation variants="no">zh_tw ##Add new WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_connected_to_1">
      <source>Connected to '%1'</source>
      <translation variants="no">zh_tw ##Connected to '%1'</translation>
    </message>
  </context>
</TS>