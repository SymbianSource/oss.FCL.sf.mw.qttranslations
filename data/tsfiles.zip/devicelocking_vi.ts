<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_devicelocking_formlabel_remote_locking">
      <source>Remote locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khóa từ xa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_locking_message">
      <source>Locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tin nhắn khóa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_when_keys_screen">
      <source>When keys &amp; screen locked</source>
      <translation variants="no">Khi phím và màn hình bị khóa</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_retype_new_lock_code">
      <source>Retype new lock code</source>
      <translation variants="no">Xác minh mã bảo vệ mới:</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_messages_do_not_match">
      <source>Messages do not match</source>
      <translation variants="no">Tin nhắn không khớp</translation>
    </message>
    <message numerus="no" id="txt_remotelocking_button_sim_changed_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpopinfo_try_again">
      <source>Try again</source>
      <translation variants="no">Thử lại.</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">Chỉ cuộc gọi khẩn cấp</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_locking_message_created">
      <source>Locking message created</source>
      <translation variants="no">Đã tạo tin nhắn khóa</translation>
    </message>
    <message numerus="no" id="txt_device_dialog_retype_locking_message">
      <source>Retype locking message</source>
      <translation variants="no">Xác minh tin nhắn khóa mới:</translation>
    </message>
    <message numerus="no" id="txt_device_dialog_new_locking_message">
      <source>New locking message</source>
      <translation variants="no">Nhập tin nhắn khóa mới:</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_lock_code_is_blocked">
      <source>Lock code is blocked</source>
      <translation variants="no">Mã bảo vệ bị chặn.</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_sim_changed_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_subhead_remote_locking">
      <source>Remote locking</source>
      <translation variants="no">Khóa từ xa</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_wrong_lock_code">
      <source>Wrong lock code</source>
      <translation variants="no">Mã bảo vệ sai.</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_lock_code">
      <source>Lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mã bảo vệ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_lock_when_sim_changed">
      <source>Lock when SIM changed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khóa khi thay đổi thẻ SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_remote_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_lock_code">
      <source>Lock code</source>
      <translation variants="no">Nhập mã bảo vệ hiện tại:</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_30_minutes">
      <source>30 minutes</source>
      <translation variants="no">30 phút</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_new_lock_code">
      <source>New lock code</source>
      <translation variants="no">Nhập mã bảo vệ mới:</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_lock_code_created">
      <source>Lock code created</source>
      <translation variants="no">Đã tạo mã bảo vệ</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_60_minutes">
      <source>60 minutes</source>
      <translation variants="no">60 phút</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_remote_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_device_lock">
      <source>Device lock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khóa thiết bị</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_devicelocking_dpopinfo_wait_ln_minutes">
      <source>Wait %Ln minutes</source>
      <translation>
        <numerusform plurality="a">Chờ %Ln phút.</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_codes_do_not_match">
      <source>Codes do not match</source>
      <translation variants="no">Các mã không khớp</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_device_locking">
      <source>Device locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khóa thiết bị</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_subhead_device_locking">
      <source>Device Locking</source>
      <translation variants="no">Khóa thiết bị</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_automatic_locking">
      <source>Automatic locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khóa tự động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_5_minutes">
      <source>5 minutes</source>
      <translation variants="no">5 phút</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_the_locking_message_and_the">
      <source>The locking message and the lock code should not be equal</source>
      <translation variants="no">Tin nhắn khóa và mã bảo vệ phải khác nhau</translation>
    </message>
  </context>
</TS>