<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_ussd_button_next">
      <source>Next</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Next</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">zh #Not allowed</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_offline_not_possible">
      <source>Offline not possible</source>
      <translation variants="no">zh #Offline not possible</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_service_commands">
      <source>Service commands</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Service commands</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_done">
      <source>Done</source>
      <translation variants="no">zh #Done</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_no_service">
      <source>No service</source>
      <translation variants="no">zh #No service</translation>
    </message>
    <message numerus="no" id="txt_ussd_info_there_are_still_unread_notifications">
      <source>There are still unread notifications.Exit anyway?</source>
      <translation variants="no">zh #There are still unread notifications.Exit anyway?</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_exit">
      <source>Exit </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Exit </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_not_completed">
      <source>Request not completed</source>
      <translation variants="no">zh #Request not completed</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_message">
      <source>Message:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Message:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_not_done">
      <source>Not done</source>
      <translation variants="no">zh #Not done</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_completed">
      <source>Request completed</source>
      <translation variants="no">zh #Request completed</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_unconfirmed">
      <source>Unconfirmed</source>
      <translation variants="no">zh #Unconfirmed</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_not_confirmed">
      <source>Request not confirmed</source>
      <translation variants="no">zh #Request not confirmed</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_unable_to_use_network_phone_is">
      <source>Unable to use network. Phone is currently in offline mode.</source>
      <translation variants="no">zh #Unable to use network. Phone is currently in offline mode.</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_reply">
      <source>Reply:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Reply:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_sending">
      <source>Sending</source>
      <translation variants="no">zh #Sending</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_result_unknown">
      <source>Result unknown</source>
      <translation variants="no">zh #Result unknown</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_reply">
      <source>Reply </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Reply </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_service_commands">
      <source>Service commands</source>
      <translation variants="no">zh #Service commands</translation>
    </message>
  </context>
</TS>