<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_ussd_info_there_are_still_unread_notifications">
      <source>There are still unread notifications.Exit anyway?</source>
      <translation variants="no">尚有未读信息。仍然退出？</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_exit">
      <source>Exit </source>
      <translation variants="yes">
        <lengthvariant priority="1">退出</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_not_completed">
      <source>Request not completed</source>
      <translation variants="no">请求未完成</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_unable_to_use_network_phone_is">
      <source>Unable to use network. Phone is currently in offline mode.</source>
      <translation variants="no">在离线模式下无法使用网络</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">不允许</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_not_confirmed">
      <source>Request not confirmed</source>
      <translation variants="no">请求未确认</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_message">
      <source>Message:</source>
      <translation variants="yes">
        <lengthvariant priority="1">已收信息：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_no_service">
      <source>No service</source>
      <translation variants="no">无服务</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_service_commands">
      <source>Service commands</source>
      <translation variants="yes">
        <lengthvariant priority="1">服务命令</lengthvariant>
        <lengthvariant priority="2">zh #Service comms.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_done">
      <source>Done</source>
      <translation variants="no">完成</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_next">
      <source>Next</source>
      <translation variants="yes">
        <lengthvariant priority="1">下一条</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_button_reply">
      <source>Reply </source>
      <translation variants="yes">
        <lengthvariant priority="1">回复</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_completed">
      <source>Request completed</source>
      <translation variants="no">请求已完成</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_unconfirmed">
      <source>Unconfirmed</source>
      <translation variants="no">zh ##Unconfirmed</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_offline_not_possible">
      <source>Offline not possible</source>
      <translation variants="no">zh ##Offline not possible</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_sending">
      <source>Sending</source>
      <translation variants="no">正在发送服务命令</translation>
    </message>
    <message numerus="no" id="txt_long_caption_service_commands">
      <source>Service commands</source>
      <translation variants="no">服务命令</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_reply">
      <source>Reply:</source>
      <translation variants="yes">
        <lengthvariant priority="1">回复：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_not_done">
      <source>Not done</source>
      <translation variants="no">未完成</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_result_unknown">
      <source>Result unknown</source>
      <translation variants="no">未知回应</translation>
    </message>
  </context>
</TS>