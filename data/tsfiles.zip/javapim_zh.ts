<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_pimtodo_formlabel_synchronization">
      <source>Synchronisation</source>
      <translation variants="no">同步</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_pobox">
      <source>P.O. Box</source>
      <translation variants="no">邮政信箱</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">上次修改时间</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_borthday">
      <source>Birthday</source>
      <translation variants="no">生日</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">职位</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_default">
      <source>Default</source>
      <translation variants="no">预设</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_date">
      <source>Date</source>
      <translation variants="no">日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">主题</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_uid">
      <source>UID</source>
      <translation variants="no">UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_company">
      <source>Company</source>
      <translation variants="no">公司</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">姓</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_location">
      <source>Location</source>
      <translation variants="no">位置</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">上次修改时间</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_assistant_name">
      <source>Assistant's name</source>
      <translation variants="no">助理姓名</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_picture">
      <source>Picture</source>
      <translation variants="no">图片</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_video_number">
      <source>Video number</source>
      <translation variants="no">视频电话</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_completed">
      <source>Completed</source>
      <translation variants="no">完成</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">名</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_car_phone">
      <source>Car phone</source>
      <translation variants="no">车载电话</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_department">
      <source>Department</source>
      <translation variants="no">部门</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">纪念日</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_pager">
      <source>Pager</source>
      <translation variants="no">寻呼机</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_priority">
      <source>Priority</source>
      <translation variants="no">优先级</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_synchronization">
      <source>Synchronisation</source>
      <translation variants="no">同步</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_telephone">
      <source>Telephone</source>
      <translation variants="no">电话</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">分机</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">截止日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_mobile">
      <source>Mobile</source>
      <translation variants="no">手机</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_wv_user_id">
      <source>WV User ID</source>
      <translation variants="no">WV 用户 ID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_postalcode">
      <source>Postal code</source>
      <translation variants="no">邮政编码</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_end_date">
      <source>End date</source>
      <translation variants="no">结束日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_end_time_and_date">
      <source>End time and date</source>
      <translation variants="no">结束时间和日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_state">
      <source>State</source>
      <translation variants="no">省/市/区</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_fax">
      <source>Fax</source>
      <translation variants="no">传真</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">称谓</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_appointments">
      <source>Appointments</source>
      <translation variants="yes">
        <lengthvariant priority="1">会议</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_occasion">
      <source>Occasion</source>
      <translation variants="no">内容</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_formatted_name">
      <source>Name</source>
      <translation variants="no">姓名</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_start_time_and_date">
      <source>Start time and date</source>
      <translation variants="no">起始时间和日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_suffix">
      <source>Suffix</source>
      <translation variants="no">头衔</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_street">
      <source>Street</source>
      <translation variants="no">街道</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_name">
      <source>Name</source>
      <translation variants="no">姓名</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">配偶</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_anniversaries">
      <source>Anniversaries</source>
      <translation variants="yes">
        <lengthvariant priority="1">纪念日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_address">
      <source>Address</source>
      <translation variants="no">地址</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_other">
      <source>Other</source>
      <translation variants="no">其他</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_uid">
      <source>UID</source>
      <translation variants="no">UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_city">
      <source>City</source>
      <translation variants="no">城市</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_description">
      <source>Description</source>
      <translation variants="no">说明</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_assistant_phone">
      <source>Assistant's phone</source>
      <translation variants="no">助理号码</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_note">
      <source>Note</source>
      <translation variants="no">备忘</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_sms">
      <source>SMS</source>
      <translation variants="no">短信息</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_synchronisation">
      <source>Synchronisation</source>
      <translation variants="no">同步</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_uid">
      <source>UID</source>
      <translation variants="no">UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_children">
      <source>Children</source>
      <translation variants="no">儿童</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">中间名</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_completion_date">
      <source>Completion date</source>
      <translation variants="no">完成日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_description">
      <source>Description</source>
      <translation variants="no">说明</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">主题</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">闹铃</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">上次修改时间</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_start_date">
      <source>Start date</source>
      <translation variants="no">开始日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_country">
      <source>Country</source>
      <translation variants="no">国家/地区</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_url">
      <source>URL address</source>
      <translation variants="no">网址</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_title_to_do_notes">
      <source>To-do notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">待办事项</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_tel_internet">
      <source>Tel. Internet</source>
      <translation variants="no">互联网电话</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">铃声</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_nickname">
      <source>Nickname</source>
      <translation variants="no">昵称</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_email">
      <source>E-Mail</source>
      <translation variants="no">电子邮件地址</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_dtmf">
      <source>DTMF</source>
      <translation variants="no">双音多频</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_title_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">名片夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_push_to_talk">
      <source>Push to talk</source>
      <translation variants="no">按键通话</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">闹铃</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_share_view">
      <source>Share view</source>
      <translation variants="no">共享视频</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_business">
      <source>Business</source>
      <translation variants="no">单位</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_home">
      <source>Home</source>
      <translation variants="no">家庭</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_first_name_reading">
      <source>First name reading</source>
      <translation variants="no">名字读取</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_last_name_reading">
      <source>Last name reading</source>
      <translation variants="no">姓氏读取</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_momos">
      <source>Memos</source>
      <translation variants="yes">
        <lengthvariant priority="1">记事本</lengthvariant>
      </translation>
    </message>
  </context>
</TS>