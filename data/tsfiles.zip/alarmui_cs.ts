<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="cs">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Snooze</source>
      <translation variants="yes">
        <lengthvariant priority="1">Odložit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Clock alarm</source>
      <translation variants="no">Budík</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snoozed_for_ln_minute">
      <source>Alarm snoozed for %Ln minutes</source>
      <translation>
        <numerusform plurality="a">Buzení odloženo o %Ln minutu</numerusform>
        <numerusform plurality="b">Buzení odloženo o %Ln minuty</numerusform>
        <numerusform plurality="c">Buzení odloženo o %Ln minut</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ticho</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Switch phone on ?</source>
      <translation variants="no">Zapnout přístroj?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Calendar alarm</source>
      <translation variants="no">Upozornění v kalendáři</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_stop">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">Stop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>To-do note</source>
      <translation variants="no">Upozornění na úkol</translation>
    </message>
  </context>
</TS>