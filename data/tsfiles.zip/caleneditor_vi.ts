<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_subhead_new_event">
      <source>New event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mục lịch mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Yearly</source>
      <translation variants="no">Hàng năm</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Repeat</source>
      <translation variants="no">Lặp lại</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">Xóa cuộc họp?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_meeting_saved">
      <source>New meeting saved</source>
      <translation variants="no">Đã lưu lại cuộc họp mới</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Chỉ sự kiện này</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Tất cả sự kiện</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_meeting">
      <source>New meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc họp mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_at_the_start">
      <source>At the start</source>
      <translation variants="no">Lúc khởi động</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_5_minutes_befor">
      <source>5 minutes before</source>
      <translation variants="no">Trước 5 phút</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_anniv_default_date">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">Lặp lại cho đến</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">Thêm mô tả</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_workdays">
      <source>Workdays</source>
      <translation variants="no">Ngày làm việc</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Delete entries ?</source>
      <translation variants="no">Xóa các mục lịch?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_anniversary_saved">
      <source>New anniversary saved</source>
      <translation variants="no">Đã lưu lại ngày kỷ niệm mới</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_anniversary">
      <source>Anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày kỷ niệm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_date">
      <source>Date</source>
      <translation variants="no">Ngày</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_fortnightly">
      <source>Fortnightly</source>
      <translation variants="no">Hai tuần một lần</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Delete</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Monthly</source>
      <translation variants="no">Hàng tháng</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Start date</source>
      <translation variants="no">Ngày bắt đầu</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Daily</source>
      <translation variants="no">Hàng ngày</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_time">
      <source>%1</source>
      <translation variants="no">vi ##%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="no">Ngày phát âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">Loại bỏ thay đổi</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Xóa mục lịch lặp lại:</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Delete anniversary?</source>
      <translation variants="no">Xóa ngày kỷ niệm?</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Location</source>
      <translation variants="no">Vị trí</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_meeting_updated">
      <source>Meeting updated</source>
      <translation variants="no">Đã cập nhật cuộc họp</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_anniversary">
      <source>New anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày kỷ niệm mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_day_before">
      <source>1 day before</source>
      <translation variants="no">Trước 1 ngày</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_time">
      <source>Reminder time</source>
      <translation variants="no">Thời gian phát âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_2_days_before">
      <source>2 days before</source>
      <translation variants="no">Trước 2 ngày</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_15_minutes_befo">
      <source>15 minutes before</source>
      <translation variants="no">Trước 15 phút</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">Lặp lại cho đến</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>End time</source>
      <translation variants="no">Thời gian kết thúc</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_date">
      <source>%2</source>
      <translation variants="no">vi ##%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="no">Ngày giờ phát âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_on_alarm">
      <source>Alarm</source>
      <translation variants="no">Âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_start_time">
      <source>Start time</source>
      <translation variants="no">Thời gian bắt đầu</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_on_event_day">
      <source>On event day</source>
      <translation variants="no">Vào ngày sự kiện</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú công việc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_reminder_time">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">Xóa mô tả</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc họp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>End date</source>
      <translation variants="no">Ngày kết thúc</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_occasion">
      <source>Occasion</source>
      <translation variants="no">Dịp</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Weekly</source>
      <translation variants="no">Hàng tuần</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Cancel</source>
      <translation variants="no">Hủy</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_hour_before">
      <source>1 hour before</source>
      <translation variants="no">Trước 1 tiếng</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_30_minutes_befo">
      <source>30 minutes before</source>
      <translation variants="no">Trước 30 phút</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">Chủ đề</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Start time</source>
      <translation variants="no">Thời gian bắt đầu</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Only once</source>
      <translation variants="no">Không lặp lại</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_description">
      <source>Description</source>
      <translation variants="no">Mô tả</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>All day event</source>
      <translation variants="no">Mục lịch cả ngày</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_end_time">
      <source>End time</source>
      <translation variants="no">Thời gian kết thúc</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="no">Thời gian phát âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Reminder</source>
      <translation variants="no">Âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entry">
      <source>Delete entry?</source>
      <translation variants="no">Xóa mục lịch?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_anniversary_updated">
      <source>Anniversary updated</source>
      <translation variants="no">Đã cập nhật ngày kỷ niệm</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Chỉnh sửa:</translation>
    </message>
  </context>
</TS>