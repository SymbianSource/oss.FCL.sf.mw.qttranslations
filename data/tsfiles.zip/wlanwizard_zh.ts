<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_list_8021x_1">
      <source>802.1X</source>
      <translation variants="no">802.1X</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_val_infrastructure_public">
      <source>Public</source>
      <translation variants="no">公共</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_destination">
      <source>Destination</source>
      <translation variants="no">承载方式</translation>
    </message>
    <message numerus="no" id="txt_occ_title_wlan_setup_wizard_summary">
      <source>WLAN wizard, summary</source>
      <translation variants="no">WLAN向导，摘要</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_key_is_of_incorrect_length_please">
      <source>Key is of incorrect length. Please check the key.</source>
      <translation variants="no">密钥长度错误。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_authentication_unsuccessful">
      <source>Authentication unsuccessful</source>
      <translation variants="no">鉴定失败</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_mode">
      <source>Network mode</source>
      <translation variants="no">网络模式</translation>
    </message>
    <message numerus="no" id="txt_occ_title_wlan_setup_wizard_step_l1">
      <source>WLAN wizard, step %L1</source>
      <translation variants="no">WLAN向导，第%L1步</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_name">
      <source>Network name</source>
      <translation variants="no">网络名称</translation>
    </message>
    <message numerus="no" id="txt_occ_list_open">
      <source>Open</source>
      <translation variants="no">打开</translation>
    </message>
    <message numerus="no" id="txt_occ_list_adhoc_1">
      <source>Ad-hoc</source>
      <translation variants="no">特殊</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_checking_connection_to_1">
      <source>Checking connection to '%1'</source>
      <translation variants="no">正在检查与"%[48]1"的连接</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_connection_failed">
      <source>Connection failed</source>
      <translation variants="no">连接失败</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_insert_the_name_of_the_new_wlan_net">
      <source>Insert the name of the new WLAN network:</source>
      <translation variants="no">新WLAN网络的名称：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_preshared_key_too_short_at_least">
      <source>Key is too short. At least 8 characters must be entered. Please check the key.</source>
      <translation variants="no">至少8个字符。</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_destination_val_internet">
      <source>Internet</source>
      <translation variants="no">互联网</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_mode_val_adhoc">
      <source>Ad-hoc</source>
      <translation variants="no">特殊</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_wep">
      <source>WEP</source>
      <translation variants="no">WEP</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_searching">
      <source>Scanning settings for '%1'</source>
      <translation variants="no">正在搜索"%[49]1"的设置</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_8021x">
      <source>802.1X</source>
      <translation variants="no">802.1X</translation>
    </message>
    <message numerus="no" id="txt_occ_list_wpa_with_eap">
      <source>WPA with EAP</source>
      <translation variants="no">带EAP的WPA</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_wpawpa2psk">
      <source>WPA with password</source>
      <translation variants="no">带密码WPA</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode">
      <source>Security mode</source>
      <translation variants="no">安全模式</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_destination_val_uncategorized">
      <source>Uncategorized</source>
      <translation variants="no">未分类</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_mode_val_infrastructure_hi">
      <source>Hidden</source>
      <translation variants="no">隐性</translation>
    </message>
    <message numerus="no" id="txt_occ_list_wep_1">
      <source>WEP</source>
      <translation variants="no">WEP</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_illegal_characters_in_key_please_c">
      <source>Illegal characters in key. Please check the key.</source>
      <translation variants="no">密钥中包含无效字符。</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_open">
      <source>Open</source>
      <translation variants="no">打开</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_select_network_mode_and_status">
      <source>Select network mode (and status):</source>
      <translation variants="no">选择网络模式/状态：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_select_network_security_mode">
      <source>Select network security mode:</source>
      <translation variants="no">选择网络安全模式：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_enter_key_for_1">
      <source>Enter key for '%1':</source>
      <translation variants="no">输入"%[50]1"的密钥：</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_mode_val_infrastructure_pu">
      <source>Public</source>
      <translation variants="no">公共</translation>
    </message>
    <message numerus="no" id="txt_occ_list_wpa_with_password">
      <source>WPA with password</source>
      <translation variants="no">带密码WPA</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_wpawpa2_with_eap">
      <source>WPA with EAP</source>
      <translation variants="no">带EAP的WPA</translation>
    </message>
    <message numerus="no" id="txt_occ_list_infrastructure_hidden">
      <source>Hidden</source>
      <translation variants="no">隐性</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_incorrect_wpa_preshared_key_pleas">
      <source>Incorrect WPA pre-shared key. Please check the key.</source>
      <translation variants="no">WPA预共享密钥不正确。检查密钥并重试。</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_wpa2_with_passwor">
      <source>WPA2 with password</source>
      <translation variants="no">带密码WPA2</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_unable_to_save_settings_please_ret">
      <source>Unable to save settings, please retry</source>
      <translation variants="no">无法储存设置。重试。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_incorrect_wep_key_please_check_the">
      <source>Incorrect WEP key. Please check the key.</source>
      <translation variants="no">WEP密钥不正确。检查密钥并重试。</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_wpa2_with_eap">
      <source>WPA2 with EAP</source>
      <translation variants="no">带EAP的WPA2</translation>
    </message>
    <message numerus="no" id="txt_occ_list_wifi_protected_setup">
      <source>Wi-Fi Protected Setup™</source>
      <translation variants="no">Wi-Fi Protected Setup</translation>
    </message>
  </context>
</TS>