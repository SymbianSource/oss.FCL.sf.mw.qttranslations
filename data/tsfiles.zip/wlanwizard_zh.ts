<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dblist_network_mode">
      <source>Network mode</source>
      <translation variants="no">网络模式</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_checking_connection_to_1">
      <source>Checking connection to '%1'</source>
      <translation variants="no">zh #Checking connection to '%[99]1'</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_preshared_key_too_short_at_least">
      <source>Key is too short. At least 8 characters must be entered. Please check the key.</source>
      <translation variants="no">至少8个字符。</translation>
    </message>
    <message numerus="no" id="txt_occ_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_authentication_unsuccessful">
      <source>Authentication unsuccessful</source>
      <translation variants="no">鉴定失败</translation>
    </message>
    <message numerus="no" id="txt_occ_title_wlan_setup_wizard_summary">
      <source>WLAN wizard, summary</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN向导，摘要</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_button_next">
      <source>Next</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Next</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_open">
      <source>Open</source>
      <translation variants="yes">
        <lengthvariant priority="1">打开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_mode_val_infrastructure_pu">
      <source>Public</source>
      <translation variants="yes">
        <lengthvariant priority="1">公共</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_destination_val_internet">
      <source>Internet</source>
      <translation variants="yes">
        <lengthvariant priority="1">互联网</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_wep">
      <source>WEP</source>
      <translation variants="yes">
        <lengthvariant priority="1">WEP</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_mode_val_adhoc">
      <source>Ad-hoc</source>
      <translation variants="yes">
        <lengthvariant priority="1">特殊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_destination">
      <source>Destination</source>
      <translation variants="no">目的地</translation>
    </message>
    <message numerus="no" id="txt_occ_title_wlan_setup_wizard_step_l1">
      <source>WLAN wizard, step %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN向导，第%L1步</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_connection_failed">
      <source>Connection failed</source>
      <translation variants="no">连接失败</translation>
    </message>
    <message numerus="no" id="txt_occ_button_finish">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Finish</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_enter_key_for_1">
      <source>Enter key for '%1':</source>
      <translation variants="no">zh #Enter key for '%[99]1'</translation>
    </message>
    <message numerus="no" id="txt_occ_button_previous">
      <source>Previous</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Previous</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_wpa2_with_passwor">
      <source>WPA2 with password</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##WPA2 with password</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_mode_val_infrastructure_hi">
      <source>Hidden</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Hidden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_select_network_mode_and_status">
      <source>Select network mode (and status):</source>
      <translation variants="no">zh ##Select network mode (and status):</translation>
    </message>
    <message numerus="no" id="txt_occ_list_wpa_with_password">
      <source>WPA with password</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##WPA with password</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_wpawpa2_with_eap">
      <source>WPA with EAP</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##WPA with EAP</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_destination_val_uncategorized">
      <source>Uncategorized</source>
      <translation variants="yes">
        <lengthvariant priority="1">未分类</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_8021x">
      <source>802.1X</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##802.1X</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_list_wpa_with_eap">
      <source>WPA with EAP</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##WPA with EAP</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_list_infrastructure_hidden">
      <source>Hidden</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Hidden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_list_open">
      <source>Open</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Open</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_wpawpa2psk">
      <source>WPA with password</source>
      <translation variants="yes">
        <lengthvariant priority="1">带密码WPA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_list_wep_1">
      <source>WEP</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##WEP</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_select_network_security_mode">
      <source>Select network security mode:</source>
      <translation variants="no">zh ##Select network security mode:</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode_val_wpa2_with_eap">
      <source>WPA2 with EAP</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##WPA2 with EAP</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_insert_the_name_of_the_new_wlan_net">
      <source>Insert the name of the new WLAN network:</source>
      <translation variants="no">zh ##Insert the name of the new WLAN network:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_key_is_of_incorrect_length_please">
      <source>Key is of incorrect length. Please check the key.</source>
      <translation variants="no">密钥长度错误。</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_val_infrastructure_public">
      <source>Public</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Public</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_name">
      <source>Network name</source>
      <translation variants="no">网络名称</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_illegal_characters_in_key_please_c">
      <source>Illegal characters in key. Please check the key.</source>
      <translation variants="no">密钥中包含无效字符。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_searching">
      <source>Scanning settings for '%1'</source>
      <translation variants="no">zh ##Scanning settings for '%1'</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_security_mode">
      <source>Security mode</source>
      <translation variants="no">安全模式</translation>
    </message>
    <message numerus="no" id="txt_occ_list_8021x_1">
      <source>802.1X</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##802.1X</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_list_adhoc_1">
      <source>Ad-hoc</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Ad-hoc</lengthvariant>
      </translation>
    </message>
  </context>
</TS>