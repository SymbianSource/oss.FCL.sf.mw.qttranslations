<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailwdgt_dblist_mail">
      <source>Mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل</lengthvariant>
      </translation>
    </message>
  </context>
</TS>