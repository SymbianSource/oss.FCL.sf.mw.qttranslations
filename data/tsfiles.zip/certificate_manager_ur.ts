<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_certificate_manager_dialog_verify_keystore_pin">
      <source>Verify Keystore PIN:</source>
      <translation variants="no">کوڈ. کرنے کے PIN تصدیق:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_trust_settings">
      <source>Trust settings</source>
      <translation variants="no">معتبر ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_setlabel_certificates">
      <source>Certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">اسناد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_authority_certific">
      <source>Authority certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">تصدیقی اسناد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_info_move">
      <source>Move.......</source>
      <translation variants="yes">
        <lengthvariant priority="1">سند منتقل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_device_certificate">
      <source>Device certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلے کی اسناد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dpopinfo_keystore_pin_does">
      <source>Keystore PIN does not match</source>
      <translation variants="no">کوڈ اسٹور کرنے کے PIN سے مطابقت نہیں</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_unable_to_use_priva">
      <source>Unable to use private key. Set keystore PIN:</source>
      <translation variants="no">نجی کوڈ استعمال سے قاصر۔  کوڈ اسٹور کرنے کا PIN مرتب:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_enter_keystore_pin">
      <source>Enter keystore PIN:</source>
      <translation variants="no">کوڈ اس. کے لیے PIN داخل:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_trusted_site_certific">
      <source>Trusted site certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">معتبر مرکز کی اسناد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_personal_certifica">
      <source>Personal certificate</source>
      <translation variants="yes">
        <lengthvariant priority="1">ذاتی اسناد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_set">
      <source>Set</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوڈ اسٹور کرنے کا PIN مرتب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_keystore_pin">
      <source>Keystore PIN</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوڈ اسٹور کرنے کا PIN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_info_device_certificates_c">
      <source>Device certificates can be used without user confirmation. Use of device lock recommended. Proceed?</source>
      <translation variants="no">صارف کی توثیق کے بغیر آلے کی اسناد کا استعمال ممکن ہے۔ آلے کے قفل کے استعمال کی سفارش کی جاتی ہے۔ جاری رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_setlabel_advanced_security">
      <source>Advanced security</source>
      <translation variants="yes">
        <lengthvariant priority="1">برتر حفاظت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_authority_certificate">
      <source>Authority certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">تصدیقی اسناد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_move_to_device_certif">
      <source>Move to device certificates</source>
      <translation variants="no">آلہ کی سند پر منتقل</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_trusted_site_certi">
      <source>Trusted site certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">معتبر مرکز کی اسناد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_device_certificates">
      <source>Device certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلے کی اسناد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_personal_certificates">
      <source>Personal certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">ذاتی اسناد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_move_to_personal_cert">
      <source>Move to personal certificates</source>
      <translation variants="no">ذاتی اسناد پر منتقل</translation>
    </message>
  </context>
</TS>