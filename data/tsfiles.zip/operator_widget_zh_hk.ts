<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_operatorwidget_list_spn">
      <source>Service provider name</source>
      <translation variants="no">服務供應商名稱</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_info_select_one">
      <source>Select at least one item</source>
      <translation variants="no">選擇至少一個項目</translation>
    </message>
    <message numerus="no" id="txt_operator_widget_title_select_info">
      <source>Select info</source>
      <translation variants="no">選擇資料</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_list_cell_information">
      <source>Cell information</source>
      <translation variants="no">訊息廣播</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_dblist_val_operator_information">
      <source>Operator information on homescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Operator information on homescreen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_operator_widget">
      <source>Operator widget</source>
      <translation variants="no">zh_hk ##Operator widget</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_list_sat_idle_mode_text">
      <source>SAT idle mode text</source>
      <translation variants="no">SIM卡服務內容</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_list_show_homezone">
      <source>Show Homezone</source>
      <translation variants="no">zh_hk #Show Homezone</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_list_line_in_use">
      <source>Line in use</source>
      <translation variants="no">zh_hk #Line in use</translation>
    </message>
  </context>
</TS>