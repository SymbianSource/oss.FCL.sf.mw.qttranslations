<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_short_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">zh_hk #Control panel</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_2_minutes">
      <source>2 minutes</source>
      <translation variants="no">2分鐘</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_locked_after">
      <source>Keys &amp; screen locked after</source>
      <translation variants="no">在此之後鎖定按鍵和螢幕：</translation>
    </message>
    <message numerus="no" id="txt_cp_title_profile">
      <source>Profile</source>
      <translation variants="no">選擇操作模式</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_8">
      <source>Copyright (c) 1996-1998
Silicon Graphics Computer Systems, Inc.

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Silicon Graphics makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</source>
      <translation variants="no">Copyright (c) 1996-1998
Silicon Graphics Computer Systems, Inc.

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Silicon Graphics makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_software_version">
      <source>Software version</source>
      <translation variants="no">軟件版本</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_6">
      <source>Copyright (c) 2004, 2005 Apple Computer, Inc.
Copyright (c) 1997-2005 University of Cambridge
All rights reserved.
Copyright (c) 2005, Google Inc.
All rights reserved.
Copyright (c) 2006, Nokia Corporation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the University of Cambridge nor the name of Google
  Inc. nor the names of their contributors may be used to endorse or
  promote products derived from this software without specific prior
  written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Copyright (c) 2004, 2005 Apple Computer, Inc.
Copyright (c) 1997-2005 University of Cambridge
All rights reserved.
Copyright (c) 2005, Google Inc.
All rights reserved.
Copyright (c) 2006, Nokia Corporation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the University of Cambridge nor the name of Google
  Inc. nor the names of their contributors may be used to endorse or
  promote products derived from this software without specific prior
  written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_touch_screen_vibra">
      <source>Touch screen vibra</source>
      <translation variants="no">震動</translation>
    </message>
    <message numerus="no" id="txt_cp_info_product_release">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">重設設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_2">
      <source>This product includes API header files originally developed by Netscape Communications Corporation, modified by Nokia by changing certain variables for the  
purpose of porting the file to Symbian operating system on May 1st, 2004, and available in source code form under the Netscape Public License, v1.1 at  
http://www.forum.nokia.com/browserapi.</source>
      <translation variants="no">This product includes API header files originally developed by Netscape Communications Corporation, modified by Nokia by changing certain variables for the  
purpose of porting the file to Symbian operating system on May 1st, 2004, and available in source code form under the Netscape Public License, v1.1 at  
http://www.forum.nokia.com/browserapi.</translation>
    </message>
    <message numerus="no" id="txt_cp_title_setup">
      <source>Setup</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_cp_info_delete_all_data_and_restore_original_s">
      <source>Delete all data and restore original settings? Ejectable memory card data is not deleted.</source>
      <translation variants="no">是否刪除所有已恢復的資料和原廠設定？不會刪除可移除的記憶卡中的資料。</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_your_region">
      <source>Select your region:</source>
      <translation variants="no">選擇地區：</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_home_network">
      <source>Data usage in home network</source>
      <translation variants="no">主網絡中的數據使用</translation>
    </message>
    <message numerus="no" id="txt_cp_button_end">
      <source>End</source>
      <translation variants="no">結束</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_1_minute">
      <source>1 minute</source>
      <translation variants="no">1分鐘</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_wallpaper">
      <source>Wallpaper</source>
      <translation variants="yes">
        <lengthvariant priority="1">背景圖片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_notification_tones">
      <source>Notification tones</source>
      <translation variants="no">通知鈴聲</translation>
    </message>
    <message numerus="no" id="txt_cp_info_when_selected_clock_is_displayed_when">
      <source>When selected, clock is displayed when in idle.</source>
      <translation variants="no">當螢幕變成空白時顯示時鐘</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_manual">
      <source>Manual</source>
      <translation variants="yes">
        <lengthvariant priority="1">手動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_confirm">
      <source>Confirm</source>
      <translation variants="no">長期請求</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_message_tone">
      <source>Message tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">訊息提示聲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_restore_original_settings_no_data_wil">
      <source>Restore original settings? No data will be deleted.</source>
      <translation variants="no">是否恢復原始設定？不會刪除任何資料。</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_brightness">
      <source>Brightness</source>
      <translation variants="no">亮度</translation>
    </message>
    <message numerus="no" id="txt_cp_info_setup_is_not_completed_would_you_lik">
      <source>Setup is not completed. 
Would you like to complete it now?</source>
      <translation variants="no">裝置設定未完成。是否現在完成？</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_confirm">
      <source>Confirm</source>
      <translation variants="no">長期請求</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">流動網絡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_and_connections_must_be_d">
      <source>Active calls and connections must be disconnected before reset.</source>
      <translation variants="no">必須中斷所有目前通話和連接才能重設</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_not_connected">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">未連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_closing_connections">
      <source>Closing connections</source>
      <translation variants="no">正在關閉連接</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device">
      <source>Device</source>
      <translation variants="yes">
        <lengthvariant priority="1">手機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">次要書寫語言</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_9">
      <source>Copyright (c) 1983, 1995, 1996 Eric P. Allman
Copyright (c) 1988, 1993
 The Regents of the University of California.  All rights reserved.
Copyright (C) 2007 Nokia Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of the University nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.</source>
      <translation variants="no">Copyright (c) 1983, 1995, 1996 Eric P. Allman
Copyright (c) 1988, 1993
 The Regents of the University of California.  All rights reserved.
Copyright (C) 2007 Nokia Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of the University nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_product_release">
      <source>Product Release</source>
      <translation variants="no">產品發行版本</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_umts">
      <source>UMTS</source>
      <translation variants="no">3G</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset_val_reset_your_device">
      <source>Reset your device</source>
      <translation variants="yes">
        <lengthvariant priority="1">恢復原廠設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">語言和地區</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset_val_reset_device">
      <source>Reset device</source>
      <translation variants="yes">
        <lengthvariant priority="1">重設裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_screensaver">
      <source>Screensaver</source>
      <translation variants="no">時鐘螢幕保護</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_gsm">
      <source>GSM</source>
      <translation variants="no">GSM</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_select_tone_type">
      <source>Change tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇鈴聲類型</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">一般</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">會議</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_processing">
      <source>Processing…</source>
      <translation variants="no">處理中</translation>
    </message>
    <message numerus="no" id="txt_cp_title_end_encryption">
      <source>End encryption</source>
      <translation variants="no">結束加密</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset">
      <source>Device reset</source>
      <translation variants="no">裝置重設</translation>
    </message>
    <message numerus="no" id="txt_cp_info_all_data_will_be_deleted_and_factory_s">
      <source>All data will be deleted and factory settings will be restored. Ejectable memory card data is not deleted.</source>
      <translation variants="no">將會刪除所有已恢復的資料和原廠設定。不會刪除可移除的記憶卡中的資料。</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">佈景主題</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices_1">
      <source>This product includes certain open source software. The exact terms of the licenses, disclaimers, acknowledgements and notices are provided below. Nokia offers to provide you with the source code as defined in the applicable license. 

Please send an e-mail to sourcecode.request@nokia.com or a written request to:

Source Code Requests
Nokia Corporation
P.O.Box 407
FI-00045 Nokia Group
Finland

This offer is valid for a period of three (3) years from the date of the distribution of this product by Nokia.</source>
      <translation variants="no">This product includes certain open source software. The exact terms of the licenses, disclaimers, acknowledgements and notices are provided below. Nokia offers to provide you with the source code as defined in the applicable license. 

Please send an e-mail to sourcecode.request@nokia.com or a written request to:

Source Code Requests
Nokia Corporation
P.O.Box 407
FI-00045 Nokia Group
Finland

This offer is valid for a period of three (3) years from the date of the distribution of this product by Nokia.</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset_val_reset_settings">
      <source>Reset settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">重設設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_4">
      <source>Copyright (C) 2004, Apple Computer, Inc. and The Mozilla Foundation. 
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. Neither the names of Apple Computer, Inc. ("Apple") or The Mozilla
Foundation ("Mozilla") nor the names of their contributors may be used
to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY APPLE, MOZILLA AND THEIR CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE, MOZILLA OR
THEIR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Copyright (C) 2004, Apple Computer, Inc. and The Mozilla Foundation. 
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. Neither the names of Apple Computer, Inc. ("Apple") or The Mozilla
Foundation ("Mozilla") nor the names of their contributors may be used
to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY APPLE, MOZILLA AND THEIR CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE, MOZILLA OR
THEIR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_list_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">關於應用程式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">離線</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_rotate_the_display_content_automatical">
      <source>Rotate the display content automatically when you turn the device on horizontal or back to a vertical position.</source>
      <translation variants="no">當裝置方向更換時自動旋轉顯示內容</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_14">
      <source>Copyright (c) 1998 - 2008, Paul Johnston &amp; Contributors
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of the author nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Copyright (c) 1998 - 2008, Paul Johnston &amp; Contributors
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of the author nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">操作模式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_key_and_touchscreen_tones">
      <source>Key and touchscreen tones</source>
      <translation variants="no">按鍵音量</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自動</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_type">
      <source>Type</source>
      <translation variants="no">類型</translation>
    </message>
    <message numerus="no" id="txt_cp_button_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">進階設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_roaming">
      <source>Data usage when roaming</source>
      <translation variants="no">漫遊時的數據使用</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_15_seconds">
      <source>15 seconds</source>
      <translation variants="no">15秒</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_disabled">
      <source>Disabled</source>
      <translation variants="no">已關閉</translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices">
      <source>Open source software notices</source>
      <translation variants="no">開放資源軟件聲明</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset">
      <source>Settings reset</source>
      <translation variants="no">設定已重設</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">流動網絡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">鈴聲音量</translation>
    </message>
    <message numerus="no" id="txt_cp_list_edit_name">
      <source>Edit name</source>
      <translation variants="no">修改名稱</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自動</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_val_change_language">
      <source>Change language</source>
      <translation variants="yes">
        <lengthvariant priority="1">修改語言設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_7">
      <source>Copyright (c) 1994
Hewlett-Packard Company

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Hewlett-Packard Company makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</source>
      <translation variants="no">Copyright (c) 1994
Hewlett-Packard Company

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Hewlett-Packard Company makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</translation>
    </message>
    <message numerus="no" id="txt_cp_text_edit_device_will_be_restarted_to_chang">
      <source>Device will be restarted to change display language. Continue?</source>
      <translation variants="no">更換顯示語言將必須重新啟動裝置。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_cp_list_music">
      <source>Choose from music</source>
      <translation variants="yes">
        <lengthvariant priority="1">音樂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">按鍵和螢幕</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active_val_clock_alarm">
      <source>Clock alarm at %1</source>
      <translation variants="no">時鐘鬧鐘設定於%1</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇佈景主題</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device_model">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_1">
      <source>Java and all Java-based marks are trademarks or registered trademarks of Sun Microsystems, Inc.
JavaTM ME environment: MIDP 2.1, CLDC 1.1.</source>
      <translation variants="no">Java以及所有以Java為基礎的標誌都是Sun Microsystems, Inc.的商標或註冊商標。
JavaTM ME環境：MIDP 2.1、CLDC 1.1。</translation>
    </message>
    <message numerus="no" id="txt_cp_button_regional_settings">
      <source>Regional settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">地區設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">進階設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_45_seconds">
      <source>45 seconds</source>
      <translation variants="no">45秒</translation>
    </message>
    <message numerus="no" id="txt_cp_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">震動</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_tones_that_play_when_you_select">
      <source>Select tones that play when you select the profile named:</source>
      <translation variants="no">選擇當選擇此操作模式時要使用的鈴聲：</translation>
    </message>
    <message numerus="no" id="txt_cp_title_preview_1">
      <source>Preview: %1</source>
      <translation variants="no">預覽：%[13]1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_data_encryption_ongoing_enryption_mus">
      <source>Data encryption ongoing. Enryption must be ended before reset.  End data enrcyption?</source>
      <translation variants="no">正在進行資料加密。必須先結束加密才能進行重設。是否結束資料加密？</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_5">
      <source>The author of this software is David M. Gay.

Copyright (c) 1991, 2000, 2001 by Lucent Technologies.

Permission to use, copy, modify, and distribute this software for any
purpose without fee is hereby granted, provided that this entire notice
is included in all copies of any software which is or includes a copy
or modification of this software and in all copies of the supporting
documentation for such software.

THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY.  IN PARTICULAR, NEITHER THE AUTHOR NOR LUCENT MAKES ANY
REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.</source>
      <translation variants="no">The author of this software is David M. Gay.

Copyright (c) 1991, 2000, 2001 by Lucent Technologies.

Permission to use, copy, modify, and distribute this software for any
purpose without fee is hereby granted, provided that this entire notice
is included in all copies of any software which is or includes a copy
or modification of this software and in all copies of the supporting
documentation for such software.

THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY.  IN PARTICULAR, NEITHER THE AUTHOR NOR LUCENT MAKES ANY
REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.</translation>
    </message>
    <message numerus="no" id="txt_cp_list_tone">
      <source>Choose from tones</source>
      <translation variants="yes">
        <lengthvariant priority="1">鈴聲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">主要書寫語言</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_display_language">
      <source>Display language</source>
      <translation variants="no">顯示語言</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices">
      <source>3rd party notices</source>
      <translation variants="no">協力廠商聲明</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">重設設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_email_tone">
      <source>E-mail tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">電郵提示聲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_type">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">語言和地區</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">中斷連線</translation>
    </message>
    <message numerus="no" id="txt_cp_list_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">按鍵和螢幕</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_ringtone">
      <source>Ringtone</source>
      <translation variants="yes">
        <lengthvariant priority="1">鈴聲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">靜音</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_dual_mode">
      <source>Dual mode</source>
      <translation variants="no">雙網絡</translation>
    </message>
    <message numerus="no" id="txt_cp_terms_of_use">
      <source>Terms of Use</source>
      <translation variants="no">使用條款</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active">
      <source>Silent state active</source>
      <translation variants="no">無聲狀態已啟動</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_connectivity">
      <source>Connectivity</source>
      <translation variants="yes">
        <lengthvariant priority="1">連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">關於應用程式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_security">
      <source>Security</source>
      <translation variants="yes">
        <lengthvariant priority="1">安全性</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_original_settings_will_be_restored_no">
      <source>Original settings will be restored. No data will be deleted.</source>
      <translation variants="no">將會恢復原始設定。不會刪除任何資料。</translation>
    </message>
    <message numerus="no" id="txt_cp_info_1">
      <source>Nokia and Nokia Connecting People are trademarks or registered trademarks of Nokia Corporation.
 
Copyright 2011 Nokia. All rights reserved. 

This product is based on Symbian^4.

Other product and company names mentioned herein may be trademarks or tradenames of their respective owners. </source>
      <translation variants="no">諾基亞、Nokia和Nokia Connecting People是諾基亞公司的商標或註冊商標。
 
版權所有2011 Nokia。保留一切權利。

本產品係依據Symbian^4所開發製造。

本文件所提及之其他產品和公司名稱可能為其各自擁有者的商標或註冊名稱。</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_001">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_list_autorotate_display">
      <source>Auto-rotate display</source>
      <translation variants="no">自動旋轉顯示</translation>
    </message>
    <message numerus="no" id="txt_cp_title_edit_name">
      <source>Edit name</source>
      <translation variants="no">修改名稱</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_disabled">
      <source>Disabled</source>
      <translation variants="no">已關閉</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_software_vesion">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_in_offline_mode_all_wireless_communica">
      <source>In offline mode all wireless communication is turned off.</source>
      <translation variants="no">已關閉所有無線連接</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_10">
      <source>Copyright (c) 1995-2006 International Business Machines Corporation and others

All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, provided that the above copyright notice(s)
and this permission notice appear in all copies of the Software and that both the above
copyright notice(s) and this permission notice appear in supporting documentation.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 
Except as contained in this notice, the name of a copyright holder shall not be used in
advertising or otherwise to promote the sale, use or other dealings in this Software
without prior written authorization of the copyright holder.</source>
      <translation variants="no">Copyright (c) 1995-2006 International Business Machines Corporation and others

All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, provided that the above copyright notice(s)
and this permission notice appear in all copies of the Software and that both the above
copyright notice(s) and this permission notice appear in supporting documentation.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 
Except as contained in this notice, the name of a copyright holder shall not be used in
advertising or otherwise to promote the sale, use or other dealings in this Software
without prior written authorization of the copyright holder.</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_graphical_style_of_the_device">
      <source>Select graphical style of the device</source>
      <translation variants="no">zh_hk ##Select theme</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode">
      <source>Network mode</source>
      <translation variants="no">網絡模式</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_open_source_software_notices">
      <source>Open source software notices</source>
      <translation variants="yes">
        <lengthvariant priority="1">開放原始碼軟件通知</lengthvariant>
        <lengthvariant priority="2">zh_hk #Open-source softw. notices</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_13">
      <source>Open Dynamics Engine
Copyright (c) 2001-2004, Russell L. Smith.
All rights reserved.

Redistribution and use in source and binary forms, 
with or without modification, are permitted provided
that the following conditions are met:

Redistributions of source code must retain the above 
copyright notice, this list of conditions and the 
following disclaimer.

Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or 
other materials provided with the distribution.

Neither the names of ODE's copyright owner nor the 
names of its contributors may be used to endorse or 
promote products derived from this software without 
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS 
AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.</source>
      <translation variants="no">Open Dynamics Engine
Copyright (c) 2001-2004, Russell L. Smith.
All rights reserved.

Redistribution and use in source and binary forms, 
with or without modification, are permitted provided
that the following conditions are met:

Redistributions of source code must retain the above 
copyright notice, this list of conditions and the 
following disclaimer.

Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or 
other materials provided with the distribution.

Neither the names of ODE's copyright owner nor the 
names of its contributors may be used to endorse or 
promote products derived from this software without 
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS 
AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_volume">
      <source>Volume</source>
      <translation variants="yes">
        <lengthvariant priority="1">音量</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_3">
      <source>Copyright (C) 2005 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2007 Apple Inc.  All rights reserved.
Copyright (C) 2007 Nokia Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without

modification, are permitted provided that the following conditions
are met:

1.  Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer. 
2.  Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution. 
3.  Neither the name of Apple Computer, Inc. ("Apple") nor the names of
    its contributors may be used to endorse or promote products derived
    from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE AND ITS CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL APPLE OR ITS CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Copyright (C) 2005 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2007 Apple Inc.  All rights reserved.
Copyright (C) 2007 Nokia Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without

modification, are permitted provided that the following conditions
are met:

1.  Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer. 
2.  Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution. 
3.  Neither the name of Apple Computer, Inc. ("Apple") nor the names of
    its contributors may be used to endorse or promote products derived
    from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE AND ITS CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL APPLE OR ITS CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_3rd_party_notices">
      <source>3rd party notices</source>
      <translation variants="yes">
        <lengthvariant priority="1">協力廠商通知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_30_seconds">
      <source>30 seconds</source>
      <translation variants="no">30秒</translation>
    </message>
    <message numerus="no" id="txt_cp_list_no_tone">
      <source>Set no tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">無</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language_val_non">
      <source>None</source>
      <translation variants="no">無</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_personalization">
      <source>Personalization</source>
      <translation variants="yes">
        <lengthvariant priority="1">個人化</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reminder_tone">
      <source>Reminder tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">日曆響鬧鈴聲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection">
      <source>Operator selection</source>
      <translation variants="no">營辦商選擇</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_11">
      <source>Copyright (C) 2003, 2004, 2005, 2006 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2006, 2007 Alexey Proskuryakov (ap@nypop.com)
Copyright (C) 2006 Nikolas Zimmermann &lt;zimmermann@kde.org&gt;
Copyright (C) 2006 Samuel Weinig &lt;sam.weinig@gmail.com&gt;
Copyright (C) 2006 James G. Speth (speth@end.com)
Copyright (C) 2006 Jonas Witt &lt;jonas.witt@gmail.com&gt;
Copyright (C) 2006, 2007 Trolltech ASA
Copyright (C) 2005, 2006 Kimmo Kinnunen &lt;kimmo.t.kinnunen@nokia.com&gt;.
Copyright (C) 2006 Zack Rusin &lt;zack@kde.org&gt;
Copyright (C) 2007 Alp Toker &lt;alp@atoker.com&gt;
Copyright (C) 2007 Alp Toker &lt;alp.toker@collabora.co.uk&gt;
Copyright (C) 2007 Graham Dennis (graham.dennis@gmail.com)
Copyright (C) 2006 Don Gibson &lt;dgibson77@gmail.com&gt;
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2007 Holger Hans Peter Freyther
Copyright (C) 2007 Matt Lilek (pewtermoose@gmail.com).
Copyright (C) 2006 David Smith (catfish.man@gmail.com)
Copyright (C) 2006 George Staikos &lt;staikos@kde.org&gt;
Copyright (C) 2006 Simon Hausmann &lt;hausmann@kde.org&gt;
Copyright (C) 2006 Rob Buis &lt;buis@kde.org&gt;
Copyright (C) 2006 Dirk Mueller &lt;mueller@kde.org&gt;
Copyright (C) 2000-2001 Dawit Alemayehu &lt;adawit@kde.org&gt;
Copyright (C) 2006, 2007 Eric Seidel &lt;eric@webkit.org&gt;
Copyright (C) 2005, 2006 Alexander Kellett &lt;lypanov@kde.org&gt;
Copyright (C) 2005 Oliver Hunt &lt;ojh16@student.canterbury.ac.nz&gt;.  All rights reserved.
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2006 Enrico Ros &lt;enrico.ros@m31engineering.it&gt;
Copyright (C) 2007 Staikos Computing Services Inc. &lt;info@staikos.net&gt;
Copyright (C) 2006 Charles Samuels &lt;charles@kde.org&gt;
Copyright (C) 2007 Kevin Ollivier &lt;kevino@theolliviers.com&gt;
Copyright (C) 2007 Robin Dunn.  All rights reserved.
Copyright     2005 Frerich Raabe &lt;raabe@kde.org&gt;
Copyright     2005 Maksim Orlovich &lt;maksim@kde.org&gt;

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the fol</source>
      <translation variants="no">zh_hk #Copyright (C) 2003, 2004, 2005, 2006 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2006, 2007 Alexey Proskuryakov (ap@nypop.com)
Copyright (C) 2006 Nikolas Zimmermann &lt;zimmermann@kde.org&gt;
Copyright (C) 2006 Samuel Weinig &lt;sam.weinig@gmail.com&gt;
Copyright (C) 2006 James G. Speth (speth@end.com)
Copyright (C) 2006 Jonas Witt &lt;jonas.witt@gmail.com&gt;
Copyright (C) 2006, 2007 Trolltech ASA
Copyright (C) 2005, 2006 Kimmo Kinnunen &lt;kimmo.t.kinnunen@nokia.com&gt;.
Copyright (C) 2006 Zack Rusin &lt;zack@kde.org&gt;
Copyright (C) 2007 Alp Toker &lt;alp@atoker.com&gt;
Copyright (C) 2007 Alp Toker &lt;alp.toker@collabora.co.uk&gt;
Copyright (C) 2007 Graham Dennis (graham.dennis@gmail.com)
Copyright (C) 2006 Don Gibson &lt;dgibson77@gmail.com&gt;
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2007 Holger Hans Peter Freyther
Copyright (C) 2007 Matt Lilek (pewtermoose@gmail.com).
Copyright (C) 2006 David Smith (catfish.man@gmail.com)
Copyright (C) 2006 George Staikos &lt;staikos@kde.org&gt;
Copyright (C) 2006 Simon Hausmann &lt;hausmann@kde.org&gt;
Copyright (C) 2006 Rob Buis &lt;buis@kde.org&gt;
Copyright (C) 2006 Dirk Mueller &lt;mueller@kde.org&gt;
Copyright (C) 2000-2001 Dawit Alemayehu &lt;adawit@kde.org&gt;
Copyright (C) 2006, 2007 Eric Seidel &lt;eric@webkit.org&gt;
Copyright (C) 2005, 2006 Alexander Kellett &lt;lypanov@kde.org&gt;
Copyright (C) 2005 Oliver Hunt &lt;ojh16@student.canterbury.ac.nz&gt;.  All rights reserved.
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2006 Enrico Ros &lt;enrico.ros@m31engineering.it&gt;
Copyright (C) 2007 Staikos Computing Services Inc. &lt;info@staikos.net&gt;
Copyright (C) 2006 Charles Samuels &lt;charles@kde.org&gt;
Copyright (C) 2007 Kevin Ollivier &lt;kevino@theolliviers.com&gt;
Copyright (C) 2007 Robin Dunn.  All rights reserved.
Copyright     2005 Frerich Raabe &lt;raabe@kde.org&gt;
Copyright     2005 Maksim Orlovich &lt;maksim@kde.org&gt;

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the fol</translation>
    </message>
    <message numerus="no" id="txt_cp_general">
      <source>General</source>
      <translation variants="no">一般</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_12">
      <source>Copyright (C) 2007 Apple Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Apple Computer, Inc. ("Apple") nor the names of
   its contributors may be used to endorse or promote products derived
   from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE COMPUTER, INC. ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Copyright (C) 2007 Apple Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Apple Computer, Inc. ("Apple") nor the names of
   its contributors may be used to endorse or promote products derived
   from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE COMPUTER, INC. ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_heading_profile_name">
      <source>Profile name: </source>
      <translation variants="no">操作模式名稱：</translation>
    </message>
    <message numerus="no" id="txt_cp_meeting">
      <source>Meeting</source>
      <translation variants="no">會議</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_themes">
      <source>Get more from Ovi</source>
      <translation variants="yes">
        <lengthvariant priority="1">取得更多</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_tones">
      <source>Get more from Ovi</source>
      <translation variants="yes">
        <lengthvariant priority="1">前往商店</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_control_panel">
      <source>Control Panel</source>
      <translation variants="yes">
        <lengthvariant priority="1">控制台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">控制台</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">控制台</translation>
    </message>
  </context>
</TS>