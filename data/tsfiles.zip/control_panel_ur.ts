<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cp_title_control_panel">
      <source>Control Panel</source>
      <translation variants="yes">
        <lengthvariant priority="1">کنٹرول پینل</lengthvariant>
        <lengthvariant priority="2">کنٹر. پینل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_45_seconds">
      <source>45 seconds</source>
      <translation variants="no">۴۵ سیکنڈ</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_wallpaper">
      <source>Wallpaper</source>
      <translation variants="yes">
        <lengthvariant priority="1">وال پیپر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_automatic">
      <source>Automatic</source>
      <translation variants="no">خودکار</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_manual">
      <source>Manual</source>
      <translation variants="no">دستی</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_dual_mode">
      <source>Dual mode</source>
      <translation variants="no">دہری وضع</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_accessibility_val_adjust_accessibili">
      <source>Adjust accessibility options</source>
      <translation variants="yes">
        <lengthvariant priority="1">اضافی آلہ. ترتیب. ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_setup">
      <source>Setup</source>
      <translation variants="yes">
        <lengthvariant priority="1">نظم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_touch_screen_vibra">
      <source>Touch screen vibra</source>
      <translation variants="no">ارتعاش</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_automatic">
      <source>Automatic</source>
      <translation variants="no">خودکار</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_about">
      <source>About</source>
      <translation variants="no">پروگرام کے متعلق</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_select_tone_type">
      <source>Select tone type</source>
      <translation variants="no">ٹون کی قسم منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">میٹنگ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_15_seconds">
      <source>15 seconds</source>
      <translation variants="no">۱۵ سیکنڈ</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_theme">
      <source>Select theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">موضوع منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_2_minutes">
      <source>2 minutes</source>
      <translation variants="no">۲ منٹ</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_volume">
      <source>Volume</source>
      <translation variants="no">والیوم</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات دوبارہ مرتب</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">بٹن اور اسکرین</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_email_tone">
      <source>E-mail tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل انتباہ ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_in_offline_mode_all_wireless_communica">
      <source>In offline mode all wireless communication is turned off.</source>
      <translation variants="no">تمام وائرلیس اتصالات بند ہیں</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_operator">
      <source>Select operator</source>
      <translation variants="yes">
        <lengthvariant priority="1">آپریٹر منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_umts">
      <source>UMTS</source>
      <translation variants="no">3G</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_home_network">
      <source>Data usage in home network</source>
      <translation variants="no">ہوم نیٹ ورک میں ڈیٹا کا استعمال</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_offline_mode_val_off">
      <source>Off</source>
      <translation variants="no">غیر کارآمد کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">بنیادی تحریری زبان</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode">
      <source>Network mode</source>
      <translation variants="no">نیٹورک وضع</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_reset">
      <source>Reset</source>
      <translation variants="no">ترتیبات پھر مرتب کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_list_tone">
      <source>Tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device">
      <source>Device</source>
      <translation variants="no">فون</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_connectivity">
      <source>Connectivity</source>
      <translation variants="no">اتصالیت</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">موضوع</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reminder_tone">
      <source>Reminder tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">کیلنڈر انتباہ ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_automatic">
      <source>Automatic</source>
      <translation variants="no">خودکار</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection">
      <source>Operator selection</source>
      <translation variants="no">آپریٹر کا انتخاب</translation>
    </message>
    <message numerus="no" id="txt_cp_info_rotate_the_display_content_automatical">
      <source>Rotate the display content automatically when you turn the device on horizontal or back to a vertical position.</source>
      <translation variants="no">جب آلے کی رخ بندی تبدیل ہوتی ہے تو خودکار گردشیں مشمولات کی نمائش کرتی ہیں</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_key_and_touchscreen_tones">
      <source>Key and touchscreen tones</source>
      <translation variants="no">بٹن ٹونز</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_roaming">
      <source>Data usage when roaming</source>
      <translation variants="no">رومنگ میں ڈیٹا کا استعمال</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_mobile_network">
      <source>Mobile network</source>
      <translation variants="no">موبائل نیٹ ورک</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="no">بٹن اور اسکرین</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_brightness">
      <source>Brightness</source>
      <translation variants="no">چمک</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">موبائل نیٹ ورک</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروگرام کے متعلق</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_no_tone">
      <source>No tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_preview_1">
      <source>Preview: %1</source>
      <translation variants="no">پیش جائزہ: %[22]1</translation>
    </message>
    <message numerus="no" id="txt_cp_list_autorotate_display">
      <source>Auto-rotate display</source>
      <translation variants="no">خودکار گردش کی نمائش</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_disabled">
      <source>Disabled</source>
      <translation variants="no">غیر فعال کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_cp_info_no_operators_found">
      <source>No operators found.</source>
      <translation variants="no">کوئی آپریٹر نہیں ملا۔</translation>
    </message>
    <message numerus="no" id="txt_cp_info_updating">
      <source>Updating operator list</source>
      <translation variants="no">آپریٹر فہرست کی تجدید ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language_val_non">
      <source>None</source>
      <translation variants="no">کوئی نہیں</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_confirm">
      <source>Confirm</source>
      <translation variants="no">ہمیشہ دریافت کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_power_management">
      <source>Power management</source>
      <translation variants="yes">
        <lengthvariant priority="1">پاور مینیجمنٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">منقطع کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_button_silence">
      <source>Silence</source>
      <translation variants="no">خاموشی</translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_must_be_disconnected_befo">
      <source>Active calls must be disconnected before operator selection.</source>
      <translation variants="no">آپریٹر کے انتخاب سے پہلے کارآمد کالوں کو منقطع کیا جانا چاہیے</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">گھنٹی والیوم</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset">
      <source>Settings reset</source>
      <translation variants="no">ترتیبات مرتب کی گئیں</translation>
    </message>
    <message numerus="no" id="txt_cp_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">ارتعاش</translation>
    </message>
    <message numerus="no" id="txt_cp_info_restore_original_settings_no_data_wil">
      <source>Restore original settings? No data will be deleted.</source>
      <translation variants="no">اصل ترتیبات بحال کریں؟ کوئی ڈیٹا نہیں مٹے گا۔</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_ringtone">
      <source>Ringtone</source>
      <translation variants="yes">
        <lengthvariant priority="1">گھنٹی کی ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_meeting">
      <source>Meeting</source>
      <translation variants="no">ملاقات</translation>
    </message>
    <message numerus="no" id="txt_cp_info_no_access_to_selected_operators_netwo">
      <source>No access to selected operator’s network.</source>
      <translation variants="no">منتخب آپریٹر کے نیٹ ورک تک رسائی سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_personalization">
      <source>Personalization</source>
      <translation variants="no">ذاتی ضرورت کے مطابق ترمیم</translation>
    </message>
    <message numerus="no" id="txt_cp_general">
      <source>General</source>
      <translation variants="no">عام</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_tones_that_play_when_you_select">
      <source>Select tones that play when you select the profile named:</source>
      <translation variants="no">اس پروفائل کے منتخب کیے جانے پر استعمال کی جانے والی ٹونز منتخب کریں:</translation>
    </message>
    <message numerus="no" id="txt_cp_info_delete_all_data_and_restore_original_s">
      <source>Delete all data and restore original settings? Ejectable memory card data is not deleted.</source>
      <translation variants="no">تمام ڈیٹا مٹائیں اور فیکٹری ترتیبات بحال کریں۔ قابل علاحدگی حافظہ کارڈ کا ڈیٹا نہیں مٹے گا۔</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">زبان اور علاقہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_regional_settings">
      <source>Regional settings</source>
      <translation variants="no">علاقائی ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset_val_reset_settings">
      <source>Reset settings</source>
      <translation variants="no">ترتیبات باز مرتب کریں</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">ur ##Control Panel</translation>
    </message>
    <message numerus="no" id="txt_cp_title_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">برتر ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_confirm">
      <source>Confirm</source>
      <translation variants="no">ہمیشہ دریافت کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_language_and_region">
      <source>Language and region</source>
      <translation variants="no">زبان اور علاقہ</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_disabled">
      <source>Disabled</source>
      <translation variants="no">غیر فعال کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_cp_title_end_encryption">
      <source>End encryption</source>
      <translation variants="yes">
        <lengthvariant priority="1">رمز نگاری ختم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروفائل منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_your_region">
      <source>Select your region:</source>
      <translation variants="no">اپنا علاقہ منتخب کریں:</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_not_connected">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">متصل نہیں کیا گیا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_end">
      <source>End</source>
      <translation variants="no">ختم کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_display_language">
      <source>Display language</source>
      <translation variants="no">زبان ظاہر کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_tones">
      <source>Get more tones</source>
      <translation variants="yes">
        <lengthvariant priority="1">اسٹور پر جائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_original_settings_will_be_restored_no">
      <source>Original settings will be restored. No data will be deleted.</source>
      <translation variants="no">اصل ترتیبات بحال ہو جائیں گی۔ کوئی ڈیٹا نہیں مٹے گا۔</translation>
    </message>
    <message numerus="no" id="txt_long_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">کنٹرول پینل</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروفائل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_operator_selection_is_not_possible_in">
      <source>Operator selection is not possible in Offline.</source>
      <translation variants="no">آف لائن وضع میں آپریٹر منتخب کرنے سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_cp_button_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">برتر ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_gsm">
      <source>GSM</source>
      <translation variants="no">GSM</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_30_seconds">
      <source>30 seconds</source>
      <translation variants="no">۳۰ سیکنڈ</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_val_change_language">
      <source>Change language</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات زبان ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset_val_reset_your_device">
      <source>Reset your device</source>
      <translation variants="yes">
        <lengthvariant priority="1">فیکٹری ترتیبات بحال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_edit_name">
      <source>Edit name</source>
      <translation variants="yes">
        <lengthvariant priority="1">نام ترمیم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_heading_profile_name">
      <source>Profile name: </source>
      <translation variants="no">پروفائل کا نام:</translation>
    </message>
    <message numerus="no" id="txt_cp_button_touch_screen_calibration">
      <source>Touch screen calibration</source>
      <translation variants="no">ٹچ اسکرین پیمانہ بندی</translation>
    </message>
    <message numerus="no" id="txt_cp_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">عام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_message_tone">
      <source>Message tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیغام انتباہ ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_edit_name">
      <source>Edit name</source>
      <translation variants="no">نام ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_list_notification_tones">
      <source>Notification tones</source>
      <translation variants="no">اطلاع نامے کی ٹونز</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active">
      <source>Silent state active</source>
      <translation variants="no">خاموش حالت کارآمد</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset_val_reset_device">
      <source>Reset device</source>
      <translation variants="no">آلہ باز مرتب کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_info_all_data_will_be_deleted_and_factory_s">
      <source>All data will be deleted and factory settings will be restored. Ejectable memory card data is not deleted.</source>
      <translation variants="no">تمام ڈیٹا مٹ جائے گا اور فیکٹری ترتیبات بحال ہو جائیں گی۔ قابل علاحدگی حافظہ کارڈ کا ڈیٹا نہیں مٹے گا۔</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_001">
      <source>1%</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_locked_after">
      <source>Keys &amp; screen locked after</source>
      <translation variants="no">بٹن اور اسکرین مقفلی:</translation>
    </message>
    <message numerus="no" id="txt_cp_list_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">موسیقی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_offline_mode_val_on">
      <source>On</source>
      <translation variants="no">کارآمد کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_1_minute">
      <source>1 minute</source>
      <translation variants="no">۱ منٹ</translation>
    </message>
    <message numerus="no" id="txt_cp_info_setup_is_not_completed_would_you_lik">
      <source>Setup is not completed. 
Would you like to complete it now?</source>
      <translation variants="no">آلے کی مرتبی مکمل نہیں کی گئی ہے۔ اب مکمل کریں؟</translation>
    </message>
    <message numerus="no" id="txt_cp_list_recording">
      <source>Recording</source>
      <translation variants="yes">
        <lengthvariant priority="1">ریکارڈنگ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_security">
      <source>Security</source>
      <translation variants="no">حفاظت</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">ثانوی تحریری زبان</translation>
    </message>
    <message numerus="no" id="txt_cp_info_data_encryption_ongoing_enryption_mus">
      <source>Data encryption ongoing. Enryption must be ended before reset.  End data enrcyption?</source>
      <translation variants="no">ڈیٹا رمز نگاری جاری۔ رمز نگاری باز مرتبی سے پہلے ختم کی جانی چاہیے۔ ڈیٹا کی رمز نگاری ختم کریں؟</translation>
    </message>
    <message numerus="no" id="txt_short_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">ur #Control panel</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active_val_clock_alarm">
      <source>Clock alarm at %1</source>
      <translation variants="no">گھڑی الارم %1 پر</translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_and_connections_must_be_d">
      <source>Active calls and connections must be disconnected before reset.</source>
      <translation variants="no">باز مرتبی سے پہلے کارآمد کالوں اور اتصالات کو منقطع کیا جانا چاہیے</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset">
      <source>Device reset</source>
      <translation variants="no">آلہ باز مرتب کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_offline_airplane_mode">
      <source>Offline (Airplane Mode)</source>
      <translation variants="no">آف لائن (ہوائی جہاز وضع)</translation>
    </message>
  </context>
</TS>