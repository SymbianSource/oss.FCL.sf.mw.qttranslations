<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cp_subhead_device">
      <source>Device</source>
      <translation variants="yes">
        <lengthvariant priority="1">فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_val_change_language">
      <source>Change language</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات زبان ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات پھر مرتب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_1_minute">
      <source>1 minute</source>
      <translation variants="no">۱ منٹ</translation>
    </message>
    <message numerus="no" id="txt_cp_info_setup_is_not_completed_would_you_lik">
      <source>Setup is not completed. 
Would you like to complete it now?</source>
      <translation variants="no">آلے کی مرتبی مکمل نہیں کی گئی ہے۔ اب مکمل کریں؟</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_security">
      <source>Security</source>
      <translation variants="yes">
        <lengthvariant priority="1">حفاظت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_locked_after">
      <source>Keys &amp; screen locked after</source>
      <translation variants="no">بٹن اور اسکرین مقفلی:</translation>
    </message>
    <message numerus="no" id="txt_cp_list_music">
      <source>Choose from music</source>
      <translation variants="yes">
        <lengthvariant priority="1">موسیقی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_setup">
      <source>Setup</source>
      <translation variants="no">نظم</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروگرام کے متعلق</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_automatic">
      <source>Automatic</source>
      <translation variants="no">خودکار</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_15_seconds">
      <source>15 seconds</source>
      <translation variants="no">۱۵ سیکنڈ</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">موضوع منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_touch_screen_vibra">
      <source>Touch screen vibra</source>
      <translation variants="no">ارتعاش</translation>
    </message>
    <message numerus="no" id="txt_cp_list_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">بٹن اور اسکرین</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_in_offline_mode_all_wireless_communica">
      <source>In offline mode all wireless communication is turned off.</source>
      <translation variants="no">تمام وائرلیس اتصالات بند ہیں</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode">
      <source>Network mode</source>
      <translation variants="no">نیٹورک وضع</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">ثانوی تحریری زبان</translation>
    </message>
    <message numerus="no" id="txt_cp_info_rotate_the_display_content_automatical">
      <source>Rotate the display content automatically when you turn the device on horizontal or back to a vertical position.</source>
      <translation variants="no">جب آلے کی رخ بندی تبدیل ہوتی ہے تو خودکار گردشیں مشمولات کی نمائش کرتی ہیں</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection">
      <source>Operator selection</source>
      <translation variants="no">آپریٹر کا انتخاب</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_2_minutes">
      <source>2 minutes</source>
      <translation variants="no">۲ منٹ</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_key_and_touchscreen_tones">
      <source>Key and touchscreen tones</source>
      <translation variants="no">بٹن ٹونز</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_home_network">
      <source>Data usage in home network</source>
      <translation variants="no">ہوم نیٹ ورک میں ڈیٹا کا استعمال</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_gsm">
      <source>GSM</source>
      <translation variants="no">GSM</translation>
    </message>
    <message numerus="no" id="txt_cp_list_tone">
      <source>Choose from tones</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_connectivity">
      <source>Connectivity</source>
      <translation variants="yes">
        <lengthvariant priority="1">اتصالیت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_30_seconds">
      <source>30 seconds</source>
      <translation variants="no">۳۰ سیکنڈ</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset_val_reset_your_device">
      <source>Reset your device</source>
      <translation variants="yes">
        <lengthvariant priority="1">فیکٹری ترتیبات بحال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_automatic">
      <source>Automatic</source>
      <translation variants="no">خودکار</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_roaming">
      <source>Data usage when roaming</source>
      <translation variants="no">رومنگ میں ڈیٹا کا استعمال</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">بنیادی تحریری زبان</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">موضوع</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_wallpaper">
      <source>Wallpaper</source>
      <translation variants="yes">
        <lengthvariant priority="1">وال پیپر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_manual">
      <source>Manual</source>
      <translation variants="yes">
        <lengthvariant priority="1">دستی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_select_tone_type">
      <source>Change tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹون کی قسم منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_45_seconds">
      <source>45 seconds</source>
      <translation variants="no">۴۵ سیکنڈ</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_dual_mode">
      <source>Dual mode</source>
      <translation variants="no">دہری وضع</translation>
    </message>
    <message numerus="no" id="txt_cp_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">میٹنگ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_control_panel">
      <source>Control Panel</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_email_tone">
      <source>E-mail tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل انتباہ ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_message_tone">
      <source>Message tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیغام انتباہ ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">عام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_volume">
      <source>Volume</source>
      <translation variants="yes">
        <lengthvariant priority="1">والیوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_umts">
      <source>UMTS</source>
      <translation variants="no">3G</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reminder_tone">
      <source>Reminder tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">کیلنڈر انتباہ ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات دوبارہ مرتب</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">موبائل نیٹ ورک</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_brightness">
      <source>Brightness</source>
      <translation variants="no">چمک</translation>
    </message>
    <message numerus="no" id="txt_cp_list_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروگرام کے متعلق</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">بٹن اور اسکرین</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_autorotate_display">
      <source>Auto-rotate display</source>
      <translation variants="no">خودکار گردش کی نمائش</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">موبائل نیٹ ورک</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_preview_1">
      <source>Preview: %1</source>
      <translation variants="no">پیش جائزہ: %[22]1</translation>
    </message>
    <message numerus="no" id="txt_cp_list_no_tone">
      <source>Set no tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_and_connections_must_be_d">
      <source>Active calls and connections must be disconnected before reset.</source>
      <translation variants="no">باز مرتبی سے پہلے کارآمد کالوں اور اتصالات کو منقطع کیا جانا چاہیے</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset">
      <source>Device reset</source>
      <translation variants="no">آلہ باز مرتب کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_cp_terms_of_use">
      <source>Terms of Use</source>
      <translation variants="no">شرائط استعمال</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_graphical_style_of_the_device">
      <source>Select graphical style of the device</source>
      <translation variants="no">ur ##Select theme</translation>
    </message>
    <message numerus="no" id="txt_short_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_12">
      <source>Copyright (C) 2007 Apple Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Apple Computer, Inc. ("Apple") nor the names of
   its contributors may be used to endorse or promote products derived
   from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE COMPUTER, INC. ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">حق اشاعت (C) ۲۰۰۷Apple Inc.۔ جملہ حقوق محفوظ۔ 

باز تقسیم کاری اور اصل اور دو عنصری شکلوں میں، 
کسی ترمیم کے ساتھ یا اس کے بغیر استعمال کی اجازت دی جاتی ہے بشرطیکہ مندرجہ ذیل شرائط کی پابندی کی جائے:
 ۱۔ اصل کوڈ کی باز تقسیم کاریوں میں مذکورہ بالا اطلاع نامۂ حق اشاعت، شرائط کی اس فہرست اور مندرجہ ذیل اعلان عدم ذمہ داری کو برقرار رکھا جائے۔
۲۔ دو عنصری شکل میں باز تقسیم کاریوں میں مذکورہ بالا حق اشاعت کے اطلاع نامہ کو، شرائط کی اس فہرست کو اورمندرجہ ذیل اعلان عدم ذمہ داری کو دستاویز اور/یا تقسیم کے لیے فراہم کردہ مواد میں نقل کیا جانا چاہیے۔ 

۳۔ نہ تو Apple Computer, Inc. کا نام("Apple")اور نہ ہی اس کے معاونین کے نام مخصوص تحریری پیشگی اجازت کے بغیر اس سافٹ ویئر سے اشتقاق شدہ مصنوعات کی سفارش و فروغ کے لیے استعمال کیے جائیں گے۔ یہ سافٹ ویئر 
APPLE COMPUTER, INC. نے''جیسا ہے'' کی بنیاد پر فراہم کیا ہے 
 اور کسی بھی قسم کی براہ راست یا بالواسطہ ضمانتیں بشمول صلاحیت فروخت کی بالواسطہ ضمانت سے، لیکن جو اس تک ہی محدود نہیں ہے، عدم ذمہ داری کا اعلان کیا جاتا ہے۔ کسی بھی حالت میں APPLE COMPUTER, INC. یا معاونین کی، براہ راست، بالواسطہ، اتفاقی،
مخصوص مثالی، یا ضمنی نقصانات، (بشمول، متبادل مصنوعات یا خدمات کا حصول؛ استعمال، ڈیٹا یا منافع سے محرومی؛ یا کاروبار میں خلل کی لیکن جو ان تک ہی محدود نہیں) چاہے وہ کسی بھی سبب یا کسی بھی نظریے سے ہوا ہو، کوئی ذمہ داری نہیں ہوگی، خواہ وہ معاہدے، سخت جواب دہی یا جرمانہ و تلافی کے قانون کے تحت ہو (بشمول عدم توجہی یا بصورت دیگر) جو اس سافٹ ویئر کے استعمال کے سبب وجود میں آئے اور خواہ اس طرح کے ممکنہ نقصان کے بارے میں آگاہ کیا جا چکا ہو۔</translation>
    </message>
    <message numerus="no" id="txt_cp_info_when_selected_clock_is_displayed_when">
      <source>When selected, clock is displayed when in idle.</source>
      <translation variants="no">اسکرین خالی ہو جانے پر گھڑی کو ظاہر کرتا ہے</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active_val_clock_alarm">
      <source>Clock alarm at %1</source>
      <translation variants="no">گھڑی الارم %1 پر</translation>
    </message>
    <message numerus="no" id="txt_cp_info_type">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_processing">
      <source>Processing…</source>
      <translation variants="no">زیر عمل</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset_val_reset_settings">
      <source>Reset settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات باز مرتب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_tones_that_play_when_you_select">
      <source>Select tones that play when you select the profile named:</source>
      <translation variants="no">اس پروفائل کے منتخب کیے جانے پر استعمال کی جانے والی ٹونز منتخب کریں:</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_themes">
      <source>Get more from Ovi</source>
      <translation variants="yes">
        <lengthvariant priority="1">موضوعات حاصل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_product_release">
      <source>Product Release</source>
      <translation variants="no">پروڈکٹ کا اجراء</translation>
    </message>
    <message numerus="no" id="txt_cp_title_edit_name">
      <source>Edit name</source>
      <translation variants="no">نام ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_general">
      <source>General</source>
      <translation variants="no">عام</translation>
    </message>
    <message numerus="no" id="txt_cp_info_product_release">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_delete_all_data_and_restore_original_s">
      <source>Delete all data and restore original settings? Ejectable memory card data is not deleted.</source>
      <translation variants="no">تمام ڈیٹا مٹائیں اور فیکٹری ترتیبات بحال کریں۔ قابل علاحدگی حافظہ کارڈ کا ڈیٹا نہیں مٹے گا۔</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_not_connected">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">متصل نہیں کیا گیا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">زبان اور علاقہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_4">
      <source>Copyright (C) 2004, Apple Computer, Inc. and The Mozilla Foundation. 
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. Neither the names of Apple Computer, Inc. ("Apple") or The Mozilla
Foundation ("Mozilla") nor the names of their contributors may be used
to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY APPLE, MOZILLA AND THEIR CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE, MOZILLA OR
THEIR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">حق اشاعت (C)۲۰۰۴Apple Computer, Inc.، اورThe Mozilla Foundation۔ 
جملہ حقوق محفوظ ۔ 

باز تقسیم کاری اور اصل اور دو عنصری شکلوں میں، 
کسی ترمیم کے ساتھ یا اس کے بغیر استعمال کی اجازت دی جاتی ہے بشرطیکہ مندرجہ ذیل شرائط کی پابندی کی جائے:
 ۱۔ اصل کوڈ کی باز تقسیم کاریوں میں مذکورہ بالا اطلاع نامۂ حق اشاعت، شرائط کی اس فہرست اور مندرجہ ذیل اعلان عدم ذمہ داری کو برقرار رکھا جائے۔
۲۔ دو عنصری شکل میں باز تقسیم کاریوں میں مذکورہ بالا حق اشاعت کے اطلاع نامہ کو، شرائط کی اس فہرست کو اورمندرجہ ذیل اعلان عدم ذمہ داری کو دستاویز اور/یا تقسیم کے لیے فراہم کردہ مواد میں نقل کیا جانا چاہیے۔ 

۳۔ نہ تو Apple Computer, Inc. کا نام("Apple")  یا The MozillaFoundation ("Mozilla") اور نہ ہی اس کے معاونین کے نام مخصوص تحریری پیشگی اجازت کے بغیر اس سافٹ ویئر سے اشتقاق شدہ مصنوعات کی سفارش و فروغ کے لیے استعمال کیا جائے گا۔ یہ سافٹ ویئر 
  APPLE, MOZILLA یا ان کے معاونین نے ''جیسا ہے'' کی بنیاد پر فراہم کیا ہے 
 اور کسی بھی قسم کی براہ راست یا بالواسطہ ضمانتیں بشمول صلاحیت فروخت کی بالواسطہ ضمانت سے، لیکن جو اس تک ہی محدود نہیں ہے، عدم ذمہ داری کا اعلان کیا جاتا ہے۔ کسی بھی حالت میں APPLE, MOZILLA یا ان کے معاونین کی، براہ راست، بالواسطہ، اتفاقی،
مخصوص مثالی، یا ضمنی نقصانات (بشمول، متبادل مصنوعات یا خدمات کا حصول؛ استعمال، ڈیٹا یا منافع سے محرومی؛ یا کاروبار میں خلل کی لیکن جو ان تک ہی محدود نہیں) چاہے وہ کسی بھی سبب یا کسی بھی نظریے سے ہوا ہو، کوئی ذمہ داری نہیں ہوگی خواہ وہ معاہدے، سخت جواب دہی یا جرمانہ و تلافی کے قانون کے تحت ہو (بشمول عدم توجہی یا بصورت دیگر) جو اس سافٹ ویئر کے استعمال کے سبب وجود میں آئے اور خواہ اس طرح کے ممکنہ نقصان کے بارے میں آگاہ کیا جا چکا ہو۔</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_6">
      <source>Copyright (c) 2004, 2005 Apple Computer, Inc.
Copyright (c) 1997-2005 University of Cambridge
All rights reserved.
Copyright (c) 2005, Google Inc.
All rights reserved.
Copyright (c) 2006, Nokia Corporation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the University of Cambridge nor the name of Google
  Inc. nor the names of their contributors may be used to endorse or
  promote products derived from this software without specific prior
  written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">حق اشاعت (c) ۲۰۰۴،۲۰۰۵ Apple Computer, Inc.۔ 
 حق اشاعت(c) ۱۹۹۷،۲۰۰۵ University of Cambridge ۔ 
جملہ حقوق محفوظ۔ حق اشاعت(c) ۲۰۰۵، Google Inc. جملہ حقوق محفوظ۔ حق اشاعت(c) ۲۰۰۶Nokia Corporation 
 

 باز تقسیم کاری اور اصل اور دو عنصری شکلوں میں، 
کسی ترمیم کے ساتھ یا اس کے بغیر استعمال کی اجازت دی جاتی ہے بشرطیکہ مندرجہ ذیل شرائط کی پابندی کی جائے:*

 اصل کوڈ کی باز تقسیم کاریوں میں مذکورہ بالا اطلاع نامۂ حق اشاعت، شرائط کی اس فہرست اور مندرجہ ذیل اعلان عدم ذمہ داری کو برقرار رکھا جائے۔ *

 دو عنصری شکل میں باز تقسیم کاریوں میں مذکورہ بالا حق اشاعت کے اطلاع نامہ کو، شرائط کی اس فہرست کو
 اورمندرجہ ذیل اعلان عدم ذمہ داری کو دستاویز اور/یا تقسیم کے لیے فراہم کردہ مواد میں نقل کیا جانا چاہیے۔ *

 نہ تو University of Cambridge کا نام اور نہ ہی Google
 Inc. کا نام اور نہ ہی ان کے معاونین کے نام مخصوص تحریری پیشگی اجازت کے بغیر اس سافٹ ویئر سے اشتقاق شدہ مصنوعات کی سفارش و فروغ کے لیے استعمال کیے جائیں گے۔

 یہ سافٹ ویئر حق اشاعت کے مالکان اور معاونین نے''جیسا ہے'' کی بنیاد پر فراہم کیا ہے 
 اور کسی بھی قسم کی براہ راست یا بالواسطہ ضمانتیں بشمول صلاحیت فروخت کی بالواسطہ ضمانت سے، لیکن جو اس تک ہی محدود نہیں ہے، عدم ذمہ داری کا اعلان کیا جاتا ہے۔ کسی بھی حالت میں حق اشاعت کے مالکان یا معاونین کی، براہ راست، بالواسطہ، اتفاقی،
مخصوص مثالی، یا ضمنی نقصانات، (بشمول، متبادل مصنوعات یا خدمات کا حصول؛ استعمال، ڈیٹا یا منافع سے محرومی؛ یا کاروبار میں خلل کی لیکن جو ان تک ہی محدود نہیں) چاہے وہ کسی بھی سبب یا کسی بھی نظریے سے ہوا ہو، 
 کوئی ذمہ داری نہیں ہوگی، خواہ وہ معاہدے، سخت جواب دہی یا جرمانہ و تلافی کے قانون کے تحت ہو (بشمول عدم توجہی یا بصورت دیگر) جو اس سافٹ ویئر کے استعمال کے سبب وجود میں آئے اور خواہ اس طرح کے ممکنہ نقصان کے بارے میں آگاہ کیا جا چکا ہو۔</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset">
      <source>Settings reset</source>
      <translation variants="no">ترتیبات مرتب کی گئیں</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_ringtone">
      <source>Ringtone</source>
      <translation variants="yes">
        <lengthvariant priority="1">گھنٹی کی ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_software_vesion">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_restore_original_settings_no_data_wil">
      <source>Restore original settings? No data will be deleted.</source>
      <translation variants="no">اصل ترتیبات بحال کریں؟ کوئی ڈیٹا نہیں مٹے گا۔</translation>
    </message>
    <message numerus="no" id="txt_cp_heading_profile_name">
      <source>Profile name: </source>
      <translation variants="no">پروفائل کا نام:</translation>
    </message>
    <message numerus="no" id="txt_cp_list_screensaver">
      <source>Screensaver</source>
      <translation variants="no">گھڑی اسکرین سیور</translation>
    </message>
    <message numerus="no" id="txt_cp_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">ارتعاش</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_5">
      <source>The author of this software is David M. Gay.

Copyright (c) 1991, 2000, 2001 by Lucent Technologies.

Permission to use, copy, modify, and distribute this software for any
purpose without fee is hereby granted, provided that this entire notice
is included in all copies of any software which is or includes a copy
or modification of this software and in all copies of the supporting
documentation for such software.

THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY.  IN PARTICULAR, NEITHER THE AUTHOR NOR LUCENT MAKES ANY
REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.</source>
      <translation variants="no">اس سافٹ ویئر کے مصنف David M. Gay ہیں۔ 

حق اشاعت (c) ۲۰۰۱،۲۰۰۰،۱۹۹۱ منجانب Lucent Technologies۔

اس سافٹ ویئر کو کسی بھی مقصد سے استعمال کرنے، نقل کرنے، اس میں رد و بدل کرنے اور اسے تقسیم کرنے کی اجازت بلا معاوضہ دی جاتی ہے، بشرطیکہ یہ پورا اطلاع نامہ کسی بھی سافٹ ویئر کی ان تمام  نقول میں شامل کیا جائے جو اس کی نقل ہوں یا جس میں اس کی نقل شامل ہو یا اس سافٹ ویئر کا  ترمیم شدہ نسخہ ہو اور اس طرح کے سافٹ ویئر کے تمام تائیدی دستاویزات کی نقول میں شامل ہو۔ یہ سافٹ ویئر ''جیسا ہے'' کی بنیاد پر کسی براہ راست یا بالواسطہ ضمانت کے بغیر فراہم کیا جا رہا ہے۔ خاص طور پر، نہ تو مصنف نہ لیوسنٹ کی طرف سے اس سافٹ ویئر کی صلاحیت فروخت یا کسی مخصوص مقصد سے اس کی موزونیت کی نمائندگی کی جاتی ہے اور نہ ہی ضمانت دی جاتی ہے۔</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_personalization">
      <source>Personalization</source>
      <translation variants="yes">
        <lengthvariant priority="1">ذاتی ضرورت کے مطابق ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_meeting">
      <source>Meeting</source>
      <translation variants="no">ملاقات</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_confirm">
      <source>Confirm</source>
      <translation variants="no">ہمیشہ دریافت کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device_model">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_button_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">خاموشی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_closing_connections">
      <source>Closing connections</source>
      <translation variants="no">اتصالات بند ہو رہے ہیں</translation>
    </message>
    <message numerus="no" id="txt_cp_button_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">برتر ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_7">
      <source>Copyright (c) 1994
Hewlett-Packard Company

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Hewlett-Packard Company makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</source>
      <translation variants="no">حق اشاعت (c) ۱۹۹۴ 
 Hewlett-Packard Company 

 اس سافٹ ویئر کو استعمال کرنے، اسے نقل کرنے، اس میں ترمیم کرنے اسے تقسیم اور فروخت کرنے اور اس کی دستاویز کاری کی اجازت بذریعۂ ہذا کسی معاوضے کے بغیر دی جاتی ہے بشرطیکہ مذکورہ بالا اطلاع نامہ، حق اشاعت کے تمام نسخوں میں ظاہر ہو اور یہ کہ وہ اطلاع نامۂ حق اشاعت اور یہ اجازت نامہ تائیدی دستاویزات میں بھی شامل کیے جائیں۔ Hewlett-Packard Company کسی بھی مقصد سے اس سافٹ ویئر کی موزونیت کے بارے میں کوئی ضمانت نہیں دیتی۔ یہ ''جیسا ہے'' کی بنیاد پر براہ راست یا بالواسطہ ضمانت کے بغیر فراہم کیا گیا ہے۔</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_10">
      <source>Copyright (c) 1995-2006 International Business Machines Corporation and others

All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, provided that the above copyright notice(s)
and this permission notice appear in all copies of the Software and that both the above
copyright notice(s) and this permission notice appear in supporting documentation.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 
Except as contained in this notice, the name of a copyright holder shall not be used in
advertising or otherwise to promote the sale, use or other dealings in this Software
without prior written authorization of the copyright holder.</source>
      <translation variants="no">حق اشاعت (c) ۱۹۹۵-۲۰۰۶ International Business Machines Corporation و دیگر

جملہ حقوق محفوظ۔ 

بذریعہ ہذا کسی بھی ایسے شخص کو جس نے اس سافٹ ویئر کا نسخہ اور متعلقہ دستاویز کی فائلیں 
 ("Software") حاصل کی ہیں سافٹ ویئر کے کاروباری معاملات کی بلا معاوضہ اجازت دی جاتی ہے جس میں غیر محدود طور پر سافٹ ویئر کے استعمال، اسے نقل کرنے، ترمیم کرنے، ضم کرنے، شا‏ئع کرنے، تقسیم کرنے اور/یا اس کے نقول فروخت کرنے اور ان لوگوں کو اجازت دینے کے حقوق کی اجازت بھی شامل ہے جنھیں اس مقصد سے سافٹ ویئر فراہم کیا گیا ہو بشرطیکہ مذکورہ بالا حق اشاعات کے اطلاع نامے اور
اس اجازت کا اطلاع نامہ سافٹ ویئر کے تمام نسخوں میں ظاہر کیا جائے اور یہ کہ حق اشاعات کے مذکورہ بالا اطلاع نامے اور اجازت سے متعلق یہ اطلاع نامہ دونوں تائیدی دستاویز میں ظاہر کیے جائیں۔ 

یہ سافٹ ویئر ''جیسا ہے'' کی بنیاد پر، کسی طرح کی براہ راست یا بالواسطہ ضمانت کے بغیر فراہم کیا جاتا ہے جس میں صلاحیت فروخت، کسی مخصوص مقصد کے لیے اس کی موزونیت اور فریق ثالث کے حقوق کی عدم خلاف ورزی کی ضمانتیں شامل ہیں لیکن جو ان تک ہی محدود نہیں ہے۔ حق اشاعت کا مالک یا اس اطلاع نامے میں شامل مالکان حق اشاعت کسی حالت میں بھی کسی دعوے یا خصوصی بالواسطے یا ضمنی نقصانات کے لیے جواب دہ نہیں ہوں گے، یا ایسے کسی بھی قسم کے نقصان کے جو اس کے استعمال سے محرومی، ڈیٹا اور منافع، چاہے وہ کسی عمل کے معاہدے کا نتیجہ ہو، غیر ذمہ داری یا کسی دیگر زیادتی کے عمل پر مبنی ہو اور جو اس سافٹ ویئر سے متعلق ہو یا اس کے استعمال کے نتیجے میں پیدا ہوا ہو۔
 
ما سوا اس کے جو اس اطلاع نامے میں شامل ہے حق اشاعت کے مالک کا نام اس سافٹ ویئرکے اشتہار یا بصورت دیگر اس کی فروخت کے فروغ، استعمال یا دیگر کاروباری معاملات میں حق اشاعت کے مالک کی پیشگی تحریری اجازت کے بغیر استعمال نہیں کیا جا ئے گا۔</translation>
    </message>
    <message numerus="no" id="txt_cp_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">منقطع کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_info_1">
      <source>Nokia and Nokia Connecting People are trademarks or registered trademarks of Nokia Corporation.
 
Copyright 2011 Nokia. All rights reserved. 

This product is based on Symbian^4.

Other product and company names mentioned herein may be trademarks or tradenames of their respective owners. </source>
      <translation variants="no">Nokia اورNokia Connecting People، Nokia Corporationکے ٹریڈ مارک یا رجسٹرڈ ٹریڈ مارک ہیں۔ 

حق اشاعت ۲۰۱۱Nokia۔ جملہ حقوق محفوظ۔ 

یہ پروڈکٹSymbian^۴ پر مبنی ہے۔ یہاں پو مذکورہ دیگر پروڈکٹ اور کمپنیوں کے نام ان کے متعلقہ مالکان کے ٹریڈ مارک یا تجارتی نام ہو سکتے ہیں۔</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_2">
      <source>This product includes API header files originally developed by Netscape Communications Corporation, modified by Nokia by changing certain variables for the  
purpose of porting the file to Symbian operating system on May 1st, 2004, and available in source code form under the Netscape Public License, v1.1 at  
http://www.forum.nokia.com/browserapi.</source>
      <translation variants="no">اس پروڈکٹ میںAPI ہیڈر فائلیں شامل ہیں جنھیں اصلاً نیٹ اسکیپ کمیونیکشنز کارپوریشن نے تیار کیا تھا اور جن میں  Nokiaنے یکم مئی ۲۰۰۴ کو فائل Symbian آپریٹنگ سسٹم میں منتقل کرنے کے مقصد سے بعض متغیروں میں تبدیل کر کے ترمیم کی تھی، اور جو سورس کوڈ کی شکل میںNetscape Public License, v1.1 
 کے تحت 
http://www.forum.nokia.com/browserapi پر دستیاب ہے۔</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_confirm">
      <source>Confirm</source>
      <translation variants="no">ہمیشہ دریافت کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_9">
      <source>Copyright (c) 1983, 1995, 1996 Eric P. Allman
Copyright (c) 1988, 1993
 The Regents of the University of California.  All rights reserved.
Copyright (C) 2007 Nokia Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of the University nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.</source>
      <translation variants="no">حق اشاعت (c) ۱۹۸۳، ۱۹۹۵،۱۹۹۶ Eric P. Allman
 حق اشاعت (c) ۱۹۸۸،۱۹۹۳ 
 The Regents of the University of California۔ جملہ حقوق محفوظ۔ 
حق اشاعت (C) ۲۰۰۷ Nokia Inc. جملہ حقوق محفوظ۔ 

باز تقسیم کاری اور اصل اور دو عنصری شکلوں میں، 
کسی ترمیم کے ساتھ یا اس کے بغیر استعمال کی اجازت دی جاتی ہے بشرطیکہ مندرجہ ذیل شرائط کی پابندی کی جائے:
 ۱۔ اصل کوڈ کی باز تقسیم کاریوں میں مذکورہ بالا اطلاع نامۂ حق اشاعت، شرائط کی اس فہرست اور مندرجہ ذیل اعلان عدم ذمہ داری کو برقرار رکھا جائے۔
۲۔ دو عنصری شکل میں باز تقسیم کاریوں میں مذکورہ بالا حق اشاعت کے اطلاع نامہ کو، شرائط کی اس فہرست کو اورمندرجہ ذیل اعلان عدم ذمہ داری کو دستاویز اور/یا تقسیم کے لیے فراہم کردہ مواد میں نقل کیا جانا چاہیے۔ 

۳۔ نہ تو University کا نام اور نہ ہی اس کے معاونین کے نام مخصوص تحریری پیشگی اجازت کے بغیر اس سافٹ ویئر سے اشتقاق شدہ مصنوعات کی سفارش و فروغ کے لیے استعمال کیا جائے گا۔ یہ سافٹ ویئر 
  The Regents اور ان کے معاونین نے ''جیسا ہے'' کی بنیاد پر فراہم کیا ہے 
 اور کسی بھی قسم کی براہ راست یا بالواسطہ ضمانتیں بشمول صلاحیت فروخت کی بالواسطہ ضمانت سے، لیکن جو اس تک ہی محدود نہیں ہے عدم ذمہ داری کا اعلان کیا جاتا ہے۔ کسی بھی حالت میں THE REGENTS یا معاونین کی براہ راست، بالواسطہ، اتفاقی،
مخصوص مثالی، یا ضمنی نقصانات، (بشمول، متبادل مصنوعات یا خدمات کا حصول؛ استعمال، ڈیٹا یا منافع سے محرومی؛ یا کاروبار میں خلل کی لیکن جو ان تک ہی محدود نہیں) چاہے وہ کسی بھی سبب یا کسی بھی نظریے سے ہوا ہو، کوئی ذمہ داری نہیں ہوگی،  خواہ وہ معاہدے، سخت جواب دہی یا جرمانہ وتلافی کے قانون کے تحت ہو (بشمول عدم توجہی یا بصورت دیگر) جو اس سافٹ ویئر کے استعمال کے سبب وجود میں آئے اور خواہ اس طرح کے ممکنہ نقصان کے بارے میں آگاہ کیا جا چکا ہو۔</translation>
    </message>
    <message numerus="no" id="txt_cp_button_regional_settings">
      <source>Regional settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">علاقائی ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">برتر ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices">
      <source>3rd party notices</source>
      <translation variants="no">تیسرے فریق کے اطلاع نامے</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">زبان اور علاقہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_disabled">
      <source>Disabled</source>
      <translation variants="no">غیر فعال کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_11">
      <source>Copyright (C) 2003, 2004, 2005, 2006 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2006, 2007 Alexey Proskuryakov (ap@nypop.com)
Copyright (C) 2006 Nikolas Zimmermann &lt;zimmermann@kde.org&gt;
Copyright (C) 2006 Samuel Weinig &lt;sam.weinig@gmail.com&gt;
Copyright (C) 2006 James G. Speth (speth@end.com)
Copyright (C) 2006 Jonas Witt &lt;jonas.witt@gmail.com&gt;
Copyright (C) 2006, 2007 Trolltech ASA
Copyright (C) 2005, 2006 Kimmo Kinnunen &lt;kimmo.t.kinnunen@nokia.com&gt;.
Copyright (C) 2006 Zack Rusin &lt;zack@kde.org&gt;
Copyright (C) 2007 Alp Toker &lt;alp@atoker.com&gt;
Copyright (C) 2007 Alp Toker &lt;alp.toker@collabora.co.uk&gt;
Copyright (C) 2007 Graham Dennis (graham.dennis@gmail.com)
Copyright (C) 2006 Don Gibson &lt;dgibson77@gmail.com&gt;
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2007 Holger Hans Peter Freyther
Copyright (C) 2007 Matt Lilek (pewtermoose@gmail.com).
Copyright (C) 2006 David Smith (catfish.man@gmail.com)
Copyright (C) 2006 George Staikos &lt;staikos@kde.org&gt;
Copyright (C) 2006 Simon Hausmann &lt;hausmann@kde.org&gt;
Copyright (C) 2006 Rob Buis &lt;buis@kde.org&gt;
Copyright (C) 2006 Dirk Mueller &lt;mueller@kde.org&gt;
Copyright (C) 2000-2001 Dawit Alemayehu &lt;adawit@kde.org&gt;
Copyright (C) 2006, 2007 Eric Seidel &lt;eric@webkit.org&gt;
Copyright (C) 2005, 2006 Alexander Kellett &lt;lypanov@kde.org&gt;
Copyright (C) 2005 Oliver Hunt &lt;ojh16@student.canterbury.ac.nz&gt;.  All rights reserved.
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2006 Enrico Ros &lt;enrico.ros@m31engineering.it&gt;
Copyright (C) 2007 Staikos Computing Services Inc. &lt;info@staikos.net&gt;
Copyright (C) 2006 Charles Samuels &lt;charles@kde.org&gt;
Copyright (C) 2007 Kevin Ollivier &lt;kevino@theolliviers.com&gt;
Copyright (C) 2007 Robin Dunn.  All rights reserved.
Copyright     2005 Frerich Raabe &lt;raabe@kde.org&gt;
Copyright     2005 Maksim Orlovich &lt;maksim@kde.org&gt;

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the fol</source>
      <translation variants="no">ur #Copyright (C) 2003, 2004, 2005, 2006 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2006, 2007 Alexey Proskuryakov (ap@nypop.com)
Copyright (C) 2006 Nikolas Zimmermann &lt;zimmermann@kde.org&gt;
Copyright (C) 2006 Samuel Weinig &lt;sam.weinig@gmail.com&gt;
Copyright (C) 2006 James G. Speth (speth@end.com)
Copyright (C) 2006 Jonas Witt &lt;jonas.witt@gmail.com&gt;
Copyright (C) 2006, 2007 Trolltech ASA
Copyright (C) 2005, 2006 Kimmo Kinnunen &lt;kimmo.t.kinnunen@nokia.com&gt;.
Copyright (C) 2006 Zack Rusin &lt;zack@kde.org&gt;
Copyright (C) 2007 Alp Toker &lt;alp@atoker.com&gt;
Copyright (C) 2007 Alp Toker &lt;alp.toker@collabora.co.uk&gt;
Copyright (C) 2007 Graham Dennis (graham.dennis@gmail.com)
Copyright (C) 2006 Don Gibson &lt;dgibson77@gmail.com&gt;
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2007 Holger Hans Peter Freyther
Copyright (C) 2007 Matt Lilek (pewtermoose@gmail.com).
Copyright (C) 2006 David Smith (catfish.man@gmail.com)
Copyright (C) 2006 George Staikos &lt;staikos@kde.org&gt;
Copyright (C) 2006 Simon Hausmann &lt;hausmann@kde.org&gt;
Copyright (C) 2006 Rob Buis &lt;buis@kde.org&gt;
Copyright (C) 2006 Dirk Mueller &lt;mueller@kde.org&gt;
Copyright (C) 2000-2001 Dawit Alemayehu &lt;adawit@kde.org&gt;
Copyright (C) 2006, 2007 Eric Seidel &lt;eric@webkit.org&gt;
Copyright (C) 2005, 2006 Alexander Kellett &lt;lypanov@kde.org&gt;
Copyright (C) 2005 Oliver Hunt &lt;ojh16@student.canterbury.ac.nz&gt;.  All rights reserved.
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2006 Enrico Ros &lt;enrico.ros@m31engineering.it&gt;
Copyright (C) 2007 Staikos Computing Services Inc. &lt;info@staikos.net&gt;
Copyright (C) 2006 Charles Samuels &lt;charles@kde.org&gt;
Copyright (C) 2007 Kevin Ollivier &lt;kevino@theolliviers.com&gt;
Copyright (C) 2007 Robin Dunn.  All rights reserved.
Copyright     2005 Frerich Raabe &lt;raabe@kde.org&gt;
Copyright     2005 Maksim Orlovich &lt;maksim@kde.org&gt;

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the fol</translation>
    </message>
    <message numerus="no" id="txt_cp_title_end_encryption">
      <source>End encryption</source>
      <translation variants="no">رمز نگاری ختم کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_8">
      <source>Copyright (c) 1996-1998
Silicon Graphics Computer Systems, Inc.

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Silicon Graphics makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</source>
      <translation variants="no">حق اشاعت (c) ۱۹۹۸- ۱۹۹۶
 Silicon Graphics Computer Systems, Inc. 

اس سافٹ ویئر کو استعمال کرنے، اسے نقل کرنے، اس میں ترمیم کرنے اسے تقسیم اور فروخت کرنے اور اس کی دستاویز کاری کی اجازت بذریعۂ ہذا کسی معاوضے کے بغیر دی جاتی ہے بشرطیکہ مذکورہ بالا اطلاع نامہ حق اشاعت کے تمام نسخوں میں ظاہر ہو اور یہ کہ وہ اطلاع نامۂ حق اشاعت اور یہ اجازت نامہ تائیدی دستاویزات میں بھی شامل کیے جائیں۔Silicon Graphics کسی بھی مقصد سے اس سافٹ ویئر کی موزونیت کے بارے میں کوئی ضمانت نہیں دیتی۔ یہ ''جیسا ہے'' کی بنیاد پر براہ راست یا بالواسطہ ضمانت کے بغیر فراہم کیا گیا ہے۔</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_disabled">
      <source>Disabled</source>
      <translation variants="no">غیر فعال کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices">
      <source>Open source software notices</source>
      <translation variants="no">اوپن سورس  سافٹ ویئر اطلاع نامے</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">گھنٹی والیوم</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language_val_non">
      <source>None</source>
      <translation variants="no">کوئی نہیں</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_14">
      <source>Copyright (c) 1998 - 2008, Paul Johnston &amp; Contributors
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of the author nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">حق اشاعت (c) ۱۹۹۸ – ۲۰۰۸، پال جانسن اور معاونین
جملہ حقوق محفوظ ۔ 

باز تقسیم کاریوں اور اصل اور دو عنصری شکلوں میں، 
کسی ترمیم کے ساتھ یا اس کے بغیر استعمال کی اجازت دی جاتی ہے بشرطیکہ مندرجہ ذیل شرائط کی پابندی کی جائے:
 اصل کوڈ کی باز تقسیم کاریوں میں مذکورہ بالا اطلاع نامۂ حق اشاعت، شرائط کی اس فہرست اور مندرجہ ذیل اعلان عدم ذمہ داری کو برقرار رکھا جائے۔
 دو عنصری شکل میں باز تقسیم کاری میں مذکورہ بالا حق اشاعت کے اطلاع نامہ کو، شرائط کی اس فہرست کو اورمندرجہ ذیل اعلان عدم ذمہ داری کو دستاویز اور/یا تقسیم کے لیے فراہم کردہ مواد میں نقل کیا جانا چاہیے۔ 

 نہ تومصنف کا نام اور نہ ہی اس کے معاونین کے نام مخصوص تحریری پیشگی اجازت کے بغیر اس سافٹ ویئر سے اشتقاق شدہ مصنوعات کی سفارش و فروغ کے لیے استعمال کیا جائے گا۔ یہ سافٹ ویئر 
حق اشاعت کے مالکان اور معاونین نے ''جیسا ہے'' کی بنیاد پر فراہم کیا ہے 
 اور کسی بھی قسم کی براہ راست یا بالواسطہ ضمانتیں بشمول صلاحیت فروخت کی بالواسطہ ضمانت سے، لیکن جو اس تک ہی محدود نہیں ہے عدم ذمہ داری کا اعلان کیا جاتا ہے۔ کسی بھی حالت میں حق اشاعت کے مالکان یا معاونین کی، براہ راست، بالواسطہ، اتفاقی،
مخصوص مثالی، یا ضمنی نقصانات، (بشمول، متبادل مصنوعات یا خدمات کا حصول؛ استعمال، ڈیٹا یا منافع سے محرومی؛ یا کاروبار میں خلل) چاہے وہ کسی بھی سببیا کسی بھی نظریے سے ہوا ہو،کوئی ذمہ داری نہیں ہوگی، خواہ وہ معاہدے، سخت جواب دہی یا جرمانہ و تلافی کے قانون کے تحت ہو (بشمول عدم توجہی یا بصورت دیگر) جو اس سافٹ ویئر کے استعمال کے سبب وجود میں آئے اور خواہ اس طرح کے ممکنہ نقصان کے بارے میں آگاہ کیا جا چکا ہو۔</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_3">
      <source>Copyright (C) 2005 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2007 Apple Inc.  All rights reserved.
Copyright (C) 2007 Nokia Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without

modification, are permitted provided that the following conditions
are met:

1.  Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer. 
2.  Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution. 
3.  Neither the name of Apple Computer, Inc. ("Apple") nor the names of
    its contributors may be used to endorse or promote products derived
    from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE AND ITS CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL APPLE OR ITS CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">حق اشاعت (C) ۲۰۰۵Apple Computer, Inc. ۔ جملہ حقوق محفوظ ۔ 
حق اشاعت (C) ۲۰۰۷ Apple Inc. جملہ حقوق محفوظ۔
 حق اشاعت (C) ۲۰۰۷Nokia Inc. ۔ جملہ حقوق محفوظ۔

باز تقسیم کاری اور اصل اور دو عنصری شکلوں میں، 
کسی ترمیم کے ساتھ یا اس کے بغیر استعمال کی اجازت دی جاتی ہے بشرطیکہ مندرجہ ذیل شرائط کی پابندی کی جائے:
 ۱۔ اصل کوڈ کی باز تقسیم کاریوں میں مذکورہ بالا اطلاع نامۂ حق اشاعت، شرائط کی اس فہرست اور مندرجہ ذیل اعلان عدم ذمہ داری کو برقرار رکھا جائے۔
۲۔ دو عنصری شکل میں باز تقسیم کاری میں مذکورہ بالا حق اشاعت کے اطلاع نامہ کو، شرائط کی اس فہرست کو اورمندرجہ ذیل اعلان عدم ذمہ داری کو دستاویز اور/یا تقسیم کے لیے فراہم کردہ مواد میں نقل کیا جانا چاہیے۔ 

۳۔ نہ تو Apple Computer, Inc.  کا نام("Apple")  اور نہ ہی اس کے معاونین کے نام مخصوص تحریری پیشگی اجازت کے بغیر اس سافٹ ویئر سے اشتقاق شدہ مصنوعات کی سفارش و فروغ کے لیے استعمال کیے جائیں گے۔ یہ سافٹ ویئر APPLE  اور اس کے معاونین نے ''جیسا ہے'' کی بنیاد پر فراہم کیا ہے 
 اور کسی بھی قسم کی براہ راست یا بالواسطہ ضمانتیں بشمول صلاحیت فروخت کی بالواسطہ ضمانت سے، لیکن جو اس تک ہی محدود نہیں ہے، عدم ذمہ داری کا اعلان کیا جاتا ہے۔ کسی بھی حالت میں APPLE  یا اس کے معاونین کی، براہ راست، بالواسطہ، اتفاقی،
مخصوص مثالی، یا ضمنی نقصانات، (بشمول، متبادل مصنوعات یا خدمات کا حصول؛ استعمال، ڈیٹا یا منافع سے محرومی؛ یا کاروبارمیں خلل کی لیکن جو ان تک ہی محدود نہیں) چاہے وہ کسی بھی سبب یا نظریے سے ہوا ہو، کوئی ذمہ داری نہیں ہوگی خواہ وہ معاہدے، سخت جواب دہی یا جرمانہ و تلافی کے قانون کے تحت ہو (بشمول عدم توجہی یا بصورت دیگر) جو اس سافٹ ویئر کے استعمال کے سبب وجود میں آئے اور خواہ اس طرح کے ممکنہ نقصان کے بارے میں آگاہ کیا جا چکا ہو۔</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_open_source_software_notices">
      <source>Open source software notices</source>
      <translation variants="yes">
        <lengthvariant priority="1">اوپن سورس سافٹ ویئر اطلاع نامے</lengthvariant>
        <lengthvariant priority="2">اوپن سو. سا. ویئر اط. نامے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_your_region">
      <source>Select your region:</source>
      <translation variants="no">اپنا علاقہ منتخب کریں:</translation>
    </message>
    <message numerus="no" id="txt_cp_button_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">آف لائن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_type">
      <source>Type</source>
      <translation variants="no">قسم</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_13">
      <source>Open Dynamics Engine
Copyright (c) 2001-2004, Russell L. Smith.
All rights reserved.

Redistribution and use in source and binary forms, 
with or without modification, are permitted provided
that the following conditions are met:

Redistributions of source code must retain the above 
copyright notice, this list of conditions and the 
following disclaimer.

Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or 
other materials provided with the distribution.

Neither the names of ODE's copyright owner nor the 
names of its contributors may be used to endorse or 
promote products derived from this software without 
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS 
AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.</source>
      <translation variants="no">Open Dynamics Engine
حق اشاعت (c) ۲۰۰۱-۲۰۰۴، رسل ایل اسمتہ۔ جملہ حقوق محفوظ ۔ 

باز تقسیم کاریوں اور اصل اور دو عنصری شکلوں میں، 
کسی ترمیم کے ساتھ یا اس کے بغیر استعمال کی اجازت دی جاتی ہے بشرطیکہ مندرجہ ذیل شرائط کی پابندی کی جائے: 
اصل کوڈ کی باز تقسیم کاریوں میں مذکورہ بالا اطلاع نامۂ حق اشاعت، شرائط کی اس فہرست اور مندرجہ ذیل اعلان عدم ذمہ داری کو برقرار رکھا جائے۔ 
دو عنصری شکل میں باز تقسیم کاری میں مذکورہ بالا حق اشاعت کے اطلاع نامہ کو، شرائط کی اس فہرست کو اورمندرجہ ذیل اعلان عدم ذمہ داری کو دستاویز اور/یا تقسیم کے لیے فراہم کردہ مواد میں نقل کیا جانا چاہیے۔ 

نہ تو ODEکے حق اشاعت کے مالک کے نام اور نہ ہی اسی کے معاونین کا نام مخصوص تحریری پیشگی اجازت کے بغیر اس سافٹ ویئر سے اشتقاق شدہ مصنوعات کی سفارش و فروغ کے لیے استعمال کیے جائیں گے۔ یہ سافٹ ویئر 
حق اشاعت کے مالکان اور معاونین نے ''جیسا ہے'' کی بنیاد پر فراہم کیا ہے 
 اور کسی بھی قسم کی براہ راست یا بالواسطہ ضمانتیں بشمول صلاحیت فروخت کی بالواسطہ ضمانت سے، لیکن جو اس تک ہی محدود نہیں ہے عدم ذمہ داری کا اعلان کیا جاتا ہے۔ کسی بھی حالت میں حق اشاعت کے مالکان یا معاونین کی، براہ راست، بالواسطہ، اتفاقی،
مخصوص مثالی، یا ضمنی نقصانات، (بشمول،  متبادل مصنوعات یا خدمات کا حصول؛ استعمال، ڈیٹا یا منافع سے محرومی؛ یا کاروبار میں خلل کی لیکن جو ان تک ہی محدود نہیں) چاہے وہ کسی بھی سبب یا کسی بھی نظریے سے ہوا ہو، کوئی ذمہ داری نہیں ہوگی یا خواہ وہ معاہدے، سخت جواب دہی یا جرمانہ و تلافی کے قانون کے تحت ہو (بشمول عدم توجہی یا بصورت دیگر) جو اس سافٹ ویئر کے استعمال کے سبب وجود میں آئے اور خواہ اس طرح کے ممکنہ نقصان کے بارے میں آگاہ کیا جا چکا ہو۔</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_tones">
      <source>Get more from Ovi</source>
      <translation variants="yes">
        <lengthvariant priority="1">گھنٹی کی ٹون حاصل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_cp_title_profile">
      <source>Profile</source>
      <translation variants="no">پروفائل منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_display_language">
      <source>Display language</source>
      <translation variants="no">زبان ظاہر کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_button_end">
      <source>End</source>
      <translation variants="no">ختم کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروفائل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_original_settings_will_be_restored_no">
      <source>Original settings will be restored. No data will be deleted.</source>
      <translation variants="no">اصل ترتیبات بحال ہو جائیں گی۔ کوئی ڈیٹا نہیں مٹے گا۔</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_3rd_party_notices">
      <source>3rd party notices</source>
      <translation variants="yes">
        <lengthvariant priority="1">فریق ثالث کے اطلاع نامے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset_val_reset_device">
      <source>Reset device</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلہ باز مرتب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_edit_name">
      <source>Edit name</source>
      <translation variants="no">نام ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_1">
      <source>Java and all Java-based marks are trademarks or registered trademarks of Sun Microsystems, Inc.
JavaTM ME environment: MIDP 2.1, CLDC 1.1.</source>
      <translation variants="no">Java اور Java پر مبنی تمام علامات Sun Microsystems, Inc کے ٹریڈ مارک یا رجسٹرڈ ٹریڈ مارک ہیں۔ 
JavaTM ME environment: MIDP 2.1, CLDC 1.1۔</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_001">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_all_data_will_be_deleted_and_factory_s">
      <source>All data will be deleted and factory settings will be restored. Ejectable memory card data is not deleted.</source>
      <translation variants="no">تمام ڈیٹا مٹ جائے گا اور فیکٹری ترتیبات بحال ہو جائیں گی۔ قابل علاحدگی حافظہ کارڈ کا ڈیٹا نہیں مٹے گا۔</translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices_1">
      <source>This product includes certain open source software. The exact terms of the licenses, disclaimers, acknowledgements and notices are provided below. Nokia offers to provide you with the source code as defined in the applicable license. 

Please send an e-mail to sourcecode.request@nokia.com or a written request to:

Source Code Requests
Nokia Corporation
P.O.Box 407
FI-00045 Nokia Group
Finland

This offer is valid for a period of three (3) years from the date of the distribution of this product by Nokia.</source>
      <translation variants="no">اس پروڈکٹ میں بعض اوپن سورس سافٹ ویئر شامل ہیں۔ لائسنسوں، اعلانات عدم ذمہ داری، اعترفات اور اطلاع ناموں کی اصل شرائط ذیل میں فراہم کی گئی ہیں۔  Nokiaآپ کو قابل اطلاق لائسنس میں وضاحت کردہ سورس  کوڈ کی فراہمی کی پیشکش کرتا ہے۔

براہ کرم sourcecode.request@nokia.com  پر ای میل کریں یا

Source Code Requests
Nokia Corporation
P.O.Box 407
FI-00045 Nokia Group
Finland

 کو تحریری درخواست ارسال کریں۔

 یہ پیشکش Nokia کی جانب سےاس پروڈکٹ کی تقسیم کی تاریخ سے تین (3) سال تک کے لیے کارآمد ہے۔</translation>
    </message>
    <message numerus="no" id="txt_cp_info_data_encryption_ongoing_enryption_mus">
      <source>Data encryption ongoing. Enryption must be ended before reset.  End data enrcyption?</source>
      <translation variants="no">ڈیٹا رمز نگاری جاری۔ رمز نگاری باز مرتبی سے پہلے ختم کی جانی چاہیے۔ ڈیٹا کی رمز نگاری ختم کریں؟</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_software_version">
      <source>Software version</source>
      <translation variants="no">سافٹ ویئر ورژن</translation>
    </message>
    <message numerus="no" id="txt_cp_list_notification_tones">
      <source>Notification tones</source>
      <translation variants="no">اطلاع نامے کی ٹونز</translation>
    </message>
    <message numerus="no" id="txt_cp_text_edit_device_will_be_restarted_to_chang">
      <source>Device will be restarted to change display language. Continue?</source>
      <translation variants="no">ڈسپلے کی زبان بدلنے پر اپنے آلے کو دوبارہ شروع کرنا ہوگا۔ جاری رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active">
      <source>Silent state active</source>
      <translation variants="no">خاموش حالت کارآمد</translation>
    </message>
  </context>
</TS>