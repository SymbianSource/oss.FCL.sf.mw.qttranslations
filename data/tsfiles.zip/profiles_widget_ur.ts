<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_profileswidget_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">میٹنگ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_profileswidget_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">عام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_profileswidget_list_silent">
      <source>Silent</source>
      <translation variants="no">خاموش</translation>
    </message>
  </context>
</TS>