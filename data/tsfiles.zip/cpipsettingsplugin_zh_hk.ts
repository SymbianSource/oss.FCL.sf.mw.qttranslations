<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_subhead_network_settings">
      <source>Network settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">網絡設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_network_settings">
      <source>Network settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">網絡設定</lengthvariant>
      </translation>
    </message>
  </context>
</TS>