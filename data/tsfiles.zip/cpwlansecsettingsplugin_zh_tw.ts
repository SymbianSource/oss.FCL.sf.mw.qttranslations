<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wapi">
      <source>WAPI</source>
      <translation variants="no">WAPI</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_use">
      <source>WEP key in use</source>
      <translation variants="no">使用中的WEP金鑰</translation>
    </message>
    <message numerus="no" id="txt_occ_hexadecimal">
      <source>Hexadecimal</source>
      <translation variants="no">十六進位</translation>
    </message>
    <message numerus="no" id="txt_occ_preshared_key_format">
      <source>Pre-shared key format</source>
      <translation variants="no">預先共用金鑰格式</translation>
    </message>
    <message numerus="no" id="txt_occ_button_eap_type_settings">
      <source>EAP type settings</source>
      <translation variants="no">EAP類型設定</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_client_cert_not_defined">
      <source>(not defined)</source>
      <translation variants="no">未定義</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_root_certificate">
      <source>WAPI root certificate</source>
      <translation variants="no">WAPI根憑證</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_authentication">
      <source>WAPI authentication</source>
      <translation variants="no">WAPI驗證</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2">
      <source>Authentication mode</source>
      <translation variants="no">驗證模式</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unencrypted_connection_val_allowe">
      <source>Allowed</source>
      <translation variants="no">允許</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2_val_eap">
      <source>EAP</source>
      <translation variants="no">EAP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">預先共用金鑰：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2_val_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">預先共用金鑰</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_client_certificate">
      <source>WAPI client certificate</source>
      <translation variants="no">WAPI用戶端憑證</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_type">
      <source>EAP type</source>
      <translation variants="no">EAP類型</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_preshared_key_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">未定義</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_root_cert_not_defined">
      <source>(not defined)</source>
      <translation variants="no">未定義</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpa2_only">
      <source>WPA2 only</source>
      <translation variants="no">僅WPA2模式</translation>
    </message>
    <message numerus="no" id="txt_occ_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">預先共用金鑰</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_security_settings">
      <source>Security settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">安全性設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wep">
      <source>WEP</source>
      <translation variants="no">WEP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_4">
      <source>#4</source>
      <translation variants="no">#4</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_3">
      <source>#3</source>
      <translation variants="no">#3</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpawpa2">
      <source>WPA/WPA2</source>
      <translation variants="no">WPA/WPA2</translation>
    </message>
    <message numerus="no" id="txt_occ_ascii">
      <source>ASCII</source>
      <translation variants="no">ASCII</translation>
    </message>
    <message numerus="no" id="txt_occ_certificate">
      <source>Certificate</source>
      <translation variants="no">憑證</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_2">
      <source>#2</source>
      <translation variants="no">#2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unencrypted_connection">
      <source>Unencrypted connection</source>
      <translation variants="no">未加密的連線</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_1">
      <source>#1</source>
      <translation variants="no">#1</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_8021x">
      <source>802.1X</source>
      <translation variants="no">802.1X</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_2">
      <source>WEP key #2</source>
      <translation variants="no">WEP金鑰#2：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_4">
      <source>WEP key #4</source>
      <translation variants="no">WEP金鑰#4：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_1">
      <source>WEP key #1</source>
      <translation variants="no">WEP金鑰#1：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_3">
      <source>WEP key #3</source>
      <translation variants="no">WEP金鑰#3：</translation>
    </message>
    <message numerus="no" id="txt_occ_button_remove_certificate_store">
      <source>Remove certificate store</source>
      <translation variants="no">移除憑證儲存</translation>
    </message>
  </context>
</TS>