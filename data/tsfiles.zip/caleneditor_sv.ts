<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="sv">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">Spara inte ändringar</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event ?</source>
      <translation variants="no">Radera heldagspost?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_at_the_start">
      <source>At the start</source>
      <translation variants="no">Vid start</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_end_time">
      <source>End time</source>
      <translation variants="no">Sluttid</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_workdays">
      <source>Workdays</source>
      <translation variants="no">Arbetsdagar</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_start_time">
      <source>Start time</source>
      <translation variants="no">Starttid</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Ändra:</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Alla tillfällen</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Monthly</source>
      <translation variants="no">Varje månad</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_time">
      <source>Reminder time</source>
      <translation variants="no">Alarmtid</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Att göra-anteckning</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_off">
      <source>Off</source>
      <translation variants="no">Av</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_2_days_before">
      <source>2 days before</source>
      <translation variants="no">2 dagar innan</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Daily</source>
      <translation variants="no">Varje dag</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Repeat</source>
      <translation variants="no">Repetera</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Reminder</source>
      <translation variants="no">Alarm</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Only once</source>
      <translation variants="no">Repeteras ej</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_description">
      <source>Description</source>
      <translation variants="no">Beskrivning</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_30_minutes_befo">
      <source>30 minutes before</source>
      <translation variants="no">30 minuter innan</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">Repetera till</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Weekly</source>
      <translation variants="no">Varje vecka</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Radera repeterad post:</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>All day event</source>
      <translation variants="no">Hela dagen</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">Lägg till beskrivning</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_15_minutes_befo">
      <source>15 minutes before</source>
      <translation variants="no">15 minuter innan</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_5_minutes_befor">
      <source>5 minutes before</source>
      <translation variants="no">5 minuter innan</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_day_before">
      <source>1 day before</source>
      <translation variants="no">1 dag innan</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Start date</source>
      <translation variants="no">Startdatum</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Start time</source>
      <translation variants="no">Starttid</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_hour_before">
      <source>1 hour before</source>
      <translation variants="no">1 timme innan</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entry">
      <source>Delete entry?</source>
      <translation variants="no">Radera post?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_on_event_day">
      <source>On event day</source>
      <translation variants="no">Vid dagen för händelsen</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>End date</source>
      <translation variants="no">Slutdatum</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_meeting_saved">
      <source>New meeting saved</source>
      <translation variants="no">Nytt möte sparat</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Location</source>
      <translation variants="no">Plats</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_fortnightly">
      <source>Fortnightly</source>
      <translation variants="no">Var fjortonde dag</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Delete entries ?</source>
      <translation variants="no">Radera poster?</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">Ämne</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_event">
      <source>New event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ny post</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Yearly</source>
      <translation variants="no">Varje år</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">Ta bort beskrivning</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_all_day_event_updated">
      <source>All day event updated</source>
      <translation variants="no">Heldagspost uppdaterad</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Möte</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">Radera möte?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">Repetera till</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_meeting_updated">
      <source>Meeting updated</source>
      <translation variants="no">Möte uppdaterat</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_all_day_event_saved">
      <source>New All day event saved</source>
      <translation variants="no">Ny heldagspost sparad</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Endast detta tillfälle</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>End time</source>
      <translation variants="no">Sluttid</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_all_day_event">
      <source>All day event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Heldagspost</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_location_updated_keep_existing">
      <source>Location updated. Keep existing location on map ?</source>
      <translation variants="no">Plats uppdaterad. Behålla befintlig plats på karta?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kalender</lengthvariant>
      </translation>
    </message>
  </context>
</TS>