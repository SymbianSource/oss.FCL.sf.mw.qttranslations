<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_info_provisioning_not_successful_reactiv">
      <source>Provisioning not successful. Re-activate provisioning in settings.</source>
      <translation variants="no">zh_hk #Provisioning not successful. Re-activate provisioning in settings.</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="no">zh_hk #Verify password:</translation>
    </message>
    <message numerus="no" id="txt_occ_info_install_pac_from_server_1">
      <source>Install PAC from server '%1'?</source>
      <translation variants="no">zh_hk #Install PAC from server '%1'?</translation>
    </message>
    <message numerus="no" id="txt_occ_title_1_message">
      <source>%1 message:</source>
      <translation variants="no">zh_hk #%1 message:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_user_name">
      <source>%1 user name:</source>
      <translation variants="no">zh_hk #%1 user name:</translation>
    </message>
    <message numerus="no" id="txt_occ_info_eapmschapv2_password_has_expired_yo">
      <source>EAP-MSCHAPv2 password has expired. You must create a new one.</source>
      <translation variants="no">zh_hk #EAP-MSCHAPv2 password has expired. You must create a new one.</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_new_eapmschapv2_password">
      <source>New EAP-MSCHAPv2 password:</source>
      <translation variants="no">zh_hk #New EAP-MSCHAPv2 password:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="no">zh_hk #PAC store password:</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_unauthenticated_provisioning_in_p">
      <source>Unauthenticated provisioning in progress</source>
      <translation variants="no">zh_hk #Unauthenticated provisioning in progress</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_create_password_for_encrypted_pac_s">
      <source>Create password for encrypted PAC store:</source>
      <translation variants="no">zh_hk #Create password for encrypted PAC store:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_file_password_for_1">
      <source>PAC file password for '%1':</source>
      <translation variants="no">zh_hk #PAC file password for '%1':</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_password">
      <source>Password:</source>
      <translation variants="no">zh_hk #Password:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_old_eapmschapv2_password">
      <source>Old EAP-MSCHAPv2 password:</source>
      <translation variants="no">zh_hk #Old EAP-MSCHAPv2 password:</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_authenticated_provisioning_in_pro">
      <source>Authenticated provisioning in progress</source>
      <translation variants="no">zh_hk #Authenticated provisioning in progress</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_password">
      <source>%1 password:</source>
      <translation variants="no">zh_hk #%1 password:</translation>
    </message>
  </context>
</TS>