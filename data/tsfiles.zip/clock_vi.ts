<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clk_menu_show_on_homescreen">
      <source>Show on homescreen</source>
      <translation variants="no">H.thị trên M.hình chính</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_set_as_current_location">
      <source>Set as current location</source>
      <translation variants="no">Đặt làm vị trí hiện tại</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hr_2_min">
      <source>%1 hr %2 min</source>
      <translation variants="no">vi #%1 hr %2 min</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hrs_2_min">
      <source>%1 hrs %2 min</source>
      <translation variants="no">vi #%1 hrs %2 min</translation>
    </message>
    <message numerus="yes" id="txt_clock_dblist_daily_val_ln_mins">
      <source>%Ln mins</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_inactive">
      <source>Inactive</source>
      <translation variants="no">vi #Inactive</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_gmt">
      <source>GMT</source>
      <translation variants="no">vi #GMT</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_add_city">
      <source>Add city</source>
      <translation variants="no">vi #Add city</translation>
    </message>
    <message numerus="yes" id="txt_clock_dblist_daily_val_ln_hr">
      <source>%Ln hr</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_title_clock">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Clock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_no_alarms_set">
      <source>No alarms set</source>
      <translation variants="yes">
        <lengthvariant priority="1">(chưa đặt báo thức)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy">
      <source>mm dd yyyy</source>
      <translation variants="no">tt nn nnnn</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_menu_delete_alarm">
      <source>Delete alarm</source>
      <translation variants="no">Xóa âm báo</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy">
      <source>dd mm yyyy</source>
      <translation variants="no">nn tt nnnn</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_settings">
      <source>Settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2mins">
      <source>In %1hrs %2mins</source>
      <translation variants="no">vi ##In %1hrs %2mins</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_activated">
      <source>Alarm Activated</source>
      <translation variants="no">Đã kích hoạt âm báo</translation>
    </message>
    <message numerus="no" id="txt_short_caption_clock">
      <source>Clock</source>
      <translation variants="no">Đồng hồ</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2mins">
      <source>In %1hr %2mins</source>
      <translation variants="no">vi ##In %1hr %2mins</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_deactivated">
      <source>Alarm Deactivated</source>
      <translation variants="no">Đã tắt âm báo</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hrs_2_mins">
      <source>%1 hrs %2 mins</source>
      <translation variants="no">vi ##%1 hrs %2 mins</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2min">
      <source>In %1hr %2min</source>
      <translation variants="no">vi ##In %1hr %2min</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1days">
      <source>In %1days</source>
      <translation variants="no">vi ##In %1days</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily">
      <source>Daily</source>
      <translation variants="no">vi ##Daily</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_workdays">
      <source>Workdays</source>
      <translation variants="no">vi ##Workdays</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_world_clock">
      <source>World Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đồng hồ thế giới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd">
      <source>yyyy mm dd</source>
      <translation variants="no">nnnn tt nn</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_delete">
      <source>Delete</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2min">
      <source>In %1hrs %2min</source>
      <translation variants="no">vi ##In %1hrs %2min</translation>
    </message>
    <message numerus="no" id="txt_long_caption_clock">
      <source>Clock</source>
      <translation variants="no">Đồng hồ</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hr_2_mins">
      <source>%1 hr %2 mins</source>
      <translation variants="no">vi ##%1 hr %2 mins</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_every_1">
      <source>Every %1</source>
      <translation variants="no">vi ##Every %1</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_today">
      <source>Today</source>
      <translation variants="no">vi ##Today</translation>
    </message>
  </context>
</TS>