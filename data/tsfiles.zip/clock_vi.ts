<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hr_2_mins">
      <source>%1 hr %2 mins</source>
      <translation variants="no">vi ##%1 hr %2 mins</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_mins">
      <source>%1 mins</source>
      <translation variants="no">vi ##%1 mins</translation>
    </message>
    <message numerus="no" id="txt_common_common_gmt">
      <source>GMT</source>
      <translation variants="no">vi ##GMT</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_every_1">
      <source>Every %1</source>
      <translation variants="no">vi ##Every %1</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_today">
      <source>Today</source>
      <translation variants="no">vi ##Today</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2mins">
      <source>In %1hrs %2mins</source>
      <translation variants="no">vi ##In %1hrs %2mins</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_activated">
      <source>Alarm Activated</source>
      <translation variants="no">vi #Alarm activated</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_button_new_alarm">
      <source>New alarm</source>
      <translation variants="no">vi ##New alarm</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_gmt_1">
      <source>GMT %1</source>
      <translation variants="no">vi ##GMT %1</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_deactivated">
      <source>Alarm Deactivated</source>
      <translation variants="no">vi #Alarm deactivated</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hrs_2_mins">
      <source>%1 hrs %2 mins</source>
      <translation variants="no">vi ##%1 hrs %2 mins</translation>
    </message>
    <message numerus="no" id="txt_common_common_clock">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Clock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2mins">
      <source>In %1hr %2mins</source>
      <translation variants="no">vi ##In %1hr %2mins</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_hr">
      <source>%1 hr</source>
      <translation variants="no">vi ##%1 hr</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2min">
      <source>In %1hr %2min</source>
      <translation variants="no">vi ##In %1hr %2min</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1days">
      <source>In %1days</source>
      <translation variants="no">vi ##In %1days</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_workdays">
      <source>Workdays</source>
      <translation variants="no">vi ##Workdays</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_world_clock">
      <source>World Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #World clock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_occurence">
      <source>Not specified</source>
      <translation variants="no">vi #Repeat</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_repeat_weekly">
      <source>Not specified</source>
      <translation variants="no">vi #Weekly</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_sunday">
      <source>Not specified</source>
      <translation variants="no">vi #Sunday</translation>
    </message>
    <message numerus="no" id="txt_clock_button_regional_date_time_settings">
      <source>Not specified</source>
      <translation variants="no">vi #Advanced settings</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_seperator">
      <source>Not specified</source>
      <translation variants="no">vi #Date separator:</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_sunday">
      <source>Not specified</source>
      <translation variants="no">vi #Sunday</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_title_clock">
      <source>Not specified</source>
      <translation variants="no">vi #Clock</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_day">
      <source>Not specified</source>
      <translation variants="no">vi #Day</translation>
    </message>
    <message numerus="no" id="txt_clk_list_grytviken_south_georgia">
      <source>Grytviken, South Georgia</source>
      <translation variants="no">Grytviken, Nam Georgia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_baltimore_md_usa">
      <source>Baltimore, MD, United States of America</source>
      <translation variants="no">Baltimore, MD, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_phnom_penh_cambodia">
      <source>Phnom Penh, Cambodia</source>
      <translation variants="no">Phnôm Pênh, Campuchia</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_exit">
      <source>Exit</source>
      <translation variants="no">Thoát</translation>
    </message>
    <message numerus="no" id="txt_clk_list_port_louis_mauritius">
      <source>Port Louis, Mauritius</source>
      <translation variants="no">Port Louis, Mauritius</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_24_hour">
      <source>Not specified</source>
      <translation variants="no">vi #24-hour</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_friday">
      <source>Not specified</source>
      <translation variants="no">vi #Friday</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_opt_exit">
      <source>Not specified</source>
      <translation variants="no">vi #Exit</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_monday">
      <source>Not specified</source>
      <translation variants="no">vi #Monday</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_alarm">
      <source>Not specified</source>
      <translation variants="no">vi #Alarm</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_tuesday">
      <source>Not specified</source>
      <translation variants="no">vi #Tuesday</translation>
    </message>
    <message numerus="no" id="txt_clk_list_san_jose_costa_rica">
      <source>San Jose, Costa Rica</source>
      <translation variants="no">San Jose, Costa Rica</translation>
    </message>
    <message numerus="no" id="txt_clk_list_fort_de_france_martinique">
      <source>Fort-de-France, Martinique</source>
      <translation variants="no">Fort-de-France, Martinique</translation>
    </message>
    <message numerus="no" id="txt_clk_list_choibalsan_mongolia">
      <source>Choibalsan, Mongolia</source>
      <translation variants="no">Choybalsan, Mông Cổ</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_once">
      <source>Not specified</source>
      <translation variants="no">vi #Not repeated</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nuuk_greenland">
      <source>Nuuk, Greenland</source>
      <translation variants="no">Nuuk, Greenland</translation>
    </message>
    <message numerus="no" id="txt_clk_list_luxembourg_city_luxembourg">
      <source>Luxembourg City, Luxembourg</source>
      <translation variants="no">Luxembourg, Luxembourg</translation>
    </message>
    <message numerus="no" id="txt_clock_subtitle_alarm">
      <source>Not specified</source>
      <translation variants="no">vi #Alarm</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_daylight_saving_time">
      <source>Not specified</source>
      <translation variants="no">vi #Daylight saving time</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_monday">
      <source>Not specified</source>
      <translation variants="no">vi #Monday</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_on">
      <source>Not specified</source>
      <translation variants="no">vi #On</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_list_no_alarms_set">
      <source>Not specified</source>
      <translation variants="no">vi #(no alarms set)</translation>
    </message>
    <message numerus="no" id="txt_clock_button_cityname_countryname">
      <source>Not specified</source>
      <translation variants="no">vi #Select city</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_time_format">
      <source>Not specified</source>
      <translation variants="no">vi #Time format:</translation>
    </message>
    <message numerus="no" id="txt_clk_list_adelaide_aus">
      <source>Adelaide, Australia</source>
      <translation variants="no">Adelaide, Úc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_moscow_russia">
      <source>Moscow, Russia</source>
      <translation variants="no">Moscow, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kathmandu_nepal">
      <source>Kathmandu, Nepal</source>
      <translation variants="no">Kathmandu, Nepal</translation>
    </message>
    <message numerus="no" id="txt_clk_list_stanley_falkland_isl">
      <source>Stanley, Falkland Islands</source>
      <translation variants="no">Stanley, Quần đảo Falkland</translation>
    </message>
    <message numerus="no" id="txt_clk_list_eucla_aus">
      <source>Eucla, Australia</source>
      <translation variants="no">Eucla, Úc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ankara_turkey">
      <source>Ankara, Turkey</source>
      <translation variants="no">Ankara, Thổ Nhĩ Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_campo_grande_brazil">
      <source>Campo Grande, Brazil</source>
      <translation variants="no">Campo Grande, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_workdays">
      <source>Not specified</source>
      <translation variants="no">vi #Workdays:</translation>
    </message>
    <message numerus="no" id="txt_clk_list_time">
      <source>&lt;time&gt;</source>
      <translation variants="no">Thời gian</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mumbai_india">
      <source>Mumbai, India</source>
      <translation variants="no">Mumbai, Ấn Độ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_manaus_brazil">
      <source>Manaus, Brazil</source>
      <translation variants="no">Manaus, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_doha_qatar">
      <source>Doha, Qatar</source>
      <translation variants="no">Doha, Qatar</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_friday">
      <source>Not specified</source>
      <translation variants="no">vi #Friday</translation>
    </message>
    <message numerus="no" id="txt_clock_subtitle_new_alarm">
      <source>Not specified</source>
      <translation variants="no">vi #New alarm</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bern_switz">
      <source>Bern, Switzerland</source>
      <translation variants="no">Bern, Thụy Sĩ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ljubljana_slovenia">
      <source>Ljubljana, Slovenia</source>
      <translation variants="no">Ljubljana, Slovenia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_pensacola_fl_usa">
      <source>Pensacola, FL, United States of America</source>
      <translation variants="no">Pensacola, FL, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_beirut_lebanon">
      <source>Beirut, Lebanon</source>
      <translation variants="no">Beirut, Lebanon</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tunis_tunisia">
      <source>Tunis, Tunisia</source>
      <translation variants="no">Tunis, Tunisia</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_alarm_sound">
      <source>Not specified</source>
      <translation variants="no">vi #Alarm tone</translation>
    </message>
    <message numerus="no" id="txt_clk_list_astana_kaz">
      <source>Astana, Kazakhstan</source>
      <translation variants="no">Astana, Kazakhstan</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_repeat_daily">
      <source>Not specified</source>
      <translation variants="no">vi #Daily</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_list_occurence_detail">
      <source>Not specified</source>
      <translation variants="no">vi #Recurrence</translation>
    </message>
    <message numerus="no" id="txt_clock_tumbler_date">
      <source>Not specified</source>
      <translation variants="no">vi #Date</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kuwait_city_kuwait">
      <source>Kuwait City, Kuwait</source>
      <translation variants="no">Kuwait City, Kuwait</translation>
    </message>
    <message numerus="no" id="txt_clk_list_atikokan_canada">
      <source>Atikokan, Canada</source>
      <translation variants="no">Atikokan, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_denver_usa">
      <source>Denver, United States of America</source>
      <translation variants="no">Denver, CO, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clock_title_clock">
      <source>Not specified</source>
      <translation variants="no">vi #Clock</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_wednesday">
      <source>Not specified</source>
      <translation variants="no">vi #Wednesday</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_repeat_weekly">
      <source>Not specified</source>
      <translation variants="no">vi #Weekly</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_dd_mm_yyyy">
      <source>Not specified</source>
      <translation variants="no">vi #dd mm yyyy</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_yyyy_mm_dd">
      <source>Not specified</source>
      <translation variants="no">vi #yyyy mm dd</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_list_in_ln_hrs">
      <source>Not specified</source>
      <translation variants="no">vi #Within %Ln hour</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_time">
      <source>Not specified</source>
      <translation variants="no">vi #Time:</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time_seperator">
      <source>Not specified</source>
      <translation variants="no">vi #Time separator:</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_friday">
      <source>Not specified</source>
      <translation variants="no">vi #Friday</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hanga_roa_easter_isl">
      <source>Hanga Roa, Easter Island</source>
      <translation variants="no">Hanga Roa, Đảo Phục Sinh</translation>
    </message>
    <message numerus="no" id="txt_clk_list_chicago_usa">
      <source>Chicago, United States of America</source>
      <translation variants="no">Chicago, IL, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_london_uk">
      <source>London, United Kingdom</source>
      <translation variants="no">London, Vương quốc Anh</translation>
    </message>
    <message numerus="no" id="txt_clk_list_monaco_monaco">
      <source>Monaco, Monaco</source>
      <translation variants="no">Monaco, Monaco</translation>
    </message>
    <message numerus="no" id="txt_clk_list_baghdad_iraq">
      <source>Baghdad, Iraq</source>
      <translation variants="no">Baghdad, Iraq</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cayenne_french_guiana">
      <source>Cayenne, French Guiana</source>
      <translation variants="no">Cayenne, Guiana thuộc Pháp</translation>
    </message>
    <message numerus="no" id="txt_clk_list_brazzaville_congo">
      <source>Not specified</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_occurence">
      <source>Not specified</source>
      <translation variants="no">vi #Repeat</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_off">
      <source>Not specified</source>
      <translation variants="no">vi #Off</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_date_time_settings">
      <source>Not specified</source>
      <translation variants="no">vi #Date and time</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_week_starts_on">
      <source>Not specified</source>
      <translation variants="no">vi #Week starts on:</translation>
    </message>
    <message numerus="no" id="txt_clk_list_irkutsk_russia">
      <source>Irkutsk, Russia</source>
      <translation variants="no">Irkutsk, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rio_de_jan_brazil">
      <source>Rio de Janeiro, Brazil</source>
      <translation variants="no">Rio de Janeiro, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_thursday">
      <source>Not specified</source>
      <translation variants="no">vi #Thursday</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_alarm_editor">
      <source>Not specified</source>
      <translation variants="no">vi #Alarm</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_list_alarm">
      <source>Not specified</source>
      <translation variants="no">vi #Alarm</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_opt_settings">
      <source>Not specified</source>
      <translation variants="no">vi #Settings</translation>
    </message>
    <message numerus="no" id="txt_clk_list_birmingham_al_usa">
      <source>Birmingham, AL, United States of America</source>
      <translation variants="no">Birmingham, AL, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_charlotte_usa">
      <source>Charlotte, United States of America</source>
      <translation variants="no">Charlotte, NC, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_louisville_ky_usa">
      <source>Louisville, KY, United States of America</source>
      <translation variants="no">Louisville, KY, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_chihuahua_mexico">
      <source>Chihuahua, Mexico</source>
      <translation variants="no">Chihuahua, Mêhicô</translation>
    </message>
    <message numerus="no" id="txt_clk_list_las_palmas_canary_isl">
      <source>Las Palmas, Canary Islands</source>
      <translation variants="no">Las Palmas, Quần đảo Canary</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bissau_guinea_bissau">
      <source>Bissau, Guinea-Bissau</source>
      <translation variants="no">Bissau, Guinea-Bissau</translation>
    </message>
    <message numerus="no" id="txt_clk_list_concord_nh_usa">
      <source>Concord, NH, United States of America</source>
      <translation variants="no">Concord, NH, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour">
      <source>24 hour</source>
      <translation variants="no">24-giờ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_guatemala_guatemala">
      <source>Guatemala, Guatemala</source>
      <translation variants="no">Guatemala, Guatemala</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_date_format">
      <source>Date format:</source>
      <translation variants="no">Định dạng ngày:</translation>
    </message>
    <message numerus="no" id="txt_clk_grid_lnln">
      <source>&lt;-/+&gt;%Ln:%Ln</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bamako_mali">
      <source>Bamako, Mali</source>
      <translation variants="no">Bamako, Mali</translation>
    </message>
    <message numerus="no" id="txt_clk_list_the_settlement_christmas_isl">
      <source>The Settlement, Christmas Island.</source>
      <translation variants="no">The Settlement, Đảo Giáng Sinh</translation>
    </message>
    <message numerus="no" id="txt_clk_list_melekeok_palau">
      <source>Melekeok, Palau</source>
      <translation variants="no">Melekeok, Palau</translation>
    </message>
    <message numerus="no" id="txt_clk_list_suva_fiji">
      <source>Suva, Fiji</source>
      <translation variants="no">Suva, Fiji</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rankin_inlet_canada">
      <source>Rankin Inlet, Canada</source>
      <translation variants="no">Rankin Inlet, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dublin_ireland">
      <source>Dublin, Ireland</source>
      <translation variants="no">Dublin, Ireland</translation>
    </message>
    <message numerus="no" id="txt_clk_line_grid_date">
      <source>&lt;date&gt;</source>
      <translation variants="no">Ngày</translation>
    </message>
    <message numerus="no" id="txt_clk_list_manila_philippines">
      <source>Manila, Philippines</source>
      <translation variants="no">Manila, Philipin</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_time_format">
      <source>Time format:</source>
      <translation variants="no">Định dạng thời gian:</translation>
    </message>
    <message numerus="no" id="txt_clk_list_halifax_canada">
      <source>Halifax, Canada</source>
      <translation variants="no">Halifax, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nairobi_kenya">
      <source>Nairobi, Kenya</source>
      <translation variants="no">Nairobi, Kenya</translation>
    </message>
    <message numerus="no" id="txt_clk_list_maputo_mozambique">
      <source>Maputo, Mozambique</source>
      <translation variants="no">Maputo, Mozambique</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hagatna_guam">
      <source>Hagatna, Guam</source>
      <translation variants="no">Hagatna, Guam</translation>
    </message>
    <message numerus="no" id="txt_clk_button_date">
      <source>&lt;date&gt;</source>
      <translation variants="no">Chọn ngày</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kuala_lumpur_malaysia">
      <source>Kuala Lumpur, Malaysia</source>
      <translation variants="no">Kuala Lumpur, Malaysia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_san_marino_city_san_marino">
      <source>San Marino City, San Marino</source>
      <translation variants="no">Thành phố San Marino, San Marino</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dakar_senegal">
      <source>Dakar, Senegal</source>
      <translation variants="no">Dakar, Senegal</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yekaterinburg_russia">
      <source>Yekaterinburg, Russia</source>
      <translation variants="no">Yekaterinburg, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_list_stockholm_sweden">
      <source>Stockholm, Sweden</source>
      <translation variants="no">Stockholm, Thụy Điển</translation>
    </message>
    <message numerus="no" id="txt_clk_list_majuro_marshall_isl">
      <source>Majuro, Marshall Islands</source>
      <translation variants="no">Majuro, Quần đảo Marshall</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_weekly">
      <source>Repeat weekly</source>
      <translation variants="no">Hàng tuần</translation>
    </message>
    <message numerus="no" id="txt_clk_list_funafuti_tuvalu">
      <source>Funafuti, Tuvalu</source>
      <translation variants="no">Funafuti, Tuvalu</translation>
    </message>
    <message numerus="no" id="txt_clk_list_managua_nicaragua">
      <source>Managua, Nicaragua</source>
      <translation variants="no">Managua, Nicaragua</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bismarck_nd_usa">
      <source>Bismarck, ND, United States of America</source>
      <translation variants="no">Bismarck, ND, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_podgorica_montenegro">
      <source>Podgorica, Montenegro</source>
      <translation variants="no">Podgorica, Montenegro</translation>
    </message>
    <message numerus="no" id="txt_clk_list_memphis_usa">
      <source>Memphis, United States of America</source>
      <translation variants="no">Memphis, TN, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cambridge_bay_canada">
      <source>Cambridge Bay, Canada</source>
      <translation variants="no">Cambridge Bay, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_caracas_venezuela">
      <source>Caracas, Venezuela</source>
      <translation variants="no">Caracas, Venezuela</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lomé_togo">
      <source>Lomé, Togo</source>
      <translation variants="no">Lomé, Togo</translation>
    </message>
    <message numerus="no" id="txt_clk_list_jerusalem_israel">
      <source>Jerusalem, Israel</source>
      <translation variants="no">Jerusalem, Israel</translation>
    </message>
    <message numerus="no" id="txt_clk_list_addis _ababa_ethiopia">
      <source>Addis Ababa, Ethiopia</source>
      <translation variants="no">Addis Ababa, Ethiopia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nicosia_cyprus">
      <source>Nicosia, Cyprus</source>
      <translation variants="no">Nicosia, Cyprus</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hartford_ct_usa">
      <source>Hartford, CT, United States of America</source>
      <translation variants="no">Hartford, CT, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_minsk_belarus">
      <source>Minsk, Belarus</source>
      <translation variants="no">Minsk, Belarus</translation>
    </message>
    <message numerus="no" id="txt_clk_list_san_salvador_el_salvador">
      <source>San Salvador, El Salvador</source>
      <translation variants="no">San Salvador, El Salvador</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_time">
      <source>Time</source>
      <translation variants="no">Thời gian</translation>
    </message>
    <message numerus="no" id="txt_clk_list_baku_azerb">
      <source>Baku, Azerbaijan</source>
      <translation variants="no">Baku, Azerbaijan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_the_valley_anguilla">
      <source>The Valley, Anguilla</source>
      <translation variants="no">The Valley, Anguilla</translation>
    </message>
    <message numerus="no" id="txt_clk_list_noumea_new_caledonia">
      <source>Noumea, New Caledonia</source>
      <translation variants="no">Noumea, New Caledonia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_miami_usa">
      <source>Miami, United States of America</source>
      <translation variants="no">Miami, FL, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_teresina_brazil">
      <source>Teresina, Brazil</source>
      <translation variants="no">Teresina, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_adamstown_pitcairn_isl">
      <source>Adamstown, Pitcairn Islands</source>
      <translation variants="no">Adamstown, Quần đảo Pitcairn</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ottawa_canada">
      <source>Ottawa, Canada</source>
      <translation variants="no">Ottawa, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_title_clock">
      <source>Clock</source>
      <translation variants="no">Đồng hồ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">Thứ Tư</translation>
    </message>
    <message numerus="no" id="txt_clk_list_libreville_gabon">
      <source>Libreville, Gabon</source>
      <translation variants="no">Libreville, Gabon</translation>
    </message>
    <message numerus="no" id="txt_clk_list_amsterdam_netherlands">
      <source>Amsterdam, Netherlands</source>
      <translation variants="no">Amsterdam, Hà Lan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kolkata_india">
      <source>Kolkata, India</source>
      <translation variants="no">Kolkata, Ấn Độ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_daily">
      <source>Repeat daily</source>
      <translation variants="no">Hàng ngày</translation>
    </message>
    <message numerus="no" id="txt_clk_list_palmas_brazil">
      <source>Palmas, Brazil</source>
      <translation variants="no">Palmas, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_boston_usa">
      <source>Boston, United States of America</source>
      <translation variants="no">Boston, MA, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_curitiba_brazil">
      <source>Curitiba, Brazil</source>
      <translation variants="no">Curitiba, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_samara_russia">
      <source>Samara, Russia</source>
      <translation variants="no">Samara, Nga</translation>
    </message>
    <message numerus="no" id="txt_clock_menu_delete">
      <source>Not specified</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_clk_list_providence_ri_usa">
      <source>Providence, RI, United States of America</source>
      <translation variants="no">Providence, RI, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_daylight_saving_time">
      <source>Daylight saving time</source>
      <translation variants="no">Thời gian tiết kiệm pin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lusaka_zambia">
      <source>Lusaka, Zambia</source>
      <translation variants="no">Lusaka, Zambia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_riyadh_saudi_arabia">
      <source>Riyadh, Saudi Arabia</source>
      <translation variants="no">Riyadh, Ả Rập Saudi</translation>
    </message>
    <message numerus="no" id="txt_clk_list_thimpu_bhutan">
      <source>Thimpu, Bhutan</source>
      <translation variants="no">Thimpu, Bhutan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_harare_zimbabwe">
      <source>Harare, Zimbabwe</source>
      <translation variants="no">Harare, Zimbabwe</translation>
    </message>
    <message numerus="no" id="txt_clk_list_georgetown_guyana">
      <source>Georgetown, Guyana</source>
      <translation variants="no">Georgetown, Guyana</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lima_peru">
      <source>Lima, Peru</source>
      <translation variants="no">Lima, Peru</translation>
    </message>
    <message numerus="no" id="txt_clk_list_santiago_chile">
      <source>Santiago, Chile</source>
      <translation variants="no">Santiago, Chilê</translation>
    </message>
    <message numerus="no" id="txt_clk_list_porto_aux_francais_kerguelen">
      <source>Port-aux-Francais, Kerguelen</source>
      <translation variants="no">Port-aux-Francais, Quần đảo Kerguelen</translation>
    </message>
    <message numerus="no" id="txt_clk_list_conakry_guinea">
      <source>Conakry, Guinea</source>
      <translation variants="no">Conakry, Guinea</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sofia_bulgaria">
      <source>Sofia, Bulgaria</source>
      <translation variants="no">Sofia, Bungary</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bridgetown_barbados">
      <source>Bridgetown, Barbados</source>
      <translation variants="no">Bridgetown, Barbados</translation>
    </message>
    <message numerus="no" id="txt_clk_list_antananarivo_madagascar">
      <source>Antananarivo, Madagascar</source>
      <translation variants="no">Antananarivo, Madagascar</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cuiaba_brazil">
      <source>Cuiaba, Brazil</source>
      <translation variants="no">Cuiaba, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_workdays">
      <source>Workdays:</source>
      <translation variants="no">Ngày làm việc:</translation>
    </message>
    <message numerus="no" id="txt_clk_list_male_maldives">
      <source>Male, Maldives</source>
      <translation variants="no">Male, Maldives</translation>
    </message>
    <message numerus="no" id="txt_clk_list_pyongyang_north_korea">
      <source>Pyongyang, North Korea</source>
      <translation variants="no">Pyongyang, Bắc Triều Tiên</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bogota_colombia">
      <source>Bogota, Colombia</source>
      <translation variants="no">Bogotá, Colombia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_roseau_dominica">
      <source>Roseau, Dominica</source>
      <translation variants="no">Roseau, Dominica</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_daylight_saving_time">
      <source>Not specified</source>
      <translation variants="no">vi #Daylight saving time</translation>
    </message>
    <message numerus="no" id="txt_clk_list_papeete_tahiti">
      <source>Papeete, Tahiti</source>
      <translation variants="no">Papeete, Tahiti</translation>
    </message>
    <message numerus="no" id="txt_clk_subhead_date_time">
      <source>Date &amp; time</source>
      <translation variants="no">Ngày giờ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_paramaribo_suriname">
      <source>Paramaribo, Suriname</source>
      <translation variants="no">Paramaribo, Suriname</translation>
    </message>
    <message numerus="no" id="txt_clk_list_diego_garcia_chagos_isl">
      <source>Diego Garcia, Chagos Islands</source>
      <translation variants="no">Diego Garcia, Chagos Archipelago</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cairo_egypt">
      <source>Cairo, Egypt</source>
      <translation variants="no">Cairo, Ai Cập</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nouakchott_mauritania">
      <source>Nouakchott, Mauritania</source>
      <translation variants="no">Nouakchott, Mauritania</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yerevan_armenia">
      <source>Yerevan, Armenia</source>
      <translation variants="no">Yerevan, Armenia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_magadan_russia">
      <source>Magadan, Russia</source>
      <translation variants="no">Magadan, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_list_berlin_germany">
      <source>Berlin, Germany</source>
      <translation variants="no">Berlin, Đức</translation>
    </message>
    <message numerus="no" id="txt_clk_list_andorra_la_vella_andorra">
      <source>Andorra La Vella, Andorra</source>
      <translation variants="no">Andorra La Vella, Andorra</translation>
    </message>
    <message numerus="no" id="txt_clk_list_brisbane_aus">
      <source>Brisbane, Australia</source>
      <translation variants="no">Brisbane, Úc</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_friday">
      <source>Friday</source>
      <translation variants="no">Thứ Sáu</translation>
    </message>
    <message numerus="no" id="txt_clk_list_funchal_madeira">
      <source>Funchal, Madeira</source>
      <translation variants="no">Funchal, Madeira</translation>
    </message>
    <message numerus="no" id="txt_clk_list_belmopan_belize">
      <source>Belmopan, Belize</source>
      <translation variants="no">Belmopan, Belize</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_help">
      <source>Help</source>
      <translation variants="no">Trợ giúp</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yellowknife_canada">
      <source>Yellowknife, Canada</source>
      <translation variants="no">Yellowknife, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mamoudzou_mayotte">
      <source>Mamoudzou, Mayotte</source>
      <translation variants="no">Mamoudzou, Mayotte</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dallas_usa">
      <source>Dallas, United States of America</source>
      <translation variants="no">Dallas, TX, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_date">
      <source>&lt;date&gt;</source>
      <translation variants="no">Ngày</translation>
    </message>
    <message numerus="no" id="txt_clk_list_chisinau_moldova">
      <source>Chisinau, Moldova</source>
      <translation variants="no">Chisinau, Moldova</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rainy_river_canada">
      <source>Rainy River, Canada</source>
      <translation variants="no">Rainy River, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_castries_st_lucia">
      <source>Castries, St. Lucia</source>
      <translation variants="no">Castries, St. Lucia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_darwin_aus">
      <source>Darwin, Australia</source>
      <translation variants="no">Darwin, Úc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_riga_latvia">
      <source>Riga, Latvia</source>
      <translation variants="no">Riga, Latvia</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_place">
      <source>Place:</source>
      <translation variants="no">Vị trí:</translation>
    </message>
    <message numerus="no" id="txt_clk_list_salvador_brazil">
      <source>Salvador, Brazil</source>
      <translation variants="no">Salvador, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_pago_pago_as_usa">
      <source>Pago Pago, AS, United States of America</source>
      <translation variants="no">Pago Pago, AS, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy">
      <source>dd mm yyyy</source>
      <translation variants="no">nn tt nnnn</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_alarm">
      <source>Alarm</source>
      <translation variants="no">Báo thức</translation>
    </message>
    <message numerus="no" id="txt_clk_list_belfast_ireland">
      <source>Belfast, Ireland</source>
      <translation variants="no">Belfast, Bắc Ireland</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_sunday">
      <source>Sunday</source>
      <translation variants="no">Chủ Nhật</translation>
    </message>
    <message numerus="no" id="txt_clk_list_augusta_usa">
      <source>Augusta, United States of America</source>
      <translation variants="no">Augusta, ME, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_washington_usa">
      <source>Washington, United States of America</source>
      <translation variants="no">Washington, DC, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_settings">
      <source>Settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_clk_list_madrid_spain">
      <source>Madrid, Spain</source>
      <translation variants="no">Madrid, Tây Ban Nha</translation>
    </message>
    <message numerus="no" id="txt_clk_list_st_loius_usa">
      <source>St. Louis, United States of America</source>
      <translation variants="no">St. Louis, MO, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_add_own_city">
      <source>Not specified</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_date_value">
      <source>Not specified</source>
      <translation variants="no">vi #Select date</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cockburn_town_turks_and_caicos_isl">
      <source>Cockburn Town, </source>
      <translation variants="no">Cockburn Town, Quần đảo Turks và Caicos</translation>
    </message>
    <message numerus="no" id="txt_clk_list_canberra_aus">
      <source>Canberra, Australia</source>
      <translation variants="no">Canberra, Úc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rome_italy">
      <source>Rome, Italy</source>
      <translation variants="no">Rome, Ý</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_occurence_detail">
      <source>&lt;Occurence detail&gt;</source>
      <translation variants="no">Chi tiết báo thức</translation>
    </message>
    <message numerus="no" id="txt_clk_list_joao_pessoa_brazil">
      <source>Joao Pessoa, Brazil</source>
      <translation variants="no">Joao Pessoa, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_fakaofo_tokelau">
      <source>Fakaofo, Tokelau</source>
      <translation variants="no">Fakaofo, Tokelau</translation>
    </message>
    <message numerus="no" id="txt_clk_list_atlanta_usa">
      <source>Atlanta, United States of America</source>
      <translation variants="no">Atlanta, GA, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_line_grid_cityname">
      <source>&lt;cityname&gt;</source>
      <translation variants="no">Thêm thành phố</translation>
    </message>
    <message numerus="no" id="txt_clk_list_billings_mt_usa">
      <source>Billings, MT, United States of America</source>
      <translation variants="no">Billings, MT, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_san_francisco_usa">
      <source>San Francisco, United States of America</source>
      <translation variants="no">San Francisco, CA, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_format">
      <source>Not specified</source>
      <translation variants="no">vi #Date format:</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_use_network_date_time">
      <source>Not specified</source>
      <translation variants="no">vi #Auto-update of date and time</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val">
      <source>Not specified</source>
      <translation variants="no">vi #-</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_12_hour">
      <source>Not specified</source>
      <translation variants="no">vi #12-hour</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_thursday">
      <source>Not specified</source>
      <translation variants="no">vi #Thursday</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lord_howe_isl_aus">
      <source>Lord Howe Island, Australia</source>
      <translation variants="no">Đảo Lord Howe, Úc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lisbon_portugal">
      <source>Lisbon, Portugal</source>
      <translation variants="no">Lisbon, Bồ Đào Nha</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy">
      <source>mm dd yyyy</source>
      <translation variants="no">tt nn nnnn</translation>
    </message>
    <message numerus="no" id="txt_clk_list_montreal_canada">
      <source>Montreal, Canada</source>
      <translation variants="no">Montreal, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_reykjavik_iceland">
      <source>Reykjavik, Iceland</source>
      <translation variants="no">Reykjavik, Iceland</translation>
    </message>
    <message numerus="no" id="txt_clk_list_acre_brazil">
      <source>Acre, Brazil</source>
      <translation variants="no">Acre, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_avarua_cook_isl">
      <source>Avarua, Cook Islands</source>
      <translation variants="no">Avarua, Quần đảo Cook</translation>
    </message>
    <message numerus="no" id="txt_clk_list_quito_equador">
      <source>Quito, Equador</source>
      <translation variants="no">Quito, Equador</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mbabane_swaziland">
      <source>Mbabane, Swaziland</source>
      <translation variants="no">Mbabane, Swaziland</translation>
    </message>
    <message numerus="no" id="txt_clk_list_singapore_city_singapore">
      <source>Singapore City, Singapore</source>
      <translation variants="no">Singapore, Singapore</translation>
    </message>
    <message numerus="no" id="txt_clk_list_coral_harbour_canada">
      <source>Coral Harbour, Canada</source>
      <translation variants="no">Coral Harbour, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hobart_aus">
      <source>Hobart, Australia</source>
      <translation variants="no">Hobart, Úc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_philadelphia_usa">
      <source>Philadelphia, United States of America</source>
      <translation variants="no">Philadelphia, PA, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_las_vegas_usa">
      <source>Las Vegas, United States of America</source>
      <translation variants="no">Las Vegas, NV, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sonora_mexico">
      <source>Sonora, Mexico</source>
      <translation variants="no">Sonora, Mêhicô</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tbilisi_georgia">
      <source>Tbilisi, Georgia</source>
      <translation variants="no">Tbilisi, Georgia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_budapest_hungary">
      <source>Budapest, Hungary</source>
      <translation variants="no">Budapest, Hungary</translation>
    </message>
    <message numerus="no" id="txt_clk_list_muscat_oman">
      <source>Muscat, Oman</source>
      <translation variants="no">Muscat, Oman</translation>
    </message>
    <message numerus="no" id="txt_clk_list_agana, guam">
      <source>Agana, Guam</source>
      <translation variants="no">Agana, Guam</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dover_de_usa">
      <source>Dover, DE, United States of America</source>
      <translation variants="no">Dover, DE, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_krasnoyarsk_russia">
      <source>Krasnoyarsk, Russia</source>
      <translation variants="no">Krasnoyarsk, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_list_charleston_wv_usa">
      <source>Charleston, WV, United States of America</source>
      <translation variants="no">Charleston, WV, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_palikir_micronesia">
      <source>Palikir, Micronesia</source>
      <translation variants="no">Palikir, Micronesia</translation>
    </message>
    <message numerus="no" id="txt_clk_title_clock">
      <source>Clock</source>
      <translation variants="no">Đồng hồ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_santo_domingo_dominican_rep">
      <source>Santo Domingo, Dominican Republic</source>
      <translation variants="no">Santo Domingo, Cộng hòa Dominica</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_menu_delete_alarm">
      <source>Delete alarm</source>
      <translation variants="no">Xóa âm báo</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ouagadougou_bf">
      <source>Ouagadougou, Burkina Faso</source>
      <translation variants="no">Ouagadougou, Burkina Faso</translation>
    </message>
    <message numerus="no" id="txt_clk_list_basse_terre_guadeloupe">
      <source>Basse-Terre, Guadeloupe</source>
      <translation variants="no">Basse-Terre, Guadeloupe</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vientiane_laos">
      <source>Vientiane, Laos</source>
      <translation variants="no">Viêng Chăng, Lào</translation>
    </message>
    <message numerus="no" id="txt_clk_list_new_orleans_usa">
      <source>New Orleans, United States of America</source>
      <translation variants="no">New Orleans, LA, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sao_luis_brazil">
      <source>Sao Luis, Brazil</source>
      <translation variants="no">Sao Luis, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_occurence">
      <source>Occurence</source>
      <translation variants="no">Lặp lại</translation>
    </message>
    <message numerus="no" id="txt_clk_list_west_isl_cocos_isl">
      <source>West Island, Cocos Islands</source>
      <translation variants="no">Đảo West, Quần đảo Cocos (Keeling)</translation>
    </message>
    <message numerus="no" id="txt_clk_list_osaka_japan">
      <source>Osaka, Japan</source>
      <translation variants="no">Osaka, Nhật Bản</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mogadishu_somalia">
      <source>Mogadishu, Somalia</source>
      <translation variants="no">Mogadishu, Somali</translation>
    </message>
    <message numerus="no" id="txt_clk_list_copenhagen_denmark">
      <source>Copenhagen, Denmark</source>
      <translation variants="no">Copenhagen, Đan Mạch</translation>
    </message>
    <message numerus="no" id="txt_clk_list_port_vila_vanuatu">
      <source>Port Vila, Vanuatu</source>
      <translation variants="no">Port Vila, Vanuatu</translation>
    </message>
    <message numerus="no" id="txt_clock_menu_set_as_current_location">
      <source>Not specified</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_clk_list_windhoek_namibia">
      <source>Windhoek, Namibia</source>
      <translation variants="no">Windhoek, Namibia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tallinn_estonia">
      <source>Tallinn, Estonia</source>
      <translation variants="no">Tallinn, Estonia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hong_kong_victoria">
      <source>Hong kong, Victoria</source>
      <translation variants="no">Hồng Kông, Victoria</translation>
    </message>
    <message numerus="no" id="txt_clk_subtitle_alarm">
      <source>Alarm</source>
      <translation variants="no">Báo thức</translation>
    </message>
    <message numerus="no" id="txt_clk_list_oranjestad_aruba">
      <source>Oranjestad, Aruba</source>
      <translation variants="no">Oranjestad, Aruba</translation>
    </message>
    <message numerus="no" id="txt_clk_list_thule_greenland">
      <source>Thule, Greenland</source>
      <translation variants="no">Thule, Greenland</translation>
    </message>
    <message numerus="no" id="txt_clk_list_havana_cuba">
      <source>Havana, Cuba</source>
      <translation variants="no">Havana, Cuba</translation>
    </message>
    <message numerus="no" id="txt_clk_list_jayapura_indonesia">
      <source>Jayapura, Indonesia</source>
      <translation variants="no">Jayapura, Inđô</translation>
    </message>
    <message numerus="no" id="txt_clk_list_boa_vista_brazil">
      <source>Boa Vista, Brazil</source>
      <translation variants="no">Boa Vista, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_indianapolis_usa">
      <source>Indianapolis, United States of America</source>
      <translation variants="no">Indianapolis, IN, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_use_network_date_time">
      <source>Use network date &amp; time</source>
      <translation variants="no">Tự động cập nhật ngày giờ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_richmond_va_usa">
      <source>Richmond, VA, United States of America</source>
      <translation variants="no">Richmond, VA, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_charlotte_amalie_vi_usa">
      <source>Charlotte Amalie, VI, United States of America</source>
      <translation variants="no">Charlotte Amalie, VI, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_st_petersburg_russia">
      <source>St. Petersburg, Russia</source>
      <translation variants="no">St. Petersburg, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cranbrook_canada">
      <source>Cranbrook, Canada</source>
      <translation variants="no">Cranbrook, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_belgrade_serbia">
      <source>Belgrade, Serbia</source>
      <translation variants="no">Belgrade, Serbia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_taiohae_marquesas_isl">
      <source>Taiohae, Marquesas Islands</source>
      <translation variants="no">Taiohae, Quần đảo Marquesas</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bratislava_slovakia">
      <source>Bratislava, Slovakia</source>
      <translation variants="no">Bratislava, Slovakia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_road_town_british_virgin_isl">
      <source>Road Town, British Virgin Islands</source>
      <translation variants="no">Road Town, Quần đảo Virgin thuộc Anh</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bishkek_kyrgyzstan">
      <source>Bishkek, Kyrgyzstan</source>
      <translation variants="no">Bishkek, Kyrgyzstan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saint_denis_reunion">
      <source>Saint-Denis, Reunion</source>
      <translation variants="no">Saint-Denis, Reunion</translation>
    </message>
    <message numerus="no" id="txt_clk_list_taipei_taiwan">
      <source>Taipei, Taiwan</source>
      <translation variants="no">Đài Bắc, Đài Loan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_phoenix_usa">
      <source>Phoenix, United States of America</source>
      <translation variants="no">Phoenix, AZ, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_regina_canada">
      <source>Regina, Canada</source>
      <translation variants="no">Regina, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_button_cityname_countryname">
      <source>&lt;cityname, countryname&gt;</source>
      <translation variants="no">Chọn thành phố</translation>
    </message>
    <message numerus="no" id="txt_clk_list_porto_au_prince_haiti">
      <source>Port-au-Prince, Haiti</source>
      <translation variants="no">Port-au-Prince, Haiti</translation>
    </message>
    <message numerus="no" id="txt_clk_list_islamabad_pak">
      <source>Islamabad, Pakistan</source>
      <translation variants="no">Islamabad, Pakistan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_freetown_sierra_leone">
      <source>Freetown, Sierra Leone</source>
      <translation variants="no">Freetown, Sierra Leone</translation>
    </message>
    <message numerus="no" id="txt_clk_list_gaborone_botswana">
      <source>Gaborone, Botswana</source>
      <translation variants="no">Gaborone, Botswana</translation>
    </message>
    <message numerus="no" id="txt_clk_list_jakarta_indonesia">
      <source>Jakarta, Indonesia</source>
      <translation variants="no">Jakarta, Inđô</translation>
    </message>
    <message numerus="no" id="txt_clk_list_araguaina_brazil">
      <source>Araguaina, Brazil</source>
      <translation variants="no">Araguaina, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_auckland_nz">
      <source>Auckland, Newzealand</source>
      <translation variants="no">Auckland, New Zealand</translation>
    </message>
    <message numerus="no" id="txt_clk_list_wichita_ks_usa">
      <source>Wichita, KS, United States of America</source>
      <translation variants="no">Wichita, KS, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_gary_in_usa">
      <source>Gary, IN, United States of America</source>
      <translation variants="no">Gary, IN, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ashgabat_turkmenistan">
      <source>Ashgabat, Turkmenistan</source>
      <translation variants="no">Ashgabat, Turkmenistan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_los_angeles_usa">
      <source>Los Angeles, United States of America</source>
      <translation variants="no">Los Angeles, CA, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sapporo_japan">
      <source>Sapporo, Japan</source>
      <translation variants="no">Sapporo, Nhật Bản</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bandar_seri_begawan_brunei">
      <source>Bandar Seri Begawan, Brunei</source>
      <translation variants="no">Bandar Seri Begawan, Brunei</translation>
    </message>
    <message numerus="no" id="txt_clk_list_honiara_solomon_isl">
      <source>Honiara, Solomon Islands</source>
      <translation variants="no">Honiara, Quần đảo Solomon</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mata_utu_wallis_futuna_isl">
      <source>Mata_Utu, Wallis and Futuna Islands</source>
      <translation variants="no">Mata-Utu, Quần đảo Wallis và Futuna</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rangoon_myanmar">
      <source>Rangoon, Myanmar</source>
      <translation variants="no">Rangoon, Myanmar</translation>
    </message>
    <message numerus="no" id="txt_clk_list_warsaw_poland">
      <source>Warsaw, Poland</source>
      <translation variants="no">Warsaw, Ba Lan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saipan_mp_usa">
      <source>Saipan, MP, United States of America</source>
      <translation variants="no">Saipan, MP, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_port_of_spain_trinidad">
      <source>Port of Spain, Trinidad</source>
      <translation variants="no">Port of Spain, Trinidad</translation>
    </message>
    <message numerus="no" id="txt_clk_list_columbia_sc_usa">
      <source>Columbia, SC, United States of America</source>
      <translation variants="no">Columbia, SC, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_malabo_eq_guinea">
      <source>Malabo, Equatorial Guinea</source>
      <translation variants="no">Malabo, Guinea Xích Đạo</translation>
    </message>
    <message numerus="no" id="txt_clk_list_recife_brazil">
      <source>Recife, Brazil</source>
      <translation variants="no">Recife, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ulaanbaatar_mongolia">
      <source>Ulaanbaatar, Mongolia</source>
      <translation variants="no">Ulaanbaatar, Mông Cổ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_joinville_brazil">
      <source>Joinville, Brazil</source>
      <translation variants="no">Joinville, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_blanc_sablon_canada">
      <source>Blanc-Sablon, Canada</source>
      <translation variants="no">Blanc-Sablon, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_button_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="no">Cài đặt nâng cao</translation>
    </message>
    <message numerus="no" id="txt_clk_list_prague_czech">
      <source>Prague, Czechoslovakia</source>
      <translation variants="no">Prague, Cộng hòa Séc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_calgary_canada">
      <source>Calgary, Canada</source>
      <translation variants="no">Calgary, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tegucigalpa_honduras">
      <source>Tegucigalpa, Honduras</source>
      <translation variants="no">Tegucigalpa, Honduras</translation>
    </message>
    <message numerus="no" id="txt_clk_list_montpelier_vt_usa">
      <source>Montpelier, VT, United States of America</source>
      <translation variants="no">Montpelier, VT, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_week_starts_on">
      <source>Week starts on:</source>
      <translation variants="no">Tuần bắt đầu vào:</translation>
    </message>
    <message numerus="no" id="txt_clk_list_fortaleza_brazil">
      <source>Fortaleza, Brazil</source>
      <translation variants="no">Fortaleza, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_novosibirsk_russia">
      <source>Novosibirsk, Russia</source>
      <translation variants="no">Novosibirsk, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lubumbashi_drc">
      <source>Lubumbashi, Democratic Republic of the Congo</source>
      <translation variants="no">Lubumbashi, Cộng hòa Dân chủ Côngô</translation>
    </message>
    <message numerus="no" id="txt_clk_list_belem_brazil">
      <source>Belem, Brazil</source>
      <translation variants="no">Belem, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tarawa_kiribati">
      <source>Tarawa, Kiribati</source>
      <translation variants="no">Tarawa, Kiribati</translation>
    </message>
    <message numerus="no" id="txt_clk_list_gambier_isl_french_polynesia">
      <source>Gambier Islands, French Polynesia</source>
      <translation variants="no">Quần đảo Gambier, Polynesia thuộc Pháp</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saint_pierre_miquelon">
      <source>Saint-Pierre, Miquelon</source>
      <translation variants="no">Saint-Pierre, Miquelon</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kyiv_ukraine">
      <source>Kyiv, Ukraine</source>
      <translation variants="no">Kyiv, Ukraina</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nassau_bahamas">
      <source>Nassau, Bahamas</source>
      <translation variants="no">Nassau, Bahamas</translation>
    </message>
    <message numerus="no" id="txt_clk_list_jamestown_st_helena">
      <source>Jamestown, St. Helena</source>
      <translation variants="no">Jamestown, Saint Helena</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mexico_city_mexico">
      <source>Mexico City, Mexico</source>
      <translation variants="no">Mexico City, Mêhicô</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_thursday">
      <source>Thursday</source>
      <translation variants="no">Thứ Năm</translation>
    </message>
    <message numerus="no" id="txt_clk_list_portland_or_usa">
      <source>Portland, OR, United States of America</source>
      <translation variants="no">Portland, OR, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kampala_uganda">
      <source>Kampala, Uganda</source>
      <translation variants="no">Kampala, Uganda</translation>
    </message>
    <message numerus="no" id="txt_clk_list_praia_cape_verde">
      <source>Praia, Cape Verde</source>
      <translation variants="no">Praia, Cape Verde</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hovd_mongolia">
      <source>Hovd, Mongolia</source>
      <translation variants="no">Hovd, Mông Cổ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saint_johns_ab">
      <source>Saint John's, Antigua and Barbuda</source>
      <translation variants="no">Saint John's, Antigua và Barbuda</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sao_paulo_brazil">
      <source>Sao Paulo, Brazil</source>
      <translation variants="no">Sao Paulo, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_once">
      <source>Once</source>
      <translation variants="no">Không lặp lại</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nuku_alofa_tonga">
      <source>Nuku’alofa, Tonga</source>
      <translation variants="no">Nuku’alofa, Tonga</translation>
    </message>
    <message numerus="no" id="txt_clk_opt_add_own_city">
      <source>Add own city</source>
      <translation variants="no">vi #Add own city</translation>
    </message>
    <message numerus="no" id="txt_clk_list_new_york_usa">
      <source>New York, United States of America</source>
      <translation variants="no">New York, NY, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_toronto_canada">
      <source>Toronto, Canada</source>
      <translation variants="no">Toronto, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tel_aviv_israel">
      <source>Tel Aviv, Israel</source>
      <translation variants="no">Tel Aviv, Israel</translation>
    </message>
    <message numerus="no" id="txt_long_caption_clk">
      <source>Clock</source>
      <translation variants="no">Đồng hồ</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date">
      <source>Time &amp; date</source>
      <translation variants="no">Ngày giờ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_albuquerque_usa">
      <source>Albuquerque, United States of America</source>
      <translation variants="no">Albuquerque, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_detroit_usa">
      <source>Detroit, United States of America</source>
      <translation variants="no">Detroit, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kanton_isl_phoenix_isl">
      <source>Kanton Island, Phoenix Islands</source>
      <translation variants="no">Đảo Kanton, Quần đảo Phoenix</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_title_control_panel">
      <source>Control Panel</source>
      <translation variants="no">Bảng điều khiển</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_subtitle_device">
      <source>Device</source>
      <translation variants="no">Điện thoại</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_delete">
      <source>Delete</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kigali_rwanda">
      <source>Kigali, Rwanda</source>
      <translation variants="no">Kigali, Rwanda</translation>
    </message>
    <message numerus="no" id="txt_clk_caption_clock">
      <source>Clock</source>
      <translation variants="no">vi #Clock</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_button_world_clock">
      <source>World clock</source>
      <translation variants="no">vi ##World clock</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2min">
      <source>In %1hrs %2min</source>
      <translation variants="no">vi ##In %1hrs %2min</translation>
    </message>
    <message numerus="no" id="txt_clock_button_add_city">
      <source>Add city</source>
      <translation variants="no">vi ##Add city</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily">
      <source>Daily</source>
      <translation variants="no">vi ##Daily</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_once">
      <source>Not specified</source>
      <translation variants="no">vi #Not repeated</translation>
    </message>
    <message numerus="no" id="txt_clk_list_abuja_nigeria">
      <source>Abuja, Nigeria</source>
      <translation variants="no">Abuja, Nigeria</translation>
    </message>
    <message numerus="no" id="txt_clk_list_damascus_syria">
      <source>Damascus, Syria</source>
      <translation variants="no">Damascus, Syria</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_alarm_sound">
      <source>Alarm sound</source>
      <translation variants="no">Âm thanh báo thức</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_button_alarms">
      <source>Alarms</source>
      <translation variants="no">vi ##Alarms</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_description">
      <source>Description</source>
      <translation variants="no">Mô tả</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">Loại bỏ thay đổi</translation>
    </message>
    <message numerus="no" id="txt_clk_list_port_moresby_png">
      <source>Port Moresby, Papua New Guinea</source>
      <translation variants="no">Port Moresby, Papua New Guinea</translation>
    </message>
    <message numerus="no" id="txt_clk_list_abu_dhabi_uae">
      <source>Abu Dhabi, United Arab Emirates</source>
      <translation variants="no">Abu Dhabi, Các Tiểu vương quốc Ả Rập Thống nhất</translation>
    </message>
    <message numerus="no" id="txt_clk_list_montevideo_uruguay">
      <source>Montevideo, Uruguay</source>
      <translation variants="no">Montevideo, Uruguay</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_show_on_homescreen">
      <source>Show on homescreen</source>
      <translation variants="no">H.thị trên M.hình chính</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_mm_dd_yyyy">
      <source>Not specified</source>
      <translation variants="no">vi #mm dd yyyy</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour">
      <source>12 hour</source>
      <translation variants="no">12-giờ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_adak_ak_usa">
      <source>Adak, AK, United States of America</source>
      <translation variants="no">Adak, AK, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_creighton_canada">
      <source>Creighton, Canada</source>
      <translation variants="no">Creighton, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cheyenne_usa">
      <source>Cheyenne, United States of America</source>
      <translation variants="no">Cheyenne, WY, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_helsinki_finland">
      <source>Helsinki, Finland</source>
      <translation variants="no">Helsinki, Phần Lan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_djibouti_djibouti">
      <source>Djibouti, Djibouti</source>
      <translation variants="no">Djibouti, Djibouti</translation>
    </message>
    <message numerus="no" id="txt_clk_subtitle_new_alarm">
      <source>New alarm</source>
      <translation variants="no">Báo thức mới</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tripoli_libya">
      <source>Tripoli, Libya</source>
      <translation variants="no">Tripoli, Libya</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_menu_delete_alarm">
      <source>Not specified</source>
      <translation variants="no">vi #Delete alarm</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_in_ln_hrs">
      <source>In %Ln hrs</source>
      <translation variants="no">Trong %Ln giờ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kabul_afghan">
      <source>Kabul, Afghanistan</source>
      <translation variants="no">Kabul, Afghanistan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_seoul_skorea">
      <source>Seoul, South Korea</source>
      <translation variants="no">Seoul, Hàn Quốc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_guam_mp_usa">
      <source>Guam, MP, United States of America</source>
      <translation variants="no">Guam, MP, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_san_juan_puerto_rico">
      <source>San Juan, Puerto Rico</source>
      <translation variants="no">San Juan, Puerto Rico</translation>
    </message>
    <message numerus="no" id="txt_clk_list_colombo_srilanka">
      <source>Colombo, Srilanka</source>
      <translation variants="no">Colombo, Sri Lanka</translation>
    </message>
    <message numerus="no" id="txt_clk_list_honolulu_hi_usa">
      <source>Honolulu, HI, United States of America</source>
      <translation variants="no">Honolulu, HI, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_porto_alegre_brazil">
      <source>Porto Alegre, Brazil</source>
      <translation variants="no">Porto Alegre, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time">
      <source>Not specified</source>
      <translation variants="no">vi #Time</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_alarm_sound">
      <source>Not specified</source>
      <translation variants="no">vi #Alarm tone</translation>
    </message>
    <message numerus="no" id="txt_clk_list_evansville_in_usa">
      <source>Evansville, IN, United States of America</source>
      <translation variants="no">Evansville, IN, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_banjul_gambia">
      <source>Banjul, Gambia</source>
      <translation variants="no">Banjul, Gambia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_paris_france">
      <source>Paris, France</source>
      <translation variants="no">Paris, Pháp</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_no_alarms_set">
      <source>No alarms set</source>
      <translation variants="yes">
        <lengthvariant priority="1">(chưa đặt báo thức)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_date_time">
      <source>Not specified</source>
      <translation variants="no">vi #Date and time</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_time">
      <source>&lt;time&gt;</source>
      <translation variants="no">Thời gian báo thức</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tehran_iran">
      <source>Tehran, Iran</source>
      <translation variants="no">Tehran, Iran</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bangkok_thai">
      <source>Bangkok, Thailand</source>
      <translation variants="no">Bangkok, Thái Lan</translation>
    </message>
    <message numerus="no" id="txt_clock_menu_show_on_homescreen">
      <source>Not specified</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_use_network_date_time">
      <source>Not specified</source>
      <translation variants="no">vi #Auto-update of date and time</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_place">
      <source>Not specified</source>
      <translation variants="no">vi #Place:</translation>
    </message>
    <message numerus="no" id="txt_clk_list_johannesburg_safrica">
      <source>Johannesburg, South Africa</source>
      <translation variants="no">Johannesburg, Nam Phi</translation>
    </message>
    <message numerus="no" id="txt_clk_list_columbus_usa">
      <source>Columbus, United States of America</source>
      <translation variants="no">Columbus, OH, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_seattle_usa">
      <source>Seattle, United States of America</source>
      <translation variants="no">Seattle, WA, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_greece_athens">
      <source>Athens, Greece</source>
      <translation variants="no">Athens, Hy Lạp</translation>
    </message>
    <message numerus="no" id="txt_clk_list_asmara_eritrea">
      <source>Asmara, Eritrea</source>
      <translation variants="no">Asmara, Eritrea</translation>
    </message>
    <message numerus="no" id="txt_clk_list_aracaju_brazil">
      <source>Aracaju, Brazil</source>
      <translation variants="no">Aracaju, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_london_christmas_isl">
      <source>London, Christmas Island</source>
      <translation variants="no">London, Đảo Christmas</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dhaka_bangla">
      <source>Dhaka, Bangladesh</source>
      <translation variants="no">Dhaka, Bangladesh</translation>
    </message>
    <message numerus="no" id="txt_clk_list_george_town_cayman_isl">
      <source>George Town, Cayman Islands</source>
      <translation variants="no">George Town, Quần đảo Cayman</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sao_tome_principe">
      <source>São Tomé, Príncipe</source>
      <translation variants="no">São Tomé, São Tomé và Príncipe</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hanoi_vietnam">
      <source>Hanoi, Vietnam</source>
      <translation variants="no">Hà Nội, Việt Nam</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_day">
      <source>Day</source>
      <translation variants="no">Ngày</translation>
    </message>
    <message numerus="no" id="txt_clk_list_abidjan_cotedIvoire">
      <source>Abidjan, Cote d'Ivoire</source>
      <translation variants="no">Abidjan, Côte d'Ivoire</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hamilton_bermuda">
      <source>Hamilton, Bermuda</source>
      <translation variants="no">Hamilton, Bermuda</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yakutsk_russia">
      <source>Yakutsk, Russia</source>
      <translation variants="no">Yakutsk, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vladivostok_russia">
      <source>Vladivostok, Russia</source>
      <translation variants="no">Vladivostok, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_subhead_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="no">Cài đặt nâng cao</translation>
    </message>
    <message numerus="no" id="txt_clk_list_manama_bahrain">
      <source>Manama, Bahrain</source>
      <translation variants="no">Manama, Bahrain</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_regional_date_time_settings">
      <source>Not specified</source>
      <translation variants="no">vi #Advanced settings</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_saturday">
      <source>Not specified</source>
      <translation variants="no">vi #Saturday</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_set_as_current_location">
      <source>Set as current location</source>
      <translation variants="no">Đặt làm vị trí hiện tại</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_wednesday">
      <source>Not specified</source>
      <translation variants="no">vi #Wednesday</translation>
    </message>
    <message numerus="no" id="txt_clock_button_date">
      <source>Not specified</source>
      <translation variants="no">vi #Select date</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vaduz_lichtenstein">
      <source>Vaduz, Lichtenstein</source>
      <translation variants="no">Vaduz, Lichtenstein</translation>
    </message>
    <message numerus="no" id="txt_clk_list_maseru_lesotho">
      <source>Maseru, Lesotho</source>
      <translation variants="no">Maseru, Lesotho</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yaren_district_nauru">
      <source>Yaren District, Nauru</source>
      <translation variants="no">Yaren District, Nauru</translation>
    </message>
    <message numerus="no" id="txt_clk_list_karachi_pakistan">
      <source>Karachi, Pakistan</source>
      <translation variants="no">Karachi, Pakistan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_chennai_india">
      <source>Chennai, India</source>
      <translation variants="no">Chennai, Ấn Độ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_willemstad_curacao">
      <source>Willemstad, Curacao</source>
      <translation variants="no">Willemstad, Curacao</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rabat_morocco">
      <source>Rabat, Morocco</source>
      <translation variants="no">Rabat, Ma Rốc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_pbm_galapagos_isl">
      <source>Puerto Baquerizo Moreno, Galapagos Islands</source>
      <translation variants="no">Puerto Baquerizo Moreno, Quần đảo Galapagos</translation>
    </message>
    <message numerus="no" id="txt_clk_list_valletta_malta">
      <source>Valletta, Malta</source>
      <translation variants="no">Valletta, Malta</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kingston_norfolk_isl">
      <source>Kingston, Norfolk Island</source>
      <translation variants="no">Kingston, Đảo Norfolk</translation>
    </message>
    <message numerus="no" id="txt_clk_list_la_paz_bolivia">
      <source>La Paz, Bolivia</source>
      <translation variants="no">La Paz, Bolivia</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_saturday">
      <source>Saturday</source>
      <translation variants="no">Thứ Bảy</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dar_es_salaam_tanzania">
      <source>Dar es Salaam, Tanzania</source>
      <translation variants="no">Dar es Salaam, Tanzania</translation>
    </message>
    <message numerus="no" id="txt_clk_list_edmonton_canada">
      <source>Edmonton, Canada</source>
      <translation variants="no">Edmonton, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_on_workdays">
      <source>Repeat on workdays</source>
      <translation variants="no">Ngày làm việc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_chatham_newz">
      <source>Chatham, Newzealand</source>
      <translation variants="no">Chatham, New Zealand</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dushanbe_tajikistan">
      <source>Dushanbe, Tajikistan</source>
      <translation variants="no">Dushanbe, Tajikistan</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_opt_help">
      <source>Not specified</source>
      <translation variants="no">vi #Help</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_list_time">
      <source>Not specified</source>
      <translation variants="no">vi #Time</translation>
    </message>
    <message numerus="no" id="txt_clk_subtitle_city_list">
      <source>City list</source>
      <translation variants="no">vi #City list</translation>
    </message>
    <message numerus="no" id="txt_clk_list_oklahoma_city_usa">
      <source>Oklahoma City, United States of America</source>
      <translation variants="no">Thành phố Oklahoma, OK, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_panama_city_panama">
      <source>Panama City, Panama</source>
      <translation variants="no">Panama City, Panama</translation>
    </message>
    <message numerus="no" id="txt_clk_list_new_delhi_india">
      <source>New Delhi, India</source>
      <translation variants="no">New Delhi, Ấn Độ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_holy_see_vatican_city">
      <source>Holy See, Vatican City</source>
      <translation variants="no">Holy See, Vatican City</translation>
    </message>
    <message numerus="no" id="txt_clk_list_boise_usa">
      <source>Boise, United States of America</source>
      <translation variants="no">Boise, ID, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ln_hrsln_mins">
      <source>&lt;+/-&gt;%Ln hrs,%Ln mins</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bucharest_romania">
      <source>Bucharest, Romania</source>
      <translation variants="no">Bucharest, Rumani</translation>
    </message>
    <message numerus="no" id="txt_clk_list_aktau_kaz">
      <source>Aktau, Kazakhstan</source>
      <translation variants="no">Aktau, Kazakhstan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_gibraltar_gibraltar">
      <source>Gibraltar, Gibraltar</source>
      <translation variants="no">Gibraltar, Gibraltar</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_delete">
      <source>Delete</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_clk_subtitle_world_clock">
      <source>World Clock</source>
      <translation variants="no">Đồng hồ thế giới</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kingston_jamaica">
      <source>Kingston, Jamaica</source>
      <translation variants="no">Kingston, Jamaica</translation>
    </message>
    <message numerus="no" id="txt_short_caption_clock">
      <source>Clock</source>
      <translation variants="no">vi #Clock</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_description">
      <source>Not specified</source>
      <translation variants="no">vi #Description</translation>
    </message>
    <message numerus="no" id="txt_clk_list_monrovia_liberia">
      <source>Monrovia, Liberia</source>
      <translation variants="no">Monrovia, Liberia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dili_east_timor">
      <source>Dili, East Timor</source>
      <translation variants="no">Dili, Đông Timor</translation>
    </message>
    <message numerus="no" id="txt_clk_list_pretoria_safrica">
      <source>Pretoria, South Africa</source>
      <translation variants="no">Pretoria, Nam Phi</translation>
    </message>
    <message numerus="no" id="txt_clk_list_maceio_brazil">
      <source>Maceio, Brazil</source>
      <translation variants="no">Maceio, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_val_alarm">
      <source>Alarm</source>
      <translation variants="no">Âm báo</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saipan_mariana_isl">
      <source>Saipan, Mariana Islands</source>
      <translation variants="no">Saipan, Quần đảo Mariana</translation>
    </message>
    <message numerus="no" id="txt_clk_list_salt_lake_city_usa">
      <source>Salt Lake City, United States of America</source>
      <translation variants="no">Thành phố Salt Lake, UT, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_hrs">
      <source>%1 hrs</source>
      <translation variants="no">vi ##%1 hrs</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dawson_creek_canada">
      <source>Dawson Creek, Canada</source>
      <translation variants="no">Dawson Creek, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_laayoune_west_sahara">
      <source>Laayoune, Western Sahara</source>
      <translation variants="no">Laayoune, Tây Sahara</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kaliningrad_russia">
      <source>Kaliningrad, Russia</source>
      <translation variants="no">Kaliningrad, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_list_anadyr_russia">
      <source>Anadyr, Russia</source>
      <translation variants="no">Anadyr, Nga</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tórshavn_faroe_isl">
      <source>Tórshavn, Faroe Islands</source>
      <translation variants="no">Tórshavn, Quần đảo Faroe</translation>
    </message>
    <message numerus="no" id="txt_clk_list_buenos_aires_argen">
      <source>Buenos Aires, Argentina</source>
      <translation variants="no">Buenos Aires, Argentina</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vancouver_canada">
      <source>Vancouver, Canada</source>
      <translation variants="no">Vancouver, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_button_time">
      <source>&lt;time&gt;</source>
      <translation variants="no">Thời gian</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vilnius_lithuania">
      <source>Vilnius, Lithuania</source>
      <translation variants="no">Vilnius, Lithuania</translation>
    </message>
    <message numerus="no" id="txt_clk_list_minneapolis_usa">
      <source>Minneapolis, United States of America</source>
      <translation variants="no">Minneapolis, MN, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_asuncion_paraguay">
      <source>Asuncion, Paraguay</source>
      <translation variants="no">Asunción, Paraguay</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sioux_falls_sd_usa">
      <source>Sioux Falls, SD, United States of America</source>
      <translation variants="no">Sioux Falls, SD, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_danmarkshavn_greenland">
      <source>Danmarkshavn, Greenland</source>
      <translation variants="no">Danmarkshavn, Greenland</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_info_date_info">
      <source>&lt;time info, date info&gt;</source>
      <translation variants="no">Giờ, ngày</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_repeat_daily">
      <source>Not specified</source>
      <translation variants="no">vi #Daily</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_repeat_on_workdays">
      <source>Not specified</source>
      <translation variants="no">vi #Workdays</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_date">
      <source>Not specified</source>
      <translation variants="no">vi #Date:</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_time">
      <source>Not specified</source>
      <translation variants="no">vi #Select time</translation>
    </message>
    <message numerus="no" id="txt_clock_button_time">
      <source>Not specified</source>
      <translation variants="no">vi #Select time</translation>
    </message>
    <message numerus="no" id="txt_clock_tumbler_time">
      <source>Not specified</source>
      <translation variants="no">vi #Time</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_workdays">
      <source>Not specified</source>
      <translation variants="no">vi #Workdays:</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ponta_delgada_azores">
      <source>Ponta Delgada, Azores</source>
      <translation variants="no">Ponta Delgada, Azores</translation>
    </message>
    <message numerus="no" id="txt_clk_list_zagreb_croatia">
      <source>Zagreb, Croatia</source>
      <translation variants="no">Zagreb, Croatia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bujumbura_burundi">
      <source>Bujumbura, Burundi</source>
      <translation variants="no">Bujumbura, Burundi</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kinshasa_drc">
      <source>Kinshasa, Democratic Republic of the Congo</source>
      <translation variants="no">Kinshasa, Cộng hòa Dân chủ Côngô</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saint_georges_grenada">
      <source>Saint George's, </source>
      <translation variants="no">Saint George's, Grenada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_moroni_comoros">
      <source>Moroni, Comoros</source>
      <translation variants="no">Moroni, Comoros</translation>
    </message>
    <message numerus="no" id="txt_clk_list_macau_macau">
      <source>Macau, Macau</source>
      <translation variants="no">Macau, Macau</translation>
    </message>
    <message numerus="no" id="txt_clk_list_winnipeg_canada">
      <source>Winnipeg, Canada</source>
      <translation variants="no">Winnipeg, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lilongwe_malawi">
      <source>Lilongwe, Malawi</source>
      <translation variants="no">Lilongwe, Malawi</translation>
    </message>
    <message numerus="no" id="txt_clk_list_alofi_niue">
      <source>Alofi, Niue</source>
      <translation variants="no">Alofi, Niue</translation>
    </message>
    <message numerus="no" id="txt_clk_list_fernando_de_noronha_brazil">
      <source>Fernando de Noronha, Brazil</source>
      <translation variants="no">Fernando de Noronha, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_omaha_usa">
      <source>Omaha, United States of America</source>
      <translation variants="no">Omaha, NE, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yaoundé_cameroon">
      <source>Yaoundé, Cameroon</source>
      <translation variants="no">Yaoundé, Cameroon</translation>
    </message>
    <message numerus="no" id="txt_clk_list_belo_horizonte_brazil">
      <source>Belo Horizonte, Brazil</source>
      <translation variants="no">Belo Horizonte, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_niamey_niger">
      <source>Niamey, Niger</source>
      <translation variants="no">Niamey, Niger</translation>
    </message>
    <message numerus="no" id="txt_clk_list_beijing_china">
      <source>Beijing, China</source>
      <translation variants="no">Beijing, Trung Quốc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_scoresbysund_greenland">
      <source>Scoresbysund, Greenland</source>
      <translation variants="no">Scoresbysund, Greenland</translation>
    </message>
    <message numerus="no" id="txt_clk_list_brussels_belgium">
      <source>Brussels, Belgium</source>
      <translation variants="no">Brussels, Bỉ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_khartoum_sudan">
      <source>Khartoum, Sudan</source>
      <translation variants="no">Khartoum, Sudan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_colonia_micronesia">
      <source>Colonia, Micronesia</source>
      <translation variants="no">Colonia, Micronesia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_makassar_indonesia">
      <source>Makassar, Indonesia</source>
      <translation variants="no">Makassar, Inđô</translation>
    </message>
    <message numerus="no" id="txt_clk_list_istanbul_turkey">
      <source>Istanbul, Turkey</source>
      <translation variants="no">Istanbul, Thổ Nhĩ Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd">
      <source>yyyy mm dd</source>
      <translation variants="no">nnnn tt nn</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cardiff_uk">
      <source>Cardiff, United Kingdom</source>
      <translation variants="no">Cardiff, Vương quốc Anh</translation>
    </message>
    <message numerus="no" id="txt_clk_list_algiers_algeria">
      <source>Algiers, Algeria</source>
      <translation variants="no">Algiers, Algeria</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sanaa_yemen">
      <source>Sanaa, Yemen</source>
      <translation variants="no">Sanaa, Yemen</translation>
    </message>
    <message numerus="no" id="txt_clk_list_taskhkent_uzbekistan">
      <source>Tashkent, Uzbekistan</source>
      <translation variants="no">Tashkent, Uzbekistan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_edinburgh_uk">
      <source>Edinburgh, United Kingdom</source>
      <translation variants="no">Edinburgh, Vương quốc Anh</translation>
    </message>
    <message numerus="no" id="txt_clk_list_iqaluit_canada">
      <source>Iqaluit, Canada</source>
      <translation variants="no">Iqaluit, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_skopje_macedonia">
      <source>Skopje, Macedonia</source>
      <translation variants="no">Skopje, Macedonia</translation>
    </message>
    <message numerus="no" id="txt_clk_list_milwaukee_wi_usa">
      <source>Milwaukee, WI, United States of America</source>
      <translation variants="no">Milwaukee, WI, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_list_luanda_angola">
      <source>Luanda, Angola</source>
      <translation variants="no">Luanda, Angola</translation>
    </message>
    <message numerus="no" id="txt_clk_list_victoria_seychelles">
      <source>Victoria, Seychelles</source>
      <translation variants="no">Victoria, Seychelles</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bangui_car">
      <source>Bangui, Central African Republic</source>
      <translation variants="no">Bangul, Cộng hòa Trung Phi</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tijuana_mexico">
      <source>Tijuana, Mexico</source>
      <translation variants="no">Tijuana, Mêhicô</translation>
    </message>
    <message numerus="no" id="txt_clk_list_charlottetown_canada">
      <source>Charlottetown, Canada</source>
      <translation variants="no">Charlottetown, Canada</translation>
    </message>
    <message numerus="no" id="txt_clk_list_perth_aus">
      <source>Perth, Australia</source>
      <translation variants="no">Perth, Úc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_city_name_country_name">
      <source>&lt;city name, country name&gt;</source>
      <translation variants="no">Thêm thành phố</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kingstown_st_vincent">
      <source>Kingstown, St. Vincent</source>
      <translation variants="no">Kingstown, Saint Vincent và Grenadines</translation>
    </message>
    <message numerus="no" id="txt_clk_list_oslo_norway">
      <source>Oslo, Norway</source>
      <translation variants="no">Oslo, Na Uy</translation>
    </message>
    <message numerus="no" id="txt_clk_list_macapa_brazil">
      <source>Macapa, Brazil</source>
      <translation variants="no">Macapa, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_apia samoa">
      <source>Apia, Samoa</source>
      <translation variants="no">Apia, Samoa</translation>
    </message>
    <message numerus="no" id="txt_clk_list_brazzaville_drc">
      <source>Brazzaville, Democratic Republic of the Congo</source>
      <translation variants="no">Brazzaville, Cộng hòa Congo</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_repeat_on_workdays">
      <source>Not specified</source>
      <translation variants="no">vi #Workdays</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_tuesday">
      <source>Not specified</source>
      <translation variants="no">vi #Tuesday</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tokya_japan">
      <source>Tokya, Japan</source>
      <translation variants="no">Tokyo, Nhật Bản</translation>
    </message>
    <message numerus="no" id="txt_clk_list_brasilia_brazil">
      <source>Brasilia, Brazil</source>
      <translation variants="no">Brasilia, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_melbourne_aus">
      <source>Melbourne, Australia</source>
      <translation variants="no">Melbourne, Úc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_casablanca_morocco">
      <source>Casablanca, Morocco</source>
      <translation variants="no">Casablanca, Ma rốc</translation>
    </message>
    <message numerus="no" id="txt_clk_list_porto_novo_benin">
      <source>Porto-Novo, Benin</source>
      <translation variants="no">Porto-Novo, Benin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_amman_jordan">
      <source>Amman, Jordan</source>
      <translation variants="no">Amman, Jordan</translation>
    </message>
    <message numerus="no" id="txt_clk_list_accra_ghana">
      <source>Accra, Ghana</source>
      <translation variants="no">Accra, Ghana</translation>
    </message>
    <message numerus="no" id="txt_clk_list_goiania_brazil">
      <source>Goiania, Brazil</source>
      <translation variants="no">Goiania, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tirana_albania">
      <source>Tirana, Albania</source>
      <translation variants="no">Tirana, Anbani</translation>
    </message>
    <message numerus="no" id="txt_long_caption_clock">
      <source>Clock</source>
      <translation variants="no">vi #Clock</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_saturday">
      <source>Not specified</source>
      <translation variants="no">vi #Saturday</translation>
    </message>
    <message numerus="no" id="txt_clk_list_wellington_nzealand">
      <source>Wellington, New Zealand</source>
      <translation variants="no">Wellington, New Zealand</translation>
    </message>
    <message numerus="no" id="txt_clk_list_des_moines_usa">
      <source>Des Moines, United States of America</source>
      <translation variants="no">Des Moines, IA, Hợp chúng quốc Hoa Kỳ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">Thứ Ba</translation>
    </message>
    <message numerus="no" id="txt_clk_list_porto_velho_brazil">
      <source>Porto Velho, Brazil</source>
      <translation variants="no">Porto Velho, Braxin</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_monday">
      <source>Monday</source>
      <translation variants="no">Thứ Hai</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vienna_austria">
      <source>Vienna, Austria</source>
      <translation variants="no">Vienna, Áo</translation>
    </message>
  </context>
</TS>