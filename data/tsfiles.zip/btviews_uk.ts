<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Source 0</source>
      <translation variants="no">Змінити час видимості</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_input_devices">
      <source>Source 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Пристрої вводу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>Source 2</source>
      <translation variants="no">Усі пристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_phones">
      <source>Source 3</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає телефонів</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_input_devices">
      <source>Source 4</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Парні пристрої вводу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>Source 5</source>
      <translation variants="no">Деталі %1</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Source 6</source>
      <translation variants="no">Італійська</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Source 7</source>
      <translation variants="yes">
        <lengthvariant priority="1">Парний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_paired_devices">
      <source>Source 8</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає інших парних пристроїв</lengthvariant>
        <lengthvariant priority="2">Немає інших парних пристр.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>Source 9</source>
      <translation variants="no">%[17]1 з’єднано</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Source 10</source>
      <translation variants="yes">
        <lengthvariant priority="1">Автоматично</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Source 11</source>
      <translation variants="yes">
        <lengthvariant priority="1">Парний, надійний, з’єднаний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Source 12</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Source 13</source>
      <translation variants="yes">
        <lengthvariant priority="1">Парний, з’єднаний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_phones">
      <source>Source 14</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Телефони</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Source 15</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Усі пристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Source 16</source>
      <translation variants="no">Французька (Бельгія)</translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Source 17</source>
      <translation variants="yes">
        <lengthvariant priority="1">Пристрій вводу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Source 18</source>
      <translation variants="no">Датська</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Source 19</source>
      <translation variants="yes">
        <lengthvariant priority="1">Завжди запитувати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>Source 20</source>
      <translation variants="no">США - міжнародна</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Source 21</source>
      <translation variants="no">Вимкнено</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_input_devices">
      <source>Source 22</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає парних пристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Source 23</source>
      <translation variants="no">Парні пристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_devices">
      <source>Source 24</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Інші пристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Source 25</source>
      <translation variants="yes">
        <lengthvariant priority="1">Комп’ютер</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>Source 26</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #On and hidden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Source 27</source>
      <translation variants="no">Фінська, Шведська</translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Source 28</source>
      <translation variants="yes">
        <lengthvariant priority="1">Інший</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Source 29</source>
      <translation variants="no">uk #Unpair</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_phones">
      <source>Source 30</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Парні телефони</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Source 31</source>
      <translation variants="no">Норвезька</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Source 32</source>
      <translation variants="no">Португальська</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Source 33</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Source 34</source>
      <translation variants="no">Розкладка клавіатури</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Source 35</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки клавіатури</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>Source 36</source>
      <translation variants="no">Британська</translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Source 37</source>
      <translation variants="yes">
        <lengthvariant priority="1">Заблоковано</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>Source 38</source>
      <translation variants="no">Німецька</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>Source 39</source>
      <translation variants="no">США - Дворак</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Source 40</source>
      <translation variants="no">Іспанська</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_audio_devices">
      <source>Source 41</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Аудіопристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_computers">
      <source>Source 42</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Комп’ютери</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>Source 43</source>
      <translation variants="yes">
        <lengthvariant priority="1">Не знайдено пристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Source 44</source>
      <translation variants="yes">
        <lengthvariant priority="1">Заблоковано</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_audio_devices">
      <source>Source 45</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає аудіопристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>Source 46</source>
      <translation variants="no">Французька</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_computers">
      <source>Source 47</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає комп’ютерів</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_audio_devices">
      <source>Source 48</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Парні аудіопристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Source 49</source>
      <translation variants="no">uk #Search completed</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_paired_devices">
      <source>Source 50</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Інші парні пристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Source 51</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Додаткові установки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_audio_devices">
      <source>Source 52</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає парних аудіопристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Source 53</source>
      <translation variants="no">uk #Pair</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Source 54</source>
      <translation variants="yes">
        <lengthvariant priority="1">З’єднання</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_1">
      <source>Source 55</source>
      <translation variants="no">Bluetooth - %1</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Source 56</source>
      <translation>
        <numerusform plurality="a">uk #Visible for %Ln minute</numerusform>
        <numerusform plurality="b">uk #Visible for %Ln minutes</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_phones">
      <source>Source 57</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає парних телефонів</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_devices">
      <source>Source 58</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає інших пристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Source 59</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки миші</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Source 60</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Visible and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Source 61</source>
      <translation variants="no">Видалити</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>Source 62</source>
      <translation variants="no">Англійська (США)</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Source 63</source>
      <translation variants="no">uk #Searching</translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Source 64</source>
      <translation variants="yes">
        <lengthvariant priority="1">З’єднано</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>Source 65</source>
      <translation variants="no">Профіль доступу до SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Source 66</source>
      <translation variants="no">Видал. парні пристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Source 67</source>
      <translation variants="no">Увімкнено</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Source 68</source>
      <translation variants="no">Заблоковані пристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Source 69</source>
      <translation variants="no">uk #Hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Source 70</source>
      <translation variants="no">Російська</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Source 71</source>
      <translation variants="no">З’єднати</translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Source 72</source>
      <translation variants="no">uk #Disconnect</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Source 73</source>
      <translation variants="no">uk #Device details</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>Source 74</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #On and visible</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Source 75</source>
      <translation variants="no">Роз’єднати</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>Source 76</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає пристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Source 77</source>
      <translation variants="no">uk #Bluetooth - Found devices</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Source 78</source>
      <translation variants="yes">
        <lengthvariant priority="1">Телефон</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Source 79</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Hidden and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Source 80</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Парні пристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>Source 81</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає парних пристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_input_devices">
      <source>Source 82</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає пристроїв вводу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Source 83</source>
      <translation variants="yes">
        <lengthvariant priority="1">Парний, надійний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Source 84</source>
      <translation variants="no">Додаткові установки</translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Source 85</source>
      <translation variants="no">uk #Connect</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Source 86</source>
      <translation variants="no">uk #Visible</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Source 87</source>
      <translation variants="no">Голландська</translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Source 88</source>
      <translation variants="yes">
        <lengthvariant priority="1">Аудіопристрій</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_computers">
      <source>Source 89</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає парних комп’ютерів</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_computers">
      <source>Source 90</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Парні комп’ютери</lengthvariant>
      </translation>
    </message>
  </context>
</TS>