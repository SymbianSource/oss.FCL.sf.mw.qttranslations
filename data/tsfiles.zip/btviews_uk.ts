<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Paired</source>
      <translation variants="yes">
        <lengthvariant priority="1">Парний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>%1 connected</source>
      <translation variants="no">%[17]1 з’єднано</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Автоматично</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_devices">
      <source>Bluetooth - Other devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Інші пристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Увімкнено (прихований)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Always ask</source>
      <translation variants="yes">
        <lengthvariant priority="1">Завжди запитувати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>German</source>
      <translation variants="no">Німецька</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Spanish</source>
      <translation variants="no">Іспанська</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Вимкнено</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_computers">
      <source>Bluetooth - Computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Комп’ютери</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>No found devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Не знайдено пристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Search done</source>
      <translation variants="no">uk #Search completed</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_audio_devices">
      <source>No paired audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає парних аудіопристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Bluetooth - Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Додаткові установки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">uk #Disconnect</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">З’єднання</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Увімкнено (видимий)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Bluetooth - Found devices</source>
      <translation variants="no">uk #Bluetooth devices found</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Enabled</source>
      <translation variants="no">Увімкнено</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Hidden</source>
      <translation variants="no">uk #Hidden</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">З’єднано (прихований)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_input_devices">
      <source>No input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає пристроїв вводу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Додаткові установки</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>No paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає парних пристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">Усі пристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Paired, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Парний, з’єднаний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>International US</source>
      <translation variants="no">США - міжнародна</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Finnish/Swedish</source>
      <translation variants="no">Фінська, Шведська</translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">Заблоковано</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">З’єднано</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Connect</source>
      <translation variants="no">З’єднати</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Dutch</source>
      <translation variants="no">Голландська</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Change visibility time</source>
      <translation variants="no">Змінити час видимості</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_input_devices">
      <source>Bluetooth - Input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Пристрої вводу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_phones">
      <source>Bluetooth - Phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Телефони</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Bluetooth - All devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Усі пристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_phones">
      <source>No phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає телефонів</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Danish</source>
      <translation variants="no">Датська</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_phones">
      <source>Bluetooth - Paired phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Парні телефони</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Portuguese</source>
      <translation variants="no">Португальська</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Keyboard settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки клавіатури</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>UK</source>
      <translation variants="no">Британська</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Visible for %Ln min</source>
      <translation>
        <numerusform plurality="a">uk #Visible for %Ln minute</numerusform>
        <numerusform plurality="b">uk #Visible for %Ln minutes</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вимкнено</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_computers">
      <source>No computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає комп’ютерів</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_devices">
      <source>No other devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає інших пристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Searching…</source>
      <translation variants="no">uk #Searching</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Mouse settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки миші</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Audio device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Аудіопристрій</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">З’єднано (видимий)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>No devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає пристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_slidervalue_l1_min">
      <source>%L1 min</source>
      <translation variants="no">%L1</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_phones">
      <source>Only phones</source>
      <translation variants="no">Тільки телефони</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Italian</source>
      <translation variants="no">Італійська</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Paired devices</source>
      <translation variants="no">Парні пристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>US Dvorak</source>
      <translation variants="no">США - Дворак</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_audio_devices">
      <source>Bluetooth - Audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Аудіопристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Pair</source>
      <translation variants="no">uk #Pair</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_1">
      <source>Bluetooth - %1</source>
      <translation variants="no">Bluetooth - %1</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Russian</source>
      <translation variants="no">Російська</translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Connect</source>
      <translation variants="no">uk #Connect</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_input_devices">
      <source>Only input devices</source>
      <translation variants="no">Тільки пристрої вводу</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_computers">
      <source>only computers</source>
      <translation variants="no">Тільки комп’ютери</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_other_devices">
      <source>Only other devices</source>
      <translation variants="no">Тільки інші пристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show">
      <source>Show</source>
      <translation variants="no">Показати</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>%1 details</source>
      <translation variants="no">Деталі %1</translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">Інший</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">Профіль доступу до SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Visible</source>
      <translation variants="no">uk #Shown to all</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Bluetooth - Paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Парні пристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_audio_devices">
      <source>Bluetooth - Paired audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Парні аудіопристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_paired_devices">
      <source>No other paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає інших парних пристроїв</lengthvariant>
        <lengthvariant priority="2">Немає інших парних пристр.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Computer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Комп’ютер</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Blocked devices</source>
      <translation variants="no">Заблоковані пристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Paired, trusted</source>
      <translation variants="yes">
        <lengthvariant priority="1">Парний, надійний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">Усі пристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_input_devices">
      <source>Bluetooth - Paired input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Парні пристрої вводу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_input_devices">
      <source>No paired input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає парних пристроїв</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Unpair</source>
      <translation variants="no">uk #Remove pairing</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">Заблоковано</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_paired_devices">
      <source>Bluetooth - Other paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Інші парні пристрої</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_phones">
      <source>No paired phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає парних телефонів</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Remove paired devices</source>
      <translation variants="no">Видал. парні пристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Device details</source>
      <translation variants="no">uk #Device details</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Телефон</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_computers">
      <source>No paired computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає парних комп’ютерів</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_audio_devices">
      <source>only audio devices</source>
      <translation variants="no">Тільки аудіопристрої</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Paired, trusted, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Парний, надійний, з’єднаний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Belgian</source>
      <translation variants="no">Французька (Бельгія)</translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Input device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Пристрій вводу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Keyboard layout</source>
      <translation variants="no">Розкладка клавіатури</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>French</source>
      <translation variants="no">Французька</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Remove</source>
      <translation variants="no">Видалити</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>US</source>
      <translation variants="no">Англійська (США)</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Роз’єднати</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_computers">
      <source>Bluetooth - Paired computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Парні комп’ютери</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Norwegian</source>
      <translation variants="no">Норвезька</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_audio_devices">
      <source>No audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає аудіопристроїв</lengthvariant>
      </translation>
    </message>
  </context>
</TS>