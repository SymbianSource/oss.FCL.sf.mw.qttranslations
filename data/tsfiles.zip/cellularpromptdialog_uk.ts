<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_title_connect_to_internet_using_cellular_d">
      <source>Connect to Internet using cellular data? Data costs may apply.</source>
      <translation variants="no">uk #Connect to Internet using cellular data? Data costs may apply.</translation>
    </message>
    <message numerus="no" id="txt_occ_title_connect_to_internet_in_this_country">
      <source>Connect to Internet using cellular data? Phone is outside of home network, and data costs may increase considerably. To allow connecting automatically, adjust the Connection settings.</source>
      <translation variants="no">uk #Connect to Internet using cellular data? Phone is outside of home network, and data costs may increase considerably. To allow connecting automatically, adjust the Connection settings.</translation>
    </message>
    <message numerus="no" id="txt_occ_button_connect_this_time">
      <source>Connect this time</source>
      <translation variants="no">З’єднатися цього разу</translation>
    </message>
    <message numerus="no" id="txt_occ_button_connect_automatically">
      <source>Connect automatically</source>
      <translation variants="no">З’єднуватися автоматично</translation>
    </message>
    <message numerus="no" id="txt_occ_button_cellular_cancel">
      <source>Cancel</source>
      <translation variants="no">Скасувати</translation>
    </message>
  </context>
</TS>