<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mus_other_unknown6">
      <source>Unknown</source>
      <translation variants="no">uk #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown5">
      <source>Unknown</source>
      <translation variants="no">uk #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown7">
      <source>Unknown </source>
      <translation variants="no">uk #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown1">
      <source>Unknown</source>
      <translation variants="no">uk #Unknown</translation>
    </message>
    <message numerus="yes" id="txt_mus_dpopinfo_ln_songs_added">
      <source>%Ln songs added</source>
      <translation>
        <numerusform plurality="a">Додано %Ln пісню</numerusform>
        <numerusform plurality="b">Додано %Ln пісні</numerusform>
        <numerusform plurality="c">Додано %Ln пісень</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_complete">
      <source>Refresh complete</source>
      <translation variants="yes">
        <lengthvariant priority="1">Оновлення завершено</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_more_recommendations">
      <source>More recommendations</source>
      <translation variants="no">uk #More recommendations</translation>
    </message>
    <message numerus="no" id="txt_mus_info_no_music">
      <source>(No music)</source>
      <translation variants="no">uk #(no music)</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_stopped">
      <source>Refresh stopped</source>
      <translation variants="yes">
        <lengthvariant priority="1">Оновлення зупинено</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Невідомо</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_refreshing">
      <source>Refreshing...</source>
      <translation variants="yes">
        <lengthvariant priority="1">Триває оновлення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_share">
      <source>Share</source>
      <translation variants="no">uk #Share</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_song_details">
      <source>Song details </source>
      <translation variants="yes">
        <lengthvariant priority="1">Деталі пісні</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_audio_effects">
      <source>Audio effects</source>
      <translation variants="yes">
        <lengthvariant priority="1">Звукові ефекти</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_shuffle">
      <source>Shuffle</source>
      <translation variants="no">uk #Shuffle</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown">
      <source>Unknown</source>
      <translation variants="no">uk #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_playlist">
      <source>Select playlist:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вибір списку відтворення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Недавно відтворювані</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Невідомо</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Недавно відтворювані</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Невідомо</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_left">
      <source>Left</source>
      <translation variants="yes">
        <lengthvariant priority="1">Лівий</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_centre">
      <source>Centre</source>
      <translation variants="yes">
        <lengthvariant priority="1">Центр</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Невідомо</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown_all">
      <source>Unknown - All</source>
      <translation variants="yes">
        <lengthvariant priority="1">Невідомо - Усі</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_1_all">
      <source>%1 - All</source>
      <translation variants="no">%1 - Усі</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_new_playlist">
      <source>New playlist</source>
      <translation variants="no">Новий список відтвор.</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_shuffle">
      <source>Shuffle</source>
      <translation variants="yes">
        <lengthvariant priority="1">Випадкове відтворення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_music">
      <source>Music</source>
      <translation variants="no">uk #Music</translation>
    </message>
    <message numerus="no" id="txt_mus_list_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">Поп-музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">Недавно додані</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_off">
      <source>Off</source>
      <translation variants="no">Вимкн.</translation>
    </message>
    <message numerus="no" id="txt_mus_list_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Рок</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_audio_effects">
      <source>Audio effects</source>
      <translation variants="no">Звукові ефекти</translation>
    </message>
    <message numerus="no" id="txt_mus_list_bass_booster">
      <source>Bass booster</source>
      <translation variants="yes">
        <lengthvariant priority="1">Підсилювання басу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_on">
      <source>Repeat on</source>
      <translation variants="no">Увімкнути повтор</translation>
    </message>
    <message numerus="no" id="txt_mus_title_music">
      <source>Music</source>
      <translation variants="no">Музика</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Невідомо</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_left_l1">
      <source>Left %L1%</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Left %L1%</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown4">
      <source>Unknown</source>
      <translation variants="no">uk #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_equalizer">
      <source>Equalizer</source>
      <translation variants="no">Еквалайзер</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_all_songs">
      <source>All songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Усі пісні</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">Класична музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Улюблені</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_inspire_me">
      <source>Inspire me</source>
      <translation variants="yes">
        <lengthvariant priority="1">Рекомендації</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_music">
      <source>Music</source>
      <translation variants="no">Музика</translation>
    </message>
    <message numerus="no" id="txt_mus_menu_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">Додати до списку відтв.</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_off">
      <source>Repeat off</source>
      <translation variants="no">Вимкнути повтор</translation>
    </message>
    <message numerus="no" id="txt_mus_button_shuffle">
      <source>Shuffle</source>
      <translation variants="yes">
        <lengthvariant priority="1">Випадкове відтворення</lengthvariant>
        <lengthvariant priority="2">Випадк. відтв.</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_subhead_ln_songs">
      <source>%Ln songs</source>
      <translation>
        <numerusform plurality="a">%Ln пісня</numerusform>
        <numerusform plurality="b">%Ln пісні</numerusform>
        <numerusform plurality="c">%Ln пісень</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_on">
      <source>On</source>
      <translation variants="no">Увімкн.</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">Недавно додані</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Улюблені</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_menu_view_details">
      <source>View details</source>
      <translation variants="no">Дивитися деталі</translation>
    </message>
    <message numerus="no" id="txt_mus_title_remove_songs">
      <source>Remove songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Видалити пісні:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_send_via_bluetooth">
      <source>Send via Bluetooth</source>
      <translation variants="no">Надісл. через Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_select_a_song">
      <source>Select a song:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть пісню:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_stereo_widening">
      <source>Stereo widening</source>
      <translation variants="no">Розширення стерео</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown3">
      <source>Unknown</source>
      <translation variants="no">uk #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown3">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Невідомо</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness">
      <source>Loudness</source>
      <translation variants="no">Гучність</translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_right">
      <source>Right</source>
      <translation variants="yes">
        <lengthvariant priority="1">Прав.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_refresh_library">
      <source>Refresh library</source>
      <translation variants="no">Оновити бібліотеку</translation>
    </message>
    <message numerus="no" id="txt_mus_list_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">Джаз</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_caption_music">
      <source>Music</source>
      <translation variants="no">uk #Music</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_songs">
      <source>Select songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть пісні:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_right_l1">
      <source>Right %L1%</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Right %L1%</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_mark_all">
      <source>Mark all</source>
      <translation variants="no">uk #Mark all</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown2">
      <source>Unknown</source>
      <translation variants="no">uk #Unknown</translation>
    </message>
    <message numerus="yes" id="txt_mus_info_ln_songs_added">
      <source>%Ln songs added</source>
      <translation>
        <numerusform plurality="a">Додано %Ln пісню</numerusform>
        <numerusform plurality="b">Додано %Ln пісні</numerusform>
        <numerusform plurality="c">Додано %Ln пісень</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">Додати до списку відтв.</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name_entry_playlist_l1">
      <source>Playlist %L1</source>
      <translation variants="no">uk #Playlist %L1</translation>
    </message>
    <message numerus="no" id="txt_mus_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">uk #Unmark all</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Невідомо</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_to_get_music_visit_ovi_music">
      <source>To get music, visit Ovi Music.</source>
      <translation variants="no">uk #To get music, visit Music store.</translation>
    </message>
    <message numerus="no" id="txt_mus_list_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вимкн.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_playlist">
      <source>Delete playlist?</source>
      <translation variants="no">Видалити список відтворення?</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name">
      <source>Enter name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Назва:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_album">
      <source>Delete album?</source>
      <translation variants="no">Видалити альбом?</translation>
    </message>
    <message numerus="no" id="txt_mus_list_ovi_music">
      <source>Ovi Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Музичний магазин</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_button_new">
      <source>New</source>
      <translation variants="no">Новий</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_balance">
      <source>Balance</source>
      <translation variants="no">Баланс</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_preset">
      <source>Select preset:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть установку:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_song">
      <source>Delete song?</source>
      <translation variants="no">Видалити пісню?</translation>
    </message>
  </context>
</TS>