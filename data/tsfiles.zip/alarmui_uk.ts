<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Calendar alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">Сигнал календаря</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>To-do note</source>
      <translation variants="yes">
        <lengthvariant priority="1">Сигнал нотатки справ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_silence">
      <source>Silence</source>
      <translation variants="no">uk ##Silence</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тиша</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Snooze</source>
      <translation variants="yes">
        <lengthvariant priority="1">Затримка</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_time">
      <source>%2</source>
      <translation variants="no">uk ##%2</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snooxed_for_ln_minute">
      <source>Alarm snooxed for %Ln minutes</source>
      <translation>
        <numerusform plurality="a">Сигнал затримано на %Ln хвилину</numerusform>
        <numerusform plurality="b">Сигнал затримано на %Ln хвилини</numerusform>
        <numerusform plurality="c">Сигнал затримано на %Ln хвилин</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_dialog_snooze">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">Зупинити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_date">
      <source>%1</source>
      <translation variants="no">uk ##%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_date">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_slide_down_to_stop">
      <source>Slide down to stop</source>
      <translation variants="no">uk ##Slide down to stop</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Clock alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">Сигнал будильника</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_snooze">
      <source>Snooze</source>
      <translation variants="no">uk ##Snooze</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Switch phone on ?</source>
      <translation variants="no">Увімкнути пристрій?</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_time">
      <source>%2</source>
      <translation variants="no">%2</translation>
    </message>
  </context>
</TS>