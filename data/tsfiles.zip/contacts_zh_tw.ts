<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phob_info_no_services_activated_would_you_lik">
      <source>No services activated, would you like to do it now?</source>
      <translation variants="no">未啟動服務。是否現在啟動？</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_home">
      <source>Email (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">郵件位址(住家)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_no_sim_contacts">
      <source>No SIM contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">無SIM卡連絡人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">郵件位址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">網址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">加入詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_note">
      <source>Edit note</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯備註</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_contact_card_image_to_business_c">
      <source>Add contact card image to Business card?</source>
      <translation variants="no">是否也包括名片中的影像？</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_matches">
      <source>No matches</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_url">
      <source>Add URL</source>
      <translation variants="no">加入網址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url">
      <source>Delete URL</source>
      <translation variants="no">刪除網址</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts">
      <source>All contacts</source>
      <translation variants="no">所有連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_services_activated">
      <source>No services activated.</source>
      <translation variants="no">未啟動服務</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone">
      <source>Delete Internet telephone</source>
      <translation variants="no">刪除網際網路電話</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_pager">
      <source>Delete Pager</source>
      <translation variants="no">刪除呼叫器</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_sim">
      <source>Import from SIM</source>
      <translation variants="yes">
        <lengthvariant priority="1">從SIM卡匯入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_home">
      <source>Delete Email (home)</source>
      <translation variants="no">刪除郵件位址(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_car">
      <source>Delete Car</source>
      <translation variants="no">刪除車用電話</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax">
      <source>Delete Fax</source>
      <translation variants="no">刪除傳真</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_spouse">
      <source>Delete Spouse</source>
      <translation variants="no">刪除配偶姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_date">
      <source>Add Date</source>
      <translation variants="no">加入日期</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_work">
      <source>Delete Phone (work)</source>
      <translation variants="no">刪除電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_ringing_tone">
      <source>Delete Ringing tone</source>
      <translation variants="no">刪除鈴聲</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_assistant">
      <source>Delete Assistant</source>
      <translation variants="no">刪除助理的電話號碼</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_sign_out">
      <source>Sign out</source>
      <translation variants="no">登出</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_manage_services">
      <source>Manage services</source>
      <translation variants="yes">
        <lengthvariant priority="1">管理服務</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_sip">
      <source>Delete SIP</source>
      <translation variants="no">刪除SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_my_details">
      <source>Edit My details</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯我的名片詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_company_details">
      <source>Add Company details</source>
      <translation variants="no">加入公司詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_remove_all_personal_data_from_my_c">
      <source>Remove all personal data from My card</source>
      <translation variants="no">是否從我的名片清除所有個人資料？</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_company_details">
      <source>Delete Company Details</source>
      <translation variants="no">刪除公司詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_work">
      <source>Delete Fax (work)</source>
      <translation variants="no">刪除傳真(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts_sync">
      <source>Contacts sync</source>
      <translation variants="yes">
        <lengthvariant priority="1">同步處理通訊錄</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_home">
      <source>Delete Phone (home)</source>
      <translation variants="no">刪除電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_device">
      <source>Importing contacts from Device</source>
      <translation variants="no">正在從手機匯入通訊錄</translation>
    </message>
    <message numerus="no" id="txt_phob_button_manage_services">
      <source>Manage services</source>
      <translation variants="no">管理服務</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_work">
      <source>Delete Mobile (work)</source>
      <translation variants="no">刪除行動電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_ovi">
      <source>Importing contacts from OVI</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi">
      <source>Import from OVI</source>
      <translation variants="yes">
        <lengthvariant priority="1">與Ovi通訊錄同步處理</lengthvariant>
        <lengthvariant priority="2">zh_tw #Sync with Ovi Contacts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_email">
      <source>Add Email</source>
      <translation variants="no">加入郵件位址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_number">
      <source>Add Number</source>
      <translation variants="no">加入電話號碼</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_children">
      <source>Delete Children</source>
      <translation variants="no">刪除小孩的名字</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_home">
      <source>Delete Internet telephone (home)</source>
      <translation variants="no">刪除網路電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_no_sim_card">
      <source>No SIM card</source>
      <translation variants="yes">
        <lengthvariant priority="1">無SIM卡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_birthday">
      <source>Delete Birthday</source>
      <translation variants="no">刪除生日</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_note">
      <source>Delete Note</source>
      <translation variants="no">刪除備註</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile">
      <source>Delete Mobile</source>
      <translation variants="no">刪除行動電話</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone">
      <source>Delete Phone</source>
      <translation variants="no">刪除電話</translation>
    </message>
    <message numerus="no" id="txt_phob_list_business_card">
      <source>Business card</source>
      <translation variants="no">zh_tw #Business card</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">網際網路電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">網際網路電話</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_video_call">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_video_call_work">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_video_call_home">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_home">
      <source>URL (home)</source>
      <translation variants="no">網址(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_home">
      <source>Email (home)</source>
      <translation variants="no">郵件位址(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_only_group_will_be_removed_contac">
      <source>Only group will be removed. Contacts can be found from all contacts list.</source>
      <translation variants="no">將僅刪除群組。可以在所有連絡人清單中找到連絡人。</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_countryregion">
      <source>Country/Region</source>
      <translation variants="no">國家或地區</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_1_group">
      <source>%1 group</source>
      <translation variants="no">群組%1</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_image_not_added">
      <source>Image not included.</source>
      <translation variants="no">未包括影像</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_stateprovince">
      <source>State/Province</source>
      <translation variants="no">州/省</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_work">
      <source>Fax (work)</source>
      <translation variants="no">傳真(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url">
      <source>URL</source>
      <translation variants="no">網址</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_home">
      <source>Fax (home)</source>
      <translation variants="no">傳真(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_manage_services">
      <source>Manage services</source>
      <translation variants="yes">
        <lengthvariant priority="1">管理服務</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_group">
      <source>New group</source>
      <translation variants="no">新增群組</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_delete_1_group">
      <source>Delete %1 group?</source>
      <translation variants="no">是否刪除群組%[06]1？</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_image">
      <source>Remove image</source>
      <translation variants="no">移除影像</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message_val_members">
      <source>Members</source>
      <translation variants="yes">
        <lengthvariant priority="1">成員</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_history_with_1">
      <source>History with %1</source>
      <translation variants="no">與%1的會談</translation>
    </message>
    <message numerus="no" id="txt_phob_list_received">
      <source>Received</source>
      <translation variants="no">zh_tw #Received call</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_services">
      <source>Manage services</source>
      <translation variants="no">管理服務</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_matching_contacts">
      <source>(no matching contacts)</source>
      <translation variants="no">zh_tw #(no matches)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_you_can_restore_linking_at_any_tim">
      <source>You can restore linking at any time by `Link profile´ or in Service view.</source>
      <translation variants="no">您隨時可以還原連結，只需選取"連結操作模式"或在服務檢視中還原。</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">zh_tw #Contacts</translation>
    </message>
    <message numerus="no" id="txt_phob_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">詳細地址</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">(未命名)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email">
      <source>Email</source>
      <translation variants="no">郵件位址</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_status_update">
      <source>Status update</source>
      <translation variants="no">狀態</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company_details_val_fax">
      <source>Fax</source>
      <translation variants="no">zh_tw #Fax</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ovi_val_connected_to_1">
      <source>Connected to %1</source>
      <translation variants="no">已連線至%[09]1</translation>
    </message>
    <message numerus="no" id="txt_phob_title_favorite_contacts">
      <source>Favorite contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛連絡人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_1_group_created">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">網際網路電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">關閉</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_mail_for_exchange">
      <source>Find: Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜尋：Mail for Exchange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_message">
      <source>Message</source>
      <translation variants="yes">
        <lengthvariant priority="1">透過訊息</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_phob_title_l1_matches_found">
      <source>%L1 Matches found</source>
      <translation>
        <numerusform plurality="a">找到%Ln項相符項目</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_url">
      <source>Add Url</source>
      <translation variants="no">加入網址</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_sign_in_to_res">
      <source>Sign in to restore or create account</source>
      <translation variants="yes">
        <lengthvariant priority="1">登入您的諾基亞帳號</lengthvariant>
        <lengthvariant priority="2">zh_tw #Register to create Account</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">網際網路電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_searching_1">
      <source>Searching %1</source>
      <translation variants="no">正在搜尋"%[28]1"</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ovi">
      <source>Ovi</source>
      <translation variants="no">諾基亞帳號</translation>
    </message>
    <message numerus="no" id="txt_phob_list_conference_call">
      <source>Conference call</source>
      <translation variants="no">會議通話</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_mail">
      <source>Send mail</source>
      <translation variants="no">傳送郵件</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts2">
      <source>All contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">所有連絡人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mail for Exchange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_import_contacts">
      <source>Import contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">匯入連絡人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_method">
      <source>Select method</source>
      <translation variants="yes">
        <lengthvariant priority="1">傳送</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_groups">
      <source>Delete groups</source>
      <translation variants="yes">
        <lengthvariant priority="1">刪除群組</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">透過藍牙</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_link_profiles">
      <source>Link profiles</source>
      <translation variants="yes">
        <lengthvariant priority="1">連結操作模式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_message">
      <source>Send message</source>
      <translation variants="no">傳送訊息</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_online">
      <source>Not specified</source>
      <translation variants="no">線上</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_home">
      <source>Address (home)</source>
      <translation variants="no">地址(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_company_details">
      <source>Not specified</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯公司詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_online2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_home">
      <source>Call phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號到電話(住家)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_work">
      <source>Call phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號到電話(公司)</lengthvariant>
        <lengthvariant priority="2">zh_tw #Call telephone (bus.)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete2">
      <source>Delete</source>
      <translation variants="no">刪除</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_work">
      <source>Address (work)</source>
      <translation variants="no">地址(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number">
      <source>Video call</source>
      <translation variants="no">撥打視訊電話</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_work">
      <source>Email (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">郵件位址(公司)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_contact_to_homescreen">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_address">
      <source>Add address</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_note">
      <source>Note</source>
      <translation variants="yes">
        <lengthvariant priority="1">備註</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_phone_number">
      <source>Edit phone number</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯電話號碼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_work">
      <source>Phone (work)</source>
      <translation variants="no">電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_find2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_default_saving_memory_val_phone">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile">
      <source>Mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">行動電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">zh_tw ##Contacts</translation>
    </message>
    <message numerus="no" id="txt_phob_missing_phonebook">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_assistant">
      <source>Assistant</source>
      <translation variants="no">助理的姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_take_a_new_photo">
      <source>Take a new photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">拍攝新影像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">行動電話(公司)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">放棄變更</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_my_card">
      <source>Save My card</source>
      <translation variants="no">儲存我的名片</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_my_card">
      <source>Not specified</source>
      <translation variants="no">傳送我的名片</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites">
      <source>Favorites</source>
      <translation variants="no">我的最愛連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile">
      <source>Call mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號到行動電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_internet_call_work">
      <source>Call internet call (work)</source>
      <translation variants="no">撥打網際網路通話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">撥號到電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_merge3">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_conflicts_resolving">
      <source>Conflicts resolving</source>
      <translation variants="no">解決衝突</translation>
    </message>
    <message numerus="no" id="txt_phob_list_phone_local_contacts">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">從我的最愛移除</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_import_contacts">
      <source>Import contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">匯入連絡人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_note2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">刪除</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_account">
      <source>Not specified</source>
      <translation variants="no">加入帳號</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_date">
      <source>Edit date</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_personal_ringing_tone_val_default">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">建立我的名片</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_do_you_want_to_delete_selected_con">
      <source>Do you want to delete selected contacts?</source>
      <translation variants="no">是否刪除選取的連絡人？</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_home">
      <source>Email (home)</source>
      <translation variants="no">傳送郵件(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">聊天(%[07]1)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importin_contacts_from_1">
      <source>Importing contacts from %1</source>
      <translation variants="no">zh_tw #Importing contacts from %1</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_ptt">
      <source>SIP</source>
      <translation variants="no">啟動即按即說</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_1_group_members">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_info_you_can_choose_any_of_the_following">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_internet_call">
      <source>Call internet call</source>
      <translation variants="no">撥打網際網路通話</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_company">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_reorder_favorites">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_home2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_group_name">
      <source>Group name</source>
      <translation variants="no">群組名稱</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ringing_tone">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_clear_history">
      <source>Not specified</source>
      <translation variants="no">清除交談記錄</translation>
    </message>
    <message numerus="no" id="txt_phob_title_your_phonebook_is_empty_you_can_ch">
      <source>Your Phonebook is empty</source>
      <translation variants="no">無連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">鈴聲</translation>
    </message>
    <message numerus="yes" id="txt_phob_dblist_val_ln_numbers">
      <source>%Ln numbers</source>
      <translation>
        <numerusform plurality="a">zh_tw #%Ln number</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_default_saving_memory">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show">
      <source>Show</source>
      <translation variants="no">顯示</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_name">
      <source>Enter name</source>
      <translation variants="no">zh_tw #Name</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_disconnect_all">
      <source>Not specified</source>
      <translation variants="no">中斷所有連線</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_syncronization_val_private">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create">
      <source>Create</source>
      <translation variants="yes">
        <lengthvariant priority="1">建立</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_synchronization_details">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_field">
      <source>Add field</source>
      <translation variants="yes">
        <lengthvariant priority="1">加入詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_internet_call_work">
      <source>Call internet call (work)</source>
      <translation variants="no">撥打網際網路通話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_contact_card">
      <source>Not specified</source>
      <translation variants="no">zh_tw #Save contact</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_job_title">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_work">
      <source>URL (work)</source>
      <translation variants="no">移至網址(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_phone_number">
      <source>Add phone number</source>
      <translation variants="yes">
        <lengthvariant priority="1">電話號碼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_syncronization_val_public">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_email">
      <source>Set as default email</source>
      <translation variants="no">設為預設郵件</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_children">
      <source>Children</source>
      <translation variants="no">小孩</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1">
      <source>Import from %1</source>
      <translation variants="no">zh_tw #Import from %1</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">網際網路電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_picture">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_name">
      <source>Edit contact name</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯連絡人姓名</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_assistant">
      <source>Call assistant</source>
      <translation variants="no">撥號給助理</translation>
    </message>
    <message numerus="no" id="txt_phob_list_public">
      <source>Public</source>
      <translation variants="no">zh_tw #Public</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">名字</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_home">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_work">
      <source>Video call (work)</source>
      <translation variants="no">撥打視訊電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_anniversary">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_work">
      <source>Fax (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">傳送傳真(公司)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_1_deleted">
      <source>Not specified</source>
      <translation variants="no">zh_tw #%[30]1 deleted</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_pager">
      <source>Call Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號到呼叫器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete3">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_internet_call_home">
      <source>Call internet call (home)</source>
      <translation variants="no">撥打網際網路通話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_video_call">
      <source>Not specified</source>
      <translation variants="no">視訊電話</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sufix">
      <source>Suffix</source>
      <translation variants="no">稱謂</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_group">
      <source>Delete group</source>
      <translation variants="no">刪除群組</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_nick_name">
      <source>Nick name</source>
      <translation variants="no">暱稱</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號到行動電話(住家)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_address">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone_val_default">
      <source>Default</source>
      <translation variants="no">預設鈴聲</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_manage_contacts">
      <source>Manage contacts</source>
      <translation variants="no">管理連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_home">
      <source>Video call (home)</source>
      <translation variants="no">撥打視訊電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_ln_contacts_imported">
      <source>%Ln contacts imported</source>
      <translation variants="no">%L1/%L2位連絡人已匯入</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_new">
      <source>Create new</source>
      <translation variants="no">新增</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_in_progress_l">
      <source>In progress (%L1/%L2)</source>
      <translation variants="no">連絡人匯入中(%L1/%L2)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_missing_all_contacts">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">年度紀念日</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_street2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_favorites">
      <source>Favorites</source>
      <translation variants="no">我的最愛連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_and_phonenumber">
      <source>Name and phonenumber</source>
      <translation variants="no">姓名和電話號碼</translation>
    </message>
    <message numerus="no" id="txt_phob_list_family">
      <source>Family</source>
      <translation variants="yes">
        <lengthvariant priority="1">家人詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_change_picture">
      <source>Change picture</source>
      <translation variants="no">變更影像</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_reorder_groups">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_im">
      <source>Not specified</source>
      <translation variants="no">聊天詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_first_nam">
      <source>First name Last name</source>
      <translation variants="no">名字 姓氏</translation>
    </message>
    <message numerus="no" id="txt_phob_button_select_location">
      <source>Select location</source>
      <translation variants="no">zh_tw #Find on map</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_birthday">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email">
      <source>Email</source>
      <translation variants="no">傳送郵件</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization_val_none">
      <source>none</source>
      <translation variants="no">無</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_dublicated_contacts">
      <source>Dublicated contacts</source>
      <translation variants="no">重複的連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_button_activity_stream">
      <source>Activity stream</source>
      <translation variants="no">社交收取點</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_image">
      <source>Image</source>
      <translation variants="no">影像</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_country">
      <source>Country</source>
      <translation variants="no">國家或地區</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_work">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_refresh">
      <source>Refresh</source>
      <translation variants="no">重新整理</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_home">
      <source>Delete Mobile (home)</source>
      <translation variants="no">刪除行動電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_work">
      <source>URL (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">網址(公司)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email">
      <source>Delete Email</source>
      <translation variants="no">刪除郵件位址</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_service">
      <source>Add service</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax">
      <source>Fax</source>
      <translation variants="no">傳送傳真</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage">
      <source>Manage contacts</source>
      <translation variants="no">管理連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_presentation_settings">
      <source>Presentation settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">連絡人設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization_val_public">
      <source>public</source>
      <translation variants="no">公開</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_number">
      <source>Conference number</source>
      <translation variants="no">會議通話號碼</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_work">
      <source>Send mail (Work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">傳送郵件(公司)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name_separator">
      <source>Last name, First name</source>
      <translation variants="no">姓氏, 名字</translation>
    </message>
    <message numerus="no" id="txt_phob_list_missed_call">
      <source>Missed call</source>
      <translation variants="no">zh_tw #Missed call</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_pager">
      <source>Call Pager</source>
      <translation variants="no">撥號到呼叫器</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號到車用電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_field2">
      <source>Not specified</source>
      <translation variants="no">加入欄位</translation>
    </message>
    <message numerus="yes" id="txt_phob_list_ln_numbers">
      <source>%Ln number</source>
      <translation>
        <numerusform plurality="a">%Ln個號碼</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_clear_communications_history_with_1">
      <source>Delete communications history with %1?</source>
      <translation variants="no">是否刪除%[40]1的通訊記錄？</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_sim">
      <source>Importing contacts from SIM</source>
      <translation variants="no">正在從SIM卡匯入通訊錄</translation>
    </message>
    <message numerus="no" id="txt_phob_list_fetch_from_1">
      <source>Fetch from %1</source>
      <translation variants="no">從%1擷取</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_assistant">
      <source>Assistant</source>
      <translation variants="no">助理的電話號碼</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_dublicates_found_see_contacts_tha">
      <source>Dublicates found. See contacts that have several dublicates in Contacts list?</source>
      <translation variants="no">找到重複的連絡人。是否查看連絡人清單中重複的連絡人？</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_home">
      <source>Fax (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">傳送傳真(住家)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_email_address">
      <source>Add email address</source>
      <translation variants="yes">
        <lengthvariant priority="1">郵件位址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email">
      <source>Send email</source>
      <translation variants="yes">
        <lengthvariant priority="1">傳送郵件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_mark_all">
      <source>Mark all</source>
      <translation variants="no">全部標記</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile">
      <source>Call Mobile</source>
      <translation variants="no">撥號到行動電話</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_work">
      <source>Delete Address (work)</source>
      <translation variants="no">刪除地址(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_choose_from_my_contacts">
      <source>Choose from my contacts</source>
      <translation variants="no">從連絡人選取</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="no">撥號到行動電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_group_1_created">
      <source>New group %1 created</source>
      <translation variants="no">新群組%[12]1已建立</translation>
    </message>
    <message numerus="no" id="txt_phob_list_yesterday_1">
      <source>yesterday %L1</source>
      <translation variants="no">zh_tw #Yesterday %L1</translation>
    </message>
    <message numerus="no" id="txt_missing_button_add_to_contacts">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile">
      <source>Mobile</source>
      <translation variants="no">行動電話</translation>
    </message>
    <message numerus="no" id="txt_phob_button_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">匯入連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_work">
      <source>Fax (work)</source>
      <translation variants="no">傳送傳真(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_to_contacts">
      <source>Add to contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">加入至通訊錄</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_url_address">
      <source>Add url address</source>
      <translation variants="yes">
        <lengthvariant priority="1">網址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_contact_saving">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_country2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_personal_ringing_tone">
      <source>Personal ringing tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">鈴聲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name">
      <source>Last name First name</source>
      <translation variants="no">姓氏 名字</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_field">
      <source>Not specified</source>
      <translation variants="no">加入詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_phob_title_show_in_contacts_list">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone">
      <source>Phone</source>
      <translation variants="no">電話</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_number">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_1">
      <source>Add %1</source>
      <translation variants="no">加入%[09]1</translation>
    </message>
    <message numerus="no" id="txt_phob_info_create_own_card_to_share_it_with_fri">
      <source>Create own card to share it with friends</source>
      <translation variants="no">使用您自己的詳細資訊建立我的名片並與朋友分享</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_to_homescreen">
      <source>Send to homescreen</source>
      <translation variants="no">加入至首頁畫面</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message">
      <source>Send message</source>
      <translation variants="yes">
        <lengthvariant priority="1">傳送訊息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_chooce_from_gallery">
      <source>Chooce from gallery</source>
      <translation variants="yes">
        <lengthvariant priority="1">從相片中選取</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_department">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_you_are_merging">
      <source>You are merging:</source>
      <translation variants="no">合併連絡人：</translation>
    </message>
    <message numerus="no" id="txt_phob_list_online">
      <source>Not specified</source>
      <translation variants="no">線上</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_group_details">
      <source>Edit group details</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯群組詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">網址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_work">
      <source>Email (work)</source>
      <translation variants="no">傳送郵件(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address">
      <source>Address</source>
      <translation variants="no">地址</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_car">
      <source>Car</source>
      <translation variants="yes">
        <lengthvariant priority="1">車用電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_online">
      <source>Not specified</source>
      <translation variants="no">線上</translation>
    </message>
    <message numerus="no" id="txt_phob_list_favorites2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_home">
      <source>Address (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址(住家)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">郵件位址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_internet_call">
      <source>Call internet call</source>
      <translation variants="no">撥打網際網路通話</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號到行動電話(公司)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_message">
      <source>Send message</source>
      <translation variants="no">傳送訊息</translation>
    </message>
    <message numerus="no" id="txt_phob_button_clear">
      <source>Not specified</source>
      <translation variants="no">清除</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit_my_card">
      <source>Not specified</source>
      <translation variants="no">編輯我的名片</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_province2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_home">
      <source>URL (home)</source>
      <translation variants="no">移至網址(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_to_group">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone">
      <source>Call phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號到電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">通訊錄</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_details">
      <source>Edit contact details</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯連絡人詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">刪除連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_importing_contacts_val_in_progress">
      <source>In progress (%L1/%L2)</source>
      <translation variants="no">連絡人匯入中(%L1/%L2)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_1">
      <source>Find: %1</source>
      <translation variants="no">搜尋"%[14]1</translation>
    </message>
    <message numerus="no" id="txt_phob_button_merge">
      <source>Merge</source>
      <translation variants="no">合併</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_conference_call">
      <source>Conference call</source>
      <translation variants="yes">
        <lengthvariant priority="1">會議通話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">聊天(%[09]1)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_none">
      <source>None</source>
      <translation variants="no">zh_tw #None</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_video_number">
      <source>Call video number</source>
      <translation variants="no">撥打視訊電話</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_l1_contacts_deleted">
      <source>Not specified</source>
      <translation variants="no">zh_tw #%Ln contact deleted</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">網際網路電話</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_assistant">
      <source>Call assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號給助理</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_your_own_card">
      <source>Create your own card</source>
      <translation variants="no">建立我的名片</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">頭銜</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_all_contacts">
      <source>Not specified</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜尋：所有連絡人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_note">
      <source>Note</source>
      <translation variants="no">記事本</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_search_for_dublicates">
      <source>Search for dublicates</source>
      <translation variants="no">搜尋重複的連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_button_history">
      <source>History</source>
      <translation variants="no">交談記錄</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_favorites_selected_select_your_p">
      <source>No favorites selected, select your preferrred contacts</source>
      <translation variants="no">未標記我的最愛連絡人。將您的首選連絡人加入至我的最愛連絡人。</translation>
    </message>
    <message numerus="no" id="txt_phob_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="no">zh_tw #Update existing contact</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_as_a_business_card">
      <source>Send as a business card</source>
      <translation variants="no">以名片傳送</translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete_group">
      <source>Delete group</source>
      <translation variants="no">刪除群組</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_email_address">
      <source>Edit email address</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯郵件位址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_merge2">
      <source>Merge</source>
      <translation variants="no">合併</translation>
    </message>
    <message numerus="no" id="txt_phob_button_group_actions">
      <source>Group actions</source>
      <translation variants="no">群組選項</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contacts_1_updated">
      <source>Contact %1 updated</source>
      <translation variants="no">連絡人%[12]1已更新</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_home">
      <source>Delete Address (home)</source>
      <translation variants="no">刪除地址(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sim_card_error">
      <source>SIM card error </source>
      <translation variants="no">zh_tw #SIM card error </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_formlabel_val_no_date_set">
      <source>No date set</source>
      <translation variants="no">(無設定資料)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_sign_in">
      <source>Sign in</source>
      <translation variants="no">登入</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sync_with_ovi_contacts">
      <source>Sync with OVI contacts</source>
      <translation variants="no">正在同步處理通訊錄</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_home">
      <source>Delete URL (home)</source>
      <translation variants="no">刪除網址(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_anniversary">
      <source>Delete Anniversary</source>
      <translation variants="no">刪除紀念日</translation>
    </message>
    <message numerus="no" id="txt_phob_list_phonebook">
      <source>Phonebook</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_web_address">
      <source>Edit web address</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯網址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_home">
      <source>Call Phone (home)</source>
      <translation variants="no">撥號到電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_mycard_image_to_business_card">
      <source>Add MyCard image to Business card?</source>
      <translation variants="no">是否也包括我的名片中的影像？</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax">
      <source>Fax</source>
      <translation variants="no">傳真</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_restore_default_settings">
      <source>Not specified</source>
      <translation variants="no">還原預設設定</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_work">
      <source>Delete Internet telephone (work)</source>
      <translation variants="no">刪除網路電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address">
      <source>Delete Address</source>
      <translation variants="no">刪除地址</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_cancel_merge">
      <source>Cancel merge</source>
      <translation variants="no">取消合併</translation>
    </message>
    <message numerus="no" id="txt_phob_button_send_my_card">
      <source>Send My card</source>
      <translation variants="no">傳送我的名片</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_favorites">
      <source>Manage favorites</source>
      <translation variants="no">管理我的最愛連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_work">
      <source>Email (work)</source>
      <translation variants="no">郵件位址(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_postal_codezip_code">
      <source>Postal code/ZIP code</source>
      <translation variants="no">郵遞區號</translation>
    </message>
    <message numerus="no" id="txt_missing_list_save_as_a_new_contact">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_contacts">
      <source>Delete contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Delete contacts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_to_homescreen_as_widget">
      <source>Send to homescreen</source>
      <translation variants="no">加入至首頁畫面</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit_group_details">
      <source>Edit group details</source>
      <translation variants="no">編輯群組詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_province">
      <source>Province</source>
      <translation variants="no">省/州</translation>
    </message>
    <message numerus="no" id="txt_phob_list_number">
      <source>Number</source>
      <translation variants="yes">
        <lengthvariant priority="1">電話號碼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contact_1_saved">
      <source>Contact %1 saved</source>
      <translation variants="no">連絡人%[12]1已建立</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company">
      <source>Company</source>
      <translation variants="no">公司</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_filter">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">匯入連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_assistant">
      <source>Assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">助理的電話號碼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_all_contacts">
      <source>All contacts</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="no">撥號到車用電話</translation>
    </message>
    <message numerus="no" id="txt_phob_list_creating_1_group">
      <source>Creating %1 group</source>
      <translation variants="no">正在建立群組%1</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_email">
      <source>Add email</source>
      <translation variants="no">加入郵件位址</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_sync_with_ovi">
      <source>Sync with OVI</source>
      <translation variants="no">與Ovi通訊錄同步處理</translation>
    </message>
    <message numerus="no" id="txt_phob_list_sychronization">
      <source>Sychronization</source>
      <translation variants="no">同步處理</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_change_image">
      <source>Change image</source>
      <translation variants="yes">
        <lengthvariant priority="1">變更影像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_link_to_phonebook">
      <source>Link to phonebook</source>
      <translation variants="no">連結至通訊錄</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_delete_contacts">
      <source>Delete contacts</source>
      <translation variants="no">zh_tw #Delete contacts?</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_my_card">
      <source>Clear My card</source>
      <translation variants="no">清除我的名片</translation>
    </message>
    <message numerus="no" id="txt_phob_info_with_ovi_by_nokia_you_can_access_you">
      <source>With Ovi by Nokia you can access your favourite social networks and make your Contacts social. Sign in with your Nokia account to get started.</source>
      <translation variants="no">使用Ovi by Nokia，您可以存取您最愛的社交網路並讓您的通訊錄更符合社交需求。請登入您的諾基亞帳號以開始。</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_address">
      <source>Add Address</source>
      <translation variants="no">加入地址</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_search_for_matched_contacts">
      <source>Search for matched contacts</source>
      <translation variants="no">搜尋相符項目</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_device">
      <source>Import from Device</source>
      <translation variants="yes">
        <lengthvariant priority="1">從手機匯入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_family_details">
      <source>Add Family details</source>
      <translation variants="no">加入家人詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_accounts">
      <source>Accounts</source>
      <translation variants="no">帳號</translation>
    </message>
    <message numerus="no" id="txt_phob_button_find">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_internet_number">
      <source>Edit internet number</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯網際網路電話詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_street">
      <source>Street</source>
      <translation variants="no">街道</translation>
    </message>
    <message numerus="no" id="txt_phob_title_members_of_1_group">
      <source>%1 members</source>
      <translation variants="no">%[12]1</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_pager">
      <source>Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">呼叫器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_new_group_name">
      <source>New group name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">群組名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_edit_members">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_history">
      <source>Delete history</source>
      <translation variants="no">清除交談記錄</translation>
    </message>
    <message numerus="no" id="txt_phob_button_stop_import">
      <source>Stop import</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">中間名</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_work">
      <source>Phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">電話(公司)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="no">行動電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">從我的最愛移除</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">職稱</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_only">
      <source>Name only</source>
      <translation variants="no">僅顯示名稱</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_image">
      <source>Remove image</source>
      <translation variants="no">移除影像</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard_val_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">zh_tw #Create my card</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_home">
      <source>Delete Fax (home)</source>
      <translation variants="no">刪除傳真(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_home">
      <source>URL (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">網址(住家)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_car">
      <source>Car</source>
      <translation variants="no">車用電話</translation>
    </message>
    <message numerus="no" id="txt_phob_info_delete_1">
      <source>Delete %1?</source>
      <translation variants="no">是否刪除
%[39]1？</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company_details">
      <source>Company Details</source>
      <translation variants="no">公司詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_contact">
      <source>New contact</source>
      <translation variants="no">新連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_group">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax">
      <source>Fax</source>
      <translation variants="yes">
        <lengthvariant priority="1">傳送傳真</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_number">
      <source>Add number</source>
      <translation variants="no">加入號碼</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_group_mail">
      <source>Not specified</source>
      <translation variants="no">傳送群組郵件</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_post_code">
      <source>Post code</source>
      <translation variants="no">郵遞區號</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_favorites">
      <source>Add favorites</source>
      <translation variants="no">加入我的最愛連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_home">
      <source>Send mail (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">傳送郵件(住家)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mail for Exchange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_number">
      <source>Set as default number</source>
      <translation variants="no">設為預設號碼</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_home">
      <source>Fax (home)</source>
      <translation variants="no">傳送傳真(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_contact">
      <source>Save contact</source>
      <translation variants="no">儲存連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_pobox">
      <source>P.O.Box</source>
      <translation variants="no">郵政信箱</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_pin">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_anniversary">
      <source>Anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">年度紀念日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites_val_no_favorites_selecte">
      <source>No favorites selected</source>
      <translation variants="no">沒有我的最愛連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_birthday">
      <source>Birthday</source>
      <translation variants="no">生日</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_group_message">
      <source>Not specified</source>
      <translation variants="no">傳送群組訊息</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_home">
      <source>Phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">電話(住家)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url">
      <source>URL</source>
      <translation variants="no">移至網址</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_video_call_work">
      <source>Not specified</source>
      <translation variants="no">視訊電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_work">
      <source>Call Phone (work)</source>
      <translation variants="no">撥號到電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_edit">
      <source>Edit</source>
      <translation variants="no">編輯</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_find_from">
      <source>Find from:</source>
      <translation variants="yes">
        <lengthvariant priority="1">從以下項目搜尋：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_unable_to_access_contacts_in_memory">
      <source>Unable to access contacts in memory: %1</source>
      <translation variants="no">zh_tw #Unable to access contacts saved to %1</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_social_view">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">姓</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_updated_1">
      <source>Updated %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新於：%L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_work">
      <source>Address (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址(公司)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order">
      <source>Name display order</source>
      <translation variants="no">姓名顯示</translation>
    </message>
    <message numerus="no" id="txt_phob_list_dialled_call">
      <source>Dialled call</source>
      <translation variants="no">zh_tw #Dialled call</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_family_details">
      <source>Edit family details</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯家人詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_group">
      <source>Remove from group</source>
      <translation variants="no">從群組移除</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_video_number_home">
      <source>Call video number (home)</source>
      <translation variants="no">撥打視訊電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_groups">
      <source>Delete groups</source>
      <translation variants="no">刪除群組</translation>
    </message>
    <message numerus="no" id="txt_phob_list_company_details">
      <source>Company Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">公司詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_video_number_work">
      <source>Call video number (work)</source>
      <translation variants="no">撥打視訊電話(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_unknown">
      <source>Unknown</source>
      <translation variants="no">zh_tw #Unknown</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">網際網路電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_home">
      <source>Phone (home)</source>
      <translation variants="no">電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_select_contact">
      <source>Select contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">選取連絡人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_work">
      <source>URL (work)</source>
      <translation variants="no">網址(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_link_in_1">
      <source>Link in %1</source>
      <translation variants="no">連結至%1</translation>
    </message>
    <message numerus="no" id="txt_phob_button_unlink">
      <source>Unlink</source>
      <translation variants="yes">
        <lengthvariant priority="1">移除連結</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_unnamed">
      <source>Unnamed</source>
      <translation variants="no">zh_tw #(unnamed)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_field">
      <source>Add field</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_email2">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">透過郵件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete_selected">
      <source>Delete selected</source>
      <translation variants="yes">
        <lengthvariant priority="1">刪除</lengthvariant>
        <lengthvariant priority="2">刪除所選群組</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_id">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization_val_private">
      <source>private</source>
      <translation variants="no">私人</translation>
    </message>
    <message numerus="no" id="txt_phob_list_mycard">
      <source>MyCard</source>
      <translation variants="no">我的名片</translation>
    </message>
    <message numerus="no" id="txt_phob_missing_find_1">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_pager">
      <source>Pager</source>
      <translation variants="no">呼叫器</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_set_as_favorite">
      <source>Set as favorite</source>
      <translation variants="no">加入至我的最愛連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_1_details">
      <source>Edit %1 details</source>
      <translation variants="no">編輯連絡人詳細資訊：%[06]1</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_my_card">
      <source>My card</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_video_call_home">
      <source>Not specified</source>
      <translation variants="no">視訊電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_call_voice_mail_box">
      <source>Not specified</source>
      <translation variants="no">撥號到語音信箱</translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">通訊錄</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">行動電話(住家)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_a_new_contact">
      <source>Create a new contact</source>
      <translation variants="no">建立新連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_work2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_missing_list_update_existing_contact">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_importing_contacts">
      <source>Importing contacts</source>
      <translation variants="no">連絡人匯入中</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_1_group_created_l2_contac">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_city">
      <source>City</source>
      <translation variants="no">城市</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_city2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_address_details">
      <source>Edit address details</source>
      <translation variants="yes">
        <lengthvariant priority="1">編輯地址詳細資訊</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="no">行動電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_1">
      <source>Delete %1</source>
      <translation variants="no">刪除%[09]1</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_groups">
      <source>Groups</source>
      <translation variants="yes">
        <lengthvariant priority="1">群組</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_department">
      <source>Department</source>
      <translation variants="no">部門</translation>
    </message>
    <message numerus="no" id="txt_phob_list_no_favorites_selected">
      <source>No favorites selected</source>
      <translation variants="no">沒有我的最愛連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_internet_call_home">
      <source>Call internet call (home)</source>
      <translation variants="no">撥打網際網路通話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_children">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_private">
      <source>Private</source>
      <translation variants="no">zh_tw #Private</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">網際網路電話</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_spouse">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="yes" id="txt_phob_dpophead_ln_contacts_linked">
      <source>%Ln contacts linked</source>
      <translation>
        <numerusform plurality="a">%Ln位連絡人已連結</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="no">zh_tw #Create new contact</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_to_contacts">
      <source>Add to contacts</source>
      <translation variants="no">加入至通訊錄</translation>
    </message>
    <message numerus="no" id="txt_phob_button_manage_members">
      <source>Manage members</source>
      <translation variants="no">管理群組</translation>
    </message>
    <message numerus="no" id="txt_phob_title_birthday">
      <source>Birthday</source>
      <translation variants="yes">
        <lengthvariant priority="1">生日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_phone_number_for_1">
      <source>No phone number for %1</source>
      <translation variants="no">zh_tw #No phone number defined for %1</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_transfer_via_b">
      <source>Transfer via bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">透過藍牙傳送</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization">
      <source>Syncronization</source>
      <translation variants="no">同步處理</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ptt">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_post_code2">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">配偶</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_view">
      <source>Not specified</source>
      <translation variants="no">檢視影像</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone">
      <source>Call Phone</source>
      <translation variants="no">撥號到電話</translation>
    </message>
    <message numerus="no" id="txt_phob_list_address2">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_work">
      <source>Delete Email (work)</source>
      <translation variants="no">刪除郵件位址(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_work">
      <source>Delete URL (work)</source>
      <translation variants="no">刪除網址(公司)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_service">
      <source>Select service</source>
      <translation variants="yes">
        <lengthvariant priority="1">選取服務</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_remove_link">
      <source>Remove link? </source>
      <translation variants="yes">
        <lengthvariant priority="1">是否移除連結？</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_val_not_logged_in">
      <source>Not logged in</source>
      <translation variants="yes">
        <lengthvariant priority="1">未登入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">刪除連絡人</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_syncronization_val_none">
      <source>Not specified</source>
      <translation variants="no">zh_tw ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard">
      <source>MyCard</source>
      <translation variants="no">zh_tw #My card</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="no">撥號到行動電話(住家)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_your_name">
      <source>Enter your name</source>
      <translation variants="no">zh_tw #Your name</translation>
    </message>
  </context>
</TS>