<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Belgian</source>
      <translation variants="no">比利時法文</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>US</source>
      <translation variants="no">美式英文</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">中斷連接</translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Input device</source>
      <translation variants="yes">
        <lengthvariant priority="1">輸入裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Norwegian</source>
      <translation variants="no">挪威文</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Keyboard layout</source>
      <translation variants="no">鍵盤配置</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>French</source>
      <translation variants="no">法文</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Remove</source>
      <translation variants="no">移除</translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Disconnect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Search done</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜尋完成</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Disabled</source>
      <translation variants="no">已停用</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Always ask</source>
      <translation variants="yes">
        <lengthvariant priority="1">長期請求</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">開(顯示)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Bluetooth - Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-進階設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>No found devices</source>
      <translation variants="no">找不到裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">所有裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Finnish/Swedish</source>
      <translation variants="no">芬蘭文/瑞典文</translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">已封鎖</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">已連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Paired, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">已配對、已連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Bluetooth - Paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-已配對裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Connect</source>
      <translation variants="no">連接</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>International US</source>
      <translation variants="no">美式國際</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Dutch</source>
      <translation variants="no">荷蘭文</translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Audio device</source>
      <translation variants="yes">
        <lengthvariant priority="1">音效裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>%1 details</source>
      <translation variants="no">%[22]1資料</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>UK</source>
      <translation variants="no">英式</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">SIM卡接入操作模式</translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">其他</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Visible</source>
      <translation variants="no">標準</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Visible for %Ln min</source>
      <translation>
        <numerusform plurality="a">顯示%Ln分鐘</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Keyboard settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">鍵盤設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Searching…</source>
      <translation variants="yes">
        <lengthvariant priority="1">尋找中</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Russian</source>
      <translation variants="no">俄文</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Bluetooth - All devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-所有裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Danish</source>
      <translation variants="no">丹麥文</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Mouse settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">滑鼠設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Portuguese</source>
      <translation variants="no">葡萄牙文</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Change visibility time</source>
      <translation variants="no">可測性期間</translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Pair</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Pair</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>US Dvorak</source>
      <translation variants="no">美式Dvorak</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Blocked devices</source>
      <translation variants="no">封鎖的裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Computer</source>
      <translation variants="yes">
        <lengthvariant priority="1">電腦</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Italian</source>
      <translation variants="no">意大利文</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Paired devices</source>
      <translation variants="no">已配對裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices_of_selected_type">
      <source>No found devices of selected type</source>
      <translation variants="no">找不到所選擇類型的裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_unpair">
      <source>Unpair</source>
      <translation variants="no">移除配對</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Bluetooth - Found devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-找到的裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">已連接(隱藏)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect_audio">
      <source>Connect audio</source>
      <translation variants="no">連接音效</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>No paired devices</source>
      <translation variants="no">沒有已配對裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_pair">
      <source>Pair</source>
      <translation variants="no">配對</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>No devices</source>
      <translation variants="no">沒有裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices_of_selected_type">
      <source>No devices of selected type</source>
      <translation variants="no">沒有所選擇類型的裝置</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">已連接(顯示)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_device">
      <source>Bluetooth device</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Bluetooth device</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>German</source>
      <translation variants="no">德文</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Spanish</source>
      <translation variants="no">西班牙文</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Enabled</source>
      <translation variants="no">已啟用</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Paired</source>
      <translation variants="yes">
        <lengthvariant priority="1">已配對</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">進階設定</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Hidden</source>
      <translation variants="no">隱藏</translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>%1 connected</source>
      <translation variants="no">%[23]1已連接</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">開(隱藏)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Connect</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Connect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect_audio">
      <source>Disconnect audio</source>
      <translation variants="no">中斷音效連接</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Paired, trusted</source>
      <translation variants="yes">
        <lengthvariant priority="1">已配對、受信任</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show">
      <source>Show…</source>
      <translation variants="no">顯示</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Device details</source>
      <translation variants="no">zh_hk #Device details</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">已封鎖</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Paired, trusted, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">已配對、受信任、已連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Unpair</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Remove pairing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Remove paired devices</source>
      <translation variants="no">移除已配對裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">手機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices_of_selected_type">
      <source>No paired devices of selected type</source>
      <translation variants="no">沒有所選擇類型的已配對裝置</translation>
    </message>
  </context>
</TS>