<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Paired</source>
      <translation variants="yes">
        <lengthvariant priority="1">已配對</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>%1 connected</source>
      <translation variants="no">%[10]1已連接</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_devices">
      <source>Bluetooth - Other devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-其他裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>On and hidden</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #On and hidden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>German</source>
      <translation variants="no">德文</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Spanish</source>
      <translation variants="no">西班牙文</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_computers">
      <source>Bluetooth - Computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-電腦</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_audio_devices">
      <source>No paired audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有已配對的音效裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Enabled</source>
      <translation variants="no">已啟用</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Hidden</source>
      <translation variants="no">zh_hk #Hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_input_devices">
      <source>No input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有輸入裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">進階設定</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">所有裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Paired, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">已配對、已連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_phones">
      <source>No phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有手機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>International US</source>
      <translation variants="no">美式國際</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_phones">
      <source>Bluetooth - Paired phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-已配對的手機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_slidervalue_l1_min">
      <source>%L1 min</source>
      <translation variants="no">zh_hk #%L1 min</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_phones">
      <source>Only phones</source>
      <translation variants="no">zh_hk #Only phones</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Always ask</source>
      <translation variants="yes">
        <lengthvariant priority="1">長期請求</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Finnish/Swedish</source>
      <translation variants="no">芬蘭文/瑞典文</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Disabled</source>
      <translation variants="no">已停用</translation>
    </message>
    <message numerus="no" id="txt_bt_slidervalue_60_min">
      <source>60 min</source>
      <translation variants="no">zh_hk #60 min</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Keyboard settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">鍵盤設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">已封鎖</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>No found devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">找不到裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Search done</source>
      <translation variants="no">zh_hk #Search completed</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>UK</source>
      <translation variants="no">英式</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Visible for %Ln min</source>
      <translation>
        <numerusform plurality="a">zh_hk #Visible for %Ln minute</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_only_sub_other_devices">
      <source>Other devices</source>
      <translation variants="no">其他裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Bluetooth - Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-進階設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">zh_hk #Disconnect</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>On and visible</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #On and visible</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Bluetooth - Found devices</source>
      <translation variants="no">zh_hk #Bluetooth - Found devices</translation>
    </message>
    <message numerus="no" id="txt_bt_slidervalue_1_min">
      <source>1 min</source>
      <translation variants="no">zh_hk #1 min</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Hidden and connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Hidden and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_devices">
      <source>No other devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有其他裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Searching…</source>
      <translation variants="no">zh_hk #Searching</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_only">
      <source>Show only</source>
      <translation variants="no">只顯示</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>No paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有已配對裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">已連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Belgian</source>
      <translation variants="no">比利時法文</translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Audio device</source>
      <translation variants="yes">
        <lengthvariant priority="1">音效裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Connect</source>
      <translation variants="no">連接</translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Input device</source>
      <translation variants="yes">
        <lengthvariant priority="1">輸入裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Keyboard layout</source>
      <translation variants="no">鍵盤配置</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Dutch</source>
      <translation variants="no">荷蘭文</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>French</source>
      <translation variants="no">法文</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Remove</source>
      <translation variants="no">移除</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>US</source>
      <translation variants="no">美式英文</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">中斷連接</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_only_sub_audio_devices">
      <source>Audio devices</source>
      <translation variants="no">音效裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_computers">
      <source>Bluetooth - Paired computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-已配對的電腦</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_computers">
      <source>only computers</source>
      <translation variants="no">zh_hk #only computers</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_other_devices">
      <source>Only other devices</source>
      <translation variants="no">zh_hk #Only other devices</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_input_devices">
      <source>Bluetooth - Paired input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-已配對的輸入裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_input_devices">
      <source>No paired input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有已配對裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Unpair</source>
      <translation variants="no">zh_hk #Unpair</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_only_sub_computers">
      <source>Computers</source>
      <translation variants="no">電腦</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">已封鎖</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_input_devices">
      <source>Only input devices</source>
      <translation variants="no">zh_hk #Only input devices</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_paired_devices">
      <source>Bluetooth - Other paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-其他已配對裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_phones">
      <source>No paired phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有已配對的手機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Remove paired devices</source>
      <translation variants="no">移除已配對裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Device details</source>
      <translation variants="no">zh_hk #Device details</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">手機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_computers">
      <source>No paired computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有已配對的電腦</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Italian</source>
      <translation variants="no">意大利文</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Paired devices</source>
      <translation variants="no">已配對裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>US Dvorak</source>
      <translation variants="no">美式Dvorak</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_audio_devices">
      <source>Bluetooth - Audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-音效裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Pair</source>
      <translation variants="no">zh_hk #Pair</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_1">
      <source>Bluetooth - %1</source>
      <translation variants="no">藍牙-%1</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Russian</source>
      <translation variants="no">俄文</translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Connect</source>
      <translation variants="no">zh_hk #Connect</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_only_audio_devices">
      <source>only audio devices</source>
      <translation variants="no">zh_hk #only audio devices</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show">
      <source>Show</source>
      <translation variants="no">zh_hk #Show</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>%1 details</source>
      <translation variants="no">%1資料</translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">其他</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">SIM卡接入操作模式</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Visible</source>
      <translation variants="no">zh_hk #Visible</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Bluetooth - Paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-已配對裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Norwegian</source>
      <translation variants="no">挪威文</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_audio_devices">
      <source>No audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有音效裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Paired, trusted, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">已配對、受信任、已連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_paired_devices">
      <source>No other paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有其他已配對裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Computer</source>
      <translation variants="yes">
        <lengthvariant priority="1">電腦</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Blocked devices</source>
      <translation variants="no">封鎖的裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Paired, trusted</source>
      <translation variants="yes">
        <lengthvariant priority="1">已配對、受信任</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">zh_hk #All devices</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Change visibility time</source>
      <translation variants="no">更換可測性時間</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_input_devices">
      <source>Bluetooth - Input devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-輸入裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_phones">
      <source>Bluetooth - Phones</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-手機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Bluetooth - All devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-所有裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Danish</source>
      <translation variants="no">丹麥文</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Portuguese</source>
      <translation variants="no">葡萄牙文</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_computers">
      <source>No computers</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有電腦</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Mouse settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">滑鼠設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Visible and connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Visible and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>No devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_only_sub_input_devices">
      <source>Input devices</source>
      <translation variants="no">輸入裝置</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_audio_devices">
      <source>Bluetooth - Paired audio devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">藍牙-已配對的音效裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_show_only_sub_phones">
      <source>Phones</source>
      <translation variants="no">手機</translation>
    </message>
  </context>
</TS>