<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_qtwrtins_info_communication_logs">
      <source>Communication Logs</source>
      <translation variants="no">zh #Communication logs</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_contact">
      <source>Contact</source>
      <translation variants="no">zh #Contacts</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_allow_1_to_access">
      <source>Allow %1 to access:</source>
      <translation variants="no">zh #Allow %[99]1 to access:</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_sensor">
      <source>Sensor</source>
      <translation variants="no">zh #Sensors</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_sysinfo">
      <source>Sysinfo</source>
      <translation variants="no">zh #System info</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_calendar">
      <source>Calendar</source>
      <translation variants="no">zh #Calendar</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_videoplayer">
      <source>VideoPlayer</source>
      <translation variants="no">zh #Video player</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_messaging">
      <source>Messaging</source>
      <translation variants="no">zh #Messaging</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_replace_existing_widget_1">
      <source>Replace existing widget %1?</source>
      <translation variants="no">zh #Replace existing widget?
%1</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_audioplayer">
      <source>AudioPlayer</source>
      <translation variants="no">zh #Music player</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_signature_invaliddo_you_still_w">
      <source>Signature invalid.Do you still want to install?</source>
      <translation variants="no">zh #Invalid signature. Install anyway?</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_unknown_errordo_you_still_want">
      <source>Unknown error.Do you still want to install?</source>
      <translation variants="no">zh #Unknown error. Continue?</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_landmark">
      <source>Landmark</source>
      <translation variants="no">zh #Places</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_camera">
      <source>Camera</source>
      <translation variants="no">zh #Camera</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_filesystem">
      <source>Filesystem</source>
      <translation variants="no">zh #File system</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_telephony">
      <source>Telephony</source>
      <translation variants="no">zh #Telephony</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_uninstall_successful">
      <source>Uninstall successful</source>
      <translation variants="no">zh #Installation removed succesfully</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_button_allow">
      <source>Allow</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Allow</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_location">
      <source>Location</source>
      <translation variants="no">zh #Position data</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_media">
      <source>Media</source>
      <translation variants="no">zh ##Media</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_installation_failed">
      <source>Installation failed</source>
      <translation variants="no">zh #Installation failed</translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_title_security_warning">
      <source>Security Warning</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Security warnings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_qtwrtins_info_uninstall_failed">
      <source>Uninstall failed</source>
      <translation variants="no">zh #Installation removal failed</translation>
    </message>
  </context>
</TS>