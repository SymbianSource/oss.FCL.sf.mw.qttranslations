<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cp_title_control_panel">
      <source>Control Panel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Панель керування</lengthvariant>
        <lengthvariant priority="2">Панель керув.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_45_seconds">
      <source>45 seconds</source>
      <translation variants="no">45 секунд</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_wallpaper">
      <source>Wallpaper</source>
      <translation variants="yes">
        <lengthvariant priority="1">Шпалери</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Автоматично</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_manual">
      <source>Manual</source>
      <translation variants="no">Вручну</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_dual_mode">
      <source>Dual mode</source>
      <translation variants="no">Подвійний режим</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_accessibility_val_adjust_accessibili">
      <source>Adjust accessibility options</source>
      <translation variants="yes">
        <lengthvariant priority="1">Редаг. установки аксесуара</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_setup">
      <source>Setup</source>
      <translation variants="yes">
        <lengthvariant priority="1">Настроювання</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_touch_screen_vibra">
      <source>Touch screen vibra</source>
      <translation variants="no">Вібрація</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Автоматично</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_about">
      <source>About</source>
      <translation variants="no">Про програму</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_select_tone_type">
      <source>Select tone type</source>
      <translation variants="no">Вибір типу тону</translation>
    </message>
    <message numerus="no" id="txt_cp_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Зустріч</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_15_seconds">
      <source>15 seconds</source>
      <translation variants="no">15 секунд</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_theme">
      <source>Select theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вибір теми</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_2_minutes">
      <source>2 minutes</source>
      <translation variants="no">2 хвилини</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_volume">
      <source>Volume</source>
      <translation variants="no">Гучність</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Скидання установок</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">Клавіші та екран</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_email_tone">
      <source>E-mail tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тон сигналу пошти</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_in_offline_mode_all_wireless_communica">
      <source>In offline mode all wireless communication is turned off.</source>
      <translation variants="no">Усі бездротові з’єднання закриті</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_operator">
      <source>Select operator</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вибір оператора</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_umts">
      <source>UMTS</source>
      <translation variants="no">3G</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_home_network">
      <source>Data usage in home network</source>
      <translation variants="no">Використання даних у домашній мережі</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_offline_mode_val_off">
      <source>Off</source>
      <translation variants="no">Вимкнено</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">Головна мова вводу</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode">
      <source>Network mode</source>
      <translation variants="no">Режим мережі</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_reset">
      <source>Reset</source>
      <translation variants="no">Скидання установок</translation>
    </message>
    <message numerus="no" id="txt_cp_list_tone">
      <source>Tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тон</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device">
      <source>Device</source>
      <translation variants="no">Телефон</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_connectivity">
      <source>Connectivity</source>
      <translation variants="no">З’єднання</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тема</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reminder_tone">
      <source>Reminder tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тон сигналу календаря</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Автоматично</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection">
      <source>Operator selection</source>
      <translation variants="no">Вибір оператора</translation>
    </message>
    <message numerus="no" id="txt_cp_info_rotate_the_display_content_automatical">
      <source>Rotate the display content automatically when you turn the device on horizontal or back to a vertical position.</source>
      <translation variants="no">Автоматичне повертання вмісту на дисплеї, коли змінюється орієнтація пристрою</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_key_and_touchscreen_tones">
      <source>Key and touchscreen tones</source>
      <translation variants="no">Тони клавіш</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_roaming">
      <source>Data usage when roaming</source>
      <translation variants="no">Використання даних у роумінгу</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_mobile_network">
      <source>Mobile network</source>
      <translation variants="no">Мобільна мережа</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="no">Клавіші та екран</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_brightness">
      <source>Brightness</source>
      <translation variants="no">Яскравість</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">Мобільна мережа</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">Про програму</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_no_tone">
      <source>No tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_preview_1">
      <source>Preview: %1</source>
      <translation variants="no">Попередній перегляд: %[10]1</translation>
    </message>
    <message numerus="no" id="txt_cp_list_autorotate_display">
      <source>Auto-rotate display</source>
      <translation variants="no">Автоповертання дисплея</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Вимкнено</translation>
    </message>
    <message numerus="no" id="txt_cp_info_no_operators_found">
      <source>No operators found.</source>
      <translation variants="no">Не знайдено операторів.</translation>
    </message>
    <message numerus="no" id="txt_cp_info_updating">
      <source>Updating operator list</source>
      <translation variants="no">Триває оновлення списку операторів</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language_val_non">
      <source>None</source>
      <translation variants="no">Немає</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_confirm">
      <source>Confirm</source>
      <translation variants="no">Завжди запитувати</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_power_management">
      <source>Power management</source>
      <translation variants="yes">
        <lengthvariant priority="1">Керування живленням</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Роз’єднати</translation>
    </message>
    <message numerus="no" id="txt_cp_button_silence">
      <source>Silence</source>
      <translation variants="no">Тиша</translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_must_be_disconnected_befo">
      <source>Active calls must be disconnected before operator selection.</source>
      <translation variants="no">Перед вибором оператора потрібно завершити активні дзвінки</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">Гучність тону дзвінка</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset">
      <source>Settings reset</source>
      <translation variants="no">Скидання установок</translation>
    </message>
    <message numerus="no" id="txt_cp_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">Вібрація</translation>
    </message>
    <message numerus="no" id="txt_cp_info_restore_original_settings_no_data_wil">
      <source>Restore original settings? No data will be deleted.</source>
      <translation variants="no">Відновити вихідні установки? Дані не буде видалено.</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_ringtone">
      <source>Ringtone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тон дзвінка</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_meeting">
      <source>Meeting</source>
      <translation variants="no">Зустріч</translation>
    </message>
    <message numerus="no" id="txt_cp_info_no_access_to_selected_operators_netwo">
      <source>No access to selected operator’s network.</source>
      <translation variants="no">Немає доступу до вибраної мережі оператора</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_personalization">
      <source>Personalization</source>
      <translation variants="no">Персоналізація</translation>
    </message>
    <message numerus="no" id="txt_cp_general">
      <source>General</source>
      <translation variants="no">Звичайний</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_tones_that_play_when_you_select">
      <source>Select tones that play when you select the profile named:</source>
      <translation variants="no">Виберіть тони, які використовуватимуться, якщо вибрати цей режим:</translation>
    </message>
    <message numerus="no" id="txt_cp_info_delete_all_data_and_restore_original_s">
      <source>Delete all data and restore original settings? Ejectable memory card data is not deleted.</source>
      <translation variants="no">Видалити всі дані та відновити заводські установки? Дані на знімній картці пам’яті не буде видалено.</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">Мова та регіон</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_regional_settings">
      <source>Regional settings</source>
      <translation variants="no">Регіональні установки</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset_val_reset_settings">
      <source>Reset settings</source>
      <translation variants="no">Скинути установки</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">uk ##Control Panel</translation>
    </message>
    <message numerus="no" id="txt_cp_title_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Додаткові установки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_confirm">
      <source>Confirm</source>
      <translation variants="no">Завжди запитувати</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_language_and_region">
      <source>Language and region</source>
      <translation variants="no">Мова та регіон</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Вимкнено</translation>
    </message>
    <message numerus="no" id="txt_cp_title_end_encryption">
      <source>End encryption</source>
      <translation variants="yes">
        <lengthvariant priority="1">Завершення шифрування</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вибір режиму</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_your_region">
      <source>Select your region:</source>
      <translation variants="no">Виберіть регіон:</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_not_connected">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Немає з’єднання</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_end">
      <source>End</source>
      <translation variants="no">Завершити</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_display_language">
      <source>Display language</source>
      <translation variants="no">Мова пристрою</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_tones">
      <source>Get more tones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Перейти до Магазину</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_original_settings_will_be_restored_no">
      <source>Original settings will be restored. No data will be deleted.</source>
      <translation variants="no">Буде відновлено вихідні установки. Дані не буде видалено.</translation>
    </message>
    <message numerus="no" id="txt_long_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">Панель керування</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Режим</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_operator_selection_is_not_possible_in">
      <source>Operator selection is not possible in Offline.</source>
      <translation variants="no">Неможливо вибрати оператора в режимі офлайн</translation>
    </message>
    <message numerus="no" id="txt_cp_button_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Додаткові установки</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_gsm">
      <source>GSM</source>
      <translation variants="no">GSM</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_30_seconds">
      <source>30 seconds</source>
      <translation variants="no">30 секунд</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_val_change_language">
      <source>Change language</source>
      <translation variants="yes">
        <lengthvariant priority="1">Редагувати установки мови</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset_val_reset_your_device">
      <source>Reset your device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Відновити заводські устан.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_edit_name">
      <source>Edit name</source>
      <translation variants="yes">
        <lengthvariant priority="1">Редагування назви</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вимкн.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_heading_profile_name">
      <source>Profile name: </source>
      <translation variants="no">Назва режиму:</translation>
    </message>
    <message numerus="no" id="txt_cp_button_touch_screen_calibration">
      <source>Touch screen calibration</source>
      <translation variants="no">Калібрування сенсорного екрана</translation>
    </message>
    <message numerus="no" id="txt_cp_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">Загальний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_message_tone">
      <source>Message tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тон сигналу повідомл.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_edit_name">
      <source>Edit name</source>
      <translation variants="no">Редагувати назву</translation>
    </message>
    <message numerus="no" id="txt_cp_list_notification_tones">
      <source>Notification tones</source>
      <translation variants="no">Тони оповіщень</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active">
      <source>Silent state active</source>
      <translation variants="no">Активовано режим "Без звуку"</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset_val_reset_device">
      <source>Reset device</source>
      <translation variants="no">Скинути пристрій</translation>
    </message>
    <message numerus="no" id="txt_cp_info_all_data_will_be_deleted_and_factory_s">
      <source>All data will be deleted and factory settings will be restored. Ejectable memory card data is not deleted.</source>
      <translation variants="no">Буде видалено всі дані та відновлено заводські установки. Дані на знімній картці пам’яті не буде видалено.</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_001">
      <source>1%</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_locked_after">
      <source>Keys &amp; screen locked after</source>
      <translation variants="no">Блокув. клав. і екран через:</translation>
    </message>
    <message numerus="no" id="txt_cp_list_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_offline_mode_val_on">
      <source>On</source>
      <translation variants="no">Увімкнено</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_1_minute">
      <source>1 minute</source>
      <translation variants="no">1 хвилина</translation>
    </message>
    <message numerus="no" id="txt_cp_info_setup_is_not_completed_would_you_lik">
      <source>Setup is not completed. 
Would you like to complete it now?</source>
      <translation variants="no">Настроювання пристрою не завершено. Завершити зараз?</translation>
    </message>
    <message numerus="no" id="txt_cp_list_recording">
      <source>Recording</source>
      <translation variants="yes">
        <lengthvariant priority="1">Запис</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_security">
      <source>Security</source>
      <translation variants="no">Захист</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">Додаткова мова вводу</translation>
    </message>
    <message numerus="no" id="txt_cp_info_data_encryption_ongoing_enryption_mus">
      <source>Data encryption ongoing. Enryption must be ended before reset.  End data enrcyption?</source>
      <translation variants="no">Триває шифрування даних. Скидання можливе тільки після завершення шифру­вання. Завершити?</translation>
    </message>
    <message numerus="no" id="txt_short_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">uk #Control panel</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active_val_clock_alarm">
      <source>Clock alarm at %1</source>
      <translation variants="no">Сигнал буд. о %1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_and_connections_must_be_d">
      <source>Active calls and connections must be disconnected before reset.</source>
      <translation variants="no">Перед скиданням потрібно завершити активні дзвінки та з’єднання</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset">
      <source>Device reset</source>
      <translation variants="no">Скидання пристрою</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_offline_airplane_mode">
      <source>Offline (Airplane Mode)</source>
      <translation variants="no">Офлайн (режим "Політ")</translation>
    </message>
  </context>
</TS>