<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_power_list_activate_power_save_mode_automatica">
      <source>Activate power save mode automatically when low power. Turns off automatically when charger is connected.</source>
      <translation variants="no">zh_tw #Activate power save mode automatically when battery is low? Charging the device will automatically disable this mode.</translation>
    </message>
    <message numerus="no" id="txt_power_list_activating_power_save_mode_will_con">
      <source>Activating power save mode will consumes minimal power. Turns off all power consuming operations/features like Bluetooth, WLAN, Vibra, Tactile feedback, Key tones, Screensaver, Wallpapers and also dimming screen brightness, Switching Network from 3G to 2G.Turns off automatically when charger is connected.</source>
      <translation variants="no">zh_tw #Activating power save mode will make the battery last longer. It will turn off all non-essential features such as Bluetooth, WLAN, touch screen vibration and tactile feedback, keypad tones, and screensavers. It will also dim the display and make the device use the 2G network. Charging the device will automatically disable this mode.</translation>
    </message>
    <message numerus="no" id="txt_power_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">zh_tw #Off</translation>
    </message>
    <message numerus="no" id="txt_power_dpopinfo_unplug_charger_to_save_energy">
      <source>Unplug charger to save energy</source>
      <translation variants="no">zh_tw #Unplug charger</translation>
    </message>
    <message numerus="no" id="txt_power_management_dblist_charging">
      <source>Charging</source>
      <translation variants="no">zh_tw #Charging</translation>
    </message>
    <message numerus="no" id="txt_power_management_dpophead_100_full">
      <source>100% Full</source>
      <translation variants="no">zh_tw #100% Full</translation>
    </message>
    <message numerus="no" id="txt_power_management_dpopinfo_low_battery">
      <source>Low Battery</source>
      <translation variants="no">zh_tw #Low battery</translation>
    </message>
    <message numerus="no" id="txt_power_management_subhead_power_management">
      <source>Power Management</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Power management</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_management_dpopinfo_psm_activated_automa">
      <source>PSM activated automatically</source>
      <translation variants="no">zh_tw #Power saving mode on</translation>
    </message>
    <message numerus="no" id="txt_power_list_power_save_mode">
      <source>Power Save Mode</source>
      <translation variants="no">zh_tw #Power save mode</translation>
    </message>
    <message numerus="no" id="txt_power_setlabel_val_on">
      <source>On</source>
      <translation variants="no">zh_tw #On</translation>
    </message>
  </context>
</TS>