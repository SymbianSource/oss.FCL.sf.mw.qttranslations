<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_short_caption_userguide">
      <source>User guide</source>
      <translation variants="no">uk #User guide</translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_user_guide">
      <source>User guide</source>
      <translation variants="yes">
        <lengthvariant priority="1">Посібник користувача</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_title_user_guide">
      <source>User guide</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #User guide</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_setlabel_search">
      <source>Search</source>
      <translation variants="yes">
        <lengthvariant priority="1">Пошук</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_dialog_search_device">
      <source>Search device</source>
      <translation variants="no">Знайти пристрій</translation>
    </message>
    <message numerus="no" id="txt_common_button_find">
      <source>Not specified</source>
      <translation variants="no">uk #Not specified</translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_clear">
      <source>Clear</source>
      <translation variants="no">uk #Clear</translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_stop">
      <source>Stop</source>
      <translation variants="no">uk #Stop</translation>
    </message>
    <message numerus="no" id="txt_user_guide_button_all">
      <source>All</source>
      <translation variants="yes">
        <lengthvariant priority="1">Усі</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_setlabel_searching">
      <source>Searching</source>
      <translation variants="yes">
        <lengthvariant priority="1">Триває пошук</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_no_match_found">
      <source>No Match found</source>
      <translation variants="no">uk #No Match found</translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_collapse_all">
      <source>Collapse all</source>
      <translation variants="no">uk #Collapse all</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_user_guide">
      <source>User guide</source>
      <translation variants="no">uk #User guide</translation>
    </message>
    <message numerus="no" id="txt_user_guide_setlabel_search_results">
      <source>Search results</source>
      <translation variants="yes">
        <lengthvariant priority="1">Результати пошуку</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_button_link_to_nokiacomsupport">
      <source>Link to nokia.com/support</source>
      <translation variants="yes">
        <lengthvariant priority="1">Посилання на nokia.com/support</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_expand_all">
      <source>Expand all</source>
      <translation variants="no">uk #Expand all</translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_applications">
      <source>Applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Applications</lengthvariant>
      </translation>
    </message>
  </context>
</TS>