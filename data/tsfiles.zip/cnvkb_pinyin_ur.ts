<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_chinese_vkb_pinyin_landscape_numberandsymbolmode_switcher">
      <source>Number and Symbol</source>
      <translation variants="no">ur #Number and Symbol</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_pinyin_landscape_language_switcher">
      <source>English</source>
      <translation variants="no">ur #English</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_pinyin_landscape_delimiter">
      <source>Delimiter</source>
      <translation variants="no">ur #Delimiter</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_pinyin_portrait_symbolmode_switcher">
      <source>Symbol</source>
      <translation variants="no">ur #Symbol</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_pinyin_portrait_numbermode_switcher">
      <source>Number</source>
      <translation variants="no">ur #Number</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_pinyin_portrait_language_switcher">
      <source>English</source>
      <translation variants="no">ur #English</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_pinyin_portrait_tone_mark">
      <source>Tone mark</source>
      <translation variants="no">ur #Tone mark</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_pinyin_portriat_delimiter">
      <source>Delimiter</source>
      <translation variants="no">ur #Delimiter</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_pinyin_landscape_tone_mark">
      <source>Tone mark</source>
      <translation variants="no">ur #Tone mark</translation>
    </message>
  </context>
</TS>