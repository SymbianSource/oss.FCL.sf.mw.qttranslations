<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_simatk_title_sim_services">
      <source>SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">SIM خدمات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_sim_services">
      <source>SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">SIM خدمات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_entern1_digit_09">
      <source>Enter:\n(1 digit 0-9) </source>
      <translation variants="no">اندراج کریں: (۱ عدد۰-۹)</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_request_not_allowed">
      <source>Request not allowed</source>
      <translation variants="no">درخواست کی اجازت نہیں ہے</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_enter">
      <source>Enter:</source>
      <translation variants="no">اندراج کریں:</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_enternnumber">
      <source>Enter:\n(number)</source>
      <translation variants="no">اندراج کریں: (نمبر)</translation>
    </message>
    <message numerus="no" id="txt_short_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">ur ##SIM Services</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_entern1_character">
      <source>Enter:\n(1 character) </source>
      <translation variants="no">اندراج کریں: (۱ حرف)</translation>
    </message>
    <message numerus="no" id="txt_simatk_dblist_val_sim_service_information_on_h">
      <source>Sim service information on Homescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Sim service information on Homescreen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">ur ##SIM Services</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_1_about_to_call">
      <source>%1 about to call</source>
      <translation variants="no">%[81]1 کو کال کرنے والا ہے</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_sim_services_not_available">
      <source>SIM services not available</source>
      <translation variants="no">SIM خدمات دستیاب نہیں</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_sending">
      <source>Sending</source>
      <translation variants="no">ڈیٹا بھیج رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_simatk_titlw_cmcc_sim_services">
      <source>CMCC SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">CMCC SIM خدمات</lengthvariant>
        <lengthvariant priority="2">ur #CMCC SIM servs.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">SIM خدمات</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_open_connection">
      <source>Open connection?</source>
      <translation variants="no">متصل کریں؟</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_request_modified">
      <source>Request modified</source>
      <translation variants="no">درخواست میں ترمیم کی گئی</translation>
    </message>
  </context>
</TS>