<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="no">ur #Verify password:</translation>
    </message>
    <message numerus="no" id="txt_occ_info_install_pac_from_server_1">
      <source>Install PAC from server '%1'?</source>
      <translation variants="no">ur #Install PAC from server '%1'?</translation>
    </message>
    <message numerus="no" id="txt_occ_info_provisioning_not_successful_reactiv">
      <source>Provisioning not successful. Re-activate provisioning in settings.</source>
      <translation variants="no">ur #Provisioning not successful. Re-activate provisioning in settings.</translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_title_1_message">
      <source>%1 message:</source>
      <translation variants="no">ur #%1 message:</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok_single_dialog">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_user_name">
      <source>%1 user name:</source>
      <translation variants="no">ur #%1 user name:</translation>
    </message>
    <message numerus="no" id="txt_occ_info_eapmschapv2_password_has_expired_yo">
      <source>EAP-MSCHAPv2 password has expired. You must create a new one.</source>
      <translation variants="no">ur #EAP-MSCHAPv2 password has expired. You must create a new one.</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_create_password_for_encrypted_pac_s">
      <source>Create password for encrypted PAC store:</source>
      <translation variants="no">ur #Create password for encrypted PAC store:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_file_password_for_1">
      <source>PAC file password for '%1':</source>
      <translation variants="no">ur #PAC file password for '%1':</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_unauthenticated_provisioning_in_p">
      <source>Unauthenticated provisioning in progress</source>
      <translation variants="no">ur #Unauthenticated provisioning in progress</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_authenticated_provisioning_in_pro">
      <source>Authenticated provisioning in progress</source>
      <translation variants="no">ur #Authenticated provisioning in progress</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_old_eapmschapv2_password">
      <source>Old EAP-MSCHAPv2 password:</source>
      <translation variants="no">ur #Old EAP-MSCHAPv2 password:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_password">
      <source>Password:</source>
      <translation variants="no">ur #Password:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_new_eapmschapv2_password">
      <source>New EAP-MSCHAPv2 password:</source>
      <translation variants="no">ur #New EAP-MSCHAPv2 password:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="no">ur #PAC store password:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_password">
      <source>%1 password:</source>
      <translation variants="no">ur #%1 password:</translation>
    </message>
  </context>
</TS>