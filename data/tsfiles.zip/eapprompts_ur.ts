<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dialog_password">
      <source>Password:</source>
      <translation variants="no">لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_unauthenticated_provisioning_in_p">
      <source>Unauthenticated provisioning in progress</source>
      <translation variants="no">غیر محفوظ فراہمی جاری ہے</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_password">
      <source>%1 password:</source>
      <translation variants="no">%[15]1 لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_occ_title_1_message">
      <source>%1 message:</source>
      <translation variants="no">%[99]1 پیغام:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_old_eapmschapv2_password">
      <source>Old EAP-MSCHAPv2 password:</source>
      <translation variants="no">پرانا EAP-MSCHAPv۲ لفظ.:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_user_name">
      <source>%1 user name:</source>
      <translation variants="no">%[18]1 صارف نام:</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_authenticated_provisioning_in_pro">
      <source>Authenticated provisioning in progress</source>
      <translation variants="no">محفوظ فراہمی جاری ہے</translation>
    </message>
    <message numerus="no" id="txt_occ_info_eapmschapv2_password_has_expired_yo">
      <source>EAP-MSCHAPv2 password has expired. You must create a new one.</source>
      <translation variants="no">EAP-MSCHAPv۲ لفظ شناخت کی مدت ختم ہوگئی۔ نیا لفظ شناخت تشکیل دیں۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="no">لفظ شناخت کی تصدیق:</translation>
    </message>
    <message numerus="no" id="txt_occ_info_install_pac_from_server_1">
      <source>Install PAC from server '%1'?</source>
      <translation variants="no">سرور '%[65]1' سے PAC کی تنصیب کریں؟</translation>
    </message>
    <message numerus="no" id="txt_occ_info_provisioning_not_successful_reactiv">
      <source>Provisioning not successful. Re-activate provisioning in settings.</source>
      <translation variants="no">فراہمی کامیاب نہیں۔ ترتیبات میں فراہمی کو دوبارہ کارآمد کریں۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_create_password_for_encrypted_pac_s">
      <source>Create password for encrypted PAC store:</source>
      <translation variants="no">رمز PAC اسٹور کیلیے لفظ.:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_file_password_for_1">
      <source>PAC file password for '%1':</source>
      <translation variants="no">PAC فائل لف. برائے '%[08]1':</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_new_eapmschapv2_password">
      <source>New EAP-MSCHAPv2 password:</source>
      <translation variants="no">نیا EAP-MSCHAPv۲ لفظ.:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="no">PAC اسٹور لفظ شناخت:</translation>
    </message>
  </context>
</TS>