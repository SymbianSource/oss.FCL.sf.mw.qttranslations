<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_button_alert_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Ok</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_tab">
      <source>Qwerty: tab</source>
      <translation variants="no">vi ##Qwerty: tab</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_previous">
      <source>Media key: previous (rewind)</source>
      <translation variants="no">vi ##Media key: previous (rewind)</translation>
    </message>
    <message numerus="no" id="txt_java_opt_screen_cmd_select">
      <source>Select</source>
      <translation variants="no">vi ##Select</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_close_1">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Close</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_end">
      <source>End key</source>
      <translation variants="no">vi ##End key</translation>
    </message>
    <message numerus="no" id="txt_java_dialog_alert">
      <source>Alert</source>
      <translation variants="no">vi ##Alert</translation>
    </message>
    <message numerus="no" id="txt_java_info_no_data">
      <source>No data</source>
      <translation variants="no">vi ##No data</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_hash_key">
      <source>ITU-T: #</source>
      <translation variants="no">vi ##ITU-T: #</translation>
    </message>
    <message numerus="no" id="txt_java_button_screen_cmd_select_2">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Select</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_close">
      <source>Close</source>
      <translation variants="no">vi ##Close</translation>
    </message>
    <message numerus="no" id="txt_java_dialog_alert_confirmation">
      <source>Confirmation</source>
      <translation variants="no">vi ##Confirmation</translation>
    </message>
    <message numerus="no" id="txt_java_button_screen_cmd_select_1">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Select</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_down">
      <source>Move down (arrow down)</source>
      <translation variants="no">vi ##Move down (arrow down)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_delete">
      <source>Qwerty: delete</source>
      <translation variants="no">vi ##Qwerty: delete</translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_cancel">
      <source>Cancel</source>
      <translation variants="no">vi ##Cancel</translation>
    </message>
    <message numerus="no" id="txt_java_dialog_alert_information">
      <source>Information</source>
      <translation variants="no">vi ##Information</translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_back">
      <source>Back</source>
      <translation variants="no">vi ##Back</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_ok_1">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Ok</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_left">
      <source>Move left (arrow left)</source>
      <translation variants="no">vi ##Move left (arrow left)</translation>
    </message>
    <message numerus="no" id="txt_java_opt_item_cmd_select">
      <source>Select</source>
      <translation variants="no">vi ##Select</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_play">
      <source>Media key: play (pause)</source>
      <translation variants="no">vi ##Media key: play (pause)</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_help_2">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Help</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_help">
      <source>Help</source>
      <translation variants="no">vi ##Help</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_voice">
      <source>Voice key</source>
      <translation variants="no">vi ##Voice key</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_cancel_1">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_options_2">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Options</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_right">
      <source>Move right (arrow right)</source>
      <translation variants="no">vi ##Move right (arrow right)</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_stop_1">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Stop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_rsk">
      <source>SK2, softkey 2, negative softkey</source>
      <translation variants="no">vi ##SK2, softkey 2, negative softkey</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_send">
      <source>Send key</source>
      <translation variants="no">vi ##Send key</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_apps">
      <source>Applications key</source>
      <translation variants="no">vi ##Applications key</translation>
    </message>
    <message numerus="no" id="txt_java_opt_call">
      <source>Call</source>
      <translation variants="no">vi ##Call</translation>
    </message>
    <message numerus="no" id="txt_java_dialog_alert_error">
      <source>Error</source>
      <translation variants="no">vi ##Error</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_clear">
      <source>Clear key</source>
      <translation variants="no">vi ##Clear key</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_cancel_2">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_title_select_bookmark">
      <source>Select bookmark</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Select bookmark</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_close">
      <source>Close</source>
      <translation variants="no">vi ##Close</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_backspace">
      <source>Qwerty: backspace</source>
      <translation variants="no">vi ##Qwerty: backspace</translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_stop">
      <source>Stop</source>
      <translation variants="no">vi ##Stop</translation>
    </message>
    <message numerus="no" id="txt_java_button_options_1">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Options</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_back_1">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Back</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_dialog_alert_warning">
      <source>Warning</source>
      <translation variants="no">vi ##Warning</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_star_key">
      <source>ITU-T: *</source>
      <translation variants="no">vi ##ITU-T: *</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_space">
      <source>Qwerty: space</source>
      <translation variants="no">vi ##Qwerty: space</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_up">
      <source>Move up (arrow up)</source>
      <translation variants="no">vi ##Move up (arrow up)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_escape">
      <source>Qwerty: escape</source>
      <translation variants="no">vi ##Qwerty: escape</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_stop">
      <source>Media key: stop</source>
      <translation variants="no">vi ##Media key: stop</translation>
    </message>
    <message numerus="no" id="txt_java_menu_screen_cmd_select">
      <source>Select</source>
      <translation variants="no">vi ##Select</translation>
    </message>
    <message numerus="no" id="txt_java_opt_fetch">
      <source>Fetch</source>
      <translation variants="no">vi ##Fetch</translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_help">
      <source>Help</source>
      <translation variants="no">vi ##Help</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_stop_2">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Stop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_ok">
      <source>Ok</source>
      <translation variants="no">vi #Ok</translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_stop">
      <source>Stop</source>
      <translation variants="no">vi #Stop</translation>
    </message>
    <message numerus="no" id="txt_java_button_fetch">
      <source>Fetch</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Fetch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_item_cmd_select_2">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Select</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_cancel">
      <source>Cancel</source>
      <translation variants="no">vi ##Cancel</translation>
    </message>
    <message numerus="no" id="txt_java_menu_fetch">
      <source>Fetch</source>
      <translation variants="no">vi ##Fetch</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_help_1">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Help</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_modifier">
      <source>All modifier keys (e.g. shift, Fn)</source>
      <translation variants="no">vi ##All modifier keys (e.g. shift, Fn)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_lsk">
      <source>SK1, softkey 1, positive softkey</source>
      <translation variants="no">vi ##SK1, softkey 1, positive softkey</translation>
    </message>
    <message numerus="no" id="txt_java_menu_item_cmd_select">
      <source>Select</source>
      <translation variants="no">vi ##Select</translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_ok">
      <source>Ok</source>
      <translation variants="no">vi ##Ok</translation>
    </message>
    <message numerus="no" id="txt_java_menu_call">
      <source>Call</source>
      <translation variants="no">vi ##Call</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_back_2">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Back</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_selection_key">
      <source>Selection key (Select)</source>
      <translation variants="no">vi ##Selection key (Select)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_enter">
      <source>Qwerty: Enter key</source>
      <translation variants="no">vi ##Qwerty: Enter key</translation>
    </message>
    <message numerus="no" id="txt_java_button_item_cmd_select_1">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Select</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_dialog_alert_alarm">
      <source>Alarm</source>
      <translation variants="no">vi ##Alarm</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_ok_2">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Ok</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_call">
      <source>Call</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Call</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_back">
      <source>Back</source>
      <translation variants="no">vi ##Back</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_close_2">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Close</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_next">
      <source>Media key: next (forward)</source>
      <translation variants="no">vi ##Media key: next (forward)</translation>
    </message>
  </context>
</TS>