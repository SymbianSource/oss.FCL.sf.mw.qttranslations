<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_long_caption_friend">
      <source>Contacts</source>
      <translation variants="no">vi #Contacts</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_title_select_contact">
      <source>Select contact:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_friend_widget_info_you_can_not_use_this_widge">
      <source>You can not use this  widget, because your phonebook is empty. Open Phonebook to add contacts?</source>
      <translation variants="no">Không thể sử dụng Danh bạ Nhỏ bởi vì không có số liên lạc trong ứng dụng Danh bạ. Mở ứng dụng Danh bạ?</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget_val_quickly">
      <source>Home screen contacts widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">L.lạc nhanh với một số l.lạc</lengthvariant>
        <lengthvariant priority="2">vi #Contact friends quickly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_friend_widget_contact_unnamed">
      <source>Unnamed</source>
      <translation variants="no">(chưa đặt tên)</translation>
    </message>
  </context>
</TS>