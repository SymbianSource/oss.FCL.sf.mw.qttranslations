<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_setlabel_occurence">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Repeat</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_repeat_weekly">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Weekly</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_daylight_saving_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Daylight saving time</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_repeat_daily">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Daily</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_repeat_on_workdays">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Workdays</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_sunday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Sunday</translation>
    </message>
    <message numerus="no" id="txt_clock_button_regional_date_time_settings">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Advanced settings</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_seperator">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Date separator:</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_sunday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Sunday</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_wednesday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Wednesday</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_title_clock">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Clock</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_friday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Friday</translation>
    </message>
    <message numerus="no" id="txt_clock_subtitle_new_alarm">
      <source>Not specified</source>
      <translation variants="no">zh_hk #New alarm</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_date_value">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Select date</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_format">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Date format:</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_use_network_date_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Auto-update of date and time</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val">
      <source>Not specified</source>
      <translation variants="no">zh_hk #-</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_12_hour">
      <source>Not specified</source>
      <translation variants="no">zh_hk #12-hour</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_thursday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Thursday</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_day">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Day</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_saturday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Saturday</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_date">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Date:</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Select time</translation>
    </message>
    <message numerus="no" id="txt_clock_button_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Select time</translation>
    </message>
    <message numerus="no" id="txt_clock_tumbler_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Time</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_workdays">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Workdays:</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_once">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Not repeated</translation>
    </message>
    <message numerus="no" id="txt_clock_subtitle_alarm">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_opt_help">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Help</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_daylight_saving_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Daylight saving time</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_monday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Monday</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_on">
      <source>Not specified</source>
      <translation variants="no">zh_hk #On</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_list_no_alarms_set">
      <source>Not specified</source>
      <translation variants="no">zh_hk #(no alarms set)</translation>
    </message>
    <message numerus="no" id="txt_clock_button_cityname_countryname">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Select city</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_list_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Time</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_time_format">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Time format:</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_24_hour">
      <source>Not specified</source>
      <translation variants="no">zh_hk #24-hour</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_friday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Friday</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_opt_exit">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Exit</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_regional_date_time_settings">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Advanced settings</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_saturday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Saturday</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_monday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Monday</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_alarm">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_tuesday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Tuesday</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_occurence">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Repeat</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_description">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Description</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_off">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Off</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_date_time_settings">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Date and time</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_week_starts_on">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Week starts on:</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_thursday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Thursday</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_alarm_editor">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_list_alarm">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_opt_settings">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Settings</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_workdays">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Workdays:</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_use_network_date_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Auto-update of date and time</translation>
    </message>
    <message numerus="no" id="txt_clk_list_grytviken_south_georgia">
      <source>Grytviken, South Georgia</source>
      <translation variants="no">格里特維肯，南喬治亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_baltimore_md_usa">
      <source>Baltimore, MD, United States of America</source>
      <translation variants="no">巴爾第摩，MD，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_phnom_penh_cambodia">
      <source>Phnom Penh, Cambodia</source>
      <translation variants="no">金邊，柬埔寨</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_exit">
      <source>Exit</source>
      <translation variants="no">退出</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_yyyy_mm_dd">
      <source>Not specified</source>
      <translation variants="no">zh_hk #yyyy mm dd</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_list_in_ln_hrs">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Within %Ln hour</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Time:</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_place">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Place:</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time_seperator">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Time separator:</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_friday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Friday</translation>
    </message>
    <message numerus="no" id="txt_clk_list_port_louis_mauritius">
      <source>Port Louis, Mauritius</source>
      <translation variants="no">路易士港，毛里求斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_san_jose_costa_rica">
      <source>San Jose, Costa Rica</source>
      <translation variants="no">聖荷西，哥斯達黎加</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mogadishu_somalia">
      <source>Mogadishu, Somalia</source>
      <translation variants="no">摩加迪沙，索馬里</translation>
    </message>
    <message numerus="no" id="txt_clk_list_fort_de_france_martinique">
      <source>Fort-de-France, Martinique</source>
      <translation variants="no">法蘭西堡，馬提尼克</translation>
    </message>
    <message numerus="no" id="txt_clk_list_choibalsan_mongolia">
      <source>Choibalsan, Mongolia</source>
      <translation variants="no">喬巴山，蒙古</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nuuk_greenland">
      <source>Nuuk, Greenland</source>
      <translation variants="no">努克，格陵蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ponta_delgada_azores">
      <source>Ponta Delgada, Azores</source>
      <translation variants="no">蓬塔德爾加達，亞速群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_wellington_nzealand">
      <source>Wellington, New Zealand</source>
      <translation variants="no">威靈頓，紐西蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dawson_creek_canada">
      <source>Dawson Creek, Canada</source>
      <translation variants="no">道森溪，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_port_vila_vanuatu">
      <source>Port Vila, Vanuatu</source>
      <translation variants="no">維拉港，瓦努阿圖</translation>
    </message>
    <message numerus="no" id="txt_clock_menu_set_as_current_location">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Not specified</translation>
    </message>
    <message numerus="no" id="txt_clk_list_luxembourg_city_luxembourg">
      <source>Luxembourg City, Luxembourg</source>
      <translation variants="no">盧森堡，盧森堡</translation>
    </message>
    <message numerus="no" id="txt_clk_list_adelaide_aus">
      <source>Adelaide, Australia</source>
      <translation variants="no">阿得雷德，澳洲</translation>
    </message>
    <message numerus="no" id="txt_clk_subtitle_alarm">
      <source>Alarm</source>
      <translation variants="no">響鬧</translation>
    </message>
    <message numerus="no" id="txt_clk_list_zagreb_croatia">
      <source>Zagreb, Croatia</source>
      <translation variants="no">沙格，克羅地亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bern_switz">
      <source>Bern, Switzerland</source>
      <translation variants="no">伯恩，瑞士</translation>
    </message>
    <message numerus="no" id="txt_clk_list_havana_cuba">
      <source>Havana, Cuba</source>
      <translation variants="no">哈瓦納，古巴</translation>
    </message>
    <message numerus="no" id="txt_clk_list_indianapolis_usa">
      <source>Indianapolis, United States of America</source>
      <translation variants="no">印地那波里，IN，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_moscow_russia">
      <source>Moscow, Russia</source>
      <translation variants="no">莫斯科，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hartford_ct_usa">
      <source>Hartford, CT, United States of America</source>
      <translation variants="no">哈特福，CT，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bujumbura_burundi">
      <source>Bujumbura, Burundi</source>
      <translation variants="no">布瓊布拉，布隆迪</translation>
    </message>
    <message numerus="no" id="txt_clk_list_monrovia_liberia">
      <source>Monrovia, Liberia</source>
      <translation variants="no">蒙羅維亞，利比利亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kinshasa_drc">
      <source>Kinshasa, Democratic Republic of the Congo</source>
      <translation variants="no">金夏沙，剛果民主共和國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ljubljana_slovenia">
      <source>Ljubljana, Slovenia</source>
      <translation variants="no">盧布爾雅那，斯洛文尼亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_laayoune_west_sahara">
      <source>Laayoune, Western Sahara</source>
      <translation variants="no">阿尤恩，西撒哈拉</translation>
    </message>
    <message numerus="no" id="txt_clk_list_beirut_lebanon">
      <source>Beirut, Lebanon</source>
      <translation variants="no">貝魯特，黎巴嫩</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vaduz_lichtenstein">
      <source>Vaduz, Lichtenstein</source>
      <translation variants="no">瓦都茲，列支敦士登</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kathmandu_nepal">
      <source>Kathmandu, Nepal</source>
      <translation variants="no">加德滿都，尼泊爾</translation>
    </message>
    <message numerus="no" id="txt_clk_list_monaco_monaco">
      <source>Monaco, Monaco</source>
      <translation variants="no">摩納哥，摩納哥</translation>
    </message>
    <message numerus="no" id="txt_clk_subtitle_city_list">
      <source>City list</source>
      <translation variants="no">zh_hk #City list</translation>
    </message>
    <message numerus="no" id="txt_clk_list_stanley_falkland_isl">
      <source>Stanley, Falkland Islands</source>
      <translation variants="no">斯坦利，福克蘭群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_chennai_india">
      <source>Chennai, India</source>
      <translation variants="no">清奈，印度</translation>
    </message>
    <message numerus="no" id="txt_clk_list_st_petersburg_russia">
      <source>St. Petersburg, Russia</source>
      <translation variants="no">聖彼得堡，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kaliningrad_russia">
      <source>Kaliningrad, Russia</source>
      <translation variants="no">加里寧格勒，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_minsk_belarus">
      <source>Minsk, Belarus</source>
      <translation variants="no">明斯克，白俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_the_settlement_christmas_isl">
      <source>The Settlement, Christmas Island.</source>
      <translation variants="no">塞特門，聖誕島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_the_valley_anguilla">
      <source>The Valley, Anguilla</source>
      <translation variants="no">維利，安圭拉</translation>
    </message>
    <message numerus="no" id="txt_clk_list_des_moines_usa">
      <source>Des Moines, United States of America</source>
      <translation variants="no">得梅因，IA，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_eucla_aus">
      <source>Eucla, Australia</source>
      <translation variants="no">尤克拉，澳洲</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kuwait_city_kuwait">
      <source>Kuwait City, Kuwait</source>
      <translation variants="no">科威特市，科威特</translation>
    </message>
    <message numerus="no" id="txt_clk_list_teresina_brazil">
      <source>Teresina, Brazil</source>
      <translation variants="no">特雷西納，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_time_format">
      <source>Time format:</source>
      <translation variants="no">時間格式：</translation>
    </message>
    <message numerus="no" id="txt_clk_list_road_town_british_virgin_isl">
      <source>Road Town, British Virgin Islands</source>
      <translation variants="no">羅德城，英屬維爾京群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saint_georges_grenada">
      <source>Saint George's, </source>
      <translation variants="no">聖喬治，格林納達</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ankara_turkey">
      <source>Ankara, Turkey</source>
      <translation variants="no">安卡拉，土耳其</translation>
    </message>
    <message numerus="no" id="txt_clk_list_moroni_comoros">
      <source>Moroni, Comoros</source>
      <translation variants="no">莫羅尼，科摩羅</translation>
    </message>
    <message numerus="no" id="txt_clk_list_campo_grande_brazil">
      <source>Campo Grande, Brazil</source>
      <translation variants="no">大坎普，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ottawa_canada">
      <source>Ottawa, Canada</source>
      <translation variants="no">渥太華，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nairobi_kenya">
      <source>Nairobi, Kenya</source>
      <translation variants="no">奈若比，肯亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_amsterdam_netherlands">
      <source>Amsterdam, Netherlands</source>
      <translation variants="no">阿姆斯特丹，荷蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dakar_senegal">
      <source>Dakar, Senegal</source>
      <translation variants="no">達卡，塞內加爾</translation>
    </message>
    <message numerus="no" id="txt_clk_list_denver_usa">
      <source>Denver, United States of America</source>
      <translation variants="no">丹佛，CO，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saint_denis_reunion">
      <source>Saint-Denis, Reunion</source>
      <translation variants="no">聖德尼，留尼旺島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_time">
      <source>&lt;time&gt;</source>
      <translation variants="no">時間</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_weekly">
      <source>Repeat weekly</source>
      <translation variants="no">每星期</translation>
    </message>
    <message numerus="no" id="txt_clk_list_macau_macau">
      <source>Macau, Macau</source>
      <translation variants="no">澳門，澳門特別行政區</translation>
    </message>
    <message numerus="no" id="txt_clk_list_regina_canada">
      <source>Regina, Canada</source>
      <translation variants="no">雷吉納，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_chicago_usa">
      <source>Chicago, United States of America</source>
      <translation variants="no">芝加哥，IL，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mumbai_india">
      <source>Mumbai, India</source>
      <translation variants="no">孟買，印度</translation>
    </message>
    <message numerus="no" id="txt_clk_list_irkutsk_russia">
      <source>Irkutsk, Russia</source>
      <translation variants="no">伊爾庫茨克，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dili_east_timor">
      <source>Dili, East Timor</source>
      <translation variants="no">迪里，東帝汶</translation>
    </message>
    <message numerus="no" id="txt_clk_list_managua_nicaragua">
      <source>Managua, Nicaragua</source>
      <translation variants="no">馬那瓜，尼加拉瓜</translation>
    </message>
    <message numerus="no" id="txt_clk_list_maseru_lesotho">
      <source>Maseru, Lesotho</source>
      <translation variants="no">馬塞盧，萊索托</translation>
    </message>
    <message numerus="no" id="txt_clk_list_podgorica_montenegro">
      <source>Podgorica, Montenegro</source>
      <translation variants="no">波德戈里察，黑山</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rio_de_jan_brazil">
      <source>Rio de Janeiro, Brazil</source>
      <translation variants="no">里約熱內盧，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_jakarta_indonesia">
      <source>Jakarta, Indonesia</source>
      <translation variants="no">雅加達，印尼</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cayenne_french_guiana">
      <source>Cayenne, French Guiana</source>
      <translation variants="no">卡宴，法屬圭亞那</translation>
    </message>
    <message numerus="no" id="txt_clk_list_brazzaville_congo">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Not specified</translation>
    </message>
    <message numerus="no" id="txt_clk_list_winnipeg_canada">
      <source>Winnipeg, Canada</source>
      <translation variants="no">溫尼伯，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">星期二</translation>
    </message>
    <message numerus="no" id="txt_clk_list_pretoria_safrica">
      <source>Pretoria, South Africa</source>
      <translation variants="no">比勒陀利亞，南非</translation>
    </message>
    <message numerus="no" id="txt_clk_list_addis _ababa_ethiopia">
      <source>Addis Ababa, Ethiopia</source>
      <translation variants="no">亞的斯亞貝巴，埃塞俄比亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_boston_usa">
      <source>Boston, United States of America</source>
      <translation variants="no">波士頓，MA，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_aracaju_brazil">
      <source>Aracaju, Brazil</source>
      <translation variants="no">阿拉卡茹，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_araguaina_brazil">
      <source>Araguaina, Brazil</source>
      <translation variants="no">阿拉瓜依納，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_manaus_brazil">
      <source>Manaus, Brazil</source>
      <translation variants="no">瑪瑙斯，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ashgabat_turkmenistan">
      <source>Ashgabat, Turkmenistan</source>
      <translation variants="no">阿什哈巴德，土庫曼斯坦</translation>
    </message>
    <message numerus="no" id="txt_clk_list_las_palmas_canary_isl">
      <source>Las Palmas, Canary Islands</source>
      <translation variants="no">拉斯帕爾馬，加那利群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lima_peru">
      <source>Lima, Peru</source>
      <translation variants="no">利馬，秘魯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_charlotte_usa">
      <source>Charlotte, United States of America</source>
      <translation variants="no">夏洛特，NC，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_san_salvador_el_salvador">
      <source>San Salvador, El Salvador</source>
      <translation variants="no">聖薩爾瓦多，薩爾瓦多</translation>
    </message>
    <message numerus="no" id="txt_clk_list_chihuahua_mexico">
      <source>Chihuahua, Mexico</source>
      <translation variants="no">奇瓦瓦，墨西哥</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lilongwe_malawi">
      <source>Lilongwe, Malawi</source>
      <translation variants="no">里朗威，馬拉維</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yaren_district_nauru">
      <source>Yaren District, Nauru</source>
      <translation variants="no">亞倫區，瑙魯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_doha_qatar">
      <source>Doha, Qatar</source>
      <translation variants="no">多哈，卡塔爾</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bissau_guinea_bissau">
      <source>Bissau, Guinea-Bissau</source>
      <translation variants="no">比紹，幾內亞比紹</translation>
    </message>
    <message numerus="no" id="txt_clk_list_guatemala_guatemala">
      <source>Guatemala, Guatemala</source>
      <translation variants="no">危地馬拉，危地馬拉</translation>
    </message>
    <message numerus="no" id="txt_clk_list_anadyr_russia">
      <source>Anadyr, Russia</source>
      <translation variants="no">阿納德爾，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bandar_seri_begawan_brunei">
      <source>Bandar Seri Begawan, Brunei</source>
      <translation variants="no">斯里巴加灣市，汶萊</translation>
    </message>
    <message numerus="no" id="txt_clk_list_baku_azerb">
      <source>Baku, Azerbaijan</source>
      <translation variants="no">巴庫，阿塞拜疆</translation>
    </message>
    <message numerus="no" id="txt_clk_list_santiago_chile">
      <source>Santiago, Chile</source>
      <translation variants="no">聖地牙哥，智利</translation>
    </message>
    <message numerus="no" id="txt_clk_list_maceio_brazil">
      <source>Maceio, Brazil</source>
      <translation variants="no">馬塞約，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_miami_usa">
      <source>Miami, United States of America</source>
      <translation variants="no">邁阿密，FL，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_alofi_niue">
      <source>Alofi, Niue</source>
      <translation variants="no">阿洛菲，紐埃</translation>
    </message>
    <message numerus="no" id="txt_clk_list_pensacola_fl_usa">
      <source>Pensacola, FL, United States of America</source>
      <translation variants="no">彭薩科拉，FL，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bamako_mali">
      <source>Bamako, Mali</source>
      <translation variants="no">巴馬科，馬里</translation>
    </message>
    <message numerus="no" id="txt_clk_list_concord_nh_usa">
      <source>Concord, NH, United States of America</source>
      <translation variants="no">康科特，NH，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_fernando_de_noronha_brazil">
      <source>Fernando de Noronha, Brazil</source>
      <translation variants="no">費南杜洛羅尼亞，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dublin_ireland">
      <source>Dublin, Ireland</source>
      <translation variants="no">都柏林，愛爾蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tunis_tunisia">
      <source>Tunis, Tunisia</source>
      <translation variants="no">突尼斯，突尼斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_antananarivo_madagascar">
      <source>Antananarivo, Madagascar</source>
      <translation variants="no">安塔那利佛，馬達加斯加</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tórshavn_faroe_isl">
      <source>Tórshavn, Faroe Islands</source>
      <translation variants="no">托爾斯港，法羅群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_libreville_gabon">
      <source>Libreville, Gabon</source>
      <translation variants="no">利伯維爾，加蓬</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cuiaba_brazil">
      <source>Cuiaba, Brazil</source>
      <translation variants="no">庫亞巴，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_line_grid_date">
      <source>&lt;date&gt;</source>
      <translation variants="no">日期</translation>
    </message>
    <message numerus="no" id="txt_clk_list_astana_kaz">
      <source>Astana, Kazakhstan</source>
      <translation variants="no">阿斯坦納，哈薩克斯坦</translation>
    </message>
    <message numerus="no" id="txt_clk_list_omaha_usa">
      <source>Omaha, United States of America</source>
      <translation variants="no">奧馬哈，NE，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_subhead_date_time">
      <source>Date &amp; time</source>
      <translation variants="no">日期和時間</translation>
    </message>
    <message numerus="no" id="txt_clk_list_willemstad_curacao">
      <source>Willemstad, Curacao</source>
      <translation variants="no">威廉斯塔德，庫拉索島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_pbm_galapagos_isl">
      <source>Puerto Baquerizo Moreno, Galapagos Islands</source>
      <translation variants="no">黑巴克里索港，巨龜島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_curitiba_brazil">
      <source>Curitiba, Brazil</source>
      <translation variants="no">庫里替巴，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lusaka_zambia">
      <source>Lusaka, Zambia</source>
      <translation variants="no">盧薩卡，贊比亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_honiara_solomon_isl">
      <source>Honiara, Solomon Islands</source>
      <translation variants="no">霍尼亞拉，所羅門群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_halifax_canada">
      <source>Halifax, Canada</source>
      <translation variants="no">哈利法克斯，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yellowknife_canada">
      <source>Yellowknife, Canada</source>
      <translation variants="no">黃刀鎮，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_warsaw_poland">
      <source>Warsaw, Poland</source>
      <translation variants="no">華沙，波蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_maputo_mozambique">
      <source>Maputo, Mozambique</source>
      <translation variants="no">馬普托，莫桑比克</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dallas_usa">
      <source>Dallas, United States of America</source>
      <translation variants="no">達拉斯，TX，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_date_format">
      <source>Date format:</source>
      <translation variants="no">日期格式：</translation>
    </message>
    <message numerus="no" id="txt_clk_grid_lnln">
      <source>&lt;-/+&gt;%Ln:%Ln</source>
      <translation variants="no">zh_hk #&lt;-/+&gt;%Ln:%Ln</translation>
    </message>
    <message numerus="no" id="txt_clk_list_harare_zimbabwe">
      <source>Harare, Zimbabwe</source>
      <translation variants="no">哈拉雷，津巴布韋</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yaoundé_cameroon">
      <source>Yaoundé, Cameroon</source>
      <translation variants="no">雅溫德，喀麥隆</translation>
    </message>
    <message numerus="no" id="txt_clk_list_porto_velho_brazil">
      <source>Porto Velho, Brazil</source>
      <translation variants="no">波多韋柳，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_atikokan_canada">
      <source>Atikokan, Canada</source>
      <translation variants="no">艾提高根，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hanga_roa_easter_isl">
      <source>Hanga Roa, Easter Island</source>
      <translation variants="no">漢加羅亞，復活節島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kuala_lumpur_malaysia">
      <source>Kuala Lumpur, Malaysia</source>
      <translation variants="no">吉隆坡，馬來西亞</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_workdays">
      <source>Workdays:</source>
      <translation variants="no">工作日：</translation>
    </message>
    <message numerus="no" id="txt_clk_list_port_of_spain_trinidad">
      <source>Port of Spain, Trinidad</source>
      <translation variants="no">西班牙港，特立尼達</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_place">
      <source>Place:</source>
      <translation variants="no">方位：</translation>
    </message>
    <message numerus="no" id="txt_clk_list_male_maldives">
      <source>Male, Maldives</source>
      <translation variants="no">馬列，馬爾代夫</translation>
    </message>
    <message numerus="no" id="txt_clk_list_belo_horizonte_brazil">
      <source>Belo Horizonte, Brazil</source>
      <translation variants="no">貝洛奧里藏特，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_new_delhi_india">
      <source>New Delhi, India</source>
      <translation variants="no">新德里，印度</translation>
    </message>
    <message numerus="no" id="txt_clk_list_london_uk">
      <source>London, United Kingdom</source>
      <translation variants="no">倫敦，英國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yekaterinburg_russia">
      <source>Yekaterinburg, Russia</source>
      <translation variants="no">葉卡捷琳堡，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_niamey_niger">
      <source>Niamey, Niger</source>
      <translation variants="no">尼亞美，尼日爾</translation>
    </message>
    <message numerus="no" id="txt_clk_list_suva_fiji">
      <source>Suva, Fiji</source>
      <translation variants="no">蘇瓦，斐濟</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yerevan_armenia">
      <source>Yerevan, Armenia</source>
      <translation variants="no">埃里溫，亞美尼亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_manila_philippines">
      <source>Manila, Philippines</source>
      <translation variants="no">馬尼拉，菲律賓</translation>
    </message>
    <message numerus="no" id="txt_clk_list_brisbane_aus">
      <source>Brisbane, Australia</source>
      <translation variants="no">布理斯班，澳洲</translation>
    </message>
    <message numerus="no" id="txt_clk_list_washington_usa">
      <source>Washington, United States of America</source>
      <translation variants="no">華盛頓，DC，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_karachi_pakistan">
      <source>Karachi, Pakistan</source>
      <translation variants="no">卡拉奇，巴基斯坦</translation>
    </message>
    <message numerus="no" id="txt_clk_list_canberra_aus">
      <source>Canberra, Australia</source>
      <translation variants="no">坎培拉，澳洲</translation>
    </message>
    <message numerus="no" id="txt_clk_list_baghdad_iraq">
      <source>Baghdad, Iraq</source>
      <translation variants="no">巴格達，伊拉克</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ulaanbaatar_mongolia">
      <source>Ulaanbaatar, Mongolia</source>
      <translation variants="no">烏蘭巴托，蒙古</translation>
    </message>
    <message numerus="no" id="txt_clk_list_prague_czech">
      <source>Prague, Czechoslovakia</source>
      <translation variants="no">布拉格，捷克</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bismarck_nd_usa">
      <source>Bismarck, ND, United States of America</source>
      <translation variants="no">俾斯麥，ND，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_beijing_china">
      <source>Beijing, China</source>
      <translation variants="no">北京，中國</translation>
    </message>
    <message numerus="no" id="txt_clk_button_date">
      <source>&lt;date&gt;</source>
      <translation variants="no">選擇日期</translation>
    </message>
    <message numerus="no" id="txt_clk_list_funchal_madeira">
      <source>Funchal, Madeira</source>
      <translation variants="no">芳夏爾，馬德拉</translation>
    </message>
    <message numerus="no" id="txt_clk_list_memphis_usa">
      <source>Memphis, United States of America</source>
      <translation variants="no">孟斐斯，TN，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_joao_pessoa_brazil">
      <source>Joao Pessoa, Brazil</source>
      <translation variants="no">川佩索 ，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_jerusalem_israel">
      <source>Jerusalem, Israel</source>
      <translation variants="no">耶路撒冷，以色列</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rabat_morocco">
      <source>Rabat, Morocco</source>
      <translation variants="no">拉巴特，摩洛哥</translation>
    </message>
    <message numerus="no" id="txt_clk_list_buenos_aires_argen">
      <source>Buenos Aires, Argentina</source>
      <translation variants="no">布宜諾斯艾利斯，阿根廷</translation>
    </message>
    <message numerus="no" id="txt_clk_list_san_marino_city_san_marino">
      <source>San Marino City, San Marino</source>
      <translation variants="no">聖馬力諾市，聖馬力諾</translation>
    </message>
    <message numerus="no" id="txt_clk_list_stockholm_sweden">
      <source>Stockholm, Sweden</source>
      <translation variants="no">斯德哥爾摩，瑞典</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rainy_river_canada">
      <source>Rainy River, Canada</source>
      <translation variants="no">雨河，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_belfast_ireland">
      <source>Belfast, Ireland</source>
      <translation variants="no">貝爾發斯特，愛爾蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_scoresbysund_greenland">
      <source>Scoresbysund, Greenland</source>
      <translation variants="no">斯科斯比松，格陵蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_time">
      <source>Time</source>
      <translation variants="no">時間</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_monday">
      <source>Monday</source>
      <translation variants="no">星期一</translation>
    </message>
    <message numerus="no" id="txt_clk_list_calgary_canada">
      <source>Calgary, Canada</source>
      <translation variants="no">卡加利，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_san_francisco_usa">
      <source>San Francisco, United States of America</source>
      <translation variants="no">三藩市，CA，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_birmingham_al_usa">
      <source>Birmingham, AL, United States of America</source>
      <translation variants="no">伯明翰，AL，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_avarua_cook_isl">
      <source>Avarua, Cook Islands</source>
      <translation variants="no">阿瓦魯，庫克群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_louisville_ky_usa">
      <source>Louisville, KY, United States of America</source>
      <translation variants="no">路易斯維爾，KY，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_fortaleza_brazil">
      <source>Fortaleza, Brazil</source>
      <translation variants="no">佛塔雷沙，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_title_clock">
      <source>Clock</source>
      <translation variants="no">時鐘</translation>
    </message>
    <message numerus="no" id="txt_clk_list_funafuti_tuvalu">
      <source>Funafuti, Tuvalu</source>
      <translation variants="no">富那富提，圖瓦盧</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour">
      <source>24 hour</source>
      <translation variants="no">24小時制</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">星期三</translation>
    </message>
    <message numerus="no" id="txt_clk_list_brussels_belgium">
      <source>Brussels, Belgium</source>
      <translation variants="no">布魯塞爾，比利時</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dhaka_bangla">
      <source>Dhaka, Bangladesh</source>
      <translation variants="no">達卡，孟加拉</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_val_alarm">
      <source>Alarm</source>
      <translation variants="no">鬧鐘</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rankin_inlet_canada">
      <source>Rankin Inlet, Canada</source>
      <translation variants="no">雷今灣，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_majuro_marshall_isl">
      <source>Majuro, Marshall Islands</source>
      <translation variants="no">馬久羅，馬紹爾群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vancouver_canada">
      <source>Vancouver, Canada</source>
      <translation variants="no">溫哥華，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cambridge_bay_canada">
      <source>Cambridge Bay, Canada</source>
      <translation variants="no">劍橋灣，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_boise_usa">
      <source>Boise, United States of America</source>
      <translation variants="no">博伊西，ID，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hobart_aus">
      <source>Hobart, Australia</source>
      <translation variants="no">荷伯特，澳洲</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tarawa_kiribati">
      <source>Tarawa, Kiribati</source>
      <translation variants="no">塔拉瓦，基里巴斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nicosia_cyprus">
      <source>Nicosia, Cyprus</source>
      <translation variants="no">尼科西亞，塞浦路斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_budapest_hungary">
      <source>Budapest, Hungary</source>
      <translation variants="no">布達佩斯，匈牙利</translation>
    </message>
    <message numerus="no" id="txt_clk_list_augusta_usa">
      <source>Augusta, United States of America</source>
      <translation variants="no">奧古斯塔，ME，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_la_paz_bolivia">
      <source>La Paz, Bolivia</source>
      <translation variants="no">拉帕斯，玻利維亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_khartoum_sudan">
      <source>Khartoum, Sudan</source>
      <translation variants="no">喀土穆，蘇丹</translation>
    </message>
    <message numerus="no" id="txt_clk_list_st_loius_usa">
      <source>St. Louis, United States of America</source>
      <translation variants="no">聖路易斯，MO，美國</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_add_own_city">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Not specified</translation>
    </message>
    <message numerus="no" id="txt_clk_list_colonia_micronesia">
      <source>Colonia, Micronesia</source>
      <translation variants="no">科隆尼亞，密克羅尼西亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_samara_russia">
      <source>Samara, Russia</source>
      <translation variants="no">薩馬拉，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dar_es_salaam_tanzania">
      <source>Dar es Salaam, Tanzania</source>
      <translation variants="no">達里斯薩蘭，坦桑尼亞</translation>
    </message>
    <message numerus="no" id="txt_clk_title_clock">
      <source>Clock</source>
      <translation variants="no">時鐘</translation>
    </message>
    <message numerus="no" id="txt_clock_menu_delete">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Not specified</translation>
    </message>
    <message numerus="no" id="txt_clk_list_noumea_new_caledonia">
      <source>Noumea, New Caledonia</source>
      <translation variants="no">諾美亞，新迦里多尼亞</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_daylight_saving_time">
      <source>Daylight saving time</source>
      <translation variants="no">日光節約時間</translation>
    </message>
    <message numerus="no" id="txt_clk_list_adamstown_pitcairn_isl">
      <source>Adamstown, Pitcairn Islands</source>
      <translation variants="no">亞當斯敦，皮特凱恩島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_george_town_cayman_isl">
      <source>George Town, Cayman Islands</source>
      <translation variants="no">喬治敦，開曼群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saint_pierre_miquelon">
      <source>Saint-Pierre, Miquelon</source>
      <translation variants="no">聖彼德，密克隆群島</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_menu_delete_alarm">
      <source>Delete alarm</source>
      <translation variants="no">刪除響鬧</translation>
    </message>
    <message numerus="no" id="txt_clk_list_makassar_indonesia">
      <source>Makassar, Indonesia</source>
      <translation variants="no">錫江，印尼</translation>
    </message>
    <message numerus="no" id="txt_clk_list_caracas_venezuela">
      <source>Caracas, Venezuela</source>
      <translation variants="no">加拉加斯，委內瑞拉</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_occurence">
      <source>Occurence</source>
      <translation variants="no">重複</translation>
    </message>
    <message numerus="no" id="txt_clk_list_fakaofo_tokelau">
      <source>Fakaofo, Tokelau</source>
      <translation variants="no">法克奧佛，托克勞群島</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_saturday">
      <source>Saturday</source>
      <translation variants="no">星期六</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tallinn_estonia">
      <source>Tallinn, Estonia</source>
      <translation variants="no">塔林，愛沙尼亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_quito_equador">
      <source>Quito, Equador</source>
      <translation variants="no">基多，厄瓜多爾</translation>
    </message>
    <message numerus="no" id="txt_clk_list_georgetown_guyana">
      <source>Georgetown, Guyana</source>
      <translation variants="no">喬治城，圭亞那</translation>
    </message>
    <message numerus="no" id="txt_clk_list_istanbul_turkey">
      <source>Istanbul, Turkey</source>
      <translation variants="no">伊斯坦堡，土耳其</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mexico_city_mexico">
      <source>Mexico City, Mexico</source>
      <translation variants="no">墨西哥市，墨西哥</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_daily">
      <source>Repeat daily</source>
      <translation variants="no">每天</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kolkata_india">
      <source>Kolkata, India</source>
      <translation variants="no">加爾各答，印度</translation>
    </message>
    <message numerus="no" id="txt_clk_list_singapore_city_singapore">
      <source>Singapore City, Singapore</source>
      <translation variants="no">新加坡，新加坡</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saipan_mariana_isl">
      <source>Saipan, Mariana Islands</source>
      <translation variants="no">塞班島，馬里安納群島</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd">
      <source>yyyy mm dd</source>
      <translation variants="no">年月日</translation>
    </message>
    <message numerus="no" id="txt_clk_list_pyongyang_north_korea">
      <source>Pyongyang, North Korea</source>
      <translation variants="no">平壤，北韓</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ln_hrsln_mins">
      <source>&lt;+/-&gt;%Ln hrs,%Ln mins</source>
      <translation variants="no">zh_hk #&lt;+/-&gt;%Ln hrs,%Ln mins</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_thursday">
      <source>Thursday</source>
      <translation variants="no">星期四</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sonora_mexico">
      <source>Sonora, Mexico</source>
      <translation variants="no">索諾拉，墨西哥</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bogota_colombia">
      <source>Bogota, Colombia</source>
      <translation variants="no">波哥大，哥倫比亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_riga_latvia">
      <source>Riga, Latvia</source>
      <translation variants="no">里加，拉脫維亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_providence_ri_usa">
      <source>Providence, RI, United States of America</source>
      <translation variants="no">普羅維丹斯，RI，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_portland_or_usa">
      <source>Portland, OR, United States of America</source>
      <translation variants="no">波特蘭，OR，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cardiff_uk">
      <source>Cardiff, United Kingdom</source>
      <translation variants="no">卡迪夫，英國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_boa_vista_brazil">
      <source>Boa Vista, Brazil</source>
      <translation variants="no">博阿維斯塔，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_paramaribo_suriname">
      <source>Paramaribo, Suriname</source>
      <translation variants="no">帕拉馬里博，蘇里南</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sao_tome_principe">
      <source>São Tomé, Príncipe</source>
      <translation variants="no">聖多美，聖多美和普林西比</translation>
    </message>
    <message numerus="no" id="txt_clk_list_riyadh_saudi_arabia">
      <source>Riyadh, Saudi Arabia</source>
      <translation variants="no">利雅得，沙特亞拉伯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_salvador_brazil">
      <source>Salvador, Brazil</source>
      <translation variants="no">薩爾瓦多，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_algiers_algeria">
      <source>Algiers, Algeria</source>
      <translation variants="no">阿爾及爾，阿爾及利亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_andorra_la_vella_andorra">
      <source>Andorra La Vella, Andorra</source>
      <translation variants="no">安道爾市，安道爾</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kampala_uganda">
      <source>Kampala, Uganda</source>
      <translation variants="no">康培拉，烏干達</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_use_network_date_time">
      <source>Use network date &amp; time</source>
      <translation variants="no">自動更新日期和時間</translation>
    </message>
    <message numerus="no" id="txt_clk_list_praia_cape_verde">
      <source>Praia, Cape Verde</source>
      <translation variants="no">培亞，佛得角</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sanaa_yemen">
      <source>Sanaa, Yemen</source>
      <translation variants="no">薩那，也門</translation>
    </message>
    <message numerus="no" id="txt_clk_list_porto_aux_francais_kerguelen">
      <source>Port-aux-Francais, Kerguelen</source>
      <translation variants="no">奧斯法蘭西斯港，凱爾蓋朗群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hovd_mongolia">
      <source>Hovd, Mongolia</source>
      <translation variants="no">科布多，蒙古</translation>
    </message>
    <message numerus="no" id="txt_clk_list_belgrade_serbia">
      <source>Belgrade, Serbia</source>
      <translation variants="no">貝爾格萊德，塞爾維亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_taskhkent_uzbekistan">
      <source>Tashkent, Uzbekistan</source>
      <translation variants="no">塔什干，烏茲別克</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dover_de_usa">
      <source>Dover, DE, United States of America</source>
      <translation variants="no">多佛，DE，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_edinburgh_uk">
      <source>Edinburgh, United Kingdom</source>
      <translation variants="no">愛丁堡，英國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_taipei_taiwan">
      <source>Taipei, Taiwan</source>
      <translation variants="no">台北，台灣</translation>
    </message>
    <message numerus="no" id="txt_clk_button_cityname_countryname">
      <source>&lt;cityname, countryname&gt;</source>
      <translation variants="no">選擇城市</translation>
    </message>
    <message numerus="no" id="txt_clk_list_conakry_guinea">
      <source>Conakry, Guinea</source>
      <translation variants="no">柯那克里，幾內亞</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_friday">
      <source>Friday</source>
      <translation variants="no">星期五</translation>
    </message>
    <message numerus="no" id="txt_clk_list_roseau_dominica">
      <source>Roseau, Dominica</source>
      <translation variants="no">盧梭，多明尼加</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_settings">
      <source>Settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saint_johns_ab">
      <source>Saint John's, Antigua and Barbuda</source>
      <translation variants="no">聖約翰，安提瓜和巴布達</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sao_paulo_brazil">
      <source>Sao Paulo, Brazil</source>
      <translation variants="no">聖保羅，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hanoi_vietnam">
      <source>Hanoi, Vietnam</source>
      <translation variants="no">河內，越南</translation>
    </message>
    <message numerus="no" id="txt_clk_list_iqaluit_canada">
      <source>Iqaluit, Canada</source>
      <translation variants="no">伊卡魯伊特，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_krasnoyarsk_russia">
      <source>Krasnoyarsk, Russia</source>
      <translation variants="no">克拉斯諾亞斯克，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mamoudzou_mayotte">
      <source>Mamoudzou, Mayotte</source>
      <translation variants="no">馬慕索，馬約特</translation>
    </message>
    <message numerus="no" id="txt_clk_list_diego_garcia_chagos_isl">
      <source>Diego Garcia, Chagos Islands</source>
      <translation variants="no">迪戈加西亞，查戈斯群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bucharest_romania">
      <source>Bucharest, Romania</source>
      <translation variants="no">布加勒斯特，羅馬尼亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cairo_egypt">
      <source>Cairo, Egypt</source>
      <translation variants="no">開羅，埃及</translation>
    </message>
    <message numerus="no" id="txt_clk_list_billings_mt_usa">
      <source>Billings, MT, United States of America</source>
      <translation variants="no">比林斯，MT，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_once">
      <source>Once</source>
      <translation variants="no">不重複</translation>
    </message>
    <message numerus="no" id="txt_clk_list_edmonton_canada">
      <source>Edmonton, Canada</source>
      <translation variants="no">埃德蒙頓，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_basse_terre_guadeloupe">
      <source>Basse-Terre, Guadeloupe</source>
      <translation variants="no">巴斯特爾，瓜德羅普</translation>
    </message>
    <message numerus="no" id="txt_clk_list_berlin_germany">
      <source>Berlin, Germany</source>
      <translation variants="no">柏林，德國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_wichita_ks_usa">
      <source>Wichita, KS, United States of America</source>
      <translation variants="no">維奇托，KS，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_new_orleans_usa">
      <source>New Orleans, United States of America</source>
      <translation variants="no">新奧爾良，LA，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nuku_alofa_tonga">
      <source>Nuku’alofa, Tonga</source>
      <translation variants="no">努庫阿洛法，東加</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lisbon_portugal">
      <source>Lisbon, Portugal</source>
      <translation variants="no">里斯本，葡萄牙</translation>
    </message>
    <message numerus="no" id="txt_clk_list_skopje_macedonia">
      <source>Skopje, Macedonia</source>
      <translation variants="no">斯科普里，馬其頓</translation>
    </message>
    <message numerus="no" id="txt_clk_list_chisinau_moldova">
      <source>Chisinau, Moldova</source>
      <translation variants="no">基什尼奧夫，摩爾多瓦</translation>
    </message>
    <message numerus="no" id="txt_clk_list_new_york_usa">
      <source>New York, United States of America</source>
      <translation variants="no">紐約，NY，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_milwaukee_wi_usa">
      <source>Milwaukee, WI, United States of America</source>
      <translation variants="no">米爾瓦基，WI，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_los_angeles_usa">
      <source>Los Angeles, United States of America</source>
      <translation variants="no">洛杉磯，CA，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_date">
      <source>&lt;date&gt;</source>
      <translation variants="no">日期</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sao_luis_brazil">
      <source>Sao Luis, Brazil</source>
      <translation variants="no">聖路易斯，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_luanda_angola">
      <source>Luanda, Angola</source>
      <translation variants="no">羅安達，安哥拉</translation>
    </message>
    <message numerus="no" id="txt_clk_list_castries_st_lucia">
      <source>Castries, St. Lucia</source>
      <translation variants="no">卡斯特里，聖盧西亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_pago_pago_as_usa">
      <source>Pago Pago, AS, United States of America</source>
      <translation variants="no">帕果帕果，AS，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_philadelphia_usa">
      <source>Philadelphia, United States of America</source>
      <translation variants="no">費城，PA，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_toronto_canada">
      <source>Toronto, Canada</source>
      <translation variants="no">多倫多，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mata_utu_wallis_futuna_isl">
      <source>Mata_Utu, Wallis and Futuna Islands</source>
      <translation variants="no">馬塔烏圖，瓦利斯及富圖納群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_dushanbe_tajikistan">
      <source>Dushanbe, Tajikistan</source>
      <translation variants="no">杜尚別，塔吉克斯坦</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_alarm">
      <source>Alarm</source>
      <translation variants="no">響鬧</translation>
    </message>
    <message numerus="no" id="txt_clk_list_columbia_sc_usa">
      <source>Columbia, SC, United States of America</source>
      <translation variants="no">哥倫比亞，SC，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_on_workdays">
      <source>Repeat on workdays</source>
      <translation variants="no">工作日</translation>
    </message>
    <message numerus="no" id="txt_clk_list_abidjan_cotedIvoire">
      <source>Abidjan, Cote d'Ivoire</source>
      <translation variants="no">阿比讓，科特迪瓦</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hong_kong_victoria">
      <source>Hong kong, Victoria</source>
      <translation variants="no">香港特別行政區，維多利亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_victoria_seychelles">
      <source>Victoria, Seychelles</source>
      <translation variants="no">維多利亞，塞舌爾</translation>
    </message>
    <message numerus="no" id="txt_clk_list_muscat_oman">
      <source>Muscat, Oman</source>
      <translation variants="no">馬斯喀特，阿曼</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bangui_car">
      <source>Bangui, Central African Republic</source>
      <translation variants="no">班吉，中非共和國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_recife_brazil">
      <source>Recife, Brazil</source>
      <translation variants="no">累西腓，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_madrid_spain">
      <source>Madrid, Spain</source>
      <translation variants="no">馬德里，西班牙</translation>
    </message>
    <message numerus="no" id="txt_clk_list_jayapura_indonesia">
      <source>Jayapura, Indonesia</source>
      <translation variants="no">查亞普拉，印尼</translation>
    </message>
    <message numerus="no" id="txt_clk_list_aktau_kaz">
      <source>Aktau, Kazakhstan</source>
      <translation variants="no">阿克套，哈薩克斯坦</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_sunday">
      <source>Sunday</source>
      <translation variants="no">星期日</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tijuana_mexico">
      <source>Tijuana, Mexico</source>
      <translation variants="no">蒂娃娜，墨西哥</translation>
    </message>
    <message numerus="no" id="txt_clk_list_gibraltar_gibraltar">
      <source>Gibraltar, Gibraltar</source>
      <translation variants="no">直布羅陀，直布羅陀</translation>
    </message>
    <message numerus="no" id="txt_clk_list_salt_lake_city_usa">
      <source>Salt Lake City, United States of America</source>
      <translation variants="no">鹽湖城，UT，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_richmond_va_usa">
      <source>Richmond, VA, United States of America</source>
      <translation variants="no">瑞奇蒙，VA，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cranbrook_canada">
      <source>Cranbrook, Canada</source>
      <translation variants="no">克蘭布魯，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_button_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="no">進階設定</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tel_aviv_israel">
      <source>Tel Aviv, Israel</source>
      <translation variants="no">特拉維夫，以色列</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cockburn_town_turks_and_caicos_isl">
      <source>Cockburn Town, </source>
      <translation variants="no">科伯恩城，特克斯和凱科斯群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_charlottetown_canada">
      <source>Charlottetown, Canada</source>
      <translation variants="no">夏洛特城，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_atlanta_usa">
      <source>Atlanta, United States of America</source>
      <translation variants="no">亞特蘭大，GA，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_albuquerque_usa">
      <source>Albuquerque, United States of America</source>
      <translation variants="no">亞柏克爾克，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_perth_aus">
      <source>Perth, Australia</source>
      <translation variants="no">柏斯，澳洲</translation>
    </message>
    <message numerus="no" id="txt_clk_list_city_name_country_name">
      <source>&lt;city name, country name&gt;</source>
      <translation variants="no">加入城市</translation>
    </message>
    <message numerus="no" id="txt_clk_list_detroit_usa">
      <source>Detroit, United States of America</source>
      <translation variants="no">底特律，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_montpelier_vt_usa">
      <source>Montpelier, VT, United States of America</source>
      <translation variants="no">蒙特佩利爾，VT，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lord_howe_isl_aus">
      <source>Lord Howe Island, Australia</source>
      <translation variants="no">豪勛爵島，澳洲</translation>
    </message>
    <message numerus="no" id="txt_clk_line_grid_cityname">
      <source>&lt;cityname&gt;</source>
      <translation variants="no">加入城市</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hamilton_bermuda">
      <source>Hamilton, Bermuda</source>
      <translation variants="no">漢米頓，百慕達</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bratislava_slovakia">
      <source>Bratislava, Slovakia</source>
      <translation variants="no">布拉第斯拉瓦，斯洛伐克</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kingstown_st_vincent">
      <source>Kingstown, St. Vincent</source>
      <translation variants="no">金斯敦，聖文森特和格林納丁</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kanton_isl_phoenix_isl">
      <source>Kanton Island, Phoenix Islands</source>
      <translation variants="no">坎頓島，鳳凰群島</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy">
      <source>mm dd yyyy</source>
      <translation variants="no">月日年</translation>
    </message>
    <message numerus="no" id="txt_clk_list_oslo_norway">
      <source>Oslo, Norway</source>
      <translation variants="no">奧斯陸，挪威</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_delete">
      <source>Delete</source>
      <translation variants="no">刪除</translation>
    </message>
    <message numerus="no" id="txt_clk_list_mbabane_swaziland">
      <source>Mbabane, Swaziland</source>
      <translation variants="no">墨巴本，斯威士蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_montreal_canada">
      <source>Montreal, Canada</source>
      <translation variants="no">蒙特利爾，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_las_vegas_usa">
      <source>Las Vegas, United States of America</source>
      <translation variants="no">拉斯維加斯，NV，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_week_starts_on">
      <source>Week starts on:</source>
      <translation variants="no">星期開始於：</translation>
    </message>
    <message numerus="no" id="txt_clk_list_macapa_brazil">
      <source>Macapa, Brazil</source>
      <translation variants="no">馬卡帕，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bishkek_kyrgyzstan">
      <source>Bishkek, Kyrgyzstan</source>
      <translation variants="no">畢斯凱，吉爾吉斯坦</translation>
    </message>
    <message numerus="no" id="txt_clk_list_agana, guam">
      <source>Agana, Guam</source>
      <translation variants="no">阿佳納，關島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tbilisi_georgia">
      <source>Tbilisi, Georgia</source>
      <translation variants="no">第比利斯，格魯吉亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kigali_rwanda">
      <source>Kigali, Rwanda</source>
      <translation variants="no">基加利，盧旺達</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lubumbashi_drc">
      <source>Lubumbashi, Democratic Republic of the Congo</source>
      <translation variants="no">盧本巴希，剛果民主共和國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vienna_austria">
      <source>Vienna, Austria</source>
      <translation variants="no">維也納，奧地利</translation>
    </message>
    <message numerus="no" id="txt_clk_list_islamabad_pak">
      <source>Islamabad, Pakistan</source>
      <translation variants="no">伊斯蘭堡，巴基斯坦</translation>
    </message>
    <message numerus="no" id="txt_clk_list_santo_domingo_dominican_rep">
      <source>Santo Domingo, Dominican Republic</source>
      <translation variants="no">聖多明哥，多明尼加共和國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_palikir_micronesia">
      <source>Palikir, Micronesia</source>
      <translation variants="no">帕利奇，密克羅尼西亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kyiv_ukraine">
      <source>Kyiv, Ukraine</source>
      <translation variants="no">基輔，烏克蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_apia samoa">
      <source>Apia, Samoa</source>
      <translation variants="no">阿皮亞，薩摩亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_gaborone_botswana">
      <source>Gaborone, Botswana</source>
      <translation variants="no">哈博羅內，博茨瓦納</translation>
    </message>
    <message numerus="no" id="txt_clk_subtitle_world_clock">
      <source>World Clock</source>
      <translation variants="no">世界時鐘</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vientiane_laos">
      <source>Vientiane, Laos</source>
      <translation variants="no">永珍，老撾</translation>
    </message>
    <message numerus="no" id="txt_clk_list_copenhagen_denmark">
      <source>Copenhagen, Denmark</source>
      <translation variants="no">哥本哈根，丹麥</translation>
    </message>
    <message numerus="no" id="txt_clk_list_windhoek_namibia">
      <source>Windhoek, Namibia</source>
      <translation variants="no">溫得和克，納米比亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kingston_jamaica">
      <source>Kingston, Jamaica</source>
      <translation variants="no">京斯敦，牙買加</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date">
      <source>Time &amp; date</source>
      <translation variants="no">日期和時間</translation>
    </message>
    <message numerus="no" id="txt_clk_opt_add_own_city">
      <source>Add own city</source>
      <translation variants="no">zh_hk #Add own city</translation>
    </message>
    <message numerus="no" id="txt_clk_list_brazzaville_drc">
      <source>Brazzaville, Democratic Republic of the Congo</source>
      <translation variants="no">布拉柴維爾，剛果民主共和國</translation>
    </message>
    <message numerus="no" id="txt_long_caption_clk">
      <source>Clock</source>
      <translation variants="no">時鐘</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_title_control_panel">
      <source>Control Panel</source>
      <translation variants="no">控制台</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_delete">
      <source>Delete</source>
      <translation variants="no">刪除</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_subtitle_device">
      <source>Device</source>
      <translation variants="no">手機</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_workdays">
      <source>Workdays</source>
      <translation variants="no">zh_hk #Workdays</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_world_clock">
      <source>World Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #World Clock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_common_clock">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Clock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2mins">
      <source>In %1hr %2mins</source>
      <translation variants="no">zh_hk #In %1hr %2mins</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_date_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Date and time</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tehran_iran">
      <source>Tehran, Iran</source>
      <translation variants="no">德黑蘭，伊朗</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bangkok_thai">
      <source>Bangkok, Thailand</source>
      <translation variants="no">曼谷，泰國</translation>
    </message>
    <message numerus="no" id="txt_clock_menu_show_on_homescreen">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Not specified</translation>
    </message>
    <message numerus="no" id="txt_clk_list_columbus_usa">
      <source>Columbus, United States of America</source>
      <translation variants="no">哥倫布市，OH，美國</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_gmt_1">
      <source>GMT %1</source>
      <translation variants="no">zh_hk #GMT %1</translation>
    </message>
    <message numerus="no" id="txt_short_caption_clock">
      <source>Clock</source>
      <translation variants="no">zh_hk #Clock</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_deactivated">
      <source>Alarm Deactivated</source>
      <translation variants="no">zh_hk #Alarm Deactivated</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hrs_2_mins">
      <source>%1 hrs %2 mins</source>
      <translation variants="no">zh_hk #%1 hrs %2 mins</translation>
    </message>
    <message numerus="no" id="txt_clk_list_greece_athens">
      <source>Athens, Greece</source>
      <translation variants="no">雅典，希臘</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_day">
      <source>Day</source>
      <translation variants="no">按天檢視</translation>
    </message>
    <message numerus="no" id="txt_clk_list_yakutsk_russia">
      <source>Yakutsk, Russia</source>
      <translation variants="no">亞庫次克，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vladivostok_russia">
      <source>Vladivostok, Russia</source>
      <translation variants="no">海參威，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hr_2_mins">
      <source>%1 hr %2 mins</source>
      <translation variants="no">zh_hk #%1 hr %2 mins</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_mins">
      <source>%1 mins</source>
      <translation variants="no">zh_hk #%1 mins</translation>
    </message>
    <message numerus="no" id="txt_common_common_gmt">
      <source>GMT</source>
      <translation variants="no">zh_hk #GMT</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_every_1">
      <source>Every %1</source>
      <translation variants="no">zh_hk #Every %1</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_today">
      <source>Today</source>
      <translation variants="no">zh_hk #Today</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2mins">
      <source>In %1hrs %2mins</source>
      <translation variants="no">zh_hk #In %1hrs %2mins</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_activated">
      <source>Alarm Activated</source>
      <translation variants="no">zh_hk #Alarm Activated</translation>
    </message>
    <message numerus="no" id="txt_clk_subhead_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="no">進階設定</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Time</translation>
    </message>
    <message numerus="no" id="txt_clk_list_manama_bahrain">
      <source>Manama, Bahrain</source>
      <translation variants="no">麥納瑪，巴林</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_alarm_sound">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Alarm tone</translation>
    </message>
    <message numerus="no" id="txt_clk_list_evansville_in_usa">
      <source>Evansville, IN, United States of America</source>
      <translation variants="no">埃文斯維爾，IN，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_banjul_gambia">
      <source>Banjul, Gambia</source>
      <translation variants="no">班珠爾，岡比亞</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_menu_delete_alarm">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Delete alarm</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_set_as_current_location">
      <source>Set as current location</source>
      <translation variants="no">設為目前的方位</translation>
    </message>
    <message numerus="no" id="txt_clk_list_paris_france">
      <source>Paris, France</source>
      <translation variants="no">巴黎，法國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_seoul_skorea">
      <source>Seoul, South Korea</source>
      <translation variants="no">首爾，南韓</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_no_alarms_set">
      <source>No alarms set</source>
      <translation variants="yes">
        <lengthvariant priority="1">(未設定響鬧)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_list_colombo_srilanka">
      <source>Colombo, Srilanka</source>
      <translation variants="no">可倫坡，斯里蘭卡</translation>
    </message>
    <message numerus="no" id="txt_clk_list_honolulu_hi_usa">
      <source>Honolulu, HI, United States of America</source>
      <translation variants="no">檀香山，HI，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_porto_alegre_brazil">
      <source>Porto Alegre, Brazil</source>
      <translation variants="no">阿雷格里港，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_time">
      <source>&lt;time&gt;</source>
      <translation variants="no">響鬧時間</translation>
    </message>
    <message numerus="no" id="txt_clk_list_johannesburg_safrica">
      <source>Johannesburg, South Africa</source>
      <translation variants="no">約翰內斯堡，南非</translation>
    </message>
    <message numerus="no" id="txt_clk_list_seattle_usa">
      <source>Seattle, United States of America</source>
      <translation variants="no">西雅圖，WA，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_asmara_eritrea">
      <source>Asmara, Eritrea</source>
      <translation variants="no">阿斯馬拉，厄立特里亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_djibouti_djibouti">
      <source>Djibouti, Djibouti</source>
      <translation variants="no">吉布提，吉布提</translation>
    </message>
    <message numerus="no" id="txt_clk_list_london_christmas_isl">
      <source>London, Christmas Island</source>
      <translation variants="no">倫敦，聖誕島</translation>
    </message>
    <message numerus="no" id="txt_clk_subtitle_new_alarm">
      <source>New alarm</source>
      <translation variants="no">新響鬧</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tripoli_libya">
      <source>Tripoli, Libya</source>
      <translation variants="no">的黎波里，利比亞</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_once">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Not repeated</translation>
    </message>
    <message numerus="no" id="txt_clk_list_abuja_nigeria">
      <source>Abuja, Nigeria</source>
      <translation variants="no">阿布賈，尼日利亞</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_in_ln_hrs">
      <source>In %Ln hrs</source>
      <translation variants="no">在%Ln小時內</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_button_new_alarm">
      <source>New alarm</source>
      <translation variants="no">zh_hk #New alarm</translation>
    </message>
    <message numerus="no" id="txt_clk_list_damascus_syria">
      <source>Damascus, Syria</source>
      <translation variants="no">大馬士革，敘利亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kabul_afghan">
      <source>Kabul, Afghanistan</source>
      <translation variants="no">喀布爾，阿富汗</translation>
    </message>
    <message numerus="no" id="txt_clk_list_guam_mp_usa">
      <source>Guam, MP, United States of America</source>
      <translation variants="no">關島，MP，美國</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_button_world_clock">
      <source>World clock</source>
      <translation variants="no">zh_hk #World clock</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2min">
      <source>In %1hrs %2min</source>
      <translation variants="no">zh_hk #In %1hrs %2min</translation>
    </message>
    <message numerus="no" id="txt_long_caption_clock">
      <source>Clock</source>
      <translation variants="no">zh_hk #Clock</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_alarm_sound">
      <source>Alarm sound</source>
      <translation variants="no">響鬧聲</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_description">
      <source>Description</source>
      <translation variants="no">內容說明</translation>
    </message>
    <message numerus="no" id="txt_clk_list_san_juan_puerto_rico">
      <source>San Juan, Puerto Rico</source>
      <translation variants="no">聖璜，波多黎各</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">放棄變更</translation>
    </message>
    <message numerus="no" id="txt_clk_list_port_moresby_png">
      <source>Port Moresby, Papua New Guinea</source>
      <translation variants="no">莫爾斯貝港，巴布亞新畿內亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_abu_dhabi_uae">
      <source>Abu Dhabi, United Arab Emirates</source>
      <translation variants="no">阿布達比，阿拉伯聯合酋長國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_montevideo_uruguay">
      <source>Montevideo, Uruguay</source>
      <translation variants="no">蒙特維的亞，烏拉圭</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_repeat_on_workdays">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Workdays</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_tuesday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Tuesday</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tokya_japan">
      <source>Tokya, Japan</source>
      <translation variants="no">東京，日本</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_show_on_homescreen">
      <source>Show on homescreen</source>
      <translation variants="no">在首頁畫面顯示</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_mm_dd_yyyy">
      <source>Not specified</source>
      <translation variants="no">zh_hk #mm dd yyyy</translation>
    </message>
    <message numerus="no" id="txt_clk_list_brasilia_brazil">
      <source>Brasilia, Brazil</source>
      <translation variants="no">巴西利亞，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_melbourne_aus">
      <source>Melbourne, Australia</source>
      <translation variants="no">墨爾本，澳洲</translation>
    </message>
    <message numerus="no" id="txt_clk_list_casablanca_morocco">
      <source>Casablanca, Morocco</source>
      <translation variants="no">卡薩布蘭卡，摩洛哥</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour">
      <source>12 hour</source>
      <translation variants="no">12小時制</translation>
    </message>
    <message numerus="no" id="txt_clk_list_adak_ak_usa">
      <source>Adak, AK, United States of America</source>
      <translation variants="no">艾達克，AK，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_creighton_canada">
      <source>Creighton, Canada</source>
      <translation variants="no">克萊頓，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_porto_novo_benin">
      <source>Porto-Novo, Benin</source>
      <translation variants="no">波多諾伏，貝寧</translation>
    </message>
    <message numerus="no" id="txt_clk_list_amman_jordan">
      <source>Amman, Jordan</source>
      <translation variants="no">安曼，約旦</translation>
    </message>
    <message numerus="no" id="txt_clk_list_accra_ghana">
      <source>Accra, Ghana</source>
      <translation variants="no">阿克拉，加納</translation>
    </message>
    <message numerus="no" id="txt_clk_list_goiania_brazil">
      <source>Goiania, Brazil</source>
      <translation variants="no">戈亞尼亞，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tirana_albania">
      <source>Tirana, Albania</source>
      <translation variants="no">地拉納，阿爾巴尼亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_cheyenne_usa">
      <source>Cheyenne, United States of America</source>
      <translation variants="no">夏延，WY，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_helsinki_finland">
      <source>Helsinki, Finland</source>
      <translation variants="no">赫爾辛基，芬蘭</translation>
    </message>
    <message numerus="no" id="txt_clock_button_add_city">
      <source>Add city</source>
      <translation variants="no">zh_hk #Add city</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_button_alarms">
      <source>Alarms</source>
      <translation variants="no">zh_hk #Alarms</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily">
      <source>Daily</source>
      <translation variants="no">zh_hk #Daily</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_alarm_sound">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Alarm tone</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_repeat_daily">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Daily</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_list_occurence_detail">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Recurrence</translation>
    </message>
    <message numerus="no" id="txt_clock_tumbler_date">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Date</translation>
    </message>
    <message numerus="no" id="txt_clock_title_clock">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Clock</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_wednesday">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Wednesday</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_val_repeat_weekly">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Weekly</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_val_dd_mm_yyyy">
      <source>Not specified</source>
      <translation variants="no">zh_hk #dd mm yyyy</translation>
    </message>
    <message numerus="no" id="txt_clk_list_melekeok_palau">
      <source>Melekeok, Palau</source>
      <translation variants="no">美利基奧克，帕勞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_hagatna_guam">
      <source>Hagatna, Guam</source>
      <translation variants="no">亞加納，關島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_lomé_togo">
      <source>Lomé, Togo</source>
      <translation variants="no">洛美，多哥</translation>
    </message>
    <message numerus="no" id="txt_clk_list_palmas_brazil">
      <source>Palmas, Brazil</source>
      <translation variants="no">帕爾馬，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_thimpu_bhutan">
      <source>Thimpu, Bhutan</source>
      <translation variants="no">廷布，不丹</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sofia_bulgaria">
      <source>Sofia, Bulgaria</source>
      <translation variants="no">索非亞，保加利亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_bridgetown_barbados">
      <source>Bridgetown, Barbados</source>
      <translation variants="no">布里奇頓，巴巴多斯</translation>
    </message>
    <message numerus="no" id="txt_clk_button_time">
      <source>&lt;time&gt;</source>
      <translation variants="no">時間</translation>
    </message>
    <message numerus="no" id="txt_clk_list_papeete_tahiti">
      <source>Papeete, Tahiti</source>
      <translation variants="no">柏佩蒂，大溪地</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nouakchott_mauritania">
      <source>Nouakchott, Mauritania</source>
      <translation variants="no">努爾克肖特，毛里塔尼亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_magadan_russia">
      <source>Magadan, Russia</source>
      <translation variants="no">馬加丹，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_belmopan_belize">
      <source>Belmopan, Belize</source>
      <translation variants="no">貝爾莫潘，伯利茲</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_help">
      <source>Help</source>
      <translation variants="no">說明</translation>
    </message>
    <message numerus="no" id="txt_clk_list_darwin_aus">
      <source>Darwin, Australia</source>
      <translation variants="no">達爾文，澳洲</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy">
      <source>dd mm yyyy</source>
      <translation variants="no">日月年</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rome_italy">
      <source>Rome, Italy</source>
      <translation variants="no">羅馬，意大利</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_occurence_detail">
      <source>&lt;Occurence detail&gt;</source>
      <translation variants="no">響鬧資料</translation>
    </message>
    <message numerus="no" id="txt_clk_list_reykjavik_iceland">
      <source>Reykjavik, Iceland</source>
      <translation variants="no">雷克雅未克，冰島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_acre_brazil">
      <source>Acre, Brazil</source>
      <translation variants="no">亞克里，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_coral_harbour_canada">
      <source>Coral Harbour, Canada</source>
      <translation variants="no">珊瑚港，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_vilnius_lithuania">
      <source>Vilnius, Lithuania</source>
      <translation variants="no">維爾紐斯，立陶宛</translation>
    </message>
    <message numerus="no" id="txt_clk_list_charleston_wv_usa">
      <source>Charleston, WV, United States of America</source>
      <translation variants="no">查爾斯頓，WV，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_ouagadougou_bf">
      <source>Ouagadougou, Burkina Faso</source>
      <translation variants="no">瓦加杜古，布基納法索</translation>
    </message>
    <message numerus="no" id="txt_clk_list_west_isl_cocos_isl">
      <source>West Island, Cocos Islands</source>
      <translation variants="no">西島，可可斯群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_osaka_japan">
      <source>Osaka, Japan</source>
      <translation variants="no">大阪，日本</translation>
    </message>
    <message numerus="no" id="txt_clk_list_oranjestad_aruba">
      <source>Oranjestad, Aruba</source>
      <translation variants="no">奧蘭葉斯塔，阿魯巴</translation>
    </message>
    <message numerus="no" id="txt_clk_list_thule_greenland">
      <source>Thule, Greenland</source>
      <translation variants="no">圖勒，格陵蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_charlotte_amalie_vi_usa">
      <source>Charlotte Amalie, VI, United States of America</source>
      <translation variants="no">夏洛泰瑪琍，VI，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_taiohae_marquesas_isl">
      <source>Taiohae, Marquesas Islands</source>
      <translation variants="no">泰奧開，馬克薩斯群島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_phoenix_usa">
      <source>Phoenix, United States of America</source>
      <translation variants="no">鳳凰城，AZ，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_porto_au_prince_haiti">
      <source>Port-au-Prince, Haiti</source>
      <translation variants="no">太子港，海地</translation>
    </message>
    <message numerus="no" id="txt_clk_list_minneapolis_usa">
      <source>Minneapolis, United States of America</source>
      <translation variants="no">明尼亞波里，MN，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_asuncion_paraguay">
      <source>Asuncion, Paraguay</source>
      <translation variants="no">亞松森，巴拉圭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_freetown_sierra_leone">
      <source>Freetown, Sierra Leone</source>
      <translation variants="no">弗里敦，塞拉利昂</translation>
    </message>
    <message numerus="no" id="txt_clk_list_auckland_nz">
      <source>Auckland, Newzealand</source>
      <translation variants="no">奧克蘭，紐西蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_gary_in_usa">
      <source>Gary, IN, United States of America</source>
      <translation variants="no">加里，IN，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sapporo_japan">
      <source>Sapporo, Japan</source>
      <translation variants="no">札幌，日本</translation>
    </message>
    <message numerus="no" id="txt_clk_list_rangoon_myanmar">
      <source>Rangoon, Myanmar</source>
      <translation variants="no">仰光，緬甸</translation>
    </message>
    <message numerus="no" id="txt_clk_list_saipan_mp_usa">
      <source>Saipan, MP, United States of America</source>
      <translation variants="no">塞班島，MP，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_malabo_eq_guinea">
      <source>Malabo, Equatorial Guinea</source>
      <translation variants="no">馬拉博，赤道幾內亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_joinville_brazil">
      <source>Joinville, Brazil</source>
      <translation variants="no">茹安維爾，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_blanc_sablon_canada">
      <source>Blanc-Sablon, Canada</source>
      <translation variants="no">伯拉克沙伯倫，加拿大</translation>
    </message>
    <message numerus="no" id="txt_clk_list_tegucigalpa_honduras">
      <source>Tegucigalpa, Honduras</source>
      <translation variants="no">特古西加帕，洪都拉斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_sioux_falls_sd_usa">
      <source>Sioux Falls, SD, United States of America</source>
      <translation variants="no">秀佛斯，SD，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_danmarkshavn_greenland">
      <source>Danmarkshavn, Greenland</source>
      <translation variants="no">丹馬沙，格陵蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_novosibirsk_russia">
      <source>Novosibirsk, Russia</source>
      <translation variants="no">新西伯立亞，俄羅斯</translation>
    </message>
    <message numerus="no" id="txt_clk_list_belem_brazil">
      <source>Belem, Brazil</source>
      <translation variants="no">貝倫，巴西</translation>
    </message>
    <message numerus="no" id="txt_clk_list_gambier_isl_french_polynesia">
      <source>Gambier Islands, French Polynesia</source>
      <translation variants="no">甘比爾群島，法屬波利尼西亞</translation>
    </message>
    <message numerus="no" id="txt_clk_list_nassau_bahamas">
      <source>Nassau, Bahamas</source>
      <translation variants="no">拿騷，巴哈馬</translation>
    </message>
    <message numerus="no" id="txt_clk_list_jamestown_st_helena">
      <source>Jamestown, St. Helena</source>
      <translation variants="no">詹姆斯敦，聖赫勒拿島</translation>
    </message>
    <message numerus="no" id="txt_clk_caption_clock">
      <source>Clock</source>
      <translation variants="no">zh_hk #Clock</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_info_date_info">
      <source>&lt;time info, date info&gt;</source>
      <translation variants="no">時間，日期</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_hr">
      <source>%1 hr</source>
      <translation variants="no">zh_hk #%1 hr</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2min">
      <source>In %1hr %2min</source>
      <translation variants="no">zh_hk #In %1hr %2min</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1days">
      <source>In %1days</source>
      <translation variants="no">zh_hk #In %1days</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_hrs">
      <source>%1 hrs</source>
      <translation variants="no">zh_hk #%1 hrs</translation>
    </message>
    <message numerus="no" id="txt_clock_button_date">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Select date</translation>
    </message>
    <message numerus="no" id="txt_clk_list_valletta_malta">
      <source>Valletta, Malta</source>
      <translation variants="no">瓦萊塔，馬耳他</translation>
    </message>
    <message numerus="no" id="txt_clk_list_kingston_norfolk_isl">
      <source>Kingston, Norfolk Island</source>
      <translation variants="no">京斯敦，諾福克島</translation>
    </message>
    <message numerus="no" id="txt_clk_list_chatham_newz">
      <source>Chatham, Newzealand</source>
      <translation variants="no">查塔姆，紐西蘭</translation>
    </message>
    <message numerus="no" id="txt_clk_list_oklahoma_city_usa">
      <source>Oklahoma City, United States of America</source>
      <translation variants="no">俄克拉何馬市，OK，美國</translation>
    </message>
    <message numerus="no" id="txt_clk_list_panama_city_panama">
      <source>Panama City, Panama</source>
      <translation variants="no">巴拿馬市，巴拿馬</translation>
    </message>
    <message numerus="no" id="txt_clk_list_holy_see_vatican_city">
      <source>Holy See, Vatican City</source>
      <translation variants="no">教廷，梵蒂岡城</translation>
    </message>
  </context>
</TS>