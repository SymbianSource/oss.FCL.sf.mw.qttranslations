<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_widget_list_l1">
      <source>(L%1)</source>
      <translation variants="no">zh_tw #(L%1)</translation>
    </message>
    <message numerus="no" id="txt_mail_widget_dblist_preview_of_recent_mail">
      <source>Preview of recent mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Preview of recent mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_widget_list_no_mail">
      <source>(No mail)</source>
      <translation variants="no">zh_tw #(No mail)</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mail_widget">
      <source>Mail widget</source>
      <translation variants="no">zh_tw #Mail widget</translation>
    </message>
    <message numerus="no" id="txt_short_caption_mail_widget">
      <source>Mail widget</source>
      <translation variants="no">zh_tw #Mail widget</translation>
    </message>
  </context>
</TS>