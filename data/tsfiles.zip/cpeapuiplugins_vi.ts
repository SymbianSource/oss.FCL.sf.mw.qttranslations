<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_user_certificate">
      <source>User certificate</source>
      <translation variants="no">vi #Personal certificate</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_certificate_val_not_in_use">
      <source>(not in use)</source>
      <translation variants="no">vi #Not in use</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_provisioning_enabled">
      <source>Enabled</source>
      <translation variants="no">vi #Enabled</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_realm_val_generate_automatically">
      <source>Generate automatically</source>
      <translation variants="no">vi #Generate automatically</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_cipher_suites">
      <source>Cipher suites</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Cipher suites</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password">
      <source>PAC store password</source>
      <translation variants="no">vi #PAC store password</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authenticated_provisioning">
      <source>Authenticated provisioning</source>
      <translation variants="no">vi #Secure provisioning</translation>
    </message>
    <message numerus="no" id="txt_occ_info_remove_pac_store_all_credentials_wil">
      <source>Remove PAC store? All credentials will be lost.</source>
      <translation variants="no">vi #Remove PAC store? All credentials will be lost.</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_realm">
      <source>Realm</source>
      <translation variants="no">vi #Realm</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unauthenticated_provisioning">
      <source>Unauthenticated provisioning</source>
      <translation variants="no">vi #Unsecure provisioning</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv1">
      <source>PEAPv1</source>
      <translation variants="no">vi #PEAPv1</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_inner_eap_type">
      <source>Inner EAP type</source>
      <translation variants="no">vi #Inner EAP type</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_generate_automatica">
      <source>Generate automatically</source>
      <translation variants="no">vi #Generate automatically</translation>
    </message>
    <message numerus="no" id="txt_occ_button_reset_pac_store">
      <source>Reset PAC store</source>
      <translation variants="no">vi #Reset PAC store</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy">
      <source>TLS privacy</source>
      <translation variants="no">vi #TLS privacy</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy_val_on">
      <source>On</source>
      <translation variants="no">vi #On</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_pac_store">
      <source>PAC store</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #PAC store</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_eap_module_settings">
      <source>%1 settings</source>
      <translation variants="no">vi #%[16]1 settings</translation>
    </message>
    <message numerus="no" id="txt_occ_button_inner_eap_type">
      <source>Configure inner EAP type</source>
      <translation variants="no">vi #Configure inner EAP type</translation>
    </message>
    <message numerus="no" id="txt_occ_info_pac_store_password_will_no_longer_be">
      <source>PAC store password will no longer be stored in phone and should be memorised. Continue?</source>
      <translation variants="no">vi #PAC store password will no longer be stored in device and should be memorised. Continue?</translation>
    </message>
    <message numerus="no" id="txt_occ_info_existing_password_cannot_be_changed">
      <source>Existing password cannot be changed. Select 'Reset PAC store' to reset the store and password.</source>
      <translation variants="no">vi #Existing password cannot be changed. Select 'Remove PAC store' to remove store and password.</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version">
      <source>PEAP version</source>
      <translation variants="no">vi #PEAP version</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate_val_select">
      <source>Select automatically</source>
      <translation variants="no">vi #Select automatically</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password_val_user_defin">
      <source>User defined</source>
      <translation variants="no">vi #User defined</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv0_or_peapv1">
      <source>PEAPv0 or PEAPv1</source>
      <translation variants="no">vi #PEAPv0 or PEAPv1</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy_val_off">
      <source>Off</source>
      <translation variants="no">vi #Off</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password_val_prompt">
      <source>Prompt</source>
      <translation variants="no">vi #Prompt</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv0">
      <source>PEAPv0</source>
      <translation variants="no">vi #PEAPv0</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate_val_not_in">
      <source>(not in use)</source>
      <translation variants="no">vi #Not in use</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate">
      <source>Authority certificate</source>
      <translation variants="no">vi #Authority certificate</translation>
    </message>
  </context>
</TS>