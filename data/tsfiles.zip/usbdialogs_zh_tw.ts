<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dpinfo_mass_storage">
      <source>as mass storage</source>
      <translation variants="no">大容量儲存裝置模式</translation>
    </message>
    <message numerus="no" id="txt_usb_info_error_in_usb_connection_disconnect_d">
      <source>Error in USB connection. Disconnect device.</source>
      <translation variants="no">USB連線發生錯誤。請將裝置中斷連線。</translation>
    </message>
    <message numerus="no" id="txt_usb_info_memory_full_close_some_applications">
      <source>Memory full. Close some applications and try to connect USB cable again.</source>
      <translation variants="no">記憶體已滿。請關閉部分應用程式並再次連接USB傳輸線。</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_safe_to_remove">
      <source>Safe to remove</source>
      <translation variants="no">可安全移除</translation>
    </message>
    <message numerus="no" id="txt_usb_info_partially_supported_usb_device_connec">
      <source>Partially supported USB device connected. All functionality might not work.</source>
      <translation variants="no">連接了只能部分支援的USB裝置。部分功能可能無法正常運作。</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unsupported_usb_device_disconnect_de">
      <source>Unsupported USB device. Disconnect device.</source>
      <translation variants="no">不支援的USB裝置。請將裝置中斷連線。</translation>
    </message>
    <message numerus="no" id="txt_usb_dpophead_usb_disconnected">
      <source>USB disconnected</source>
      <translation variants="no">USB已中斷連線</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_media_transfer">
      <source>as media transfer</source>
      <translation variants="no">影音傳輸模式</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_eject_the_usb_device_some">
      <source>Unable to eject the USB device. Some of the applications may still be using it.</source>
      <translation variants="no">無法退出USB裝置。部分應用程式可能仍在使用裝置。</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unknown_file_system_disconnect_devic">
      <source>Unknown file system. Disconnect device.</source>
      <translation variants="no">不明的檔案系統。請將裝置中斷連線。</translation>
    </message>
    <message numerus="no" id="txt_usb_dpophead_usb_connected">
      <source>USB connected</source>
      <translation variants="no">USB已連線</translation>
    </message>
    <message numerus="no" id="txt_usb_info_remove_usb_cable_or_connect_a_device">
      <source>Remove USB cable or connect a device.</source>
      <translation variants="no">請移除USB傳輸線或連接裝置。</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_headset_in_use">
      <source>headset in use</source>
      <translation variants="no">使用中的通話用耳機</translation>
    </message>
    <message numerus="no" id="txt_usb_info_hubs_are_not_supported_disconnect_us">
      <source>Hubs are not supported. Disconnect device.</source>
      <translation variants="no">不支援集線器。請將裝置中斷連線。</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_show_a_memory_to_other_devi">
      <source>Unable to show a memory to other device.</source>
      <translation variants="no">無法對其他裝置顯示記憶體內容</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_phone_as_modem">
      <source>as web connection</source>
      <translation variants="no">電腦網際網路連線模式</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_ovi_suite">
      <source>to OVI suite</source>
      <translation variants="no">Nokia Ovi電腦端套件</translation>
    </message>
    <message numerus="no" id="txt_usb_info_disk_full_remove_some_files_and_try">
      <source>Disk full. Remove some files and try connect USB cable again</source>
      <translation variants="no">磁碟已滿。請移除部分檔案並再次連接USB傳輸線。</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_use_file_system_in_device">
      <source>Unable to use file system in device. Disconnect device.</source>
      <translation variants="no">無法使用裝置中的檔案系統。請將傳輸線中斷連線。</translation>
    </message>
  </context>
</TS>