<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_photos_formlabel_location_tag">
      <source>Location tag</source>
      <translation variants="no">位置標籤</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_fast">
      <source>Fast</source>
      <translation variants="no">快</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_comments">
      <source>Not specified</source>
      <translation variants="no">評論</translation>
    </message>
    <message numerus="no" id="txt_photos_title_photos">
      <source>Photos</source>
      <translation variants="yes">
        <lengthvariant priority="1">相片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_places_ln">
      <source>Places (%ln)</source>
      <translation variants="no">zh_tw #Locations (%L1)</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_slideshow">
      <source>Slideshow</source>
      <translation variants="no">投影片秀</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_slow">
      <source>Slow</source>
      <translation variants="no">慢</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay">
      <source>Transistion delay</source>
      <translation variants="no">轉換速度</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_smooth">
      <source>Smooth Fade</source>
      <translation variants="no">漸漸消失</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_add_to_album">
      <source>Add to album</source>
      <translation variants="no">加入至相簿</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_mark_all">
      <source>Mark all</source>
      <translation variants="no">全部標記</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_share">
      <source>Share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_view_releated_items">
      <source>View releated items</source>
      <translation variants="no">檢視相關影像</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_play">
      <source>Play</source>
      <translation variants="no">播放</translation>
    </message>
    <message numerus="yes" id="txt_photos_subtitle_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">%Ln張影像</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">已拍攝影像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_shared_with">
      <source>Shared with</source>
      <translation variants="no">已分享</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">全部取消標記</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_share">
      <source>Share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_slideshow">
      <source>Slideshow</source>
      <translation variants="no">投影片秀</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_places_l1">
      <source>Not specified</source>
      <translation variants="no">位置(%L1)</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_val_ln_items">
      <source>%Ln items</source>
      <translation variants="no">%Ln張影像</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect">
      <source>Transistion effect</source>
      <translation variants="no">轉換效果</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_settings">
      <source>Settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_medium">
      <source>Medium</source>
      <translation variants="no">普通</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_remove_from_album">
      <source>Remove from album</source>
      <translation variants="no">從相簿中移除</translation>
    </message>
    <message numerus="no" id="txt_short_caption_photos">
      <source>photos</source>
      <translation variants="no">zh_tw #Photos</translation>
    </message>
    <message numerus="no" id="txt_long_caption_photos">
      <source>photos</source>
      <translation variants="no">相片</translation>
    </message>
    <message numerus="no" id="txt_photos_info_delete_l1_the_files_will_not_be">
      <source>Delete %1? (The files will not be deleted.)</source>
      <translation variants="no">是否刪除%[07]1？已儲存項目不會刪除。</translation>
    </message>
    <message numerus="no" id="txt_photos_info_remove_l1_from_album_the_file_w">
      <source>Remove %1 from album? (The file will not be deleted.)</source>
      <translation variants="no">是否從相簿中移除%[13]1？</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_use_image">
      <source>Use image</source>
      <translation variants="no">使用影像</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album">
      <source>Album</source>
      <translation variants="no">相簿</translation>
    </message>
    <message numerus="no" id="txt_photos_info_deleting_1">
      <source>Deleting %1?</source>
      <translation variants="no">正在刪除%[18]1</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_description">
      <source>Description</source>
      <translation variants="yes">
        <lengthvariant priority="1">內容說明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_drm_license_info">
      <source>DRM License Info</source>
      <translation variants="no">zh_tw #License details</translation>
    </message>
    <message numerus="no" id="txt_photos_info_no_images_to_play_slideshow">
      <source>No images to play slideshow</source>
      <translation variants="no">zh_tw #No images to play slideshow</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album_ln">
      <source>Album (%Ln)</source>
      <translation variants="no">zh_tw #Album (%Ln)</translation>
    </message>
    <message numerus="no" id="txt_photos_info_unable_to_open_image">
      <source>Unable to open image</source>
      <translation variants="no">zh_tw #Unable to open image</translation>
    </message>
    <message numerus="no" id="txt_photos_grid_no_images">
      <source>No images</source>
      <translation variants="no">zh_tw #No images</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_val_view_details">
      <source>View Details</source>
      <translation variants="no">zh_tw #View Details</translation>
    </message>
    <message numerus="no" id="txt_photos_list_size_1">
      <source>Size: %Ln </source>
      <translation variants="no">zh_tw #Size: %Ln </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_kb">
      <source>Size: %Ln kB</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_grid">
      <source>Grid</source>
      <translation variants="no">zh_tw #Grid</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album_l1">
      <source>Album (%L1)</source>
      <translation variants="no">zh_tw #Album (%L1)</translation>
    </message>
    <message numerus="yes" id="txt_photos_dblist_my_camera_val_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_list_date_1">
      <source>Date: %1</source>
      <translation variants="no">zh_tw #Date: %1</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_no_image_or_videos_to_display">
      <source>Not specified</source>
      <translation variants="no">(無影像或影片)</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view">
      <source>View</source>
      <translation variants="no">zh_tw #View</translation>
    </message>
    <message numerus="no" id="txt_photos_title_enter_name">
      <source>Enter name :</source>
      <translation variants="yes">
        <lengthvariant priority="1">輸入相簿名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_menu_add_to_album">
      <source>Add to album</source>
      <translation variants="no">加入至相簿</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">已拍攝影像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_list_time_1">
      <source>Time: %1</source>
      <translation variants="no">zh_tw #Time: %1</translation>
    </message>
    <message numerus="yes" id="txt_photos_info_delete_ln_items">
      <source>Delete %Ln items?</source>
      <translation>
        <numerusform plurality="a">是否刪除%Ln個項目？</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_media_wall">
      <source>Media wall</source>
      <translation variants="no">zh_tw #Media wall</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_photos">
      <source>Photos</source>
      <translation variants="no">zh_tw #Photos</translation>
    </message>
    <message numerus="yes" id="txt_photos_info_remove_ln_items_from_album_the">
      <source>Remove %Ln items from album? (The files will not be deleted.)</source>
      <translation>
        <numerusform plurality="a">是否從相簿刪除%Ln個項目？項目不會從手機中刪除。</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_gb">
      <source>Size: %Ln Gb </source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_mb">
      <source>Size: %Ln Mb</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_rotate">
      <source>Rotate</source>
      <translation variants="no">zh_tw #Rotate</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_wave">
      <source>Wave</source>
      <translation variants="no">波浪</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_new_album">
      <source>New album</source>
      <translation variants="no">新相簿</translation>
    </message>
  </context>
</TS>