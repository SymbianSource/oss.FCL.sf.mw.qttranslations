<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_pm_button_power_off">
      <source>Power Off</source>
      <translation variants="no">关机!
</translation>
    </message>
    <message numerus="no" id="txt_pm_button_silence">
      <source>Silence</source>
      <translation variants="no">无声</translation>
    </message>
    <message numerus="no" id="txt_pm_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">触摸屏振动</translation>
    </message>
    <message numerus="no" id="txt_pm_list_offline_airplane_mode">
      <source>Offline (Airplane Mode)</source>
      <translation variants="no">离线模式</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">zh ##Ringing volume</translation>
    </message>
  </context>
</TS>