<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_ir_list_internet_radio">
      <source>Internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">互联网收音机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_iradhswidget_list_internet_radio_widget">
      <source>Internet radio widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">互联网收音机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_iradhswidget_list_quick_access_for_internet_radio">
      <source>Quick access for internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">快速访问主屏幕互联网收音机</lengthvariant>
        <lengthvariant priority="2">zh #Radio on the Home screen</lengthvariant>
      </translation>
    </message>
  </context>
</TS>