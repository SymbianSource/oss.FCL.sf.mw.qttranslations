<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dpophead_connection_failed">
      <source>Connection failed</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Connection failed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_wlan_network_not_found">
      <source>WLAN network not found</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##WLAN network not found</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_check_connection_settings">
      <source>Check connection settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Check connection settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_connection_already_active">
      <source>Connection already active</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Connection already active</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_service_unreachable">
      <source>Service unreachable</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Service unreachable</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_configuration_failed">
      <source>Configuration failed</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Configuration failed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_authentication_unsuccessful">
      <source>Authentication unsuccessful</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Authentication unsuccessful</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_signal_too_weak">
      <source>Signal too weak </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Signal too weak </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_sim_card_missing">
      <source>SIM card missing </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##SIM card missing </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_connection_unavailable">
      <source>Connection unavailable</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Connection unavailable</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_check_security_key">
      <source>Check security key</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Check security key</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_please_try_again">
      <source>Please try again </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Please try again </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_permission_denied">
      <source>Permission denied </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Permission denied </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_internal_error">
      <source>Internal error </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Internal error </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_connecting">
      <source>Connecting</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Connecting</lengthvariant>
      </translation>
    </message>
  </context>
</TS>