<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_drm_dpophead_registration">
      <source>Registration</source>
      <translation variants="no">vi #Registration</translation>
    </message>
    <message numerus="no" id="txt_common_button_copy">
      <source>Copy</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Copy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_registration">
      <source>Registration</source>
      <translation variants="no">vi #Registration</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_expired">
      <source>Licence expired</source>
      <translation variants="no">vi #Licence expired</translation>
    </message>
    <message numerus="no" id="txt_drm_title_right_objects">
      <source>Right Objects</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Right Objects</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_days">
      <source>%Ln day</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_forward_protected">
      <source>Forward Protected</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Forward Protected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_playing_time_left">
      <source>Playing time left:</source>
      <translation variants="no">vi #Playing time left:</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_print_print_rights_until">
      <source>Print: Print rights until </source>
      <translation variants="no">vi #Print: Print rights until </translation>
    </message>
    <message numerus="no" id="txt_drm_button_continue">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Continue</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_use_object_can_only_be_vie">
      <source>Unable to use. Object can only be viewed</source>
      <translation variants="no">vi #Unable to use. Object can only be viewed</translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_hours">
      <source>%Ln hour</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_times">
      <source>%Ln time</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_list_valid">
      <source>Valid</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Valid</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_print">
      <source>Print:</source>
      <translation variants="no">vi #Print:</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_display">
      <source>Display:</source>
      <translation variants="no">vi #Display:</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_months">
      <source>%Ln month</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_view_restriction">
      <source>View restriction </source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #View restriction </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_some_objects_protected_unable_to_sen">
      <source>Some objects protected. Unable to send protected objects</source>
      <translation variants="no">vi #Some objects protected. Unable to send protected objects</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_view_view_rights_until">
      <source>View: View rights until </source>
      <translation variants="no">vi #View: View rights until </translation>
    </message>
    <message numerus="no" id="txt_drm_list_allowed">
      <source>Allowed</source>
      <translation variants="no">vi #Allowed</translation>
    </message>
    <message numerus="no" id="txt_drm_title_licence">
      <source>Licence</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Licence</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_no_licence">
      <source>No licence</source>
      <translation variants="no">vi #No licence</translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_years">
      <source>%Ln year</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_view_view_rights_from">
      <source>View: View rights from</source>
      <translation variants="no">vi #View: View rights from</translation>
    </message>
    <message numerus="no" id="txt_drm_list_unlimited">
      <source>Unlimited</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unlimited</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_valid_from_l1">
      <source>Licence valid from %L1</source>
      <translation variants="no">vi #Licence valid from %L1</translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_seconds">
      <source>%Ln second</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_send_protected_objects">
      <source>Unable to send protected objects</source>
      <translation variants="no">vi #Unable to send protected objects</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_play_and_execute_valid_until">
      <source>Play and Execute: Valid until </source>
      <translation variants="no">vi #Play and Execute: Valid until </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_views_left">
      <source>Views left:</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Views left:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_play_and_execute">
      <source>Play and Execute:</source>
      <translation variants="no">vi #Play and Execute:</translation>
    </message>
    <message numerus="no" id="txt_drm_title_no_licence">
      <source>No licence</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #No licence</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dpophead_licence_download">
      <source>Licence download</source>
      <translation variants="no">vi #Licence download</translation>
    </message>
    <message numerus="no" id="txt_drm_title_registration">
      <source>Registration</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Registration</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_unlock_file">
      <source>Unlock file</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unlock file</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_licence_download">
      <source>Licence download</source>
      <translation variants="no">vi #Licence download</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_print_print_rights_from">
      <source>Print: Print rights from</source>
      <translation variants="no">vi #Print: Print rights from</translation>
    </message>
    <message numerus="no" id="txt_drm_title_unable_to_send">
      <source>Unable to send</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unable to send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_list_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">vi #Not allowed</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_forward_protected_objects">
      <source>Unable to forward protected objects</source>
      <translation variants="no">vi #Unable to forward protected objects</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_play_and_execute_valid_from">
      <source>Play and Execute: Valid from</source>
      <translation variants="no">vi #Play and Execute: Valid from</translation>
    </message>
    <message numerus="no" id="txt_drm_title_unable_to_use">
      <source>Unable to use</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unable to use</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_licence_status">
      <source>Licence status:</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Licence status:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_execution_times">
      <source>Execution times:</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Execution times:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Send</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_minutes">
      <source>%Ln minute</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_prints_left">
      <source>Prints left:</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Prints left:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_send_protected_objects_sen">
      <source>Unable to send protected objects. Send unprotected objects only?"</source>
      <translation variants="no">vi #Unable to send protected objects. Send unprotected objects only?"</translation>
    </message>
    <message numerus="no" id="txt_drm_list_not_valid_yet">
      <source>Not valid yet</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Not valid yet</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_sending">
      <source>Sending:</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Sending:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_plays_left">
      <source>Plays left:</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Plays left:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_1_deleted">
      <source>%1 deleted</source>
      <translation variants="no">vi #%1 deleted</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_send_protected_object">
      <source>Unable to send protected object</source>
      <translation variants="no">vi #Unable to send protected object</translation>
    </message>
    <message numerus="no" id="txt_drm_title_file_will_be_expired">
      <source>File will be expired</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #File will be expired</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_limited_time_use">
      <source>limited time use</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #limited time use</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_licence_expired">
      <source>Licence expired</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Licence expired</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_file_locked">
      <source>File locked</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #File locked</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_button_unlock">
      <source>Unlock</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unlock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_button_get">
      <source>Get</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Get</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_button_extend">
      <source>Extend</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Extend</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_no_usage">
      <source>No Usage</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #No Usage</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_no_usage_time_to_use_extend_to_use">
      <source>No usage time to use. Extend to use? </source>
      <translation variants="no">vi #No usage time to use. Extend to use? </translation>
    </message>
    <message numerus="no" id="txt_drm_title_unsupported">
      <source>Unsupported</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unsupported</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_use_object">
      <source>Unable to use object</source>
      <translation variants="no">vi #Unable to use object</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_send_copyright_protected_it">
      <source>Unable to send copyright protected item</source>
      <translation variants="no">vi #Unable to send copyright protected item</translation>
    </message>
    <message numerus="no" id="txt_drm_title_rights_object_expire">
      <source>Rights Object Expire</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Rights Object Expire</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_no_rights_object_for_the_file_in_this">
      <source>No Rights Object for the file in this device</source>
      <translation variants="no">vi #No Rights Object for the file in this device</translation>
    </message>
    <message numerus="no" id="txt_drm_button_update">
      <source>Update</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_locked_with_current_sim_card_un">
      <source>File locked with current SIM card. Unlock for this SIM card?</source>
      <translation variants="no">vi #File locked with current SIM card. Unlock for this SIM card?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_1_is_locked_unlock_now">
      <source>File %1 is locked. Unlock now?</source>
      <translation variants="no">vi #File %1 is locked. Unlock now?</translation>
    </message>
    <message numerus="no" id="txt_drm_title_move_objects">
      <source>Move Objects</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Move Objects</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_move_protected_objects_mov">
      <source>Unable to move protected objects. Move unprotected objects only?</source>
      <translation variants="no">vi #Unable to move protected objects. Move unprotected objects only?</translation>
    </message>
    <message numerus="no" id="txt_drm_button_move">
      <source>Move</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Move</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_unable_to_move">
      <source>Unable to Move</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unable to Move</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_move_protected_object_to_me">
      <source>Unable to move protected object to memory card</source>
      <translation variants="no">vi #Unable to move protected object to memory card</translation>
    </message>
    <message numerus="no" id="txt_drm_title_deleted">
      <source>Deleted</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Deleted</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_deleted">
      <source>File deleted.</source>
      <translation variants="no">vi #File deleted.</translation>
    </message>
    <message numerus="no" id="txt_drm_title_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_delete_drm_protected_file">
      <source>Delete DRM protected file?</source>
      <translation variants="no">vi #Delete DRM protected file?</translation>
    </message>
    <message numerus="no" id="txt_drm_title_no_count">
      <source>No Count</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #No Count</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_use_object_extend_to_use">
      <source>Unable to use object. Extend to use?</source>
      <translation variants="no">vi #Unable to use object. Extend to use?</translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_right_object_received">
      <source>Right object received</source>
      <translation variants="no">vi #Right object received</translation>
    </message>
    <message numerus="no" id="txt_drm_dpophead_right_objects_received">
      <source>Right Objects Received</source>
      <translation variants="no">vi #Right Objects Received</translation>
    </message>
    <message numerus="no" id="txt_drm_title_copy_objects">
      <source>Copy Objects</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Copy Objects</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_copy_protected_objects_cop">
      <source>Unable to copy protected objects. Copy unprotected objects only?</source>
      <translation variants="no">vi #Unable to copy protected objects. Copy unprotected objects only?</translation>
    </message>
    <message numerus="no" id="txt_drm_title_unable_to_copy">
      <source>Unable to Copy</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unable to Copy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_copy_protected_object_to_me">
      <source>Unable to copy protected object to memory card</source>
      <translation variants="no">vi #Unable to copy protected object to memory card</translation>
    </message>
    <message numerus="no" id="txt_drm_info_deregistering_phone">
      <source>Deregistering phone</source>
      <translation variants="no">vi #Deregistering phone</translation>
    </message>
    <message numerus="no" id="txt_drm_title_deregistering">
      <source>Deregistering</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Deregistering</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_phone_deregistered">
      <source>Phone deregistered</source>
      <translation variants="no">vi #Phone deregistered</translation>
    </message>
    <message numerus="no" id="txt_drm_title_deregistered">
      <source>Deregistered</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Deregistered</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_deregister_phone">
      <source>Unable to deregister phone</source>
      <translation variants="no">vi #Unable to deregister phone</translation>
    </message>
    <message numerus="no" id="txt_drm_title_unable_to_deregister">
      <source>Unable to deregister</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unable to deregister</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_account_is_not_recognized">
      <source>Account is not recognized</source>
      <translation variants="no">vi #Account is not recognized</translation>
    </message>
    <message numerus="no" id="txt_drm_title_not_recognized">
      <source>Not recognized</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Not recognized</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_acquiring_licence">
      <source>Acquiring licence</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Acquiring licence</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_processing">
      <source>Processing</source>
      <translation variants="no">vi #Processing</translation>
    </message>
    <message numerus="no" id="txt_drm_title_retry_for_licence">
      <source>Retry for licence</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Retry for licence</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_not_received_try_again">
      <source>Licence not received. Try again?</source>
      <translation variants="no">vi #Licence not received. Try again?</translation>
    </message>
    <message numerus="no" id="txt_drm_button_try_again">
      <source>Try again</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Try again</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_account_update">
      <source>Account update</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Account update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_will_be_updated_continu">
      <source>Registration will be updated. Continue?</source>
      <translation variants="no">vi #Registration will be updated. Continue?</translation>
    </message>
    <message numerus="no" id="txt_drm_title_register_failure">
      <source>Register failure</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Register failure</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_register">
      <source>Unable to register</source>
      <translation variants="no">vi #Unable to register</translation>
    </message>
    <message numerus="no" id="txt_drm_title_registered">
      <source>Registered</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Registered</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_phone_registered">
      <source>Phone registered</source>
      <translation variants="no">vi #Phone registered</translation>
    </message>
    <message numerus="no" id="txt_drm_title_get_new_licence">
      <source>Get new licence</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Get new licence</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_not_yet_received_expected_ti">
      <source>Licence not yet received. Expected time of delivery elapsed. Get new licence?</source>
      <translation variants="no">vi #Licence not yet received. Expected time of delivery elapsed. Get new licence?</translation>
    </message>
    <message numerus="no" id="txt_drm_title_updating">
      <source>Updating</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Updating</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_updating_registration">
      <source>Updating registration</source>
      <translation variants="no">vi #Updating registration</translation>
    </message>
    <message numerus="no" id="txt_drm_title_updated">
      <source>Updated</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Updated</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_updated">
      <source>Registration updated</source>
      <translation variants="no">vi #Registration updated</translation>
    </message>
    <message numerus="no" id="txt_drm_title_update_failure">
      <source>Update failure</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Update failure</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_update_registration">
      <source>Unable to update registration</source>
      <translation variants="no">vi #Unable to update registration</translation>
    </message>
    <message numerus="no" id="txt_drm_title_registering">
      <source>Registering</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Registering</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_registering_phone">
      <source>Registering phone</source>
      <translation variants="no">vi #Registering phone</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_ringing_tone_1_expired">
      <source>Licence for ringing tone %1 expired</source>
      <translation variants="no">vi #Licence for ringing tone %1 expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_ringing_tone_1_get">
      <source>Licence for ringing tone %1 expired. Get new licence to unlock file?</source>
      <translation variants="no">vi #Licence for ringing tone %1 expired. Get new licence to unlock file?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_message_alert_tone_1_exp">
      <source>Licence for message alert tone %1 expired</source>
      <translation variants="no">vi #Licence for message alert tone %1 expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_message_alert_tone_1_get">
      <source>Licence for message alert tone %1 expired. Get new licence to unlock file?</source>
      <translation variants="no">vi #Licence for message alert tone %1 expired. Get new licence to unlock file?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_im_alert_tone_1_expired">
      <source>Licence for IM alert tone %1 expired"</source>
      <translation variants="no">vi #Licence for IM alert tone %1 expired"</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_im_alert_tone_1_get">
      <source>Licence for IM alert tone %1 expired. Activate?</source>
      <translation variants="no">vi #Licence for IM alert tone %1 expired. Activate?</translation>
    </message>
    <message numerus="no" id="txt_drm_button_activate">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Activate</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_email_alert_tone_1_expi">
      <source>Licence for e-mail alert tone %1 expired</source>
      <translation variants="no">vi #Licence for e-mail alert tone %1 expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_email_alert_tone_1_get">
      <source>Licence for e-mail alert tone %1 expired. Get new licence to unlock file?</source>
      <translation variants="no">vi #Licence for e-mail alert tone %1 expired. Get new licence to unlock file?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_clock_alarm_tone_1_expir">
      <source>Licence for clock alarm tone %1 expired</source>
      <translation variants="no">vi #Licence for clock alarm tone %1 expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_clock_alarm_tone_1_get">
      <source>Licence for clock alarm tone %1 expired. Get new licence to unlock file?</source>
      <translation variants="no">vi #Licence for clock alarm tone %1 expired. Get new licence to unlock file?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_calendar_alert_tone_1_ex">
      <source>Licence for calendar alert tone %1 expired</source>
      <translation variants="no">vi #Licence for calendar alert tone %1 expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_calendar_alert_tone_1_get">
      <source>Licence for calendar alert tone %1 expired. Get new licence to unlock file?"</source>
      <translation variants="no">vi #Licence for calendar alert tone %1 expired. Get new licence to unlock file?"</translation>
    </message>
    <message numerus="no" id="txt_drm_info_registering">
      <source>Registering</source>
      <translation variants="no">vi #Registering</translation>
    </message>
    <message numerus="no" id="txt_drm_title_registration_complete">
      <source>Registration complete</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Registration complete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_complete">
      <source>Registration complete</source>
      <translation variants="no">vi #Registration complete</translation>
    </message>
    <message numerus="no" id="txt_drm_title_registration_failure">
      <source>Registration failure</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Registration failure</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_failed">
      <source>Registration failed</source>
      <translation variants="no">vi #Registration failed</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_theme_1_expired">
      <source>Licence for theme %1 expired</source>
      <translation variants="no">vi #Licence for theme %1 expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_theme_1_expired_get_new">
      <source>Licence for theme %1 expired. Get new licence to unlock file?</source>
      <translation variants="no">vi #Licence for theme %1 expired. Get new licence to unlock file?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_wallpaper_1_expired">
      <source>Licence for wallpaper %1 expired</source>
      <translation variants="no">vi #Licence for wallpaper %1 expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_wallpaper_1_expired_get">
      <source>Licence for wallpaper %1 expired. Get new licence to unlock file?</source>
      <translation variants="no">vi #Licence for wallpaper %1 expired. Get new licence to unlock file?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_power_saver_1_expired">
      <source>Licence for power saver %1 expired</source>
      <translation variants="no">vi #Licence for power saver %1 expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_power_saver_1_expired_g">
      <source>Licence for power saver %1 expired. Get new licence to unlock file?</source>
      <translation variants="no">vi #Licence for power saver %1 expired. Get new licence to unlock file?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_1_locked_with_current_sim_unlo">
      <source>File %1 locked with current SIM. Unlock for this SIM card?</source>
      <translation variants="no">vi #File %1 locked with current SIM. Unlock for this SIM card?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_wallpaper_1_locked_with_unlock">
      <source>Wallpaper %1 locked with current SIM card. Unlock for this SIM card?</source>
      <translation variants="no">vi #Wallpaper %1 locked with current SIM card. Unlock for this SIM card?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_theme_1_locked_with_current_unlock">
      <source>Theme %1 locked with current SIM card. Unlock for this SIM card?</source>
      <translation variants="no">vi #Theme %1 locked with current SIM card. Unlock for this SIM card?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_ringing_tone_1_locked_with_unlock">
      <source>Ringing tone %1 locked with current SIM card. Unlock for this SIM card?</source>
      <translation variants="no">vi #Ringing tone %1 locked with current SIM card. Unlock for this SIM card?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_message_alert_tone_1_locked_unlock">
      <source>Message alert tone %1 locked with current SIM card. Unlock for this SIM card?</source>
      <translation variants="no">vi #Message alert tone %1 locked with current SIM card. Unlock for this SIM card?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_email_alert_tone_1_locked_with_unlock">
      <source>E-mail alert tone %1 locked with current SIM card. unlock for this SIM card?</source>
      <translation variants="no">vi #E-mail alert tone %1 locked with current SIM card. unlock for this SIM card?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_clock_alarm_tone_1_locked_with_unlock">
      <source>Clock alarm tone %1 locked with current SIM card. Unlock for this SIM card?</source>
      <translation variants="no">vi #Clock alarm tone %1 locked with current SIM card. Unlock for this SIM card?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_calendar_alert_tone_1_locked_with_cu">
      <source>Calendar alert tone %1 locked with current SIM card. Unlock for this SIM card?</source>
      <translation variants="no">vi #Calendar alert tone %1 locked with current SIM card. Unlock for this SIM card?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_with_1_needed_register">
      <source>Registration with %1 needed. Register phone?"</source>
      <translation variants="no">vi #Registration with %1 needed. Register phone?"</translation>
    </message>
    <message numerus="no" id="txt_drm_button_register">
      <source>Register</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Register</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_registration_needed">
      <source>Registration needed</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Registration needed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_with_content_provider_ne">
      <source>Registration with content provider needed. Register phone?</source>
      <translation variants="no">vi #Registration with content provider needed. Register phone?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_will_be_unlocked_connection_to">
      <source>File will be unlocked. Connection to internet is needed. Continue?</source>
      <translation variants="no">vi #File will be unlocked. Connection to internet is needed. Continue?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_1_locked_with_current_sim_card">
      <source>File %1 locked with current SIM card.</source>
      <translation variants="no">vi #File %1 locked with current SIM card.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_wallpaper_1_locked_with_current_sim">
      <source>Wallpaper %1 locked with current SIM card. Default wallpaper will be used.</source>
      <translation variants="no">vi #Wallpaper %1 locked with current SIM card. Default wallpaper will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_theme_1_locked_with_current_sim_card">
      <source>Theme %1 locked with current SIM card. Default theme will be used.</source>
      <translation variants="no">vi #Theme %1 locked with current SIM card. Default theme will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_power_saver_1_locked_with_current_si">
      <source>Power saver %1 locked with current SIM card. Default power saver will be used.</source>
      <translation variants="no">vi #Power saver %1 locked with current SIM card. Default power saver will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_ringing_tone_1_locked_with_current_s">
      <source>Ringing tone %1 locked with current SIM card. Default tone will be used.</source>
      <translation variants="no">vi #Ringing tone %1 locked with current SIM card. Default tone will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_message_alert_tone_1_locked_with_cur">
      <source>Message alert tone %1 locked with current SIM card. Default tone will be used.</source>
      <translation variants="no">vi #Message alert tone %1 locked with current SIM card. Default tone will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_email_alert_tone_1_locked_with_curr">
      <source>E-mail alert tone %1 locked with current SIM card. Default tone will be used.</source>
      <translation variants="no">vi #E-mail alert tone %1 locked with current SIM card. Default tone will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_clock_alarm_tone_1_locked_with_curre">
      <source>Clock alarm tone %1 locked with current SIM card. Default tone will be used.</source>
      <translation variants="no">vi #Clock alarm tone %1 locked with current SIM card. Default tone will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_calendar_alarm_tone_1_locked_with_cu">
      <source>Calendar alarm tone %1 locked with current SIM card. Default tone will be used.</source>
      <translation variants="no">vi #Calendar alarm tone %1 locked with current SIM card. Default tone will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_locked_with_current_sim_card">
      <source>File locked with current SIM card</source>
      <translation variants="no">vi #File locked with current SIM card</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_unlock_file">
      <source>Unable to unlock file</source>
      <translation variants="no">vi #Unable to unlock file</translation>
    </message>
    <message numerus="no" id="txt_drm_title_unable_to_unlock">
      <source>Unable to unlock</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unable to unlock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_connection_failure">
      <source>Connection failure</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Connection failure</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_unlock_file_connection_fai">
      <source>Unable to unlock file. Connection failed with used access point.</source>
      <translation variants="no">vi #Unable to unlock file. Connection failed with used access point.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_unlock_file_define_at_leas">
      <source>Unable to unlock file. Define at least one access point.</source>
      <translation variants="no">vi #Unable to unlock file. Define at least one access point.</translation>
    </message>
    <message numerus="no" id="txt_drm_title_no_access_point">
      <source>No access point</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #No access point</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_opening">
      <source>Opening</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Opening</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_opening">
      <source>Opening</source>
      <translation variants="no">vi #Opening</translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_with_content_provider_is">
      <source>Registration with content provider is needed. After registration, licences for protected files can be downloaded automatically.</source>
      <translation variants="no">vi #Registration with content provider is needed. After registration, licences for protected files can be downloaded automatically.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_can_be_used_from_1">
      <source>File can be used from %1</source>
      <translation variants="no">vi #File can be used from %1</translation>
    </message>
    <message numerus="no" id="txt_drm_info_updating_service_information">
      <source>Updating service information</source>
      <translation variants="no">vi #Updating service information</translation>
    </message>
    <message numerus="no" id="txt_drm_title_unable_to_open">
      <source>Unable to open</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unable to open</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_open_file_change_allow_us">
      <source>Unable to open file. Change 'Allow usage reporting for' settings.</source>
      <translation variants="no">vi #Unable to open file. Change 'Allow usage reporting for' settings.</translation>
    </message>
    <message numerus="no" id="txt_drm_title_not_registered">
      <source>Not registered</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Not registered</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_phone_not_registered_with_content_pro">
      <source>Phone not registered with content provider.</source>
      <translation variants="no">vi #Phone not registered with content provider.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_connected_to_1_via_2">
      <source>Connected to ’%1’ via ’%2’"</source>
      <translation variants="no">vi #Connected to ’%1’ via ’%2’"</translation>
    </message>
    <message numerus="no" id="txt_drm_info_connecting_via_1">
      <source>Connecting via: ’%1’</source>
      <translation variants="no">vi #Connecting via: ’%1’</translation>
    </message>
    <message numerus="no" id="txt_drm_title_connecting">
      <source>Connecting</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Connecting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_connecting_to_1">
      <source>Connecting to: ’%1’</source>
      <translation variants="no">vi #Connecting to: ’%1’</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_unlock_file_see_more_infor">
      <source>Unable to unlock file. See more information online?</source>
      <translation variants="no">vi #Unable to unlock file. See more information online?</translation>
    </message>
    <message numerus="no" id="txt_drm_button_connect">
      <source>Connect</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Connect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_unlock_file_no_network_cov">
      <source>Unable to unlock file. No network coverage.</source>
      <translation variants="no">vi #Unable to unlock file. No network coverage.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_selected_item_is_valid_for_limited_ti">
      <source>Selected item is valid for limited time. Continue?</source>
      <translation variants="no">vi #Selected item is valid for limited time. Continue?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_selected_item_valid_until">
      <source>Licence for selected item valid until %1. Continue?</source>
      <translation variants="no">vi #Licence for selected item valid until %1. Continue?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_1_expired_or_missing_ge">
      <source>Licence for %1 expired or missing. Get new licence now?</source>
      <translation variants="no">vi #Licence for %1 expired or missing. Get new licence now?</translation>
    </message>
    <message numerus="no" id="txt_drm_title_file_expired_or_missing">
      <source>File expired or missing</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #File expired or missing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_has_expired_or_it_is_missing">
      <source>Licence has expired or it is missing</source>
      <translation variants="no">vi #Licence has expired or it is missing</translation>
    </message>
    <message numerus="no" id="txt_drm_title_registration_update">
      <source>Registration update</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Registration update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_will_be_updated">
      <source>Registration will be updated. Continue?</source>
      <translation variants="no">vi #Registration will be updated. Continue?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_not_yet_received_expected_get">
      <source>Licence not yet received. Expected time of delivery elapsed. Get new licence?</source>
      <translation variants="no">vi #Licence not yet received. Expected time of delivery elapsed. Get new licence?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_waiting_for_licence_try_again_later">
      <source>Waiting for licence. Try again later.</source>
      <translation variants="no">vi #Waiting for licence. Try again later.</translation>
    </message>
    <message numerus="no" id="txt_drm_title_waiting_for_licence">
      <source>Waiting for licence</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Waiting for licence</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_not_yet_received_expected">
      <source>Licence not yet received. Expected time of delivery elapsed.</source>
      <translation variants="no">vi #Licence not yet received. Expected time of delivery elapsed.</translation>
    </message>
    <message numerus="no" id="txt_drm_title_unable_to_receive_licence">
      <source>Unable to receive licence</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unable to receive licence</lengthvariant>
      </translation>
    </message>
  </context>
</TS>