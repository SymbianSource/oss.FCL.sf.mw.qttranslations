<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_ussd_info_there_are_still_unread_notifications">
      <source>There are still unread notifications.Exit anyway?</source>
      <translation variants="no">اب بھی بغیر پڑھے گئے پیغامات ہیں۔ بہرحال باہر نکلیں؟</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_exit">
      <source>Exit </source>
      <translation variants="yes">
        <lengthvariant priority="1">باہر نکلیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_not_completed">
      <source>Request not completed</source>
      <translation variants="no">درخواست مکمل نہیں کی گئی</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_unable_to_use_network_phone_is">
      <source>Unable to use network. Phone is currently in offline mode.</source>
      <translation variants="no">آف. وضع میں نیٹ. است. سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">اجازت نہیں</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_not_confirmed">
      <source>Request not confirmed</source>
      <translation variants="no">درخواست کی توثیق نہیں ہوئی</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_message">
      <source>Message:</source>
      <translation variants="yes">
        <lengthvariant priority="1">موصولہ پیغام:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_no_service">
      <source>No service</source>
      <translation variants="no">کوئی خدمت نہیں</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_service_commands">
      <source>Service commands</source>
      <translation variants="yes">
        <lengthvariant priority="1">احکام خدمت</lengthvariant>
        <lengthvariant priority="2">ur #Service comms.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_done">
      <source>Done</source>
      <translation variants="no">انجام دیا گیا</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_next">
      <source>Next</source>
      <translation variants="yes">
        <lengthvariant priority="1">اگلا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_button_reply">
      <source>Reply </source>
      <translation variants="yes">
        <lengthvariant priority="1">جواب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_completed">
      <source>Request completed</source>
      <translation variants="no">درخواست مکمل کی گئی</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_unconfirmed">
      <source>Unconfirmed</source>
      <translation variants="no">ur ##Unconfirmed</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_offline_not_possible">
      <source>Offline not possible</source>
      <translation variants="no">ur ##Offline not possible</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_sending">
      <source>Sending</source>
      <translation variants="no">احکام خدمت بھیجا جا رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_long_caption_service_commands">
      <source>Service commands</source>
      <translation variants="no">احکام خدمت</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_reply">
      <source>Reply:</source>
      <translation variants="yes">
        <lengthvariant priority="1">جواب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_not_done">
      <source>Not done</source>
      <translation variants="no">انجام نہیں دیا گیا</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_result_unknown">
      <source>Result unknown</source>
      <translation variants="no">نامعلوم جواب</translation>
    </message>
  </context>
</TS>