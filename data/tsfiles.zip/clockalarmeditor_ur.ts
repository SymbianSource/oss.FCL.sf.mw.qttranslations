<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_title_clock3">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Clock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hrs_and_2_min">
      <source>Time to alarm %1 hours and %2 minute</source>
      <translation variants="no">الارم تک کا وقت: %[07]1 گھنٹے %[07]2 منٹ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_once">
      <source>Once</source>
      <translation variants="no">کوئی نہیں</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hr_and_2_mins">
      <source>Time to alarm %1 hour and %2 minutes</source>
      <translation variants="no">الارم تک کا وقت: %[07]1 گھنٹہ %[07]2 منٹ</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_delete">
      <source>Delete</source>
      <translation variants="no">مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">تبدیلیاں مسترد</translation>
    </message>
    <message numerus="no" id="txt_clock_note_alarm_occurs_once_only_on_next_1_a">
      <source>Alarm occurs once only on next %1 at %2</source>
      <translation variants="no">الارم صرف ایک بار، اگلا %[11]1 %2</translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="no">تاریخ الارم</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_alarm_will_occur_at_1_after_au">
      <source>Alarm will occur at %1 after automatic daylight saving update</source>
      <translation variants="no">دن کی روشنی بچت کی خودکار تجدید کے بعد الارم %[08]1 پر بجے گا</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_alarm_sound">
      <source>Alarm sound</source>
      <translation variants="no">الارم کی آواز</translation>
    </message>
    <message numerus="no" id="txt_clock_note_alarm_occurs_workdays_at_1">
      <source>Alarm occurs workdays at %1</source>
      <translation variants="no">الارم کام کے دنوں میں %[12]1 پر بجتا ہے</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_alarm_occurs_every_day_at_1">
      <source>Alarm occurs every day at %1</source>
      <translation variants="no">الارم روزانہ %[22]1 پر بجتا ہے</translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_time">
      <source>Time</source>
      <translation variants="no">وقت</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_time">
      <source>Time</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_date">
      <source>Date</source>
      <translation variants="no">تاریخ</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hrs_and_2_mins">
      <source>Time to alarm %1 hours and %2 minutes</source>
      <translation variants="no">الارم تک کا وقت: %[07]1 گھنٹے %[07]2 منٹ</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_val_alarm">
      <source>Alarm</source>
      <translation variants="no">الارم</translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="no">وقت الارم</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_on_workdays">
      <source>Repeat on workdays</source>
      <translation variants="no">کام کے دن</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hr_and_2_min">
      <source>Time to alarm %1 hour and %2 minute</source>
      <translation variants="no">الارم تک کا وقت: %[07]1 گھنٹہ %[07]2 منٹ</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_description">
      <source>Description</source>
      <translation variants="no">تفصیل</translation>
    </message>
    <message numerus="no" id="txt_clock_note_alarm_occurs_every_week_on_1_at_2">
      <source>Alarm occurs every week on %1 at %2</source>
      <translation variants="no">الارم ہر ہفتے %[08]1 کو %[08]2 پر بجتا ہے </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_occurence">
      <source>Occurence</source>
      <translation variants="yes">
        <lengthvariant priority="1">دہرائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_new_alarm">
      <source>New alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا الارم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">الارم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_daily">
      <source>Repeat daily</source>
      <translation variants="no">روزانہ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_day">
      <source>Day</source>
      <translation variants="yes">
        <lengthvariant priority="1">دن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_weekly">
      <source>Repeat weekly</source>
      <translation variants="no">ہفتہ وار</translation>
    </message>
  </context>
</TS>