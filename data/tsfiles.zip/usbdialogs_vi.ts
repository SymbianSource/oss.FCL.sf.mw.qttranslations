<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dpinfo_mass_storage">
      <source>as mass storage</source>
      <translation variants="no">Chế độ ổ đĩa chung</translation>
    </message>
    <message numerus="no" id="txt_usb_info_error_in_usb_connection_disconnect_d">
      <source>Error in USB connection. Disconnect device.</source>
      <translation variants="no">Lỗi trong kết nối USB. Ngắt kết nối thiết bị.</translation>
    </message>
    <message numerus="no" id="txt_usb_info_partially_supported_usb_device_connec">
      <source>Partially supported USB device connected. All functionality might not work.</source>
      <translation variants="no">Đã kết nối thiết bị USB được hỗ trợ một phần. Tất cả các chức năng có thể không hoạt động.</translation>
    </message>
    <message numerus="no" id="txt_usb_dpophead_usb_disconnected">
      <source>USB disconnected</source>
      <translation variants="no">Đã ngắt kết nối USB</translation>
    </message>
    <message numerus="no" id="txt_usb_info_memory_full_close_some_applications">
      <source>Memory full. Close some applications and try to connect USB cable again.</source>
      <translation variants="no">Bộ nhớ đầy. Đóng bớt ứng dụng và kết nối lại cáp dữ liệu.</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_safe_to_remove">
      <source>Safe to remove</source>
      <translation variants="no">An toàn để tháo ra</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unsupported_usb_device_disconnect_de">
      <source>Unsupported USB device. Disconnect device.</source>
      <translation variants="no">Thiết bị USB không được hỗ trợ. Ngắt kết nối thiết bị.</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_media_transfer">
      <source>as media transfer</source>
      <translation variants="no">Chế độ truyền media</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_headset_in_use">
      <source>headset in use</source>
      <translation variants="no">Tai nghe đang được sử dụng</translation>
    </message>
    <message numerus="no" id="txt_usb_info_hubs_are_not_supported_disconnect_us">
      <source>Hubs are not supported. Disconnect device.</source>
      <translation variants="no">Hub không được hỗ trợ. Ngắt kết nối thiết bị.</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_ovi_suite">
      <source>to OVI suite</source>
      <translation variants="no">Nokia Ovi Suite</translation>
    </message>
    <message numerus="no" id="txt_usb_info_disk_full_remove_some_files_and_try">
      <source>Disk full. Remove some files and try connect USB cable again</source>
      <translation variants="no">Ổ đĩa đầy. Xóa bớt tập tin và kết nối lại cáp dữ liệu.</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_use_file_system_in_device">
      <source>Unable to use file system in device. Disconnect device.</source>
      <translation variants="no">Không thể sử dụng hệ thống tập tin trong thiết bị. Ngắt kết nối cáp.</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_show_a_memory_to_other_devi">
      <source>Unable to show a memory to other device.</source>
      <translation variants="no">Không thể hiển thị bộ nhớ cho các thiết bị khác</translation>
    </message>
    <message numerus="no" id="txt_usb_info_remove_usb_cable_or_connect_a_device">
      <source>Remove USB cable or connect a device.</source>
      <translation variants="no">Tháo cáp dữ liệu hoặc kết nối thiết bị.</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_phone_as_modem">
      <source>as web connection</source>
      <translation variants="no">Kết nối PC vào chế độ internet</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_eject_the_usb_device_some">
      <source>Unable to eject the USB device. Some of the applications may still be using it.</source>
      <translation variants="no">Không thể tháo cáp dữ liệu ra. Có thể một số ứng dụng vẫn đang sử dụng cáp.</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unknown_file_system_disconnect_devic">
      <source>Unknown file system. Disconnect device.</source>
      <translation variants="no">Hệ thống tập tin không biết. Ngắt kết nối thiết bị.</translation>
    </message>
    <message numerus="no" id="txt_usb_dpophead_usb_connected">
      <source>USB connected</source>
      <translation variants="no">Đã kết nối USB</translation>
    </message>
  </context>
</TS>