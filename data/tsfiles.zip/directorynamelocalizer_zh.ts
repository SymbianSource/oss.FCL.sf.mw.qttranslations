<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_links">
      <source>Links</source>
      <translation variants="no">链接</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_install">
      <source>Install files</source>
      <translation variants="no">已安装的文件</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_sounds">
      <source>Sound files</source>
      <translation variants="no">声音文件</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_contacts">
      <source>Contats</source>
      <translation variants="no">名片</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_games">
      <source>Games</source>
      <translation variants="no">游戏</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_others">
      <source>Others</source>
      <translation variants="no">其他</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_digital_tones">
      <source>Sound clips</source>
      <translation variants="no">声音片段</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_pres_logos">
      <source>Presence logos</source>
      <translation variants="no">状态标志</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_mms_bc">
      <source>Wallpapers</source>
      <translation variants="no">壁纸</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_gms_pict">
      <source>Picture messages</source>
      <translation variants="no">图片信息</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_videos">
      <source>Video clips</source>
      <translation variants="no">视频片段</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_images">
      <source>Images</source>
      <translation variants="no">图像</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_simple_tones">
      <source>Ringing tones</source>
      <translation variants="no">铃声</translation>
    </message>
  </context>
</TS>