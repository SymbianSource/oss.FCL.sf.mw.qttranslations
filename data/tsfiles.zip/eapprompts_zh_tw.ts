<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_info_provisioning_not_successful_reactiv">
      <source>Provisioning not successful. Re-activate provisioning in settings.</source>
      <translation variants="no">佈建失敗。請在設定當中重新啟動佈建。</translation>
    </message>
    <message numerus="no" id="txt_occ_title_1_message">
      <source>%1 message:</source>
      <translation variants="no">%[21]1訊息：</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok_single_dialog">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_create_password_for_encrypted_pac_s">
      <source>Create password for encrypted PAC store:</source>
      <translation variants="yes">
        <lengthvariant priority="1">加密PAC儲存密碼：</lengthvariant>
        <lengthvariant priority="2">zh_tw #Password for PAC store:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_user_name">
      <source>%1 user name:</source>
      <translation variants="no">%[07]1使用者名稱：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_new_eapmschapv2_password">
      <source>New EAP-MSCHAPv2 password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">新EAP-MSCHAPv2密碼：</lengthvariant>
        <lengthvariant priority="2">zh_tw #New EAP-MSCHAPv2 passw.:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">確認密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_install_pac_from_server_1">
      <source>Install PAC from server '%1'?</source>
      <translation variants="no">是否從伺服器"%[39]1"安裝PAC？</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">PAC儲存密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_authenticated_provisioning_in_pro">
      <source>Authenticated provisioning in progress</source>
      <translation variants="no">正在進行安全佈建</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_file_password_for_1">
      <source>PAC file password for '%1':</source>
      <translation variants="no">"%[05]1"的PAC檔案密碼：</translation>
    </message>
    <message numerus="no" id="txt_occ_info_eapmschapv2_password_has_expired_yo">
      <source>EAP-MSCHAPv2 password has expired. You must create a new one.</source>
      <translation variants="no">EAP-MSCHAPv2密碼已逾期。請建立新密碼。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_old_eapmschapv2_password">
      <source>Old EAP-MSCHAPv2 password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">舊EAP-MSCHAPv2密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_unauthenticated_provisioning_in_p">
      <source>Unauthenticated provisioning in progress</source>
      <translation variants="no">正在進行不安全佈建</translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_password">
      <source>Password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_password">
      <source>%1 password:</source>
      <translation variants="no">%[10]1密碼：</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #OK</lengthvariant>
      </translation>
    </message>
  </context>
</TS>