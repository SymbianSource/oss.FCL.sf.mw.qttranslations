<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_drm_info_licence_expired_or_missing">
      <source>Licence expired or missing</source>
      <translation variants="no">zh_tw #Licence expired or missing</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_expired">
      <source>Licence expired</source>
      <translation variants="no">zh_tw #Licence expired</translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_months">
      <source>%Ln month</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_not_yet_received_expected_ti">
      <source>Licence not yet received. Expected time of delivery elapsed. Need new licence.</source>
      <translation variants="no">zh_tw #Licence not yet received. Expected time of delivery elapsed. Need new licence.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_unlock_file_see_more_infor">
      <source>Unable to unlock file. For more information go online</source>
      <translation variants="no">zh_tw #Unable to unlock file. For more information go online</translation>
    </message>
    <message numerus="no" id="txt_drm_button_extend">
      <source>Extend</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Extend</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dpophead_licence_downloaded">
      <source>Licence downloaded</source>
      <translation variants="no">zh_tw #Licence downloaded</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_theme_expired_need_now">
      <source>Licence for theme expired. Like to use?</source>
      <translation variants="no">zh_tw #Licence for theme expired. Like to use?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_move_protected_objects_mov">
      <source>Unable to move protected objects. How about unprotected objects?</source>
      <translation variants="no">zh_tw #Unable to move protected objects. How about unprotected objects?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_ringing_tone_expired">
      <source>Licence for ringing tone expired</source>
      <translation variants="no">zh_tw #Licence for ringing tone expired</translation>
    </message>
    <message numerus="no" id="txt_drm_list_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">zh_tw #Not allowed</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_power_saver_expired_need">
      <source>Licence for power saver expired.  Like to use?</source>
      <translation variants="no">zh_tw #Licence for power saver expired.  Like to use?</translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_registration_for_1_val_completed">
      <source>Completed</source>
      <translation variants="no">zh_tw #Completed</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_calendar_alert_tone_expir">
      <source>Licence for calendar alert tone expired</source>
      <translation variants="no">zh_tw #Licence for calendar alert tone expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_use_object_extend_to_use">
      <source>Unable to use object. Would like to use?</source>
      <translation variants="no">zh_tw #Unable to use object. Would like to use?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_deregistering_phone">
      <source>Unsubscribing</source>
      <translation variants="no">zh_tw #Unsubscribing</translation>
    </message>
    <message numerus="no" id="txt_drm_button_unlock">
      <source>Unlock</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Unlock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_view_view_rights_from">
      <source>View: View rights from</source>
      <translation variants="no">zh_tw #View: View rights from</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_play_and_execute">
      <source>Play and Execute:</source>
      <translation variants="no">zh_tw #Play and Execute:</translation>
    </message>
    <message numerus="no" id="txt_drm_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_button_update">
      <source>Update</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_licence_download_completed">
      <source>Licence download for %1</source>
      <translation variants="no">zh_tw #Licence download for %1</translation>
    </message>
    <message numerus="no" id="txt_drm_formlabel_track_protected_content">
      <source>Track protected content</source>
      <translation variants="no">zh_tw #Track protected content</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_display">
      <source>Display:</source>
      <translation variants="no">zh_tw #Display:</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_views_left">
      <source>Views left:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Views left:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dpophead_right_objects_received">
      <source>Licence Received</source>
      <translation variants="no">zh_tw #Licence Received</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_register">
      <source>Unable to register</source>
      <translation variants="no">zh_tw #Unable to register</translation>
    </message>
    <message numerus="no" id="txt_drm_info_account_is_not_recognized">
      <source>Account is not recognized</source>
      <translation variants="no">zh_tw #Account is not recognized</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_wallpaper_expired_need_n">
      <source>Licence for wallpaper expired. Like to use?</source>
      <translation variants="no">zh_tw #Licence for wallpaper expired. Like to use?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_power_saver_locked_with_current_sim">
      <source>Power saver  locked with current SIM card. Default power saver will be used.</source>
      <translation variants="no">zh_tw #Power saver  locked with current SIM card. Default power saver will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_registering">
      <source>Registering</source>
      <translation variants="no">zh_tw #Registering</translation>
    </message>
    <message numerus="no" id="txt_drm_button_get">
      <source>Get</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Get</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_locked_with_current_sim_card">
      <source>File locked with current SIM card</source>
      <translation variants="no">zh_tw #File locked with current SIM card</translation>
    </message>
    <message numerus="no" id="txt_drm_button_move">
      <source>Move</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Move</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_theme_locked_with_current_sim_card">
      <source>Theme  locked with current SIM card. Default theme will be used.</source>
      <translation variants="no">zh_tw #Theme  locked with current SIM card. Default theme will be used.</translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_days">
      <source>%Ln day</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_print_print_rights_from">
      <source>Print: Print rights from</source>
      <translation variants="no">zh_tw #Print: Print rights from</translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_with_content_provider_is">
      <source>Registration with content provDoneer is needed. After registration, licences for protected files can be downloaded automatically.</source>
      <translation variants="no">zh_tw #Registration with content provDoneer is needed. After registration, licences for protected files can be downloaded automatically.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_send_protected_objects_how">
      <source>Unable to send protected objects. How about unprotected objects?</source>
      <translation variants="no">zh_tw #Unable to send protected objects. How about unprotected objects?</translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_val_on_going">
      <source>On going</source>
      <translation variants="no">zh_tw #On going</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_view_view_rights_until">
      <source>View: View rights until </source>
      <translation variants="no">zh_tw #View: View rights until </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_play_and_execute_valid_from">
      <source>Play and Execute: Valid from</source>
      <translation variants="no">zh_tw #Play and Execute: Valid from</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_licence_status">
      <source>Licence status:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Licence status:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_send_protected_object">
      <source>Unable to send protected object</source>
      <translation variants="no">zh_tw #Unable to send protected object</translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_right_object_received">
      <source>Licence received</source>
      <translation variants="no">zh_tw #Licence received</translation>
    </message>
    <message numerus="no" id="txt_drm_list_valid">
      <source>Valid</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Valid</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_years">
      <source>%Ln year</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_seconds">
      <source>%Ln second</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_list_not_valid_yet">
      <source>Not valid yet</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Not valid yet</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_button_continue">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Continue</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_button_register">
      <source>Register</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Register</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_phone_registered">
      <source>Phone registered</source>
      <translation variants="no">zh_tw #Phone registered</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_open_file_change_allow_us">
      <source>Unable to open file. Change 'Allow usage reporting for' settings.</source>
      <translation variants="no">zh_tw #Unable to open file. Change 'Allow usage reporting for' settings.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_use_object">
      <source>Unable to use object</source>
      <translation variants="no">zh_tw #Unable to use object</translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_deleted">
      <source>File deleted.</source>
      <translation variants="no">zh_tw #File deleted.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_no_licence">
      <source>No licence</source>
      <translation variants="no">zh_tw #No licence</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_move_protected_object_to_me">
      <source>Unable to move protected objects.</source>
      <translation variants="no">zh_tw #Unable to move protected objects.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_use_object_can_only_be_vie">
      <source>Unable to use object. Only details can be viewed.</source>
      <translation variants="no">zh_tw #Unable to use object. Only details can be viewed.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_valid_from_l1">
      <source>Licence valid from %1</source>
      <translation variants="no">zh_tw #Licence valid from %1</translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_failed">
      <source>Registration failed</source>
      <translation variants="no">zh_tw #Registration failed</translation>
    </message>
    <message numerus="no" id="txt_drm_info_email_alert_tone_locked_with_current">
      <source>Mail alert tone locked with current SIM card. Default tone will be used.</source>
      <translation variants="no">zh_tw #Mail alert tone locked with current SIM card. Default tone will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_wallpaper_locked_with_current_sim_car">
      <source>Wallpaper locked with current SIM card. Default wallpaper will be used.</source>
      <translation variants="no">zh_tw #Wallpaper locked with current SIM card. Default wallpaper will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_email_alert_tone_expired">
      <source>Licence for mail alert tone expired</source>
      <translation variants="no">zh_tw #Licence for mail alert tone expired</translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_hours">
      <source>%Ln hour</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_times">
      <source>%Ln time</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_forward_protected_objects">
      <source>Unable to forward protected objects</source>
      <translation variants="no">zh_tw #Unable to forward protected objects</translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_with_1_needed_register">
      <source>Phone registration with %1 needed.</source>
      <translation variants="no">zh_tw #Phone registration with %1 needed.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_complete">
      <source>Registration complete</source>
      <translation variants="no">zh_tw #Registration complete</translation>
    </message>
    <message numerus="no" id="txt_drm_info_processing">
      <source>Processing</source>
      <translation variants="no">zh_tw #Processing</translation>
    </message>
    <message numerus="no" id="txt_drm_title_licence_aquiring">
      <source>Licence aquiring </source>
      <translation variants="no">zh_tw #Licence aquiring </translation>
    </message>
    <message numerus="no" id="txt_drm_list_allowed">
      <source>Allowed</source>
      <translation variants="no">zh_tw #Allowed</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_execution_times">
      <source>Execution times:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Execution times:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_title_updating">
      <source>Service information</source>
      <translation variants="no">zh_tw #Service information</translation>
    </message>
    <message numerus="no" id="txt_drm_formlabel_allow_usage_reporting">
      <source>Allow usage reporting</source>
      <translation variants="no">zh_tw #Allow usage reporting</translation>
    </message>
    <message numerus="no" id="txt_drm_list_unlimited">
      <source>Unlimited</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Unlimited</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_selected_item_is_valid_for_limited_ti">
      <source>Selected item is valid for limited time.</source>
      <translation variants="no">zh_tw #Selected item is valid for limited time.</translation>
    </message>
    <message numerus="no" id="txt_drm_button_try_again">
      <source>Try again</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Try again</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_locked_with_current_sim">
      <source>File locked with current SIM.</source>
      <translation variants="no">zh_tw #File locked with current SIM.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_clock_alarm_tone_expired">
      <source>Licence for clock alarm tone expired</source>
      <translation variants="no">zh_tw #Licence for clock alarm tone expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_theme_expired">
      <source>Licence for theme expired</source>
      <translation variants="no">zh_tw #Licence for theme expired</translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_service_information">
      <source>Service information</source>
      <translation variants="no">zh_tw #Service information</translation>
    </message>
    <message numerus="no" id="txt_drm_info_message_alert_tone_locked_with_curren">
      <source>Message alert tone locked with current SIM card. Default tone will be used.</source>
      <translation variants="no">zh_tw #Message alert tone locked with current SIM card. Default tone will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_clock_alarm_tone_locked_with_current">
      <source>Clock alarm tone locked with current SIM card. Default tone will be used.</source>
      <translation variants="no">zh_tw #Clock alarm tone locked with current SIM card. Default tone will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_calendar_alert_tone_locked_with_curre">
      <source>Calendar alert tone locked with current SIM card.</source>
      <translation variants="no">zh_tw #Calendar alert tone locked with current SIM card.</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_print">
      <source>Print:</source>
      <translation variants="no">zh_tw #Print:</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_send_protected_objects">
      <source>Unable to send protected objects</source>
      <translation variants="no">zh_tw #Unable to send protected objects</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_play_and_execute_valid_until">
      <source>Play and Execute: Valid until </source>
      <translation variants="no">zh_tw #Play and Execute: Valid until </translation>
    </message>
    <message numerus="yes" id="txt_drm_list_ln_minutes">
      <source>%Ln minute</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_plays_left">
      <source>Plays left:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Plays left:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_copy_protected_objects_cop">
      <source>Unable to copy protected objects. How about unprotected objects?</source>
      <translation variants="no">zh_tw #Unable to copy protected objects. How about unprotected objects?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_phone_not_registered_with_content_pro">
      <source> Registration canceled</source>
      <translation variants="no">zh_tw # Registration canceled</translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_can_be_used_from_1">
      <source>File can be used from %1</source>
      <translation variants="no">zh_tw #File can be used from %1</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_prints_left">
      <source>Prints left:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Prints left:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_1_deleted">
      <source>%1 deleted</source>
      <translation variants="no">zh_tw #%1 deleted</translation>
    </message>
    <message numerus="no" id="txt_drm_info_ringing_tone_locked_with_current_sim">
      <source>Ringing tone  locked with current SIM card. Default tone will be used.</source>
      <translation variants="no">zh_tw #Ringing tone  locked with current SIM card. Default tone will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_calendar_alarm_tone_locked_with_curre">
      <source>Calendar alarm tone locked with current SIM card. Default tone will be used.</source>
      <translation variants="no">zh_tw #Calendar alarm tone locked with current SIM card. Default tone will be used.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_im_alert_tone_expired">
      <source>Licence for IM alert tone expired"</source>
      <translation variants="no">zh_tw #Licence for IM alert tone expired"</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_power_saver_expired">
      <source>Licence for power saver expired</source>
      <translation variants="no">zh_tw #Licence for power saver expired</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_expired_or_missing_need_new">
      <source>Licence expired or missing. Need  new licence</source>
      <translation variants="no">zh_tw #Licence expired or missing. Need  new licence</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_ringing_tone_expired_nee">
      <source>Licence for ringing tone expired. Like to use?</source>
      <translation variants="no">zh_tw #Licence for ringing tone expired. Like to use?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_message_alert_tone_expire">
      <source>Licence for message alert tone expired</source>
      <translation variants="no">zh_tw #Licence for message alert tone expired</translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_registration_for_1_val_updating">
      <source>Updating….</source>
      <translation variants="no">zh_tw #Updating….</translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_licence_aquiring">
      <source>Licence aquiring </source>
      <translation variants="no">zh_tw #Licence aquiring </translation>
    </message>
    <message numerus="no" id="txt_drm_info_update_required">
      <source>Update required</source>
      <translation variants="no">zh_tw #Update required</translation>
    </message>
    <message numerus="no" id="txt_drm_formlabel_licence_acquisition">
      <source>Licence acquisition</source>
      <translation variants="no">zh_tw #Licence acquisition</translation>
    </message>
    <message numerus="no" id="txt_drm_info_no_usage_time_to_use_extend_to_use">
      <source>No usage time. Need more!</source>
      <translation variants="no">zh_tw #No usage time. Need more!</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_playing_time_left">
      <source>Playing time left:</source>
      <translation variants="no">zh_tw #Playing time left:</translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_registration">
      <source>Registration for %1</source>
      <translation variants="no">zh_tw #Registration for %1</translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_is_locked_willing_to_use">
      <source>File is locked. Willing to use?</source>
      <translation variants="no">zh_tw #File is locked. Willing to use?</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_sending">
      <source>Sending:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Sending:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_file_1_locked_with_current_sim_card">
      <source>File locked with current SIM card.</source>
      <translation variants="no">zh_tw #File locked with current SIM card.</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_not_received_try_again">
      <source>Licence not received. Would you like to give a try?</source>
      <translation variants="no">zh_tw #Licence not received. Would you like to give a try?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_copy_protected_object_to_me">
      <source>Unable to copy protected objects</source>
      <translation variants="no">zh_tw #Unable to copy protected objects</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_wallpaper_expired">
      <source>Licence for wallpaper expired</source>
      <translation variants="no">zh_tw #Licence for wallpaper expired</translation>
    </message>
    <message numerus="no" id="txt_drm_dblist_licence_aquiring_val_processing">
      <source>Processing….</source>
      <translation variants="no">zh_tw #Processing….</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_deregister_phone">
      <source>Unable to unsubscribe phone</source>
      <translation variants="no">zh_tw #Unable to unsubscribe phone</translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_send_copyright_protected_it">
      <source>Unable to send copyrights protected item</source>
      <translation variants="no">zh_tw #Unable to send copyrights protected item</translation>
    </message>
    <message numerus="no" id="txt_drm_info_updating_service_information">
      <source>Updating </source>
      <translation variants="no">zh_tw #Updating </translation>
    </message>
    <message numerus="no" id="txt_drm_button_activate">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Activate</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_drm_info_registering_phone">
      <source>Registering phone</source>
      <translation variants="no">zh_tw #Registering phone</translation>
    </message>
    <message numerus="no" id="txt_drm_formlabell_automatic">
      <source>Automatic</source>
      <translation variants="no">zh_tw #Automatic</translation>
    </message>
    <message numerus="no" id="txt_drm_formlabel_manual">
      <source>Manual</source>
      <translation variants="no">zh_tw #Manual</translation>
    </message>
    <message numerus="no" id="txt_drm_info_phone_deregistered">
      <source>Phone Unsubscribed</source>
      <translation variants="no">zh_tw #Phone Unsubscribed</translation>
    </message>
    <message numerus="no" id="txt_drm_info_registration_updated">
      <source>Updated Sucessfully</source>
      <translation variants="no">zh_tw #Updated Sucessfully</translation>
    </message>
    <message numerus="no" id="txt_drm_info_delete_drm_protected_file">
      <source>Delete DRM protected file?</source>
      <translation variants="no">zh_tw #Delete DRM protected file?</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_not_yet_received">
      <source> Licence not yet received</source>
      <translation variants="no">zh_tw # Licence not yet received</translation>
    </message>
    <message numerus="no" id="txt_drm_dialog_print_print_rights_until">
      <source>Print: Print rights until </source>
      <translation variants="no">zh_tw #Print: Print rights until </translation>
    </message>
    <message numerus="no" id="txt_drm_info_unable_to_update_registration">
      <source>Unable to update</source>
      <translation variants="no">zh_tw #Unable to update</translation>
    </message>
    <message numerus="no" id="txt_drm_info_licence_for_selected_item_valid_until">
      <source>Licence for selected item valid until %1.</source>
      <translation variants="no">zh_tw #Licence for selected item valid until %1.</translation>
    </message>
  </context>
</TS>