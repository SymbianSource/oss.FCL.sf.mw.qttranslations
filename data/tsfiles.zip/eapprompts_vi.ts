<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dialog_new_eapmschapv2_password">
      <source>New EAP-MSCHAPv2 password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mật khẩu EAP-MSCHAPv2 mới:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mật khẩu lưu trữ PAC:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_title_1_message">
      <source>%1 message:</source>
      <translation variants="no">%[16]1 tin nhắn:</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok_single_dialog">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_eapmschapv2_password_has_expired_yo">
      <source>EAP-MSCHAPv2 password has expired. You must create a new one.</source>
      <translation variants="no">Mật khẩu EAP-MSCHAPv2 đã hết hạn. Tạo mật khẩu mới.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_authenticated_provisioning_in_pro">
      <source>Authenticated provisioning in progress</source>
      <translation variants="no">Đang cung cấp an toàn</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_user_name">
      <source>%1 user name:</source>
      <translation variants="no">Tên người dùng %[40]1:</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_old_eapmschapv2_password">
      <source>Old EAP-MSCHAPv2 password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mật khẩu EAP-MSCHAPv2 cũ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xác minh mật khẩu:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_install_pac_from_server_1">
      <source>Install PAC from server '%1'?</source>
      <translation variants="no">Cài đặt PAC từ máy chủ '%[99]1'?</translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_provisioning_not_successful_reactiv">
      <source>Provisioning not successful. Re-activate provisioning in settings.</source>
      <translation variants="no">Cung cấp không thành công. Kích hoạt lại việc cung cấp trong cài đặt.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_unauthenticated_provisioning_in_p">
      <source>Unauthenticated provisioning in progress</source>
      <translation variants="no">Đang cung cấp không an toàn</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_password">
      <source>Password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mật khẩu:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_create_password_for_encrypted_pac_s">
      <source>Create password for encrypted PAC store:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mật khẩu cho lưu trữ PAC được mã hóa:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_password">
      <source>%1 password:</source>
      <translation variants="no">Mật khẩu %[46]1:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_file_password_for_1">
      <source>PAC file password for '%1':</source>
      <translation variants="no">Mật khẩu tập tin PAC cho '%[33]1':</translation>
    </message>
  </context>
</TS>