<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="tl">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_dblist_repeats_yearly">
      <source>Repeats Yearly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Inuulit nang taunan</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Tanggalin umuulit na tala:</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Itong kaganapan lamang na ito</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_fortnightly">
      <source>Repeats fortnightly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Inuulit bwat dlwang linggo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Paglalarawan:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_select_location_from">
      <source>Select location from search results</source>
      <translation variants="yes">
        <lengthvariant priority="1">Pumili ng lokasyon sa resulta ng pghahanap</lengthvariant>
        <lengthvariant priority="2">tl #Select from search results</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Lahat ng kaganapan</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">Tanggalin ang tala ng gagawin?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_select_location">
      <source>Select location :</source>
      <translation variants="no">Pumili ng lokasyon:</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_subject">
      <source>Subject</source>
      <translation variants="yes">
        <lengthvariant priority="1">Paksa:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_find_location_on_map">
      <source>Find location on map</source>
      <translation variants="yes">
        <lengthvariant priority="1">Maghanap ng lokasyon sa mapa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_monthly">
      <source>Repeats monthly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Inuulit nang buwanan</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hindi pinangalanan</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">Tanggalin ang pulong?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_finding_location_on_m">
      <source>Finding location on map…</source>
      <translation variants="yes">
        <lengthvariant priority="1">Paghanap ng lokasyon sa mapa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_from_1">
      <source>From %1</source>
      <translation variants="no">Simula %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tala ng gagawin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">Markahang di pa tapos</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_workdays">
      <source>Repeats workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">Inuulit kapag may pasok</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_weekly">
      <source>Repeats weekly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Inuulit lingu-linggo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Markahang tapos na</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">I-edit:</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kalendaryo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_location_not_found_on">
      <source>Location not found on map</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hindi natagpuan ang lokasyon sa mapa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event ?</source>
      <translation variants="no">Tanggalin ang tala sa buong-araw?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily">
      <source>Repeats daily</source>
      <translation variants="yes">
        <lengthvariant priority="1">Umuulit araw-araw</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Pulong</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_all_day_event">
      <source>All day event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tala sa buong-araw</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Petsa nang natapos:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_until_1">
      <source>Until %1</source>
      <translation variants="no">Hanggang sa %1</translation>
    </message>
  </context>
</TS>