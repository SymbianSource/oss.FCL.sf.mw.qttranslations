<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_common_button_yes_toolbar">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok_toolbar">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_hide_toolbar">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Hide</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_send_toolbar">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel_toolbar">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_answer_toolbar">
      <source>Answer</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Answer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_opening">
      <source>Opening</source>
      <translation variants="no">正在打开</translation>
    </message>
    <message numerus="no" id="txt_common_title_details">
      <source>Details:</source>
      <translation variants="yes">
        <lengthvariant priority="1">详情：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_undo">
      <source>Undo</source>
      <translation variants="no">撤销</translation>
    </message>
    <message numerus="no" id="txt_common_opt_internet_call">
      <source>Internet call</source>
      <translation variants="no">拨打互联网电话</translation>
    </message>
    <message numerus="no" id="txt_common_opt_go_to_web_address">
      <source>Go to web address</source>
      <translation variants="no">转至网址</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_expires">
      <source>Expires:</source>
      <translation variants="yes">
        <lengthvariant priority="1">到期：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_disconnect">
      <source>Disconnect</source>
      <translation variants="no">断开连接</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">确认</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_unmark">
      <source>Unmark</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消标记</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_define">
      <source>Define</source>
      <translation variants="yes">
        <lengthvariant priority="1">定义</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">关闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_uninstall">
      <source>Uninstall</source>
      <translation variants="no">卸载</translation>
    </message>
    <message numerus="no" id="txt_common_opt_rename_people">
      <source>Rename</source>
      <translation variants="no">重新命名</translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_object">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">启动</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_collapse">
      <source>Collapse</source>
      <translation variants="yes">
        <lengthvariant priority="1">折叠</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_exit">
      <source>Exit</source>
      <translation variants="no">退出</translation>
    </message>
    <message numerus="no" id="txt_common_opt_move">
      <source>Move</source>
      <translation variants="no">移动</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone1">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择铃声：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_web_address">
      <source>Web address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_folder">
      <source>Add to folder</source>
      <translation variants="no">加至文件夹</translation>
    </message>
    <message numerus="no" id="txt_common_opt_move_to_folder">
      <source>Move to folder</source>
      <translation variants="no">移至文件夹</translation>
    </message>
    <message numerus="no" id="txt_common_opt_play_music">
      <source>Play</source>
      <translation variants="no">播放</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">增加详情</translation>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_off">
      <source>Automatic find off</source>
      <translation variants="no">关闭自动查找</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_time">
      <source>Time:</source>
      <translation variants="yes">
        <lengthvariant priority="1">时间：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_bookmark_name">
      <source>Bookmark name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">书签名称：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_connecting">
      <source>Connecting</source>
      <translation variants="no">正在连接</translation>
    </message>
    <message numerus="no" id="txt_common_button_deactivate">
      <source>Deactivate</source>
      <translation variants="yes">
        <lengthvariant priority="1">关闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_preview_audio">
      <source>Preview</source>
      <translation variants="no">预览</translation>
    </message>
    <message numerus="no" id="txt_common_menu_settings">
      <source>Settings</source>
      <translation variants="no">设置</translation>
    </message>
    <message numerus="no" id="txt_common_opt_install">
      <source>Install</source>
      <translation variants="no">安装</translation>
    </message>
    <message numerus="no" id="txt_common_info_copying">
      <source>Copying</source>
      <translation variants="no">正在复制</translation>
    </message>
    <message numerus="no" id="txt_common_menu_preview_video">
      <source>Preview</source>
      <translation variants="no">预览</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_from_contacts">
      <source>Add from Contacts</source>
      <translation variants="no">从名片夹增加</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_folder">
      <source>Select folder:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择文件夹：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_forward">
      <source>Forward</source>
      <translation variants="no">转发</translation>
    </message>
    <message numerus="no" id="txt_common_button_clear">
      <source>Clear</source>
      <translation variants="yes">
        <lengthvariant priority="1">清除</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_insert">
      <source>Insert</source>
      <translation variants="yes">
        <lengthvariant priority="1">插入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_requesting">
      <source>Requesting</source>
      <translation variants="no">正在请求</translation>
    </message>
    <message numerus="no" id="txt_common_menu_install">
      <source>Install</source>
      <translation variants="no">安装</translation>
    </message>
    <message numerus="no" id="txt_common_info_saving">
      <source>Saving</source>
      <translation variants="no">正在储存</translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">是</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_first_name">
      <source>Last name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">姓：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_image">
      <source>Add image</source>
      <translation variants="no">增加图像</translation>
    </message>
    <message numerus="no" id="txt_common_menu_find">
      <source>Find</source>
      <translation variants="no">查找</translation>
    </message>
    <message numerus="no" id="txt_common_opt_print">
      <source>Print</source>
      <translation variants="no">打印</translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate">
      <source>Activate</source>
      <translation variants="no">启动</translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_video">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">预览</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_help">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">用户指南</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_bookmark">
      <source>Add bookmark</source>
      <translation variants="no">另存为书签</translation>
    </message>
    <message numerus="no" id="txt_common_opt_exit">
      <source>Exit</source>
      <translation variants="no">退出</translation>
    </message>
    <message numerus="no" id="txt_common_opt_help">
      <source>Help</source>
      <translation variants="no">用户指南</translation>
    </message>
    <message numerus="no" id="txt_common_button_answer">
      <source>Answer</source>
      <translation variants="yes">
        <lengthvariant priority="1">接听</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_start">
      <source>Start</source>
      <translation variants="yes">
        <lengthvariant priority="1">开始</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_unmute">
      <source>Unmute</source>
      <translation variants="no">取消静音</translation>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_off">
      <source>Automatic find off</source>
      <translation variants="no">关闭自动查找</translation>
    </message>
    <message numerus="no" id="txt_common_menu_replace">
      <source>Replace</source>
      <translation variants="no">替换</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_date">
      <source>Date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">日期：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_connect">
      <source>Connect</source>
      <translation variants="no">连接</translation>
    </message>
    <message numerus="no" id="txt_common_opt_video_call">
      <source>Video call</source>
      <translation variants="no">拨打视频电话</translation>
    </message>
    <message numerus="no" id="txt_common_info_inserting">
      <source>Inserting</source>
      <translation variants="no">正在插入</translation>
    </message>
    <message numerus="no" id="txt_common_info_moving">
      <source>Moving</source>
      <translation variants="no">正在移动</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_address">
      <source>Address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">打开</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_title">
      <source>Title:</source>
      <translation variants="yes">
        <lengthvariant priority="1">标题：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_move_to_folder">
      <source>Move to folder</source>
      <translation variants="no">移至文件夹</translation>
    </message>
    <message numerus="no" id="txt_common_opt_chat">
      <source>Chat</source>
      <translation variants="no">聊天</translation>
    </message>
    <message numerus="no" id="txt_common_opt_additional_details">
      <source>Additional details</source>
      <translation variants="no">更多信息</translation>
    </message>
    <message numerus="no" id="txt_common_title_writing_language">
      <source>Writing language:</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑语言：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_resume">
      <source>Resume</source>
      <translation variants="yes">
        <lengthvariant priority="1">恢复</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_memory">
      <source>Select memory:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择存储：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_voice_call">
      <source>Voice call</source>
      <translation variants="no">拨打语音电话</translation>
    </message>
    <message numerus="no" id="txt_common_opt_call_verb">
      <source>Call</source>
      <translation variants="no">通话</translation>
    </message>
    <message numerus="no" id="txt_common_menu_paste">
      <source>Paste</source>
      <translation variants="no">粘贴</translation>
    </message>
    <message numerus="no" id="txt_common_info_registering">
      <source>Registering</source>
      <translation variants="no">正在注册</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_recipient">
      <source>Add recipient</source>
      <translation variants="no">增加收件人</translation>
    </message>
    <message numerus="no" id="txt_common_menu_enable">
      <source>Enable</source>
      <translation variants="no">启用</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone3">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择铃声：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_address">
      <source>Select address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择地址：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_buffering">
      <source>Buffering</source>
      <translation variants="no">正在缓冲</translation>
    </message>
    <message numerus="no" id="txt_common_button_select">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_hide">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">隐藏</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_cut">
      <source>Cut</source>
      <translation variants="no">剪切</translation>
    </message>
    <message numerus="no" id="txt_common_opt_save">
      <source>Save</source>
      <translation variants="no">储存</translation>
    </message>
    <message numerus="no" id="txt_common_button_reply">
      <source>Reply</source>
      <translation variants="yes">
        <lengthvariant priority="1">回复</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_play_music">
      <source>Play</source>
      <translation variants="no">播放</translation>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_in">
      <source>Zoom in</source>
      <translation variants="no">放大</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name1">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">姓名：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_rename_item">
      <source>Rename</source>
      <translation variants="no">重新命名</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_recipient">
      <source>Add recipient</source>
      <translation variants="no">增加收件人</translation>
    </message>
    <message numerus="no" id="txt_common_menu_cut">
      <source>Cut</source>
      <translation variants="no">剪切</translation>
    </message>
    <message numerus="no" id="txt_common_menu_disable">
      <source>Disable</source>
      <translation variants="no">禁用</translation>
    </message>
    <message numerus="no" id="txt_common_menu_cancel_download">
      <source>Cancel download</source>
      <translation variants="no">取消下载</translation>
    </message>
    <message numerus="no" id="txt_common_button_connect">
      <source>Connect</source>
      <translation variants="yes">
        <lengthvariant priority="1">连接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_out">
      <source>Zoom out</source>
      <translation variants="no">缩小</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_duration">
      <source>Duration:</source>
      <translation variants="yes">
        <lengthvariant priority="1">时段：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_continue">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">继续</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_additional_details">
      <source>Additional details</source>
      <translation variants="no">其他详情</translation>
    </message>
    <message numerus="no" id="txt_common_menu_voice_call">
      <source>Voice call</source>
      <translation variants="no">拨打语音电话</translation>
    </message>
    <message numerus="no" id="txt_common_info_initialising">
      <source>Initialising</source>
      <translation variants="no">正在初始化</translation>
    </message>
    <message numerus="no" id="txt_common_opt_mark">
      <source>Mark</source>
      <translation variants="no">标记</translation>
    </message>
    <message numerus="no" id="txt_common_opt_details">
      <source>Details</source>
      <translation variants="no">详情</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_current_password">
      <source>Current password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">当前密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_insert">
      <source>Insert</source>
      <translation variants="no">插入</translation>
    </message>
    <message numerus="no" id="txt_common_button_reject">
      <source>Reject</source>
      <translation variants="yes">
        <lengthvariant priority="1">拒绝</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_audio">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">预览</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">高级设置</translation>
    </message>
    <message numerus="no" id="txt_common_opt_replace">
      <source>Replace</source>
      <translation variants="no">替换</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_new_password">
      <source>Verify new password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">验证新密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_undo">
      <source>Undo</source>
      <translation variants="no">撤销</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_bookmark">
      <source>Add bookmark</source>
      <translation variants="no">另存为书签</translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_message">
      <source>Send message</source>
      <translation variants="no">发送信息</translation>
    </message>
    <message numerus="no" id="txt_common_menu_internet_call">
      <source>Internet call</source>
      <translation variants="no">拨打互联网电话</translation>
    </message>
    <message numerus="no" id="txt_common_opt_play_video">
      <source>Play</source>
      <translation variants="no">播放</translation>
    </message>
    <message numerus="no" id="txt_common_button_play_audio">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">播放</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_attachments">
      <source>Attachments</source>
      <translation variants="no">附件</translation>
    </message>
    <message numerus="no" id="txt_common_opt_remove">
      <source>Remove</source>
      <translation variants="no">删除</translation>
    </message>
    <message numerus="no" id="txt_common_button_save">
      <source>Save</source>
      <translation variants="yes">
        <lengthvariant priority="1">储存</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_install">
      <source>Install</source>
      <translation variants="yes">
        <lengthvariant priority="1">安装</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_video_call">
      <source>Video call</source>
      <translation variants="no">拨打视频电话</translation>
    </message>
    <message numerus="no" id="txt_common_button_retry">
      <source>Retry</source>
      <translation variants="yes">
        <lengthvariant priority="1">重试</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_to">
      <source>To:</source>
      <translation variants="yes">
        <lengthvariant priority="1">到：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_create_message">
      <source>Create message</source>
      <translation variants="no">写信息</translation>
    </message>
    <message numerus="no" id="txt_common_button_paste">
      <source>Paste</source>
      <translation variants="yes">
        <lengthvariant priority="1">粘贴</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_user_id">
      <source>User ID:</source>
      <translation variants="yes">
        <lengthvariant priority="1">用户识别码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_about_application">
      <source>About application</source>
      <translation variants="no">关于此程序</translation>
    </message>
    <message numerus="no" id="txt_common_menu_remove">
      <source>Remove</source>
      <translation variants="no">删除</translation>
    </message>
    <message numerus="no" id="txt_common_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">断开连接</translation>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate">
      <source>Deactivate</source>
      <translation variants="no">关闭</translation>
    </message>
    <message numerus="no" id="txt_common_opt_edit">
      <source>Edit</source>
      <translation variants="no">编辑</translation>
    </message>
    <message numerus="no" id="txt_common_menu_continue">
      <source>Continue</source>
      <translation variants="no">继续</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_thumbnail">
      <source>Add thumbnail</source>
      <translation variants="no">增加微缩图像</translation>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_in">
      <source>Zoom in</source>
      <translation variants="no">放大</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_image">
      <source>Add image</source>
      <translation variants="no">增加图像</translation>
    </message>
    <message numerus="no" id="txt_common_opt_fit_to_screen">
      <source>Fit to screen</source>
      <translation variants="no">适合屏幕大小</translation>
    </message>
    <message numerus="no" id="txt_common_button_unmute">
      <source>Unmute</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消静音</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_file_name">
      <source>File name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">文件名：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_forward">
      <source>Forward</source>
      <translation variants="no">转发</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_detail">
      <source>Add detail</source>
      <translation variants="no">增加详情</translation>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">关闭扬声器</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_folder">
      <source>Add to folder</source>
      <translation variants="no">加至文件夹</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="no">加至名片夹</translation>
    </message>
    <message numerus="no" id="txt_common_opt_call_noun">
      <source>Call</source>
      <translation variants="no">通话</translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmark">
      <source>Unmark</source>
      <translation variants="no">取消标记</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_phone_number">
      <source>Phone number:</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机号码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_go_to_web_address">
      <source>Go to web address</source>
      <translation variants="no">转至网址</translation>
    </message>
    <message numerus="no" id="txt_common_button_show">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">显示</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_copy_to_folder">
      <source>Copy to folder</source>
      <translation variants="no">复制至文件夹</translation>
    </message>
    <message numerus="no" id="txt_common_menu_chat">
      <source>Chat</source>
      <translation variants="no">聊天</translation>
    </message>
    <message numerus="no" id="txt_common_button_handset">
      <source>Handset</source>
      <translation variants="yes">
        <lengthvariant priority="1">启动手机听筒</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate">
      <source>Activate</source>
      <translation variants="no">启动</translation>
    </message>
    <message numerus="no" id="txt_common_menu_unmark">
      <source>Unmark</source>
      <translation variants="no">取消标记</translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate_handsfree">
      <source>Activate handset</source>
      <translation variants="no">启动手机听筒</translation>
    </message>
    <message numerus="no" id="txt_common_button_record_video">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">录制</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_join">
      <source>Join</source>
      <translation variants="yes">
        <lengthvariant priority="1">加入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_mute">
      <source>Mute</source>
      <translation variants="yes">
        <lengthvariant priority="1">静音</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_pause">
      <source>Pause</source>
      <translation variants="no">暂停</translation>
    </message>
    <message numerus="no" id="txt_common_info_closing">
      <source>Closing</source>
      <translation variants="no">正在关闭</translation>
    </message>
    <message numerus="no" id="txt_common_menu_connect">
      <source>Connect</source>
      <translation variants="no">连接</translation>
    </message>
    <message numerus="no" id="txt_common_menu_play_video">
      <source>Play</source>
      <translation variants="no">播放</translation>
    </message>
    <message numerus="no" id="txt_common_menu_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">存至名片夹</translation>
    </message>
    <message numerus="no" id="txt_common_button_copy">
      <source>Copy</source>
      <translation variants="yes">
        <lengthvariant priority="1">复制</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_cancelling">
      <source>Cancelling</source>
      <translation variants="no">正在取消</translation>
    </message>
    <message numerus="no" id="txt_common_button_play_video">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">播放</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_read">
      <source>Read</source>
      <translation variants="yes">
        <lengthvariant priority="1">阅读</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">删除</translation>
    </message>
    <message numerus="no" id="txt_common_button_options">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">选项</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_language">
      <source>Select language:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择语言：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">启动扬声器</translation>
    </message>
    <message numerus="no" id="txt_common_button_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">重设</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_pause">
      <source>Pause</source>
      <translation variants="yes">
        <lengthvariant priority="1">暂停</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_password">
      <source>Password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_select">
      <source>Select</source>
      <translation variants="no">选择</translation>
    </message>
    <message numerus="no" id="txt_common_button_quit">
      <source>Quit</source>
      <translation variants="yes">
        <lengthvariant priority="1">退出</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_insert">
      <source>Insert</source>
      <translation variants="no">插入</translation>
    </message>
    <message numerus="no" id="txt_common_menu_copy">
      <source>Copy</source>
      <translation variants="no">复制</translation>
    </message>
    <message numerus="no" id="txt_common_opt_copy_to_folder">
      <source>Copy to folder</source>
      <translation variants="no">复制至文件夹</translation>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate">
      <source>Deactivate</source>
      <translation variants="no">关闭</translation>
    </message>
    <message numerus="no" id="txt_common_opt_enable">
      <source>Enable</source>
      <translation variants="no">启用</translation>
    </message>
    <message numerus="no" id="txt_common_info_adding">
      <source>Adding</source>
      <translation variants="no">正在增加</translation>
    </message>
    <message numerus="no" id="txt_common_menu_call_noun">
      <source>Call</source>
      <translation variants="no">通话</translation>
    </message>
    <message numerus="no" id="txt_common_info_disconnecting">
      <source>Disconnecting</source>
      <translation variants="no">正在断开连接</translation>
    </message>
    <message numerus="no" id="txt_common_menu_uninstall">
      <source>Uninstall</source>
      <translation variants="no">卸载</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_file">
      <source>Select file:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择文件：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_rename_people">
      <source>Rename</source>
      <translation variants="no">重新命名</translation>
    </message>
    <message numerus="no" id="txt_common_button_call">
      <source>Call</source>
      <translation variants="yes">
        <lengthvariant priority="1">通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_out">
      <source>Zoom out</source>
      <translation variants="no">缩小</translation>
    </message>
    <message numerus="no" id="txt_common_menu_create_message">
      <source>Create message</source>
      <translation variants="no">写信息</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_folder_name">
      <source>Folder name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">文件夹名称：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmute">
      <source>Unmute</source>
      <translation variants="no">取消静音</translation>
    </message>
    <message numerus="no" id="txt_common_opt_disable">
      <source>Disable</source>
      <translation variants="no">禁用</translation>
    </message>
    <message numerus="no" id="txt_common_opt_cancel_download">
      <source>Cancel download</source>
      <translation variants="no">取消下载</translation>
    </message>
    <message numerus="no" id="txt_common_info_searching">
      <source>Searching</source>
      <translation variants="no">正在搜索</translation>
    </message>
    <message numerus="no" id="txt_common_button_back">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">返回</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_user_name">
      <source>User name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">用户名：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">高级设置</translation>
    </message>
    <message numerus="no" id="txt_common_menu_call_verb">
      <source>Call</source>
      <translation variants="no">通话</translation>
    </message>
    <message numerus="no" id="txt_common_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">启动扬声器</translation>
    </message>
    <message numerus="no" id="txt_common_menu_organise">
      <source>Organise</source>
      <translation variants="no">整理</translation>
    </message>
    <message numerus="no" id="txt_common_opt_change">
      <source>Change</source>
      <translation variants="no">更改</translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate_handsfree">
      <source>Activate handset</source>
      <translation variants="no">启动手机听筒</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_member">
      <source>Add member</source>
      <translation variants="no">增加成员</translation>
    </message>
    <message numerus="no" id="txt_common_opt_preview_video">
      <source>Preview</source>
      <translation variants="no">预览</translation>
    </message>
    <message numerus="no" id="txt_common_title_web_address">
      <source>Web address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择网址：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name2">
      <source>New name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">新名称：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_find">
      <source>Find</source>
      <translation variants="no">查找</translation>
    </message>
    <message numerus="no" id="txt_common_info_removing">
      <source>Removing</source>
      <translation variants="no">正在删除</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_member">
      <source>Add member</source>
      <translation variants="no">增加成员</translation>
    </message>
    <message numerus="no" id="txt_common_button_change">
      <source>Change</source>
      <translation variants="yes">
        <lengthvariant priority="1">更改</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from">
      <source>From:</source>
      <translation variants="yes">
        <lengthvariant priority="1">从：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_listen">
      <source>Listen</source>
      <translation variants="yes">
        <lengthvariant priority="1">接听</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_reject_toolbar">
      <source>Reject</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Reject</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_fit_to_screen">
      <source>Fit to screen</source>
      <translation variants="no">适合屏幕大小</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_password">
      <source>New password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">新密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_on">
      <source>Automatic find on</source>
      <translation variants="no">打开自动查找</translation>
    </message>
    <message numerus="no" id="txt_common_button_add">
      <source>Add</source>
      <translation variants="yes">
        <lengthvariant priority="1">增加</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_stop">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">停止</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_copy">
      <source>Copy</source>
      <translation variants="no">复制</translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_process">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">启动</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_installing">
      <source>Installing</source>
      <translation variants="no">正在安装</translation>
    </message>
    <message numerus="no" id="txt_common_opt_back">
      <source>Back</source>
      <translation variants="no">返回</translation>
    </message>
    <message numerus="no" id="txt_common_button_expand">
      <source>Expand</source>
      <translation variants="yes">
        <lengthvariant priority="1">展开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_open">
      <source>Open</source>
      <translation variants="yes">
        <lengthvariant priority="1">打开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name2">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">名称：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_edit">
      <source>Edit</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_enable">
      <source>Enable</source>
      <translation variants="yes">
        <lengthvariant priority="1">启用</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_organise">
      <source>Organise</source>
      <translation variants="no">整理</translation>
    </message>
    <message numerus="no" id="txt_common_opt_open">
      <source>Open</source>
      <translation variants="no">打开</translation>
    </message>
    <message numerus="no" id="txt_common_button_finish">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">完成</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_retrieving">
      <source>Retrieving</source>
      <translation variants="no">正在提取</translation>
    </message>
    <message numerus="no" id="txt_common_info_deleting">
      <source>Deleting</source>
      <translation variants="no">正在删除</translation>
    </message>
    <message numerus="no" id="txt_common_button_replace">
      <source>Replace</source>
      <translation variants="yes">
        <lengthvariant priority="1">替换</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_attachments">
      <source>Attachments</source>
      <translation variants="no">附件</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_thumbnail">
      <source>Add thumbnail</source>
      <translation variants="no">增加微缩图像</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="no">存至名片夹</translation>
    </message>
    <message numerus="no" id="txt_common_menu_details">
      <source>Details</source>
      <translation variants="no">详情</translation>
    </message>
    <message numerus="no" id="txt_common_button_find">
      <source>Find</source>
      <translation variants="yes">
        <lengthvariant priority="1">查找</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name1">
      <source>New name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">新名字：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_no_toolbar">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_menu">
      <source>Menu</source>
      <translation variants="yes">
        <lengthvariant priority="1">功能表</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">关闭扬声器</translation>
    </message>
    <message numerus="no" id="txt_common_opt_pause">
      <source>Pause</source>
      <translation variants="no">暂停</translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_item">
      <source>Send</source>
      <translation variants="no">发送</translation>
    </message>
    <message numerus="no" id="txt_common_opt_continue">
      <source>Continue</source>
      <translation variants="no">继续</translation>
    </message>
    <message numerus="no" id="txt_common_button_delete_toolbar">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_uninstall">
      <source>Uninstall</source>
      <translation variants="yes">
        <lengthvariant priority="1">卸载</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_message">
      <source>Send message</source>
      <translation variants="no">发送信息</translation>
    </message>
    <message numerus="no" id="txt_common_opt_settings">
      <source>Settings</source>
      <translation variants="no">设置</translation>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_on">
      <source>Automatic find on</source>
      <translation variants="no">打开自动查找</translation>
    </message>
    <message numerus="no" id="txt_common_info_processing">
      <source>Processing</source>
      <translation variants="no">正在处理</translation>
    </message>
    <message numerus="no" id="txt_common_menu_save">
      <source>Save</source>
      <translation variants="no">储存</translation>
    </message>
    <message numerus="no" id="txt_common_button_disconnect">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">断开连接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone2">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择铃声：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_on">
      <source>Loudsp. on</source>
      <translation variants="yes">
        <lengthvariant priority="1">打开扬声器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_about_application">
      <source>About application</source>
      <translation variants="no">关于此程序</translation>
    </message>
    <message numerus="no" id="txt_common_menu_edit">
      <source>Edit</source>
      <translation variants="no">编辑</translation>
    </message>
    <message numerus="no" id="txt_common_menu_move">
      <source>Move</source>
      <translation variants="no">移动</translation>
    </message>
    <message numerus="no" id="txt_common_opt_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">存至名片夹</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_from_contacts">
      <source>Add from Contacts</source>
      <translation variants="no">从名片夹增加</translation>
    </message>
    <message numerus="no" id="txt_common_menu_mark">
      <source>Mark</source>
      <translation variants="no">标记</translation>
    </message>
    <message numerus="no" id="txt_common_button_record_audio">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">录音</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_mark">
      <source>Mark</source>
      <translation variants="yes">
        <lengthvariant priority="1">标记</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">验证密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_rename_item">
      <source>Rename</source>
      <translation variants="no">重新命名</translation>
    </message>
    <message numerus="no" id="txt_common_opt_select">
      <source>Select</source>
      <translation variants="no">选择</translation>
    </message>
    <message numerus="no" id="txt_common_menu_preview_audio">
      <source>Preview</source>
      <translation variants="no">预览</translation>
    </message>
    <message numerus="no" id="txt_common_button_remove">
      <source>Remove</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_loading">
      <source>Loading</source>
      <translation variants="no">正在加载</translation>
    </message>
    <message numerus="no" id="txt_common_opt_delete">
      <source>Delete</source>
      <translation variants="no">删除</translation>
    </message>
    <message numerus="no" id="txt_common_button_exit">
      <source>Exit</source>
      <translation variants="yes">
        <lengthvariant priority="1">退出</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_clear_toolbar">
      <source>Clear</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Clear</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_move">
      <source>Move</source>
      <translation variants="yes">
        <lengthvariant priority="1">移动</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_paste">
      <source>Paste</source>
      <translation variants="no">粘贴</translation>
    </message>
    <message numerus="no" id="txt_common_menu_print">
      <source>Print</source>
      <translation variants="no">打印</translation>
    </message>
    <message numerus="no" id="txt_common_info_unistalling">
      <source>Uninstalling</source>
      <translation variants="no">正在卸载</translation>
    </message>
    <message numerus="no" id="txt_common_button_disable">
      <source>Disable</source>
      <translation variants="yes">
        <lengthvariant priority="1">禁用</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_item">
      <source>Send</source>
      <translation variants="no">发送</translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_off">
      <source>Loudsp. off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关闭扬声器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_end_date">
      <source>End date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">结束日期：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_change">
      <source>Change</source>
      <translation variants="no">更改</translation>
    </message>
  </context>
</TS>