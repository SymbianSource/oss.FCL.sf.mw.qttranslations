<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_inst_info_error_attr_mismatch">
      <source>Attritbute %1 is different in JAD and JAR files.</source>
      <translation variants="no">属性"%[98]1"在JAD文件和JAR文件中不同。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_uninst_unexpected">
      <source>Unable to uninstall. Unexpected error.</source>
      <translation variants="no">无法删除软件。意外错误。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_push_reg">
      <source>Push registration failed.</source>
      <translation variants="no">注册失败。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_pkg_misuse">
      <source>Package %1 is protected and can not be used.</source>
      <translation variants="no">程序"%[98]1"受保护，无法使用。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_bad_syntax">
      <source>Attribute %1 has bad syntax.</source>
      <translation variants="no">无效属性"%[98]1"。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_unsupported_value">
      <source>Attribute %1 has unsupported value.</source>
      <translation variants="no">属性"%[98]1"的值无效。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_cancel">
      <source>Installation cancelled.</source>
      <translation variants="no">安装已取消。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_authentication">
      <source>Application authentication failed.</source>
      <translation variants="no">应用程序鉴定失败。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_handling_failed">
      <source>Attribute %1 handling failed.</source>
      <translation variants="no">属性"%[98]1"处理失败。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_uninst_cancel">
      <source>Uninstallation cancelled.</source>
      <translation variants="no">软件删除已取消。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_internal_error">
      <source>Internal error: %1</source>
      <translation variants="no">内部错误：
%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_mem_detail">
      <source>Application requires %L1 kB of memory. You have to remove other applications or data from the device to install the application</source>
      <translation variants="no">存储不足。应用程序需要%L1 kB。删除一些其他应用程序或数据后再试。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_missing">
      <source>Mandatory attribute %1 is missing.</source>
      <translation variants="no">缺少强制属性"%[98]1"。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_different_signers">
      <source>The signers of the update and the already installed applications do not match.</source>
      <translation variants="no">用来签名更新的证书不同于当前安装的应用程序的证书。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_cert_unsupported">
      <source>Application has been signed with a certificate that is not supported in this device.</source>
      <translation variants="no">应用程序已使用不受此设备支持的证书签名。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_mem_detail_mb">
      <source>Application requires %L1 MB of memory. You have to remove other applications or data from the device to install the application</source>
      <translation variants="no">存储不足。应用程序需要%L1 MB。删除一些其他应用程序或数据后再试。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_net_detail">
      <source>Cannot download installation package from URL %1.</source>
      <translation variants="no">无法从以下网址下载安装包：
%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_authorization">
      <source>Application authorization failed.</source>
      <translation variants="no">应用程序授权失败。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_uninst_blocked">
      <source>Uninstallation is blocked by an attribute in application.</source>
      <translation variants="no">软件删除已被应用程序中的一个属性阻止。</translation>
    </message>
  </context>
</TS>