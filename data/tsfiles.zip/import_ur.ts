<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_ftu_list_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">ur #Bookmarks</translation>
    </message>
    <message numerus="no" id="txt_ftu_dblist_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Music</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_list_landnmarks">
      <source>Landmarks</source>
      <translation variants="no">ur #Landmarks</translation>
    </message>
    <message numerus="no" id="txt_Import_p_dblist_import_data_1">
      <source>Import Data -%1</source>
      <translation variants="no">ur #Import Data -%1</translation>
    </message>
    <message numerus="no" id="txt_import_dblist_music_val_importing_l1_of_l2">
      <source>Importing %L1 of %L2</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Importing %L1 of %L2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_list_notes">
      <source>Notes</source>
      <translation variants="no">ur #Notes</translation>
    </message>
    <message numerus="no" id="txt_ftu_list_photos">
      <source>Photos</source>
      <translation variants="no">ur #Photos</translation>
    </message>
    <message numerus="no" id="txt_import_p_info_erroneous_occurred">
      <source>Import was unsuccesful:</source>
      <translation variants="no">ur #Import was unsuccesful:</translation>
    </message>
    <message numerus="no" id="txt_ftu_list_music">
      <source>Music</source>
      <translation variants="no">ur #Music</translation>
    </message>
    <message numerus="no" id="txt_ftu_subhead_ready_to_import_data_from_1">
      <source>Import data from %1</source>
      <translation variants="no">ur #Import data from %1</translation>
    </message>
    <message numerus="no" id="txt_ftu_list_contacts">
      <source>Contacts</source>
      <translation variants="no">ur #Contacts</translation>
    </message>
    <message numerus="no" id="txt_import_p_dpopinfo_complete">
      <source>complete</source>
      <translation variants="no">ur #complete</translation>
    </message>
    <message numerus="no" id="txt_Import_p_dpophead_import_data_1">
      <source>Import data- %1</source>
      <translation variants="no">ur #Import data- %1</translation>
    </message>
    <message numerus="no" id="txt_ftu_list_videos">
      <source>Videos</source>
      <translation variants="no">ur #Videos</translation>
    </message>
    <message numerus="yes" id="txt_import_dblist_videos_val_ln_entries_imported">
      <source>%Ln entries imported</source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_import_p_dblist_contacts_val_in_progress">
      <source>In progress..</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #In progress..</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_import_dblist_contacts_val_ln_entries_imported">
      <source>%Ln entries imported</source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_list_calendars">
      <source>Calendars</source>
      <translation variants="no">ur #Calendars</translation>
    </message>
    <message numerus="no" id="txt_import_dblist_calendars_val_importing_l1_of">
      <source>Importing %L1 of %L2</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Importing %L1 of %L2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_import_data">
      <source>Import Data</source>
      <translation variants="no">ur #Import Data</translation>
    </message>
    <message numerus="no" id="txt_import_p_title_import_data_from_matt_n95">
      <source>Import data from %1</source>
      <translation variants="no">ur #Import data from %1</translation>
    </message>
    <message numerus="no" id="txt_import_tile_import_data">
      <source>Import Data</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Import Data</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_import_dblist_val_imported_from_1">
      <source>Imported from %1</source>
      <translation variants="no">ur #Imported from %1</translation>
    </message>
    <message numerus="no" id="txt_import_p_info_bluetooth_connection_failed">
      <source>Bluetooth Connection failed</source>
      <translation variants="no">ur #Bluetooth Connection failed</translation>
    </message>
    <message numerus="no" id="txt_import_dblist_contacts_val_wating">
      <source>Waiting</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Waiting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_dblist_videos">
      <source>Videos</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Videos</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_dblist_messages">
      <source>Messages</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Messages</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_button_finish">
      <source>Done</source>
      <translation variants="no">ur #Done</translation>
    </message>
    <message numerus="no" id="txt_import_dblist_photos_val_importing_l1_of_l2">
      <source>Importing %L1 of %L2</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Importing %L1 of %L2</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_import_dblist_recent_calls_val_ln_entries_im">
      <source>%Ln entries imported</source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_import_dblist_contacts_val_not_imported_cont">
      <source>Error! content is blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Error! content is blocked</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_import_data_list_import_data">
      <source>Import Data</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Import Data</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_import_dblist_recent_calls_val_importing_l1_o">
      <source>Importing %L1 of %L2</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Importing %L1 of %L2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_dblist_photos">
      <source>Photos</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Photos</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_import_dblist_photos_val_ln_entries_imported">
      <source>%Ln entries imported</source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_button_start_import">
      <source>continue</source>
      <translation variants="no">ur #continue</translation>
    </message>
    <message numerus="no" id="txt_import_dblist_messages_val_importing_l1_of_l">
      <source>Importing %L1 of %L2</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Importing %L1 of %L2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_list_personalized_settings">
      <source>Personalized Settings</source>
      <translation variants="no">ur #Personalized Settings</translation>
    </message>
    <message numerus="yes" id="txt_import_dblist_messages_val_ln_entries_import">
      <source>%Ln entries imported</source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_dblist_calendars">
      <source>Calendars</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Calendars</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_import_dblist_music_val_ln_entries_imported">
      <source>%Ln entries imported</source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_import_dblist_calendars_val_ln_entries_impor">
      <source>%Ln entries imported</source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_dblist_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Contacts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_dblist_recent_calls">
      <source>Recent calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Recent calls</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_list_recent_calls">
      <source>Recent Calls</source>
      <translation variants="no">ur #Recent Calls</translation>
    </message>
    <message numerus="no" id="txt_ftu_list_messages">
      <source>Messages</source>
      <translation variants="no">ur #Messages</translation>
    </message>
    <message numerus="no" id="txt_import_dblist_val_importing_from_1">
      <source>Importing from %1</source>
      <translation variants="no">ur #Importing from %1</translation>
    </message>
    <message numerus="no" id="txt_import_dblist_videos_val_importing_l1_of_l2">
      <source>Importing %L1 of %L2</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Importing %L1 of %L2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ftu_button_stop_importing">
      <source>Stop importing</source>
      <translation variants="no">ur #Stop importing</translation>
    </message>
    <message numerus="no" id="txt_import_dblist_contacts_val_importing_l1_of_l">
      <source>Importing %L1 of %L2</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Importing %L1 of %L2</lengthvariant>
      </translation>
    </message>
  </context>
</TS>