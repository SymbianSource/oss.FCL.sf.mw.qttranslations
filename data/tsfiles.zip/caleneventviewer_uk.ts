<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_list_reminder_time_date">
      <source>%1 %2</source>
      <translation variants="no">uk #%[23]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_fortnightly">
      <source>Repeats fortnightly</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Repeats fortnightly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_subject">
      <source>Subject:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Subject:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Delete repeated entry :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_meeting_date">
      <source>%1</source>
      <translation variants="no">uk #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_anniversary">
      <source>Anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Anniversary</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_until_1">
      <source>Until %1</source>
      <translation variants="no">uk #Until %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_monthly">
      <source>Repeats monthly</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Repeats monthly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_workdays">
      <source>Repeats workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Repeats on workdays</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_delete">
      <source>Delete</source>
      <translation variants="no">uk #Delete</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_start_time_date">
      <source>%1 %2</source>
      <translation variants="no">uk #%[23]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Delete anniversary?</source>
      <translation variants="no">uk #Delete anniversary?</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_reminder_time">
      <source>%1</source>
      <translation variants="no">uk #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_weekly">
      <source>Repeats weekly</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Repeats weekly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_from_1">
      <source>From %1</source>
      <translation variants="no">uk #From %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily">
      <source>Repeats daily</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Repeats daily</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Description:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Edit :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">uk #All occurences</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_event">
      <source>Event</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Entry</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_occasion">
      <source>Occasion:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Occasion:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_edit">
      <source>Edit</source>
      <translation variants="no">uk #Edit</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Unnamed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">uk #Delete meeting?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Completed date:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">uk #Mark as done</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #To-do note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_send">
      <source>Send</source>
      <translation variants="no">uk #Send</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_save_to_calendar">
      <source>Save to calendar</source>
      <translation variants="no">uk #Save to Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Meeting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">uk #Delete to-do note?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_end_time_date">
      <source>- %1 %2</source>
      <translation variants="no">uk #- %[98]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">uk #Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_start_end_time">
      <source>%1 - %2</source>
      <translation variants="no">uk #%[22]1 - %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">uk #This occurrence only</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_yearly">
      <source>Repeats Yearly</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Repeats yearly</lengthvariant>
      </translation>
    </message>
  </context>
</TS>