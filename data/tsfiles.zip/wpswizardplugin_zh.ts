<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dialog_first_press_button_on_the_wireless">
      <source>First, press button on the wireless station to initiate the setup process, then select 'Next'.</source>
      <translation variants="no">首先，按无线频道上的按钮来启动设置过程，然后选择"下一步"。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_settings_received_for_multiple_wlan">
      <source>Settings received for multiple WLAN networks. Select the network to use:</source>
      <translation variants="no">收到多个WLAN网络的设置。选择要使用的网络：</translation>
    </message>
    <message numerus="no" id="txt_occ_list_configure_manually">
      <source>Configure manually</source>
      <translation variants="no">手动定义</translation>
    </message>
    <message numerus="no" id="txt_occ_list_use_pushbutton">
      <source>Use push-button</source>
      <translation variants="no">使用按钮</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_negotiating">
      <source>Negotiating</source>
      <translation variants="no">正在检查设置</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_selected_network_supports_wifi_pro">
      <source>Selected network supports Wi-Fi Protected Setup™ for receiving settings automatically.</source>
      <translation variants="no">选择的网络支持Wi-Fi保护设置自动接收设置。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_enter_1_on_the_wireless_station_t">
      <source>Enter '%1' on the wireless station then select 'Next'.</source>
      <translation variants="no">在无线频道上输入"%[38]1"，然后选择"下一步"。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_configuration_failed_please_try_ag">
      <source>Configuration failed. Please try again.</source>
      <translation variants="no">配置失败。重试。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_configuration_failed_authenticatio">
      <source>Configuration failed. Authentication unsuccessful.</source>
      <translation variants="no">配置失败。鉴定未成功。</translation>
    </message>
    <message numerus="no" id="txt_occ_list_use_pin_code">
      <source>Use PIN code</source>
      <translation variants="no">使用PIN代码</translation>
    </message>
  </context>
</TS>