<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_formlabel_city_name">
      <source>City name</source>
      <translation variants="yes">
        <lengthvariant priority="1">城市名称</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_country">
      <source>Country</source>
      <translation variants="yes">
        <lengthvariant priority="1">国家或地区</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_city_list">
      <source>City list</source>
      <translation variants="yes">
        <lengthvariant priority="1">城市列表</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_opt_add_own_city">
      <source>Add own city</source>
      <translation variants="no">添加自己的城市</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_timezone">
      <source>Timezone</source>
      <translation variants="yes">
        <lengthvariant priority="1">时区</lengthvariant>
      </translation>
    </message>
  </context>
</TS>