<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_applib_subtitle_office">
      <source>Office</source>
      <translation variants="yes">
        <lengthvariant priority="1">Văn phòng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_games">
      <source>Games</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trò chơi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_downloads">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tải về</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_essentials">
      <source>Essentials</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Essentials</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_essentials">
      <source>Essentials</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Essentials</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_office">
      <source>Office</source>
      <translation variants="yes">
        <lengthvariant priority="1">Văn phòng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_games">
      <source>Games</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trò chơi</lengthvariant>
      </translation>
    </message>
  </context>
</TS>