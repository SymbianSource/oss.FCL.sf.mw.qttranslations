<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_connection_name_val_connection">
      <source>Connection</source>
      <translation variants="no">接入点</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_intranet">
      <source>Intranet</source>
      <translation variants="yes">
        <lengthvariant priority="1">内部网</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_operator_services">
      <source>Operator services</source>
      <translation variants="yes">
        <lengthvariant priority="1">运营商服务</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_internet">
      <source>Internet</source>
      <translation variants="yes">
        <lengthvariant priority="1">互联网</lengthvariant>
      </translation>
    </message>
  </context>
</TS>