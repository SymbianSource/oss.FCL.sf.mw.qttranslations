<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_videos_title_videos">
      <source>Videos</source>
      <translation variants="yes">
        <lengthvariant priority="1">短片庫</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_subtitle_recently_watched">
      <source>Recently watched</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近觀賞的短片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_menu_remove_collection">
      <source>Remove collection</source>
      <translation variants="no">移除收藏集</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_name">
      <source>Name</source>
      <translation variants="no">名稱</translation>
    </message>
    <message numerus="no" id="txt_videos_list_duration">
      <source>Duration:</source>
      <translation variants="yes">
        <lengthvariant priority="1">時間：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sub_date">
      <source>Date</source>
      <translation variants="no">日期</translation>
    </message>
    <message numerus="no" id="txt_videos_subtitle_downloaded_l1">
      <source>Downloaded (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">已下載(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_keywords">
      <source>Keywords:</source>
      <translation variants="yes">
        <lengthvariant priority="1">標籤：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_collection_name">
      <source>Collection name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏集名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_menu_share">
      <source>Share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_videos_list_location">
      <source>Location:</source>
      <translation variants="yes">
        <lengthvariant priority="1">方位：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_rating">
      <source>Rating</source>
      <translation variants="no">喜好程度</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_total_length">
      <source>Total length</source>
      <translation variants="no">總長度</translation>
    </message>
    <message numerus="no" id="txt_videos_menu_add_to_collection">
      <source>Add to collection</source>
      <translation variants="no">加入至收藏集</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_add_to_collection">
      <source>Add to collection</source>
      <translation variants="no">加入至收藏集</translation>
    </message>
    <message numerus="no" id="txt_videos_info_no_video">
      <source>(No video)</source>
      <translation variants="no">(沒有短片)</translation>
    </message>
    <message numerus="no" id="txt_videos_info_no_videos">
      <source>(No videos)</source>
      <translation variants="no">(沒有短片)</translation>
    </message>
    <message numerus="no" id="txt_videos_info_to_get_videos_visit_ovi_store">
      <source>To get videos, visit OVI store.</source>
      <translation variants="no">若要獲取短片，請前往商店。</translation>
    </message>
    <message numerus="no" id="txt_videos_list_copyright">
      <source>Copyright:</source>
      <translation variants="yes">
        <lengthvariant priority="1">版權：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_drm">
      <source>DRM</source>
      <translation variants="yes">
        <lengthvariant priority="1">DRM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_subtitle_1_l2">
      <source>%1 (%L2)</source>
      <translation variants="no">%[27]1 (%L2)</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_recently_watched">
      <source>Recently watched</source>
      <translation variants="no">最近觀賞的項目</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_remove_videos">
      <source>Remove videos…</source>
      <translation variants="no">移除短片</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_downloaded">
      <source>Downloaded</source>
      <translation variants="yes">
        <lengthvariant priority="1">下載的短片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_format">
      <source>Format:</source>
      <translation variants="yes">
        <lengthvariant priority="1">格式：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_size">
      <source>Size</source>
      <translation variants="no">大小</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_recently_watched">
      <source>Recently watched</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近觀賞的項目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by">
      <source>Sort by</source>
      <translation variants="no">排序依據</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_share">
      <source>Share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_videos_list_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">內容說明：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_language">
      <source>Language:</source>
      <translation variants="yes">
        <lengthvariant priority="1">語言：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_menu_remove_from_collection">
      <source>Remove from collection</source>
      <translation variants="no">從收藏集移除</translation>
    </message>
    <message numerus="no" id="txt_long_caption_videos">
      <source>Videos</source>
      <translation variants="no">短片庫</translation>
    </message>
    <message numerus="no" id="txt_videos_list_file_size">
      <source>File Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">檔案大小：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_resolution">
      <source>Resolution:</source>
      <translation variants="yes">
        <lengthvariant priority="1">解像度：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured">
      <source>Captured</source>
      <translation variants="yes">
        <lengthvariant priority="1">拍攝的短片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_bitrate">
      <source>Bitrate:</source>
      <translation variants="yes">
        <lengthvariant priority="1">位元速率：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_modified">
      <source>Modified:</source>
      <translation variants="yes">
        <lengthvariant priority="1">修改時間：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_kbps">
      <source>%L1 kbps</source>
      <translation variants="no">%L1 kbps</translation>
    </message>
    <message numerus="no" id="txt_videos_button_new">
      <source>New collection</source>
      <translation variants="yes">
        <lengthvariant priority="1">新收藏集</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_title">
      <source>Title:</source>
      <translation variants="yes">
        <lengthvariant priority="1">標題：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_do_you_want_to_delete_1">
      <source>Do you want to delete %1?</source>
      <translation variants="no">是否刪除%[45]1？</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_connect">
      <source>Unable to connect</source>
      <translation variants="no">無法連接</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_videos">
      <source>Videos</source>
      <translation variants="yes">
        <lengthvariant priority="1">短片庫</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_all_videos_already_added_to_this_c">
      <source>All videos already added to this collection.</source>
      <translation variants="no">所有短片都已加入至此收藏集</translation>
    </message>
    <message numerus="no" id="txt_videos_setlabel_mark_all">
      <source>Mark all</source>
      <translation variants="no">全部標記</translation>
    </message>
    <message numerus="no" id="txt_videos_info_license_has_expired_or_it_is_missi">
      <source>License has expired or it is missing</source>
      <translation variants="no">授權已逾期或遺失</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_delete_1_it_is_current">
      <source>Do you want to delete %1?</source>
      <translation variants="no">無法刪除。檔案"%[39]1"為開啟。</translation>
    </message>
    <message numerus="yes" id="txt_videos_dblist_val_ln_videos">
      <source>%Ln videos</source>
      <translation>
        <numerusform plurality="a">%Ln段短片</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_video_play_not_allowed_during_voic">
      <source>Video play not allowed during voice call over 2G network</source>
      <translation variants="no">在2G網絡中進行語音通話時無法播放短片</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_connect_invalid_url">
      <source>Unable to connect: Invalid URL</source>
      <translation variants="no">無法連接至伺服器。網址無效。</translation>
    </message>
    <message numerus="no" id="txt_videos_list_belongs_to_collections">
      <source>Belongs to collections:</source>
      <translation variants="yes">
        <lengthvariant priority="1">屬於收藏集：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_gb">
      <source>%L1 GB</source>
      <translation variants="no">%L1 GB</translation>
    </message>
    <message numerus="no" id="txt_videos_info_do_you_want_to_remove_collection">
      <source>Do you want to remove collection %1?</source>
      <translation variants="no">是否移除收藏集%[42]1？</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_connect_file_not_found">
      <source>Unable to connect: File not found</source>
      <translation variants="no">無法連接至伺服器。找不到檔案。</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1_l2_gb">
      <source>%L1:%L2:%L3, %L4 GB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1:%L2:%L3，%L4 GB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_invalid_clip_operation_canceled">
      <source>Invalid Clip. Operation canceled</source>
      <translation variants="no">短片無效。操作已取消。</translation>
    </message>
    <message numerus="yes" id="txt_videos_dpopinfo_ln_videos_are_being_deleted">
      <source>%Ln videos are being deleted.</source>
      <translation>
        <numerusform plurality="a">正在刪除%Ln段短片</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_title_select_videos">
      <source>Select videos:</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇短片：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1_l2_kb">
      <source>%L1:%L2:%L3, %L4 kB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1:%L2:%L3，%L4 kB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_kb">
      <source>%L1 kB</source>
      <translation variants="no">%L1 kB</translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_mbps">
      <source>%L1 Mbps</source>
      <translation variants="no">%L1 Mbps</translation>
    </message>
    <message numerus="no" id="txt_videos_dialog_entry_new_collection">
      <source>New collection</source>
      <translation variants="no">新收藏集</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_recently_watched_val_no_videos">
      <source>(No videos)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(沒有短片)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_delete_some_videos_which">
      <source>Unable to delete some videos which are currently open.</source>
      <translation variants="no">無法刪除部分短片。請關閉開啟中的短片並重試。</translation>
    </message>
    <message numerus="no" id="txt_videos_info_protected_clip_can_not_be_played">
      <source>Protected clip, can not be played through TV-Out</source>
      <translation variants="no">短片受到保護。無法使用電視輸出傳輸線。</translation>
    </message>
    <message numerus="no" id="txt_videos_menu_play">
      <source>Play</source>
      <translation variants="no">播放</translation>
    </message>
    <message numerus="no" id="txt_videos_list_service">
      <source>Service:</source>
      <translation variants="yes">
        <lengthvariant priority="1">服務：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_audio_type">
      <source>Audio type:</source>
      <translation variants="yes">
        <lengthvariant priority="1">音效類型：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_remove_collection_1">
      <source>Unable to remove collection %1.</source>
      <translation variants="no">無法移除收藏集%1</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_remove_some_collections">
      <source>Unable to remove some collections.</source>
      <translation variants="no">無法移除部分收藏集</translation>
    </message>
    <message numerus="no" id="txt_videos_title_select_collection">
      <source>Select collection:</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇收藏集：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_video_playback_is_not_allowed_duri">
      <source>Video playback is not allowed during video call</source>
      <translation variants="no">視像電話期間無法播放短片</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_connect_connection_time">
      <source>Unable to connect: Connection timeout</source>
      <translation variants="no">無法連接至伺服器。連接逾時。</translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1l2">
      <source>%L1×%L2</source>
      <translation variants="no">%L1×%L2</translation>
    </message>
    <message numerus="no" id="txt_videos_title_enter_name">
      <source>Collection name</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏集名稱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_author">
      <source>Author:</source>
      <translation variants="yes">
        <lengthvariant priority="1">作者：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_subtitle_captured_l1">
      <source>Captured (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">已拍攝(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_date">
      <source>Creation date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">日期：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_opt_sort_by_sub_number_of_items">
      <source>Number of items</source>
      <translation variants="no">項目數</translation>
    </message>
    <message numerus="no" id="txt_videos_opt_create_new_collection">
      <source>Create new collection</source>
      <translation variants="no">新增收藏集</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_access_point">
      <source>Access point</source>
      <translation variants="no">接入點</translation>
    </message>
    <message numerus="no" id="txt_videos_formlabel_proxy_in_use">
      <source>Proxy in use</source>
      <translation variants="no">使用中的Proxy</translation>
    </message>
    <message numerus="no" id="txt_short_caption_videos">
      <source>Videos</source>
      <translation variants="no">短片庫</translation>
    </message>
    <message numerus="no" id="txt_videos_list_file_name">
      <source>File name</source>
      <translation variants="yes">
        <lengthvariant priority="1">檔案名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1l2l3">
      <source>%L1:%L2:%L3</source>
      <translation variants="no">%L1:%L2:%L3</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_none">
      <source>None</source>
      <translation variants="no">無</translation>
    </message>
    <message numerus="no" id="txt_videos_subhead_video_streaming_settings">
      <source>Video streaming settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">短片串流設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1l2l3">
      <source>%L1:%L2:%L3</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1:%L2:%L3</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_file_not_found">
      <source>File not found</source>
      <translation variants="no">找不到檔案</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1_mb">
      <source>%L1 MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_slidervalue_live">
      <source>Live</source>
      <translation variants="no">即時</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_min_udp_port">
      <source>Min UDP port</source>
      <translation variants="no">最小UDP端口號碼</translation>
    </message>
    <message numerus="no" id="txt_videos_list_file_path">
      <source>File path</source>
      <translation variants="yes">
        <lengthvariant priority="1">檔案路徑：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dpopinfo_video_added_to_1">
      <source>Video added to %1</source>
      <translation variants="no">短片已加入至%1</translation>
    </message>
    <message numerus="no" id="txt_videos_slidervalue_l1l2">
      <source>%L1:%L2</source>
      <translation variants="no">%L1:%L2</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_val_l1l2">
      <source>%L1/%L2</source>
      <translation variants="no">%L1/%L2</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1_gb">
      <source>%L1 GB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 GB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1_kb">
      <source>%L1 kB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 kB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_proxy_host_name">
      <source>Proxy host name</source>
      <translation variants="no">Proxy伺服器位址</translation>
    </message>
    <message numerus="no" id="txt_videos_subtitle_collections_l1">
      <source>Collections (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏集(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_proxy_port">
      <source>Proxy port</source>
      <translation variants="no">Proxy端口號碼</translation>
    </message>
    <message numerus="no" id="txt_videos_subtitle_all_videos_l1">
      <source>All videos (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #All videos (%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_info_resource_lost">
      <source>Resource Lost</source>
      <translation variants="no">資源中斷</translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_gbps">
      <source>%L1 Gbps</source>
      <translation variants="no">%L1 Gbps</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_captured_val_l1_l2_mb">
      <source>%L1:%L2:%L3, %L4 MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1:%L2:%L3，%L4 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_list_l1_mb">
      <source>%L1 MB</source>
      <translation variants="no">%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_videos_info_unable_to_connect_not_enough_band">
      <source>Unable to connect: Not enough bandwidth</source>
      <translation variants="no">無法連接至伺服器。頻寬不足。</translation>
    </message>
    <message numerus="no" id="txt_videos_slidervalue_l1">
      <source>%L1</source>
      <translation variants="no">%L1</translation>
    </message>
    <message numerus="no" id="txt_videos_dpopinfo_videos_added_to_1">
      <source>Videos added to %1</source>
      <translation variants="no">短片已加入至%1</translation>
    </message>
    <message numerus="no" id="txt_videos_dialog_video_name">
      <source>Video name</source>
      <translation variants="yes">
        <lengthvariant priority="1">短片名稱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_videos_slidervalue_l1l2l3_2">
      <source>%L1:%L2:%L3</source>
      <translation variants="no">%L1:%L2:%L3</translation>
    </message>
    <message numerus="no" id="txt_videos_dblist_max_udp_port">
      <source>Max UDP port</source>
      <translation variants="no">最大UDP端口號碼</translation>
    </message>
  </context>
</TS>