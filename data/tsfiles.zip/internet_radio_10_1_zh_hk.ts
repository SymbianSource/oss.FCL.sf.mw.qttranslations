<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_short_caption_internetradio">
      <source>internetradio</source>
      <translation variants="no">zh_hk #internetradio</translation>
    </message>
    <message numerus="no" id="txt_long_caption_internetradio">
      <source>internetradio</source>
      <translation variants="no">互聯網收音機</translation>
    </message>
    <message numerus="no" id="txt_irad_info_can_not_add_more">
      <source>Can't add more</source>
      <translation variants="no">記憶體不足，無法加入更多內容</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_search_in_music_store">
      <source>search in music store</source>
      <translation variants="no">在音樂商店中找尋</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_network_connectiion">
      <source>No network connection</source>
      <translation variants="no">(沒有網絡連接)</translation>
    </message>
    <message numerus="no" id="txt_irad_info_connecting_timout">
      <source>Connecting timeout</source>
      <translation variants="no">連接逾時</translation>
    </message>
    <message numerus="no" id="txt_irad_title_internet_radio">
      <source>internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">互聯網收音機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_share_not_available">
      <source>Share not available</source>
      <translation variants="no">無法取得分享電台</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_space_on_c_drive_internet_radio_closed">
      <source>No space on C drive, Internet Radio closed</source>
      <translation variants="no">記憶體不足，無法啟動互聯網收音機</translation>
    </message>
    <message numerus="no" id="txt_irad_info_favorite_updated">
      <source>Favorite updated</source>
      <translation variants="no">我的最愛頻道已更新</translation>
    </message>
    <message numerus="no" id="txt_irad_info_song_recognition_not_available">
      <source>Song recognition not available</source>
      <translation variants="no">(無法使用歌曲識別)</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_go_to_station">
      <source>Go to station</source>
      <translation variants="no">前往電台</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_matching_stations_found">
      <source>No matching stations found</source>
      <translation variants="no">(找不到相符的電台)</translation>
    </message>
    <message numerus="no" id="txt_irad_info_music_store_not_available">
      <source>Music store not available</source>
      <translation variants="no">無法使用音樂商店</translation>
    </message>
    <message numerus="no" id="txt_internetradio_list_unknown_unknown">
      <source>Unknown - Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知-未知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_click_the_song_and_find_it_in_nokia_music_store">
      <source>Click the song and find it in nokia music store</source>
      <translation variants="no">按一下歌曲並在音樂商店中尋找</translation>
    </message>
    <message numerus="no" id="txt_irad_info_song_info_not_available">
      <source>song info not available</source>
      <translation variants="no">(無法取得歌曲資料)</translation>
    </message>
    <message numerus="no" id="txt_internetradio_list_1_unknown">
      <source>%1 - Unknown</source>
      <translation variants="no">%1-未知</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_share">
      <source>share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_country_region">
      <source>stations by country(region)</source>
      <translation variants="yes">
        <lengthvariant priority="1">以國家/地區顯示電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_internetradio_list_unknown_1">
      <source>Unknown - %1</source>
      <translation variants="no">未知-%1</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_high">
      <source>High</source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_clear_list">
      <source>clear list</source>
      <translation variants="no">zh_hk #clear list</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_internetradio">
      <source>internetradio</source>
      <translation variants="no">zh_hk #internetradio</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_search">
      <source>search</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #search</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_recently_played_songs">
      <source>recently played songs</source>
      <translation variants="no">最近播放過的歌曲</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_search_in_wikipedia">
      <source>search in wikipedia</source>
      <translation variants="no">在維基百科中找尋</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality">
      <source>download quality</source>
      <translation variants="no">下載品質</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_add_to_favorite">
      <source>Add to favorite</source>
      <translation variants="no">加入至我的最愛</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_from_play_list">
      <source>Stations from play list</source>
      <translation variants="yes">
        <lengthvariant priority="1">播放清單中的電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_recently_played_stations">
      <source>recently played stations</source>
      <translation variants="no">最近播放過的電台</translation>
    </message>
    <message numerus="yes" id="txt_irad_setlabel_bit_rate">
      <source>Bit rate: %Ln kbps</source>
      <translation>
        <numerusform plurality="a">zh_hk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_operation_failed">
      <source>operation failed</source>
      <translation variants="no">不能執行操作</translation>
    </message>
    <message numerus="no" id="txt_irad_list_recently_played_stations">
      <source>recently played stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放過的電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_go_to_now_playing">
      <source>Go to Now Playing</source>
      <translation variants="no">前往"正在播放"</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_search_result">
      <source>search result</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜尋結果</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_description">
      <source>Description</source>
      <translation variants="yes">
        <lengthvariant priority="1">內容說明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_station_name">
      <source>Station name</source>
      <translation variants="yes">
        <lengthvariant priority="1">電台名稱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_language">
      <source>stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">以語言顯示電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_hi_these_are_my_favorite_stations_hope_you_like_them">
      <source>Hi, these are my favortie stations. Hope you like them</source>
      <translation variants="no">你好，這些是我的最愛電台。希望你喜歡！</translation>
    </message>
    <message numerus="no" id="txt_irad_info_added_to_favorites">
      <source>Added to Favorites</source>
      <translation variants="no">zh_hk #Added to Favorites</translation>
    </message>
    <message numerus="no" id="txt_irad_info_downloading_logos">
      <source>Downloading logos</source>
      <translation variants="no">正在下載標誌</translation>
    </message>
    <message numerus="no" id="txt_irad_list_recently_played_songs">
      <source>recently played songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放過的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_disallowed_by_this_station">
      <source>Disallowed by this station</source>
      <translation variants="no">電台不允許</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_language">
      <source>stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">以語言顯示電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_failed_to_connect">
      <source>Connecting failed</source>
      <translation variants="no">無法連接</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_network_setting">
      <source>Network Setting</source>
      <translation variants="no">網絡設定</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_songs">
      <source>recently played songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放過的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_standard">
      <source>Standard</source>
      <translation variants="no">標準</translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_country_region">
      <source>stations by country(region)</source>
      <translation variants="yes">
        <lengthvariant priority="1">以國家/地區顯示電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_invalid_link_please_change_it">
      <source>invalid URL link, please change it</source>
      <translation variants="no">網址無效</translation>
    </message>
    <message numerus="no" id="txt_irad_connecting_failed_try_next_url">
      <source>Connecting failed, try next URL</source>
      <translation variants="no">無法連接。請嘗試其他的網址。</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_deactivate_stereo">
      <source>Deactivate Stereo</source>
      <translation variants="no">關閉立體聲</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_activate_stereo">
      <source>Activate Stereo</source>
      <translation variants="no">啟動立體聲</translation>
    </message>
    <message numerus="no" id="txt_irad_info_connecting_to_server">
      <source>Connecting to server</source>
      <translation variants="no">正在連接至伺服器</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_share">
      <source>share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_stations">
      <source>recently played stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放過的電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_network_setting">
      <source>network setting</source>
      <translation variants="yes">
        <lengthvariant priority="1">網絡設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_unnamed">
      <source>Unnamed</source>
      <translation variants="no">未命名</translation>
    </message>
  </context>
</TS>