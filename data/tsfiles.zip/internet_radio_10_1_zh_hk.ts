<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_irad_opt_share">
      <source>share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_stations">
      <source>recently played stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放過的電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_menu_share">
      <source>share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_irad_info_music_store_not_available">
      <source>Music store not available</source>
      <translation variants="no">無法使用音樂商店</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_country_region">
      <source>stations by country(region)</source>
      <translation variants="yes">
        <lengthvariant priority="1">以國家/地區顯示電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_click_the_song_and_find_it_in_nokia_music_store">
      <source>Click the song and find it in nokia music store</source>
      <translation variants="no">按一下歌曲並在音樂商店中尋找</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_high">
      <source>High</source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_irad_info_song_info_not_available">
      <source>song info not available</source>
      <translation variants="no">(無法取得歌曲資料)</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_internetradio">
      <source>internetradio</source>
      <translation variants="no">zh_hk ##internetradio</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_search">
      <source>search</source>
      <translation variants="no">zh_hk ##search</translation>
    </message>
    <message numerus="no" id="txt_long_caption_internetradio">
      <source>internetradio</source>
      <translation variants="no">互聯網收音機</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_go_to_station">
      <source>Go to station</source>
      <translation variants="no">前往電台</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_matching_stations_found">
      <source>No matching stations found</source>
      <translation variants="no">(找不到相符的電台)</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_recently_played_songs">
      <source>recently played songs</source>
      <translation variants="no">最近播放過的歌曲</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_search_in_wikipedia">
      <source>search in wikipedia</source>
      <translation variants="no">在維基百科中找尋</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality">
      <source>download quality</source>
      <translation variants="yes">
        <lengthvariant priority="1">下載品質</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_from_play_list">
      <source>Stations from play list</source>
      <translation variants="yes">
        <lengthvariant priority="1">播放清單中的電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_recently_played_stations">
      <source>recently played stations</source>
      <translation variants="no">最近播放過的電台</translation>
    </message>
    <message numerus="no" id="txt_short_caption_internetradio">
      <source>internetradio</source>
      <translation variants="no">zh_hk ##internetradio</translation>
    </message>
    <message numerus="no" id="txt_irad_info_operation_failed">
      <source>operation failed</source>
      <translation variants="no">不能執行操作</translation>
    </message>
    <message numerus="no" id="txt_irad_list_recently_played_stations">
      <source>recently played stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放過的電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_menu_search_in_music_store">
      <source>search in music store</source>
      <translation variants="no">在音樂商店中找尋</translation>
    </message>
    <message numerus="no" id="txt_irad_title_internet_radio">
      <source>internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">互聯網收音機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_space_on_c_drive_internet_radio_closed">
      <source>No space on C drive, Internet Radio closed</source>
      <translation variants="no">記憶體不足，無法啟動互聯網收音機</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_deactivate_stereo">
      <source>Deactivate Stereo</source>
      <translation variants="no">關閉立體聲</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_activate_stereo">
      <source>Activate Stereo</source>
      <translation variants="no">啟動立體聲</translation>
    </message>
    <message numerus="no" id="txt_irad_info_connecting_to_server">
      <source>Connecting to server</source>
      <translation variants="no">正在連接至伺服器</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_go_to_now_playing">
      <source>Go to Now Playing</source>
      <translation variants="no">前往"正在播放"</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_search_result">
      <source>search result</source>
      <translation variants="no">搜尋結果</translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_station_name">
      <source>Station name</source>
      <translation variants="no">電台名稱</translation>
    </message>
    <message numerus="yes" id="txt_irad_setlabel_bit_rate">
      <source>Bit rate: %Ln kbps</source>
      <translation>
        <numerusform plurality="a">zh_hk ##Bit rate: %Ln kbps</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_service_availability_content">
      <source>The Service is provided as a convenience to you. It is provided "as is" and on an "as available" basis. Nokia does not guarantee that the Service shall be uninterrupted or error-free. Nokia reserves the right to revise the Service or withdraw access to it at any time.\n\nNokia may provide upgrades for software applications related to the Service at its sole discretion.
</source>
      <translation variants="no">zh_hk #The Service is provided as a convenience to you. It is provided "as is" and on an "as available" basis. Nokia does not guarantee that the Service shall be uninterrupted or error-free. Nokia reserves the right to revise the Service or withdraw access to it at any time.\n\nNokia may provide upgrades for software applications related to the Service at its sole discretion.
</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_use_of_the_service">
      <source>USE OF THE SERVICE</source>
      <translation variants="no">zh_hk #USE OF THE SERVICE</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_privacy">
      <source>PRIVACY</source>
      <translation variants="no">zh_hk #PRIVACY</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_governing_law">
      <source>GOVERNING LAW</source>
      <translation variants="no">zh_hk #GOVERNING LAW</translation>
    </message>
    <message numerus="no" id="txt_irad_list_added_new_station">
      <source>The link to the Internet radio station is a resource locator or a set of resource locators that enable the user to access the content streamed by the Internet radio station.</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #The link to the Internet radio station is a resource locator or a set of resource locators that enable the user to access the content streamed by the Internet radio station.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_button_decline">
      <source>Decline</source>
      <translation variants="no">zh_hk #Decline</translation>
    </message>
    <message numerus="no" id="txt_irad_info_use_of_the_service_content">
      <source>Use of the Service is only permitted for your private and non-commercial use. Nokia shall own all intellectual property rights relating to the Service.\n\nNokia reserves the right to change these terms and conditions by informing you of such change.
</source>
      <translation variants="no">zh_hk #Use of the Service is only permitted for your private and non-commercial use. Nokia shall own all intellectual property rights relating to the Service.\n\nNokia reserves the right to change these terms and conditions by informing you of such change.
</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_network_setting">
      <source>network setting</source>
      <translation variants="no">網絡設定</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_language">
      <source>stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">以語言顯示電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_recently_played_songs">
      <source>recently played songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放過的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_disallowed_by_this_station">
      <source>Disallowed by this station</source>
      <translation variants="no">電台不允許</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_l">
      <source>Unknown artist</source>
      <translation variants="no">zh_hk #Unknown artist</translation>
    </message>
    <message numerus="no" id="txt_irad_info_definitions_content">
      <source>Internet radio stations are entities that generally produce and distribute audio content and related metadata over the Internet in a stream.\n\nThe link to the Internet radio station is a resource locator or a set of resource locators that enable the user to access the content streamed by the Internet radio station.
</source>
      <translation variants="no">zh_hk #Internet radio stations are entities that generally produce and distribute audio content and related metadata over the Internet in a stream.\n\nThe link to the Internet radio station is a resource locator or a set of resource locators that enable the user to access the content streamed by the Internet radio station.
</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_definitions">
      <source>DEFINITIONS</source>
      <translation variants="no">zh_hk #DEFINITIONS</translation>
    </message>
    <message numerus="no" id="txt_irad_info_disclaimer_and_liability_content">
      <source>For your ease of accessibility, Nokia may include links to Internet radio stations that are owned or operated by third parties. Nokia does not guarantee that the links to Internet radio stations will be operational. In addition, the content that is not related to Nokia does not imply whatsoever that Nokia endorses the content as such or the products or services referenced in such content.\n\nYou must review and agree to each station's rules of use, if any, before accessing it. You also agree that Nokia has no control over the content of third-party services and cannot assume any responsibility for the content provided by Internet radio stations.\n\nAccessing the content of Internet radio stations using the Service may involve the transmission of large amounts of data through your service provider's network. Contact your service provider for information about data transmission charges. Note that using the Service with Internet radio stations that are delivering higher bit rate streams to you may incur higher costs associated with data traffic.\n\nThe data traffic associated with the usage of the Service may include the following at least: updating the content of the stations’ directory, streaming data from the Internet radio station, collecting statistical data and upgrading the Internet radio application.\n\nNokia is not liable for the costs of data traffic associated with your use of the Service.\n\nNO WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF TITLE OR NON-INFRINGEMENT OR IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, IS MADE IN RELATION TO THE AVAILABILITY, ACCURACY, RELIABILITY OR CONTENT OF THE SERVICE. NOKIA SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR FOR BUSINESS INTERRUPTION ARISING OUT OF THE USE OF OR INABILITY TO USE THE SERVICE, EVEN IF NOKIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. SOME JURISDICTIONS DO</source>
      <translation variants="no">zh_hk #For your ease of accessibility, Nokia may include links to Internet radio stations that are owned or operated by third parties. Nokia does not guarantee that the links to Internet radio stations will be operational. In addition, the content that is not related to Nokia does not imply whatsoever that Nokia endorses the content as such or the products or services referenced in such content.\n\nYou must review and agree to each station's rules of use, if any, before accessing it. You also agree that Nokia has no control over the content of third-party services and cannot assume any responsibility for the content provided by Internet radio stations.\n\nAccessing the content of Internet radio stations using the Service may involve the transmission of large amounts of data through your service provider's network. Contact your service provider for information about data transmission charges. Note that using the Service with Internet radio stations that are delivering higher bit rate streams to you may incur higher costs associated with data traffic.\n\nThe data traffic associated with the usage of the Service may include the following at least: updating the content of the stations’ directory, streaming data from the Internet radio station, collecting statistical data and upgrading the Internet radio application.\n\nNokia is not liable for the costs of data traffic associated with your use of the Service.\n\nNO WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF TITLE OR NON-INFRINGEMENT OR IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, IS MADE IN RELATION TO THE AVAILABILITY, ACCURACY, RELIABILITY OR CONTENT OF THE SERVICE. NOKIA SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR FOR BUSINESS INTERRUPTION ARISING OUT OF THE USE OF OR INABILITY TO USE THE SERVICE, EVEN IF NOKIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. SOME JURISDICTIONS DO</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_identify_song">
      <source>identify song</source>
      <translation variants="no">zh_hk #identify song</translation>
    </message>
    <message numerus="no" id="txt_irad_info_delete_station">
      <source>Delete station?</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Delete station?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_internet_radio">
      <source>internet radio</source>
      <translation variants="no">zh_hk #internet radio</translation>
    </message>
    <message numerus="no" id="txt_irad_info_nokia_internet_radio">
      <source>Nokia Internet Radio service (“Service”) enables you to discover and experience the content of Internet radio stations. YOU AGREE THAT YOUR USE OF THE SERVICE ACKNOWLEDGES THAT YOU HAVE READ THIS AGREEMENT, YOU HAVE UNDERSTOOD IT AND YOU AGREE TO BE BOUND BY ITS TERMS AND CONDITIONS. If you do not agree, please note that you will not be allowed to use the Service.</source>
      <translation variants="no">zh_hk #Nokia Internet Radio service (“Service”) enables you to discover and experience the content of Internet radio stations. YOU AGREE THAT YOUR USE OF THE SERVICE ACKNOWLEDGES THAT YOU HAVE READ THIS AGREEMENT, YOU HAVE UNDERSTOOD IT AND YOU AGREE TO BE BOUND BY ITS TERMS AND CONDITIONS. If you do not agree, please note that you will not be allowed to use the Service.</translation>
    </message>
    <message numerus="no" id="txt_irad_info_clear_song_list">
      <source>clear song list? </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #clear song list? </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_can_not_input_more_characters">
      <source>can't not input more characters</source>
      <translation variants="no">zh_hk #can't not input more characters</translation>
    </message>
    <message numerus="no" id="txt_irad_info_rename">
      <source>rename</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #rename</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_downloading_logos">
      <source>Downloading logos</source>
      <translation variants="no">正在下載標誌</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_terms_conditions">
      <source>Terms and Conditions</source>
      <translation variants="no">zh_hk #Terms and Conditions</translation>
    </message>
    <message numerus="no" id="txt_irad_info_the_service_content">
      <source>The Service enables the following:\n\n1. browsing of links to Internet radio stations;\n\n2. accessing the content of Internet radio stations;
</source>
      <translation variants="no">zh_hk #The Service enables the following:\n\n1. browsing of links to Internet radio stations;\n\n2. accessing the content of Internet radio stations;
</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_service_availability">
      <source>SERVICE AVAILABILITY</source>
      <translation variants="no">zh_hk #SERVICE AVAILABILITY</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_add_to_favorites">
      <source>Add to favorites</source>
      <translation variants="no">zh_hk #Add to favorites</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_unknown_song">
      <source>Unknown artist - Unknown song</source>
      <translation variants="no">zh_hk #Unknown artist - Unknown song</translation>
    </message>
    <message numerus="no" id="txt_irad_info_privacy_content">
      <source>Nokia is committed to protecting user privacy, and thus implements strict confidentiality policies.\n\n In order to monitor the use of and to improve the Service, Nokia may collect usage data including, but not limited to, information about the Internet radio stations accessed, the time spent on each station and the items rated as favourites.\n\nNokia does not collect any information that allows identification of the user of the Service.
</source>
      <translation variants="no">zh_hk #Nokia is committed to protecting user privacy, and thus implements strict confidentiality policies.\n\n In order to monitor the use of and to improve the Service, Nokia may collect usage data including, but not limited to, information about the Internet radio stations accessed, the time spent on each station and the items rated as favourites.\n\nNokia does not collect any information that allows identification of the user of the Service.
</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_p">
      <source>Unknown artist</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Unknown artist</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_station_could_not_find">
      <source>Station could not find</source>
      <translation variants="no">zh_hk #Station could not find</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_songs">
      <source>recently played songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放過的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_button_accept">
      <source>Accept</source>
      <translation variants="no">zh_hk #Accept</translation>
    </message>
    <message numerus="yes" id="txt_irad_subtitle_stations">
      <source>%Ln stations</source>
      <translation>
        <numerusform plurality="a">zh_hk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_select_items_to_delete">
      <source>select items to delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #select items to delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_station_address">
      <source>Station address</source>
      <translation variants="no">zh_hk #Station address</translation>
    </message>
    <message numerus="no" id="txt_irad_info_station_with_new_name_exists">
      <source>station with new name exists</source>
      <translation variants="no">zh_hk #station with new name exists</translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_country_region">
      <source>stations by country(region)</source>
      <translation variants="yes">
        <lengthvariant priority="1">以國家/地區顯示電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_song_p">
      <source>Unknown song</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Unknown song</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_network_setting">
      <source>Network Setting</source>
      <translation variants="no">網絡設定</translation>
    </message>
    <message numerus="no" id="txt_irad_connecting_failed_try_next_url">
      <source>Connecting failed, try next URL</source>
      <translation variants="no">無法連接。請嘗試其他的網址。</translation>
    </message>
    <message numerus="no" id="txt_irad_info_clear_station_list">
      <source>clear station list?</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #clear station list?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_can_not_add_more">
      <source>Can't add more</source>
      <translation variants="no">記憶體不足，無法加入更多內容</translation>
    </message>
    <message numerus="no" id="txt_irad_info_share_not_available">
      <source>Share not available</source>
      <translation variants="no">無法取得分享電台</translation>
    </message>
    <message numerus="no" id="txt_irad_info_song_recognition_not_available">
      <source>Song recognition not available</source>
      <translation variants="no">(無法使用歌曲識別)</translation>
    </message>
    <message numerus="no" id="txt_irad_info_hi_these_are_my_favorite_stations_hope_you_like_them">
      <source>Hi, these are my favortie stations. Hope you like them</source>
      <translation variants="no">你好，這些是我的最愛電台。希望你喜歡！</translation>
    </message>
    <message numerus="no" id="txt_irad_info_added_to_favorites">
      <source>Added to Favorites</source>
      <translation variants="no">zh_hk ##Added to Favorites</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_the_services">
      <source>THE SERVICE</source>
      <translation variants="no">zh_hk #THE SERVICE</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_clear_list">
      <source>clear list</source>
      <translation variants="no">zh_hk #clear list</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_policy_copyright">
      <source>POLICY REGARDING ALLEGATIONS OF COPYRIGHT INFRINGEMENT</source>
      <translation variants="no">zh_hk #POLICY REGARDING ALLEGATIONS OF COPYRIGHT INFRINGEMENT</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_network_connection">
      <source>No network connection</source>
      <translation variants="no">zh_hk #No network connection</translation>
    </message>
    <message numerus="no" id="txt_irad_info_failed_to_connect">
      <source>Connecting failed</source>
      <translation variants="no">無法連接</translation>
    </message>
    <message numerus="no" id="txt_irad_info_invalid_link_please_change_it">
      <source>invalid URL link, please change it</source>
      <translation variants="no">網址無效</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_song_l">
      <source>Unknown song</source>
      <translation variants="no">zh_hk #Unknown song</translation>
    </message>
    <message numerus="no" id="txt_irad_info_connecting_timout">
      <source>Connecting timeout</source>
      <translation variants="no">連接逾時</translation>
    </message>
    <message numerus="no" id="txt_irad_info_favorite_updated">
      <source>Favorite updated</source>
      <translation variants="no">我的最愛頻道已更新</translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_language">
      <source>stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">以語言顯示電台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_governing_law_content">
      <source>As used in these terms and conditions, "Nokia" means Nokia Corporation. Nokia operates and controls the Service from locations within Finland. As such, the information contained on the Service hereby is deemed to be provided in Finland.\n\nExcept where prohibited by applicable law, these terms and conditions shall be governed by the laws of Finland without regard to conflict of law provisions. For US residents: These terms and conditions shall be governed by the laws of Texas.\n\nCopyright © Nokia Corporation 2006. All rights reserved.
</source>
      <translation variants="no">zh_hk #As used in these terms and conditions, "Nokia" means Nokia Corporation. Nokia operates and controls the Service from locations within Finland. As such, the information contained on the Service hereby is deemed to be provided in Finland.\n\nExcept where prohibited by applicable law, these terms and conditions shall be governed by the laws of Finland without regard to conflict of law provisions. For US residents: These terms and conditions shall be governed by the laws of Texas.\n\nCopyright © Nokia Corporation 2006. All rights reserved.
</translation>
    </message>
    <message numerus="no" id="txt_irad_info_unnamed_station">
      <source>Unnamed station</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Unnamed station</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_policy_copyright_content">
      <source>If you believe that your copyrighted work has been handled in a way that constitutes copyright infringement, you may notify Nokia by providing a notification including the following:\n\n(1) A physical or electronic signature of a person authorised to act on behalf of the owner of the exclusive right that is allegedly infringed;\n\n(2) Identification or description of the copyrighted work claimed to have been infringed;\n\n(3) Identification or description of the material that is claimed to be infringing and information reasonably sufficient to locate the material;\n\n(4) Your name, address, telephone number, e-mail address and any other information that will permit Nokia to contact you;\n\n(5) A statement that you believe, in good faith, that use of the material in the manner on which this complaint is based is not authorised by the copyright owner, its agent or the law; and\n\n(6) A statement that the information in the notification is accurate and, under penalty of perjury, that you are authorised to act on behalf of the owner of an exclusive right that is allegedly infringed.\n\nThe notification must be sent to our Designated Agent address at:\n\nCopyright.Notices@nokia.com
</source>
      <translation variants="no">zh_hk #If you believe that your copyrighted work has been handled in a way that constitutes copyright infringement, you may notify Nokia by providing a notification including the following:\n\n(1) A physical or electronic signature of a person authorised to act on behalf of the owner of the exclusive right that is allegedly infringed;\n\n(2) Identification or description of the copyrighted work claimed to have been infringed;\n\n(3) Identification or description of the material that is claimed to be infringing and information reasonably sufficient to locate the material;\n\n(4) Your name, address, telephone number, e-mail address and any other information that will permit Nokia to contact you;\n\n(5) A statement that you believe, in good faith, that use of the material in the manner on which this complaint is based is not authorised by the copyright owner, its agent or the law; and\n\n(6) A statement that the information in the notification is accurate and, under penalty of perjury, that you are authorised to act on behalf of the owner of an exclusive right that is allegedly infringed.\n\nThe notification must be sent to our Designated Agent address at:\n\nCopyright.Notices@nokia.com
</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_disclaimer_and_liability">
      <source>DISCLAIMER AND LIABILITY</source>
      <translation variants="no">zh_hk #DISCLAIMER AND LIABILITY</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_standard">
      <source>Standard</source>
      <translation variants="no">標準</translation>
    </message>
  </context>
</TS>