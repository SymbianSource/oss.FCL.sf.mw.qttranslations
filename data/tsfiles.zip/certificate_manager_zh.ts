<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_certificate_manager_info_device_certificates_c">
      <source>Device certificates can be used without user confirmation. Use of device lock recommended. Proceed?</source>
      <translation variants="no">无需用户确认也能使用设备证书。建议使用设备锁。继续？</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_authority_certific">
      <source>Authority certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">授权证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_verify_keystore_pin">
      <source>Verify Keystore PIN:</source>
      <translation variants="no">验证密钥存储PIN：</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_info_move">
      <source>Move.......</source>
      <translation variants="yes">
        <lengthvariant priority="1">移动证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_move_to_device_certif">
      <source>Move to device certificates</source>
      <translation variants="no">移至设备证书</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_personal_certificates">
      <source>Personal certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">个人证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_move_to_personal_cert">
      <source>Move to personal certificates</source>
      <translation variants="no">移至个人证书</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_trusted_site_certific">
      <source>Trusted site certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">可信站点证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_personal_certifica">
      <source>Personal certificate</source>
      <translation variants="yes">
        <lengthvariant priority="1">个人证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_trust_settings">
      <source>Trust settings</source>
      <translation variants="no">信任设置</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_device_certificate">
      <source>Device certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">设备证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_trusted_site_certi">
      <source>Trusted site certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">可信站点证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_unable_to_use_priva">
      <source>Unable to use private key. Set keystore PIN:</source>
      <translation variants="no">无法使用私钥。先设置密钥存储PIN：</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_setlabel_advanced_security">
      <source>Advanced security</source>
      <translation variants="yes">
        <lengthvariant priority="1">高级安全</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_set">
      <source>Set</source>
      <translation variants="yes">
        <lengthvariant priority="1">设置密钥存储PIN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_authority_certificate">
      <source>Authority certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">授权证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_keystore_pin">
      <source>Keystore PIN</source>
      <translation variants="yes">
        <lengthvariant priority="1">密钥存储PIN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dpopinfo_keystore_pin_does">
      <source>Keystore PIN does not match</source>
      <translation variants="no">密钥存储PIN不一致</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_device_certificates">
      <source>Device certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">设备证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_enter_keystore_pin">
      <source>Enter keystore PIN:</source>
      <translation variants="no">输入密钥存储PIN：</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_setlabel_certificates">
      <source>Certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">证书</lengthvariant>
      </translation>
    </message>
  </context>
</TS>