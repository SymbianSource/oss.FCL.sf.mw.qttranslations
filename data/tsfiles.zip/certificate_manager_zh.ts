<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_certificate_manager_list_personal_certificates">
      <source>Personal certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">个人证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_list_algorithm">
      <source>Algorithm:</source>
      <translation variants="no">zh #Algorithm:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_sha2">
      <source>SHA2</source>
      <translation variants="no">zh #SHA2</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_certificate_format">
      <source>Certificate format:</source>
      <translation variants="no">zh #Certificate format:</translation>
    </message>
    <message numerus="no" id="txt_certificate_info_device_certificates_can_be_us">
      <source>Device certificates can be used without user confirmation. Use of device lock recommended. Continue?</source>
      <translation variants="no">无需用户确认即可使用设备证书。建议使用设备锁。继续？</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_formlabel_vpn">
      <source>VPN</source>
      <translation variants="no">VPN</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_key_store_is_corrupted">
      <source>Key store is corrupted</source>
      <translation variants="no">密钥存储损坏</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_title_certificate">
      <source>Certificate</source>
      <translation variants="no">zh #Certificate</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_memory_database_corrupte">
      <source>Memory database corrupted!</source>
      <translation variants="no">存储数据库损坏</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_move_to_personal_cert">
      <source>Move to personal certificates</source>
      <translation variants="no">移至个人证书</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_rsa">
      <source>RSA</source>
      <translation variants="no">zh #RSA</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_dh">
      <source>DH</source>
      <translation variants="no">zh #DH</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_enter_keystore_pin">
      <source>Enter keystore PIN:</source>
      <translation variants="yes">
        <lengthvariant priority="1">输入密钥存储PIN：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_list_valid_until">
      <source>Valid until:</source>
      <translation variants="no">zh #Valid until:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_dsa">
      <source>DSA</source>
      <translation variants="no">zh #DSA</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_issuer">
      <source>Issuer:</source>
      <translation variants="no">zh #Issuer:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_title_certificate_access">
      <source>Certificate</source>
      <translation variants="yes">
        <lengthvariant priority="1">证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_connect_to_host_name">
      <source>Connect to '%1' without warnings. Continue?</source>
      <translation variants="no">与"%[99]1"的后续连接将不再出现证书警告。继续？</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dpopinfo_keystore_pin_does">
      <source>Keystore PIN does not match</source>
      <translation variants="no">密钥存储PIN不一致</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_unknown_cert">
      <source>Unknown</source>
      <translation variants="no">zh #Unknown</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_certname">
      <source>%1</source>
      <translation variants="no">zh #%1</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_formlabel_online_certifica">
      <source>Online certificate check</source>
      <translation variants="no">在线证书检查</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_key_type_is_not_supported">
      <source>Key type is not supported</source>
      <translation variants="no">密钥类型不受支持</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_valid_from">
      <source>Valid from:</source>
      <translation variants="no">zh #Valid from:</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpophead_validity_expired">
      <source>Validity Expired</source>
      <translation variants="no">有效期届满</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_verify_keystore_pin">
      <source>Verify Keystore PIN:</source>
      <translation variants="yes">
        <lengthvariant priority="1">验证密钥存储PIN：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_1_sent_untrusted_cert">
      <source>'%1' has sent an untrusted certificate. Accept anyway?</source>
      <translation variants="no">zh #Service '%[98]1' has sent a certificate that is not trusted. Accept anyway?</translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_1_sent_cert_out_of_date">
      <source>%1' has sent a certificate which is out of date. Accept anyway?</source>
      <translation variants="no">zh ##%1' has sent a certificate which is out of date. Accept anyway?</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_service">
      <source>Service:</source>
      <translation variants="no">zh #Service:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_rsa">
      <source>RSA</source>
      <translation variants="no">zh #RSA</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_unsuppoerted_certificate">
      <source>Unsupported certificate</source>
      <translation variants="no">证书不受支持</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_formlabel_internet">
      <source>Internet</source>
      <translation variants="no">互联网</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_setlabel_certificates">
      <source>Certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_contains">
      <source>Contains:</source>
      <translation variants="no">zh #Contains:</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_serial_number">
      <source>Serial number:</source>
      <translation variants="no">zh #Serial number:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_formlabel_deactivate">
      <source>Deactivate</source>
      <translation variants="yes">
        <lengthvariant priority="1">关闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_trust_settings">
      <source>Trust settings</source>
      <translation variants="no">信任设置</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_certificate_format">
      <source>Certificate format:</source>
      <translation variants="no">zh #Certificate format:</translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_protect_with_password">
      <source>Protect with password</source>
      <translation variants="no">带密码保护</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_device_certificate">
      <source>Device certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">设备证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_authority_certific">
      <source>Authority certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">授权证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_1_sent_cert_different_sitename">
      <source>%1' has sent a certificate with different site name. Accept anyway?</source>
      <translation variants="no">zh ##%1' has sent a certificate with different site name. Accept anyway?</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_x509">
      <source>X.509</source>
      <translation variants="no">zh #X.509</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_service">
      <source>Service:</source>
      <translation variants="no">zh #Service:</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_fingerprint_sha1">
      <source>Fingerprint (SHA1):</source>
      <translation variants="no">zh #Fingerprint (SHA1):</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_certname">
      <source>%1</source>
      <translation variants="no">zh #%1</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_formlabel_java_installing">
      <source>Java installation</source>
      <translation variants="no">Java安装</translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_name_the_label">
      <source>Name the Label:</source>
      <translation variants="yes">
        <lengthvariant priority="1">标签：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_serial_number">
      <source>Serial number:</source>
      <translation variants="no">zh #Serial number:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_fingerprint_sha1">
      <source>Fingerprint (SHA1):</source>
      <translation variants="no">zh #Fingerprint (SHA1):</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_info_move">
      <source>Move.......</source>
      <translation variants="yes">
        <lengthvariant priority="1">移动证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_valid_until">
      <source>Valid until:</source>
      <translation variants="no">zh #Valid until:</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_md2">
      <source>MD2</source>
      <translation variants="no">zh #MD2</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_trusted_site_certific">
      <source>Trusted site certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">可信站点证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_title_untrusted_certificat">
      <source>Untrusted certificate</source>
      <translation variants="no">zh #Untrusted certificate</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_sha1">
      <source>SHA1</source>
      <translation variants="no">zh #SHA1</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_unknown_algo">
      <source>Unknown</source>
      <translation variants="no">zh #Unknown</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_not_enough_memory">
      <source>Not enough memory!</source>
      <translation variants="no">无足够存储</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_cannot_be_saved">
      <source>Cannot be saved</source>
      <translation variants="no">无法储存</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_personal_certifica">
      <source>Personal certificate</source>
      <translation variants="yes">
        <lengthvariant priority="1">个人证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_1_sent_untrusted_cert_diff_sitename_and_out_of_date">
      <source>%1' has sent an untrusted certificate with different site name and which is out of date. Accept anyway?</source>
      <translation variants="no">zh ##%1' has sent an untrusted certificate with different site name and which is out of date. Accept anyway?</translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_1_sent_untrusted_cert_out_of_date">
      <source>'%1' has sent an untrusted certificate which is out of date. Accept anyway?</source>
      <translation variants="no">zh ##'%1' has sent an untrusted certificate which is out of date. Accept anyway?</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_adding_a_certificat">
      <source>Adding a certificate might be a risk!</source>
      <translation variants="no">zh #Adding this certificate may be risky</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_formlabel_symbian_instal">
      <source>Symbian installation</source>
      <translation variants="no">Symbian安装</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_md5">
      <source>MD5</source>
      <translation variants="no">zh #MD5</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_downloaded_certificate_i">
      <source>Downloaded certificate is expired!</source>
      <translation variants="no">证书过期</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_setlabel_advanced_security">
      <source>Advanced security</source>
      <translation variants="yes">
        <lengthvariant priority="1">高级安全</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_1_sent_cert_diff_sitename_and_out_of_date">
      <source>%1' has sent a certificate with different site name and which is out of date. Accept anyway?</source>
      <translation variants="no">zh #Service '%[98]1' has sent a certificate which is out of date and has a different website name. Accept anyway?</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_algorithm">
      <source>Algorithm:</source>
      <translation variants="no">zh #Algorithm:</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_unknown">
      <source>Unknown</source>
      <translation variants="no">zh #Unknown</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_sha2">
      <source>SHA2</source>
      <translation variants="no">zh #SHA2</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_md2">
      <source>MD2</source>
      <translation variants="no">zh #MD2</translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_unable_to_use_private_key">
      <source>Unable to use private key. </source>
      <translation variants="no">无法使用私钥。</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_key_type_is_not_supporte">
      <source>Key type is not supported!</source>
      <translation variants="no">密钥类型不受支持</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_authority_certificate">
      <source>Authority certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">授权证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_sha1">
      <source>SHA1</source>
      <translation variants="no">zh #SHA1</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_key_already_exist">
      <source>Key already exist</source>
      <translation variants="no">密钥已存在</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_formlabel_widget_installat">
      <source>Widget installation</source>
      <translation variants="no">小部件安装</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_private_key_is_corrupted">
      <source>Private key is corrupted</source>
      <translation variants="no">私钥已损坏</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_keystore_pin">
      <source>Keystore PIN</source>
      <translation variants="yes">
        <lengthvariant priority="1">密钥存储PIN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_subject">
      <source>Subject:</source>
      <translation variants="no">zh #Subject:</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_dh">
      <source>DH</source>
      <translation variants="no">zh #DH</translation>
    </message>
    <message numerus="no" id="txt_certificate_subhead_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_1_sent_untrusted_cert_diff_sitename">
      <source>'%1' has sent an untrusted certificate with different site name. Accept anyway?</source>
      <translation variants="no">zh ##'%1' has sent an untrusted certificate with different site name. Accept anyway?</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_dsa">
      <source>DSA</source>
      <translation variants="no">zh #DSA</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_unknown_algo_name">
      <source>Unknown</source>
      <translation variants="no">zh #Unknown</translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_password_for_certificate">
      <source>Password for %1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%[23]1的密码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_fingerprint_md5">
      <source>Fingerprint (MD5):</source>
      <translation variants="no">zh #Fingerprint (MD5):</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_certificate_corrupted">
      <source>Certificate Corrupted</source>
      <translation variants="no">zh #Certificate corrupted</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_formlabel_activate">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">启动</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_device_certificates">
      <source>Device certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">设备证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_move_to_device_certif">
      <source>Move to device certificates</source>
      <translation variants="no">移至设备证书</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_fingerprint_md5">
      <source>Fingerprint (MD5):</source>
      <translation variants="no">zh #Fingerprint (MD5):</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_issuer">
      <source>Issuer:</source>
      <translation variants="no">zh #Issuer:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_md5">
      <source>MD5</source>
      <translation variants="no">zh #MD5</translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_accept_permanently">
      <source>Accept permanently</source>
      <translation variants="no">总是接受</translation>
    </message>
    <message numerus="no" id="txt_certificate_dialog_set_keystore_pin">
      <source>Set keystore PIN:</source>
      <translation variants="yes">
        <lengthvariant priority="1">设置密钥存储PIN码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_trusted_site_certi">
      <source>Trusted site certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">可信站点证书</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_list_subject">
      <source>Subject:</source>
      <translation variants="no">zh #Subject:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_valid_from">
      <source>Valid from:</source>
      <translation variants="no">zh #Valid from:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_1_sent_invalid_cert_connection_failed">
      <source>'%1' has sent an invalid certificate. Connection cannot be created.</source>
      <translation variants="no">zh #Unable to create connection. '%[98]1' has sent an invalid certificate.</translation>
    </message>
    <message numerus="no" id="txt_certificate_list_x509">
      <source>X.509</source>
      <translation variants="no">zh #X.509</translation>
    </message>
    <message numerus="no" id="txt_certificate_dpopinfo_certificate_not_valid">
      <source>Certificate not valid</source>
      <translation variants="no">证书无效</translation>
    </message>
  </context>
</TS>