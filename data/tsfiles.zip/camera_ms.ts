<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ms">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cam_list_night_portrait">
      <source>Source 0</source>
      <translation variants="yes">
        <lengthvariant priority="1">ms #Night portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_portrait">
      <source>Source 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">ms #Portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sports">
      <source>Source 2</source>
      <translation variants="yes">
        <lengthvariant priority="1">ms #Sport</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer">
      <source>Source 3</source>
      <translation variants="no">Pemasa diri</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos">
      <source>Source 4</source>
      <translation variants="no">Foto</translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode">
      <source>Source 5</source>
      <translation variants="no">ms #Camera on standby</translation>
    </message>
    <message numerus="no" id="txt_cam_list_landscape">
      <source>Source 6</source>
      <translation variants="yes">
        <lengthvariant priority="1">ms #Landscape</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation">
      <source>Source 7</source>
      <translation variants="no">Pemampasan dedahan</translation>
    </message>
    <message numerus="no" id="txt_cam_list_date">
      <source>Source 8</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tarikh</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec">
      <source>Source 9</source>
      <translation>
        <numerusform plurality="a">%Ln saat</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip">
      <source>Source 10</source>
      <translation variants="no">ms #Delete video clip?</translation>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camcorder">
      <source>Source 11</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kamera video kedua</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus">
      <source>Source 12</source>
      <translation variants="no">+%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video">
      <source>Source 13</source>
      <translation variants="no">Tunjukkan video yang dirakam</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings">
      <source>Source 14</source>
      <translation variants="no">Tetapan kamera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_flash">
      <source>Source 15</source>
      <translation variants="yes">
        <lengthvariant priority="1">Aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene">
      <source>Source 16</source>
      <translation variants="yes">
        <lengthvariant priority="1">Automatik</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_video">
      <source>Source 17</source>
      <translation variants="yes">
        <lengthvariant priority="1">Aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds">
      <source>Source 18</source>
      <translation>
        <numerusform plurality="a">%Ln saat</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_camera">
      <source>Source 19</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kamera</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_start">
      <source>Source 20</source>
      <translation variants="no">Mula</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_stabilization">
      <source>Source 21</source>
      <translation variants="no">Penstabilan video</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_set_as_default_scene_mode">
      <source>Source 22</source>
      <translation variants="no">Ttp sbg md pmndngn lalai</translation>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode">
      <source>Source 23</source>
      <translation variants="no">Denyar</translation>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation">
      <source>Source 24</source>
      <translation variants="no">ms #Exposure compensation</translation>
    </message>
    <message numerus="no" id="txt_cam_list_reduce_red_eye">
      <source>Source 25</source>
      <translation variants="yes">
        <lengthvariant priority="1">Pengurangan mata merah</lengthvariant>
        <lengthvariant priority="2">P'gurangan mata merah</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone">
      <source>Source 26</source>
      <translation variants="no">ms #Colour tone</translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left">
      <source>Source 27</source>
      <translation>
        <numerusform plurality="a">Baki %Ln imej</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_camera">
      <source>Source 28</source>
      <translation variants="no">ms #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_stabilization">
      <source>Source 29</source>
      <translation variants="no">Penstabilan video</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound">
      <source>Source 30</source>
      <translation variants="no">Bunyi video</translation>
    </message>
    <message numerus="no" id="txt_cam_list_incandescent">
      <source>Source 31</source>
      <translation variants="yes">
        <lengthvariant priority="1">Pijar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_geotagging">
      <source>Source 32</source>
      <translation variants="no">Tag geo</translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix">
      <source>Source 33</source>
      <translation>
        <numerusform plurality="a">%Ln Mpix</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sunny">
      <source>Source 34</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cerah</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_white">
      <source>Source 35</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hitam dan putih</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_mass_memory">
      <source>Source 36</source>
      <translation variants="yes">
        <lengthvariant priority="1">Memori massa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_change_mode">
      <source>Source 37</source>
      <translation variants="no">Tukar mod</translation>
    </message>
    <message numerus="no" id="txt_cam_other_restore_settings">
      <source>Source 38</source>
      <translation variants="no">ms #Restore settings?</translation>
    </message>
    <message numerus="yes" id="txt_cam_other_delete_n_items">
      <source>Source 39</source>
      <translation>
        <numerusform plurality="a">ms #Delete %Ln item?</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_geotagging">
      <source>Source 40</source>
      <translation variants="no">ms #Geotagging</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_video">
      <source>Source 41</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tak aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_camera ">
      <source>Source 42</source>
      <translation variants="no">Kamera</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_43">
      <source>Source 43</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA 4:3</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_face_tracking">
      <source>Source 44</source>
      <translation variants="no">Pengecaman muka</translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_rotation">
      <source>Source 45</source>
      <translation variants="no">Pemutaran imej</translation>
    </message>
    <message numerus="no" id="txt_cam_title_memory_in_use">
      <source>Source 46</source>
      <translation variants="no">Memori yang digunakan</translation>
    </message>
    <message numerus="no" id="txt_cam_list_camera">
      <source>Source 47</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kamera</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_flash">
      <source>Source 48</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tak aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_night">
      <source>Source 49</source>
      <translation variants="yes">
        <lengthvariant priority="1">Malam</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_video">
      <source>Source 50</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ya</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name">
      <source>Source 51</source>
      <translation variants="no">Nama imej lalai</translation>
    </message>
    <message numerus="no" id="txt_cam_title_set_as_default_scene_mode">
      <source>Source 52</source>
      <translation variants="no">Ttpkn sbg mod pmandangn lalai</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_video">
      <source>Source 53</source>
      <translation variants="yes">
        <lengthvariant priority="1">Malam</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_contrast">
      <source>Source 54</source>
      <translation variants="no">ms #Contrast</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_scene">
      <source>Source 55</source>
      <translation variants="yes">
        <lengthvariant priority="1">Aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_scene">
      <source>Source 56</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tak aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings">
      <source>Source 57</source>
      <translation variants="no">Tetapan</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_memory_in_use">
      <source>Source 58</source>
      <translation variants="no">Memori yang digunakan</translation>
    </message>
    <message numerus="no" id="txt_cam_title_capture_tone">
      <source>Source 59</source>
      <translation variants="no">Nada tangkapan</translation>
    </message>
    <message numerus="no" id="txt_cam_other_please_type_here">
      <source>Source 60</source>
      <translation variants="no">Taip di sini</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_video">
      <source>Source 61</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tidak</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_rotation">
      <source>Source 62</source>
      <translation variants="no">Pemutaran imej</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_phone_memory">
      <source>Source 63</source>
      <translation variants="yes">
        <lengthvariant priority="1">Memori telefon</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_cancel">
      <source>Source 64</source>
      <translation variants="no">Batal</translation>
    </message>
    <message numerus="no" id="txt_cam_info_no_memory_card_in_device_please_inse">
      <source>Source 65</source>
      <translation variants="no">ms #No memory card inserted. Insert memory card to capture images.</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality">
      <source>Source 66</source>
      <translation variants="no">Kualiti imej</translation>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer">
      <source>Source 67</source>
      <translation variants="no">Pemasa diri</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_rotate">
      <source>Source 68</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tidak</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sepia">
      <source>Source 69</source>
      <translation variants="yes">
        <lengthvariant priority="1">Perang</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity">
      <source>Source 70</source>
      <translation variants="no">Kepekaan cahaya</translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_image_name">
      <source>Source 71</source>
      <translation variants="no">Nama imej lalai</translation>
    </message>
    <message numerus="no" id="txt_cam_list_closeup">
      <source>Source 72</source>
      <translation variants="yes">
        <lengthvariant priority="1">Jarak dekat</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_low_light">
      <source>Source 73</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cahaya malap</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_face">
      <source>Source 74</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tak aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_qcif_sharing">
      <source>Source 75</source>
      <translation variants="yes">
        <lengthvariant priority="1">Perkongsian QCIF</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_video_name">
      <source>Source 76</source>
      <translation variants="no">Nama video lalai</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_face">
      <source>Source 77</source>
      <translation variants="yes">
        <lengthvariant priority="1">Aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_memory_card">
      <source>Source 78</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kad memori</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking">
      <source>Source 79</source>
      <translation variants="no">ms #Face detection</translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_rotate">
      <source>Source 80</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ya</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality">
      <source>Source 81</source>
      <translation variants="no">Kualiti imej</translation>
    </message>
    <message numerus="no" id="txt_cam_button_iso">
      <source>Source 82</source>
      <translation variants="no">ms #ISO</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos">
      <source>Source 83</source>
      <translation variants="no">Klip video</translation>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone">
      <source>Source 84</source>
      <translation variants="no">Rona warna</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name">
      <source>Source 85</source>
      <translation variants="no">Nama video lalai</translation>
    </message>
    <message numerus="no" id="txt_cam_caption_camera">
      <source>Source 86</source>
      <translation variants="no">ms #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_image">
      <source>Source 87</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ya</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone">
      <source>Source 88</source>
      <translation variants="no">Nada tangkapan</translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined">
      <source>Source 89</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ditentukan pengguna</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_negative">
      <source>Source 90</source>
      <translation variants="yes">
        <lengthvariant priority="1">Negatif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality">
      <source>Source 91</source>
      <translation variants="no">Kualiti video</translation>
    </message>
    <message numerus="no" id="txt_cam_other_default_image_name">
      <source>Source 92</source>
      <translation variants="no">Nama imej lalai</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality">
      <source>Source 93</source>
      <translation variants="no">Kualiti video</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga">
      <source>Source 94</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_camcorder">
      <source>Source 95</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kamera video</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_cloudy">
      <source>Source 96</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mendung</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_timer">
      <source>Source 97</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tak aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use">
      <source>Source 98</source>
      <translation variants="no">ms #Camera already in use by another application</translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus">
      <source>Source 99</source>
      <translation variants="no">-%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_whitebal">
      <source>Source 100</source>
      <translation variants="yes">
        <lengthvariant priority="1">Automatik</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_upload_settings">
      <source>Source 101</source>
      <translation variants="no">Tetapan muat naik</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_exposure_compensation">
      <source>Source 102</source>
      <translation variants="no">Pemampasan dedahan</translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_sound">
      <source>Source 103</source>
      <translation variants="no">Bunyi video</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_settings">
      <source>Source 104</source>
      <translation variants="no">Tetapan</translation>
    </message>
    <message numerus="no" id="txt_cam_info_error">
      <source>Source 105</source>
      <translation variants="no">ms #Unexpected error occurred. Restart phone.</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_restore_settings">
      <source>Source 106</source>
      <translation variants="no">Simpan semula tetapan</translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous">
      <source>Source 107</source>
      <translation variants="yes">
        <lengthvariant priority="1">Berterusan</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode">
      <source>Source 108</source>
      <translation variants="no">Mod pemandangan</translation>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance">
      <source>Source 109</source>
      <translation variants="no">ms #White balance</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_val_ln_recording_time_left">
      <source>Source 110</source>
      <translation variants="yes">
        <lengthvariant priority="1">Masa rakaman yang tinggal: %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image">
      <source>Source 111</source>
      <translation variants="no">ms #Show captured image</translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined_scene">
      <source>Source 112</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ditentukan pengguna</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_169_widescreen">
      <source>Source 113</source>
      <translation variants="yes">
        <lengthvariant priority="1">Skrin lebar HD 720p 16:9</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image">
      <source>Source 114</source>
      <translation variants="no">ms #Delete image?</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_stabil">
      <source>Source 115</source>
      <translation variants="yes">
        <lengthvariant priority="1">Aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_normal">
      <source>Source 116</source>
      <translation variants="yes">
        <lengthvariant priority="1">Biasa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_flash">
      <source>Source 117</source>
      <translation variants="yes">
        <lengthvariant priority="1">Automatik</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_not">
      <source>Source 118</source>
      <translation variants="no">Tidak</translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix_widescreen">
      <source>Source 119</source>
      <translation>
        <numerusform plurality="a">Skrin lebar %Ln Mpix</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance">
      <source>Source 120</source>
      <translation variants="no">Imbangan putih</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_image">
      <source>Source 121</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tidak</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_vivid">
      <source>Source 122</source>
      <translation variants="yes">
        <lengthvariant priority="1">Terang</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camera">
      <source>Source 123</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kamera kedua</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_lightsens">
      <source>Source 124</source>
      <translation variants="yes">
        <lengthvariant priority="1">Automatik</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image">
      <source>Source 125</source>
      <translation variants="no">Tunjuk imej yang ditangkap</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_stabil">
      <source>Source 126</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tak aktif</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_white_balance">
      <source>Source 127</source>
      <translation variants="no">Imbangan putih</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video">
      <source>Source 128</source>
      <translation variants="no">Tunjkkn video yg dirakam</translation>
    </message>
    <message numerus="no" id="txt_cam_list_fluorescent">
      <source>Source 129</source>
      <translation variants="yes">
        <lengthvariant priority="1">Pendarflour</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video">
      <source>Source 130</source>
      <translation>
        <numerusform plurality="a">%Ln saat</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_contrast">
      <source>Source 131</source>
      <translation variants="no">Kontras</translation>
    </message>
    <message numerus="no" id="txt_cam_info_captured_photos_and_videos_will_be_ta">
      <source>Source 132</source>
      <translation variants="no">Foto dan video yang dirakam akan diletakkan tag lokasi anda. Jika foto atau video dikongsi, data lokasi mungkin boleh dilihat oleh pihak ketiga. Telefon akan menggunakan rangkaian untuk mendapatkan data lokasi. Caj pemindahan data mungkin dikenakan. Perakaman lokasi boleh tak dibenarkan dalam tetapan.</translation>
    </message>
    <message numerus="no" id="txt_cam_list_not_video">
      <source>Source 133</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tidak</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video">
      <source>Source 134</source>
      <translation variants="yes">
        <lengthvariant priority="1">Berterusan</lengthvariant>
      </translation>
    </message>
  </context>
</TS>