<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="no">ur #(unnamed)</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_applib ">
      <source>Shows calendar events</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہوم. کیلنڈر اندراج دیکھیں</lengthvariant>
        <lengthvariant priority="2">ہوم اس. کیلنڈر ا. دیکھیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_no_events_ox">
      <source>No events in next 7 days</source>
      <translation variants="no">۷ دن کے لیے کوئی اندراجات نہیں</translation>
    </message>
    <message numerus="yes" id="txt_calendar_widget_v_dblist_val_l1_events">
      <source>%Ln events overlapping</source>
      <translation>
        <numerusform plurality="a">%Ln پر متجاوز اندراج</numerusform>
        <numerusform plurality="b">%Ln پر متجاوز اندراجات</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar_widget">
      <source>Calendar widget</source>
      <translation variants="no">کیلنڈر</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_no_events_tod">
      <source>No events today</source>
      <translation variants="no">آج کوئی اندراجات نہیں</translation>
    </message>
  </context>
</TS>