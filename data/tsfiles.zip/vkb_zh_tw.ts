<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_iti_setlabel_itut">
      <source>ITU-T</source>
      <translation variants="no">zh_tw #ITU-T</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_very_slow">
      <source>Very slow</source>
      <translation variants="no">zh_tw #Very slow</translation>
    </message>
    <message numerus="no" id="txt_iti_input_methods">
      <source>Input methods</source>
      <translation variants="no">zh_tw #Input methods</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_handwriting_speed">
      <source>Handwriting speed</source>
      <translation variants="no">zh_tw #Handwriting speed</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_best_prediction">
      <source>Best prediction</source>
      <translation variants="no">zh_tw #Best prediction</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_normal">
      <source>Normal</source>
      <translation variants="no">zh_tw #Normal</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_fast">
      <source>Fast</source>
      <translation variants="no">zh_tw #Fast</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_typing_correction">
      <source>Typing correction</source>
      <translation variants="no">zh_tw #Typing correction</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_portrait_input_method">
      <source>Portrait input method</source>
      <translation variants="no">zh_tw #Portrait input method</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_word_autocompletion">
      <source>Word autocompletion</source>
      <translation variants="no">zh_tw #Word autocompletion</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_default_mode_for_val_english">
      <source>English</source>
      <translation variants="no">zh_tw #English</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_pinyin">
      <source>Pinyin</source>
      <translation variants="no">zh_tw #Pinyin</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_word_autocompletion_val_off">
      <source>Off</source>
      <translation variants="no">zh_tw #Off</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_chinese_input_settings_hk">
      <source>Chinese input settings (HK)</source>
      <translation variants="no">zh_tw #Chinese input settings (HK)</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">zh_tw #Secondary writing language</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_qwerty">
      <source>Qwerty</source>
      <translation variants="no">zh_tw #Qwerty</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_stroke">
      <source>Stroke</source>
      <translation variants="no">zh_tw #Stroke</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_default_mode_for_keyboard_input">
      <source>Default mode for keyboard input</source>
      <translation variants="no">zh_tw #Default mode for keyboard input</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_medium">
      <source>Medium</source>
      <translation variants="no">zh_tw #Medium</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_landscape_input_method">
      <source>Landscape input method</source>
      <translation variants="no">zh_tw #Landscape input method</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_high">
      <source>High</source>
      <translation variants="no">zh_tw #High</translation>
    </message>
    <message numerus="no" id="txt_iti_list_number_keypad">
      <source>Number keypad</source>
      <translation variants="no">zh_tw #Number keypad</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_writing_language">
      <source>Writing language</source>
      <translation variants="no">zh_tw #Writing language</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">zh_tw #Off</translation>
    </message>
    <message numerus="no" id="txt_iti_handwriting">
      <source>Handwriting</source>
      <translation variants="no">zh_tw #Handwriting</translation>
    </message>
    <message numerus="no" id="txt_iti_spell">
      <source>Spell</source>
      <translation variants="no">zh_tw #Spell</translation>
    </message>
    <message numerus="no" id="txt_iti_language">
      <source>Language</source>
      <translation variants="no">zh_tw #Language</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_on">
      <source>On</source>
      <translation variants="no">zh_tw #On</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_primary_candidate">
      <source>Primary candidate</source>
      <translation variants="no">zh_tw #Primary candidate</translation>
    </message>
    <message numerus="no" id="txt_iti_title_word">
      <source>Word:</source>
      <translation variants="no">zh_tw #Word:</translation>
    </message>
    <message numerus="no" id="txt_iti_prediction">
      <source>Prediction</source>
      <translation variants="no">zh_tw #Prediction</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_zhuyin">
      <source>Zhuyin</source>
      <translation variants="no">zh_tw #Zhuyin</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_advanced">
      <source>Advanced</source>
      <translation variants="no">zh_tw #Advanced</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_character_bubble">
      <source>Character bubble</source>
      <translation variants="no">zh_tw #Character bubble</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_normal_chinese">
      <source>Normal</source>
      <translation variants="no">zh_tw #Normal</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_slow">
      <source>Slow</source>
      <translation variants="no">zh_tw #Slow</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_off_typing_corr">
      <source>Off</source>
      <translation variants="no">zh_tw #Off</translation>
    </message>
    <message numerus="no" id="txt_iti_list_letter_keypad">
      <source>Letter keypad</source>
      <translation variants="no">zh_tw #Letter keypad</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_cangjie">
      <source>Cangjie</source>
      <translation variants="no">zh_tw #Cangjie</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_exact_typing">
      <source>Exact typing</source>
      <translation variants="no">zh_tw #Exact typing</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_cangjie_mode">
      <source>Cangjie mode  </source>
      <translation variants="no">zh_tw #Cangjie mode  </translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_hwr">
      <source>HWR</source>
      <translation variants="no">zh_tw #HWR</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_chinese_input_settings_taiwan">
      <source>Chinese input settings (Taiwan)</source>
      <translation variants="no">zh_tw #Chinese input settings (Taiwan)</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_word_autocompletion_val_on">
      <source>On</source>
      <translation variants="no">zh_tw #On</translation>
    </message>
    <message numerus="no" id="txt_iti_prediction_not_supported">
      <source>Prediction not supported</source>
      <translation variants="no">zh_tw #Prediction not supported</translation>
    </message>
    <message numerus="no" id="txt_iti_input_settings">
      <source>Input settings</source>
      <translation variants="no">zh_tw #Input settings</translation>
    </message>
    <message numerus="no" id="txt_iti_on">
      <source>On</source>
      <translation variants="no">zh_tw #On</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_language">
      <source>Language</source>
      <translation variants="no">zh_tw #Language</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_prediction_val_none">
      <source>None</source>
      <translation variants="no">zh_tw #None</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_very_fast">
      <source>Very fast</source>
      <translation variants="no">zh_tw #Very fast</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_keyboard">
      <source>Keyboard</source>
      <translation variants="no">zh_tw #Keyboard</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_on">
      <source>On</source>
      <translation variants="no">zh_tw #On</translation>
    </message>
    <message numerus="no" id="txt_iti_off">
      <source>Off</source>
      <translation variants="no">zh_tw #Off</translation>
    </message>
    <message numerus="no" id="txt_iti_swype">
      <source>Swype</source>
      <translation variants="no">zh_tw #Swype</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_chinese_input_settings_simplified">
      <source>Chinese input settings (Simplified)</source>
      <translation variants="no">zh_tw #Chinese input settings (Simplified)</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_keypress_timeout">
      <source>Keypress timeout</source>
      <translation variants="no">zh_tw #Keypress timeout</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_prediction">
      <source>Prediction</source>
      <translation variants="no">zh_tw #Prediction</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_default_mode_for_val_chinese">
      <source>Chinese</source>
      <translation variants="no">zh_tw #Chinese</translation>
    </message>
    <message numerus="no" id="txt_iti_subhead_prediction_settings">
      <source>Prediction settings</source>
      <translation variants="no">zh_tw #Prediction settings</translation>
    </message>
    <message numerus="no" id="txt_iti_subhead_swype_settings">
      <source>Swype settings</source>
      <translation variants="no">zh_tw #Swype settings</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">zh_tw #Off</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">zh_tw #Primary writing language</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_easy">
      <source>Easy</source>
      <translation variants="no">zh_tw #Easy</translation>
    </message>
  </context>
</TS>