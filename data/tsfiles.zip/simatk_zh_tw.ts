<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_simatk_dialog_sim_services">
      <source>SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">系統業者服務</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">系統業者服務</translation>
    </message>
    <message numerus="no" id="txt_simatk_title_sim_services">
      <source>SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">系統業者服務</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">系統業者服務</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_sending">
      <source>Sending</source>
      <translation variants="no">資料傳送中</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_enternnumber">
      <source>Enter:\n(number)</source>
      <translation variants="no">輸入：(號碼)</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_entern1_digit_09">
      <source>Enter:\n(1 digit 0-9) </source>
      <translation variants="no">輸入：(1個數字0至9)</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_open_connection">
      <source>Open connection?</source>
      <translation variants="no">是否連線？</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_request_not_allowed">
      <source>Request not allowed</source>
      <translation variants="no">不允許要求</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_enter">
      <source>Enter:</source>
      <translation variants="no">輸入：</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_request_modified">
      <source>Request modified</source>
      <translation variants="no">要求已修改</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_entern1_character">
      <source>Enter:\n(1 character) </source>
      <translation variants="no">輸入：(1個字元)</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_1_about_to_call">
      <source>%1 about to call</source>
      <translation variants="no">%[46]1即將撥號</translation>
    </message>
    <message numerus="no" id="txt_short_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">zh_tw ##SIM Services</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_sim_services_not_available">
      <source>SIM services not available</source>
      <translation variants="no">系統業者服務無法使用</translation>
    </message>
    <message numerus="no" id="txt_simatk_dblist_val_sim_service_information_on_h">
      <source>Sim service information on Homescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">首頁畫面的系統業者服務資訊</lengthvariant>
        <lengthvariant priority="2">zh_tw #Operator serv. on Home scr.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_simatk_titlw_cmcc_sim_services">
      <source>CMCC SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">CMCC系統業者服務</lengthvariant>
        <lengthvariant priority="2">CMCC系統服務</lengthvariant>
      </translation>
    </message>
  </context>
</TS>