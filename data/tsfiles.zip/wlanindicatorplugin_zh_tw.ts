<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dblist_indi_menu_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_wireless_lan_val_not_connected">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">未連線</lengthvariant>
      </translation>
    </message>
  </context>
</TS>