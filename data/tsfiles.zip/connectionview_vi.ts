<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_list_name">
      <source>Name</source>
      <translation variants="no">vi #Name</translation>
    </message>
    <message numerus="no" id="txt_occ_button_disconnect_all">
      <source>Disconnect all</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngắt tất cả kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Ngắt kết nối</translation>
    </message>
    <message numerus="no" id="txt_occ_info_no_active_connections">
      <source>No active connections</source>
      <translation variants="no">(không có kết nối hoạt động)</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_connection_details">
      <source>Connection details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết kết nối</lengthvariant>
      </translation>
    </message>
  </context>
</TS>