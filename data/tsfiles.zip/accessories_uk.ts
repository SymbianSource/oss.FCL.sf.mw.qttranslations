<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_accessories_dpophead_headphones">
      <source>Headphones</source>
      <translation variants="no">uk #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="no">uk #4:3</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_on">
      <source>On</source>
      <translation variants="no">uk #On</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_music_stand">
      <source>Music stand</source>
      <translation variants="no">uk #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Accessory</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headse">
      <source>Headset</source>
      <translation variants="no">uk #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">uk #Wireless car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">uk #Wireless car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">uk #TV aspect ratio</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headset">
      <source>Headset</source>
      <translation variants="no">uk #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">uk #Accessory type</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headset">
      <source>Headset</source>
      <translation variants="no">uk #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Wired car kit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_tty">
      <source>TTY</source>
      <translation variants="no">uk #Text phone</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_wired">
      <source>Wired carkit</source>
      <translation variants="no">uk #Wired car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_loopset">
      <source>Loopset</source>
      <translation variants="no">uk #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="no">uk #16:9</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">uk #Wired car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">uk #Wired car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_loopset">
      <source>Loopset</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Loopset</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_music">
      <source>Music stand</source>
      <translation variants="no">uk #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights">
      <source>Lights</source>
      <translation variants="no">uk #Lights</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_tty">
      <source>TTY</source>
      <translation variants="no">uk #Text phone</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Text phone</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Headset</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Wireless car kit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="no">uk #Text phone</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_loopset">
      <source>Loopset</source>
      <translation variants="no">uk #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_music_stand">
      <source>Music stand</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Music stand</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Accessory settings</lengthvariant>
        <lengthvariant priority="2">uk #Accessory sett.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_music_stand">
      <source>Music stand</source>
      <translation variants="no">uk #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_automatic">
      <source>Automatic</source>
      <translation variants="no">uk #Automatic</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_loopse">
      <source>Loopset</source>
      <translation variants="no">uk #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headphones">
      <source>Headphones</source>
      <translation variants="no">uk #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headphones">
      <source>Headphones</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Headphones</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headph">
      <source>Headphones</source>
      <translation variants="no">uk #Headphones</translation>
    </message>
  </context>
</TS>