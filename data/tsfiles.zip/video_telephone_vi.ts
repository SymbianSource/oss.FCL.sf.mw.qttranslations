<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_caption_video_telephone">
      <source>Video telephone</source>
      <translation variants="no">vi ##Video telephone</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_swap_views">
      <source>Swap views</source>
      <translation variants="no">Ch.đổi các chế độ xem</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_open_keypad">
      <source>Open keypad</source>
      <translation variants="no">Mở bàn phím</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_enable_camera">
      <source>Enable camera</source>
      <translation variants="no">Bật camera</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_share_image">
      <source>Share image</source>
      <translation variants="no">Chia sẻ hình ảnh</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_zoom">
      <source>Zoom</source>
      <translation variants="no">Zoom</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_change_camera">
      <source>Change camera</source>
      <translation variants="no">T.đổi camera đang dùng</translation>
    </message>
    <message numerus="no" id="txt_vt_title_video_call">
      <source>Video call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi video</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vt_menu_disable_camera">
      <source>Disable camera</source>
      <translation variants="no">Vô hiệu camera</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_stop_sharing">
      <source>Stop sharing</source>
      <translation variants="no">Ngừng chia sẻ</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_swap_views">
      <source>Swap views</source>
      <translation variants="no">Ch.đổi các chế độ xem</translation>
    </message>
    <message numerus="no" id="txt_vt_custom_private_number">
      <source>Private number</source>
      <translation variants="no">vi ##Private number</translation>
    </message>
    <message numerus="no" id="txt_vt_custom_unknown_number">
      <source>Unknown number</source>
      <translation variants="no">vi ##Unknown number</translation>
    </message>
    <message numerus="no" id="txt_vt_button_end_call">
      <source>End call</source>
      <translation variants="no">vi ##End call</translation>
    </message>
    <message numerus="no" id="txt_long_caption_video_telephone">
      <source>Video telephone</source>
      <translation variants="no">Cuộc gọi video</translation>
    </message>
    <message numerus="no" id="txt_vt_info_allow_own_image_to_be_sent">
      <source>Allow own image to be sent?</source>
      <translation variants="no">Cho phép gửi hình ảnh video đến người gọi?</translation>
    </message>
    <message numerus="no" id="txt_vt_dblist_ongoing_video_call">
      <source>Ongoing video call</source>
      <translation variants="no">vi #Ongoing video call</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_zoom">
      <source>Zoom </source>
      <translation variants="no">Zoom</translation>
    </message>
  </context>
</TS>