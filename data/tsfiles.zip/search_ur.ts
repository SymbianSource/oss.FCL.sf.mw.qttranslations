<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_caption_search">
      <source>Search</source>
      <translation variants="no">ur #Search</translation>
    </message>
    <message numerus="no" id="txt_search_list_media">
      <source>Media</source>
      <translation variants="no">ur #Media</translation>
    </message>
    <message numerus="no" id="txt_short_caption_search">
      <source>Search</source>
      <translation variants="no">ur #Search</translation>
    </message>
    <message numerus="no" id="txt_search_info_select_search_scope">
      <source>Select search scope:</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Select search scope:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_select_all">
      <source>Select all</source>
      <translation variants="no">ur #Select all</translation>
    </message>
    <message numerus="no" id="txt_search_list_calendarnotes">
      <source>Calendar &amp; Notes</source>
      <translation variants="no">ur #Calendar &amp; Notes</translation>
    </message>
    <message numerus="no" id="txt_search_title_search">
      <source>Search</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Search</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_all_other_files">
      <source>All other files</source>
      <translation variants="no">ur #All other files</translation>
    </message>
    <message numerus="no" id="txt_search_list_contatcs">
      <source>Contacts</source>
      <translation variants="no">ur #Contacts</translation>
    </message>
    <message numerus="no" id="txt_long_caption_search">
      <source>Search</source>
      <translation variants="no">ur #Search</translation>
    </message>
    <message numerus="no" id="txt_search_list_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">ur #Bookmarks</translation>
    </message>
    <message numerus="no" id="txt_search_list_device">
      <source>Device</source>
      <translation variants="no">ur #Device</translation>
    </message>
    <message numerus="no" id="txt_search_title_search_scope">
      <source>Search scope</source>
      <translation variants="no">ur #Search scope</translation>
    </message>
    <message numerus="no" id="txt_search_dialog_search_internet">
      <source>Search internet</source>
      <translation variants="no">ur #Search internet</translation>
    </message>
    <message numerus="no" id="txt_search_dialog_search_device">
      <source>Search device</source>
      <translation variants="no">ur #Search device</translation>
    </message>
    <message numerus="no" id="txt_search_list_internet">
      <source>Internet</source>
      <translation variants="no">ur #Internet</translation>
    </message>
    <message numerus="no" id="txt_search_list_search_for_1">
      <source>Search for "%1" </source>
      <translation variants="no">ur #Search for "%1" </translation>
    </message>
    <message numerus="no" id="txt_search_list_messagemail">
      <source>Message &amp; Mail</source>
      <translation variants="no">ur #Message &amp; Mail</translation>
    </message>
    <message numerus="no" id="txt_search_list_applications">
      <source>Applications</source>
      <translation variants="no">ur #Applications</translation>
    </message>
    <message numerus="no" id="txt_search_list_no_match_found">
      <source>No Match Found</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #No Match Found</lengthvariant>
      </translation>
    </message>
  </context>
</TS>