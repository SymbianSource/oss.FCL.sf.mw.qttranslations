<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port">
      <source>Incoming port</source>
      <translation variants="no">uk #Incoming port</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_user">
      <source>User authentication</source>
      <translation variants="no">uk #User authentication</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_on_starttls">
      <source>On (StartTLS)</source>
      <translation variants="no">uk #On (StartTLS)</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_security">
      <source>Incoming secure connection</source>
      <translation variants="no">uk #Incoming secure connection</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port_default">
      <source>Default</source>
      <translation variants="no">uk #Default</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_port">
      <source>Outgoing port</source>
      <translation variants="no">uk #Outgoing port</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path_val_default">
      <source>Default</source>
      <translation variants="no">uk #Default</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path">
      <source>Folder path</source>
      <translation variants="no">uk #Folder path</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mailips">
      <source>Mail</source>
      <translation variants="no">uk #Mail</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_inbox_path_user_defined">
      <source>User defined</source>
      <translation variants="no">uk #User defined</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port_user_defined">
      <source>User defined</source>
      <translation variants="no">uk #User defined</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_security">
      <source>Outgoing secure connection</source>
      <translation variants="no">uk #Outgoing secure connection</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path_user_defined">
      <source>User defined</source>
      <translation variants="no">uk #User defined</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_same">
      <source>Same as for incoming</source>
      <translation variants="no">uk #Same as for incoming</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_none">
      <source>None</source>
      <translation variants="no">uk #None</translation>
    </message>
    <message numerus="no" id="txt_mailnips_setlabel_signature">
      <source>Signature</source>
      <translation variants="no">uk #Signature</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_preferences">
      <source>Preferences</source>
      <translation variants="no">Установки облікового запису</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_day_end_time">
      <source>Day end time</source>
      <translation variants="no">Час закінчення дня</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">Адреса електронної пошти</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_connection">
      <source>Connection</source>
      <translation variants="no">З’єднання</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_uptodate_during">
      <source>The mailbox is up-to-date during daytime</source>
      <translation variants="no">Вміст поштової скриньки підтримується в оновленому стані в денний час</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_reply_to_address">
      <source>Reply to address</source>
      <translation variants="no">Адреса для відповіді</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_fetch_manua">
      <source>Fetch manually</source>
      <translation variants="no">Завант. пошту вручну</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_port">
      <source>Port</source>
      <translation variants="no">Порт</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_receiving_weekdays">
      <source>Receiving weekdays</source>
      <translation variants="no">Дні завантаження</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_receiving_schedule">
      <source>Receiving Schedule</source>
      <translation variants="no">Розклад завантаження</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_user_info">
      <source>User info</source>
      <translation variants="no">Установки користувача</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_refresh_during_daytime_val_of">
      <source>Off</source>
      <translation variants="no">Вимкн.</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_save_energy">
      <source>Save energy</source>
      <translation variants="no">Збереження енергії</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_mail_server">
      <source>Incoming mail server</source>
      <translation variants="no">Сервер вхідної пошти</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_wed">
      <source>Wed</source>
      <translation variants="no">Середа</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_inbox_path">
      <source>Inbox path</source>
      <translation variants="no">Шлях до папки "Вхідні"</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_refresh_during_daytime_val_on">
      <source>On (SLL/TLS)</source>
      <translation variants="no">Увімкн. (SSL/TLS)</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_tue">
      <source>Tue</source>
      <translation variants="no">Вівторок</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_thu">
      <source>Thu</source>
      <translation variants="no">Четвер</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_mail_server">
      <source>Outgoing mail server</source>
      <translation variants="no">Сервер вихідної пошти</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_show_mail_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">Показ. листи в пап. "Вхідні"</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_fri">
      <source>Fri</source>
      <translation variants="no">П’ятниця</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode">
      <source>Selected mode</source>
      <translation variants="no">Викор. варіант оновлення</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_username">
      <source>Username</source>
      <translation variants="no">Ім’я користувача</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_only_by">
      <source>The mailbox is refreshed only by user request</source>
      <translation variants="no">Вміст поштової скриньки оновлюється тільки за запуску оновлення вручну користувачем</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_day_start_time">
      <source>Day start time</source>
      <translation variants="no">Час початку дня</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_secure_connection">
      <source>Secure connection</source>
      <translation variants="no">Захищене з’єднання</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_every_day">
      <source>Every day</source>
      <translation variants="no">Щодня</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">Оновити поштову скриньку</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_mailbox_name">
      <source>Mailbox name</source>
      <translation variants="no">Назва поштової скриньки</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_mail_authentication">
      <source>User authentication</source>
      <translation variants="no">Автентифікація користувача</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_my_name">
      <source>My name</source>
      <translation variants="no">Моє ім’я</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_keep_upto">
      <source>Keep up-to-date</source>
      <translation variants="no">Своєчасно оновлювати</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_show_mail_in_other_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">Показ. листи в інших папках</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_password">
      <source>Password</source>
      <translation variants="no">Пароль</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_mon">
      <source>Mon</source>
      <translation variants="no">Понеділок</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_server_info">
      <source>Server info</source>
      <translation variants="no">Установки сервера</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="no">Кожні 4 години</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="no">Кожні 15 хвилин</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_off">
      <source>Off</source>
      <translation variants="no">uk #Off</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_on_ssltls">
      <source>On (SLL/TLS)</source>
      <translation variants="no">uk #On (SLL/TLS)</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_keep_uptodate">
      <source>Keep up-to-date</source>
      <translation variants="no">Своєчасно оновлювати</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_sun">
      <source>Sun</source>
      <translation variants="no">Неділя</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_inbox_path_val_default">
      <source>Default</source>
      <translation variants="no">Стандартний</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_user_define">
      <source>User defined</source>
      <translation variants="no">Визначає користувач</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_1_hour">
      <source>Every 1 hour</source>
      <translation variants="no">uk #Every 1 hour</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_sat">
      <source>Sat</source>
      <translation variants="no">Субота</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_when_i_open_mailbox">
      <source>When I open mailbox</source>
      <translation variants="no">Коли я відкриваю поштову скриньку</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_every_15">
      <source>The mailbox is refreshed every 15 minutes during daytime</source>
      <translation variants="no">Вміст поштової скриньки оновлюється кожні 15 хвилин у денний час</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_all">
      <source>All</source>
      <translation variants="no">Усі</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_version_l1">
      <source>Version: %[]1</source>
      <translation variants="no">uk #Version: %[512]1</translation>
    </message>
    <message numerus="no" id="txt_mailips_button_delete_mailbox">
      <source>Delete mailbox</source>
      <translation variants="no">Видалити поштову скриньку</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_as_defin">
      <source>The mailbox is refreshed as defined by the user</source>
      <translation variants="no">Вміст поштової скриньки оновлюється в час, визначений користувачем</translation>
    </message>
  </context>
</TS>