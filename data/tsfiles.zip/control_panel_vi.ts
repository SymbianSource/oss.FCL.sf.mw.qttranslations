<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cp_title_control_panel">
      <source>Control Panel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bảng điều khiển</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_45_seconds">
      <source>45 seconds</source>
      <translation variants="no">45 giây</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_wallpaper">
      <source>Wallpaper</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hình nền</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Tự động</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_manual">
      <source>Manual</source>
      <translation variants="no">Thủ công</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_dual_mode">
      <source>Dual mode</source>
      <translation variants="no">Chế độ song song</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_accessibility_val_adjust_accessibili">
      <source>Adjust accessibility options</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa cài đặt phụ kiện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_setup">
      <source>Setup</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thiết lập</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_touch_screen_vibra">
      <source>Touch screen vibra</source>
      <translation variants="no">Rung</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Tự động</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_about">
      <source>About</source>
      <translation variants="no">Giới thiệu ứng dụng</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_select_tone_type">
      <source>Select tone type</source>
      <translation variants="no">Chọn loại nhạc chuông</translation>
    </message>
    <message numerus="no" id="txt_cp_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc họp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_15_seconds">
      <source>15 seconds</source>
      <translation variants="no">15 giây</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_theme">
      <source>Select theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn giao diện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_2_minutes">
      <source>2 minutes</source>
      <translation variants="no">2 phút</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_volume">
      <source>Volume</source>
      <translation variants="no">Âm lượng</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đặt lại cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">Các phím và màn hình</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_email_tone">
      <source>E-mail tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo e-mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_in_offline_mode_all_wireless_communica">
      <source>In offline mode all wireless communication is turned off.</source>
      <translation variants="no">Tất cả kết nối không dây đều bị đóng</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_operator">
      <source>Select operator</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn nhà điều hành</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_umts">
      <source>UMTS</source>
      <translation variants="no">3G</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_home_network">
      <source>Data usage in home network</source>
      <translation variants="no">Sử dụng dữ liệu trong mạng chủ</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_offline_mode_val_off">
      <source>Off</source>
      <translation variants="no">Đã tắt</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">Ngôn ngữ soạn thảo chính</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode">
      <source>Network mode</source>
      <translation variants="no">Chế độ mạng</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_reset">
      <source>Reset</source>
      <translation variants="no">Đặt lại cài đặt</translation>
    </message>
    <message numerus="no" id="txt_cp_list_tone">
      <source>Tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc chuông</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device">
      <source>Device</source>
      <translation variants="no">Điện thoại</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_connectivity">
      <source>Connectivity</source>
      <translation variants="no">Kết nối</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giao diện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reminder_tone">
      <source>Reminder tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo lịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Tự động</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection">
      <source>Operator selection</source>
      <translation variants="no">Chọn nhà điều hành</translation>
    </message>
    <message numerus="no" id="txt_cp_info_rotate_the_display_content_automatical">
      <source>Rotate the display content automatically when you turn the device on horizontal or back to a vertical position.</source>
      <translation variants="no">Tự động xoay nội dung trên màn hình khi thay đổi hướng thiết bị</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_key_and_touchscreen_tones">
      <source>Key and touchscreen tones</source>
      <translation variants="no">Âm phím</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_roaming">
      <source>Data usage when roaming</source>
      <translation variants="no">Sử dụng dữ liệu khi chuyển vùng</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_mobile_network">
      <source>Mobile network</source>
      <translation variants="no">Mạng di động</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="no">Các phím và màn hình</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_brightness">
      <source>Brightness</source>
      <translation variants="no">Độ sáng</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mạng di động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thông tin về ứng dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_no_tone">
      <source>No tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_preview_1">
      <source>Preview: %1</source>
      <translation variants="no">Xem trước: %[20]1</translation>
    </message>
    <message numerus="no" id="txt_cp_list_autorotate_display">
      <source>Auto-rotate display</source>
      <translation variants="no">Tự động xoay màn hình</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Đã tắt</translation>
    </message>
    <message numerus="no" id="txt_cp_info_no_operators_found">
      <source>No operators found.</source>
      <translation variants="no">Không tìm thấy nhà điều hành.</translation>
    </message>
    <message numerus="no" id="txt_cp_info_updating">
      <source>Updating operator list</source>
      <translation variants="no">Đang cập nhật danh sách nhà điều hành</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language_val_non">
      <source>None</source>
      <translation variants="no">Không có</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_confirm">
      <source>Confirm</source>
      <translation variants="no">Luôn hỏi</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_power_management">
      <source>Power management</source>
      <translation variants="yes">
        <lengthvariant priority="1">Quản lý nguồn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Ngắt kết nối</translation>
    </message>
    <message numerus="no" id="txt_cp_button_silence">
      <source>Silence</source>
      <translation variants="no">Im lặng</translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_must_be_disconnected_befo">
      <source>Active calls must be disconnected before operator selection.</source>
      <translation variants="no">Phải ngắt kết nối các cuộc gọi hiện tại trước khi chọn nhà điều hành</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">Âm lượng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset">
      <source>Settings reset</source>
      <translation variants="no">Đặt lại cài đặt</translation>
    </message>
    <message numerus="no" id="txt_cp_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">Rung</translation>
    </message>
    <message numerus="no" id="txt_cp_info_restore_original_settings_no_data_wil">
      <source>Restore original settings? No data will be deleted.</source>
      <translation variants="no">Khôi phục cài đặt gốc? Không có dữ liệu nào sẽ bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_ringtone">
      <source>Ringtone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc chuông</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_meeting">
      <source>Meeting</source>
      <translation variants="no">Cuộc họp</translation>
    </message>
    <message numerus="no" id="txt_cp_info_no_access_to_selected_operators_netwo">
      <source>No access to selected operator’s network.</source>
      <translation variants="no">Không thể truy cập mạng của nhà điều hành đã chọn</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_personalization">
      <source>Personalization</source>
      <translation variants="no">Cài đặt riêng</translation>
    </message>
    <message numerus="no" id="txt_cp_general">
      <source>General</source>
      <translation variants="no">Bình thường</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_tones_that_play_when_you_select">
      <source>Select tones that play when you select the profile named:</source>
      <translation variants="no">Chọn nhạc chuông sẽ được  sử dụng khi profile này được chọn:</translation>
    </message>
    <message numerus="no" id="txt_cp_info_delete_all_data_and_restore_original_s">
      <source>Delete all data and restore original settings? Ejectable memory card data is not deleted.</source>
      <translation variants="no">Xóa tất cả dữ liệu và khôi phục cài đặt gốc? Dữ liệu trên thẻ nhớ tháo lắp được sẽ không bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngôn ngữ và vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_regional_settings">
      <source>Regional settings</source>
      <translation variants="no">Cài đặt vùng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset_val_reset_settings">
      <source>Reset settings</source>
      <translation variants="no">Đặt lại cài đặt</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">vi ##Control Panel</translation>
    </message>
    <message numerus="no" id="txt_cp_title_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt nâng cao</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_confirm">
      <source>Confirm</source>
      <translation variants="no">Luôn hỏi</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_language_and_region">
      <source>Language and region</source>
      <translation variants="no">Ngôn ngữ và vùng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Đã tắt</translation>
    </message>
    <message numerus="no" id="txt_cp_title_end_encryption">
      <source>End encryption</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kết thúc mã hóa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn profile</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_your_region">
      <source>Select your region:</source>
      <translation variants="no">Chọn vùng của bạn:</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_not_connected">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chưa kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_end">
      <source>End</source>
      <translation variants="no">Kết thúc</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_display_language">
      <source>Display language</source>
      <translation variants="no">Ngôn ngữ hiển thị</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_tones">
      <source>Get more tones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chuyển đến Mục lưu trữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_original_settings_will_be_restored_no">
      <source>Original settings will be restored. No data will be deleted.</source>
      <translation variants="no">Cài đặt gốc sẽ được khôi phục. Không có dữ liệu nào sẽ bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_long_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">Bảng điều khiển</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Profile</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_operator_selection_is_not_possible_in">
      <source>Operator selection is not possible in Offline.</source>
      <translation variants="no">Không thể chọn nhà điều hành ở chế độ offline</translation>
    </message>
    <message numerus="no" id="txt_cp_button_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Cài đặt nâng cao</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_gsm">
      <source>GSM</source>
      <translation variants="no">GSM</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_30_seconds">
      <source>30 seconds</source>
      <translation variants="no">30 giây</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_val_change_language">
      <source>Change language</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa cài đặt ngôn ngữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset_val_reset_your_device">
      <source>Reset your device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khôi phục cài đặt gốc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_edit_name">
      <source>Edit name</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa tên</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_heading_profile_name">
      <source>Profile name: </source>
      <translation variants="no">Tên profile:</translation>
    </message>
    <message numerus="no" id="txt_cp_button_touch_screen_calibration">
      <source>Touch screen calibration</source>
      <translation variants="no">Cân chỉnh màn hình cảm ứng</translation>
    </message>
    <message numerus="no" id="txt_cp_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bình thường</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_message_tone">
      <source>Message tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo tin nhắn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_edit_name">
      <source>Edit name</source>
      <translation variants="no">Chỉnh sửa tên</translation>
    </message>
    <message numerus="no" id="txt_cp_list_notification_tones">
      <source>Notification tones</source>
      <translation variants="no">Nhạc chuông thông báo</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active">
      <source>Silent state active</source>
      <translation variants="no">Hiện đang ở trạng thái im lặng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset_val_reset_device">
      <source>Reset device</source>
      <translation variants="no">Đặt lại thiết bị</translation>
    </message>
    <message numerus="no" id="txt_cp_info_all_data_will_be_deleted_and_factory_s">
      <source>All data will be deleted and factory settings will be restored. Ejectable memory card data is not deleted.</source>
      <translation variants="no">Tất cả dữ liệu sẽ bị xóa và cài đặt gốc được khôi phục. Dữ liệu trên thẻ nhớ tháo lắp được sẽ không bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_001">
      <source>1%</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_locked_after">
      <source>Keys &amp; screen locked after</source>
      <translation variants="no">Khóa phím và màn hình sau:</translation>
    </message>
    <message numerus="no" id="txt_cp_list_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm nhạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_offline_mode_val_on">
      <source>On</source>
      <translation variants="no">Đã kích hoạt</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_1_minute">
      <source>1 minute</source>
      <translation variants="no">1 phút</translation>
    </message>
    <message numerus="no" id="txt_cp_info_setup_is_not_completed_would_you_lik">
      <source>Setup is not completed. 
Would you like to complete it now?</source>
      <translation variants="no">Thiết lập thiết bị chưa được hoàn tất. Hoàn tất ngay bây giờ?</translation>
    </message>
    <message numerus="no" id="txt_cp_list_recording">
      <source>Recording</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đang ghi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_security">
      <source>Security</source>
      <translation variants="no">Bảo mật</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">Ngôn ngữ soạn thảo phụ</translation>
    </message>
    <message numerus="no" id="txt_cp_info_data_encryption_ongoing_enryption_mus">
      <source>Data encryption ongoing. Enryption must be ended before reset.  End data enrcyption?</source>
      <translation variants="no">Đang mã hóa dữ liệu. Mã hóa phải được kết thúc trước khi đặt lại. Kết thúc mã hóa dữ liệu?</translation>
    </message>
    <message numerus="no" id="txt_short_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">vi #Control panel</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active_val_clock_alarm">
      <source>Clock alarm at %1</source>
      <translation variants="no">Âm báo giờ lúc %1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_and_connections_must_be_d">
      <source>Active calls and connections must be disconnected before reset.</source>
      <translation variants="no">Phải ngắt kết nối các cuộc gọi và kết nối hiện tại trước khi đặt lại</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset">
      <source>Device reset</source>
      <translation variants="no">Đặt lại thiết bị</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_offline_airplane_mode">
      <source>Offline (Airplane Mode)</source>
      <translation variants="no">Offline (Chế độ trên Máy bay)</translation>
    </message>
  </context>
</TS>