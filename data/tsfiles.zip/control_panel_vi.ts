<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_confirm">
      <source>Confirm</source>
      <translation variants="no">Luôn hỏi</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset">
      <source>Settings reset</source>
      <translation variants="no">Đặt lại cài đặt</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_power_management">
      <source>Power management</source>
      <translation variants="yes">
        <lengthvariant priority="1">Quản lý nguồn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">Rung</translation>
    </message>
    <message numerus="no" id="txt_cp_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Ngắt kết nối</translation>
    </message>
    <message numerus="no" id="txt_cp_button_silence">
      <source>Silence</source>
      <translation variants="no">Im lặng</translation>
    </message>
    <message numerus="no" id="txt_cp_info_restore_original_settings_no_data_wil">
      <source>Restore original settings? No data will be deleted.</source>
      <translation variants="no">Khôi phục cài đặt gốc? Không có dữ liệu nào sẽ bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_cp_button_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Cài đặt nâng cao</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_ringtone">
      <source>Ringtone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc chuông</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc họp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_must_be_disconnected_befo">
      <source>Active calls must be disconnected before operator selection.</source>
      <translation variants="no">Phải ngắt kết nối các cuộc gọi hiện tại trước khi chọn nhà điều hành</translation>
    </message>
    <message numerus="no" id="txt_cp_info_no_access_to_selected_operators_netwo">
      <source>No access to selected operator’s network.</source>
      <translation variants="no">Không thể truy cập mạng của nhà điều hành đã chọn</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_personalization">
      <source>Personalization</source>
      <translation variants="no">Cài đặt riêng</translation>
    </message>
    <message numerus="no" id="txt_cp_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bình thường</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_tones_that_play_when_you_select">
      <source>Select tones that play when you select the profile named:</source>
      <translation variants="no">Chọn nhạc chuông sẽ được  sử dụng khi profile này được chọn:</translation>
    </message>
    <message numerus="no" id="txt_cp_info_delete_all_data_and_restore_original_s">
      <source>Delete all data and restore original settings? Ejectable memory card data is not deleted.</source>
      <translation variants="no">Xóa tất cả dữ liệu và khôi phục cài đặt gốc? Dữ liệu trên thẻ nhớ tháo lắp được sẽ không bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Đã tắt</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngôn ngữ và vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_no_operators_found">
      <source>No operators found.</source>
      <translation variants="no">Không tìm thấy nhà điều hành.</translation>
    </message>
    <message numerus="no" id="txt_cp_title_edit_name">
      <source>Edit name</source>
      <translation variants="no">Chỉnh sửa tên</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset_val_reset_settings">
      <source>Reset settings</source>
      <translation variants="no">Đặt lại cài đặt</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">vi #Control Panel</translation>
    </message>
    <message numerus="no" id="txt_cp_info_updating">
      <source>Updating operator list</source>
      <translation variants="no">Đang cập nhật danh sách nhà điều hành</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language_val_non">
      <source>None</source>
      <translation variants="no">Không có</translation>
    </message>
    <message numerus="no" id="txt_cp_title_profile">
      <source>Profile</source>
      <translation variants="no">Chọn profile</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_your_region">
      <source>Select your region:</source>
      <translation variants="no">Chọn vùng của bạn:</translation>
    </message>
    <message numerus="no" id="txt_cp_button_end">
      <source>End</source>
      <translation variants="no">Kết thúc</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_display_language">
      <source>Display language</source>
      <translation variants="no">Ngôn ngữ hiển thị</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_tones">
      <source>Fetch from Ovi</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chuyển đến Mục lưu trữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_original_settings_will_be_restored_no">
      <source>Original settings will be restored. No data will be deleted.</source>
      <translation variants="no">Cài đặt gốc sẽ được khôi phục. Không có dữ liệu nào sẽ bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_long_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">Bảng điều khiển</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Profile</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_regional_settings">
      <source>Regional settings</source>
      <translation variants="no">Cài đặt vùng</translation>
    </message>
    <message numerus="no" id="txt_cp_title_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt nâng cao</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_confirm">
      <source>Confirm</source>
      <translation variants="no">Luôn hỏi</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_language_and_region">
      <source>Language and region</source>
      <translation variants="no">Ngôn ngữ và vùng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Đã tắt</translation>
    </message>
    <message numerus="no" id="txt_cp_title_end_encryption">
      <source>End encryption</source>
      <translation variants="no">Kết thúc mã hóa</translation>
    </message>
    <message numerus="no" id="txt_cp_list_edit_name">
      <source>Edit name</source>
      <translation variants="no">Chỉnh sửa tên</translation>
    </message>
    <message numerus="no" id="txt_cp_info_data_encryption_ongoing_enryption_mus">
      <source>Data encryption ongoing. Enryption must be ended before reset.  End data enrcyption?</source>
      <translation variants="no">Đang mã hóa dữ liệu. Mã hóa phải được kết thúc trước khi đặt lại. Kết thúc mã hóa dữ liệu?</translation>
    </message>
    <message numerus="no" id="txt_cp_list_notification_tones">
      <source>Notification tones</source>
      <translation variants="no">Nhạc chuông thông báo</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active">
      <source>Silent state active</source>
      <translation variants="no">Hiện đang ở trạng thái im lặng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset_val_reset_device">
      <source>Reset device</source>
      <translation variants="no">Đặt lại thiết bị</translation>
    </message>
    <message numerus="no" id="txt_cp_info_all_data_will_be_deleted_and_factory_s">
      <source>All data will be deleted and factory settings will be restored. Ejectable memory card data is not deleted.</source>
      <translation variants="no">Tất cả dữ liệu sẽ bị xóa và cài đặt gốc được khôi phục. Dữ liệu trên thẻ nhớ tháo lắp được sẽ không bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_cp_button_offline">
      <source>Offline</source>
      <translation variants="no">vi #Offline</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_type">
      <source>Type</source>
      <translation variants="no">vi #Type</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_13">
      <source>Open Dynamics Engine
Copyright (c) 2001-2004, Russell L. Smith.
All rights reserved.

Redistribution and use in source and binary forms, 
with or without modification, are permitted provided
that the following conditions are met:

Redistributions of source code must retain the above 
copyright notice, this list of conditions and the 
following disclaimer.

Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or 
other materials provided with the distribution.

Neither the names of ODE's copyright owner nor the 
names of its contributors may be used to endorse or 
promote products derived from this software without 
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS 
AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.</source>
      <translation variants="no">vi #Open Dynamics Engine
Copyright (c) 2001-2004, Russell L. Smith.
All rights reserved.

Redistribution and use in source and binary forms, 
with or without modification, are permitted provided
that the following conditions are met:

Redistributions of source code must retain the above 
copyright notice, this list of conditions and the 
following disclaimer.

Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or 
other materials provided with the distribution.

Neither the names of ODE's copyright owner nor the 
names of its contributors may be used to endorse or 
promote products derived from this software without 
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS 
AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_3rd_party_notices">
      <source>3rd party notices</source>
      <translation variants="no">vi #3rd party notices</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_6">
      <source>Copyright (c) 2004, 2005 Apple Computer, Inc.
Copyright (c) 1997-2005 University of Cambridge
All rights reserved.
Copyright (c) 2005, Google Inc.
All rights reserved.
Copyright (c) 2006, Nokia Corporation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the University of Cambridge nor the name of Google
  Inc. nor the names of their contributors may be used to endorse or
  promote products derived from this software without specific prior
  written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">vi #Copyright (c) 2004, 2005 Apple Computer, Inc.
Copyright (c) 1997-2005 University of Cambridge
All rights reserved.
Copyright (c) 2005, Google Inc.
All rights reserved.
Copyright (c) 2006, Nokia Corporation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the University of Cambridge nor the name of Google
  Inc. nor the names of their contributors may be used to endorse or
  promote products derived from this software without specific prior
  written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_list_screensaver">
      <source>Screensaver</source>
      <translation variants="no">vi #Screensaver</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_5">
      <source>The author of this software is David M. Gay.

Copyright (c) 1991, 2000, 2001 by Lucent Technologies.

Permission to use, copy, modify, and distribute this software for any
purpose without fee is hereby granted, provided that this entire notice
is included in all copies of any software which is or includes a copy
or modification of this software and in all copies of the supporting
documentation for such software.

THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY.  IN PARTICULAR, NEITHER THE AUTHOR NOR LUCENT MAKES ANY
REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.</source>
      <translation variants="no">vi #The author of this software is David M. Gay.

Copyright (c) 1991, 2000, 2001 by Lucent Technologies.

Permission to use, copy, modify, and distribute this software for any
purpose without fee is hereby granted, provided that this entire notice
is included in all copies of any software which is or includes a copy
or modification of this software and in all copies of the supporting
documentation for such software.

THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY.  IN PARTICULAR, NEITHER THE AUTHOR NOR LUCENT MAKES ANY
REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.</translation>
    </message>
    <message numerus="no" id="txt_cp_info_software_vesion">
      <source>%1</source>
      <translation variants="no">vi #%1</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_7">
      <source>Copyright (c) 1994
Hewlett-Packard Company

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Hewlett-Packard Company makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</source>
      <translation variants="no">vi #Copyright (c) 1994
Hewlett-Packard Company

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Hewlett-Packard Company makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device_model">
      <source>%1</source>
      <translation variants="no">vi #%1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_1">
      <source>Nokia and Nokia Connecting People are trademarks or registered trademarks of Nokia Corporation.
 
Copyright 2011 Nokia. All rights reserved. 

This product is based on Symbian^4.

Other product and company names mentioned herein may be trademarks or tradenames of their respective owners. </source>
      <translation variants="no">vi #Nokia and Nokia Connecting People are trademarks or registered trademarks of Nokia Corporation.
 
Copyright 2011 Nokia. All rights reserved. 

This product is based on Symbian^4.

Other product and company names mentioned herein may be trademarks or tradenames of their respective owners. </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_10">
      <source>Copyright (c) 1995-2006 International Business Machines Corporation and others

All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, provided that the above copyright notice(s)
and this permission notice appear in all copies of the Software and that both the above
copyright notice(s) and this permission notice appear in supporting documentation.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 
Except as contained in this notice, the name of a copyright holder shall not be used in
advertising or otherwise to promote the sale, use or other dealings in this Software
without prior written authorization of the copyright holder.</source>
      <translation variants="no">vi #Copyright (c) 1995-2006 International Business Machines Corporation and others

All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, provided that the above copyright notice(s)
and this permission notice appear in all copies of the Software and that both the above
copyright notice(s) and this permission notice appear in supporting documentation.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 
Except as contained in this notice, the name of a copyright holder shall not be used in
advertising or otherwise to promote the sale, use or other dealings in this Software
without prior written authorization of the copyright holder.</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_themes">
      <source>Fetch from Ovi</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Fetch from Ovi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_product_release">
      <source>%1</source>
      <translation variants="no">vi #%1</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_product_release">
      <source>Product Release</source>
      <translation variants="no">vi #Product Release</translation>
    </message>
    <message numerus="no" id="txt_cp_info_processing">
      <source>Processing…</source>
      <translation variants="no">vi #Processing…</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_4">
      <source>Copyright (C) 2004, Apple Computer, Inc. and The Mozilla Foundation. 
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. Neither the names of Apple Computer, Inc. ("Apple") or The Mozilla
Foundation ("Mozilla") nor the names of their contributors may be used
to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY APPLE, MOZILLA AND THEIR CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE, MOZILLA OR
THEIR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">vi #Copyright (C) 2004, Apple Computer, Inc. and The Mozilla Foundation. 
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. Neither the names of Apple Computer, Inc. ("Apple") or The Mozilla
Foundation ("Mozilla") nor the names of their contributors may be used
to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY APPLE, MOZILLA AND THEIR CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE, MOZILLA OR
THEIR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_2">
      <source>This product includes API header files originally developed by Netscape Communications Corporation, modified by Nokia by changing certain variables for the  
purpose of porting the file to Symbian operating system on May 1st, 2004, and available in source code form under the Netscape Public License, v1.1 at  
http://www.forum.nokia.com/browserapi.</source>
      <translation variants="no">vi #This product includes API header files originally developed by Netscape Communications Corporation, modified by Nokia by changing certain variables for the  
purpose of porting the file to Symbian operating system on May 1st, 2004, and available in source code form under the Netscape Public License, v1.1 at  
http://www.forum.nokia.com/browserapi.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_9">
      <source>Copyright (c) 1983, 1995, 1996 Eric P. Allman
Copyright (c) 1988, 1993
 The Regents of the University of California.  All rights reserved.
Copyright (C) 2007 Nokia Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of the University nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.</source>
      <translation variants="no">vi #Copyright (c) 1983, 1995, 1996 Eric P. Allman
Copyright (c) 1988, 1993
 The Regents of the University of California.  All rights reserved.
Copyright (C) 2007 Nokia Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of the University nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_11">
      <source>Copyright (C) 2003, 2004, 2005, 2006 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2006, 2007 Alexey Proskuryakov (ap@nypop.com)
Copyright (C) 2006 Nikolas Zimmermann &lt;zimmermann@kde.org&gt;
Copyright (C) 2006 Samuel Weinig &lt;sam.weinig@gmail.com&gt;
Copyright (C) 2006 James G. Speth (speth@end.com)
Copyright (C) 2006 Jonas Witt &lt;jonas.witt@gmail.com&gt;
Copyright (C) 2006, 2007 Trolltech ASA
Copyright (C) 2005, 2006 Kimmo Kinnunen &lt;kimmo.t.kinnunen@nokia.com&gt;.
Copyright (C) 2006 Zack Rusin &lt;zack@kde.org&gt;
Copyright (C) 2007 Alp Toker &lt;alp@atoker.com&gt;
Copyright (C) 2007 Alp Toker &lt;alp.toker@collabora.co.uk&gt;
Copyright (C) 2007 Graham Dennis (graham.dennis@gmail.com)
Copyright (C) 2006 Don Gibson &lt;dgibson77@gmail.com&gt;
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2007 Holger Hans Peter Freyther
Copyright (C) 2007 Matt Lilek (pewtermoose@gmail.com).
Copyright (C) 2006 David Smith (catfish.man@gmail.com)
Copyright (C) 2006 George Staikos &lt;staikos@kde.org&gt;
Copyright (C) 2006 Simon Hausmann &lt;hausmann@kde.org&gt;
Copyright (C) 2006 Rob Buis &lt;buis@kde.org&gt;
Copyright (C) 2006 Dirk Mueller &lt;mueller@kde.org&gt;
Copyright (C) 2000-2001 Dawit Alemayehu &lt;adawit@kde.org&gt;
Copyright (C) 2006, 2007 Eric Seidel &lt;eric@webkit.org&gt;
Copyright (C) 2005, 2006 Alexander Kellett &lt;lypanov@kde.org&gt;
Copyright (C) 2005 Oliver Hunt &lt;ojh16@student.canterbury.ac.nz&gt;.  All rights reserved.
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2006 Enrico Ros &lt;enrico.ros@m31engineering.it&gt;
Copyright (C) 2007 Staikos Computing Services Inc. &lt;info@staikos.net&gt;
Copyright (C) 2006 Charles Samuels &lt;charles@kde.org&gt;
Copyright (C) 2007 Kevin Ollivier &lt;kevino@theolliviers.com&gt;
Copyright (C) 2007 Robin Dunn.  All rights reserved.
Copyright     2005 Frerich Raabe &lt;raabe@kde.org&gt;
Copyright     2005 Maksim Orlovich &lt;maksim@kde.org&gt;

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redis</source>
      <translation variants="no">vi #Copyright (C) 2003, 2004, 2005, 2006 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2006, 2007 Alexey Proskuryakov (ap@nypop.com)
Copyright (C) 2006 Nikolas Zimmermann &lt;zimmermann@kde.org&gt;
Copyright (C) 2006 Samuel Weinig &lt;sam.weinig@gmail.com&gt;
Copyright (C) 2006 James G. Speth (speth@end.com)
Copyright (C) 2006 Jonas Witt &lt;jonas.witt@gmail.com&gt;
Copyright (C) 2006, 2007 Trolltech ASA
Copyright (C) 2005, 2006 Kimmo Kinnunen &lt;kimmo.t.kinnunen@nokia.com&gt;.
Copyright (C) 2006 Zack Rusin &lt;zack@kde.org&gt;
Copyright (C) 2007 Alp Toker &lt;alp@atoker.com&gt;
Copyright (C) 2007 Alp Toker &lt;alp.toker@collabora.co.uk&gt;
Copyright (C) 2007 Graham Dennis (graham.dennis@gmail.com)
Copyright (C) 2006 Don Gibson &lt;dgibson77@gmail.com&gt;
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2007 Holger Hans Peter Freyther
Copyright (C) 2007 Matt Lilek (pewtermoose@gmail.com).
Copyright (C) 2006 David Smith (catfish.man@gmail.com)
Copyright (C) 2006 George Staikos &lt;staikos@kde.org&gt;
Copyright (C) 2006 Simon Hausmann &lt;hausmann@kde.org&gt;
Copyright (C) 2006 Rob Buis &lt;buis@kde.org&gt;
Copyright (C) 2006 Dirk Mueller &lt;mueller@kde.org&gt;
Copyright (C) 2000-2001 Dawit Alemayehu &lt;adawit@kde.org&gt;
Copyright (C) 2006, 2007 Eric Seidel &lt;eric@webkit.org&gt;
Copyright (C) 2005, 2006 Alexander Kellett &lt;lypanov@kde.org&gt;
Copyright (C) 2005 Oliver Hunt &lt;ojh16@student.canterbury.ac.nz&gt;.  All rights reserved.
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2006 Enrico Ros &lt;enrico.ros@m31engineering.it&gt;
Copyright (C) 2007 Staikos Computing Services Inc. &lt;info@staikos.net&gt;
Copyright (C) 2006 Charles Samuels &lt;charles@kde.org&gt;
Copyright (C) 2007 Kevin Ollivier &lt;kevino@theolliviers.com&gt;
Copyright (C) 2007 Robin Dunn.  All rights reserved.
Copyright     2005 Frerich Raabe &lt;raabe@kde.org&gt;
Copyright     2005 Maksim Orlovich &lt;maksim@kde.org&gt;

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redis</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices">
      <source>3rd party notices</source>
      <translation variants="no">vi #3rd party notices</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_8">
      <source>Copyright (c) 1996-1998
Silicon Graphics Computer Systems, Inc.

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Silicon Graphics makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</source>
      <translation variants="no">vi #Copyright (c) 1996-1998
Silicon Graphics Computer Systems, Inc.

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Silicon Graphics makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_14">
      <source>Copyright (c) 1998 - 2008, Paul Johnston &amp; Contributors
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of the author nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">vi #Copyright (c) 1998 - 2008, Paul Johnston &amp; Contributors
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of the author nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices">
      <source>Open source software notices</source>
      <translation variants="no">vi #Open source software notices</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_open_source_software_notices">
      <source>Open source software notices</source>
      <translation variants="no">vi #Open source software notices</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_3">
      <source>Copyright (C) 2005 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2007 Apple Inc.  All rights reserved.
Copyright (C) 2007 Nokia Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without

modification, are permitted provided that the following conditions
are met:

1.  Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer. 
2.  Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution. 
3.  Neither the name of Apple Computer, Inc. ("Apple") nor the names of
    its contributors may be used to endorse or promote products derived
    from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE AND ITS CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL APPLE OR ITS CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">vi #Copyright (C) 2005 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2007 Apple Inc.  All rights reserved.
Copyright (C) 2007 Nokia Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without

modification, are permitted provided that the following conditions
are met:

1.  Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer. 
2.  Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution. 
3.  Neither the name of Apple Computer, Inc. ("Apple") nor the names of
    its contributors may be used to endorse or promote products derived
    from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE AND ITS CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL APPLE OR ITS CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_software_version">
      <source>Software version</source>
      <translation variants="no">vi #Software version</translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices_1">
      <source>This product includes certain open source software. The exact terms of the licenses, disclaimers, acknowledgements and notices are provided below. Nokia offers to provide you with the source code as defined in the applicable license. 

Please send an e-mail to sourcecode.request@nokia.com or a written request to:

Source Code Requests
Nokia Corporation
P.O.Box 407
FI-00045 Nokia Group
Finland

This offer is valid for a period of three (3) years from the date of the distribution of this product by Nokia.</source>
      <translation variants="no">vi #This product includes certain open source software. The exact terms of the licenses, disclaimers, acknowledgements and notices are provided below. Nokia offers to provide you with the source code as defined in the applicable license. 

Please send an e-mail to sourcecode.request@nokia.com or a written request to:

Source Code Requests
Nokia Corporation
P.O.Box 407
FI-00045 Nokia Group
Finland

This offer is valid for a period of three (3) years from the date of the distribution of this product by Nokia.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_1">
      <source>Java and all Java-based marks are trademarks or registered trademarks of Sun Microsystems, Inc.
JavaTM ME environment: MIDP 2.1, CLDC 1.1.</source>
      <translation variants="no">vi #Java and all Java-based marks are trademarks or registered trademarks of Sun Microsystems, Inc.
JavaTM ME environment: MIDP 2.1, CLDC 1.1.</translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices_2">
      <source>   GNU LESSER GENERAL PUBLIC LICENSE
         Version 2.1, February 1999

 Copyright (C) 1991, 1999 Free Software Foundation, Inc.
     59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

[This is the first released version of the Lesser GPL.  It also counts
 as the successor of the GNU Library Public License, version 2, hence
 the version number 2.1.]

       Preamble

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
Licenses are intended to guarantee your freedom to share and change
free software--to make sure the software is free for all its users.

  This license, the Lesser General Public License, applies to some
specially designated software packages--typically libraries--of the
Free Software Foundation and other authors who decide to use it.  You
can use it too, but we suggest you first think carefully about whether
this license or the ordinary General Public License is the better
strategy to use in any particular case, based on the explanations below.

  When we speak of free software, we are referring to freedom of use,
not price.  Our General Public Licenses are designed to make sure that
you have the freedom to distribute copies of free software (and charge
for this service if you wish); that you receive source code or can get
it if you want it; that you can change the software and use pieces of
it in new free programs; and that you are informed that you can do
these things.

  To protect your rights, we need to make restrictions that forbid
distributors to deny you these rights or to ask you to surrender these
rights.  These restrictions translate to certain responsibilities for
you if you distribute copies of the library or if you modify it.

  For example, if you distribute copies of the library, whether gratis
or for a fee, you must give the rec</source>
      <translation variants="no">vi #   GNU LESSER GENERAL PUBLIC LICENSE
         Version 2.1, February 1999

 Copyright (C) 1991, 1999 Free Software Foundation, Inc.
     59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

[This is the first released version of the Lesser GPL.  It also counts
 as the successor of the GNU Library Public License, version 2, hence
 the version number 2.1.]

       Preamble

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
Licenses are intended to guarantee your freedom to share and change
free software--to make sure the software is free for all its users.

  This license, the Lesser General Public License, applies to some
specially designated software packages--typically libraries--of the
Free Software Foundation and other authors who decide to use it.  You
can use it too, but we suggest you first think carefully about whether
this license or the ordinary General Public License is the better
strategy to use in any particular case, based on the explanations below.

  When we speak of free software, we are referring to freedom of use,
not price.  Our General Public Licenses are designed to make sure that
you have the freedom to distribute copies of free software (and charge
for this service if you wish); that you receive source code or can get
it if you want it; that you can change the software and use pieces of
it in new free programs; and that you are informed that you can do
these things.

  To protect your rights, we need to make restrictions that forbid
distributors to deny you these rights or to ask you to surrender these
rights.  These restrictions translate to certain responsibilities for
you if you distribute copies of the library or if you modify it.

  For example, if you distribute copies of the library, whether gratis
or for a fee, you must give the rec</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_2_minutes">
      <source>2 minutes</source>
      <translation variants="no">2 phút</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_home_network">
      <source>Data usage in home network</source>
      <translation variants="no">Sử dụng dữ liệu trong mạng chủ</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_operator">
      <source>Select operator</source>
      <translation variants="no">Chọn nhà điều hành</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">Ngôn ngữ soạn thảo chính</translation>
    </message>
    <message numerus="no" id="txt_cp_list_tone">
      <source>Choose from tones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc chuông</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_val_change_language">
      <source>Change language</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa cài đặt ngôn ngữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_connectivity">
      <source>Connectivity</source>
      <translation variants="no">Kết nối</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_gsm">
      <source>GSM</source>
      <translation variants="no">GSM</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_reset">
      <source>Reset</source>
      <translation variants="no">Đặt lại cài đặt</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device">
      <source>Device</source>
      <translation variants="no">Điện thoại</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_30_seconds">
      <source>30 seconds</source>
      <translation variants="no">30 giây</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset_val_reset_your_device">
      <source>Reset your device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khôi phục cài đặt gốc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_key_and_touchscreen_tones">
      <source>Key and touchscreen tones</source>
      <translation variants="no">Âm phím</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giao diện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_roaming">
      <source>Data usage when roaming</source>
      <translation variants="no">Sử dụng dữ liệu khi chuyển vùng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Tự động</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_touch_screen_vibra">
      <source>Touch screen vibra</source>
      <translation variants="no">Rung</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection">
      <source>Operator selection</source>
      <translation variants="no">Chọn nhà điều hành</translation>
    </message>
    <message numerus="no" id="txt_cp_info_rotate_the_display_content_automatical">
      <source>Rotate the display content automatically when you turn the device on horizontal or back to a vertical position.</source>
      <translation variants="no">Tự động xoay nội dung trên màn hình khi thay đổi hướng thiết bị</translation>
    </message>
    <message numerus="no" id="txt_cp_list_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">Các phím và màn hình</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Tự động</translation>
    </message>
    <message numerus="no" id="txt_cp_info_in_offline_mode_all_wireless_communica">
      <source>In offline mode all wireless communication is turned off.</source>
      <translation variants="no">Tất cả kết nối không dây đều bị đóng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode">
      <source>Network mode</source>
      <translation variants="no">Chế độ mạng</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_accessibility_val_adjust_accessibili">
      <source>Adjust accessibility options</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa cài đặt phụ kiện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_setup">
      <source>Setup</source>
      <translation variants="no">Thiết lập</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Tự động</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_about">
      <source>About</source>
      <translation variants="no">Giới thiệu ứng dụng</translation>
    </message>
    <message numerus="no" id="txt_cp_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bình thường</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_volume">
      <source>Volume</source>
      <translation variants="no">Âm lượng</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_message_tone">
      <source>Message tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo tin nhắn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_email_tone">
      <source>E-mail tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo e-mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_15_seconds">
      <source>15 seconds</source>
      <translation variants="no">15 giây</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_theme">
      <source>Select theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn giao diện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đặt lại cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_umts">
      <source>UMTS</source>
      <translation variants="no">3G</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reminder_tone">
      <source>Reminder tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo lịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_control_panel">
      <source>Control Panel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bảng điều khiển</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_45_seconds">
      <source>45 seconds</source>
      <translation variants="no">45 giây</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_wallpaper">
      <source>Wallpaper</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hình nền</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_manual">
      <source>Manual</source>
      <translation variants="no">Thủ công</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_dual_mode">
      <source>Dual mode</source>
      <translation variants="no">Chế độ song song</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_select_tone_type">
      <source>Change tone</source>
      <translation variants="no">Chọn loại nhạc chuông</translation>
    </message>
    <message numerus="no" id="txt_cp_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc họp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_not_connected">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chưa kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_heading_profile_name">
      <source>Profile name: </source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên profile:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_operator_selection_is_not_possible_in">
      <source>Operator selection is not possible in Offline.</source>
      <translation variants="no">Không thể chọn nhà điều hành ở chế độ offline</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">Âm lượng</translation>
    </message>
    <message numerus="no" id="txt_short_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">vi #Control panel</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active_val_clock_alarm">
      <source>Clock alarm at %1</source>
      <translation variants="no">Âm báo giờ lúc %1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_and_connections_must_be_d">
      <source>Active calls and connections must be disconnected before reset.</source>
      <translation variants="no">Phải ngắt kết nối các cuộc gọi và kết nối hiện tại trước khi đặt lại</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset">
      <source>Device reset</source>
      <translation variants="no">Đặt lại thiết bị</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_mobile_network">
      <source>Mobile network</source>
      <translation variants="no">Mạng di động</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="no">Các phím và màn hình</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_brightness">
      <source>Brightness</source>
      <translation variants="no">Độ sáng</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mạng di động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thông tin về ứng dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_no_tone">
      <source>Set no tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_preview_1">
      <source>Preview: %1</source>
      <translation variants="no">Xem trước: %[20]1</translation>
    </message>
    <message numerus="no" id="txt_cp_list_autorotate_display">
      <source>Auto-rotate display</source>
      <translation variants="no">Tự động xoay màn hình</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_12">
      <source>Copyright (C) 2007 Apple Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Apple Computer, Inc. ("Apple") nor the names of
   its contributors may be used to endorse or promote products derived
   from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE COMPUTER, INC. ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">vi #Copyright (C) 2007 Apple Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Apple Computer, Inc. ("Apple") nor the names of
   its contributors may be used to endorse or promote products derived
   from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE COMPUTER, INC. ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_info_when_selected_clock_is_displayed_when">
      <source>When selected, clock is displayed when in idle.</source>
      <translation variants="no">vi #When selected, clock is displayed when in idle.</translation>
    </message>
    <message numerus="no" id="txt_cp_info_type">
      <source>%1</source>
      <translation variants="no">vi #%1</translation>
    </message>
    <message numerus="no" id="txt_cp_terms_of_use">
      <source>Terms of Use</source>
      <translation variants="no">vi #Terms of Use</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_001">
      <source>%1</source>
      <translation variants="no">vi #%1</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_locked_after">
      <source>Keys &amp; screen locked after</source>
      <translation variants="no">Khóa phím và màn hình sau:</translation>
    </message>
    <message numerus="no" id="txt_cp_list_music">
      <source>Choose from music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm nhạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_1_minute">
      <source>1 minute</source>
      <translation variants="no">1 phút</translation>
    </message>
    <message numerus="no" id="txt_cp_info_setup_is_not_completed_would_you_lik">
      <source>Setup is not completed. 
Would you like to complete it now?</source>
      <translation variants="no">Thiết lập thiết bị chưa được hoàn tất. Hoàn tất ngay bây giờ?</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_security">
      <source>Security</source>
      <translation variants="no">Bảo mật</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">Ngôn ngữ soạn thảo phụ</translation>
    </message>
  </context>
</TS>