<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cp_subhead_device">
      <source>Device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_val_change_language">
      <source>Change language</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa cài đặt ngôn ngữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đặt lại cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_1_minute">
      <source>1 minute</source>
      <translation variants="no">1 phút</translation>
    </message>
    <message numerus="no" id="txt_cp_info_setup_is_not_completed_would_you_lik">
      <source>Setup is not completed. 
Would you like to complete it now?</source>
      <translation variants="no">Thiết lập thiết bị chưa được hoàn tất. Hoàn tất ngay bây giờ?</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_security">
      <source>Security</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bảo mật</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_locked_after">
      <source>Keys &amp; screen locked after</source>
      <translation variants="no">Khóa phím và màn hình sau:</translation>
    </message>
    <message numerus="no" id="txt_cp_list_music">
      <source>Choose from music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm nhạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_setup">
      <source>Setup</source>
      <translation variants="no">Thiết lập</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giới thiệu ứng dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tự động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Tự động</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_15_seconds">
      <source>15 seconds</source>
      <translation variants="no">15 giây</translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn giao diện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_touch_screen_vibra">
      <source>Touch screen vibra</source>
      <translation variants="no">Rung</translation>
    </message>
    <message numerus="no" id="txt_cp_list_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">Các phím và màn hình</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_in_offline_mode_all_wireless_communica">
      <source>In offline mode all wireless communication is turned off.</source>
      <translation variants="no">Tất cả kết nối không dây đều bị đóng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode">
      <source>Network mode</source>
      <translation variants="no">Chế độ mạng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">Ngôn ngữ soạn thảo phụ</translation>
    </message>
    <message numerus="no" id="txt_cp_info_rotate_the_display_content_automatical">
      <source>Rotate the display content automatically when you turn the device on horizontal or back to a vertical position.</source>
      <translation variants="no">Tự động xoay nội dung trên màn hình khi thay đổi hướng thiết bị</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection">
      <source>Operator selection</source>
      <translation variants="no">Chọn nhà điều hành</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_2_minutes">
      <source>2 minutes</source>
      <translation variants="no">2 phút</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_key_and_touchscreen_tones">
      <source>Key and touchscreen tones</source>
      <translation variants="no">Âm phím</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_home_network">
      <source>Data usage in home network</source>
      <translation variants="no">Sử dụng dữ liệu trong mạng chủ</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_gsm">
      <source>GSM</source>
      <translation variants="no">GSM</translation>
    </message>
    <message numerus="no" id="txt_cp_list_tone">
      <source>Choose from tones</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc chuông</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_connectivity">
      <source>Connectivity</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_30_seconds">
      <source>30 seconds</source>
      <translation variants="no">30 giây</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset_val_reset_your_device">
      <source>Reset your device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khôi phục cài đặt gốc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Tự động</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_roaming">
      <source>Data usage when roaming</source>
      <translation variants="no">Sử dụng dữ liệu khi chuyển vùng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">Ngôn ngữ soạn thảo chính</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giao diện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_wallpaper">
      <source>Wallpaper</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hình nền</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_manual">
      <source>Manual</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thủ công</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_select_tone_type">
      <source>Change tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn loại nhạc chuông</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_45_seconds">
      <source>45 seconds</source>
      <translation variants="no">45 giây</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_dual_mode">
      <source>Dual mode</source>
      <translation variants="no">Chế độ song song</translation>
    </message>
    <message numerus="no" id="txt_cp_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc họp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_control_panel">
      <source>Control Panel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_email_tone">
      <source>E-mail tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo e-mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_message_tone">
      <source>Message tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo tin nhắn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bình thường</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_volume">
      <source>Volume</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm lượng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_umts">
      <source>UMTS</source>
      <translation variants="no">3G</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reminder_tone">
      <source>Reminder tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo lịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đặt lại cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mạng di động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_brightness">
      <source>Brightness</source>
      <translation variants="no">Độ sáng</translation>
    </message>
    <message numerus="no" id="txt_cp_list_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thông tin về ứng dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">Các phím và màn hình</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_autorotate_display">
      <source>Auto-rotate display</source>
      <translation variants="no">Tự động xoay màn hình</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mạng di động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_preview_1">
      <source>Preview: %1</source>
      <translation variants="no">Xem trước: %[20]1</translation>
    </message>
    <message numerus="no" id="txt_cp_list_no_tone">
      <source>Set no tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_and_connections_must_be_d">
      <source>Active calls and connections must be disconnected before reset.</source>
      <translation variants="no">Phải ngắt kết nối các cuộc gọi và kết nối hiện tại trước khi đặt lại</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset">
      <source>Device reset</source>
      <translation variants="no">Đặt lại thiết bị</translation>
    </message>
    <message numerus="no" id="txt_cp_terms_of_use">
      <source>Terms of Use</source>
      <translation variants="no">Điều khoản sử dụng</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_graphical_style_of_the_device">
      <source>Select graphical style of the device</source>
      <translation variants="no">vi ##Select theme</translation>
    </message>
    <message numerus="no" id="txt_short_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_12">
      <source>Copyright (C) 2007 Apple Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Apple Computer, Inc. ("Apple") nor the names of
   its contributors may be used to endorse or promote products derived
   from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE COMPUTER, INC. ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Bản quyền (C) 2007 Apple Inc.  Đã đăng ký bản quyền.

Cho phép phân phối lại và sử dụng theo dạng nguồn và nhị phân, có hoặc không có
sửa đổi, miễn là đáp ứng được các
điều kiện sau đây:
1. Phân phối lại mã nguồn phải giữ lại thông báo
   bản quyền ở trên, danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau.
2. Phân phối lại ở dạng nhị phân phải sao chép lại thông báo bản quyền
   ở trên, danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau trong
   tài liệu và/hoặc các tài liệu khác được cung cấp cùng với việc phân phối.
3. Không được sử dụng tên của Apple Computer, Inc. ("Apple") cũng như tên của
   người cộng tác của công ty để xác nhận hoặc quảng bá các sản phẩm được bắt nguồn từ
   phần mềm này mà không được phép trước bằng văn bản cụ thể. 

PHẦN MỀM NÀY ĐƯỢC APPLE COMPUTER, INC. CUNG CẤP THEO "HIỆN TRẠNG'' VÀ MIỄN TRỪ TRÁCH NHIỆM ĐỐI VỚI BẤT KỲ 
BẢO ĐẢM RÕ RÀNG HAY NGỤ Ý NÀO, BAO GỒM, NHƯNG KHÔNG GIỚI HẠN
BẢO ĐẢM NGỤ Ý VỀ KHẢ NĂNG BÁN ĐƯỢC VÀ TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH
CỤ THỂ.  APPLE COMPUTER, INC. HOẶC
NGƯỜI CỘNG TÁC HOÀN TOÀN KHÔNG CÓ TRÁCH NHIỆM VỀ PHÁP LÝ ĐỐI VỚI BẤT KỲ THIỆT HẠI TRỰC TIẾP, GIÁN TIẾP, NGẪU NHIÊN, ĐẶC BIỆT,
ĐỂ LÀM GƯƠNG HAY DO HẬU QUẢ (BAO GỒM, NHƯNG KHÔNG GIỚI HẠN,
VIỆC MUA ĐƯỢC SẢN PHẨM HOẶC DỊCH VỤ THAY THẾ; MẤT SỬ DỤNG, DỮ LIỆU HOẶC
LỢI NHUẬN HOẶC GIÁN ĐOẠN KINH DOANH) DÙ ĐƯỢC GÂY RA VÀ THEO BẤT KỲ LÝ LUẬN NÀO
VỀ TRÁCH NHIỆM PHÁP LÝ, CHO DÙ BẰNG HỢP ĐỒNG, TRÁCH NHIỆM PHÁP LÝ HẠN CHẾ HAY SAI LẦM CỦA CÁ NHÂN
(BAO GỒM TÍNH CẨU THẢ HOẶC CÁCH KHÁC) GÂY RA BẰNG BẤT KỲ CÁCH NÀO NGOÀI VIỆC S? DỤNG
PHẦN MỀM NÀY, NGAY CẢ KHI ĐƯỢC BÁO CHO BIẾT VỀ KHẢ NĂNG XẢY RA THIỆT HẠI ĐÓ.</translation>
    </message>
    <message numerus="no" id="txt_cp_info_when_selected_clock_is_displayed_when">
      <source>When selected, clock is displayed when in idle.</source>
      <translation variants="no">Hiển thị đồng hồ khi màn hình trống</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active_val_clock_alarm">
      <source>Clock alarm at %1</source>
      <translation variants="no">Báo thức lúc %1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_type">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_processing">
      <source>Processing…</source>
      <translation variants="no">Đang xử lý</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset_val_reset_settings">
      <source>Reset settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đặt lại cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_tones_that_play_when_you_select">
      <source>Select tones that play when you select the profile named:</source>
      <translation variants="no">Chọn nhạc chuông sẽ được  sử dụng khi profile này được chọn:</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_themes">
      <source>Get more from Ovi</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhận thêm giao diện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_product_release">
      <source>Product Release</source>
      <translation variants="no">Phát hành sản phẩm</translation>
    </message>
    <message numerus="no" id="txt_cp_title_edit_name">
      <source>Edit name</source>
      <translation variants="no">Chỉnh sửa tên</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_general">
      <source>General</source>
      <translation variants="no">Bình thường</translation>
    </message>
    <message numerus="no" id="txt_cp_info_product_release">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_delete_all_data_and_restore_original_s">
      <source>Delete all data and restore original settings? Ejectable memory card data is not deleted.</source>
      <translation variants="no">Xóa tất cả dữ liệu và khôi phục cài đặt gốc? Dữ liệu trên thẻ nhớ tháo lắp được sẽ không bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_not_connected">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chưa kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngôn ngữ và vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_4">
      <source>Copyright (C) 2004, Apple Computer, Inc. and The Mozilla Foundation. 
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. Neither the names of Apple Computer, Inc. ("Apple") or The Mozilla
Foundation ("Mozilla") nor the names of their contributors may be used
to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY APPLE, MOZILLA AND THEIR CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE, MOZILLA OR
THEIR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Bản quyền (C) 2004, Apple Computer, Inc. và The Mozilla Foundation. 
Đã đăng ký bản quyền.

Được phép phân phối lại và sử dụng theo dạng nguồn và nhị phân, có hoặc không có

sửa đổi, miễn là đáp ứng
các điều kiện sau:

1. Phân phối lại mã nguồn phải giữ lại thông báo
bản quyền ở trên, danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau. 
2. Phân phối lại theo dạng nhị phân phải sao chép lại thông báo bản quyền
ở trên, danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau
trong tài liệu và/hoặc các tài liệu khác được cung cấp cùng với việc phân phối. 
3. Không được sử dụng tên của Apple Computer, Inc. ("Apple") hoặc The Mozilla
Foundation ("Mozilla") cũng như tên của người cộng tác để xác nhận hoặc quảng bá sản phẩm
bắt nguồn từ phần mềm này mà không
được phép trước bằng văn bản cụ thể.

PHẦN MỀM NÀY ĐƯỢC APPLE, MOZILLA VÀ NGƯỜI CỘNG TÁC CỦA HỌ CUNG CẤP THEO "HIỆN\NTRA ̣NG" VÀ TỪ CHỐI BẤT KỲ BẢO ĐẢM RÕ RÀNG HAY NGỤ Ý, BAO GỒM NHƯNG KHÔNG GIỚI HẠN, BẢO ĐẢM
NGỤ Ý VỀ KHẢ NĂNG BÁN ĐƯỢC VÀ TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH
CỤ THỂ. APPLE, MOZILLA HOẶC
NGƯỜI CỘNG TÁC CỦA HỌ HOÀN TOÀN KHÔNG CÓ TRÁCH NHIỆM VỀ PHÁP LÝ ĐỐI VỚI BẤT KỲ THIỆT HẠI TRỰC TIẾP, GIÁN TIẾP, NGẪU NHIÊN,
ĐẶC BIỆT, ĐỂ LÀM GƯƠNG HOẶC DO HẬU QUẢ (BAO GỒM NHƯNG KHÔNG GIỚI HẠN,
VIỆC MUA ĐƯỢC SẢN PHẨM HOẶC DỊCH VỤ THAY THẾ; MẤT SỬ DỤNG, DỮ LIỆU HOẶC
LỢI NHUẬN; HOẶC GIÁN ĐOẠN KINH DOANH) DÙ ĐƯỢC GÂY RA VÀ THEO BẤT KỲ LÝ LUẬN NÀO
VỀ TRÁCH NHIỆM PHÁP LÝ, CHO DÙ BẰNG HỢP ĐỒNG, TRÁCH NHIỆM PHÁP LÝ HẠN CHẾ HAY SAI LẦM CỦA CÁ NHÂN (BAO GỒM
TÍNH CẨU THẢ HAY CÁCH KHÁC) GÂY RA BẰNG BẤT KỲ CÁCH NÀO NGOÀI VIỆC SỬ DỤNG PHẦN MỀM NÀY,
NGAY CẢ KHI ĐƯỢC BÁO CHO BIẾT VỀ KHẢ NĂNG XẢY RA THIỆT HẠI ĐÓ.</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_6">
      <source>Copyright (c) 2004, 2005 Apple Computer, Inc.
Copyright (c) 1997-2005 University of Cambridge
All rights reserved.
Copyright (c) 2005, Google Inc.
All rights reserved.
Copyright (c) 2006, Nokia Corporation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the University of Cambridge nor the name of Google
  Inc. nor the names of their contributors may be used to endorse or
  promote products derived from this software without specific prior
  written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Bản quyền (c) 2004, 2005 Apple Computer, Inc.
Bản quyền (c) 1997-2005 Trường Đại học Cambridge
Đã đăng ký bản quyền.
Bản quyền (c) 2005, Google Inc.
Đã đăng ký bản quyền.
Bản quyền (c) 2006, Nokia Corporation

Được phép phân phối lại và sử dụng ở dạng nguồn và nhị phân, có hoặc không có
sửa đổi miễn là đáp ứng các điều kiện sau:

* Phân phối lại mã nguồn phải giữ lại thông báo bản quyền ở trên,
  danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau.

* Phân phối lại ở dạng nhị phân phải sao chép lại thông báo bản quyền
  ở trên, danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau trong
  tài liệu và/hoặc các tài liệu khác được cung cấp cùng với phân phối.

* Không được sử dụng tên của Trường Đại học Cambridge, tên của Google
  Inc. cũng như tên của người cộng tác của họ để xác nhận hoặc
  quảng bá sản phẩm bắt nguồn từ phần mềm này mà không được phép trước bằng
  văn bản cụ thể.

PHẦN MỀM NÀY ĐƯỢC NGƯỜI GIỮ BẢN QUYỀN VÀ NGƯỜI CỘNG TÁC CUNG CẤP THEO "HIỆN TRẠNG"
VÀ TỪ CHỐI BẤT KỲ BẢO ĐẢM RÕ RÀNG HAY NGỤ Ý, BAO GỒM NHƯNG KHÔNG GIỚI HẠN, BẢO ĐẢM
NGỤ Ý VỀ KHẢ NĂNG BÁN ĐƯỢC VÀ TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH
CỤ THỂ. CHỦ SỞ HỮU BẢN QUYỀN HOẶC NGƯỜI CỘNG TÁC
HOÀN TOÀN KHÔNG CÓ TRÁCH NHIỆM VỀ PHÁP LÝ ĐỐI VỚI BẤT KỲ THIỆT HẠI TRỰC TIẾP, GIÁN TIẾP, NGẪU NHIÊN, ĐẶC BIỆT, ĐỂ LÀM GƯƠNG HOẶC
DO HẬU QUẢ (BAO GỒM NHƯNG KHÔNG GIỚI HẠN, VIỆC MUA ĐƯỢC
SẢN PHẨM HOẶC DỊCH VỤ THAY THẾ; MẤT SỬ DỤNG, DỮ LIỆU HOẶC LỢI NHUẬN; HOẶC GIÁN ĐOẠN
KINH DOANH) DÙ ĐƯỢC GÂY RA VÀ THEO BẤT KỲ LÝ LUẬN NÀO VỀ TRÁCH NHIỆM PHÁP LÝ, CHO DÙ BẰNG
HỢP ĐỒNG, TRÁCH NHIỆM PHÁP LÝ HẠN CHẾ HAY SAI LẦM CỦA CÁ NHÂN (BAO GỒM TÍNH CẨU THẢ HAY CÁCH KHÁC)
GÂY RA BẰNG BẤT KỲ CÁCH NÀO NGOÀI VIỆC SỬ DỤNG PHẦN MỀM NÀY, NGAY CẢ KHI ĐƯỢC BÁO CHO BIẾT VỀ KHẢ NĂNG XẢY RA THIỆT HẠI ĐÓ.</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset">
      <source>Settings reset</source>
      <translation variants="no">Đặt lại cài đặt</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_ringtone">
      <source>Ringtone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc chuông</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_software_vesion">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_restore_original_settings_no_data_wil">
      <source>Restore original settings? No data will be deleted.</source>
      <translation variants="no">Khôi phục cài đặt gốc? Không có dữ liệu nào sẽ bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_cp_heading_profile_name">
      <source>Profile name: </source>
      <translation variants="no">Tên profile:</translation>
    </message>
    <message numerus="no" id="txt_cp_list_screensaver">
      <source>Screensaver</source>
      <translation variants="no">Bảo vệ màn hình bằng đồng hồ</translation>
    </message>
    <message numerus="no" id="txt_cp_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">Rung</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_5">
      <source>The author of this software is David M. Gay.

Copyright (c) 1991, 2000, 2001 by Lucent Technologies.

Permission to use, copy, modify, and distribute this software for any
purpose without fee is hereby granted, provided that this entire notice
is included in all copies of any software which is or includes a copy
or modification of this software and in all copies of the supporting
documentation for such software.

THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY.  IN PARTICULAR, NEITHER THE AUTHOR NOR LUCENT MAKES ANY
REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.</source>
      <translation variants="no">Tác giả của phần mềm này là David M. Gay.
\Bản quyền (c) 1991, 2000, 2001 của Lucent Technologies.

Qua tài liệu này, giấy phép được cấp miễn phí để sử dụng, sao chép, sửa đổi và phân phối phần mềm này cho bất kỳ
mục đích nào miễn là toàn bộ thông báo này
được bao gồm trong tất cả các bản sao của mọi phần mềm là hoặc bao gồm bản sao
hoặc sửa đổi của phần mềm này và trong tất cả bản sao của tài liệu
hỗ trợ cho phần mềm như vậy.

PHẦN MỀM NÀY ĐƯỢC CUNG CẤP "THEO HIỆN TRẠNG” MÀ KHÔNG CÓ BẤT KỲ BẢO ĐẢM RÕ RÀNG
HAY NGỤ Ý NÀO. CỤ THỂ, TÁC GIẢ CŨNG NHƯ LUCENT HOÀN TOÀN KHÔNG
ĐẠI DIỆN HOẶC BẢO ĐẢM BẤT KỲ MỐI LIÊN QUAN NÀO ĐẾN KHẢ NĂNG BÁN ĐƯỢC
PHẦN MỀM NÀY HOẶC TÍNH THÍCH HỢP CỦA PHẦN MỀM ĐỐI VỚI BẤT KỲ MỤC ĐÍCH CỤ THỂ NÀO.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_personalization">
      <source>Personalization</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt riêng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_meeting">
      <source>Meeting</source>
      <translation variants="no">Cuộc họp</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_confirm">
      <source>Confirm</source>
      <translation variants="no">Luôn hỏi</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device_model">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_button_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">Im lặng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_closing_connections">
      <source>Closing connections</source>
      <translation variants="no">Đang đóng kết nối</translation>
    </message>
    <message numerus="no" id="txt_cp_button_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt nâng cao</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_7">
      <source>Copyright (c) 1994
Hewlett-Packard Company

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Hewlett-Packard Company makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</source>
      <translation variants="no">Bản quyền (c) 1994
Công ty Hewlett-Packard

Qua tài liệu này, giấy phép được cấp miễn phí để sử dụng, sao chép, sửa đổi, phân phối và bán phần mềm này
và tài liệu của phần mềm cho bất kỳ mục đích nào
miễn là thông báo bản quyền ở trên xuất hiện trong tất cả bản sao và
cả thông báo bản quyền đó và thông báo cấp phép này xuất hiện
trong tài liệu hỗ trợ.  Công ty Hewlett-Packard hoàn toàn
không đại diện về sự thích hợp của phần mềm này cho bất kỳ
mục đích nào. Phần mềm được cung cấp theo “hiện trạng” mà không có bảo đảm rõ ràng hay ngụ ý.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_10">
      <source>Copyright (c) 1995-2006 International Business Machines Corporation and others

All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, provided that the above copyright notice(s)
and this permission notice appear in all copies of the Software and that both the above
copyright notice(s) and this permission notice appear in supporting documentation.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 
Except as contained in this notice, the name of a copyright holder shall not be used in
advertising or otherwise to promote the sale, use or other dealings in this Software
without prior written authorization of the copyright holder.</source>
      <translation variants="no">Bản quyền (c) 1995-2006 International Business Machines Corporation và các công ty khác

Đã đăng ký bản quyền.

Qua tài liệu này, giấy phép được cấp miễn phí cho bất kỳ ai nhận được bản sao
phần mềm này và các tập tin tài liệu được kết hợp ("Phần mềm"), đ? giao dịch trong Phần mềm
mà không có hạn chế, kể cả không có giới hạn về quyền sử dụng, sao chép, sửa đổi,
kết hợp, xuất bản, phân phối và/hoặc bán bản sao Phần mềm và để cho phép những người
mà Phần mềm được cung cấp để làm như vậy, miễn là (các) thông báo bản quyền ở trên
và thông báo cấp phép này xuất hiện trong tất cả các bản sao của Phần mềm, đồng thời cả
(các) thông báo bản quyền ở trên và thông báo cấp phép này xuất hiện trong tài liệu hỗ trợ.

PHẦN MỀM ĐƯỢC CUNG CẤP THEO "HIỆN TRẠNG" MÀ KHÔNG CÓ BẤT KỲ SỰ BẢO ĐẢM NÀO, RÕ RÀNG HAY NGỤ Ý, BAO GỒM NHƯNG KHÔNG GIỚI HẠN CÁC BẢO ĐẢM VỀ KHẢ NĂNG BÁN ĐƯỢC, SỰ THÍCH HỢP CHO MỘT MỤC ĐÍCH CỤ THỂ VÀ KHÔNG VI PHẠM BẢN QUYỀN CỦA BÊN THỨ BA. NGƯỜI NẮM GIỮ HOẶC NHỮNG NGƯỜI NẮM GIỮ BẢN QUYỀN ĐƯỢC BAO GỒM TRONG THÔNG BÁO NÀY HOÀN TOÀN KHÔNG CÓ TRÁCH NHIỆM VỀ PHÁP LÝ ĐỐI VỚI BẤT KỲ KHIẾU NẠI NÀO HOẶC BẤT KỲ THIỆT HẠI TRỰC TIẾP  HOẶC DO HẬU QUẢ ĐẶC BIỆT NÀO HOẶC BẤT KỲ THIỆT HẠI NÀO LÀ KẾT QUẢ TỪ VIỆC MẤT SỬ DỤNG, DỮ LIỆU HOẶC LỢI NHUẬN, CHO DÙ BẰNG HÀNH ĐỘNG C?A HỢP ĐỒNG, TÍNH CẨU THẢ HAY HÀNH ĐỘNG SAI LẦM KHÁC, PHÁT SINH
NGOÀI HOẶC CÓ LIÊN QUAN VỚI VIỆC SỬ DỤNG HOẶC HOẠT ĐỘNG CỦA PHẦN MỀM NÀY.
 
Ngoại trừ được nêu trong thông báo này, tên của người nắm giữ bản quyền sẽ không được sử dụng trong
quảng cáo hoặc cách khác quảng bá việc bán, sử dụng hoặc các giao dịch khác trong Phần mềm này
mà không được người nắm giữ bản quyền ủy quyền trước bằng văn bản.</translation>
    </message>
    <message numerus="no" id="txt_cp_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Ngắt kết nối</translation>
    </message>
    <message numerus="no" id="txt_cp_info_1">
      <source>Nokia and Nokia Connecting People are trademarks or registered trademarks of Nokia Corporation.
 
Copyright 2011 Nokia. All rights reserved. 

This product is based on Symbian^4.

Other product and company names mentioned herein may be trademarks or tradenames of their respective owners. </source>
      <translation variants="no">Nokia và Nokia Connecting People là thương hiệu hoặc thương hiệu đã đăng ký của Nokia Corporation.
 
Bản quyền 2011 Nokia. Đã đăng ký bản quyền. 

Sản phẩm này dựa trên Symbian^4.

Các tên sản phẩm và công ty khác được đề cập ở đây có thể là thương hiệu hoặc tên thương hiệu của các chủ sở hữu tương ứng.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_2">
      <source>This product includes API header files originally developed by Netscape Communications Corporation, modified by Nokia by changing certain variables for the  
purpose of porting the file to Symbian operating system on May 1st, 2004, and available in source code form under the Netscape Public License, v1.1 at  
http://www.forum.nokia.com/browserapi.</source>
      <translation variants="no">Sản phẩm này bao gồm các tập tin tiêu đề API được phát triển đầu tiên bởi Netscape Communications Corporation, được sửa đổi bởi Nokia bằng cách thay đổi các biến thể nhất định cho 
mục đích hướng tập tin sang hệ điều hành Symbian vào 1/5/2004 và có sẵn bằng dạng mã nguồn theo Netscape Public License (Giấy phép Công cộng Netscape), phiên bản 1.1 tại 
http://www.forum.nokia.com/browserapi.</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_confirm">
      <source>Confirm</source>
      <translation variants="no">Luôn hỏi</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_9">
      <source>Copyright (c) 1983, 1995, 1996 Eric P. Allman
Copyright (c) 1988, 1993
 The Regents of the University of California.  All rights reserved.
Copyright (C) 2007 Nokia Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of the University nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.</source>
      <translation variants="no">Bản quyền (c) 1983, 1995, 1996 Eric P. Allman
Bản quyền (c) 1988, 1993
 The Regents of the University of California.  Đã đăng ký bản quyền.
Bản quyền (C) 2007 Nokia Inc. Đã đăng ký bản quyền.

Được phép phân phối lại và sử dụng ở dạng nguồn và nhị phân, có hoặc không có
sửa đổi miễn là đáp ứng các điều kiện
sau:

1. Phân phối lại mã nguồn phải giữ lại thông báo bản quyền ở trên,
  danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau.
2. Phân phối lại ở dạng nhị phân phải sao chép lại thông báo bản quyền
ở trên, danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau trong
tài liệu và/hoặc các tài liệu khác được cung cấp cùng với phân phối.
3. Không được sử dụng tên của Trường Đại học cũng như tên của người cộng tác của trường
  để xác nhận hoặc quảng bá sản phẩm bắt nguồn từ phần mềm này
  mà không được phép trước bằng văn bản cụ thể.

PHẦN MỀM NÀY ĐƯỢC REGENTS VÀ NGƯỜI CỘNG TÁC CUNG CẤP THEO "HIỆN TRẠNG" VÀ
TỪ CHỐI BẤT KỲ BẢO ĐẢM RÕ RÀNG HAY NGỤ Ý, BAO GỒM NHƯNG KHÔNG GIỚI HẠN, BẢO ĐẢM
NGỤ Ý VỀ KHẢ NĂNG BÁN ĐƯỢC VÀ TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH
CỤ THỂ. REGENTS HOẶC NGƯỜI CỘNG TÁC
HOÀN TOÀN KHÔNG CÓ TRÁCH NHIỆM VỀ PHÁP LÝ ĐỐI VỚI BẤT KỲ THIỆT HẠI TRỰC TIẾP, GIÁN TIẾP, NGẪU NHIÊN, ĐẶC BIỆT, ĐỂ LÀM GƯƠNG HOẶC
DO HẬU QUẢ (BAO GỒM NHƯNG KHÔNG GIỚI HẠN, VIỆC MUA ĐƯỢC SẢN PHẨM
HOẶC DỊCH VỤ THAY THẾ; MẤT SỬ DỤNG, DỮ LIỆU HOẶC LỢI NHUẬN; HOẶC GIÁN ĐOẠN KINH DOANH)
DÙ ĐƯỢC GÂY RA VÀ THEO BẤT KỲ LÝ LUẬN NÀO VỀ TRÁCH NHIỆM PHÁP LÝ, CHO DÙ BẰNG HỢP ĐỒNG,
TRÁCH NHIỆM PHÁP LÝ HẠN CHẾ HAY SAI LẦM CỦA CÁ NHÂN (BAO GỒM TÍNH CẨU THẢ HAY CÁCH KHÁC) GÂY RA BẰNG BẤT KỲ CÁCH NÀO
NGOÀI VIỆC SỬ DỤNG PHẦN MỀM NÀY, NGAY CẢ KHI ĐƯỢC BÁO CHO BIẾT VỀ KHẢ NĂNG XẢY RA
THIỆT HẠI ĐÓ.</translation>
    </message>
    <message numerus="no" id="txt_cp_button_regional_settings">
      <source>Regional settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt nâng cao</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices">
      <source>3rd party notices</source>
      <translation variants="no">Thông báo của bên thứ ba</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngôn ngữ và vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Đã tắt</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_11">
      <source>Copyright (C) 2003, 2004, 2005, 2006 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2006, 2007 Alexey Proskuryakov (ap@nypop.com)
Copyright (C) 2006 Nikolas Zimmermann &lt;zimmermann@kde.org&gt;
Copyright (C) 2006 Samuel Weinig &lt;sam.weinig@gmail.com&gt;
Copyright (C) 2006 James G. Speth (speth@end.com)
Copyright (C) 2006 Jonas Witt &lt;jonas.witt@gmail.com&gt;
Copyright (C) 2006, 2007 Trolltech ASA
Copyright (C) 2005, 2006 Kimmo Kinnunen &lt;kimmo.t.kinnunen@nokia.com&gt;.
Copyright (C) 2006 Zack Rusin &lt;zack@kde.org&gt;
Copyright (C) 2007 Alp Toker &lt;alp@atoker.com&gt;
Copyright (C) 2007 Alp Toker &lt;alp.toker@collabora.co.uk&gt;
Copyright (C) 2007 Graham Dennis (graham.dennis@gmail.com)
Copyright (C) 2006 Don Gibson &lt;dgibson77@gmail.com&gt;
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2007 Holger Hans Peter Freyther
Copyright (C) 2007 Matt Lilek (pewtermoose@gmail.com).
Copyright (C) 2006 David Smith (catfish.man@gmail.com)
Copyright (C) 2006 George Staikos &lt;staikos@kde.org&gt;
Copyright (C) 2006 Simon Hausmann &lt;hausmann@kde.org&gt;
Copyright (C) 2006 Rob Buis &lt;buis@kde.org&gt;
Copyright (C) 2006 Dirk Mueller &lt;mueller@kde.org&gt;
Copyright (C) 2000-2001 Dawit Alemayehu &lt;adawit@kde.org&gt;
Copyright (C) 2006, 2007 Eric Seidel &lt;eric@webkit.org&gt;
Copyright (C) 2005, 2006 Alexander Kellett &lt;lypanov@kde.org&gt;
Copyright (C) 2005 Oliver Hunt &lt;ojh16@student.canterbury.ac.nz&gt;.  All rights reserved.
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2006 Enrico Ros &lt;enrico.ros@m31engineering.it&gt;
Copyright (C) 2007 Staikos Computing Services Inc. &lt;info@staikos.net&gt;
Copyright (C) 2006 Charles Samuels &lt;charles@kde.org&gt;
Copyright (C) 2007 Kevin Ollivier &lt;kevino@theolliviers.com&gt;
Copyright (C) 2007 Robin Dunn.  All rights reserved.
Copyright     2005 Frerich Raabe &lt;raabe@kde.org&gt;
Copyright     2005 Maksim Orlovich &lt;maksim@kde.org&gt;

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the fol</source>
      <translation variants="no">vi #Copyright (C) 2003, 2004, 2005, 2006 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2006, 2007 Alexey Proskuryakov (ap@nypop.com)
Copyright (C) 2006 Nikolas Zimmermann &lt;zimmermann@kde.org&gt;
Copyright (C) 2006 Samuel Weinig &lt;sam.weinig@gmail.com&gt;
Copyright (C) 2006 James G. Speth (speth@end.com)
Copyright (C) 2006 Jonas Witt &lt;jonas.witt@gmail.com&gt;
Copyright (C) 2006, 2007 Trolltech ASA
Copyright (C) 2005, 2006 Kimmo Kinnunen &lt;kimmo.t.kinnunen@nokia.com&gt;.
Copyright (C) 2006 Zack Rusin &lt;zack@kde.org&gt;
Copyright (C) 2007 Alp Toker &lt;alp@atoker.com&gt;
Copyright (C) 2007 Alp Toker &lt;alp.toker@collabora.co.uk&gt;
Copyright (C) 2007 Graham Dennis (graham.dennis@gmail.com)
Copyright (C) 2006 Don Gibson &lt;dgibson77@gmail.com&gt;
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2007 Holger Hans Peter Freyther
Copyright (C) 2007 Matt Lilek (pewtermoose@gmail.com).
Copyright (C) 2006 David Smith (catfish.man@gmail.com)
Copyright (C) 2006 George Staikos &lt;staikos@kde.org&gt;
Copyright (C) 2006 Simon Hausmann &lt;hausmann@kde.org&gt;
Copyright (C) 2006 Rob Buis &lt;buis@kde.org&gt;
Copyright (C) 2006 Dirk Mueller &lt;mueller@kde.org&gt;
Copyright (C) 2000-2001 Dawit Alemayehu &lt;adawit@kde.org&gt;
Copyright (C) 2006, 2007 Eric Seidel &lt;eric@webkit.org&gt;
Copyright (C) 2005, 2006 Alexander Kellett &lt;lypanov@kde.org&gt;
Copyright (C) 2005 Oliver Hunt &lt;ojh16@student.canterbury.ac.nz&gt;.  All rights reserved.
Copyright (C) 2006 Michael Emmel mike.emmel@gmail.com 
Copyright (C) 2006 Enrico Ros &lt;enrico.ros@m31engineering.it&gt;
Copyright (C) 2007 Staikos Computing Services Inc. &lt;info@staikos.net&gt;
Copyright (C) 2006 Charles Samuels &lt;charles@kde.org&gt;
Copyright (C) 2007 Kevin Ollivier &lt;kevino@theolliviers.com&gt;
Copyright (C) 2007 Robin Dunn.  All rights reserved.
Copyright     2005 Frerich Raabe &lt;raabe@kde.org&gt;
Copyright     2005 Maksim Orlovich &lt;maksim@kde.org&gt;

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the fol</translation>
    </message>
    <message numerus="no" id="txt_cp_title_end_encryption">
      <source>End encryption</source>
      <translation variants="no">Kết thúc mã hóa</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_8">
      <source>Copyright (c) 1996-1998
Silicon Graphics Computer Systems, Inc.

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Silicon Graphics makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</source>
      <translation variants="no">Bản quyền (c) 1996-1998
Silicon Graphics Computer Systems, Inc.

Qua tài liệu này, giấy phép được cấp miễn phí để sử dụng, sao chép, sửa đổi, phân phối và bán phần mềm này
và tài liệu của phần mềm cho bất kỳ mục đích nào
miễn là thông báo bản quyền ở trên xuất hiện trong tất cả bản sao và
cả thông báo bản quyền đó và thông báo cấp phép này xuất hiện
trong tài liệu hỗ trợ.  Silicon Graphics hoàn toàn
không đại diện về sự thích hợp của phần mềm này cho bất kỳ
mục đích nào. Phần mềm được cung cấp theo “hiện trạng” mà không có bảo đảm rõ ràng hay ngụ ý.</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Đã tắt</translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices">
      <source>Open source software notices</source>
      <translation variants="no">Thông báo phần mềm nguồn mở</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">Âm lượng</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language_val_non">
      <source>None</source>
      <translation variants="no">Không có</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_14">
      <source>Copyright (c) 1998 - 2008, Paul Johnston &amp; Contributors
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of the author nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Bản quyền (c) 1998 - 2008, Paul Johnston &amp; Người cộng tác
Đã đăng ký bản quyền.

Được phép phân phối lại và sử dụng theo dạng nguồn và nhị phân, có hoặc không có sửa đổi, miễn là đáp ứng các điều kiện sau:

Phân phối lại mã nguồn phải giữ lại thông báo bản quyền ở trên, danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau. Phân phối lại theo dạng nhị phân phải sao chép lại thông báo bản quyền ở trên, danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau trong tài liệu và/hoặc các tài liệu khác được cung cấp cùng với việc phân phối.
Không được sử dụng tên của tác giả cũng như tên của người cộng tác để xác nhận hoặc quảng bá sản phẩm bắt nguồn từ phần mềm này mà không được phép trước bằng văn bản cụ thể.

PHẦN MỀM NÀY ĐƯỢC NGƯỜI GIỮ BẢN QUYỀN VÀ NGƯỜI CỘNG TÁC CUNG CẤP THEO "HIỆN TRẠNG" VÀ TỪ CHỐI BẤT KỲ BẢO ĐẢM RÕ RÀNG HAY NGỤ Ý, BAO GỒM NHƯNG KHÔNG GIỚI HẠN, BẢO ĐẢM NGỤ Ý VỀ KHẢ NĂNG BÁN ĐƯỢC VÀ TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH CỤ THỂ. CHỦ SỞ HỮU BẢN QUYỀN HOẶC NGƯỜI CỘNG TÁC HOÀN TOÀN KHÔNG CÓ TRÁCH NHIỆM VỀ PHÁP LÝ ĐỐI VỚI BẤT KỲ THIỆT HẠI TRỰC TIẾP, GIÁN TIẾP, NGẪU NHIÊN, ĐẶC BIỆT, ĐỂ LÀM GƯƠNG HOẶC DO HẬU QUẢ (BAO GỒM NHƯNG KHÔNG GIỚI HẠN, VIỆC MUA ĐƯỢC SẢN PHẨM HOẶC DỊCH VỤ THAY THẾ; MẤT SỬ DỤNG, DỮ LIỆU HOẶC LỢI NHUẬN; HOẶC GIÁN ĐOẠN KINH DOANH) DÙ ĐƯỢC GÂY RA VÀ THEO BẤT KỲ LÝ LUẬN NÀO VỀ TRÁCH NHIỆM PHÁP LÝ, CHO DÙ BẰNG HỢP ĐỒNG, TRÁCH NHIỆM PHÁP LÝ HẠN CHẾ HAY SAI LẦM CỦA CÁ NHÂN (BAO GỒM TÍNH CẨU THẢ HAY CÁCH KHÁC) GÂY RA BẰNG BẤT KỲ CÁCH NÀO NGOÀI VIỆC SỬ DỤNG PHẦN MỀM NÀY, NGAY CẢ KHI ĐƯỢC BÁO CHO BIẾT VỀ KHẢ NĂNG XẢY RA THIỆT HẠI ĐÓ.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_3">
      <source>Copyright (C) 2005 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2007 Apple Inc.  All rights reserved.
Copyright (C) 2007 Nokia Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without

modification, are permitted provided that the following conditions
are met:

1.  Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer. 
2.  Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution. 
3.  Neither the name of Apple Computer, Inc. ("Apple") nor the names of
    its contributors may be used to endorse or promote products derived
    from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE AND ITS CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL APPLE OR ITS CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Bản quyền (C) 2005 Apple Computer, Inc.  Đã đăng ký bản quyền.
Bản quyền (C) 2007 Apple Inc.  Đã đăng ký bản quyền.
Bản quyền (C) 2007 Nokia Inc.  Đã đăng ký bản quyền.

Được phép phân phối lại và sử dụng theo dạng nguồn và nhị phân, có hoặc không có

sửa đổi, miễn là đáp ứng
các điều kiện sau:

1.  Phân phối lại mã nguồn phải giữ lại thông báo
bản quyền ở trên, danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau. 
2.  Phân phối lại theo dạng nhị phân phải sao chép lại thông báo bản quyền
ở trên, danh sách các điều kiện này và tuyên bố miễn trừ trách nhiệm sau
trong tài liệu và/hoặc các tài liệu khác được cung cấp cùng với việc phân phối. 
3.  Không được sử dụng tên của Apple Computer, Inc. ("Apple") cũng như tên của
người cộng tác để xác nhận hoặc quảng bá sản phẩm
bắt nguồn từ phần mềm này mà không được phép trước bằng văn bản cụ thể. 

PHẦN MỀM NÀY ĐƯỢC NGƯỜI GIỮ BẢN QUYỀN VÀ NGƯỜI CỘNG TÁC CUNG CẤP THEO "HIỆN TRẠNG" VÀ
TỪ CHỐI BẤT KỲ BẢO ĐẢM RÕ RÀNG HAY NGỤ Ý, BAO GỒM NHƯNG KHÔNG GIỚI HẠN, BẢO ĐẢM
NGỤ Ý VỀ KHẢ NĂNG BÁN ĐƯỢC VÀ TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH
CỤ THỂ. CHỦ SỞ HỮU BẢN QUYỀN HOẶC NGƯỜI CỘNG TÁC HOÀN TOÀN KHÔNG CÓ TRÁCH NHIỆM VỀ PHÁP LÝ ĐỐI VỚI
BẤT KỲ THIỆT HẠI TRỰC TIẾP, GIÁN TIẾP, NGẪU NHIÊN, ĐẶC BIỆT, ĐỂ LÀM GƯƠNG HOẶC DO HẬU QUẢ
(BAO GỒM NHƯNG KHÔNG GIỚI HẠN, VIỆC MUA ĐƯỢC SẢN PHẨM HOẶC DỊCH VỤ THAY THẾ;
MẤT SỬ DỤNG, DỮ LIỆU HOẶC LỢI NHUẬN; HOẶC GIÁN ĐOẠN KINH DOANH) DÙ ĐƯỢC GÂY RA
VÀ THEO BẤT KỲ LÝ LUẬN NÀO VỀ TRÁCH NHIỆM PHÁP LÝ, CHO DÙ BẰNG HỢP ĐỒNG, TRÁCH NHIỆM PHÁP LÝ HẠN CHẾ HAY SAI LẦM CỦA CÁ NHÂN
(BAO GỒM TÍNH CẨU THẢ HAY CÁCH KHÁC) GÂY RA BẰNG BẤT KỲ CÁCH NÀO NGOÀI VIỆC SỬ DỤNG PHẦN MỀM NÀY, NGAY CẢ KHI ĐƯỢC BÁO CHO BIẾT VỀ KHẢ NĂNG XẢY RA THIỆT HẠI ĐÓ.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_open_source_software_notices">
      <source>Open source software notices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thông báo phần mềm nguồn mở</lengthvariant>
        <lengthvariant priority="2">T.báo phần mềm nguồn mở</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_your_region">
      <source>Select your region:</source>
      <translation variants="no">Chọn vùng của bạn:</translation>
    </message>
    <message numerus="no" id="txt_cp_button_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">Offline</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_type">
      <source>Type</source>
      <translation variants="no">Loại</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_13">
      <source>Open Dynamics Engine
Copyright (c) 2001-2004, Russell L. Smith.
All rights reserved.

Redistribution and use in source and binary forms, 
with or without modification, are permitted provided
that the following conditions are met:

Redistributions of source code must retain the above 
copyright notice, this list of conditions and the 
following disclaimer.

Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or 
other materials provided with the distribution.

Neither the names of ODE's copyright owner nor the 
names of its contributors may be used to endorse or 
promote products derived from this software without 
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS 
AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.</source>
      <translation variants="no">Open Dynamics Engine
Bản quyền (c) 2001-2004, Russell L. Smith.
Đã đăng ký bản quyền.

Được phép phân phối lại và sử dụng theo dạng nguồn và nhị phân, 
có hoặc không có sửa đổi, miễn là
đáp ứng các điều kiện sau:

Phân phối lại mã nguồn phải giữ lại 
thông báo bản quyền ở trên, danh sách các điều kiện này và 
tuyên bố miễn trừ trách nhiệm sau.

Phân phối lại theo dạng nhị phân phải sao chép lại 
thông báo bản quyền ở trên, danh sách các điều kiện này và 
tuyên bố miễn trừ trách nhiệm sau trong tài liệu và/hoặc 
các tài liệu khác được cung cấp cùng với việc phân phối.

Không được sử dụng tên của chủ sở hữu bản quyền của ODE cũng như 
tên của người cộng tác của công ty để xác nhận hoặc 
quảng bá sản phẩm bắt nguồn từ phần mềm này mà không 
được phép trước bằng văn bản cụ thể.

PHẦN MỀM NÀY ĐƯỢC NGƯỜI GIỮ BẢN QUYỀN 
VÀ NGƯỜI CỘNG TÁC CUNG CẤP THEO "HIỆN TRẠNG" VÀ TỪ CHỐI BẤT KỲ BẢO ĐẢM 
RÕ RÀNG HAY NGỤ Ý, BAO GỒM NHƯNG KHÔNG GIỚI HẠN, BẢO ĐẢM 
NGỤ Ý VỀ KHẢ NĂNG BÁN ĐƯỢC VÀ TÍNH THÍCH HỢP CHO MỘT 
MỤC ĐÍCH CỤ THỂ. NGƯỜI CHỦ SỞ HỮU 
BẢN QUYỀN HOẶC NGƯỜI CỘNG TÁC HOÀN TOÀN KHÔNG CÓ TRÁCH NHIỆM VỀ PHÁP LÝ ĐỐI VỚI BẤT KỲ 
THIỆT HẠI TRỰC TIẾP, GIÁN TIẾP, NGẪU NHIÊN, ĐẶC BIỆT, ĐỂ LÀM GƯƠNG HOẶC 
DO HẬU QUẢ (BAO GỒM NHƯNG KHÔNG GIỚI HẠN, 
VIỆC MUA ĐƯỢC SẢN PHẨM HOẶC DỊCH VỤ THAY THẾ; MẤT 
SỬ DỤNG, DỮ LIỆU HOẶC LỢI NHUẬN; HOẶC GIÁN ĐOẠN KINH DOANH) DÙ 
ĐƯỢC GÂY RA VÀ THEO BẤT KỲ LÝ LUẬN NÀO VỀ TRÁCH NHIỆM PHÁP LÝ, CHO DÙ BẰNG 
HỢP ĐỒNG, TRÁCH NHIỆM PHÁP LÝ HẠN CHẾ HAY SAI LẦM CỦA CÁ NHÂN (BAO GỒM 
TÍNH CẨU THẢ HAY CÁCH KHÁC) GÂY RA BẰNG BẤT KỲ CÁCH NÀO NGOÀI 
VIỆC SỬ DỤNG PHẦN MỀM NÀY, NGAY CẢ KHI ĐƯỢC BÁO CHO BIẾT VỀ KHẢ NĂNG 
XẢY RA THIỆT HẠI ĐÓ.</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_tones">
      <source>Get more from Ovi</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhận thêm nhạc chuông</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_cp_title_profile">
      <source>Profile</source>
      <translation variants="no">Chọn profile</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_display_language">
      <source>Display language</source>
      <translation variants="no">Ngôn ngữ hiển thị</translation>
    </message>
    <message numerus="no" id="txt_cp_button_end">
      <source>End</source>
      <translation variants="no">Kết thúc</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Profile</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_original_settings_will_be_restored_no">
      <source>Original settings will be restored. No data will be deleted.</source>
      <translation variants="no">Cài đặt gốc sẽ được khôi phục. Không có dữ liệu nào sẽ bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_3rd_party_notices">
      <source>3rd party notices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thông báo của bên thứ ba</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset_val_reset_device">
      <source>Reset device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đặt lại thiết bị</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_edit_name">
      <source>Edit name</source>
      <translation variants="no">Chỉnh sửa tên</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_1">
      <source>Java and all Java-based marks are trademarks or registered trademarks of Sun Microsystems, Inc.
JavaTM ME environment: MIDP 2.1, CLDC 1.1.</source>
      <translation variants="no">Java và tất cả nhãn hiệu dựa trên Java là thương hiệu hoặc thương hiệu đã đăng ký của Sun Microsystems, Inc.
Môi trường JavaTM ME: MIDP 2.1, CLDC 1.1.</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_001">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_info_all_data_will_be_deleted_and_factory_s">
      <source>All data will be deleted and factory settings will be restored. Ejectable memory card data is not deleted.</source>
      <translation variants="no">Tất cả dữ liệu sẽ bị xóa và cài đặt gốc được khôi phục. Dữ liệu trên thẻ nhớ tháo lắp được sẽ không bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices_1">
      <source>This product includes certain open source software. The exact terms of the licenses, disclaimers, acknowledgements and notices are provided below. Nokia offers to provide you with the source code as defined in the applicable license. 

Please send an e-mail to sourcecode.request@nokia.com or a written request to:

Source Code Requests
Nokia Corporation
P.O.Box 407
FI-00045 Nokia Group
Finland

This offer is valid for a period of three (3) years from the date of the distribution of this product by Nokia.</source>
      <translation variants="no">Sản phẩm này bao gồm phần mềm nguồn mở nhất định. Điều khoản chính xác của giấy phép, tuyên bố miễn trừ trách nhiệm, sự công nhận và thông báo được cung cấp bên dưới. Nokia đề nghị cung cấp cho bạn mã nguồn mở như được xác định trong giấy phép hiện hành. 

Vui lòng gửi e-mail đến sourcecode.request@nokia.com hoặc yêu cầu bằng văn bản đến:

Source Code Requests
Nokia Corporation
P.O.Box 407
FI-00045 Nokia Group
Finland

Ứng dụng này hợp lệ trong khoảng thời gian ba (3) năm kể từ ngày Nokia phân phối sản phẩm này.</translation>
    </message>
    <message numerus="no" id="txt_cp_info_data_encryption_ongoing_enryption_mus">
      <source>Data encryption ongoing. Enryption must be ended before reset.  End data enrcyption?</source>
      <translation variants="no">Đang mã hóa dữ liệu. Mã hóa phải được kết thúc trước khi đặt lại. Kết thúc mã hóa dữ liệu?</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_software_version">
      <source>Software version</source>
      <translation variants="no">Phiên bản phần mềm</translation>
    </message>
    <message numerus="no" id="txt_cp_list_notification_tones">
      <source>Notification tones</source>
      <translation variants="no">Nhạc chuông thông báo</translation>
    </message>
    <message numerus="no" id="txt_cp_text_edit_device_will_be_restarted_to_chang">
      <source>Device will be restarted to change display language. Continue?</source>
      <translation variants="no">Thay đổi ngôn ngữ hiển thị sẽ yêu cầu thiết bị của bạn khởi động lại. Tiếp tục?</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active">
      <source>Silent state active</source>
      <translation variants="no">Đg ở tr.thái im lặng</translation>
    </message>
  </context>
</TS>