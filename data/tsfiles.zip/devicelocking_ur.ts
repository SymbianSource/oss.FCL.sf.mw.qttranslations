<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="no">ur #Cancel</translation>
    </message>
    <message numerus="no" id="txt_common_button_call">
      <source>Call</source>
      <translation variants="no">ur #Call</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="no">ur #OK</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_device_lock">
      <source>Device lock</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلہ قفل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_dialog_new_locking_message">
      <source>New locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا مقفلی پیغام داخل کریں:</lengthvariant>
        <lengthvariant priority="2">نیا مقفلی پیغام داخل:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_dialog_retype_locking_message">
      <source>Retype locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا مقف. پیغام تصدیق:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_create_lock_code">
      <source>Create lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقفل کوڈ تشکیل دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_remote_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_remote_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_sim_changed_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_lock_code">
      <source>Lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">موجودہ مقفل کوڈ داخل کریں:</lengthvariant>
        <lengthvariant priority="2">موجودہ مقفل کوڈ داخل:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_lock_code_unlock">
      <source>Not specified</source>
      <translation variants="no">مقفل کوڈ</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_new_lock_code">
      <source>New lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا مقفل کوڈ داخل کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_retype_new_lock_code">
      <source>Retype new lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا مقفل کوڈ تصدیق:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_codes_do_not_match">
      <source>Codes do not match</source>
      <translation variants="no">کوڈ مطابقت نہیں</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">ہنگامی کالیں</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_lock_code_created">
      <source>Lock code created</source>
      <translation variants="no">مقفل کوڈ تشکیل</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_lock_code_is_blocked">
      <source>Lock code is blocked</source>
      <translation variants="no">مقفل کوڈ بلاک کر دیا گیا</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_locking_message_created">
      <source>Locking message created</source>
      <translation variants="no">مق. پیغام تشکیل</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_messages_do_not_match">
      <source>Messages do not match</source>
      <translation variants="no">پیغام مطا. نہیں</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_wrong_lock_code">
      <source>Wrong lock code</source>
      <translation variants="no">غیر درست مق. کوڈ۔</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpopinfo_try_again">
      <source>Try again</source>
      <translation variants="no">دوبارہ کوشش کریں۔</translation>
    </message>
    <message numerus="yes" id="txt_devicelocking_dpopinfo_wait_ln_minutes">
      <source>Wait %Ln minutes</source>
      <translation>
        <numerusform plurality="a">%Ln منٹ انتظار کریں۔</numerusform>
        <numerusform plurality="b">%Ln منٹ انتظار کریں۔</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_automatic_locking">
      <source>Automatic locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار مقفلی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_device_locking">
      <source>Device locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلہ مقفلی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_lock_code">
      <source>Lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقفل کوڈ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_lock_when_sim_changed">
      <source>Lock when SIM changed</source>
      <translation variants="yes">
        <lengthvariant priority="1">‏SIM کارڈ تبدیل ہونے پر مقفل کریں</lengthvariant>
        <lengthvariant priority="2">‏SIM کارڈ تبدیل پر مقفل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_locking_message">
      <source>Locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">مقفلی پیغام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_remote_locking">
      <source>Remote locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">فاصلاتی مقفلی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_cannot_contain_more_than_l">
      <source>Cannot contain more than %L1 characters</source>
      <translation variants="no">قفل کوڈ %Ln حروف سے زیادہ پر مشتمل نہیں ہو سکتا</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_characters_cannot_be_rep_no">
      <source>Characters cannot be repeated more than %L1 times</source>
      <translation variants="no">ur #Characters cannot be repeated more than %Ln time</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_characters_cannot_be_repeat">
      <source>Characters cannot be repeated</source>
      <translation variants="no">حروف دہرائے نہیں جا سکتے</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_code_must_contain_at_least">
      <source>Code must contain at least %L1 special characters</source>
      <translation variants="no">قفل کوڈ میں کم از کم %Ln خصوصی حروف ہونے چاہئیں</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_code_must_not_contain_conse">
      <source>Code must not contain consecutive characters</source>
      <translation variants="no">کوڈ میں حروف تسلسل میں شامل نہیں کیے جا سکتے</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_code_must_not_contain_singl">
      <source>Code must not contain single repeated character</source>
      <translation variants="no">انفرادی حروف ایک قطار میں کئی بار دہرائے نہیں جا سکتے</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_incorrect_lock_code_one_at">
      <source>Incorrect lock code. One attempt left before data is erased.</source>
      <translation variants="no">غیر درست مقفل کوڈ۔ ڈیٹا مٹائے جانے سے پہلے ایک کوشش باقی ہے۔</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_information_included_in_the">
      <source>Information included in the lock code is not allowed</source>
      <translation variants="no">ur ##Information included in the lock code is not allowed</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_lock_code_can_be_changed_l">
      <source>Lock code can be changed %L1n times in %L2n hours</source>
      <translation variants="no">ur #Lock code can be changed %[26]1 times in %[26]2 hours</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_lock_code_can_be_used_for_p">
      <source>Lock code can be used for protecting the device from unauthorized use</source>
      <translation variants="no">آپ کے آلے کو غیر مجاز شدہ استعمال سے محفوظ رکھنے کے لیے مقفل کوڈ استعمال کیا جا سکتا ہے</translation>
    </message>
    <message numerus="yes" id="txt_devicelocking_info_lock_code_cannot_be_same_as">
      <source>Lock code cannot be same as previous  %Ln lock codes</source>
      <translation>
        <numerusform plurality="a">یہ قفل کوڈ پہلے ہی آخری %Ln کوڈ میں استعمال کیا جا چکا ہے۔ دوبارہ کوشش کریں۔</numerusform>
        <numerusform plurality="b">یہ قفل کوڈ پہلے ہی آخری %Ln کوڈ میں استعمال کیا جا چکا ہے۔ دوبارہ کوشش کریں۔</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_lock_code_is_expired">
      <source>Lock code is expired.</source>
      <translation variants="no">مقفل کوڈ کی مدت ختم ہوگئی۔ </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_more_than_two_consecutive_n">
      <source>More than two consecutive numbers not allowed</source>
      <translation variants="no">تسلسل میں دو سے زیادہ نمبروں کی اجازت نہیں ہے</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_must_be_at_least_l1_charac">
      <source>Must be at least %L1 characters</source>
      <translation variants="no">قفل کوڈ میں کم از کم %Ln حروف ہونے چاہئیں</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_must_include_letters_and_nu">
      <source>Must include letters and numbers</source>
      <translation variants="no">حروف اور نمبروں کو شامل کیا جانا چاہیے</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_must_include_upper_and_lowe">
      <source>Must include upper and lower case characters</source>
      <translation variants="no">بڑے اور چھوٹے حروف کو شامل کیا جانا چاہیے</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_the_locking_message_and_the">
      <source>The locking message and the lock code should not be equal</source>
      <translation variants="no">مقفلی پیغام اور مقفل کوڈ مختلف ہونے چاہیے</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_the_security_code_must_be_a">
      <source>The security code must be alphanumeric</source>
      <translation variants="no">مقفل کوڈ ابجدی عددی ہونا چاہیے</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_30_minutes">
      <source>30 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">۳۰ منٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_5_minutes">
      <source>5 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">۵ منٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_60_minutes">
      <source>60 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">۶۰ منٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_when_keys_screen">
      <source>When keys &amp; screen locked</source>
      <translation variants="yes">
        <lengthvariant priority="1">جب بٹن اور اسکرین مقفل ہیں</lengthvariant>
        <lengthvariant priority="2">جب بٹن و اسکرین مقفل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_subhead_device_locking">
      <source>Device Locking</source>
      <translation variants="no">آلہ مقفلی</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_subhead_remote_locking">
      <source>Remote locking</source>
      <translation variants="no">فاصلاتی مقفلی</translation>
    </message>
    <message numerus="no" id="txt_remotelocking_button_sim_changed_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو</lengthvariant>
      </translation>
    </message>
  </context>
</TS>