<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="no">uk #Alarm time and date</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_on_alarm">
      <source>Alarm</source>
      <translation variants="no">uk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_start_time">
      <source>Start time</source>
      <translation variants="no">uk #Start time</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Start date</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Start date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Daily</source>
      <translation variants="no">uk #Daily</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">uk #Discard changes</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Location</source>
      <translation variants="no">uk #Location</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_on_event_day">
      <source>On event day</source>
      <translation variants="no">uk #On event day</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_15_minutes_befo">
      <source>15 minutes before</source>
      <translation variants="no">uk #15 minutes before</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Start time</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Start time</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_anniversary_saved">
      <source>New anniversary saved</source>
      <translation variants="no">uk #New anniversary saved</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_off">
      <source>Off</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Only once</source>
      <translation variants="no">uk #Not repeated</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>All day event</source>
      <translation variants="no">uk #All-day entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_end_time">
      <source>End time</source>
      <translation variants="no">uk #End time</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Alarm time</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_anniversary">
      <source>Anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Anniversary</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_date">
      <source>Date</source>
      <translation variants="no">uk #Date</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_fortnightly">
      <source>Fortnightly</source>
      <translation variants="no">uk #Fortnightly</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Reminder</source>
      <translation variants="no">uk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entry">
      <source>Delete entry?</source>
      <translation variants="no">uk #Delete entry?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Monthly</source>
      <translation variants="no">uk #Monthly</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_time">
      <source>%1</source>
      <translation variants="no">uk ##%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Alarm date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Delete anniversary?</source>
      <translation variants="no">uk #Delete anniversary?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_meeting_updated">
      <source>Meeting updated</source>
      <translation variants="no">uk #Meeting updated</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_anniversary">
      <source>New anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #New anniversary</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_anniv_default_date">
      <source>%1</source>
      <translation variants="no">uk #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_days">
      <source>Before %Ln days</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">uk #Repeat until</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">uk #Add description</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_workdays">
      <source>Workdays</source>
      <translation variants="no">uk #Workdays</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Delete entries ?</source>
      <translation variants="no">uk #Delete entries ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_time">
      <source>Reminder time</source>
      <translation variants="no">uk #Alarm time</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_event">
      <source>New event</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #New entry</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Yearly</source>
      <translation variants="no">uk #Yearly</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Repeat</source>
      <translation variants="no">uk #Repeat</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_event">
      <source>Delete event</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">uk #Delete meeting?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_meeting_saved">
      <source>New meeting saved</source>
      <translation variants="no">uk #New meeting saved</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">uk #This occurrence only</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">uk #All occurences</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_meeting">
      <source>New meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #New meeting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_off">
      <source>Off</source>
      <translation variants="no">uk #Off</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_at_the_start">
      <source>At the start</source>
      <translation variants="no">uk #At the start</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_5_minutes_befor">
      <source>5 minutes before</source>
      <translation variants="no">uk #5 minutes before</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">uk #Remove description</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Meeting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>End date</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #End date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_occasion">
      <source>Occasion</source>
      <translation variants="no">uk #Occasion</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_hour_before">
      <source>1 hour before</source>
      <translation variants="no">uk #1 hour before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_30_minutes_befo">
      <source>30 minutes before</source>
      <translation variants="no">uk #30 minutes before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_minutes">
      <source>Before %Ln minutes</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_weeks">
      <source>Before %Ln weeks</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_reminder_time">
      <source>%1</source>
      <translation variants="no">uk #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_anniversary_updated">
      <source>Anniversary updated</source>
      <translation variants="no">uk #Anniversary updated</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Edit :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_day_before">
      <source>1 day before</source>
      <translation variants="no">uk #1 day before</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #To-do note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_repeat_until">
      <source>Repeat until</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Repeat until</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>End time</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #End time</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_hours">
      <source>Before %Ln hours</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_date">
      <source>%2</source>
      <translation variants="no">uk ##%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_description">
      <source>Description</source>
      <translation variants="no">uk #Description</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Delete repeated entry :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_2_days_before">
      <source>2 days before</source>
      <translation variants="no">uk #2 days before</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">uk #Subject</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Weekly</source>
      <translation variants="no">uk #Weekly</translation>
    </message>
  </context>
</TS>