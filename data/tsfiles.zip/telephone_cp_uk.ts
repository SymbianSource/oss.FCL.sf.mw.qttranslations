<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_setlabel_if_not_answered">
      <source>If not answered</source>
      <translation variants="no">Якщо немає відповіді</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_ask_first">
      <source>Ask first</source>
      <translation variants="no">Спочатку запитувати</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_video_call_settings">
      <source>Video call settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки відеодзвінків</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting_val_on">
      <source>On</source>
      <translation variants="no">Увімкнено</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Телефон</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting">
      <source>Call waiting</source>
      <translation variants="no">Очікування дзвінків</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_val_line_2">
      <source>Line 2</source>
      <translation variants="no">Лінія 2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_out_of_reach">
      <source>If out of reach</source>
      <translation variants="no">Якщо поза покриттям</translation>
    </message>
    <message numerus="no" id="txt_phone_list_incoming_calls">
      <source>Incoming calls</source>
      <translation variants="no">Вхідні дзвінки</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_send_my_caller_id">
      <source>Send my caller id</source>
      <translation variants="no">Надсил. мої дані абонента</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_delay">
      <source>Delay</source>
      <translation variants="no">uk #Delay</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking">
      <source>Phone line blocking</source>
      <translation variants="no">Зміна лінії</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_barring">
      <source>Call barring</source>
      <translation variants="yes">
        <lengthvariant priority="1">Заборона дзвінків</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_val_user_defined">
      <source>User defined</source>
      <translation variants="no">Визначає користувач</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_ip_mbx">
      <source>%1 mailbox</source>
      <translation variants="no">uk #%[]1 mailbox</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_voice_mbx_line_2">
      <source>Voice mailbox line 2</source>
      <translation variants="no">Голос. скринька на лінії 2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_voice_mbx">
      <source>Voice mailbox</source>
      <translation variants="no">Голосова скринька</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_val_line_1">
      <source>Line 1</source>
      <translation variants="no">Лінія 1</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_no">
      <source>No</source>
      <translation variants="no">Ні</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting_val_off">
      <source>Off</source>
      <translation variants="no">Не ввімкнено</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx">
      <source>Default mailbox</source>
      <translation variants="no">Стандартна</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking_val_off">
      <source>Off</source>
      <translation variants="no">Вимкнути</translation>
    </message>
    <message numerus="no" id="txt_phone_list_incoming_call_when_abroad">
      <source>Incoming call when abroad</source>
      <translation variants="no">Вхідні дзвінки під час роумінгу</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking_val_on">
      <source>On</source>
      <translation variants="no">Увімкнути</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_busy">
      <source>If busy</source>
      <translation variants="no">Якщо зайнято</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_settings">
      <source>Call settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки дзвінків</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Телефон</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_mbx">
      <source>Call mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">Скринька дзвінків</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_list_international_calls">
      <source>International calls</source>
      <translation variants="no">Міжнародні дзвінки</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_received_call">
      <source>Own video in received call</source>
      <translation variants="no">Своє відео для вхідного дзв.</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_ip">
      <source>Not specified</source>
      <translation variants="no">uk #%1</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_call">
      <source>Image in video call</source>
      <translation variants="no">Зображення у відеодзвінку</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_soft_reject_val_default_text">
      <source>Hi, I’m busy at the moment, but I contact you a bit later.</source>
      <translation variants="no">uk #Hi, I’m busy at the moment, but I contact you a bit later.</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_not_available">
      <source>If not available</source>
      <translation variants="no">Якщо абонент недоступний</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_default">
      <source>Default</source>
      <translation variants="no">Установлено мережею</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service_val_video_divert">
      <source>Video divert</source>
      <translation variants="no">Переадрес. відеодзвінків</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_voice">
      <source>Voice</source>
      <translation variants="no">Голосова скринька</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als">
      <source>Phone line in use</source>
      <translation variants="no">Використовувана лінія</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting">
      <source>Internet call waiting</source>
      <translation variants="no">Очікування Інтернет-дзв.</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_voice_line_2">
      <source>Voice line 2</source>
      <translation variants="no">Голосова на лінії 2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service">
      <source>Service</source>
      <translation variants="no">Послуга</translation>
    </message>
    <message numerus="no" id="txt_phone_info_current_password">
      <source>Current password</source>
      <translation variants="no">Поточний пароль:</translation>
    </message>
    <message numerus="no" id="txt_phone_info_password_changed">
      <source>Password changed</source>
      <translation variants="no">Пароль змінено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_waiting_activated">
      <source>Call waiting activated</source>
      <translation variants="no">Очікування дзвінків увімкнено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_waiting_deactivated">
      <source>Call waiting deactivated</source>
      <translation variants="no">Очікування дзвінків вимкнено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_rejected">
      <source>Request rejected</source>
      <translation variants="no">Запит відхилено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_not_confirmed">
      <source>Request not confirmed</source>
      <translation variants="no">Запит не підтверджено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_deactivated">
      <source>Barring deactivated</source>
      <translation variants="no">Заборону вимкнено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">Не дозволено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_requesting">
      <source>Requesting</source>
      <translation variants="no">Триває обробка запиту</translation>
    </message>
    <message numerus="no" id="txt_phone_info_result_unknown">
      <source>Result unknown</source>
      <translation variants="no">Результат невідомий</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_operation_not_successful">
      <source>Barring operation not successful. Contact your service provider</source>
      <translation variants="no">Невдала операція заборони. Зверніться до постачальника послуг.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_new_password">
      <source>New password</source>
      <translation variants="no">Новий пароль:</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_activated">
      <source>Barring activated</source>
      <translation variants="no">Заборону ввімкнено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_not_completed">
      <source>Request not completed</source>
      <translation variants="no">Запит не виконано</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_password">
      <source>Barring password</source>
      <translation variants="no">Пароль заборони:</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_lost_select_network">
      <source>Network lost. Select network?</source>
      <translation variants="no">uk #Network lost. Select network?</translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">uk #Invalid phone number</translation>
    </message>
    <message numerus="no" id="txt_phone_list_to_voice_mailbox">
      <source>To voice mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #To voice mailbox</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_list_enter_number_manually">
      <source>Enter number manually</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Enter number manually</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_number">
      <source>Number:</source>
      <translation variants="no">uk #Number:</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_out_of_reach">
      <source>If out of reach:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #If out of reach:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_diverts_activated">
      <source>Diverts activated</source>
      <translation variants="no">uk #Diverts activated</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_not_available">
      <source>If not available:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #If not available:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_title_all_calls">
      <source>All calls:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #All calls:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_not_answered">
      <source>If not answered:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #If not answered:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_dont_show">
      <source>Don't show</source>
      <translation variants="no">Не показувати</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_available_in_current_lo">
      <source>Service not available in current location</source>
      <translation variants="no">Послуга недоступна в поточному розташуванні</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_on">
      <source>On</source>
      <translation variants="no">Увімкнено</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service_val_voice_divert">
      <source>Voice divert</source>
      <translation variants="no">Переадрес. голосових дзв.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_verify_new_password">
      <source>Verify new password</source>
      <translation variants="no">Підтвердьте новий пароль:</translation>
    </message>
    <message numerus="no" id="txt_phone_info_divert_activated">
      <source>Divert activated</source>
      <translation variants="no">Переадресацію ввімкнено</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_val_none">
      <source>None</source>
      <translation variants="no">Немає</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_edit_barring_password">
      <source>Edit barring password</source>
      <translation variants="no">Редагув. пароль заборони</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_all_calls">
      <source>All calls</source>
      <translation variants="no">Усі дзвінки</translation>
    </message>
    <message numerus="no" id="txt_phone_list_international_calls_except_to_home">
      <source>International calls except to home country</source>
      <translation variants="no">Міжнародні дзвінки, крім домашньої країни</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_video">
      <source>Video</source>
      <translation variants="no">Скринька відео</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_divert">
      <source>Call divert</source>
      <translation variants="yes">
        <lengthvariant priority="1">Переадресація дзвінків</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_yes">
      <source>Yes</source>
      <translation variants="no">Так</translation>
    </message>
    <message numerus="no" id="txt_phone_list_outgoing_calls">
      <source>Outgoing calls</source>
      <translation variants="no">Вихідні дзвінки</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_show_automatic">
      <source>Show automatically</source>
      <translation variants="no">Показувати автоматично</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_soft_reject">
      <source>Reject call with message</source>
      <translation variants="no">Відхиляти дзвінки з повід.</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_video_mbx">
      <source>Video mailbox</source>
      <translation variants="no">Скринька відео</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_off">
      <source>Off</source>
      <translation variants="no">Не ввімкнено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conflict_error">
      <source>Conflict error</source>
      <translation variants="no">Помилка через конфлікт</translation>
    </message>
    <message numerus="no" id="txt_phone_info_divert_deactivated">
      <source>Divert deactivated</source>
      <translation variants="no">Переадресацію вимкнено</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_edit_barring_password_val_edit">
      <source>Edit</source>
      <translation variants="no">Редагувати</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_password_blocked">
      <source>Barring password blocked</source>
      <translation variants="no">Пароль заборони заблоковано</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_busy">
      <source>If busy:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #If busy:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_diverts_deactivated">
      <source>Diverts deactivated</source>
      <translation variants="no">uk #Diverts deactivated</translation>
    </message>
  </context>
</TS>