<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_applib_grid_profiles_widget">
      <source>Profiles widget</source>
      <translation variants="no">vi #Profiles widget</translation>
    </message>
    <message numerus="no" id="txt_applib_list_profiles_widget">
      <source>Profiles widget</source>
      <translation variants="no">Profile</translation>
    </message>
    <message numerus="no" id="txt_profileswidget_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc họp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_profileswidget_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bình thường</lengthvariant>
      </translation>
    </message>
  </context>
</TS>