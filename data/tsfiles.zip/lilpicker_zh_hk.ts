<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_lint_list_recent_map_searches">
      <source>Recent map searches</source>
      <translation variants="no">最近的地圖搜尋</translation>
    </message>
    <message numerus="no" id="txt_lint_list_arrange">
      <source>Arrange</source>
      <translation variants="no">組織</translation>
    </message>
    <message numerus="no" id="txt_lint_list_type">
      <source>Type</source>
      <translation variants="no">類型</translation>
    </message>
    <message numerus="no" id="txt_lint_list_ascending">
      <source>Ascending</source>
      <translation variants="no">遞增</translation>
    </message>
    <message numerus="no" id="txt_lint_list_places">
      <source>Places</source>
      <translation variants="no">位置</translation>
    </message>
    <message numerus="no" id="txt_lint_list_sort_by">
      <source>Sort by </source>
      <translation variants="no">排序依據</translation>
    </message>
    <message numerus="no" id="txt_lint_list_remove_thumbnail">
      <source>Remove thumbnail</source>
      <translation variants="no">移除縮圖</translation>
    </message>
    <message numerus="no" id="txt_lint_list_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="no">聯絡人地址</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_location_entries_present">
      <source>No Location entries present</source>
      <translation variants="no">(沒有位置)</translation>
    </message>
    <message numerus="no" id="txt_lint_button_done">
      <source>Done</source>
      <translation variants="no">完成</translation>
    </message>
    <message numerus="no" id="txt_lint_list_descending">
      <source>Descending</source>
      <translation variants="no">遞減</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_results">
      <source>No results</source>
      <translation variants="no">(找不到結果)</translation>
    </message>
    <message numerus="no" id="txt_lint_list_calendar_event_locations">
      <source>Calendar event locations</source>
      <translation variants="no">日曆項目位置</translation>
    </message>
    <message numerus="no" id="txt_lint_title_select_location">
      <source>Select location</source>
      <translation variants="no">選擇位置</translation>
    </message>
    <message numerus="no" id="txt_lint_list_details">
      <source>Details</source>
      <translation variants="no">資料</translation>
    </message>
  </context>
</TS>