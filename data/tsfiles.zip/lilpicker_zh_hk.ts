<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_lint_button_done">
      <source>Done</source>
      <translation variants="no">完成</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_location_entries_present">
      <source>No Location entries present</source>
      <translation variants="yes">
        <lengthvariant priority="1">(沒有位置)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="yes">
        <lengthvariant priority="1">聯絡人地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_title_select_location">
      <source>Select location</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇位置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_places">
      <source>Places</source>
      <translation variants="yes">
        <lengthvariant priority="1">位置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_select">
      <source>Select</source>
      <translation variants="no">zh_hk #Select</translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_recent_map_searches">
      <source>Recent map searches</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Recent map searches</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_places">
      <source>Places</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Places</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_lint_list_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">zh_hk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by">
      <source>Sort by </source>
      <translation variants="no">zh_hk #Sort by </translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_calendar_event_locations">
      <source>Calendar event locations</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Calendar event locations</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Contact addresses</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by_sub_ascending">
      <source>Ascending</source>
      <translation variants="no">zh_hk #Ascending</translation>
    </message>
    <message numerus="no" id="txt_lint_list_map_searches">
      <source>Map searches</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Map searches</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_menu_remove_thumbnail">
      <source>Remove thumbnail</source>
      <translation variants="no">zh_hk #Remove thumbnail</translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by_sub_descending">
      <source>Descending</source>
      <translation variants="no">zh_hk #Descending</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_results">
      <source>No results</source>
      <translation variants="yes">
        <lengthvariant priority="1">(找不到結果)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_menu_details">
      <source>Details</source>
      <translation variants="no">zh_hk #Details</translation>
    </message>
    <message numerus="no" id="txt_lint_opt_arrange">
      <source>Arrange</source>
      <translation variants="no">zh_hk #Arrange</translation>
    </message>
    <message numerus="no" id="txt_lint_list_calendar_locations">
      <source>Calendar locations</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Calendar locations</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by_sub_type">
      <source>Type</source>
      <translation variants="no">zh_hk #Type</translation>
    </message>
  </context>
</TS>