<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_iti_setlabel_typing_correction">
      <source>Typing correction</source>
      <translation variants="no">文字修正級別</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_character_bubble">
      <source>Character bubble</source>
      <translation variants="no">字符泡泡</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_keypress_timeout">
      <source>Keypress timeout</source>
      <translation variants="no">按鍵逾時</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_prediction">
      <source>Prediction</source>
      <translation variants="no">智慧輸入法</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_prediction_val_none">
      <source>None</source>
      <translation variants="no">無</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_word_autocompletion">
      <source>Word autocompletion</source>
      <translation variants="no">文字自動完成</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_writing_language">
      <source>Writing language</source>
      <translation variants="no">書寫語言</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_off_typing_corr">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_iti_spell">
      <source>Spell</source>
      <translation variants="no">拼字</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_word_autocompletion_val_on">
      <source>On</source>
      <translation variants="no">開</translation>
    </message>
    <message numerus="no" id="txt_iti_prediction_not_supported">
      <source>Prediction not supported</source>
      <translation variants="no">不支援智慧輸入</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_medium">
      <source>Medium</source>
      <translation variants="no">普通</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_on">
      <source>On</source>
      <translation variants="no">開</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_iti_list_letter_keypad">
      <source>Letter keypad</source>
      <translation variants="no">文字鍵盤</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_word_autocompletion_val_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_high">
      <source>High</source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_best_prediction">
      <source>Best prediction</source>
      <translation variants="no">顯示建議字</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_on">
      <source>On</source>
      <translation variants="no">開</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_primary_candidate">
      <source>Primary candidate</source>
      <translation variants="no">文字修正模式</translation>
    </message>
    <message numerus="no" id="txt_iti_title_word">
      <source>Word:</source>
      <translation variants="no">文字：</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_val_exact_typing">
      <source>Exact typing</source>
      <translation variants="no">顯示輸入的文字</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">主要書寫語言</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">次要書寫語言</translation>
    </message>
    <message numerus="no" id="txt_vkb_title_input_settings">
      <source>Input settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">輸入設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_pinyin">
      <source>Pinyin</source>
      <translation variants="no">拼音</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_normal_chinese">
      <source>Normal</source>
      <translation variants="no">中</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_easy">
      <source>Easy</source>
      <translation variants="no">簡單</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_landscape_input_method">
      <source>Landscape input method</source>
      <translation variants="no">橫寫輸入模式</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_default_mode_for_val_english">
      <source>English</source>
      <translation variants="no">英文</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_cangjie_mode">
      <source>Cangjie mode  </source>
      <translation variants="no">倉頡模式  </translation>
    </message>
    <message numerus="no" id="txt_iti_list_number_keypad">
      <source>Number keypad</source>
      <translation variants="no">zh_hk #Number keypad</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_advanced">
      <source>Advanced</source>
      <translation variants="no">zh_hk #Advanced</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_stroke">
      <source>Stroke</source>
      <translation variants="no">zh_hk #Stroke</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_default_mode_for_keyboard_input">
      <source>Default mode for keyboard input</source>
      <translation variants="no">預設模式</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_default_mode_for_val_chinese">
      <source>Chinese</source>
      <translation variants="no">中文</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_handwriting_speed">
      <source>Handwriting speed</source>
      <translation variants="no">手寫速度</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_cangjie">
      <source>Cangjie</source>
      <translation variants="no">倉頡</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_fast">
      <source>Fast</source>
      <translation variants="no">快</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_hwr">
      <source>HWR</source>
      <translation variants="no">手寫</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_normal">
      <source>Normal</source>
      <translation variants="no">中</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_slow">
      <source>Slow</source>
      <translation variants="no">慢</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_very_fast">
      <source>Very fast</source>
      <translation variants="no">非常快</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_very_slow">
      <source>Very slow</source>
      <translation variants="no">非常慢</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_val_zhuyin">
      <source>Zhuyin</source>
      <translation variants="no">注音</translation>
    </message>
    <message numerus="no" id="txt_vkb_setlabel_portrait_input_method">
      <source>Portrait input method</source>
      <translation variants="no">zh_hk #Portrait input method</translation>
    </message>
    <message numerus="no" id="txt_iti_handwriting">
      <source>Handwriting</source>
      <translation variants="no">手寫</translation>
    </message>
    <message numerus="no" id="txt_iti_input_methods">
      <source>Input methods</source>
      <translation variants="no">輸入法</translation>
    </message>
    <message numerus="no" id="txt_iti_input_settings">
      <source>Input settings</source>
      <translation variants="no">輸入設定</translation>
    </message>
    <message numerus="no" id="txt_iti_language">
      <source>Language</source>
      <translation variants="no">語言</translation>
    </message>
    <message numerus="no" id="txt_iti_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_iti_on">
      <source>On</source>
      <translation variants="no">開</translation>
    </message>
    <message numerus="no" id="txt_iti_prediction">
      <source>Prediction</source>
      <translation variants="no">智慧輸入法</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_itut">
      <source>ITU-T</source>
      <translation variants="no">ITU-T</translation>
    </message>
    <message numerus="no" id="txt_iti_setlabel_qwerty">
      <source>Qwerty</source>
      <translation variants="no">QWERTY</translation>
    </message>
    <message numerus="no" id="txt_iti_subhead_prediction_settings">
      <source>Prediction settings</source>
      <translation variants="no">智慧輸入法設定</translation>
    </message>
    <message numerus="no" id="txt_iti_subhead_swype_settings">
      <source>Swype settings</source>
      <translation variants="no">Swype設定</translation>
    </message>
    <message numerus="no" id="txt_iti_swype">
      <source>Swype</source>
      <translation variants="no">Swype</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_keyboard">
      <source>Keyboard</source>
      <translation variants="no">鍵盤</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_chinese_input_settings_hk">
      <source>Chinese input settings (HK)</source>
      <translation variants="no">中文輸入設定(香港)</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_chinese_input_settings_simplified">
      <source>Chinese input settings (Simplified)</source>
      <translation variants="no">中文輸入設定(簡體)</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_chinese_input_settings_taiwan">
      <source>Chinese input settings (Taiwan)</source>
      <translation variants="no">中文輸入設定(台灣)</translation>
    </message>
    <message numerus="no" id="txt_vkb_subhead_language">
      <source>Language</source>
      <translation variants="no">語言</translation>
    </message>
  </context>
</TS>