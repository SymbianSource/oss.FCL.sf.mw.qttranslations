<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phob_info_no_services_activated_would_you_lik">
      <source>No services activated, would you like to do it now?</source>
      <translation variants="no">无服务启动。现在启动？</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_home">
      <source>Email (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_no_sim_contacts">
      <source>No SIM contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">无SIM卡名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">添加详情</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_note">
      <source>Edit note</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑备忘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_contact_card_image_to_business_c">
      <source>Add contact card image to Business card?</source>
      <translation variants="no">同时包括名片卡图像？</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_matches">
      <source>No matches</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_url">
      <source>Add URL</source>
      <translation variants="no">添加网址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url">
      <source>Delete URL</source>
      <translation variants="no">删除网址</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts">
      <source>All contacts</source>
      <translation variants="no">全部名片</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_services_activated">
      <source>No services activated.</source>
      <translation variants="no">无服务启动</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone">
      <source>Delete Internet telephone</source>
      <translation variants="no">删除互联网电话</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_pager">
      <source>Delete Pager</source>
      <translation variants="no">删除寻呼机</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_sim">
      <source>Import from SIM</source>
      <translation variants="yes">
        <lengthvariant priority="1">从SIM卡导入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_home">
      <source>Delete Email (home)</source>
      <translation variants="no">删除电子邮件地址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_car">
      <source>Delete Car</source>
      <translation variants="no">删除车载电话</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax">
      <source>Delete Fax</source>
      <translation variants="no">删除传真</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_spouse">
      <source>Delete Spouse</source>
      <translation variants="no">删除配偶姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_date">
      <source>Add Date</source>
      <translation variants="no">添加日期</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_work">
      <source>Delete Phone (work)</source>
      <translation variants="no">删除电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_ringing_tone">
      <source>Delete Ringing tone</source>
      <translation variants="no">删除铃声</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_assistant">
      <source>Delete Assistant</source>
      <translation variants="no">删除助理号码</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_sign_out">
      <source>Sign out</source>
      <translation variants="no">注销</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_manage_services">
      <source>Manage services</source>
      <translation variants="yes">
        <lengthvariant priority="1">管理服务</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_sip">
      <source>Delete SIP</source>
      <translation variants="no">删除SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_my_details">
      <source>Edit My details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑我的名片卡详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_company_details">
      <source>Add Company details</source>
      <translation variants="no">添加公司详情</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_remove_all_personal_data_from_my_c">
      <source>Remove all personal data from My card</source>
      <translation variants="no">从我的名片卡清除所有个人数据？</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_company_details">
      <source>Delete Company Details</source>
      <translation variants="no">删除公司详情</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_work">
      <source>Delete Fax (work)</source>
      <translation variants="no">删除传真(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts_sync">
      <source>Contacts sync</source>
      <translation variants="yes">
        <lengthvariant priority="1">同步名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_home">
      <source>Delete Phone (home)</source>
      <translation variants="no">删除电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_device">
      <source>Importing contacts from Device</source>
      <translation variants="no">正在从手机导入名片</translation>
    </message>
    <message numerus="no" id="txt_phob_button_manage_services">
      <source>Manage services</source>
      <translation variants="no">管理服务</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_work">
      <source>Delete Mobile (work)</source>
      <translation variants="no">删除手机(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_ovi">
      <source>Importing contacts from OVI</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi">
      <source>Import from OVI</source>
      <translation variants="yes">
        <lengthvariant priority="1">与Ovi通讯录同步</lengthvariant>
        <lengthvariant priority="2">zh #Sync with Ovi Contacts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_email">
      <source>Add Email</source>
      <translation variants="no">添加电子邮件地址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_number">
      <source>Add Number</source>
      <translation variants="no">添加电话号码</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_children">
      <source>Delete Children</source>
      <translation variants="no">删除子女姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_home">
      <source>Delete Internet telephone (home)</source>
      <translation variants="no">删除互联网电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_no_sim_card">
      <source>No SIM card</source>
      <translation variants="yes">
        <lengthvariant priority="1">无SIM卡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_birthday">
      <source>Delete Birthday</source>
      <translation variants="no">删除生日</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_note">
      <source>Delete Note</source>
      <translation variants="no">删除备忘</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile">
      <source>Delete Mobile</source>
      <translation variants="no">删除手机</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone">
      <source>Delete Phone</source>
      <translation variants="no">删除电话</translation>
    </message>
    <message numerus="no" id="txt_phob_list_business_card">
      <source>Business card</source>
      <translation variants="no">zh #Business card</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">互联网电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">互联网电话</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_video_call">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_video_call_work">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_video_call_home">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_home">
      <source>URL (home)</source>
      <translation variants="no">网址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_home">
      <source>Email (home)</source>
      <translation variants="no">电子邮件地址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_only_group_will_be_removed_contac">
      <source>Only group will be removed. Contacts can be found from all contacts list.</source>
      <translation variants="no">将只删除分组。仍能从所有名片列表找到名片。</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_countryregion">
      <source>Country/Region</source>
      <translation variants="no">国家/地区</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_1_group">
      <source>%1 group</source>
      <translation variants="no">分组%1</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_image_not_added">
      <source>Image not included.</source>
      <translation variants="no">不包括图像</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_stateprovince">
      <source>State/Province</source>
      <translation variants="no">省/市/区</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_work">
      <source>Fax (work)</source>
      <translation variants="no">传真(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url">
      <source>URL</source>
      <translation variants="no">网址</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_home">
      <source>Fax (home)</source>
      <translation variants="no">传真(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_manage_services">
      <source>Manage services</source>
      <translation variants="yes">
        <lengthvariant priority="1">管理服务</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_group">
      <source>New group</source>
      <translation variants="no">新建分组</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_delete_1_group">
      <source>Delete %1 group?</source>
      <translation variants="no">删除分组%[08]1？</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_image">
      <source>Remove image</source>
      <translation variants="no">删除图像</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message_val_members">
      <source>Members</source>
      <translation variants="yes">
        <lengthvariant priority="1">成员</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_history_with_1">
      <source>History with %1</source>
      <translation variants="no">与%1的会话</translation>
    </message>
    <message numerus="no" id="txt_phob_list_received">
      <source>Received</source>
      <translation variants="no">zh #Received call</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_services">
      <source>Manage services</source>
      <translation variants="no">管理服务</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_matching_contacts">
      <source>(no matching contacts)</source>
      <translation variants="no">zh #(no matches)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_you_can_restore_linking_at_any_tim">
      <source>You can restore linking at any time by `Link profile´ or in Service view.</source>
      <translation variants="no">可以在任何时候通过选择"链接个人资料"或在服务视图中恢复链接。</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">zh #Contacts</translation>
    </message>
    <message numerus="no" id="txt_phob_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">地址详情</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">(未命名)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email">
      <source>Email</source>
      <translation variants="no">电子邮件地址</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_status_update">
      <source>Status update</source>
      <translation variants="no">状态</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company_details_val_fax">
      <source>Fax</source>
      <translation variants="no">zh #Fax</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ovi_val_connected_to_1">
      <source>Connected to %1</source>
      <translation variants="no">已连接至%[09]1</translation>
    </message>
    <message numerus="no" id="txt_phob_title_favorite_contacts">
      <source>Favorite contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">常用联系人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_1_group_created">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">互联网电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">关闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_mail_for_exchange">
      <source>Find: Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜索：Exchange邮件同步</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_message">
      <source>Message</source>
      <translation variants="yes">
        <lengthvariant priority="1">经信息</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_phob_title_l1_matches_found">
      <source>%L1 Matches found</source>
      <translation>
        <numerusform plurality="a">找到%Ln个匹配</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_url">
      <source>Add Url</source>
      <translation variants="no">添加网址</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_sign_in_to_res">
      <source>Sign in to restore or create account</source>
      <translation variants="yes">
        <lengthvariant priority="1">登录您的诺基亚帐户</lengthvariant>
        <lengthvariant priority="2">zh #Register to create Account</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">互联网电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_searching_1">
      <source>Searching %1</source>
      <translation variants="no">正在搜索"%[28]1"</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ovi">
      <source>Ovi</source>
      <translation variants="no">诺基亚帐户</translation>
    </message>
    <message numerus="no" id="txt_phob_list_conference_call">
      <source>Conference call</source>
      <translation variants="no">会议通话</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_mail">
      <source>Send mail</source>
      <translation variants="no">发送电子邮件</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts2">
      <source>All contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">全部名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">Exchange邮件同步</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_import_contacts">
      <source>Import contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">导入名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_method">
      <source>Select method</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_groups">
      <source>Delete groups</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除分组</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">经蓝牙</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_link_profiles">
      <source>Link profiles</source>
      <translation variants="yes">
        <lengthvariant priority="1">链接情景模式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_message">
      <source>Send message</source>
      <translation variants="no">发送信息</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_online">
      <source>Not specified</source>
      <translation variants="no">在线</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_home">
      <source>Address (home)</source>
      <translation variants="no">地址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_company_details">
      <source>Not specified</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑公司详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_online2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_home">
      <source>Call phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打电话(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_work">
      <source>Call phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打电话(办公)</lengthvariant>
        <lengthvariant priority="2">zh #Call telephone (bus.)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete2">
      <source>Delete</source>
      <translation variants="no">删除</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_work">
      <source>Address (work)</source>
      <translation variants="no">地址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number">
      <source>Video call</source>
      <translation variants="no">拨打视频电话</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_work">
      <source>Email (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_contact_to_homescreen">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_address">
      <source>Add address</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_note">
      <source>Note</source>
      <translation variants="yes">
        <lengthvariant priority="1">备忘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_phone_number">
      <source>Edit phone number</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑电话号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_work">
      <source>Phone (work)</source>
      <translation variants="no">电话号码(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_find2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_default_saving_memory_val_phone">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile">
      <source>Mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">zh ##Contacts</translation>
    </message>
    <message numerus="no" id="txt_phob_missing_phonebook">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_assistant">
      <source>Assistant</source>
      <translation variants="no">助理姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_take_a_new_photo">
      <source>Take a new photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">拍摄新图像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">放弃所做更改</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_my_card">
      <source>Save My card</source>
      <translation variants="no">储存我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_my_card">
      <source>Not specified</source>
      <translation variants="no">发送我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites">
      <source>Favorites</source>
      <translation variants="no">常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile">
      <source>Call mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打手机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_internet_call_work">
      <source>Call internet call (work)</source>
      <translation variants="no">拨打互联网电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">互联网电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_merge3">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_conflicts_resolving">
      <source>Conflicts resolving</source>
      <translation variants="no">冲突解决</translation>
    </message>
    <message numerus="no" id="txt_phob_list_phone_local_contacts">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">从收藏夹删除</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_import_contacts">
      <source>Import contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">导入名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_note2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_account">
      <source>Not specified</source>
      <translation variants="no">添加帐户</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_date">
      <source>Edit date</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_personal_ringing_tone_val_default">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">创建我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_do_you_want_to_delete_selected_con">
      <source>Do you want to delete selected contacts?</source>
      <translation variants="no">删除所选名片？</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_home">
      <source>Email (home)</source>
      <translation variants="no">发送电子邮件(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">聊天室(%[06]1)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importin_contacts_from_1">
      <source>Importing contacts from %1</source>
      <translation variants="no">zh #Importing contacts from %1</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_ptt">
      <source>SIP</source>
      <translation variants="no">启动按键通话</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_1_group_members">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_info_you_can_choose_any_of_the_following">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_internet_call">
      <source>Call internet call</source>
      <translation variants="no">拨打互联网电话</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_company">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_reorder_favorites">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_home2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_group_name">
      <source>Group name</source>
      <translation variants="no">通话组名称</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ringing_tone">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_clear_history">
      <source>Not specified</source>
      <translation variants="no">清除历史记录</translation>
    </message>
    <message numerus="no" id="txt_phob_title_your_phonebook_is_empty_you_can_ch">
      <source>Your Phonebook is empty</source>
      <translation variants="no">无名片</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">铃声</translation>
    </message>
    <message numerus="yes" id="txt_phob_dblist_val_ln_numbers">
      <source>%Ln numbers</source>
      <translation>
        <numerusform plurality="a">zh #%Ln number</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_default_saving_memory">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show">
      <source>Show</source>
      <translation variants="no">显示</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_name">
      <source>Enter name</source>
      <translation variants="no">zh #Name</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_disconnect_all">
      <source>Not specified</source>
      <translation variants="no">断开所有连接</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_syncronization_val_private">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create">
      <source>Create</source>
      <translation variants="yes">
        <lengthvariant priority="1">创建</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_synchronization_details">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_field">
      <source>Add field</source>
      <translation variants="yes">
        <lengthvariant priority="1">添加详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_internet_call_work">
      <source>Call internet call (work)</source>
      <translation variants="no">拨打互联网电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_contact_card">
      <source>Not specified</source>
      <translation variants="no">zh #Save contact</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_job_title">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_work">
      <source>URL (work)</source>
      <translation variants="no">转至网址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_phone_number">
      <source>Add phone number</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_syncronization_val_public">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_email">
      <source>Set as default email</source>
      <translation variants="no">设为预设电子邮件</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_children">
      <source>Children</source>
      <translation variants="no">子女</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1">
      <source>Import from %1</source>
      <translation variants="no">zh #Import from %1</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">互联网电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_picture">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_name">
      <source>Edit contact name</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑联系人姓名</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_assistant">
      <source>Call assistant</source>
      <translation variants="no">呼叫助理</translation>
    </message>
    <message numerus="no" id="txt_phob_list_public">
      <source>Public</source>
      <translation variants="no">zh #Public</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">名</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_home">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_work">
      <source>Video call (work)</source>
      <translation variants="no">拨打视频电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_anniversary">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_work">
      <source>Fax (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送传真(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_1_deleted">
      <source>Not specified</source>
      <translation variants="no">zh #%[30]1 deleted</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_pager">
      <source>Call Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打寻呼机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete3">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_internet_call_home">
      <source>Call internet call (home)</source>
      <translation variants="no">拨打互联网电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_video_call">
      <source>Not specified</source>
      <translation variants="no">视频通话</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sufix">
      <source>Suffix</source>
      <translation variants="no">头衔</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_group">
      <source>Delete group</source>
      <translation variants="no">删除通话组</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_nick_name">
      <source>Nick name</source>
      <translation variants="no">昵称</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打手机(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_address">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone_val_default">
      <source>Default</source>
      <translation variants="no">预设铃声</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_manage_contacts">
      <source>Manage contacts</source>
      <translation variants="no">管理名片</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_home">
      <source>Video call (home)</source>
      <translation variants="no">拨打视频电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_ln_contacts_imported">
      <source>%Ln contacts imported</source>
      <translation variants="no">%L1/%L2名片已导入</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_new">
      <source>Create new</source>
      <translation variants="no">新建</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_in_progress_l">
      <source>In progress (%L1/%L2)</source>
      <translation variants="no">正在导入名片(%L1/%L2)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_missing_all_contacts">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">纪念日</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_street2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_favorites">
      <source>Favorites</source>
      <translation variants="no">常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_and_phonenumber">
      <source>Name and phonenumber</source>
      <translation variants="no">姓名和手机号码</translation>
    </message>
    <message numerus="no" id="txt_phob_list_family">
      <source>Family</source>
      <translation variants="yes">
        <lengthvariant priority="1">家庭详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_change_picture">
      <source>Change picture</source>
      <translation variants="no">更改图像</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_reorder_groups">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_im">
      <source>Not specified</source>
      <translation variants="no">聊天详情</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_first_nam">
      <source>First name Last name</source>
      <translation variants="no">名前姓后</translation>
    </message>
    <message numerus="no" id="txt_phob_button_select_location">
      <source>Select location</source>
      <translation variants="no">zh #Find on map</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_birthday">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email">
      <source>Email</source>
      <translation variants="no">发送电子邮件</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization_val_none">
      <source>none</source>
      <translation variants="no">无</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_dublicated_contacts">
      <source>Dublicated contacts</source>
      <translation variants="no">重复名片</translation>
    </message>
    <message numerus="no" id="txt_phob_button_activity_stream">
      <source>Activity stream</source>
      <translation variants="no">社交订阅源</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_image">
      <source>Image</source>
      <translation variants="no">图像</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_country">
      <source>Country</source>
      <translation variants="no">国家/地区</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_work">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_refresh">
      <source>Refresh</source>
      <translation variants="no">刷新</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_home">
      <source>Delete Mobile (home)</source>
      <translation variants="no">删除手机(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_work">
      <source>URL (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email">
      <source>Delete Email</source>
      <translation variants="no">删除电子邮件地址</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_service">
      <source>Add service</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax">
      <source>Fax</source>
      <translation variants="no">发送传真</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage">
      <source>Manage contacts</source>
      <translation variants="no">管理名片</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_presentation_settings">
      <source>Presentation settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">名片设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization_val_public">
      <source>public</source>
      <translation variants="no">公开</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_number">
      <source>Conference number</source>
      <translation variants="no">会议通话号码</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_work">
      <source>Send mail (Work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送电子邮件(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name_separator">
      <source>Last name, First name</source>
      <translation variants="no">名，姓</translation>
    </message>
    <message numerus="no" id="txt_phob_list_missed_call">
      <source>Missed call</source>
      <translation variants="no">zh #Missed call</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_pager">
      <source>Call Pager</source>
      <translation variants="no">拨打寻呼机</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打车载电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_field2">
      <source>Not specified</source>
      <translation variants="no">添加栏位</translation>
    </message>
    <message numerus="yes" id="txt_phob_list_ln_numbers">
      <source>%Ln number</source>
      <translation>
        <numerusform plurality="a">%Ln个号码</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_clear_communications_history_with_1">
      <source>Delete communications history with %1?</source>
      <translation variants="no">删除与%[39]1的通讯历史记录？</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_sim">
      <source>Importing contacts from SIM</source>
      <translation variants="no">正在从SIM卡导入名片</translation>
    </message>
    <message numerus="no" id="txt_phob_list_fetch_from_1">
      <source>Fetch from %1</source>
      <translation variants="no">从%1提取</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_assistant">
      <source>Assistant</source>
      <translation variants="no">助理电话号码</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_dublicates_found_see_contacts_tha">
      <source>Dublicates found. See contacts that have several dublicates in Contacts list?</source>
      <translation variants="no">找到重复名片。查看名片列表中存在重复的名片？</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_home">
      <source>Fax (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送传真(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_email_address">
      <source>Add email address</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email">
      <source>Send email</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送电子邮件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_mark_all">
      <source>Mark all</source>
      <translation variants="no">标记全部</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile">
      <source>Call Mobile</source>
      <translation variants="no">拨打手机</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_work">
      <source>Delete Address (work)</source>
      <translation variants="no">删除地址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_choose_from_my_contacts">
      <source>Choose from my contacts</source>
      <translation variants="no">从名片中选择</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="no">拨打手机(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_group_1_created">
      <source>New group %1 created</source>
      <translation variants="no">新分组%[12]1已创建</translation>
    </message>
    <message numerus="no" id="txt_phob_list_yesterday_1">
      <source>yesterday %L1</source>
      <translation variants="no">zh #Yesterday %L1</translation>
    </message>
    <message numerus="no" id="txt_missing_button_add_to_contacts">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile">
      <source>Mobile</source>
      <translation variants="no">手机</translation>
    </message>
    <message numerus="no" id="txt_phob_button_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">导入名片</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_work">
      <source>Fax (work)</source>
      <translation variants="no">发送传真(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_to_contacts">
      <source>Add to contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">增加至名片夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_url_address">
      <source>Add url address</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_contact_saving">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_country2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_personal_ringing_tone">
      <source>Personal ringing tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">铃声</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name">
      <source>Last name First name</source>
      <translation variants="no">姓前名后</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_field">
      <source>Not specified</source>
      <translation variants="no">添加详情</translation>
    </message>
    <message numerus="no" id="txt_phob_title_show_in_contacts_list">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone">
      <source>Phone</source>
      <translation variants="no">电话号码</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_number">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_1">
      <source>Add %1</source>
      <translation variants="no">添加%[09]1</translation>
    </message>
    <message numerus="no" id="txt_phob_info_create_own_card_to_share_it_with_fri">
      <source>Create own card to share it with friends</source>
      <translation variants="no">用您的个人详情创建名片卡并与朋友共享</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_to_homescreen">
      <source>Send to homescreen</source>
      <translation variants="no">增加至主屏幕</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message">
      <source>Send message</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送信息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_chooce_from_gallery">
      <source>Chooce from gallery</source>
      <translation variants="yes">
        <lengthvariant priority="1">从照片中选择</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_department">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_you_are_merging">
      <source>You are merging:</source>
      <translation variants="no">合并名片：</translation>
    </message>
    <message numerus="no" id="txt_phob_list_online">
      <source>Not specified</source>
      <translation variants="no">在线</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_group_details">
      <source>Edit group details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑通话组详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_work">
      <source>Email (work)</source>
      <translation variants="no">发送电子邮件(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address">
      <source>Address</source>
      <translation variants="no">地址</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_car">
      <source>Car</source>
      <translation variants="yes">
        <lengthvariant priority="1">车载电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_online">
      <source>Not specified</source>
      <translation variants="no">在线</translation>
    </message>
    <message numerus="no" id="txt_phob_list_favorites2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_home">
      <source>Address (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_internet_call">
      <source>Call internet call</source>
      <translation variants="no">拨打互联网电话</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打手机(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_message">
      <source>Send message</source>
      <translation variants="no">发送信息</translation>
    </message>
    <message numerus="no" id="txt_phob_button_clear">
      <source>Not specified</source>
      <translation variants="no">清除</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit_my_card">
      <source>Not specified</source>
      <translation variants="no">编辑我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_province2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_home">
      <source>URL (home)</source>
      <translation variants="no">转至网址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_to_group">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone">
      <source>Call phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">名片夹</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_details">
      <source>Edit contact details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑名片详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">删除名片</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_importing_contacts_val_in_progress">
      <source>In progress (%L1/%L2)</source>
      <translation variants="no">正在导入名片(%L1/%L2)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_1">
      <source>Find: %1</source>
      <translation variants="no">搜索：%[13]1</translation>
    </message>
    <message numerus="no" id="txt_phob_button_merge">
      <source>Merge</source>
      <translation variants="no">合并</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_conference_call">
      <source>Conference call</source>
      <translation variants="yes">
        <lengthvariant priority="1">会议通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">聊天室(%[08]1)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_none">
      <source>None</source>
      <translation variants="no">zh #None</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_video_number">
      <source>Call video number</source>
      <translation variants="no">拨打视频电话</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_l1_contacts_deleted">
      <source>Not specified</source>
      <translation variants="no">zh #%Ln contact deleted</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">互联网电话</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_assistant">
      <source>Call assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">呼叫助理</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_your_own_card">
      <source>Create your own card</source>
      <translation variants="no">创建我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">称谓</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_all_contacts">
      <source>Not specified</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜索：所有名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_note">
      <source>Note</source>
      <translation variants="no">备忘</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_search_for_dublicates">
      <source>Search for dublicates</source>
      <translation variants="no">搜索重复名片</translation>
    </message>
    <message numerus="no" id="txt_phob_button_history">
      <source>History</source>
      <translation variants="no">历史记录</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_favorites_selected_select_your_p">
      <source>No favorites selected, select your preferrred contacts</source>
      <translation variants="no">无联系人被标记为常用联系人。将首选联系人添加至常用联系人中。</translation>
    </message>
    <message numerus="no" id="txt_phob_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="no">zh #Update existing contact</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_as_a_business_card">
      <source>Send as a business card</source>
      <translation variants="no">作为名片发送</translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete_group">
      <source>Delete group</source>
      <translation variants="no">删除分组</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_email_address">
      <source>Edit email address</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑电子邮件地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_merge2">
      <source>Merge</source>
      <translation variants="no">合并</translation>
    </message>
    <message numerus="no" id="txt_phob_button_group_actions">
      <source>Group actions</source>
      <translation variants="no">通话组选项</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contacts_1_updated">
      <source>Contact %1 updated</source>
      <translation variants="no">名片%[13]1已更新</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_home">
      <source>Delete Address (home)</source>
      <translation variants="no">删除地址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sim_card_error">
      <source>SIM card error </source>
      <translation variants="no">zh #SIM card error </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_formlabel_val_no_date_set">
      <source>No date set</source>
      <translation variants="no">(未设置日期)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_sign_in">
      <source>Sign in</source>
      <translation variants="no">登录</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sync_with_ovi_contacts">
      <source>Sync with OVI contacts</source>
      <translation variants="no">正在同步名片</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_home">
      <source>Delete URL (home)</source>
      <translation variants="no">删除网址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_anniversary">
      <source>Delete Anniversary</source>
      <translation variants="no">删除纪念日</translation>
    </message>
    <message numerus="no" id="txt_phob_list_phonebook">
      <source>Phonebook</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_web_address">
      <source>Edit web address</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑网址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_home">
      <source>Call Phone (home)</source>
      <translation variants="no">拨打电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_mycard_image_to_business_card">
      <source>Add MyCard image to Business card?</source>
      <translation variants="no">同时包括我的名片卡图像？</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax">
      <source>Fax</source>
      <translation variants="no">传真</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_restore_default_settings">
      <source>Not specified</source>
      <translation variants="no">恢复预设设置</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_work">
      <source>Delete Internet telephone (work)</source>
      <translation variants="no">删除互联网电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address">
      <source>Delete Address</source>
      <translation variants="no">删除地址</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_cancel_merge">
      <source>Cancel merge</source>
      <translation variants="no">取消合并</translation>
    </message>
    <message numerus="no" id="txt_phob_button_send_my_card">
      <source>Send My card</source>
      <translation variants="no">发送我的名片</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_favorites">
      <source>Manage favorites</source>
      <translation variants="no">管理常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_work">
      <source>Email (work)</source>
      <translation variants="no">电子邮件地址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_postal_codezip_code">
      <source>Postal code/ZIP code</source>
      <translation variants="no">邮政编码</translation>
    </message>
    <message numerus="no" id="txt_missing_list_save_as_a_new_contact">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_contacts">
      <source>Delete contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Delete contacts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_to_homescreen_as_widget">
      <source>Send to homescreen</source>
      <translation variants="no">增加至主屏幕</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit_group_details">
      <source>Edit group details</source>
      <translation variants="no">编辑通话组详情</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_province">
      <source>Province</source>
      <translation variants="no">省/市/区</translation>
    </message>
    <message numerus="no" id="txt_phob_list_number">
      <source>Number</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contact_1_saved">
      <source>Contact %1 saved</source>
      <translation variants="no">名片%[13]1已创建</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company">
      <source>Company</source>
      <translation variants="no">公司</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_filter">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">导入名片</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_assistant">
      <source>Assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">助理电话号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_all_contacts">
      <source>All contacts</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="no">拨打车载电话</translation>
    </message>
    <message numerus="no" id="txt_phob_list_creating_1_group">
      <source>Creating %1 group</source>
      <translation variants="no">正在创建分组%1</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_email">
      <source>Add email</source>
      <translation variants="no">添加电子邮件地址</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_sync_with_ovi">
      <source>Sync with OVI</source>
      <translation variants="no">与Ovi通讯录同步</translation>
    </message>
    <message numerus="no" id="txt_phob_list_sychronization">
      <source>Sychronization</source>
      <translation variants="no">同步</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_change_image">
      <source>Change image</source>
      <translation variants="yes">
        <lengthvariant priority="1">更改图像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_link_to_phonebook">
      <source>Link to phonebook</source>
      <translation variants="no">链接至名片夹</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_delete_contacts">
      <source>Delete contacts</source>
      <translation variants="no">zh #Delete contacts?</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_my_card">
      <source>Clear My card</source>
      <translation variants="no">清除我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_info_with_ovi_by_nokia_you_can_access_you">
      <source>With Ovi by Nokia you can access your favourite social networks and make your Contacts social. Sign in with your Nokia account to get started.</source>
      <translation variants="no">通过Ovi by Nokia可访问常用社交网络，并使您的名片夹成为一个小群体。登录诺基亚帐户，然后开始。</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_address">
      <source>Add Address</source>
      <translation variants="no">添加地址</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_search_for_matched_contacts">
      <source>Search for matched contacts</source>
      <translation variants="no">搜索匹配项</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_device">
      <source>Import from Device</source>
      <translation variants="yes">
        <lengthvariant priority="1">从手机导入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_family_details">
      <source>Add Family details</source>
      <translation variants="no">添加家庭详情</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_accounts">
      <source>Accounts</source>
      <translation variants="no">帐户</translation>
    </message>
    <message numerus="no" id="txt_phob_button_find">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_internet_number">
      <source>Edit internet number</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑互联网电话详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_street">
      <source>Street</source>
      <translation variants="no">街道</translation>
    </message>
    <message numerus="no" id="txt_phob_title_members_of_1_group">
      <source>%1 members</source>
      <translation variants="no">%[10]1成员</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_pager">
      <source>Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">寻呼机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_new_group_name">
      <source>New group name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">通话组名称：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_edit_members">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_history">
      <source>Delete history</source>
      <translation variants="no">清除历史记录</translation>
    </message>
    <message numerus="no" id="txt_phob_button_stop_import">
      <source>Stop import</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">中间名</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_work">
      <source>Phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话号码(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="no">手机(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">从收藏夹删除</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">职位</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_only">
      <source>Name only</source>
      <translation variants="no">仅姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_image">
      <source>Remove image</source>
      <translation variants="no">删除图像</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard_val_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">zh #Create my card</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_home">
      <source>Delete Fax (home)</source>
      <translation variants="no">删除传真(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_home">
      <source>URL (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_car">
      <source>Car</source>
      <translation variants="no">车载电话</translation>
    </message>
    <message numerus="no" id="txt_phob_info_delete_1">
      <source>Delete %1?</source>
      <translation variants="no">删除
%[39]1？</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company_details">
      <source>Company Details</source>
      <translation variants="no">公司详情</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_contact">
      <source>New contact</source>
      <translation variants="no">新名片</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_group">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax">
      <source>Fax</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送传真</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_number">
      <source>Add number</source>
      <translation variants="no">添加号码</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_group_mail">
      <source>Not specified</source>
      <translation variants="no">发送分组电子邮件</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_post_code">
      <source>Post code</source>
      <translation variants="no">邮政编码</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_favorites">
      <source>Add favorites</source>
      <translation variants="no">添加常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_home">
      <source>Send mail (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送电子邮件(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">Exchange邮件同步</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_number">
      <source>Set as default number</source>
      <translation variants="no">设为预设号码</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_home">
      <source>Fax (home)</source>
      <translation variants="no">发送传真(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_contact">
      <source>Save contact</source>
      <translation variants="no">储存名片</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_pobox">
      <source>P.O.Box</source>
      <translation variants="no">邮政信箱</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_pin">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_anniversary">
      <source>Anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">纪念日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites_val_no_favorites_selecte">
      <source>No favorites selected</source>
      <translation variants="no">无常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_birthday">
      <source>Birthday</source>
      <translation variants="no">生日</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_group_message">
      <source>Not specified</source>
      <translation variants="no">发送分组信息</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_home">
      <source>Phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话号码(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url">
      <source>URL</source>
      <translation variants="no">转至网址</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_video_call_work">
      <source>Not specified</source>
      <translation variants="no">视频通话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_work">
      <source>Call Phone (work)</source>
      <translation variants="no">拨打电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_edit">
      <source>Edit</source>
      <translation variants="no">编辑</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_find_from">
      <source>Find from:</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜索位置：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_unable_to_access_contacts_in_memory">
      <source>Unable to access contacts in memory: %1</source>
      <translation variants="no">zh #Unable to access contacts saved to %1</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_social_view">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">姓</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_updated_1">
      <source>Updated %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">已更新：%L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_work">
      <source>Address (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order">
      <source>Name display order</source>
      <translation variants="no">显示姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_list_dialled_call">
      <source>Dialled call</source>
      <translation variants="no">zh #Dialled call</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_family_details">
      <source>Edit family details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑家庭详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_group">
      <source>Remove from group</source>
      <translation variants="no">从名片分组删除</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_video_number_home">
      <source>Call video number (home)</source>
      <translation variants="no">拨打视频电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_groups">
      <source>Delete groups</source>
      <translation variants="no">删除通话组</translation>
    </message>
    <message numerus="no" id="txt_phob_list_company_details">
      <source>Company Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">公司详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_video_number_work">
      <source>Call video number (work)</source>
      <translation variants="no">拨打视频电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_unknown">
      <source>Unknown</source>
      <translation variants="no">zh #Unknown</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">互联网电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_home">
      <source>Phone (home)</source>
      <translation variants="no">电话号码(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_select_contact">
      <source>Select contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_work">
      <source>URL (work)</source>
      <translation variants="no">网址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_link_in_1">
      <source>Link in %1</source>
      <translation variants="no">链接至%1</translation>
    </message>
    <message numerus="no" id="txt_phob_button_unlink">
      <source>Unlink</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除链接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_unnamed">
      <source>Unnamed</source>
      <translation variants="no">zh #(unnamed)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_field">
      <source>Add field</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_email2">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">经电子邮件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete_selected">
      <source>Delete selected</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_id">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization_val_private">
      <source>private</source>
      <translation variants="no">非公开</translation>
    </message>
    <message numerus="no" id="txt_phob_list_mycard">
      <source>MyCard</source>
      <translation variants="no">我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_missing_find_1">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_pager">
      <source>Pager</source>
      <translation variants="no">寻呼机</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_set_as_favorite">
      <source>Set as favorite</source>
      <translation variants="no">增加至常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_1_details">
      <source>Edit %1 details</source>
      <translation variants="no">编辑名片详情：%[09]1</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_my_card">
      <source>My card</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的名片卡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_video_call_home">
      <source>Not specified</source>
      <translation variants="no">视频通话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_call_voice_mail_box">
      <source>Not specified</source>
      <translation variants="no">拨打语音信箱号码</translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">名片夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_a_new_contact">
      <source>Create a new contact</source>
      <translation variants="no">新建名片</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_work2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_missing_list_update_existing_contact">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_importing_contacts">
      <source>Importing contacts</source>
      <translation variants="no">正在导入名片</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_1_group_created_l2_contac">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_city">
      <source>City</source>
      <translation variants="no">城市</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_city2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_address_details">
      <source>Edit address details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑地址详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="no">手机(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_1">
      <source>Delete %1</source>
      <translation variants="no">删除%[09]1</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_groups">
      <source>Groups</source>
      <translation variants="yes">
        <lengthvariant priority="1">通话组</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_department">
      <source>Department</source>
      <translation variants="no">部门</translation>
    </message>
    <message numerus="no" id="txt_phob_list_no_favorites_selected">
      <source>No favorites selected</source>
      <translation variants="no">无常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_internet_call_home">
      <source>Call internet call (home)</source>
      <translation variants="no">拨打互联网电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_children">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_private">
      <source>Private</source>
      <translation variants="no">zh #Private</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">互联网电话</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_spouse">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="yes" id="txt_phob_dpophead_ln_contacts_linked">
      <source>%Ln contacts linked</source>
      <translation>
        <numerusform plurality="a">%Ln个名片已链接</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="no">zh #Create new contact</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_to_contacts">
      <source>Add to contacts</source>
      <translation variants="no">添加至名片夹</translation>
    </message>
    <message numerus="no" id="txt_phob_button_manage_members">
      <source>Manage members</source>
      <translation variants="no">管理通话组</translation>
    </message>
    <message numerus="no" id="txt_phob_title_birthday">
      <source>Birthday</source>
      <translation variants="yes">
        <lengthvariant priority="1">生日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_phone_number_for_1">
      <source>No phone number for %1</source>
      <translation variants="no">zh #No phone number defined for %1</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_transfer_via_b">
      <source>Transfer via bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">经蓝牙发送</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization">
      <source>Syncronization</source>
      <translation variants="no">同步</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ptt">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_post_code2">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">配偶</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_view">
      <source>Not specified</source>
      <translation variants="no">查看图像</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone">
      <source>Call Phone</source>
      <translation variants="no">拨打电话</translation>
    </message>
    <message numerus="no" id="txt_phob_list_address2">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_work">
      <source>Delete Email (work)</source>
      <translation variants="no">删除电子邮件地址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_work">
      <source>Delete URL (work)</source>
      <translation variants="no">删除网址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_service">
      <source>Select service</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择服务</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_remove_link">
      <source>Remove link? </source>
      <translation variants="yes">
        <lengthvariant priority="1">删除链接？</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_val_not_logged_in">
      <source>Not logged in</source>
      <translation variants="yes">
        <lengthvariant priority="1">未登录</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">删除名片</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_syncronization_val_none">
      <source>Not specified</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard">
      <source>MyCard</source>
      <translation variants="no">zh #My card</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="no">拨打手机(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_your_name">
      <source>Enter your name</source>
      <translation variants="no">zh #Your name</translation>
    </message>
  </context>
</TS>