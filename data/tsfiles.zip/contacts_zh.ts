<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phob_subtitle_edit_phone_number">
      <source>Edit phone number</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑电话号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_mycard">
      <source>MyCard</source>
      <translation variants="no">我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_number">
      <source>Conference number</source>
      <translation variants="no">会议通话号码</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_address">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_pager">
      <source>Call Pager</source>
      <translation variants="no">拨打寻呼机</translation>
    </message>
    <message numerus="no" id="txt_phob_list_missed_call">
      <source>Missed call</source>
      <translation variants="no">未接电话</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_to_homescreen_as_widget">
      <source>Send to homescreen</source>
      <translation variants="no">增加至主屏幕</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_work">
      <source>Phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话号码(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">删除名片</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">放弃所做更改</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_assistant">
      <source>Assistant</source>
      <translation variants="no">助理姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_groups">
      <source>Delete groups</source>
      <translation variants="no">删除通话组</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name_separator">
      <source>Last name, First name</source>
      <translation variants="no">名，姓</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile">
      <source>Call Mobile</source>
      <translation variants="no">拨打手机</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number">
      <source>Video call</source>
      <translation variants="no">拨打视频电话</translation>
    </message>
    <message numerus="no" id="txt_phob_button_choose_from_my_contacts">
      <source>Choose from my contacts</source>
      <translation variants="no">从名片中选择</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_work">
      <source>Email (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址(办公)</lengthvariant>
        <lengthvariant priority="2">zh #Mail address (bus.)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打车载电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_assistant">
      <source>Assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">助理电话号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_home">
      <source>Call Fax (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送传真(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_pager">
      <source>Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">寻呼机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_pager">
      <source>Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">寻呼机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_work">
      <source>Call Fax (work)</source>
      <translation variants="no">发送传真(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_set_as_favorite">
      <source>Set as favorite</source>
      <translation variants="no">增加至常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_group_1_created">
      <source>New group %1 created</source>
      <translation variants="no">新分组%[12]1已创建</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_assistant">
      <source>Assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">助理电话号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile">
      <source>Call mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打手机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contact_1_saved">
      <source>Contact %1 created</source>
      <translation variants="no">名片%[13]1已创建</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">职位</translation>
    </message>
    <message numerus="no" id="txt_phob_list_note">
      <source>Note</source>
      <translation variants="yes">
        <lengthvariant priority="1">备忘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile">
      <source>Mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_take_a_new_photo">
      <source>Take a new photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">拍摄新图像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites_val_no_favorites_selecte">
      <source>No favorites selected</source>
      <translation variants="no">无常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_my_card">
      <source>My card</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的名片卡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_clear_communications_history_with_1">
      <source>Delete communications history with %1?</source>
      <translation variants="no">删除与%[39]1通讯的历史记录？</translation>
    </message>
    <message numerus="no" id="txt_phob_list_yesterday_1">
      <source>yesterday %1</source>
      <translation variants="no">昨天%1</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_email_address">
      <source>Email address</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email">
      <source>Send email</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送电子邮件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites">
      <source>Favorites</source>
      <translation variants="no">常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit_group_details">
      <source>Edit group details</source>
      <translation variants="no">编辑通话组详情</translation>
    </message>
    <message numerus="no" id="txt_short_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">名片夹</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">姓</translation>
    </message>
    <message numerus="no" id="txt_phob_list_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">创建我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_title_new_group_name">
      <source>New group name:</source>
      <translation variants="no">通话组名称：</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_car">
      <source>Car</source>
      <translation variants="yes">
        <lengthvariant priority="1">车载电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_to_contacts">
      <source>Add to contacts</source>
      <translation variants="no">增加至名片夹</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_url_address">
      <source>Url address</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">聊天(%[19]1)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">名片夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_province">
      <source>Province</source>
      <translation variants="no">省/市/区</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">中间名</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="no">拨打手机(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_birthday">
      <source>Birthday</source>
      <translation variants="no">生日</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_import_contacts">
      <source>Import contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">导入名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_personal_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">铃声</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_company_details">
      <source>Company details</source>
      <translation variants="yes">
        <lengthvariant priority="1">公司详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile">
      <source>Mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_my_card">
      <source>Save My card</source>
      <translation variants="no">储存我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">从收藏夹删除</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_work">
      <source>Phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">铃声</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">配偶</translation>
    </message>
    <message numerus="yes" id="txt_phob_dblist_val_ln_numbers">
      <source>%Ln number</source>
      <translation>
        <numerusform plurality="a">%Ln个号码</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_home">
      <source>URL (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_to_homescreen">
      <source>Send to homescreen</source>
      <translation variants="no">增加至主屏幕</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_number">
      <source>Set as default number</source>
      <translation variants="no">设为预设号码</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_date">
      <source>Edit date</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message">
      <source>Send message</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送信息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_home">
      <source>Email (home)</source>
      <translation variants="no">发送电子邮件(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_street">
      <source>Street</source>
      <translation variants="no">街道</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="no">拨打车载电话</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_group_details">
      <source>Edit group details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑通话组详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_updated_1">
      <source>Updated %1</source>
      <translation variants="no">已更新：%1</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create">
      <source>Create</source>
      <translation variants="yes">
        <lengthvariant priority="1">创建</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard">
      <source>MyCard</source>
      <translation variants="no">我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_group_name">
      <source>Group name</source>
      <translation variants="no">通话组名称</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address">
      <source>Address</source>
      <translation variants="no">地址</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_work">
      <source>Address (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show">
      <source>Show</source>
      <translation variants="no">显示</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_home">
      <source>Phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_city">
      <source>City</source>
      <translation variants="no">城市</translation>
    </message>
    <message numerus="no" id="txt_phob_info_delete_1">
      <source>Delete %1?</source>
      <translation variants="no">删除%[99]1？</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打手机(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_field">
      <source>Add detail</source>
      <translation variants="no">添加详情</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_name">
      <source>Enter name</source>
      <translation variants="no">姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company">
      <source>Company</source>
      <translation variants="no">公司</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_assistant">
      <source>Call assistant</source>
      <translation variants="no">呼叫助理</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_address_details">
      <source>Edit address details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑地址详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company_details">
      <source>Company Details</source>
      <translation variants="no">公司详情</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_phone_number">
      <source>Phone number</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_home">
      <source>URL (home)</source>
      <translation variants="no">转至网址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_work">
      <source>URL (work)</source>
      <translation variants="no">转至网址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_image">
      <source>Remove image</source>
      <translation variants="no">删除图像</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name">
      <source>Last name First name</source>
      <translation variants="no">姓前名后</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax">
      <source>Call Fax</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送传真</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_name">
      <source>Edit name</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑联系人姓名</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_unknown">
      <source>Unknown</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_phob_info_create_own_card_to_share_it_with_fri">
      <source>Create own card to share it with friends</source>
      <translation variants="no">用您的个人详情创建名片卡并与朋友共享</translation>
    </message>
    <message numerus="no" id="txt_phob_list_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_children">
      <source>Children</source>
      <translation variants="no">子女</translation>
    </message>
    <message numerus="no" id="txt_long_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">名片夹</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_conference_call">
      <source>Conference call</source>
      <translation variants="yes">
        <lengthvariant priority="1">会议通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_pager">
      <source>Call Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打寻呼机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_work">
      <source>Call Fax (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送传真(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">导入名片</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sufix">
      <source>Suffix</source>
      <translation variants="no">头衔</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_history">
      <source>Delete history</source>
      <translation variants="no">清除历史记录</translation>
    </message>
    <message numerus="no" id="txt_phob_list_address">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">名</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order">
      <source>Name display order</source>
      <translation variants="no">显示姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url">
      <source>URL</source>
      <translation variants="no">转至网址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_email">
      <source>Set as default email</source>
      <translation variants="no">设为预设电子邮件</translation>
    </message>
    <message numerus="no" id="txt_phob_list_chooce_from_gallery">
      <source>Choose from gallery</source>
      <translation variants="yes">
        <lengthvariant priority="1">从照片中选择</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_groups">
      <source>Groups</source>
      <translation variants="yes">
        <lengthvariant priority="1">通话组</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_group">
      <source>Delete group</source>
      <translation variants="no">删除通话组</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_ln_contacts_imported">
      <source>%L1 / %L2 contacts imported</source>
      <translation variants="no">%L1/%L2名片已导入</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_department">
      <source>Department</source>
      <translation variants="no">部门</translation>
    </message>
    <message numerus="no" id="txt_phob_title_members_of_1_group">
      <source>%1 members</source>
      <translation variants="no">%[22]1成员</translation>
    </message>
    <message numerus="no" id="txt_phob_list_dialled_call">
      <source>Dialled call</source>
      <translation variants="no">已拨电话</translation>
    </message>
    <message numerus="no" id="txt_phob_list_favorites">
      <source>Favorites</source>
      <translation variants="no">常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="no">拨打手机(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_change_picture">
      <source>Change picture</source>
      <translation variants="no">更改图像</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_work">
      <source>Video call (work)</source>
      <translation variants="no">拨打视频电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_home">
      <source>Call Fax (home)</source>
      <translation variants="no">发送传真(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">纪念日</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">聊天(%[08]1)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone">
      <source>Call Phone</source>
      <translation variants="no">拨打电话</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_nick_name">
      <source>Nick name</source>
      <translation variants="no">昵称</translation>
    </message>
    <message numerus="no" id="txt_phob_list_no_favorites_selected">
      <source>No favorites selected</source>
      <translation variants="no">无常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_work">
      <source>Email (work)</source>
      <translation variants="no">发送电子邮件(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_contact">
      <source>New contact</source>
      <translation variants="no">新名片</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_first_nam">
      <source>First name Last name</source>
      <translation variants="no">名前姓后</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_car">
      <source>Car</source>
      <translation variants="yes">
        <lengthvariant priority="1">车载电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打手机(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_home">
      <source>Address (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_all_contacts">
      <source>Find: All contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜索：所有名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_home">
      <source>Video call (home)</source>
      <translation variants="no">拨打视频电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard_val_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">创建我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_select_location">
      <source>Select location</source>
      <translation variants="no">选择位置</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_assistant">
      <source>Call assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">呼叫助理</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_home">
      <source>Phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话号码(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax">
      <source>Call Fax</source>
      <translation variants="no">发送传真</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_your_name">
      <source>Enter your name</source>
      <translation variants="no">您的姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_presentation_settings">
      <source>Presentation settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">名片设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_family_details">
      <source>Edit family details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑家庭详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_family">
      <source>Family details</source>
      <translation variants="yes">
        <lengthvariant priority="1">家庭详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_message">
      <source>Send message</source>
      <translation variants="no">发送信息</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_new">
      <source>Create new</source>
      <translation variants="no">新建</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone">
      <source>Call phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_home">
      <source>Send mail (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送电子邮件(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email">
      <source>Email</source>
      <translation variants="no">发送电子邮件</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_group">
      <source>Remove from group</source>
      <translation variants="no">从名片分组删除</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_work">
      <source>URL (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_as_a_business_card">
      <source>Send as a business card</source>
      <translation variants="no">作为名片发送</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_work">
      <source>Send mail (Work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送电子邮件(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">称谓</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_note">
      <source>Note</source>
      <translation variants="no">备忘</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_work">
      <source>Call phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打电话(办公)</lengthvariant>
        <lengthvariant priority="2">zh #Call telephone (bus.)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_home">
      <source>Address (home)</source>
      <translation variants="no">地址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_company_details">
      <source>Edit company details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑公司详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_home">
      <source>Call phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">拨打电话(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone_val_default">
      <source>Default</source>
      <translation variants="no">预设铃声</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_only">
      <source>Name only</source>
      <translation variants="no">仅姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_work">
      <source>Address (work)</source>
      <translation variants="no">地址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_and_phonenumber">
      <source>Name and phonenumber</source>
      <translation variants="no">姓名和手机号码</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_number">
      <source>Add number</source>
      <translation variants="no">添加号码</translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_mycard_image_to_business_card">
      <source>Add MyCard image to Business card?</source>
      <translation variants="no">同时包括我的名片卡图像？</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">删除名片</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_contact">
      <source>Save contact</source>
      <translation variants="no">储存名片</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_email_address">
      <source>Edit email address</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑电子邮件地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_favorites_selected_select_your_p">
      <source>No favorites selected, select your preferrred contacts</source>
      <translation variants="no">无联系人被标记</translation>
    </message>
    <message numerus="no" id="txt_phob_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="no">新建名片</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_favorites">
      <source>Add favorites</source>
      <translation variants="no">添加常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">从收藏夹删除</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_web_address">
      <source>Edit web address</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑网址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="no">更新现有名片</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_favorites">
      <source>Manage favorites</source>
      <translation variants="no">管理常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_work">
      <source>Internet number (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">互联网电话(办公)</lengthvariant>
        <lengthvariant priority="2">zh #Internet telephone (bus.)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone">
      <source>Internet number</source>
      <translation variants="yes">
        <lengthvariant priority="1">互联网电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_home">
      <source>Internet number (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">互联网电话(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_home">
      <source>URL (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_pobox">
      <source>P.O.Box</source>
      <translation variants="no">邮政信箱</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_home">
      <source>Email (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_countryregion">
      <source>Country/Region</source>
      <translation variants="no">国家/地区</translation>
    </message>
    <message numerus="no" id="txt_phob_title_select_contact">
      <source>Select contact</source>
      <translation variants="no">选择名片</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_stateprovince">
      <source>State/Province</source>
      <translation variants="no">省/市/区</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_work">
      <source>Email (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_work">
      <source>URL (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_postal_codezip_code">
      <source>Postal code/ZIP code</source>
      <translation variants="no">邮政编码</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_delete_1_group">
      <source>Delete %1 group?</source>
      <translation variants="no">删除分组%[19]1？</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_image">
      <source>Remove image</source>
      <translation variants="no">删除图像</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_group">
      <source>New group</source>
      <translation variants="no">新建分组</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_history_with_1">
      <source>History with %1</source>
      <translation variants="no">与%1的会话</translation>
    </message>
    <message numerus="no" id="txt_phob_list_received">
      <source>Received call</source>
      <translation variants="no">已接电话</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_home">
      <source>Call Phone (home)</source>
      <translation variants="no">拨打电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_only_group_will_be_removed_contac">
      <source>Only group will be removed. Contacts can be found from all contacts list.</source>
      <translation variants="no">将只删除分组。仍能从所有名片列表找到名片。</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_work">
      <source>Fax (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">传真(办公)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_change_image">
      <source>Change image</source>
      <translation variants="yes">
        <lengthvariant priority="1">更改图像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message_val_members">
      <source>Members</source>
      <translation variants="yes">
        <lengthvariant priority="1">成员</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_work">
      <source>Call Phone (work)</source>
      <translation variants="no">拨打电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_home">
      <source>Fax (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">传真(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">名片夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_home">
      <source>Email (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址(家庭)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">地址详情</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_matching_contacts">
      <source>(no matching contacts)</source>
      <translation variants="no">(无匹配)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_unnamed">
      <source>Unnamed</source>
      <translation variants="no">(未命名)</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_image_not_added">
      <source>Image not included.</source>
      <translation variants="no">不包括图像</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_my_card">
      <source>Clear My card</source>
      <translation variants="no">清除我的名片卡</translation>
    </message>
    <message numerus="no" id="txt_phob_title_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">导入名片</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax">
      <source>Fax</source>
      <translation variants="yes">
        <lengthvariant priority="1">传真</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">(未命名)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">网址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">添加详情</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_note">
      <source>Edit note</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑备忘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_email">
      <source>Add email</source>
      <translation variants="no">添加电子邮件地址</translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_contact_card_image_to_business_c">
      <source>Add contact card image to Business card?</source>
      <translation variants="no">同时包括名片卡图像？</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_no_sim_contacts">
      <source>No SIM contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">无SIM卡名片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_number">
      <source>Number</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_address2">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_home">
      <source>Delete Mobile (home)</source>
      <translation variants="no">删除手机(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_pager">
      <source>Delete Pager</source>
      <translation variants="no">删除寻呼机</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_car">
      <source>Delete Car</source>
      <translation variants="no">删除车载电话</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_sim">
      <source>Import from SIM</source>
      <translation variants="yes">
        <lengthvariant priority="1">从SIM卡导入</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email">
      <source>Delete Email</source>
      <translation variants="no">删除电子邮件地址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_anniversary">
      <source>Delete Anniversary</source>
      <translation variants="no">删除纪念日</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_spouse">
      <source>Delete Spouse details</source>
      <translation variants="no">删除配偶姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_home">
      <source>Delete Email (home)</source>
      <translation variants="no">删除电子邮件地址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_work">
      <source>Delete Email (work)</source>
      <translation variants="no">删除电子邮件地址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax">
      <source>Delete Fax</source>
      <translation variants="no">删除传真</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_number">
      <source>Add Number</source>
      <translation variants="no">添加电话号码</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_my_details">
      <source>Edit My details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑我的名片卡详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_family_details">
      <source>Add Family details</source>
      <translation variants="no">添加家庭详情</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_date">
      <source>Add Date</source>
      <translation variants="no">添加日期</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_company_details">
      <source>Delete Company Details</source>
      <translation variants="no">删除公司详情</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_email">
      <source>Add Email</source>
      <translation variants="no">添加电子邮件地址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_url">
      <source>Add URL</source>
      <translation variants="no">添加网址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url">
      <source>Delete URL</source>
      <translation variants="no">删除网址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_address">
      <source>Add Address</source>
      <translation variants="no">添加地址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_work">
      <source>Delete Mobile (work)</source>
      <translation variants="no">删除手机(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_work">
      <source>Delete Phone (work)</source>
      <translation variants="no">删除电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_work">
      <source>Delete Internet telephone (work)</source>
      <translation variants="no">删除互联网电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_sim">
      <source>Importing contacts from SIM</source>
      <translation variants="no">正在从SIM卡导入名片</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_home">
      <source>Delete Internet telephone (home)</source>
      <translation variants="no">删除互联网电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_note">
      <source>Delete Note</source>
      <translation variants="no">删除备忘</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_remove_all_personal_data_from_my_c">
      <source>Remove all personal data from My card?</source>
      <translation variants="no">从我的名片卡清除所有个人数据？</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_ringing_tone">
      <source>Delete Ringing tone</source>
      <translation variants="no">删除铃声</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_work">
      <source>Delete Address (work)</source>
      <translation variants="no">删除地址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_home">
      <source>Delete Fax (home)</source>
      <translation variants="no">删除传真(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts">
      <source>All contacts</source>
      <translation variants="no">全部名片</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_children">
      <source>Delete Children details</source>
      <translation variants="no">删除子女姓名</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_birthday">
      <source>Delete Birthday</source>
      <translation variants="no">删除生日</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_sip">
      <source>Delete SIP</source>
      <translation variants="no">删除SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_details">
      <source>Edit contact details</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑名片详情</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_company_details">
      <source>Add Company details</source>
      <translation variants="no">添加公司详情</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_home">
      <source>Delete Address (home)</source>
      <translation variants="no">删除地址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_work">
      <source>Delete Fax (work)</source>
      <translation variants="no">删除传真(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile">
      <source>Delete Mobile</source>
      <translation variants="no">删除手机</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_home">
      <source>Delete URL (home)</source>
      <translation variants="no">删除网址(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone">
      <source>Delete Phone</source>
      <translation variants="no">删除电话</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_home">
      <source>Delete Phone (home)</source>
      <translation variants="no">删除电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address">
      <source>Delete Address</source>
      <translation variants="no">删除地址</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_assistant">
      <source>Delete Assistant number</source>
      <translation variants="no">删除助理号码</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_work">
      <source>Delete URL (work)</source>
      <translation variants="no">删除网址(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone">
      <source>Delete Internet telephone</source>
      <translation variants="no">删除互联网电话</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_no_sim_card">
      <source>No SIM card</source>
      <translation variants="yes">
        <lengthvariant priority="1">无SIM卡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">互联网电话</translation>
    </message>
    <message numerus="no" id="txt_phob_list_business_card">
      <source>Business card</source>
      <translation variants="no">名片</translation>
    </message>
    <message numerus="no" id="txt_phob_title_favorite_contacts">
      <source>Favorite contacts</source>
      <translation variants="no">常用联系人</translation>
    </message>
    <message numerus="no" id="txt_phob_list_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">经蓝牙</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">互联网电话(办公)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete_selected">
      <source>Delete selected</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">互联网电话(家庭)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_method">
      <source>Select method</source>
      <translation variants="no">发送</translation>
    </message>
    <message numerus="no" id="txt_phob_list_message">
      <source>Message</source>
      <translation variants="yes">
        <lengthvariant priority="1">经信息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_conference_call">
      <source>Conference call</source>
      <translation variants="no">会议通话</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_message">
      <source>Send message</source>
      <translation variants="no">发送信息</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_mail">
      <source>Send mail</source>
      <translation variants="no">发送电子邮件</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_url">
      <source>Add Url</source>
      <translation variants="no">添加网址</translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_groups">
      <source>Delete groups</source>
      <translation variants="no">删除分组</translation>
    </message>
    <message numerus="no" id="txt_phob_title_birthday">
      <source>Birthday</source>
      <translation variants="no">生日</translation>
    </message>
    <message numerus="no" id="txt_phob_title_anniversary">
      <source>Anniversary</source>
      <translation variants="no">纪念日</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contacts_1_updated">
      <source>Contact %1 updated</source>
      <translation variants="no">名片%[13]1已更新</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_formlabel_val_no_date_set">
      <source>No date set</source>
      <translation variants="no">(未设置日期)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_email2">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">经电子邮件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_contacts">
      <source>Delete contacts</source>
      <translation variants="no">删除名片</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_phone_number_for_1">
      <source>No phone number for %1</source>
      <translation variants="no">没有为%1定义手机号码</translation>
    </message>
    <message numerus="no" id="txt_phob_info_unable_to_access_contacts_in_memory">
      <source>Unable to access contacts in memory: %1</source>
      <translation variants="no">无法访问存至%1的名片</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sim_card_error">
      <source>SIM card error </source>
      <translation variants="no">SIM卡错误</translation>
    </message>
    <message numerus="no" id="txt_phob_list_no_members_selected">
      <source>No members selected</source>
      <translation variants="no">未选择成员</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_val_no_members_selected">
      <source>No members selected</source>
      <translation variants="no">未选择成员</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_note">
      <source>Add note</source>
      <translation variants="no">添加备忘</translation>
    </message>
    <message numerus="no" id="txt_phob_info_keep_existing_map_location">
      <source>Address updated. Keep existing location on Map? </source>
      <translation variants="no">地址已更新。保留现有地图位置？</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_note">
      <source>Add Note</source>
      <translation variants="no">添加备忘</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_contact_save_error">
      <source>Contact save error</source>
      <translation variants="no">无法储存名片</translation>
    </message>
    <message numerus="no" id="txt_phob_info_your_phonebook_is_empty_do_you_wish">
      <source>Your phonebook is empty. Do you wish to import contacts?</source>
      <translation variants="no">zh #Your phonebook is empty. Would you like to import your contacts?</translation>
    </message>
    <message numerus="no" id="txt_phob_button_import">
      <source>Import</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Import</lengthvariant>
      </translation>
    </message>
  </context>
</TS>