<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_device_update_dblist_product_code">
      <source>Product code</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Product code</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__800BA">
      <source>800MHz on Band A</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #800MHz on Band A</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val_unknown">
      <source>Band Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Unknown band</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_duplicate_server_id">
      <source>Duplicate server Id.
</source>
      <translation variants="no">zh #Server ID already exists</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_update_incomplete_dwnld_kb">
      <source>The last update %1 (%2),%L3 kb was not completed. You can download it now </source>
      <translation variants="no">zh #Download now avaliable for the previous incomplete update %[25]1 (%[25]2),%L3 kB.</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_multimedia_access_pts">
      <source>Multimedia access pts</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Multimedia access points</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_network_band_supported">
      <source>Network Band supported</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Supported network band</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_service_supported">
      <source>Data service supported</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Supported data service</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_server_password">
      <source>Server Password </source>
      <translation variants="no">zh #Server password</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_server_profile_not_created">
      <source>Mandatory fields missing</source>
      <translation variants="no">zh #Mandatory fields incomplete</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_uninstalling_application">
      <source>Uninstalling application</source>
      <translation variants="no">zh #Uninstalling application</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_no_access_points_found_in_t">
      <source>No access points found in the message. Settings cannot be saved." </source>
      <translation variants="no">zh #No access points found in configuration message. Settings cannot be saved.</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_destination_networks">
      <source>Destination networks</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Destination networks</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wcdma_bands">
      <source>WCDMA bands </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #WCDMA bands</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_device_update_dialog_enter_the_config_trial">
      <source>Incorrect Pin. &lt;%Ln&gt; tries left.</source>
      <translation>
        <numerusform plurality="a">zh #Enter configuration PIN . %Ln tries left.</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_invalid_host_address">
      <source>Invalid host address </source>
      <translation variants="no">zh #Invalid host address</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_model">
      <source>Model</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Model</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_device_update_services">
      <source>Device update services</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Device update services</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_update_cmd">
      <source>Update</source>
      <translation variants="no">zh ##Update</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_advanced_device_updates">
      <source>Advanced: Device updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Device update - advanced settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_service_recomended">
      <source>Service recomended</source>
      <translation variants="no">zh #Service recommended</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BE">
      <source>1900MHz on Band E</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #1900MHz on Band E</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_installing">
      <source>Installing</source>
      <translation variants="no">zh #Installing</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_downloading_failed">
      <source>Downloading failed</source>
      <translation variants="no">zh #Download failed</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_1_recommends_a_service_for">
      <source>%1 recommends a service for your phone. It requires connection to the internet.</source>
      <translation variants="no">zh #A service for your device has been recommended by %[17]1. Internet connection required.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_device_memory_is_busy_try">
      <source>Device memory is busy.You will be notified once the installation can resume.</source>
      <translation variants="no">zh #Device memory is busy. Try installation later.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_no_server_configured_to_get">
      <source>No server configured to get the updates. Please call customer care</source>
      <translation variants="no">zh ##No server configured to get the updates. Please call customer care</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_during_the_installation_the">
      <source>During the installation the phone can not be used even for emergency.</source>
      <translation variants="no">zh ##During the installation the phone can not be used even for emergency.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_your_phone_is_now_updated_w">
      <source>Your phone is now updated with the latest device software</source>
      <translation variants="no">zh #Update successful. Your device now has the latest software.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_wlan">
      <source>WLAN</source>
      <translation variants="no">zh #WLAN</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_change_the_id_to_save_the_p">
      <source>Change the ID to save the profile.</source>
      <translation variants="no">zh #Use a different ID to save the profile</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_enter_first_4_characters_of">
      <source>Enter first 4 characters of the %1 PIN code </source>
      <translation variants="no">zh #Enter first 4 characters of PIN for %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_update_incomp_instal_kb">
      <source>The last update %1 (%2),%L3 kb was not completed. You can install it now </source>
      <translation variants="no">zh #Download now ready for installation for the previous incomplete update %[20]1 (%[19]2),%L3 kB.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_camera">
      <source>Camera</source>
      <translation variants="no">zh #Camera</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_001">
      <source>%1</source>
      <translation variants="no">zh #%1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading_of_1_Mb_failed">
      <source>Downloading of %1 %L2 Mb failed</source>
      <translation variants="no">zh #Download failed of %[58]1 (%L2 MB)</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BA">
      <source>1900MHz on Band A</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #1900MHz on Band A</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_menu_delete">
      <source>Delete</source>
      <translation variants="no">zh #Delete</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wlan_mac_address">
      <source>WLAN MAC address </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #WLAN MAC address</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_software_version">
      <source>Software version</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Software version</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading_of_1_Kb_failed">
      <source>Downloading of %1 %L2 Kb failed</source>
      <translation variants="no">zh #Download failed of %[59]1 (%L2 kB)</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_HSUPA">
      <source>HSUPA</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #HSUPA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_new_device_software_availab_Mb">
      <source>New device software available %1 %2 %L3 Mb</source>
      <translation variants="no">zh ##New device software available %1 %2 % L3 Mb</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_error_in_communication_with">
      <source>Error in communication with the server, try again later" </source>
      <translation variants="no">zh #Error in communication with server. Try again later.</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_installation_complete">
      <source>Installation complete</source>
      <translation variants="no">zh #Installation complete</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_installation_failed">
      <source>Installation failed</source>
      <translation variants="no">zh #Installation failed</translation>
    </message>
    <message numerus="no" id="txt_device_update_dpophead_trust_established">
      <source>Trust Established with server %1</source>
      <translation variants="no">zh #Trust established</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_language_set">
      <source>Language set</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Language set</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_gprs">
      <source>GPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #GPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_connecti">
      <source>connecting</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Connecting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_WCDMA">
      <source>WCDMA</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #WCDMA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_user_name">
      <source>User name*</source>
      <translation variants="no">zh #Username*</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_advanced">
      <source>Advanced</source>
      <translation variants="no">zh ##Advanced</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_sw_version_date">
      <source>SW version date</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #SW version date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_custom_version_date">
      <source>Custom version date</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Custom version date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_new_server_profile">
      <source>New server profile</source>
      <translation variants="no">zh ##New server profile</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BF">
      <source>1900MHz on Band F</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #1900MHz on Band F</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_phone_was_not_updated">
      <source>The phone was not updated. The update package was not compatible with the phone. Please contact your service provider.</source>
      <translation variants="no">zh #Update unsuccessful. Update package not compatible with your device. Contact your service provider.</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_install">
      <source>Install?</source>
      <translation variants="no">zh #Install</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_device_updated">
      <source>Device updated</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Device updated</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_menu_connect">
      <source>Connect </source>
      <translation variants="no">zh #Connect</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_during_the_installation_the">
      <source>During the installation the phone can not be used even for emergency.</source>
      <translation variants="no">zh #During the installation your device will not even be able to make emergency calls.</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_update">
      <source>Update</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_set_the_received_settings">
      <source> "Set the received settings as default?</source>
      <translation variants="no">zh #Set received settings as default settings?</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_access_point">
      <source>Access point</source>
      <translation variants="no">zh #Access point</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_resume_later">
      <source>Resume later</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Try again later</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_download_and_install">
      <source>Download and install?</source>
      <translation variants="no">zh #Download and install?</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_to_update_your_device_s">
      <source>To update your device software to the latest available device software</source>
      <translation variants="no">zh ##To update your device software to the latest available device software</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_8pskul">
      <source>8PSK-UL</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #8PSK-UL</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_egprs">
      <source>EGPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #EGPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_type">
      <source>Type</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Type</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_install_to">
      <source>Install to:</source>
      <translation variants="no">zh #Install to:</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_network_auth_val_yes">
      <source>Yes</source>
      <translation variants="no">zh ##Yes</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_warning_device_memory_is_b">
      <source>Warning! Device memory is busy. Try installation later.</source>
      <translation variants="no">zh ##Warning! Device memory is busy. Try installation later.</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_to_update_your_val_inter">
      <source>Internet</source>
      <translation variants="no">zh ##Internet</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_sender_of_the_message_is_unt">
      <source>Sender of the message is untrusted. Continue?"</source>
      <translation variants="no">zh #Sender of message is not trusted. Continue?</translation>
    </message>
    <message numerus="no" id="txt_device_update_menu_set_as_default">
      <source>Set as default</source>
      <translation variants="no">zh #Set as default</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_download_complete">
      <source>Download complete!</source>
      <translation variants="no">zh ##Download complete!</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_session_mode">
      <source>Session mode</source>
      <translation variants="no">zh #Session mode</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_streaming_settings">
      <source>Streaming settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Streaming settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_device_updates">
      <source>Device updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Device update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_security_information">
      <source>Security Information</source>
      <translation variants="no">zh #Security information</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_browser_settings">
      <source>Browser settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Browser settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_de_info_l1_Mb_free_memory_needed_for_update">
      <source>%L1 MB free memory needed for update. Delete some data now or update later </source>
      <translation variants="no">zh #Not enough memory for update. %L1 MB required. Delete some data and try again. </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_after_the_installation_the">
      <source>After the installation the phone will restart.</source>
      <translation variants="no">zh #Your device will restart after the installation has finished.</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_none">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #None</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_recommended_update_is_avail">
      <source>Recommended update is available from %1.  Downloading requires connection to the internet</source>
      <translation variants="no">zh #Recommended update is available from %[47]1. Downloading will require connection to the internet.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_server_not_responding">
      <source>Server not responding </source>
      <translation variants="no">zh #Server not responding</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_network_auth_val_no">
      <source>No</source>
      <translation variants="no">zh ##No</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BD">
      <source>1900MHz on Band D</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #1900MHz on Band D</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_GSM">
      <source>GSM</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #GSM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_network_security_level">
      <source>Network security level</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Network security level</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_external_memory_card">
      <source>External Memory card</source>
      <translation variants="no">zh #External memory card</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_java_version">
      <source>Java version</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Java version</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_new_device_software_availab_Kb">
      <source>New device software available %1 %2 %L3 Kb</source>
      <translation variants="no">zh ##New device software available %1 %2 % L3 Kb</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_file_1_2">
      <source>file: %1 </source>
      <translation variants="no">zh #File: %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_server_id">
      <source>Server ID *</source>
      <translation variants="no">zh #Server ID*</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_firmware_update">
      <source>Firmware Update</source>
      <translation variants="no">zh #Device update</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_enabled_by_the_system_admi">
      <source>Enabled by the system admin</source>
      <translation variants="no">zh #Enabled by system admin</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_to_proceed_with_installatio">
      <source>To proceed with installation connect to the charger now</source>
      <translation variants="no">zh ##To proceed with installation connect to the charger now</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_EGPRS">
      <source>EGPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #EGPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__800BC">
      <source>800MHz on Band C</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #800MHz on Band C</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_you_will_be_notified_once_t">
      <source>Connect the charger.You will be notified once the charging level reaches acceptable level.</source>
      <translation variants="no">zh #Connect the charger. You will be notified when you can remove the charger.</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_server_message">
      <source>Server Message</source>
      <translation variants="no">zh #Server message</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_new_server_profile">
      <source>New server profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #New server profile</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_configuration_message">
      <source>Configuration Settings</source>
      <translation variants="no">zh #Configuration message</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_messaging">
      <source>Messaging</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Messaging</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_other_details">
      <source>Other details</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Other details</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_de_info_l1_kb_free_memory_needed_for_update_">
      <source>%L1 kB free memory needed for update. Delete some data now or update later </source>
      <translation variants="no">zh #Not enough memory for update. %[57]L1 kB required. Delete some data and try again. </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_title_delete">
      <source>Delete?</source>
      <translation variants="no">zh #Delete?</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_network_authentication">
      <source>Network authentication</source>
      <translation variants="no">zh #Network authentication</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_update_available">
      <source>Update available</source>
      <translation variants="no">zh #Update available</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_system_error_try_again_l">
      <source> System Error . Try again later </source>
      <translation variants="no">zh #System Error. Try again later</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_its_recommended_to_connec">
      <source>It is recommended to connect to the charger</source>
      <translation variants="no">zh ##It is recommended to connect to the charger</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__800BB">
      <source>800MHz on Band B</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #800MHz on Band B</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_downloading">
      <source>Downloading</source>
      <translation variants="no">zh #Downloading</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_imei">
      <source>IMEI</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #IMEI</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wcdma_cipherings">
      <source>WCDMA cipherings </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #WCDMA ciphers</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_CDMA">
      <source>CDMA</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #CDMA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_device_update">
      <source>Device Update</source>
      <translation variants="no">zh #Device update</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_installation_of_1_kb_failed">
      <source>Installation of %1 failed.</source>
      <translation variants="no">zh #Failed to install %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_browser_version">
      <source>Browser version </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Browser version</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_set_as_default">
      <source>Set as default</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Set as default</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_custom_version">
      <source>Custom version</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Custom version</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_1_server_wants_to_contro">
      <source>%1 server wants to control data on your device. Accept control?</source>
      <translation variants="no">zh #%[50]1 server wishes to control data on your device. Accept control?</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_bt_mac_address">
      <source>BT MAC address </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #BT MAC address</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_Unknow">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Unknown</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_configuration_message">
      <source>Configuration Message  </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Configuration message </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dpophead_device_update">
      <source>Device Update</source>
      <translation variants="no">zh #Device update</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_installi">
      <source>Installing %1</source>
      <translation variants="no">zh #Installing %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_the_last_update_1_2_mb">
      <source> The last update %1 %2 %L3 Mb was not completed. </source>
      <translation variants="no">zh #Previous update %[21]1 %[21]2 %L3 MB not completed</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BC">
      <source>1900MHz on Band C</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #1900MHz on Band C</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_updating_phone">
      <source>Updating phone</source>
      <translation variants="no">zh #Updating device</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_disabled_by_the_system_adm">
      <source>Disabled by the system admin</source>
      <translation variants="no">zh #Disabled by system admin</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_save_to">
      <source>Save to configure the settings  </source>
      <translation variants="no">zh #Save this message to use the settings</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_phone_uptodate">
      <source>Phone Up-to-date</source>
      <translation variants="no">zh #Device up-to-date</translation>
    </message>
    <message numerus="no" id="txt_device_update_list_from_1_2">
      <source>From: %1</source>
      <translation variants="no">zh #From: %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_update_incomp_instal_Mb">
      <source>The last update %1 (%2),%L3 Mb was not completed. You can install it now </source>
      <translation variants="no">zh #Download now ready for installation for the previous incomplete update %[20]1 (%[19]2),%L3 MB.</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_are_you_sure_you_want_to_del">
      <source>Are you sure you want to delete %1</source>
      <translation variants="no">zh #Are you sure that you want to delete server?
%1</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_network_username">
      <source>network username</source>
      <translation variants="no">zh #Network username</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_authentication_failed_chec">
      <source>Authentication failed, check server ID and password </source>
      <translation variants="no">zh #Authentication failed. Check server ID and password.</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_download">
      <source>Downloading %1</source>
      <translation variants="no">zh #Downloading %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_security_info_access_denied">
      <source>Security Information did not match. Access denied </source>
      <translation variants="no">zh #Access denied. Security information did not match. </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_the_last_update_1_2_kb">
      <source> The last update %1 %2 %L3 kb was not completed. </source>
      <translation variants="no">zh #Previous update %[21]1 %[21]2 %L3 kB not completed</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_invalid_user_name_or_passwo">
      <source>Invalid user name or password  </source>
      <translation variants="no">zh #Invalid username or password </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_release">
      <source>Product Release</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Product release</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_details_not_available">
      <source>Details not available</source>
      <translation variants="no">zh #Details not available</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">zh #%[15]1 %2</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_unable_to_open_message_f">
      <source> "Unable to open. Message format not supported" </source>
      <translation variants="no">zh #Unable to open. Message format not supported. Contact your service provider.</translation>
    </message>
    <message numerus="no" id="txt_device_update_list_from_l2">
      <source>From: %2</source>
      <translation variants="no">zh #From: %2</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_device_updates">
      <source>Device updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Device update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_HSDPA">
      <source>HSDPA</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #HSDPA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading">
      <source>Downloading</source>
      <translation variants="no">zh ##Downloading</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_unable_to_add_access_point">
      <source>Unable to add access point to protected access point settings</source>
      <translation variants="no">zh #Unable to add access point to protected access point settings</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wap_access_point">
      <source>WAP access point</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #WAP access point</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BB">
      <source>1900MHz on Band B</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #1900MHz on Band B</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dpopinfo_your_phone_is_already_u">
      <source>Your phone is already updated with the latest Nokia OS</source>
      <translation variants="no">zh #Your device already has the latest Nokia operating system software</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_network_password">
      <source>network password</source>
      <translation variants="no">zh #Network password</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_after_the_installation_the">
      <source>After the installation the phone will restart.</source>
      <translation variants="no">zh ##After the installation the phone will restart.</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_host_address">
      <source>Host address*</source>
      <translation variants="no">zh #Host address*</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_flash_version">
      <source>Flash version </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Flash version</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_settings_could_not_be_saved">
      <source>Settings could not be saved properly. Configuration might not be usable. Contact service provider</source>
      <translation variants="no">zh #Settings could not be saved properly and configuration may not be usable. Contact service provider for missing settings.</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_new_device_software_availabl">
      <source>New device software available</source>
      <translation variants="no">zh ##New device software available</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_updte_incomp_dwnld_Mb">
      <source>The last update %1 (%2),%L3 Mb was not completed. You can download it now </source>
      <translation variants="no">zh #Download now avaliable for the previous incomplete update %[25]1 (%[25]2),%L3 MB.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_desktop_sync">
      <source>Desktop Sync</source>
      <translation variants="no">zh #Synchronisation</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_dtm_mscs">
      <source>DTM MSCs</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #DTM MSCs</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_server_name">
      <source>Server name *</source>
      <translation variants="no">zh #Server name*</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_it_is_recommended_to_connec">
      <source>It is recommended to connect to the charger.</source>
      <translation variants="no">zh #Charging your device during the installation is recommended.</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_download">
      <source>Download?</source>
      <translation variants="no">zh #Download</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_resume_update">
      <source>Resume update</source>
      <translation variants="no">zh ##Resume update</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_access_points">
      <source>Access Points</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Access points</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_language_variant_version">
      <source>Language variant version</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Language variant version</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_connecting">
      <source>connecting</source>
      <translation variants="no">zh #Connecting</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_rebooting">
      <source>Rebooting</source>
      <translation variants="no">zh #Rebooting</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_popup_device_update">
      <source>Device Update</source>
      <translation variants="no">zh #Device update</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_uninstalla_comple">
      <source>Uninstalled/Removed %1 </source>
      <translation variants="no">zh #Uninstalled/removed %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_uninstalling_of_1_Mb_failed">
      <source>Uninstalling of %1 failed</source>
      <translation variants="no">zh #Failed to uninstall %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading_of_1_Gb_failed">
      <source>Downloading of %1 %L2 Gb failed</source>
      <translation variants="no">zh #Download failed of %[58]1 (%L2 GB)</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_Uninstallation_failed">
      <source>Unistallation/Removing failed</source>
      <translation variants="no">zh #Failed to uninstall or remove software</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_installa_comple">
      <source>Installation %1 Complete</source>
      <translation variants="no">zh #Installation %[]1 complete</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_application_1">
      <source>Application: %1</source>
      <translation variants="no">zh #Application: %1</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_uninstall_app1_2">
      <source>Application:%1 (%2)</source>
      <translation variants="no">zh #Application: %[32]1 (%[31]2)</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_size_1_Gb">
      <source>Size: %L1 Gb</source>
      <translation variants="no">zh #Size: %L1 GB</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_updating_device_from_server">
      <source>Updating device from server %1  </source>
      <translation variants="no">zh #Updating device from server:
%1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_an_error_occurred_update_stop">
      <source>Phone can not be updated due to unknown error.</source>
      <translation variants="no">zh #Unknown error. Device cannot be updated.</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_config_set_val_saving">
      <source>Saving</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Saving</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_device_updates_val_not_con">
      <source>Not configured</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Not configured</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_device_updates_fota">
      <source>Device updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Device updates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_config_set">
      <source>Configuration Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Configuration sett.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_uninstallation_complete">
      <source>Uninstallation complete</source>
      <translation variants="no">zh #Software uninstalled</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_download_complete">
      <source>Download complete</source>
      <translation variants="no">zh #Download complete</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_device_updates_val_connect_fota">
      <source>connecting</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Connecting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_file1_2">
      <source>File:%1 (%2)</source>
      <translation variants="no">zh #File: %[66]1 (%[66]2)</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_install_to_val_1_2_Gb">
      <source>%1: ( %L2) Gb</source>
      <translation variants="no">zh #%[09]1: (%L2 GB)</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_installation_will_proceed_n">
      <source>Installation will proceed now</source>
      <translation variants="no">zh ##Installation will proceed now</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_install_to_val_1_2_Mb">
      <source>%1: ( %L2) Mb</source>
      <translation variants="no">zh #%[09]1: (%L2 MB)</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_size_1_kb">
      <source>Size: %L1 Kb</source>
      <translation variants="no">zh #Size: %[68]1 kB</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_later">
      <source>Later</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Later</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dialog_enter_the_configuration_p">
      <source>Enter the Configuration Pin </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Enter configuration PIN </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_to_update_your_val_bluet">
      <source>Bluetooth</source>
      <translation variants="no">zh ##Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_removing">
      <source>Uninstalling/Removing</source>
      <translation variants="no">zh #Uninstalling/removing</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_verification_failed_and_mes">
      <source>Verification failed and message was deleted. Contact your service provider</source>
      <translation variants="no">zh #Verification failed and message was deleted. Contact your service provider.</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_access_point_val_default">
      <source>Default</source>
      <translation variants="no">zh #Default</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">zh #Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_an_error_occurred_during_do">
      <source>An error occurred during download. Device will try resuming the download after some time.</source>
      <translation variants="no">zh #Error occurred. Device will try to resume download later.</translation>
    </message>
    <message numerus="yes" id="txt_device_update_info_security_information_did_no">
      <source>Security Information did not Match . %Ln tries left.
Enter first 4 characters of the %1 PIN code </source>
      <translation>
        <numerusform plurality="a">zh #Security information did not match . %Ln try left.
Enter first 4 characters of PIN for %1.</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_install_to_val_1_2_kb">
      <source>%1: ( %L2) Kb</source>
      <translation variants="no">zh #%[08]1: (%L2 kB)</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_mandatory_fields_not_filled">
      <source>Mandatory fields not filled, server profile will not be created, exit anyway?</source>
      <translation variants="no">zh #Server profile will not be created because there is missing information. Exit anyway?</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wireless_village_settings">
      <source>Wireless Village settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Instant messaging settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_bookmark">
      <source>Bookmark</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Bookmark</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_port">
      <source>Port</source>
      <translation variants="no">zh #Port</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_GPRS">
      <source>GPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #GPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_connection_lost_while_do">
      <source>Internet connection lost.Device will try resuming the download once the connection is available</source>
      <translation variants="no">zh #Internet connection lost. Device will try to continue the download when the connection is available again.</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_settings_are_already_saved">
      <source>Settings are already saved. Save again?" </source>
      <translation variants="no">zh #Settings already saved. Save again?</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_phone_uptodate_popup">
      <source>Phone Up-to-date</source>
      <translation variants="no">zh #Device up-to-date</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_size_1_mb">
      <source>Size: %L1 Mb</source>
      <translation variants="no">zh #Size: %[67]1 MB</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_ready">
      <source>Ready</source>
      <translation variants="no">zh #Ready</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_password">
      <source>Password</source>
      <translation variants="no">zh #Password</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_mailbox_settings">
      <source>Mailbox Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Mailbox settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_installing">
      <source>Installing </source>
      <translation variants="no">zh #Installing </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_uninstall">
      <source>Uninstalling %1</source>
      <translation variants="no">zh #Uninstalling %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_download_comple">
      <source>Download %1 Complete</source>
      <translation variants="no">zh #Download %[]1 complete</translation>
    </message>
  </context>
</TS>