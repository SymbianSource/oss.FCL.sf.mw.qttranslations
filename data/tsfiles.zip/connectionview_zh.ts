<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_button_disconnect">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">断开连接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_list_name">
      <source>Name</source>
      <translation variants="no">名称：</translation>
    </message>
    <message numerus="no" id="txt_occ_info_no_active_connections">
      <source>No active connections</source>
      <translation variants="no">(无当前连接)</translation>
    </message>
    <message numerus="no" id="txt_occ_button_disconnect_all">
      <source>Disconnect all</source>
      <translation variants="yes">
        <lengthvariant priority="1">断开所有连接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_connection_details">
      <source>Connection details</source>
      <translation variants="yes">
        <lengthvariant priority="1">连接详情</lengthvariant>
      </translation>
    </message>
  </context>
</TS>