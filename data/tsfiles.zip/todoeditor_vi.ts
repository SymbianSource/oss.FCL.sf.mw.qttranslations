<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">Chủ đề</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="no">Thời gian phát âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_db_conflict_info_delete">
      <source>This entry has been deleted by another application</source>
      <translation variants="no">Mục lịch này đã bị xóa bởi một ứng dụng khác</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_low">
      <source>Low</source>
      <translation variants="no">Thấp</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_todo">
      <source>New To-do</source>
      <translation variants="no">Ghi chú công việc mới</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">Ngày đến hạn</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="no">Ngày phát âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_time">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">Loại bỏ thay đổi</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">Thêm mô tả</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_high">
      <source>High</source>
      <translation variants="no">Cao</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_todo">
      <source>To-do</source>
      <translation variants="no">Ghi chú công việc</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="no">Ngày và giờ phát âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_date">
      <source>%2</source>
      <translation variants="no">%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_normal">
      <source>Normal</source>
      <translation variants="no">Bình thường</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_due_date">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">Xóa mô tả</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">Âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_database_conflict">
      <source>Database conflict</source>
      <translation variants="no">Mâu thuẫn cơ sở dữ liệu lịch</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_due_date">
      <source>Due date</source>
      <translation variants="no">Ngày đến hạn</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_description">
      <source>Description</source>
      <translation variants="no">Mô tả</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_db_conflict_info_modify">
      <source>This entry has been modified by another application</source>
      <translation variants="no">Mục lịch này đã bị sửa đổi bởi một ứng dụng khác</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_priority">
      <source>Priority</source>
      <translation variants="no">Ưu tiên</translation>
    </message>
  </context>
</TS>