<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_software_dblist_val_not_activated">
      <source>Not activated</source>
      <translation variants="no">zh_tw #Not activated</translation>
    </message>
    <message numerus="no" id="txt_software_info_this_update_improves_your_device">
      <source>This update improves your device performance and brings you latest features.</source>
      <translation variants="no">zh_tw #This update will improve device performance and bring the latest features.</translation>
    </message>
    <message numerus="no" id="txt_software_info_this_application_allows_you_to_d">
      <source>This application allows you to download and use applications and services provided by Nokia or third parties. Service Terms and Privacy Policy will apply. Nokia will not assume any liability or responsibility for the availability or third party applications or services. Before using the third party application or service, read the applicable terms of use. Use of this application involves transmission of data.&lt;br /&gt;Contact your network service provider for information about data transmission charges.&lt;br /&gt;(c) %L1-%L2 Nokia. All rights reserved.</source>
      <translation variants="no">zh_tw #This application allows you to download and use applications and services provided by Nokia or third parties. Service Terms and Privacy Policy will apply. Nokia will not assume any liability or responsibility for the availability or third party applications or services. Before using the third party application or service, read the applicable terms of use. Use of this application involves transmission of data.&lt;br /&gt;Contact your network service provider for information about data transmission charges.&lt;br /&gt;(c) %L1-%L2 Nokia. All rights reserved.</translation>
    </message>
    <message numerus="no" id="txt_software_info_version_1l_2l_3l">
      <source>%L1.%L2 (%L3)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #%L1.%L2 (%L3)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_updates_1_need_deselected_upd">
      <source>Updates "%1" need deselected update to work</source>
      <translation variants="no">zh_tw #Updates "%1" need deselected update to work</translation>
    </message>
    <message numerus="no" id="txt_software_info_installing_1">
      <source>Installing 1%</source>
      <translation variants="no">zh_tw #Installing 1%</translation>
    </message>
    <message numerus="no" id="txt_software_info_selected_update_also_needs_updat">
      <source>Selected update also needs updates "%1" to work</source>
      <translation variants="no">zh_tw #Selected update also needs updates "%1" to work</translation>
    </message>
    <message numerus="yes" id="txt_software_dblist_val_ln_update">
      <source>%Ln updates</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_refreshing_failed_try_agai">
      <source>Refreshing failed. Try again later.</source>
      <translation variants="no">zh_tw #Refreshing failed. Try again later.</translation>
    </message>
    <message numerus="no" id="txt_software_info_selected_update_also_needs_1">
      <source>Selected update also needs "%1" to work</source>
      <translation variants="no">zh_tw #Selected update also needs "%1" to work</translation>
    </message>
    <message numerus="no" id="txt_software_info_update_1_needs_deselected_upd">
      <source>Update "%1" needs deselected update to work</source>
      <translation variants="no">zh_tw #Update "%1" needs deselected update to work</translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_val_on">
      <source>On</source>
      <translation variants="no">zh_tw #On</translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_successful">
      <source>%Ln updates successful</source>
      <translation>
        <numerusform plurality="a">zh_tw #%Ln successful update</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_subhead_application_updates">
      <source>Application updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Application updates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_name">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Name:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_task_caption_software_update">
      <source>Software update</source>
      <translation variants="no">zh_tw #Software update</translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_update_available">
      <source>Update available</source>
      <translation variants="no">zh_tw #Update available</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_updated">
      <source>Updated</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Updated</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_updates_available">
      <source>Updates available</source>
      <translation variants="no">zh_tw #Updates available</translation>
    </message>
    <message numerus="no" id="txt_software_opt_settings">
      <source>Settings</source>
      <translation variants="no">zh_tw #Settings</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_optional_kb">
      <source>Optional (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Optional (%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_please_use_your_pc_to_update_the">
      <source>Use your PC to update the device software ([version %L])  from address www.nokia.com/softwareupdate</source>
      <translation variants="no">zh_tw #Use your PC to update the device software ([version %L])  from address www.nokia.com/softwareupdate</translation>
    </message>
    <message numerus="no" id="txt_software_info_this_required_update_cannot_be_o">
      <source>This required update cannot be omitted.</source>
      <translation variants="no">zh_tw #Required update - cannot be omitted</translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_applications_are_up_to_date">
      <source>Applications are up to date</source>
      <translation variants="no">zh_tw #Applications are up-to-date</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_available">
      <source>Update available</source>
      <translation variants="no">zh_tw #Update available</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_device_software">
      <source>Device software</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Device software</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_failed">
      <source>%Ln updates failed</source>
      <translation>
        <numerusform plurality="a">zh_tw #%Ln failed update</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_update_list_software_update">
      <source>Software update</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Software update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_dependencies">
      <source>Dependencies</source>
      <translation variants="no">zh_tw #Dependencies</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_failed">
      <source>Failed</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Failed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_software_update">
      <source>Software update</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Software update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_insufficient_memory_free_some_m">
      <source>Insufficient memory. Free some memory and try again.</source>
      <translation variants="no">zh_tw #Insufficient memory. Free some memory and try again.</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_required_kb">
      <source>Required (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Required (%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_required_mb">
      <source>Required (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Required (%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_details">
      <source>Details</source>
      <translation variants="no">zh_tw #Details</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_downloading_1">
      <source>Downloading %1</source>
      <translation variants="no">zh_tw #Downloading %1</translation>
    </message>
    <message numerus="no" id="txt_software_button_accept">
      <source>Accept</source>
      <translation variants="no">zh_tw #Accept</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_selected_1l_2l_3l_kb">
      <source>Selected %L1/%L2 (%L3 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Selected: %L1/%L2 (%L3 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">zh_tw #Off</translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_cancelled">
      <source>%Ln updates cancelled</source>
      <translation>
        <numerusform plurality="a">zh_tw #%Ln cancelled update</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_opt_cancel_update">
      <source>Cancel update</source>
      <translation variants="no">zh_tw #Cancel update</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_checking">
      <source>Update checking</source>
      <translation variants="no">zh_tw #Update checking</translation>
    </message>
    <message numerus="no" id="txt_software_title_disclaimer">
      <source>Disclaimer</source>
      <translation variants="no">zh_tw #Disclaimer</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_l_kb">
      <source>%L kB</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #%L1 kB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_autocheck_for_updates">
      <source>Auto-check for updates</source>
      <translation variants="no">zh_tw #Automatic check for updates</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Description:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_refreshing_updates_list">
      <source>Refreshing updates list</source>
      <translation variants="no">zh_tw #Refreshing updates list</translation>
    </message>
    <message numerus="no" id="txt_software_dpopinfo_tap_to_view">
      <source>Tap to view</source>
      <translation variants="no">zh_tw #Tap to view</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_device_software_available">
      <source>Device software available</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Device software available</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_updates_available">
      <source>Updates available</source>
      <translation variants="no">zh_tw #Updates available</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_version">
      <source>Version:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Version:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_now">
      <source>Now</source>
      <translation variants="no">zh_tw #Now</translation>
    </message>
    <message numerus="no" id="txt_software_button_decline">
      <source>Decline</source>
      <translation variants="no">zh_tw #Decline</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_optional_mb">
      <source>Optional (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Optional (%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_later">
      <source>Later</source>
      <translation variants="no">zh_tw #Later</translation>
    </message>
    <message numerus="no" id="txt_software_title_update_results">
      <source>Update results</source>
      <translation variants="no">zh_tw #Update results</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_recommended_kb">
      <source>Recommended (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Recommended (%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_allow_automatic_update_checks">
      <source>Allow automatic update checks?</source>
      <translation variants="no">zh_tw #Allow automatic update checks?</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_installing_1">
      <source>Installing %1</source>
      <translation variants="no">zh_tw #Installing %1</translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_network_connection">
      <source>Network connection</source>
      <translation variants="no">zh_tw #Network connection</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_important_kb">
      <source>Important (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Important (%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_device_restart_is_needed_restar">
      <source>Device restart is needed. Restart now?</source>
      <translation variants="no">zh_tw #Device restart needed. Restart now?</translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_update_checking">
      <source>Update checking</source>
      <translation variants="no">zh_tw #Update checking</translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_val_on_in_home_network">
      <source>On in home network</source>
      <translation variants="no">zh_tw #On in home network</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_downloaded">
      <source>Downloaded</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Downloaded</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_opt_disclaimer">
      <source>Disclaimer</source>
      <translation variants="no">zh_tw #Disclaimer</translation>
    </message>
    <message numerus="no" id="txt_software_info_application_update_is_available">
      <source>Application update is available from Nokia. Update?</source>
      <translation variants="no">zh_tw #Application update available from Nokia. Update?</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_recommended_mb">
      <source>Recommended (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Recommended (%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_size">
      <source>Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Size:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_l_mb">
      <source>%L MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #%L1 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_important_mb">
      <source>Important (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Important (%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_update">
      <source>Update</source>
      <translation variants="no">zh_tw #Update</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_selected_1l_2l_3l_mb">
      <source>Selected %L1/%L2 (%L3 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Selected: %L1/%L2 (%L3 MB)</lengthvariant>
      </translation>
    </message>
  </context>
</TS>