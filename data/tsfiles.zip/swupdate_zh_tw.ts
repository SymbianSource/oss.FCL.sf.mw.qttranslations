<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_software_setlabel_val_on">
      <source>On</source>
      <translation variants="no">開</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_downloading_1">
      <source>Downloading %1</source>
      <translation variants="no">正在下載%1</translation>
    </message>
    <message numerus="no" id="txt_software_info_application_update_is_available">
      <source>Application update is available from Nokia. Update?</source>
      <translation variants="no">Nokia有應用程式更新可供使用。是否更新？</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_recommended_mb">
      <source>Recommended (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">建議(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_accept">
      <source>Accept</source>
      <translation variants="yes">
        <lengthvariant priority="1">接受</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_dependencies">
      <source>Dependencies</source>
      <translation variants="no">依存性</translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_successful">
      <source>%Ln updates successful</source>
      <translation>
        <numerusform plurality="a">%Ln個成功的更新</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_failed">
      <source>Failed</source>
      <translation variants="yes">
        <lengthvariant priority="1">失敗</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_important_kb">
      <source>Important (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">重要(%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_decline">
      <source>Decline</source>
      <translation variants="yes">
        <lengthvariant priority="1">拒絕</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_refreshing_updates_list">
      <source>Refreshing updates list</source>
      <translation variants="no">正在重新整理更新清單</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_optional_mb">
      <source>Optional (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇性(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dpopinfo_tap_to_view">
      <source>Tap to view</source>
      <translation variants="no">點擊以檢視</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_optional_kb">
      <source>Optional (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇性(%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_device_restart_is_needed_restar">
      <source>Device restart is needed. Restart now?</source>
      <translation variants="no">必須重新啟動裝置。是否現在重新啟動？</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_application_updates">
      <source>Application updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">應用程式更新</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_subhead_selected_1l_2l_3l_kb">
      <source>Selected %L1/%L2 (%L3 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">已選取：%L1/%L2(%L3 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_size">
      <source>Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">大小：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_l_mb">
      <source>%L MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_update_checking">
      <source>Update checking</source>
      <translation variants="no">更新檢查</translation>
    </message>
    <message numerus="no" id="txt_software_info_please_use_your_pc_to_update_the">
      <source>Use your PC to update the device software ([version %L])  from address &lt;a href=http://www.nokia.com/softwareupdate”&gt;http://www.nokia.com/softwareupdate&lt;/a&gt;</source>
      <translation variants="no">zh_tw #Use your PC to update your device's software ([version %L])  from address &lt;a href=http://www.nokia.com/softwareupdate”&gt;http://www.nokia.com/softwareupdate&lt;/a&gt;</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_name">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_this_required_update_cannot_be_o">
      <source>This required update cannot be omitted.</source>
      <translation variants="no">必須更新-無法略過</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_device_software_available">
      <source>Device software available</source>
      <translation variants="yes">
        <lengthvariant priority="1">有可用的裝置軟體</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_later">
      <source>Later</source>
      <translation variants="yes">
        <lengthvariant priority="1">稍後</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_software_update">
      <source>Software update</source>
      <translation variants="yes">
        <lengthvariant priority="1">軟體更新</lengthvariant>
        <lengthvariant priority="2">zh_tw #SW update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_val_on_in_home_network">
      <source>On in home network</source>
      <translation variants="no">於原註冊系統開啟</translation>
    </message>
    <message numerus="no" id="txt_software_info_insufficient_memory_free_some_m">
      <source>Insufficient memory. Free some memory and try again.</source>
      <translation variants="no">記憶體不足。請釋放一些記憶體並再試一次。</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_important_mb">
      <source>Important (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">重要(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_cancelled">
      <source>%Ln updates cancelled</source>
      <translation>
        <numerusform plurality="a">%Ln個取消的更新</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_opt_cancel_update">
      <source>Cancel update</source>
      <translation variants="no">取消更新</translation>
    </message>
    <message numerus="no" id="txt_software_button_update">
      <source>Update</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_required_kb">
      <source>Required (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">必須(%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_subhead_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_update_available">
      <source>Update available</source>
      <translation variants="no">可用的更新</translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_updates_available">
      <source>Updates available</source>
      <translation variants="no">可用的更新</translation>
    </message>
    <message numerus="no" id="txt_software_title_update_results">
      <source>Update results</source>
      <translation variants="no">更新結果</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_recommended_kb">
      <source>Recommended (%L1 kB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">建議(%L1 kB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_applications_are_up_to_date">
      <source>Applications are up to date</source>
      <translation variants="no">應用程式是最新的</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_updated">
      <source>Updated</source>
      <translation variants="yes">
        <lengthvariant priority="1">已更新</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_available">
      <source>Update available</source>
      <translation variants="no">有可用的更新</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_checking">
      <source>Update checking</source>
      <translation variants="no">正在檢查更新</translation>
    </message>
    <message numerus="no" id="txt_software_title_disclaimer">
      <source>Disclaimer</source>
      <translation variants="no">免責聲明</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_l_kb">
      <source>%L kB</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 kB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_updates_available">
      <source>Updates available</source>
      <translation variants="no">有可用的更新</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_device_software">
      <source>Device software</source>
      <translation variants="yes">
        <lengthvariant priority="1">裝置軟體</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_downloaded">
      <source>Downloaded</source>
      <translation variants="yes">
        <lengthvariant priority="1">已下載</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_failed">
      <source>%Ln updates failed</source>
      <translation>
        <numerusform plurality="a">%Ln個失敗的更新</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_version">
      <source>Version:</source>
      <translation variants="yes">
        <lengthvariant priority="1">版本：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_allow_automatic_update_checks">
      <source>Allow automatic update checks?</source>
      <translation variants="no">是否允許自動更新檢查？</translation>
    </message>
    <message numerus="no" id="txt_software_button_now">
      <source>Now</source>
      <translation variants="yes">
        <lengthvariant priority="1">現在</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_installing_1">
      <source>Installing %1</source>
      <translation variants="no">正在安裝%1</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_required_mb">
      <source>Required (%L1 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">必須(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_opt_disclaimer">
      <source>Disclaimer</source>
      <translation variants="no">免責聲明</translation>
    </message>
    <message numerus="no" id="txt_software_title_details">
      <source>Details</source>
      <translation variants="no">詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_software_opt_settings">
      <source>Settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_autocheck_for_updates">
      <source>Auto-check for updates</source>
      <translation variants="no">自動檢查更新</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">內容說明：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_subhead_selected_1l_2l_3l_mb">
      <source>Selected %L1/%L2 (%L3 MB)</source>
      <translation variants="yes">
        <lengthvariant priority="1">已選取：%L1/%L2(%L3 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_network_connection">
      <source>Network connection</source>
      <translation variants="no">網路連線</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_val_not_activated">
      <source>Not activated</source>
      <translation variants="no">未啟動</translation>
    </message>
    <message numerus="no" id="txt_software_info_this_application_allows_you_to_d">
      <source>This application allows you to download and use applications and services provided by Nokia or third parties. Service Terms and Privacy Policy will apply. Nokia will not assume any liability or responsibility for the availability or third party applications or services. Before using the third party application or service, read the applicable terms of use. Use of this application involves transmission of data.&lt;br /&gt;Contact your network service provider for information about data transmission charges.&lt;br /&gt;(c) %L1-%L2 Nokia. All rights reserved.</source>
      <translation variants="no">此應用程式可讓您下載和使用Nokia及其協力廠商所提供的應用程式與服務。適用於服務條款與隱私權政策。對於協力廠商提供的應用程式或服務之可用性，Nokia沒有義務亦不承擔任何責任。使用協力廠商的應用程式與服務之前，請閱讀適用的使用條款。使用此應用程式需要資料傳輸。&lt;br /&gt;若需要資料傳輸費用的資訊，請洽詢網路服務提供商。&lt;br /&gt;(c) %L1-%L2 Nokia。版權所有。</translation>
    </message>
    <message numerus="no" id="txt_software_info_this_update_improves_your_device">
      <source>This update improves your device performance and brings you latest features.</source>
      <translation variants="no">這項更新將會改善裝置的效能，並提供您最新的功能。</translation>
    </message>
    <message numerus="no" id="txt_software_info_version_1l_2l_3l">
      <source>%L1.%L2 (%L3)</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1.%L2(%L3)</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_software_dblist_val_ln_update">
      <source>%Ln updates</source>
      <translation>
        <numerusform plurality="a">%Ln個更新</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_refreshing_failed_try_agai">
      <source>Refreshing failed. Try again later.</source>
      <translation variants="no">重新整理失敗。請稍後再試。</translation>
    </message>
    <message numerus="no" id="txt_software_info_updates_1_need_deselected_upd">
      <source>Updates "%1" need deselected update to work</source>
      <translation variants="no">更新"%[56]1"需要這項更新才能運作</translation>
    </message>
    <message numerus="no" id="txt_software_info_installing_1">
      <source>Installing %1</source>
      <translation variants="no">正在安裝%1</translation>
    </message>
    <message numerus="no" id="txt_software_info_update_1_needs_deselected_upd">
      <source>Update "%1" needs deselected update to work</source>
      <translation variants="no">更新"%[58]1"需要這項更新才能運作</translation>
    </message>
    <message numerus="no" id="txt_software_info_selected_update_also_needs_updat">
      <source>Selected update also needs updates "%1" to work</source>
      <translation variants="no">選取的更新也需要以下更新才能運作：
%1</translation>
    </message>
    <message numerus="no" id="txt_software_info_selected_update_also_needs_1">
      <source>Selected update also needs "%1" to work</source>
      <translation variants="no">選取的更新也需要此更新才能運作：
%1</translation>
    </message>
    <message numerus="no" id="txt_long_caption_iaupdatelauncher">
      <source>Software update</source>
      <translation variants="no">軟體更新</translation>
    </message>
    <message numerus="no" id="txt_short_caption_iaupdate">
      <source>Software update</source>
      <translation variants="no">zh_tw #Software update</translation>
    </message>
    <message numerus="no" id="txt_short_caption_iaupdatelauncher">
      <source>Software update</source>
      <translation variants="no">zh_tw #Software update</translation>
    </message>
  </context>
</TS>