<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_dict2_button_accept">
      <source>Accept</source>
      <translation variants="no">ur #I accept</translation>
    </message>
    <message numerus="no" id="txt_dict2_title_delete_history">
      <source>Delete History:</source>
      <translation variants="no">ur #Clear history:</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_sub_very_big">
      <source>Very big</source>
      <translation variants="no">ur #Very large</translation>
    </message>
    <message numerus="no" id="txt_dict2_title_dictionary">
      <source>Dictionary</source>
      <translation variants="no">ur #Dictionary</translation>
    </message>
    <message numerus="no" id="txt_dict2_info_legal_disclaimer">
      <source>All contents and information (\"Content\") are proprietary to DW Education (Group) Limited and Cambridge University Press and are subjected to copyright protection. Nokia makes no representations or warranties, express or implied, including but not limited to the warranties of the accuracy or completeness of the Contents or that the Contents will not infringe any third party intellectual property rights. In no event shall Nokia be liable for the Contents in any aspect.\nBy clicking 'Accept' below you acknowledge that you have read, understand, and agree to be bound by the terms above.</source>
      <translation variants="no">ur #All contents and information ('Content') are proprietary to DW Education (Group) Limited and Cambridge University Press, and are subjected to copyright protection. Nokia makes no representations or warranties, express or implied, including but not limited to the warranties of the accuracy or completeness of the Content or that the Content will not infringe any third party intellectual property rights. In no event shall Nokia be liable for the Content in any aspect.
By clicking 'I accept' below you acknowledge that you have read, understand, and agree to be bound by the terms above.</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_sub_small">
      <source>Small</source>
      <translation variants="no">ur #Small</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_sub_normal">
      <source>Normal</source>
      <translation variants="no">ur #Normal</translation>
    </message>
    <message numerus="no" id="txt_dict2_title_legal_disclaimer">
      <source>Legal disclaimer:</source>
      <translation variants="no">ur #Disclaimer:</translation>
    </message>
    <message numerus="no" id="txt_dict2_dialog_entry_fuzzy_search">
      <source>*? for fuzzy search</source>
      <translation variants="no">ur #Enter * or ? for fuzzy search</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_history_record_setting">
      <source>Keep history record for</source>
      <translation variants="no">ur #Keep history for</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_sub_90_days">
      <source>90 days</source>
      <translation variants="no">ur #90 days</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_text_size">
      <source>Text Size</source>
      <translation variants="no">ur #Text size</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_adjust_volume">
      <source>Adjust Volume</source>
      <translation variants="no">ur #Adjust volume</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_sub_big">
      <source>Big</source>
      <translation variants="no">ur #Large</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_sub_for_ever">
      <source>For ever</source>
      <translation variants="no">ur #Always on</translation>
    </message>
    <message numerus="no" id="txt_short_caption_dict2">
      <source>Dict.</source>
      <translation variants="no">ur #Dict.</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_sub_very_small">
      <source>Very Small</source>
      <translation variants="no">ur #Very small</translation>
    </message>
    <message numerus="no" id="txt_long_caption_dict2">
      <source>Dictionary</source>
      <translation variants="no">ur #Dictionary</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_sub_30_days">
      <source>30 days</source>
      <translation variants="no">ur #30 days</translation>
    </message>
    <message numerus="no" id="txt_dict2_setlabel_no_result">
      <source>No Result</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #(no matches)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dict2_info_dict_files_missing">
      <source>Dictionary files missing. The files may have been deleted or are located on a memory card that is not available.</source>
      <translation variants="no">ur #Dictionary files missing</translation>
    </message>
    <message numerus="no" id="txt_dict2_opt_sub_not_save">
      <source>Not save</source>
      <translation variants="no">ur #Off</translation>
    </message>
  </context>
</TS>