<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_new_pac_store_password">
      <source>New PAC store password:</source>
      <translation variants="no">新的PAC存储密码：</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_provisioning_mode_for_eapfast">
      <source>EAP-FAST provisioning mode</source>
      <translation variants="no">EAP-FAST配置模式：</translation>
    </message>
    <message numerus="no" id="txt_occ_info_incorrect_password">
      <source>Incorrect password</source>
      <translation variants="no">密码不正确</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="no">PAC存储密码：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_no_certificates_installed_wizard_c">
      <source>No certificates installed. Wizard cannot continue.</source>
      <translation variants="no">未安装证书。无法继续安装。</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_confirm_password">
      <source>Confirm password:</source>
      <translation variants="no">验证密码：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_password">
      <source>Password:</source>
      <translation variants="no">密码：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_for_1">
      <source>User name for '%1':</source>
      <translation variants="no">"%[51]1"的用户名：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_realm">
      <source>Realm:</source>
      <translation variants="no">安全域：</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_provisioning_mode_for_val_unauthent">
      <source>Unauthenticated</source>
      <translation variants="no">未鉴定</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_select_automatically">
      <source>Select automatically</source>
      <translation variants="no">自动选择</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_innear_eap_type_for_1">
      <source>Select inner EAP type for '%1':</source>
      <translation variants="no">选择"%[47]1"的内部EAP类型：</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_eap_type">
      <source>Select EAP type:</source>
      <translation variants="no">选择EAP类型：</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_inner_eap">
      <source>Inner EAP</source>
      <translation variants="no">内部EAP：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_generate_automatic">
      <source>Generate automatically</source>
      <translation variants="no">自动生成</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_authority_certificate">
      <source>Select authority certificate:</source>
      <translation variants="no">选择授权证书：</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_outer_eap">
      <source>Outer EAP</source>
      <translation variants="no">外部EAP：</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_user_certificate">
      <source>Select user certificate:</source>
      <translation variants="no">选择个人证书：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_check_sim">
      <source>%1 authentication failed. Check SIM card.</source>
      <translation variants="no">%[62]1鉴定失败。检查SIM卡。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_auth_failed_user_cert_exp">
      <source>%1 authentication failed. User certificate has expired.</source>
      <translation variants="no">%[59]1鉴定失败。个人证书已过期。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_cipher_su">
      <source>%1 authentication failed. Cipher suite mismatch.</source>
      <translation variants="no">%[60]1鉴定失败。密码套件不符。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_server_ce">
      <source>%1 authentication failed. Server certificate has expired.</source>
      <translation variants="no">%[58]1鉴定失败。服务器证书已过期。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed">
      <source>%1 authentication failed</source>
      <translation variants="no">%[68]1鉴定失败</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_auth_failed_user_cert_rej">
      <source>%1 authentication failed. User certificate not accepted.</source>
      <translation variants="no">%[59]1鉴定失败。不接受个人证书。</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_realm_val_generate_automatic">
      <source>Generate automatically</source>
      <translation variants="no">自动生成</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_reset_pac">
      <source>%1 authentication failed. Reset PAC store.</source>
      <translation variants="no">%[61]1鉴定失败。删除PAC存储。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_could_not">
      <source>%1 authentication failed. Could not verify server certificate.</source>
      <translation variants="no">%[57]1鉴定失败。无法验证服务器证书。</translation>
    </message>
  </context>
</TS>