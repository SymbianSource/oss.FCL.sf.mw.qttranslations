<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_randomizer_title_random_generator">
      <source>Randomizer</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #No. generator</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_randomizer_checkbox_same_numbers">
      <source>Same numbers</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Use same numbers</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_randomizer_button_clear">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #New message in inbox with text</lengthvariant>
        <lengthvariant priority="2">ur #New message</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_randomizer_button_generate">
      <source>Generate</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Generate</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_randomizer_checkbox_invert_display_colors">
      <source>Invert display colors</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Invert display colours</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_randomizer_checkbox_generate_even_numbers">
      <source>Generate even numbers</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Generate even numbers</lengthvariant>
      </translation>
    </message>
  </context>
</TS>