<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_user">
      <source>User authentication</source>
      <translation variants="no">vi ##User authentication</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path">
      <source>Folder path</source>
      <translation variants="no">vi ##Folder path</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path_user_defined">
      <source>User defined</source>
      <translation variants="no">vi ##User defined</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_same">
      <source>Same as for incoming</source>
      <translation variants="no">vi ##Same as for incoming</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_none">
      <source>None</source>
      <translation variants="no">vi ##None</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port_default">
      <source>Default</source>
      <translation variants="no">vi ##Default</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_port">
      <source>Outgoing port</source>
      <translation variants="no">vi ##Outgoing port</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port">
      <source>Incoming port</source>
      <translation variants="no">vi ##Incoming port</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mailips">
      <source>Mail</source>
      <translation variants="no">vi ##Mail</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port_user_defined">
      <source>User defined</source>
      <translation variants="no">vi ##User defined</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_security">
      <source>Outgoing secure connection</source>
      <translation variants="no">vi ##Outgoing secure connection</translation>
    </message>
    <message numerus="no" id="txt_mailnips_setlabel_signature">
      <source>Signature</source>
      <translation variants="no">vi ##Signature</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_inbox_path_user_defined">
      <source>User defined</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_reply_to_address">
      <source>Reply to address</source>
      <translation variants="no">Địa chỉ trả lời</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_port">
      <source>Port</source>
      <translation variants="no">Cổng</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_receiving_schedule">
      <source>Receiving Schedule</source>
      <translation variants="no">Lịch biểu tải</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_user_info">
      <source>User info</source>
      <translation variants="no">Cài đặt người dùng</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_secure_connection">
      <source>Secure connection</source>
      <translation variants="no">Kết nối an toàn</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_save_energy">
      <source>Save energy</source>
      <translation variants="no">Tiết kiệm pin</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_every_day">
      <source>Every day</source>
      <translation variants="no">Mỗi ngày</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_wed">
      <source>Wed</source>
      <translation variants="no">Thứ Tư</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_refresh_during_daytime_val_on">
      <source>On (SLL/TLS)</source>
      <translation variants="no">Bật (SSL/TLS)</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">Làm mới hộp thư</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_show_mail_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">H.thị e-mail trong h.thư đến</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_keep_upto">
      <source>Keep up-to-date</source>
      <translation variants="no">Luôn cập nhật</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode">
      <source>Selected mode</source>
      <translation variants="no">Làm mới t.chọn đang s.dụng</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_refresh_during_daytime_val_of">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_inbox_path">
      <source>Inbox path</source>
      <translation variants="no">Đường dẫn hộp thư</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_thu">
      <source>Thu</source>
      <translation variants="no">Thứ Năm</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_fri">
      <source>Fri</source>
      <translation variants="no">Thứ Sáu</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_on_ssltls">
      <source>On (SLL/TLS)</source>
      <translation variants="no">vi ##On (SLL/TLS)</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_tue">
      <source>Tue</source>
      <translation variants="no">Thứ Ba</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_mail_server">
      <source>Outgoing mail server</source>
      <translation variants="no">Máy chủ gửi e-mail</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_username">
      <source>Username</source>
      <translation variants="no">Tên người dùng</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_only_by">
      <source>The mailbox is refreshed only by user request</source>
      <translation variants="no">Nội dung hộp thư chỉ được làm mới khi người dùng bắt đầu</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_day_start_time">
      <source>Day start time</source>
      <translation variants="no">Thời gian bắt đầu ngày</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_preferences">
      <source>Preferences</source>
      <translation variants="no">Cài đặt tài khoản</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_day_end_time">
      <source>Day end time</source>
      <translation variants="no">Thời gian kết thúc ngày</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">Địa chỉ e-mail</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_connection">
      <source>Connection</source>
      <translation variants="no">Kết nối</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_sat">
      <source>Sat</source>
      <translation variants="no">Thứ Bảy</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_uptodate_during">
      <source>The mailbox is up-to-date during daytime</source>
      <translation variants="no">Nội dung hộp thư được cập nhật trong ngày</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_fetch_manua">
      <source>Fetch manually</source>
      <translation variants="no">Tải e-mail thủ công</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_when_i_open_mailbox">
      <source>When I open mailbox</source>
      <translation variants="no">Khi tôi mở hộp thư</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_every_15">
      <source>The mailbox is refreshed every 15 minutes during daytime</source>
      <translation variants="no">Nội dung hộp thư được làm mới mỗi 15 phút trong ngày</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_version_l1">
      <source>Version: %[]1</source>
      <translation variants="no">vi #Version: %[512]1</translation>
    </message>
    <message numerus="no" id="txt_mailips_button_delete_mailbox">
      <source>Delete mailbox</source>
      <translation variants="no">Xóa hộp thư</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_user_define">
      <source>User defined</source>
      <translation variants="no">Người dùng xác định</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_on_starttls">
      <source>On (StartTLS)</source>
      <translation variants="no">vi ##On (StartTLS)</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_security">
      <source>Incoming secure connection</source>
      <translation variants="no">vi ##Incoming secure connection</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_keep_uptodate">
      <source>Keep up-to-date</source>
      <translation variants="no">Luôn cập nhật</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_off">
      <source>Off</source>
      <translation variants="no">vi ##Off</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path_val_default">
      <source>Default</source>
      <translation variants="no">vi ##Default</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_inbox_path_val_default">
      <source>Default</source>
      <translation variants="no">Mặc định</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_sun">
      <source>Sun</source>
      <translation variants="no">Chủ Nhật</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_receiving_weekdays">
      <source>Receiving weekdays</source>
      <translation variants="no">Số ngày tải</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_mailbox_name">
      <source>Mailbox name</source>
      <translation variants="no">Tên hộp thư</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_password">
      <source>Password</source>
      <translation variants="no">Mật khẩu</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_as_defin">
      <source>The mailbox is refreshed as defined by the user</source>
      <translation variants="no">Nội dung hộp thư được làm mới theo xác định của người dùng</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_mail_server">
      <source>Incoming mail server</source>
      <translation variants="no">Máy chủ nhận e-mail</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_all">
      <source>All</source>
      <translation variants="no">Tất cả</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_my_name">
      <source>My name</source>
      <translation variants="no">Tên tôi</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_show_mail_in_other_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">H.thị e-mail trg thư mục khác</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_mon">
      <source>Mon</source>
      <translation variants="no">Thứ Hai</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_server_info">
      <source>Server info</source>
      <translation variants="no">Cài đặt máy chủ</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="no">Mỗi 4 giờ</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_1_hour">
      <source>Every 1 hour</source>
      <translation variants="no">vi ##Every 1 hour</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_mail_authentication">
      <source>User authentication</source>
      <translation variants="no">Xác thực người dùng</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="no">Mỗi 15 phút</translation>
    </message>
  </context>
</TS>