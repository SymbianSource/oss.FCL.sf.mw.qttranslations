<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_wep_key_format_val_ascii">
      <source>ASCII</source>
      <translation variants="no">zh #ASCII</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2_val_eap">
      <source>EAP</source>
      <translation variants="no">zh #EAP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wep">
      <source>WEP</source>
      <translation variants="no">zh #WEP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_4">
      <source>#4</source>
      <translation variants="no">zh ##4</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_encryption">
      <source>WEP encryption</source>
      <translation variants="no">zh #WEP encryption</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_root_certificate">
      <source>WAPI root certificate</source>
      <translation variants="no">zh #WAPI root certificate</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_encryption_val_64bit_key">
      <source>64-bit key</source>
      <translation variants="no">zh #64-bit key</translation>
    </message>
    <message numerus="no" id="txt_occ_ascii">
      <source>ASCII</source>
      <translation variants="no">zh #ASCII</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2">
      <source>WPA/WPA2</source>
      <translation variants="no">zh #WPA/WPA2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">zh #Pre-shared key</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_wep_key_4">
      <source>WEP key #4</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #WEP key #4</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_security_settings">
      <source>Security settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Security settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_wep_key_1">
      <source>WEP key #1</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #WEP key #1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_button_eap_type_settings">
      <source>EAP type settings</source>
      <translation variants="no">zh #EAP type settings</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_client_cert_not_defined">
      <source>(not defined)</source>
      <translation variants="no">zh #(not defined)</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_wep_key_3">
      <source>WEP key #3</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #WEP key #3</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_2">
      <source>#2</source>
      <translation variants="no">zh ##2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_1">
      <source>#1</source>
      <translation variants="no">zh ##1</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_authentication">
      <source>WAPI authentication</source>
      <translation variants="no">zh #WAPI authentication</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_wep_key_2">
      <source>WEP key #2</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #WEP key #2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_encryption_val_128bit_key">
      <source>128-bit key</source>
      <translation variants="no">zh #128-bit key</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2_val_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">zh #Pre-shared key</translation>
    </message>
    <message numerus="no" id="txt_occ_preshared_key_format">
      <source>Pre-shared key format</source>
      <translation variants="no">zh #Pre-shared key format</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_type">
      <source>EAP type</source>
      <translation variants="no">zh #EAP type</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unencrypted_connection">
      <source>Unencrypted connection</source>
      <translation variants="no">zh #Unencrypted connection</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_8021x">
      <source>802.1X</source>
      <translation variants="no">zh #802.1X</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_use">
      <source>WEP key in use</source>
      <translation variants="no">zh #WEP key in use</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_root_cert_not_defined">
      <source>(not defined)</source>
      <translation variants="no">zh #(not defined)</translation>
    </message>
    <message numerus="no" id="txt_occ_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">zh #Pre-shared key</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_format_val_hexadecimal">
      <source>Hexadecimal</source>
      <translation variants="no">zh #Hexadecimal</translation>
    </message>
    <message numerus="no" id="txt_occ_certificate">
      <source>Certificate</source>
      <translation variants="no">zh #Certificate</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_format">
      <source>WEP key format</source>
      <translation variants="no">zh #WEP key format</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unencrypted_connection_val_allowe">
      <source>Allowed</source>
      <translation variants="no">zh #Allowed</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_3">
      <source>#3</source>
      <translation variants="no">zh ##3</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpawpa2">
      <source>WPA/WPA2</source>
      <translation variants="no">zh #WPA/WPA2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_4">
      <source>WEP key #4</source>
      <translation variants="no">zh #WEP key #4</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_3">
      <source>WEP key #3</source>
      <translation variants="no">zh #WEP key #3</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key">
      <source>WEP key</source>
      <translation variants="no">zh #WEP key</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_preshared_key_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">zh #(not defined)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wapi">
      <source>WAPI</source>
      <translation variants="no">zh #WAPI</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpa2_only">
      <source>WPA2 only</source>
      <translation variants="no">zh #WPA2 only</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_2">
      <source>WEP key #2</source>
      <translation variants="no">zh #WEP key #2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_1">
      <source>WEP key #1</source>
      <translation variants="no">zh #WEP key #1</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_client_certificate">
      <source>WAPI client certificate</source>
      <translation variants="no">zh #WAPI client certificate</translation>
    </message>
    <message numerus="no" id="txt_occ_hexadecimal">
      <source>Hexadecimal</source>
      <translation variants="no">zh #Hexadecimal</translation>
    </message>
  </context>
</TS>