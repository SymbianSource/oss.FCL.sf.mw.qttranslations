<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dpopinfo_internal_error">
      <source>Internal error </source>
      <translation variants="no">Lỗi nội bộ.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_connecting">
      <source>Connecting</source>
      <translation variants="no">Đang kết nối</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_check_connection_settings">
      <source>Check connection settings</source>
      <translation variants="no">Kiểm tra c.đặt Kết nối</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_service_unreachable">
      <source>Service unreachable</source>
      <translation variants="no">D.vụ ko tiếp cận được.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_connection_already_active">
      <source>Connection already active</source>
      <translation variants="no">Kết nối đã hoạt động.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_configuration_failed">
      <source>Configuration failed</source>
      <translation variants="no">Ko cấu hình được.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_please_try_again">
      <source>Please try again </source>
      <translation variants="no">Thử lại.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_wlan_network_not_found">
      <source>WLAN network not found</source>
      <translation variants="no">Ko tìm thấy mạng WLAN.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_connection_failed">
      <source>Connection failed</source>
      <translation variants="no">Không kết nối được.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_check_security_key">
      <source>Check security key</source>
      <translation variants="no">Kiểm tra khóa bảo mật.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_connection_unavailable">
      <source>Connection unavailable</source>
      <translation variants="no">Kết nối không có sẵn.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_sim_card_missing">
      <source>SIM card missing </source>
      <translation variants="no">Thiếu thẻ SIM.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_authentication_unsuccessful">
      <source>Authentication unsuccessful</source>
      <translation variants="no">Không xác thực được.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_signal_too_weak">
      <source>Signal too weak </source>
      <translation variants="no">Tín hiệu quá yếu.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_maximum_connections_in_use">
      <source>Maximum connections in use</source>
      <translation variants="no">Tất cả kết nối đang dùng.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_select_to_manage">
      <source>Select to manage</source>
      <translation variants="no">Chọn để quản lý.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_permission_denied">
      <source>Permission denied </source>
      <translation variants="no">Giấy phép bị từ chối.</translation>
    </message>
  </context>
</TS>