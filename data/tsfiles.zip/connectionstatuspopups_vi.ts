<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dpopinfo_connection_unavailable">
      <source>Connection unavailable</source>
      <translation variants="no">vi #Connection unavailable.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_check_security_key">
      <source>Check security key</source>
      <translation variants="no">vi #Check security key.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_configuration_failed">
      <source>Configuration failed</source>
      <translation variants="no">vi #Configuration failed.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_please_try_again">
      <source>Please try again </source>
      <translation variants="no">vi #Try again.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_check_connection_settings">
      <source>Check connection settings</source>
      <translation variants="no">vi #Check Connection sett.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_connection_already_active">
      <source>Connection already active</source>
      <translation variants="no">vi #Conn. already active.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_service_unreachable">
      <source>Service unreachable</source>
      <translation variants="no">vi #Service unreachable.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_connection_failed">
      <source>Connection failed</source>
      <translation variants="no">vi #Connection failed.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_wlan_network_not_found">
      <source>WLAN network not found</source>
      <translation variants="no">vi #WLAN netw. not found.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_authentication_unsuccessful">
      <source>Authentication unsuccessful</source>
      <translation variants="no">vi #Authentic. unsuccessful.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_signal_too_weak">
      <source>Signal too weak </source>
      <translation variants="no">vi #Signal too weak.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_sim_card_missing">
      <source>SIM card missing </source>
      <translation variants="no">vi #SIM card missing.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_permission_denied">
      <source>Permission denied </source>
      <translation variants="no">vi #Permission denied.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_select_to_manage">
      <source>Select to manage</source>
      <translation variants="no">vi #Select to manage.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_maximum_connections_in_use">
      <source>Maximum connections in use</source>
      <translation variants="no">vi #Maximum number of connections in use.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_internal_error">
      <source>Internal error </source>
      <translation variants="no">vi #Internal error.</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_connecting">
      <source>Connecting</source>
      <translation variants="no">vi #Connecting</translation>
    </message>
  </context>
</TS>