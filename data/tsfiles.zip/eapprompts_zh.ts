<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_info_provisioning_not_successful_reactiv">
      <source>Provisioning not successful. Re-activate provisioning in settings.</source>
      <translation variants="no">设置失败。在"设置"中重新启动设置。</translation>
    </message>
    <message numerus="no" id="txt_occ_title_1_message">
      <source>%1 message:</source>
      <translation variants="no">%[21]1信息：</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok_single_dialog">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_create_password_for_encrypted_pac_s">
      <source>Create password for encrypted PAC store:</source>
      <translation variants="yes">
        <lengthvariant priority="1">加密PAC存储的密码：</lengthvariant>
        <lengthvariant priority="2">zh #Password for PAC store:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_user_name">
      <source>%1 user name:</source>
      <translation variants="no">%[09]1用户名：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_new_eapmschapv2_password">
      <source>New EAP-MSCHAPv2 password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">新的EAP-MSCHAPv2密码：</lengthvariant>
        <lengthvariant priority="2">zh #New EAP-MSCHAPv2 passw.:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">验证密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_install_pac_from_server_1">
      <source>Install PAC from server '%1'?</source>
      <translation variants="no">从服务器"%[41]1"安装PAC？</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">PAC存储密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_authenticated_provisioning_in_pro">
      <source>Authenticated provisioning in progress</source>
      <translation variants="no">正在进行安全设置</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_pac_file_password_for_1">
      <source>PAC file password for '%1':</source>
      <translation variants="no">"%[05]1"的PAC文件密码：</translation>
    </message>
    <message numerus="no" id="txt_occ_info_eapmschapv2_password_has_expired_yo">
      <source>EAP-MSCHAPv2 password has expired. You must create a new one.</source>
      <translation variants="no">EAP-MSCHAPv2密码已过期。创建新密码。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_old_eapmschapv2_password">
      <source>Old EAP-MSCHAPv2 password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">旧的EAP-MSCHAPv2密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_unauthenticated_provisioning_in_p">
      <source>Unauthenticated provisioning in progress</source>
      <translation variants="no">正在进行非安全设置</translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_password">
      <source>Password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_password">
      <source>%1 password:</source>
      <translation variants="no">%[10]1密码：</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #OK</lengthvariant>
      </translation>
    </message>
  </context>
</TS>