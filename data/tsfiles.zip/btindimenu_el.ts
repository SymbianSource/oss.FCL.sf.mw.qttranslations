<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="el">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_dblist_receiving_files">
      <source>Receiving files</source>
      <translation variants="no">Λήψη αρχείων…</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_paired">
      <source>%1 paired</source>
      <translation variants="no">%[13]1 σε ζεύξη</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="no">Ενεργοποιημένο (ορατό)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="no">Ενεργοποιημένο (κρυφό)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_computer">
      <source>Computer</source>
      <translation variants="no">Υπολογιστής</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_phone">
      <source>Phone</source>
      <translation variants="no">Τηλέφωνο</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="no">Συνδέθηκε (κρυφό)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="no">Απενεργοποιημένο</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_connected">
      <source>%1 connected</source>
      <translation variants="no">%[10]1 σε σύνδεση</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_other_device">
      <source>Other device</source>
      <translation variants="no">Άλλη συσκευή</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_usign_sim_access_profi">
      <source>usign SIM access profile</source>
      <translation variants="no">Λειτουργία απομακρυσμένης πρόσβασης στη SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="no">Σε σύνδεση (ορατό)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_sending_files">
      <source>Sending files</source>
      <translation variants="no">Αποστολή αρχείων…</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_audio_device">
      <source>Audio device</source>
      <translation variants="no">Συσκευή ήχου</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_input_device">
      <source>Input device</source>
      <translation variants="no">Συσκευή εισόδου</translation>
    </message>
  </context>
</TS>