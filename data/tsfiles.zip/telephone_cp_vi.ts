<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_title_delay">
      <source>Delay:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời gian hoãn:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_video">
      <source>Video</source>
      <translation variants="no">Hộp thư video</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_out_of_reach">
      <source>If out of reach</source>
      <translation variants="no">Nếu không liên lạc được</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_edit_barring_password">
      <source>Edit barring password</source>
      <translation variants="no">Chỉnh sửa m.khẩu chặn c.gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number">
      <source>Number:</source>
      <translation variants="no">Số:</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_ask_first">
      <source>Ask first</source>
      <translation variants="no">Hỏi trước</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting">
      <source>Call waiting</source>
      <translation variants="no">Cuộc gọi chờ</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_busy">
      <source>If busy:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khi máy bận:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking">
      <source>Phone line blocking</source>
      <translation variants="no">Đổi số máy</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_received_call">
      <source>Own video in received call</source>
      <translation variants="no">Video riêng trg c.gọi đã nhận</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_yes">
      <source>Yes</source>
      <translation variants="no">Có</translation>
    </message>
    <message numerus="no" id="txt_phone_info_current_password">
      <source>Current password</source>
      <translation variants="no">Mật khẩu hiện tại:</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_default">
      <source>Default</source>
      <translation variants="no">Do mạng cài</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als">
      <source>Phone line in use</source>
      <translation variants="no">Số máy đang dùng</translation>
    </message>
    <message numerus="no" id="txt_phone_dblist_active_diverts">
      <source>Active diverts</source>
      <translation variants="no">Các c.hướng hiện tại</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_password">
      <source>Barring password</source>
      <translation variants="no">Mật mã chặn:</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_not_available">
      <source>If not available:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khi không sẵn sàng:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_ip_mbx">
      <source>%1 mailbox</source>
      <translation variants="no">vi #%[17]1 mailbox</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service_val_video_divert">
      <source>Video divert</source>
      <translation variants="no">Chuyển hướng c.gọi video</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_available_in_curren">
      <source>Service not available in current location</source>
      <translation variants="no">Dịch vụ không có sẵn ở vị trí hiện tại</translation>
    </message>
    <message numerus="no" id="txt_phone_title_all_calls">
      <source>All calls:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tất cả cuộc gọi:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_soft_reject">
      <source>Reject call with message</source>
      <translation variants="no">Từ chối c.gọi bằng tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_not_available">
      <source>If not available</source>
      <translation variants="no">Khi không sẵn sàng</translation>
    </message>
    <message numerus="no" id="txt_phone_formlabel_show_call_duration">
      <source>Show call duration</source>
      <translation variants="no">Hiển thị thời lượng cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_info_new_password">
      <source>New password</source>
      <translation variants="no">Mật khẩu mới:</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service">
      <source>Service</source>
      <translation variants="no">Dịch vụ</translation>
    </message>
    <message numerus="yes" id="txt_phone_setlabel_divert_delay_ln_seconds">
      <source>Divert delay %Ln seconds</source>
      <translation>
        <numerusform plurality="a">Hoãn chuyển hướng: %Ln giây</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx">
      <source>Default mailbox</source>
      <translation variants="no">Mặc định</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_video_mbx">
      <source>Video mailbox</source>
      <translation variants="no">Hộp thư video</translation>
    </message>
    <message numerus="no" id="txt_phone_list_international_calls_except_to_home">
      <source>International calls except to home country</source>
      <translation variants="no">Cuộc gọi quốc tế ngoại trừ các cuộc gọi về nước</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_barring">
      <source>Call barring</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chặn cuộc gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_voice_mbx">
      <source>Voice mailbox</source>
      <translation variants="no">Hộp thư thoại</translation>
    </message>
    <message numerus="no" id="txt_phone_list_to_voice_mailbox">
      <source>To voice mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đến hộp thư thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_send_my_caller_id">
      <source>Send my caller id</source>
      <translation variants="no">Báo số cá nhân</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_not_answered">
      <source>If not answered</source>
      <translation variants="no">Nếu không trả lời</translation>
    </message>
    <message numerus="no" id="txt_phone_list_incoming_call_when_abroad">
      <source>Incoming call when abroad</source>
      <translation variants="no">Cuộc gọi đến khi chuyển vùng</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_edit_barring_password_val_edit">
      <source>Edit</source>
      <translation variants="no">Chỉnh sửa</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_all_calls">
      <source>All calls</source>
      <translation variants="no">Tất cả cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_val_none">
      <source>None</source>
      <translation variants="no">Không có</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_voice_mbx_line_2">
      <source>Voice mailbox line 2</source>
      <translation variants="no">Số hộp thư thoại 2</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_divert">
      <source>Call divert</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chuyển hướng cuộc gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_out_of_reach">
      <source>If out of reach:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nếu không liên lạc được:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_val_user_defined">
      <source>User defined</source>
      <translation variants="no">Người dùng xác định</translation>
    </message>
    <message numerus="no" id="txt_phone_list_enter_number_manually">
      <source>Enter number manually</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhập số</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_settings">
      <source>Call settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt cuộc gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_list_international_calls">
      <source>International calls</source>
      <translation variants="no">Cuộc gọi quốc tế</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_not_answered">
      <source>If not answered:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khi không trả lời:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_list_outgoing_calls">
      <source>Outgoing calls</source>
      <translation variants="no">Cuộc gọi đi</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_dont_show">
      <source>Don't show</source>
      <translation variants="no">Không hiển thị</translation>
    </message>
    <message numerus="yes" id="txt_phone_list_ln_seconds">
      <source>%Ln seconds</source>
      <translation>
        <numerusform plurality="a">%Ln giây</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_show_automatic">
      <source>Show automatically</source>
      <translation variants="no">Hiển thị tự động</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_val_line_1">
      <source>Line 1</source>
      <translation variants="no">Số máy 1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_verify_new_password">
      <source>Verify new password</source>
      <translation variants="no">Xác minh mật khẩu mới:</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_lost_select_network">
      <source>Network lost. Select network?</source>
      <translation variants="no">Mất mạng. Tìm kiếm các mạng có sẵn?</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_voice">
      <source>Voice</source>
      <translation variants="no">Hộp thư thoại</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_mbx">
      <source>Call mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hộp thư cuộc gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_val_line_2">
      <source>Line 2</source>
      <translation variants="no">Số máy 2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_busy">
      <source>If busy</source>
      <translation variants="no">Khi máy bận</translation>
    </message>
    <message numerus="no" id="txt_phone_list_incoming_calls">
      <source>Incoming calls</source>
      <translation variants="no">Cuộc gọi đến</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_check_status">
      <source>Check status</source>
      <translation variants="no">Kiểm tra trạng thái</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_voice_line_2">
      <source>Voice line 2</source>
      <translation variants="no">Số máy thoại 2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_call">
      <source>Image in video call</source>
      <translation variants="no">Hình ảnh trong c.gọi video</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service_val_voice_divert">
      <source>Voice divert</source>
      <translation variants="no">Chuyển hướng c.gọi thoại</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting">
      <source>Internet call waiting</source>
      <translation variants="no">Cuộc gọi internet chờ</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_soft_reject_val_default_text">
      <source>Hi, I’m busy at the moment, but I contact you a bit later.</source>
      <translation variants="no">Rất tiếc, hiện giờ tôi đang bận. Tôi sẽ gọi cho bạn sau.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_result_unknown">
      <source>Result unknown</source>
      <translation variants="no">Kết quả không biết</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_rejected">
      <source>Request rejected</source>
      <translation variants="no">Yêu cầu bị từ chối</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_not_confirmed">
      <source>Request not confirmed</source>
      <translation variants="no">Yêu cầu chưa được xác nhận</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_not_completed">
      <source>Request not completed</source>
      <translation variants="no">Yêu cầu chưa được hoàn tất</translation>
    </message>
    <message numerus="no" id="txt_phone_info_password_changed">
      <source>Password changed</source>
      <translation variants="no">Đã đổi mật khẩu</translation>
    </message>
    <message numerus="no" id="txt_phone_info_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">Không được phép</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conflict_error">
      <source>Conflict error</source>
      <translation variants="no">Lỗi xung đột</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_password_blocked">
      <source>Barring password blocked</source>
      <translation variants="no">Đã khóa mật khẩu chặn cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_operation_not_successful">
      <source>Barring operation not successful. Contact your service provider</source>
      <translation variants="no">Thao tác chặn không thành công. Liên hệ với nhà cung cấp dịch vụ của bạn.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_available_in_current_lo">
      <source>Not specified</source>
      <translation variants="no">Dịch vụ không có sẵn ở vị trí hiện tại</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_calls">
      <source>Video calls</source>
      <translation variants="no">Cuộc gọi video</translation>
    </message>
    <message numerus="no" id="txt_phone_info_to_numbernl1">
      <source>To number:\n%L1</source>
      <translation variants="no">Đến số:
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_fax">
      <source>Fax</source>
      <translation variants="no">Fax</translation>
    </message>
    <message numerus="no" id="txt_phone_title_active_for">
      <source>Active for</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dùng cho:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_voice_calls">
      <source>Voice calls</source>
      <translation variants="no">Cuộc gọi thoại</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_divert_not_active">
      <source>Divert not active</source>
      <translation variants="no">Chuyển hướng không hoạt động</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking_val_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking_val_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_show_call_duration_val_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_show_call_duration_val_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">Số điện thoại không hợp lệ</translation>
    </message>
    <message numerus="no" id="txt_phone_info_diverts_deactivated">
      <source>Diverts deactivated</source>
      <translation variants="no">Đã tắt chuyển hướng</translation>
    </message>
    <message numerus="no" id="txt_phone_info_diverts_activated">
      <source>Diverts activated</source>
      <translation variants="no">Đã kích hoạt chuyển hướng</translation>
    </message>
    <message numerus="no" id="txt_phone_info_divert_deactivated">
      <source>Divert deactivated</source>
      <translation variants="no">Đã tắt chuyển hướng</translation>
    </message>
    <message numerus="no" id="txt_phone_info_divert_activated">
      <source>Divert activated</source>
      <translation variants="no">Đã kích hoạt chuyển hướng</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_deactivated">
      <source>Barring deactivated</source>
      <translation variants="no">Đã tắt chặn cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_activated">
      <source>Barring activated</source>
      <translation variants="no">Đã kích hoạt chặn cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting_val_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting_val_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_waiting_deactivated">
      <source>Call waiting deactivated</source>
      <translation variants="no">Đã tắt cuộc gọi chờ</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_waiting_activated">
      <source>Call waiting activated</source>
      <translation variants="no">Đã kích hoạt cuộc gọi chờ</translation>
    </message>
    <message numerus="yes" id="txt_phone_info_delay_timenln_seconds">
      <source>Delay time:\n%Ln seconds</source>
      <translation>
        <numerusform plurality="a">Thời gian chậm trễ:
%Ln giây</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_no">
      <source>No</source>
      <translation variants="no">Không</translation>
    </message>
  </context>
</TS>