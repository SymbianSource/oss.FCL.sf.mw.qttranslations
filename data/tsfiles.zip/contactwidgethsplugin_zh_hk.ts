<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_long_caption_friend">
      <source>Contacts</source>
      <translation variants="no">通訊錄</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_title_select_contact">
      <source>Select contact:</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇聯絡人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_friend_widget_info_you_can_not_use_this_widge">
      <source>You can not use this  widget, because your phonebook is empty. Open Phonebook to add contacts?</source>
      <translation variants="no">無法使用通訊錄Widget，因為通訊錄應用程式中沒有聯絡人。是否開啟通訊錄應用程式？</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget_val_quickly">
      <source>Home screen contacts widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">從首頁畫面快速聯絡朋友</lengthvariant>
        <lengthvariant priority="2">zh_hk #Contact friends quickly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_friend_widget_contact_unnamed">
      <source>Unnamed</source>
      <translation variants="no">(未命名)</translation>
    </message>
  </context>
</TS>