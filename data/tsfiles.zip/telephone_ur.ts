<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_other_call_ln">
      <source>Call %L1</source>
      <translation variants="no">ur #Call %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_button_drop">
      <source>Drop</source>
      <translation variants="no">ur #Drop</translation>
    </message>
    <message numerus="no" id="txt_phone_other_attempting">
      <source>Attempting</source>
      <translation variants="no">ur #Attempting</translation>
    </message>
    <message numerus="no" id="txt_phone_other_on_hold">
      <source>On hold</source>
      <translation variants="no">ur #On hold</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_call">
      <source>Incoming call</source>
      <translation variants="no">ur #Incoming call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_swap">
      <source>Swap</source>
      <translation variants="no">ur #Swap</translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling">
      <source>Calling</source>
      <translation variants="no">ur #Calling</translation>
    </message>
    <message numerus="no" id="txt_phone_other_waiting">
      <source>Waiting</source>
      <translation variants="no">ur #Waiting</translation>
    </message>
    <message numerus="no" id="txt_phone_other_swipe_down_to_answer">
      <source>Swipe down to answer</source>
      <translation variants="no">ur #Swipe down to answer</translation>
    </message>
    <message numerus="no" id="txt_long_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_phone_button_replace_active_call">
      <source>Replace active call</source>
      <translation variants="no">ur #Replace active call</translation>
    </message>
    <message numerus="no" id="txt_phone_other_private_number">
      <source>Private number</source>
      <translation variants="no">ur #Private number</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_transfer">
      <source>Transfer</source>
      <translation variants="no">منتقل کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_title_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹیلی فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_opt_share_video">
      <source>Share video</source>
      <translation variants="no">ویڈیو میں شرکت</translation>
    </message>
    <message numerus="no" id="txt_phone_other_conference_call">
      <source>Conference call</source>
      <translation variants="no">ur #Conference call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_end_call">
      <source>End call</source>
      <translation variants="no">ur #End call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_hold">
      <source>Hold</source>
      <translation variants="no">ur #Hold</translation>
    </message>
    <message numerus="no" id="txt_phone_button_send_message">
      <source>Send message</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیغام بھیجیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_button_join">
      <source>Join</source>
      <translation variants="no">ur #Join</translation>
    </message>
    <message numerus="no" id="txt_phone_other_disconnected">
      <source>Disconnected</source>
      <translation variants="no">ur #Disconnected</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_ended">
      <source>Call ended</source>
      <translation variants="no">کال منقطع ہوگئی</translation>
    </message>
    <message numerus="no" id="txt_phone_info_called_number_has_barred_incoming">
      <source>Called number has barred incoming calls</source>
      <translation variants="no">ویڈیو کال کرنے سے قاصر۔ دوسرے فون پر درآمدی کالوں پر بندش۔</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_use">
      <source>Number not in use</source>
      <translation variants="no">نمبر استعمال میں نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_own_number_sending">
      <source>Check own number sending</source>
      <translation variants="no">میری کال کنندہ شناخت کی ارسالگی کی جانچ کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_terminated">
      <source>Call Terminated</source>
      <translation variants="no">کال خلاصہ</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_answer">
      <source>No answer</source>
      <translation variants="no">کوئی جواب نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_other_call">
      <source>Call</source>
      <translation variants="no">ur #Call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_send_string">
      <source>Send string:\n%L1</source>
      <translation variants="no">DTMF بھیجیں: %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_barred_in_closed_group">
      <source>Call barred in closed group</source>
      <translation variants="no">قریبی صارف گروہ میں کال پر بندش</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending_file_to_1">
      <source>Sending file to %L1</source>
      <translation variants="no">%L1 کو پیغام بھیج رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_barrings">
      <source>Note: you have active barrings</source>
      <translation variants="no">نوٹ: فعال کال پر بندشیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">صرف ہنگامی کالیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_busy">
      <source>Network busy</source>
      <translation variants="no">نیٹ ورک مصروف</translation>
    </message>
    <message numerus="no" id="txt_phone_info_unable_to_make_video_call_not_supp">
      <source>Unable to make video call. Not supported by other phone or network.</source>
      <translation variants="no">ویڈیو کال کرنے سے قاصر۔ دیگر فون یا نیٹ ورک سے تائید شدہ نہیں۔</translation>
    </message>
    <message numerus="no" id="txt_phone_info_transfer_in_progress">
      <source>Transfer in progress</source>
      <translation variants="no">منتقلی جاری</translation>
    </message>
    <message numerus="no" id="txt_phone_info_could_not_send_own_number">
      <source>Could not send own number</source>
      <translation variants="no">آپ کی کال کنندہ شناخت نہیں بھیج سکا</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_rf_loopback_enabled">
      <source>Bluetooth RF loopback enabled</source>
      <translation variants="no">Bluetooth جانچ وضع</translation>
    </message>
    <message numerus="no" id="txt_phone_info_closed_group_unknown">
      <source>Closed group unknown</source>
      <translation variants="no">قریبی صارف گروپ نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected">
      <source>Connected</source>
      <translation variants="no">متصل کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phone_info_wlan_mac_address_1">
      <source>WLAN MAC address: %L1</source>
      <translation variants="no">WLAN MAC پتہ: %1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_select_closed_group">
      <source>Select closed group</source>
      <translation variants="no">قریبی صارف گروپ منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_time">
      <source>Time</source>
      <translation variants="no">مدت:</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_diverts">
      <source>Note:  you have active diverts</source>
      <translation variants="no">نوٹ: فعال کال منتقلیاں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_not_allowed_during_resto">
      <source>Video call not allowed during restore</source>
      <translation variants="no">عمل کی بحالی کے دوران ویڈیو کال کرنے سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_network_services">
      <source>Check network services</source>
      <translation variants="no">نیٹ ورک خدمات کی جانچ کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_transferred">
      <source>Transferred</source>
      <translation variants="no">منتقل کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending">
      <source>Sending\n%L1</source>
      <translation variants="no">بھیج رہا ہے 
kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk</translation>
    </message>
    <message numerus="no" id="txt_phone_other_remote_sim">
      <source>Remote SIM</source>
      <translation variants="no">ur #Remote SIM</translation>
    </message>
    <message numerus="no" id="txt_phone_info_videocall_only_possible_under_3g">
      <source>Videocall only possible under 3G coverage</source>
      <translation variants="no">۳G نیٹ ورک سے باہر ویڈیو کالیں تائید شدہ نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">غیر کارآمد فون نمبر</translation>
    </message>
    <message numerus="no" id="txt_phone_info_life_timer">
      <source>Life timer\n%L1</source>
      <translation variants="no">لائف ٹائمر:
kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk</translation>
    </message>
    <message numerus="no" id="txt_phone_info_serial_no">
      <source>Serial No.\n%L1</source>
      <translation variants="no">سلسلہ نمبر:
kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_rejected">
      <source>Call rejected</source>
      <translation variants="no">کال مسترد کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phone_info_closed_group_1_in_use">
      <source>Closed group %L1 in use</source>
      <translation variants="no">قریبی صارف گروپ %L1 زیر استعمال</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_number_stored_in_location_1">
      <source>No number stored in location %L1</source>
      <translation variants="no">SIM مقام %L1 پر کوئی نمبر حفظ نہیں کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_not_allowed_fixed_dialling">
      <source>Call not allowed, fixed dialling active</source>
      <translation variants="no">کال کی اجازت نہیں۔ مقررہ ڈائلنگ فعال۔</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_closed_user_group">
      <source>Check closed user group</source>
      <translation variants="no">قریبی صارف گروپ کی جانچ کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_in_progress">
      <source>Call in progress</source>
      <translation variants="no">کال جاری ہے</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_call_failed">
      <source>Emergency call failed</source>
      <translation variants="no">ہنگامی کال ناکام</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected_to_1">
      <source>Connected to %L1</source>
      <translation variants="no">%L1 سے متصل کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_didnt_succeed_to_called">
      <source>Video call didn't succeed to called end</source>
      <translation variants="no">ویڈیو کال کرنے سے قاصر۔ دوسرے فون یا نیٹ ورک سے تائید شدہ نہیں۔</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conference_call_active">
      <source>Conference call active</source>
      <translation variants="no">کانفرنس کال فعال</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_network_support_for_video_call">
      <source>No network support for video call</source>
      <translation variants="no">ویڈیو کال نیٹ ورک سے تائید شدہ نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_no_network_coverage">
      <source>No network coverage</source>
      <translation variants="no">ur #No network coverage</translation>
    </message>
    <message numerus="no" id="txt_phone_button_silence">
      <source>Silence</source>
      <translation variants="no">ur #Silence</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_end_all_calls">
      <source>End all calls</source>
      <translation variants="no">تمام کالیں ختم کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_title_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">آف لائن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_switched_off_or_out_of_3g">
      <source>Phone switched off or out of 3G coverage</source>
      <translation variants="no">ویڈیو کال کرنے سے قاصر۔ دوسرا فون بند ہے یا ۳G نیٹ ورک سے باہر ہے۔</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_rf_loopback_disabled">
      <source>Bluetooth RF loopback disabled</source>
      <translation variants="no">Bluetooth جانچ وضع</translation>
    </message>
    <message numerus="no" id="txt_phone_info_error_in_connection">
      <source>Error in connection</source>
      <translation variants="no">اتصال کی غلطی</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_busy">
      <source>Number busy</source>
      <translation variants="no">نمبر مصروف</translation>
    </message>
    <message numerus="no" id="txt_short_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">ur #Telephone</translation>
    </message>
    <message numerus="no" id="txt_phone_info_end_gprs_connection_first">
      <source>End GPRS connection first</source>
      <translation variants="no">پہلے پیکٹ ڈیٹا اتصال بند کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_other_emergency_call">
      <source>Emergency call</source>
      <translation variants="no">ur #Emergency call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_setup_failed">
      <source>Video call setup failed</source>
      <translation variants="no">ویڈیو کال کرنے سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_barred">
      <source>Number barred</source>
      <translation variants="no">نمبر پر بندش</translation>
    </message>
    <message numerus="no" id="txt_phone_button_private">
      <source>Private</source>
      <translation variants="no">ur #Private</translation>
    </message>
    <message numerus="no" id="txt_phone_button_unlock">
      <source>Unlock</source>
      <translation variants="no">ur #Unlock</translation>
    </message>
    <message numerus="no" id="txt_phone_button_unhold">
      <source>Unhold</source>
      <translation variants="no">ur #Unhold</translation>
    </message>
    <message numerus="no" id="txt_phone_other_diverted_call">
      <source>Diverted call</source>
      <translation variants="no">ur #Diverted call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_closed_group">
      <source>Number not in closed group</source>
      <translation variants="no">نمبر قریبی صارف گروپ میں نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_possible_in_this_group">
      <source>Service not possible in this group</source>
      <translation variants="no">اس گروپ میں خدمت ممکن نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_all_incoming_calls_diver">
      <source>Note:  all incoming calls diverted</source>
      <translation variants="no">نوٹ: تمام درآمدی کالیں منتقل کی گئیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_tty_call_active_volume_control_not">
      <source>TTY call active. Volume control not available</source>
      <translation variants="no">متنی فون استعمال کرتے ہوئے والیوم کنٹرول دستیاب نہیں</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_device_address_1">
      <source>Bluetooth device address: %L1</source>
      <translation variants="no">Bluetooth آلے کا پتہ: %1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_activate_own_number_sending">
      <source>Activate own number sending</source>
      <translation variants="no">کال کنندہ شناخت کی ارسالگی فعال کریں</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">ur #Not allowed</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_diverting">
      <source>Diverting</source>
      <translation variants="no">منتقلی جاری</translation>
    </message>
  </context>
</TS>