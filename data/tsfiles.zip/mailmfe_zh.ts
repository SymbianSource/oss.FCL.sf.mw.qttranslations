<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailmfe_list_version_l1">
      <source>Version: %[]1</source>
      <translation variants="no">zh #Version: %[512]1</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_calendar">
      <source>Calendar</source>
      <translation variants="no">日历</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_1_month_back">
      <source>1 month back</source>
      <translation variants="no">1个月</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_username">
      <source>Username</source>
      <translation variants="no">用户名</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_my_name">
      <source>My name</source>
      <translation variants="no">我的名称</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_password">
      <source>Password</source>
      <translation variants="no">密码</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_3_days_back">
      <source>3 days back</source>
      <translation variants="no">3天</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_show_mail_in_other_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">在其他文件夹中显示电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_1_week_back">
      <source>1 week back</source>
      <translation variants="no">1个星期</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_fri">
      <source>Fri</source>
      <translation variants="no">星期五</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_as_defined">
      <source>The mailbox is refreshed as defined by the user</source>
      <translation variants="no">按用户的规定刷新信箱内容</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_every_15_mi">
      <source>The mailbox is refreshed every 15 minutes during daytime</source>
      <translation variants="no">信箱内容在白天每隔15分钟刷新一次</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_secure_connection">
      <source>Secure connection</source>
      <translation variants="no">安全连接</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_tasks">
      <source>Tasks</source>
      <translation variants="no">待办事项</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_only_by_use">
      <source>The mailbox is refreshed only by user request</source>
      <translation variants="no">仅当用户启动刷新时才刷新信箱内容</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_server_info">
      <source>Server info</source>
      <translation variants="no">服务器设置</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_day_end_time">
      <source>Day end time</source>
      <translation variants="no">一天结束时间</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_during_daytime_val_off">
      <source>Off</source>
      <translation variants="no">关</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_receiving_schedule">
      <source>Receiving Schedule</source>
      <translation variants="no">提取日程表</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_preferences">
      <source>Preferences</source>
      <translation variants="no">帐户设置</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_contacts">
      <source>Contacts</source>
      <translation variants="no">联系人</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="no">每隔4小时</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">刷新信箱</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_keep_uptodat">
      <source>Keep up-to-date</source>
      <translation variants="no">保持最新</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_sun">
      <source>Sun</source>
      <translation variants="no">星期日</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_receiving_weekdays">
      <source>Receiving weekdays</source>
      <translation variants="no">提取日</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_every_day">
      <source>Every day</source>
      <translation variants="no">每天</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_user_defined">
      <source>User defined</source>
      <translation variants="no">用户自定义</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_connection">
      <source>Connection</source>
      <translation variants="no">连接</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_3_months_back">
      <source>3 months back</source>
      <translation variants="no">3个月</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_tue">
      <source>Tue</source>
      <translation variants="no">星期二</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_6_months_back">
      <source>6 months back</source>
      <translation variants="no">6个月</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_day_start_time">
      <source>Day start time</source>
      <translation variants="no">一天开始时间</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_button_delete_mailbox">
      <source>Delete mailbox</source>
      <translation variants="no">删除信箱</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_port">
      <source>Port</source>
      <translation variants="no">端口</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_notes">
      <source>Notes</source>
      <translation variants="no">备忘</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_fetch_manually">
      <source>Fetch manually</source>
      <translation variants="no">手动提取电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode">
      <source>Selected mode</source>
      <translation variants="no">使用的刷新选项</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_mailbox_name">
      <source>Mailbox name</source>
      <translation variants="no">信箱名称</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_keep_uptodate">
      <source>Keep up-to-date</source>
      <translation variants="no">保持最新</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">电子邮件地址</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_during_daytime_val_on">
      <source>On</source>
      <translation variants="no">开</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_server">
      <source>Server</source>
      <translation variants="no">服务器</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_received_items">
      <source>Received items</source>
      <translation variants="no">同步条目</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_sat">
      <source>Sat</source>
      <translation variants="no">星期六</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_1_hour">
      <source>Every 1 hour</source>
      <translation variants="no">zh #Every 1 hour</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_mon">
      <source>Mon</source>
      <translation variants="no">星期一</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_user_info">
      <source>User info</source>
      <translation variants="no">用户设置</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_thu">
      <source>Thu</source>
      <translation variants="no">星期四</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_show_mail_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">在收件箱中显示电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mailnmfe_setlabel_signature">
      <source>Signature</source>
      <translation variants="no">zh #Signature</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_domain">
      <source>Domain</source>
      <translation variants="no">域</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_save_energy">
      <source>Save energy</source>
      <translation variants="no">节能</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_mail">
      <source>Mail</source>
      <translation variants="no">电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_uptodate_during_day">
      <source>The mailbox is up-to-date during daytime</source>
      <translation variants="no">白天信箱始终保持最新内容</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="no">每隔15分钟</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_wed">
      <source>Wed</source>
      <translation variants="no">星期三</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_when_i_open_mailbox">
      <source>When I open mailbox</source>
      <translation variants="no">当我打开信箱时</translation>
    </message>
  </context>
</TS>