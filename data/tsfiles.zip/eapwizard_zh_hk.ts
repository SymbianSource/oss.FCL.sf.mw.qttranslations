<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_confirm_password">
      <source>Confirm password:</source>
      <translation variants="no">確認密碼：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_no_certificates_installed_wizard_c">
      <source>No certificates installed. Wizard cannot continue.</source>
      <translation variants="no">尚未安裝證書。無法繼續設定。</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_provisioning_mode_for_eapfast">
      <source>EAP-FAST provisioning mode</source>
      <translation variants="no">EAP-FAST佈建模式：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_realm">
      <source>Realm:</source>
      <translation variants="no">領域：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_new_pac_store_password">
      <source>New PAC store password:</source>
      <translation variants="no">新PAC儲存密碼：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_for_1">
      <source>User name for '%1':</source>
      <translation variants="no">"%[50]1"的用戶名稱：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_generate_automatic">
      <source>Generate automatically</source>
      <translation variants="no">自動產生</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_authority_certificate">
      <source>Select authority certificate:</source>
      <translation variants="no">選擇授權證書：</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_user_certificate">
      <source>Select user certificate:</source>
      <translation variants="no">選擇個人證書：</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_inner_eap">
      <source>Inner EAP</source>
      <translation variants="no">內層EAP：</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_innear_eap_type_for_1">
      <source>Select inner EAP type for '%1':</source>
      <translation variants="no">選擇"%[47]1"的內層EAP類型：</translation>
    </message>
    <message numerus="no" id="txt_occ_info_incorrect_password">
      <source>Incorrect password</source>
      <translation variants="no">密碼不正確</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_select_automatically">
      <source>Select automatically</source>
      <translation variants="no">自動選擇</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_eap_type">
      <source>Select EAP type:</source>
      <translation variants="no">選擇EAP類型：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="no">PAC儲存密碼：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_cipher_su">
      <source>%1 authentication failed. Cipher suite mismatch.</source>
      <translation variants="no">%[60]1認證失敗。加密套件不符。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_auth_failed_user_cert_rej">
      <source>%1 authentication failed. User certificate not accepted.</source>
      <translation variants="no">%[58]1認證失敗。個人證書不被接受。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_server_ce">
      <source>%1 authentication failed. Server certificate has expired.</source>
      <translation variants="no">%[58]1認證失敗。伺服器證書已到期。</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_realm_val_generate_automatic">
      <source>Generate automatically</source>
      <translation variants="no">自動產生</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_auth_failed_user_cert_exp">
      <source>%1 authentication failed. User certificate has expired.</source>
      <translation variants="no">%[59]1認證失敗。個人證書已到期。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_check_sim">
      <source>%1 authentication failed. Check SIM card.</source>
      <translation variants="no">%[61]1認證失敗。請檢查SIM卡。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_reset_pac">
      <source>%1 authentication failed. Reset PAC store.</source>
      <translation variants="no">%[61]1認證失敗。移除PAC儲存。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_could_not">
      <source>%1 authentication failed. Could not verify server certificate.</source>
      <translation variants="no">%[57]1認證失敗。無法確認伺服器證書。</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_provisioning_mode_for_val_unauthent">
      <source>Unauthenticated</source>
      <translation variants="no">未認證</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_outer_eap">
      <source>Outer EAP</source>
      <translation variants="no">外層EAP：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_password">
      <source>Password:</source>
      <translation variants="no">密碼：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed">
      <source>%1 authentication failed</source>
      <translation variants="no">%[68]1認證失敗</translation>
    </message>
  </context>
</TS>