<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_dialer_ui_dblist_call_duration">
      <source>Call duration</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời lượng gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_info_call_event_will_be_removed_from">
      <source>Call event will be removed from the list. Continue?</source>
      <translation variants="no">vi #Call event will be removed from list. Continue?</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_change_call_service_sub_cellul">
      <source>Cellular</source>
      <translation variants="no">Tế bào</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_date_and_time">
      <source>Date and time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày giờ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_change_call_service">
      <source>Change call service</source>
      <translation variants="no">T.đổi dịch vụ cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_dialled">
      <source>Dialled</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số đã gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_title_dialer">
      <source>Dialer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trình quay số</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_menu_call_details">
      <source>Call details</source>
      <translation variants="no">Chi tiết cuộc gọi</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_id">
      <source>Caller ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số gọi đến</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_missed_calls">
      <source>Missed calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi nhỡ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_voip_call">
      <source>VoiP call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi internet</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_recent_calls">
      <source>Recent calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_recent">
      <source>Recent</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_menu_open_contact">
      <source>Open contact</source>
      <translation variants="no">Mở thẻ liên lạc</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_info_all_call_events_will_be_remo">
      <source>All call events will be removed from the list. Continue?</source>
      <translation variants="no">vi #All call events will be removed from list. Continue?</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_dialled">
      <source>Dialled</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_contact_search_off">
      <source>Contact search off</source>
      <translation variants="no">Tắt tìm kiếm số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_subhead_matches">
      <source>Matches</source>
      <translation variants="yes">
        <lengthvariant priority="1">Danh sách phù hợp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_missed">
      <source>Missed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bị nhỡ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction">
      <source>Call direction</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hướng cuộc gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_service">
      <source>Call service</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dịch vụ cuộc gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_call_using">
      <source>Call using</source>
      <translation variants="no">Gọi với</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_contact_search_on">
      <source>Contact search on</source>
      <translation variants="no">Bật tìm kiếm số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_open_contact">
      <source>Open contact</source>
      <translation variants="no">Mở thẻ liên lạc</translation>
    </message>
    <message numerus="no" id="txt_dial_subhead_received_calls">
      <source>Received calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi đã nhận</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_id_val_unknown_number">
      <source>Unknown number</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_call_service_sub_cellular">
      <source>Cellular</source>
      <translation variants="no">Tế bào</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_id_val_privat_number">
      <source>Privat number</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số riêng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">Trình quay số</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_video_call">
      <source>Video call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi video</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_received">
      <source>Received</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đến</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Save as new contact</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">vi ##Dialer</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_line_id_val_line_2">
      <source>%L1, line 2</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1, số máy 2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_outgoing_line_2">
      <source>Change outgoing line 2</source>
      <translation variants="no">Thay đổi số máy gọi đi 2</translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_activated_profile_silent">
      <source>Activated profile: silent</source>
      <translation variants="no">vi #Activated profile: Silent</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_last_call_event">
      <source>Last call event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sự kiện cuộc gọi cuối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_activated_profile_general">
      <source>Activated profile: general</source>
      <translation variants="no">vi #Activated profile: General</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_callee_id">
      <source>Callee ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">ID người nhận</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_outgoing_line_1">
      <source>Change outgoing line 1</source>
      <translation variants="no">Thay đổi số máy gọi đi 1</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_line_id">
      <source>Line ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">ID số máy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_no_saved_number_for_this_contact">
      <source>No saved number for this contact. Call not possible</source>
      <translation variants="no">vi #Unable to call. Phone number missing.</translation>
    </message>
    <message numerus="no" id="txt_dial_title_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thêm vào Danh bạ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type">
      <source>Call type</source>
      <translation variants="yes">
        <lengthvariant priority="1">Loại cuộc gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_dialled_calls">
      <source>Dialled calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số đã gọi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_received">
      <source>Received</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi đã nhận</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_voice_call">
      <source>Voice call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">vi ##Dialer</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_line_id_val_line_1">
      <source>%L1, line 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1, số máy 1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_no_history_of_calls">
      <source>No history of calls</source>
      <translation variants="no">(không có cuộc gọi gần đây)</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_service_val_cellular">
      <source>Cellular</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tế bào</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">Xóa danh sách</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_missed">
      <source>Missed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi nhỡ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_title_delete_event">
      <source>Delete event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa cuộc gọi khỏi danh sách</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Update existing contact</lengthvariant>
        <lengthvariant priority="2">vi #Update existing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_no_matches_found">
      <source>No matches found</source>
      <translation variants="no">(không có kết quả phù hợp)</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_val_dialer_enable_access_to_recent">
      <source>Dialer enable access to recent calls and dialpad</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Make calls and see recent calls</lengthvariant>
        <lengthvariant priority="2">vi #Make and see recent calls</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_title_clear_list">
      <source>Clear list</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa danh sách</lengthvariant>
      </translation>
    </message>
  </context>
</TS>