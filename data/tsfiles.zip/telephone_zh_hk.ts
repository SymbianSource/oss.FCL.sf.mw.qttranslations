<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">不允許</translation>
    </message>
    <message numerus="no" id="txt_phone_dblist_ongoing_call">
      <source>Ongoing call</source>
      <translation variants="no">進行中的通話</translation>
    </message>
    <message numerus="yes" id="txt_phone_dblist_ln_missed_calls">
      <source>%Ln missed calls</source>
      <translation>
        <numerusform plurality="a">%Ln個未接來電</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_attempting">
      <source>Attempting</source>
      <translation variants="yes">
        <lengthvariant priority="1">正在嘗試撥打緊急通話</lengthvariant>
        <lengthvariant priority="2">zh_hk #Attempting emergency cl.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_not_allowed_during_resto">
      <source>Video call not allowed during restore</source>
      <translation variants="no">恢復期間無法撥打視像電話</translation>
    </message>
    <message numerus="no" id="txt_phone_info_life_timer">
      <source>Life timer\n%L1</source>
      <translation variants="no">總通話計時器：
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_call_failed">
      <source>Emergency call failed</source>
      <translation variants="no">緊急通話失敗</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conference_call_active">
      <source>Conference call active</source>
      <translation variants="no">會議通話已啟動</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_all_incoming_calls_diver">
      <source>Note:  all incoming calls diverted</source>
      <translation variants="no">注意：轉接所有來電</translation>
    </message>
    <message numerus="no" id="txt_phone_other_on_hold">
      <source>On hold</source>
      <translation variants="no">保留中</translation>
    </message>
    <message numerus="no" id="txt_phone_info_activate_own_number_sending">
      <source>Activate own number sending</source>
      <translation variants="no">啟動本機號碼傳送</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_call">
      <source>Incoming call</source>
      <translation variants="yes">
        <lengthvariant priority="1">來電</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling">
      <source>Calling</source>
      <translation variants="no">撥號中</translation>
    </message>
    <message numerus="no" id="txt_phone_other_disconnected">
      <source>Disconnected</source>
      <translation variants="no">已結束通話</translation>
    </message>
    <message numerus="no" id="txt_phone_other_waiting">
      <source>Waiting</source>
      <translation variants="no">等候中</translation>
    </message>
    <message numerus="no" id="txt_phone_info_called_number_has_barred_incoming">
      <source>Called number has barred incoming calls</source>
      <translation variants="no">無法撥打視像電話。對方手機限制來電。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_use">
      <source>Number not in use</source>
      <translation variants="no">號碼為空號</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_answer">
      <source>No answer</source>
      <translation variants="no">無人接聽</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">只允許緊急通話</translation>
    </message>
    <message numerus="no" id="txt_phone_other_private_number">
      <source>Private number</source>
      <translation variants="no">私人號碼</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_busy">
      <source>Network busy</source>
      <translation variants="no">網絡繁忙</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_own_number_sending">
      <source>Check own number sending</source>
      <translation variants="no">請檢查我的本機號碼傳送情況</translation>
    </message>
    <message numerus="no" id="txt_phone_info_unable_to_make_video_call_not_supp">
      <source>Unable to make video call. Not supported by other phone or network.</source>
      <translation variants="no">無法撥打視像電話。對方裝置或網絡不支援。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_send_string">
      <source>Send string:\n%L1</source>
      <translation variants="no">傳送DTMF： %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_barrings">
      <source>Note: you have active barrings</source>
      <translation variants="no">注意：已啟動通話限制</translation>
    </message>
    <message numerus="no" id="txt_phone_info_could_not_send_own_number">
      <source>Could not send own number</source>
      <translation variants="no">不能傳送你的本機號碼</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending">
      <source>Sending\n%L1</source>
      <translation variants="no">正在傳送
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_other_remote_sim">
      <source>Remote SIM</source>
      <translation variants="no">遠端SIM卡</translation>
    </message>
    <message numerus="no" id="txt_phone_other_unknown_number">
      <source>Unknown number</source>
      <translation variants="no">未知號碼</translation>
    </message>
    <message numerus="no" id="txt_phone_other_emergency_call">
      <source>Emergency call</source>
      <translation variants="yes">
        <lengthvariant priority="1">緊急通話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_barred">
      <source>Number barred</source>
      <translation variants="no">號碼被限制</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_diverting">
      <source>Diverting</source>
      <translation variants="no">轉接中</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_end_all_calls">
      <source>End all calls</source>
      <translation variants="no">結束所有通話</translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_switched_off_or_out_of_3g">
      <source>Phone switched off or out of 3G coverage</source>
      <translation variants="no">無法撥打視像電話。對方裝置關機或不在3G網絡內。</translation>
    </message>
    <message numerus="no" id="txt_phone_other_conference_call">
      <source>Conference call</source>
      <translation variants="no">會議通話</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_busy">
      <source>Number busy</source>
      <translation variants="no">線路繁忙</translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">電話號碼無效</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_not_allowed_fixed_dialling">
      <source>Call not allowed, fixed dialling active</source>
      <translation variants="no">不允許通話。固定撥號已啟動。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_didnt_succeed_to_called">
      <source>Video call didn't succeed to called end</source>
      <translation variants="no">無法撥打視像電話。對方裝置或網絡不支援。</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_no_network_coverage">
      <source>No network coverage</source>
      <translation variants="no">沒有網絡覆蓋</translation>
    </message>
    <message numerus="no" id="txt_short_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">zh_hk ##Telephone</translation>
    </message>
    <message numerus="no" id="txt_long_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">電話</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_transfer">
      <source>Transfer</source>
      <translation variants="no">轉接</translation>
    </message>
    <message numerus="no" id="txt_phone_title_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_network_services">
      <source>Check network services</source>
      <translation variants="no">請檢查網絡服務</translation>
    </message>
    <message numerus="no" id="txt_phone_info_videocall_only_possible_under_3g">
      <source>Videocall only possible under 3G coverage</source>
      <translation variants="no">在3G網絡以外的地區不支援視像電話</translation>
    </message>
    <message numerus="no" id="txt_phone_info_serial_no">
      <source>Serial No.\n%L1</source>
      <translation variants="no">序號：
%1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected_to_1">
      <source>Connected to %L1</source>
      <translation variants="no">已連接至%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_error_in_connection">
      <source>Error in connection</source>
      <translation variants="no">連接錯誤</translation>
    </message>
  </context>
</TS>