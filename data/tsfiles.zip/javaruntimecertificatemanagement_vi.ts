<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_secur_info_cert_deleting">
      <source>Deleting a certificate may prevent you from installing or running some applications. Continue?</source>
      <translation variants="no">vi #Deleting a certificate may prevent you from installing or running some applications. Continue?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_prompt_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Có</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_prompt_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cert_disabling">
      <source>Disabling a certificate may prevent you from installing or running some applications. Continue?</source>
      <translation variants="no">vi #Disabling a certificate may prevent you from installing or running some applications. Continue?</translation>
    </message>
    <message numerus="no" id="txt_java_secur_title_cert_disabling">
      <source>Certificate management </source>
      <translation variants="yes">
        <lengthvariant priority="1">Quản lý chứng chỉ</lengthvariant>
      </translation>
    </message>
  </context>
</TS>