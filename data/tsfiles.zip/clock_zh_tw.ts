<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy">
      <source>Not specified</source>
      <translation variants="no">日月年</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_weekly">
      <source>Not specified</source>
      <translation variants="no">每週</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_wednesday">
      <source>Not specified</source>
      <translation variants="no">星期三</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_thursday">
      <source>Not specified</source>
      <translation variants="no">星期四</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_val_alarm">
      <source>Not specified</source>
      <translation variants="no">鬧鈴</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour">
      <source>Not specified</source>
      <translation variants="no">24小時制</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_menu_delete_alarm">
      <source>Delete alarm</source>
      <translation variants="no">取消鬧鈴</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_once">
      <source>Not specified</source>
      <translation variants="no">不重複</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_friday">
      <source>Not specified</source>
      <translation variants="no">星期五</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_saturday">
      <source>Not specified</source>
      <translation variants="no">星期六</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_settings">
      <source>Settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy">
      <source>Not specified</source>
      <translation variants="no">月日年</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_tuesday">
      <source>Not specified</source>
      <translation variants="no">星期二</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_monday">
      <source>Not specified</source>
      <translation variants="no">星期一</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd">
      <source>Not specified</source>
      <translation variants="no">年月日</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_workdays">
      <source>Workdays</source>
      <translation variants="no">zh_tw ##Workdays</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_world_clock">
      <source>World Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">世界時鐘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date">
      <source>Not specified</source>
      <translation variants="no">日期與時間</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_gmt_1">
      <source>GMT %1</source>
      <translation variants="no">zh_tw ##GMT %1</translation>
    </message>
    <message numerus="no" id="txt_short_caption_clock">
      <source>Clock</source>
      <translation variants="no">時鐘</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_deactivated">
      <source>Alarm Deactivated</source>
      <translation variants="no">鬧鈴已關閉</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hrs_2_mins">
      <source>%1 hrs %2 mins</source>
      <translation variants="no">zh_tw ##%1 hrs %2 mins</translation>
    </message>
    <message numerus="no" id="txt_long_caption_clk">
      <source>Not specified</source>
      <translation variants="no">時鐘</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_title_control_panel">
      <source>Not specified</source>
      <translation variants="no">控制台</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_info_date_info">
      <source>Not specified</source>
      <translation variants="no">時間，日期</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2mins">
      <source>In %1hrs %2mins</source>
      <translation variants="no">zh_tw ##In %1hrs %2mins</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_activated">
      <source>Alarm Activated</source>
      <translation variants="no">鬧鈴已啟動</translation>
    </message>
    <message numerus="no" id="txt_common_common_clock">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">時鐘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2mins">
      <source>In %1hr %2mins</source>
      <translation variants="no">zh_tw ##In %1hr %2mins</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_no_alarms_set">
      <source>No alarms set</source>
      <translation variants="yes">
        <lengthvariant priority="1">(未設定鬧鈴)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_hr">
      <source>%1 hr</source>
      <translation variants="no">zh_tw ##%1 hr</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2min">
      <source>In %1hr %2min</source>
      <translation variants="no">zh_tw ##In %1hr %2min</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1days">
      <source>In %1days</source>
      <translation variants="no">zh_tw ##In %1days</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_hrs">
      <source>%1 hrs</source>
      <translation variants="no">zh_tw ##%1 hrs</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_set_as_current_location">
      <source>Set as current location</source>
      <translation variants="no">設為目前的位置</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_show_on_homescreen">
      <source>Show on homescreen</source>
      <translation variants="no">在首頁畫面中顯示</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour">
      <source>Not specified</source>
      <translation variants="no">12小時制</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily">
      <source>Daily</source>
      <translation variants="no">zh_tw ##Daily</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_daily">
      <source>Not specified</source>
      <translation variants="no">每日</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_on_workdays">
      <source>Not specified</source>
      <translation variants="no">工作日</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_sunday">
      <source>Not specified</source>
      <translation variants="no">星期日</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2min">
      <source>In %1hrs %2min</source>
      <translation variants="no">zh_tw ##In %1hrs %2min</translation>
    </message>
    <message numerus="no" id="txt_long_caption_clock">
      <source>Clock</source>
      <translation variants="no">時鐘</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_delete">
      <source>Delete</source>
      <translation variants="no">刪除</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_subtitle_device">
      <source>Not specified</source>
      <translation variants="no">手機</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hr_2_mins">
      <source>%1 hr %2 mins</source>
      <translation variants="no">zh_tw ##%1 hr %2 mins</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_mins">
      <source>%1 mins</source>
      <translation variants="no">zh_tw ##%1 mins</translation>
    </message>
    <message numerus="no" id="txt_common_common_gmt">
      <source>GMT</source>
      <translation variants="no">zh_tw ##GMT</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_every_1">
      <source>Every %1</source>
      <translation variants="no">zh_tw ##Every %1</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_today">
      <source>Today</source>
      <translation variants="no">zh_tw ##Today</translation>
    </message>
  </context>
</TS>