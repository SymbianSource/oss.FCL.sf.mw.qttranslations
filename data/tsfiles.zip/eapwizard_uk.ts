<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dialog_no_certificates_installed_wizard_c">
      <source>No certificates installed. Wizard cannot continue.</source>
      <translation variants="no">uk ##No certificates installed. Wizard cannot continue.</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_confirm_password">
      <source>Confirm password:</source>
      <translation variants="no">uk ##Confirm password:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_select_automatically">
      <source>Select automatically</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Select automatically</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_eap_type">
      <source>Select EAP type:</source>
      <translation variants="no">uk ##Select EAP type:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_realm_val_generate_automatically">
      <source>Generate automatically</source>
      <translation variants="no">uk ##Generate automatically</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_for_1">
      <source>User name for '%1':</source>
      <translation variants="no">uk ##User name for '%1':</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_generate_automatic">
      <source>Generate automatically</source>
      <translation variants="no">uk ##Generate automatically</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_new_pac_store_password">
      <source>New PAC store password:</source>
      <translation variants="no">uk ##New PAC store password:</translation>
    </message>
    <message numerus="no" id="txt_occ_title_eap_identity_for_1">
      <source>EAP identity for '%1':</source>
      <translation variants="no">uk ##EAP identity for '%1':</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_authority_certificate">
      <source>Select authority certificate:</source>
      <translation variants="no">uk ##Select authority certificate:</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_user_certificate">
      <source>Select user certificate:</source>
      <translation variants="no">uk ##Select user certificate:</translation>
    </message>
    <message numerus="no" id="txt_occ_info_incorrect_password">
      <source>Incorrect password</source>
      <translation variants="no">uk ##Incorrect password</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_inner_eap">
      <source>Inner EAP</source>
      <translation variants="no">uk ##Inner EAP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_user_name">
      <source>User name:</source>
      <translation variants="no">uk ##User name:</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_provisioning_mode_for_val_unauthent">
      <source>Unauthenticated</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Unauthenticated</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_outer_eap">
      <source>Outer EAP</source>
      <translation variants="no">uk ##Outer EAP</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_provisioning_mode_for_eapfast">
      <source>EAP-FAST provisioning mode</source>
      <translation variants="no">uk ##EAP-FAST provisioning mode</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="no">uk ##PAC store password:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_realm">
      <source>Realm:</source>
      <translation variants="no">uk ##Realm:</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_innear_eap_type_for_1">
      <source>Select innear EAP type for '%1':</source>
      <translation variants="no">uk ##Select innear EAP type for '%1':</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_password">
      <source>Password:</source>
      <translation variants="no">uk ##Password:</translation>
    </message>
  </context>
</TS>