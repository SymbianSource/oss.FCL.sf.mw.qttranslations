<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_grid_connected_to_1">
      <source>Connected to '%1'</source>
      <translation variants="no">Đã kết nối '%[77]1'</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_not_connected">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chưa được kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_grid_connecting_to_1">
      <source>Connecting to '%1'</source>
      <translation variants="no">Đang kết nối '%[74]1'</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_switch_wlan_on">
      <source>Switch WLAN on</source>
      <translation variants="no">Bật WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_switch_wlan_off">
      <source>Switch WLAN off</source>
      <translation variants="no">Tắt WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_add_new_wlan">
      <source>Add new WLAN</source>
      <translation variants="no">Thêm WLAN mới</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_title_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_wlansniffer">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_wlansniffer">
      <source>Wireless LAN</source>
      <translation variants="no">vi #Wireless LAN</translation>
    </message>
    <message numerus="no" id="txt_occ_info_activate_wlan_in_airplane_mode">
      <source>Allow WLAN connections during this offline session?</source>
      <translation variants="no">Cho phép kết nối WLAN trong khoảng thời gian offline này?</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_wlan_is_switched_off">
      <source>WLAN is switched off</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN đã tắt</lengthvariant>
      </translation>
    </message>
  </context>
</TS>