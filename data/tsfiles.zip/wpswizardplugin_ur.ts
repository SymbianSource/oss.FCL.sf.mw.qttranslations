<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dialog_first_press_button_on_the_wireless">
      <source>First, press button on the wireless station to initiate the setup process, then select 'Next'.</source>
      <translation variants="no">ur #First, press button on the wireless station to initiate the setup process, then select 'Next'.</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_settings_received_for_multiple_wlan">
      <source>Settings received for multiple WLAN networks. Select the network to use:</source>
      <translation variants="no">ur #Settings received for multiple WLAN networks. Select the network to use:</translation>
    </message>
    <message numerus="no" id="txt_occ_list_use_pin_code">
      <source>Use PIN code</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Use PIN code</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_list_configure_manually">
      <source>Configure manually</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Configure manually</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_list_use_pushbutton">
      <source>Use push-button</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Use push-button</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_enter_1_on_the_wireless_station_t">
      <source>Enter '%1' on the wireless station then select 'Next'.</source>
      <translation variants="no">ur #Enter '%1' on the wireless station then select 'Next'.</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_selected_network_supports_wifi_pro">
      <source>Selected network supports Wi-Fi Protected Setup™ for receiving settings automatically.</source>
      <translation variants="no">ur #Selected network supports Wi-Fi Protected Setup™ for receiving settings automatically.</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_negotiating">
      <source>Negotiating</source>
      <translation variants="no">ur #Negotiating</translation>
    </message>
  </context>
</TS>