<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="tr">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_opt_show">
      <source>Show…</source>
      <translation variants="no">Göster</translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">tr #Disconnect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>No paired devices</source>
      <translation variants="no">Eşlenmiş cihaz yok</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">Tüm cihazlar</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Paired</source>
      <translation variants="yes">
        <lengthvariant priority="1">Eşlenmiş</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Input device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giriş cihazı</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>International US</source>
      <translation variants="no">US-International</translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Computer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bilgisayar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">Diğer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kapalı</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">Engelli</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bağlantı</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bağlandı (görünür)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">SIM erişim tercihi</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Enabled</source>
      <translation variants="no">Etkin</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bağlandı (gizli)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Paired, trusted</source>
      <translation variants="yes">
        <lengthvariant priority="1">Eşlenmiş, günenilir</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Dutch</source>
      <translation variants="no">Felemenkçe</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_pair">
      <source>Pair</source>
      <translation variants="no">tr #Pair</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Visible for %Ln min</source>
      <translation>
        <numerusform plurality="a">tr #Visible for %Ln minute</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices_of_selected_type">
      <source>No found devices of selected type</source>
      <translation variants="no">tr #No found devices of selected type</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>No found devices</source>
      <translation variants="no">Bulunan cihaz yok</translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Connect</source>
      <translation variants="yes">
        <lengthvariant priority="1">tr #Connect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>%1 details</source>
      <translation variants="no">%[19]1 bilgi</translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>%1 connected</source>
      <translation variants="no">%[17]1 bağlandı</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Belgian</source>
      <translation variants="no">Belçika Fransızcası</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Always ask</source>
      <translation variants="yes">
        <lengthvariant priority="1">Her zaman sor</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Norwegian</source>
      <translation variants="no">Norveççe</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Keyboard layout</source>
      <translation variants="no">Klavye düzeni</translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">Engelli</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Spanish</source>
      <translation variants="no">İspanyolca</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Bluetooth - Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth- Gelişmiş ayarlar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bağlandı</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Blocked devices</source>
      <translation variants="no">Engelli cihazalar</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Connect</source>
      <translation variants="no">Bağlan</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Device details</source>
      <translation variants="no">tr #Device details</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Telefon</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect_audio">
      <source>Disconnect audio</source>
      <translation variants="no">tr #Disconnect audio</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Hidden</source>
      <translation variants="no">tr #Hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Bluetooth - Found devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">tr #Bluetooth devices found</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_device">
      <source>Bluetooth device</source>
      <translation variants="yes">
        <lengthvariant priority="1">tr #Bluetooth device</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices_of_selected_type">
      <source>No devices of selected type</source>
      <translation variants="no">tr #No devices of selected type</translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Unpair</source>
      <translation variants="yes">
        <lengthvariant priority="1">tr #Remove pairing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Pair</source>
      <translation variants="yes">
        <lengthvariant priority="1">tr #Pair</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>No devices</source>
      <translation variants="no">Cihaz yok</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Paired, trusted, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Eşlenmiş, güvenilir, bağlandı</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Bluetooth - All devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Tüm cihazlar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Danish</source>
      <translation variants="no">Danca</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Kapalı</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Açık (gizli)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>UK</source>
      <translation variants="no">Birleşik Krallık</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>US Dvorak</source>
      <translation variants="no">ABD Dvorak</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>French</source>
      <translation variants="no">Fransızca</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Remove</source>
      <translation variants="no">Kaldır</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Russian</source>
      <translation variants="no">Rusça</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Açık (görünür)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Bluetooth - Paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth -Eşlenmiş cihazlar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Gelişmiş ayarlar</translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Audio device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ses cihazı</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect_audio">
      <source>Connect audio</source>
      <translation variants="no">tr #Connect audio</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_unpair">
      <source>Unpair</source>
      <translation variants="no">tr #Unpair</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Searching…</source>
      <translation variants="yes">
        <lengthvariant priority="1">tr #Searching</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices_of_selected_type">
      <source>No paired devices of selected type</source>
      <translation variants="no">tr #No paired devices of selected type</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Change visibility time</source>
      <translation variants="no">Görünürlük zamanını değiştir</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Italian</source>
      <translation variants="no">İtalyanca</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Otomatik</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Paired, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Eşlenmiş, bağlandı</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Paired devices</source>
      <translation variants="no">Eşlenmiş cihazlar</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Finnish/Swedish</source>
      <translation variants="no">Fince, İsveççe</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Portuguese</source>
      <translation variants="no">Portekizce</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Keyboard settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Klavye ayarları</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>German</source>
      <translation variants="no">Almanca</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Mouse settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Fare ayarları</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>US</source>
      <translation variants="no">ABD İngilizce</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Remove paired devices</source>
      <translation variants="no">Eşlenmiş cihazları kaldır</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Bağlantıyı kes</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Visible</source>
      <translation variants="no">tr #Shown to all</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Search done</source>
      <translation variants="yes">
        <lengthvariant priority="1">tr #Search completed</lengthvariant>
      </translation>
    </message>
  </context>
</TS>