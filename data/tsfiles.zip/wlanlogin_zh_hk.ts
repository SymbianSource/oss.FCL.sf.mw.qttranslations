<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_caption_wlan_login">
      <source>WLAN login</source>
      <translation variants="no">WLAN登入</translation>
    </message>
    <message numerus="no" id="txt_occ_info_wlan_connection_closed_login_applica">
      <source>WLAN connection closed. Login application will be closed.</source>
      <translation variants="no">WLAN連接已關閉。登入應用程式將會關閉。</translation>
    </message>
  </context>
</TS>