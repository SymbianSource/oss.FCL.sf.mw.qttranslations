<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Start date</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Start date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Daily</source>
      <translation variants="no">ur #Daily</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">ur #Discard changes</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Delete repeated entry :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Location</source>
      <translation variants="no">ur #Location</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_2_days_before">
      <source>2 days before</source>
      <translation variants="no">ur #2 days before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_15_minutes_befo">
      <source>15 minutes before</source>
      <translation variants="no">ur #15 minutes before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Monthly</source>
      <translation variants="no">ur #Monthly</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_time">
      <source>%1</source>
      <translation variants="no">ur #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Alarm date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Delete anniversary?</source>
      <translation variants="no">ur #Delete anniversary?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_meeting_updated">
      <source>Meeting updated</source>
      <translation variants="no">ur #Meeting updated</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_anniversary">
      <source>New anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #New anniversary</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_anniversary_saved">
      <source>New anniversary saved</source>
      <translation variants="no">ur #New anniversary saved</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_off">
      <source>Off</source>
      <translation variants="no">ur #Off</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_anniversary">
      <source>Anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Anniversary</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_date">
      <source>Date</source>
      <translation variants="no">ur #Date</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_fortnightly">
      <source>Fortnightly</source>
      <translation variants="no">ur #Fortnightly</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_day_before">
      <source>1 day before</source>
      <translation variants="no">ur #1 day before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_time">
      <source>Reminder time</source>
      <translation variants="no">ur #Reminder time</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Start time</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Start time</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Only once</source>
      <translation variants="no">ur #Only once</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_description">
      <source>Description</source>
      <translation variants="no">ur #Description</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>All day event</source>
      <translation variants="no">ur #All day event</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_end_time">
      <source>End time</source>
      <translation variants="no">ur #End time</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Alarm time</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Reminder</source>
      <translation variants="no">ur #Reminder</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entry">
      <source>Delete entry?</source>
      <translation variants="no">ur #Delete entry?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_off">
      <source>Off</source>
      <translation variants="no">ur #Off</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_hours">
      <source>Before %Ln hours</source>
      <translation variants="no">ur #Before %Ln hours</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_date">
      <source>%2</source>
      <translation variants="no">ur #%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="no">ur #Alarm date and time</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_on_alarm">
      <source>Alarm</source>
      <translation variants="no">ur #Alarm</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_start_time">
      <source>Start time</source>
      <translation variants="no">ur #Start time</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_on_event_day">
      <source>On event day</source>
      <translation variants="no">ur #On event day</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">ur #Remove description</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Meeting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>End date</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #End date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_occasion">
      <source>Occasion</source>
      <translation variants="no">ur #Occasion</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Weekly</source>
      <translation variants="no">ur #Weekly</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">ur #Alarm</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_hour_before">
      <source>1 hour before</source>
      <translation variants="no">ur #1 hour before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_30_minutes_befo">
      <source>30 minutes before</source>
      <translation variants="no">ur #30 minutes before</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_event">
      <source>New event</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #New event</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Yearly</source>
      <translation variants="no">ur #Yearly</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Repeat</source>
      <translation variants="no">ur #Repeat</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_event">
      <source>Delete event</source>
      <translation variants="no">ur #Delete event</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">ur #Delete meeting?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_meeting_saved">
      <source>New meeting saved</source>
      <translation variants="no">ur #New meeting saved</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">ur #This occurrence only</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">ur #All occurences</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_meeting">
      <source>New meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #New meeting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_at_the_start">
      <source>At the start</source>
      <translation variants="no">ur #At the start</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_5_minutes_befor">
      <source>5 minutes before</source>
      <translation variants="no">ur #5 minutes before</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #To do</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_anniversary_updated">
      <source>Anniversary updated</source>
      <translation variants="no">ur #Anniversary updated</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Edit :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_minutes">
      <source>Before %Ln minutes</source>
      <translation variants="no">ur #Before %Ln minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_weeks">
      <source>Before %Ln weeks</source>
      <translation variants="no">ur #Before %Ln weeks</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_reminder_time">
      <source>%1</source>
      <translation variants="no">ur #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">ur #Subject</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_anniv_default_date">
      <source>%1</source>
      <translation variants="no">ur #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_val_before_ln_days">
      <source>Before %Ln days</source>
      <translation variants="no">ur #Before %Ln days</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">ur #Repeat until</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">ur #Add description</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_workdays">
      <source>Workdays</source>
      <translation variants="no">ur #Workdays</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Delete entries ?</source>
      <translation variants="no">ur #Delete entries ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_repeat_until">
      <source>Repeat until</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Repeat until</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>End time</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #End time</lengthvariant>
      </translation>
    </message>
  </context>
</TS>