<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_common_title_select_tone1">
      <source>Select tone:</source>
      <translation variants="no">選擇鈴聲：</translation>
    </message>
    <message numerus="no" id="txt_common_info_initialising">
      <source>Initialising</source>
      <translation variants="no">啟動中</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_expires">
      <source>Expires:</source>
      <translation variants="no">到期日：</translation>
    </message>
    <message numerus="no" id="txt_common_button_stop_singledialog">
      <source>Stop</source>
      <translation variants="no">停止</translation>
    </message>
    <message numerus="no" id="txt_common_opt_details">
      <source>Details</source>
      <translation variants="no">資料</translation>
    </message>
    <message numerus="no" id="txt_common_opt_disconnect">
      <source>Disconnect</source>
      <translation variants="no">中斷連接</translation>
    </message>
    <message numerus="no" id="txt_common_opt_edit">
      <source>Edit</source>
      <translation variants="no">zh_hk #Edit</translation>
    </message>
    <message numerus="no" id="txt_common_button_show">
      <source>Show</source>
      <translation variants="no">顯示</translation>
    </message>
    <message numerus="no" id="txt_common_info_installing">
      <source>Installing</source>
      <translation variants="no">zh_hk #Installing</translation>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate">
      <source>Deactivate</source>
      <translation variants="no">關閉</translation>
    </message>
    <message numerus="no" id="txt_common_button_continue">
      <source>Continue</source>
      <translation variants="no">繼續</translation>
    </message>
    <message numerus="no" id="txt_common_info_adding">
      <source>Adding</source>
      <translation variants="no">加入中</translation>
    </message>
    <message numerus="no" id="txt_common_button_listen">
      <source>Listen</source>
      <translation variants="no">接聽</translation>
    </message>
    <message numerus="no" id="txt_common_opt_install">
      <source>Install</source>
      <translation variants="no">安裝</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="no">確認密碼：</translation>
    </message>
    <message numerus="no" id="txt_common_opt_voice_call">
      <source>Voice call</source>
      <translation variants="no">語音通話</translation>
    </message>
    <message numerus="no" id="txt_common_title_writing_language">
      <source>Writing language:</source>
      <translation variants="no">書寫語言：</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_first_name">
      <source>First name:</source>
      <translation variants="no">名：</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_title">
      <source>Title:</source>
      <translation variants="no">zh_hk #Title:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_thumbnail">
      <source>Add thumbnail</source>
      <translation variants="no">加入縮圖</translation>
    </message>
    <message numerus="no" id="txt_common_opt_insert">
      <source>Insert</source>
      <translation variants="no">插入</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="no">取消</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_web_address">
      <source>Web address:</source>
      <translation variants="no">zh_hk #Web address:</translation>
    </message>
    <message numerus="no" id="txt_common_info_opening">
      <source>Opening</source>
      <translation variants="no">開啟中</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_phone_number">
      <source>Phone number:</source>
      <translation variants="no">zh_hk #Phone number:</translation>
    </message>
    <message numerus="no" id="txt_common_button_add">
      <source>Add</source>
      <translation variants="no">加入</translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="no">是</translation>
    </message>
    <message numerus="no" id="txt_common_info_deleting">
      <source>Deleting</source>
      <translation variants="no">刪除中</translation>
    </message>
    <message numerus="no" id="txt_common_opt_chat">
      <source>Chat</source>
      <translation variants="no">聊天</translation>
    </message>
    <message numerus="no" id="txt_common_menu_format">
      <source>Format</source>
      <translation variants="no">zh_hk #Format</translation>
    </message>
    <message numerus="no" id="txt_common_info_connecting">
      <source>Connecting</source>
      <translation variants="no">連接中</translation>
    </message>
    <message numerus="no" id="txt_common_info_inserting">
      <source>Inserting</source>
      <translation variants="no">插入中</translation>
    </message>
    <message numerus="no" id="txt_common_button_handset">
      <source>Handset</source>
      <translation variants="no">手機</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_member">
      <source>Add member</source>
      <translation variants="no">加入成員</translation>
    </message>
    <message numerus="no" id="txt_common_button_hide_single_dialog">
      <source>Hide</source>
      <translation variants="no">隱藏</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">zh_hk #Add detail</translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_language">
      <source>Select language:</source>
      <translation variants="no">選擇語言：</translation>
    </message>
    <message numerus="no" id="txt_common_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">zh_hk #Advanced settings</translation>
    </message>
    <message numerus="no" id="txt_common_opt_print">
      <source>Print</source>
      <translation variants="no">zh_hk #Print</translation>
    </message>
    <message numerus="no" id="txt_common_opt_format">
      <source>Format </source>
      <translation variants="no">zh_hk #Format </translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_recipient">
      <source>Add recipient</source>
      <translation variants="no">zh_hk #Add recipient</translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmark_all_items">
      <source>Deselect all items</source>
      <translation variants="no">取消選擇所有項目</translation>
    </message>
    <message numerus="no" id="txt_common_button_collapse">
      <source>Collapse</source>
      <translation variants="no">摺疊</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_address">
      <source>Select address:</source>
      <translation variants="no">選擇地址：</translation>
    </message>
    <message numerus="no" id="txt_common_menu_paste">
      <source>Paste</source>
      <translation variants="no">zh_hk #Paste</translation>
    </message>
    <message numerus="no" id="txt_common_button_expand">
      <source>Expand</source>
      <translation variants="no">展開</translation>
    </message>
    <message numerus="no" id="txt_common_opt_additional_details">
      <source>Additional details</source>
      <translation variants="no">其他資料</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_password">
      <source>Password:</source>
      <translation variants="no">zh_hk #Password:</translation>
    </message>
    <message numerus="no" id="txt_common_button_start">
      <source>Start</source>
      <translation variants="no">開始</translation>
    </message>
    <message numerus="no" id="txt_common_info_registering">
      <source>Registering</source>
      <translation variants="no">zh_hk #Registering</translation>
    </message>
    <message numerus="no" id="txt_common_opt_video_call">
      <source>Video call</source>
      <translation variants="no">zh_hk #Video call</translation>
    </message>
    <message numerus="no" id="txt_common_menu_cut">
      <source>Cut</source>
      <translation variants="no">zh_hk #Cut</translation>
    </message>
    <message numerus="no" id="txt_common_opt_forward">
      <source>Forward</source>
      <translation variants="no">轉發</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_to">
      <source>To:</source>
      <translation variants="no">結束時間：</translation>
    </message>
    <message numerus="no" id="txt_common_opt_pause">
      <source>Pause</source>
      <translation variants="no">zh_hk #Pause</translation>
    </message>
    <message numerus="no" id="txt_common_opt_undo">
      <source>Undo</source>
      <translation variants="no">zh_hk #Undo</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_date">
      <source>Date:</source>
      <translation variants="no">日期：</translation>
    </message>
    <message numerus="no" id="txt_common_info_moving">
      <source>Moving</source>
      <translation variants="no">zh_hk #Moving</translation>
    </message>
    <message numerus="no" id="txt_common_button_reply">
      <source>Reply</source>
      <translation variants="no">回覆</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_password">
      <source>New password:</source>
      <translation variants="no">新密碼：</translation>
    </message>
    <message numerus="no" id="txt_common_opt_exit">
      <source>Exit</source>
      <translation variants="no">退出</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_address">
      <source>Address:</source>
      <translation variants="no">地址：</translation>
    </message>
    <message numerus="no" id="txt_common_opt_go_to_web_address">
      <source>Go to web address</source>
      <translation variants="no">前往網址</translation>
    </message>
    <message numerus="no" id="txt_common_info_searching">
      <source>Searching</source>
      <translation variants="no">尋找中</translation>
    </message>
    <message numerus="no" id="txt_common_opt_remove">
      <source>Remove</source>
      <translation variants="no">zh_hk #Remove</translation>
    </message>
    <message numerus="no" id="txt_common_info_requesting">
      <source>Requesting</source>
      <translation variants="no">zh_hk #Requesting</translation>
    </message>
    <message numerus="no" id="txt_common_info_saving">
      <source>Saving</source>
      <translation variants="no">儲存中</translation>
    </message>
    <message numerus="no" id="txt_common_info_unistalling">
      <source>Uninstalling</source>
      <translation variants="no">解除安裝中</translation>
    </message>
    <message numerus="no" id="txt_common_button_quit">
      <source>Quit</source>
      <translation variants="no">退出</translation>
    </message>
    <message numerus="no" id="txt_common_opt_uninstall">
      <source>Uninstall</source>
      <translation variants="no">解除安裝</translation>
    </message>
    <message numerus="no" id="txt_common_button_help">
      <source>Help</source>
      <translation variants="no">說明</translation>
    </message>
    <message numerus="no" id="txt_common_button_join">
      <source>Join</source>
      <translation variants="no">參加</translation>
    </message>
    <message numerus="no" id="txt_common_info_loading">
      <source>Loading</source>
      <translation variants="no">載入中</translation>
    </message>
    <message numerus="no" id="txt_common_opt_replace">
      <source>Replace</source>
      <translation variants="no">取代</translation>
    </message>
    <message numerus="no" id="txt_common_info_cancelling">
      <source>Cancelling</source>
      <translation variants="no">取消中</translation>
    </message>
    <message numerus="no" id="txt_common_title_details">
      <source>Details:</source>
      <translation variants="no">資料：</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_folder">
      <source>Select folder:</source>
      <translation variants="no">選擇資料夾：</translation>
    </message>
    <message numerus="no" id="txt_common_button_finish_single_dialog">
      <source>Finish</source>
      <translation variants="no">zh_hk #Finish</translation>
    </message>
    <message numerus="no" id="txt_common_button_delete">
      <source>Delete</source>
      <translation variants="no">刪除</translation>
    </message>
    <message numerus="no" id="txt_common_info_closing">
      <source>Closing</source>
      <translation variants="no">zh_hk #Closing</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_time">
      <source>Time:</source>
      <translation variants="no">時間：</translation>
    </message>
    <message numerus="no" id="txt_common_info_copying">
      <source>Copying</source>
      <translation variants="no">複製中</translation>
    </message>
    <message numerus="no" id="txt_common_opt_create_message">
      <source>Create message</source>
      <translation variants="no">建立訊息</translation>
    </message>
    <message numerus="no" id="txt_common_opt_find">
      <source>Find</source>
      <translation variants="no">找尋</translation>
    </message>
    <message numerus="no" id="txt_common_opt_internet_call">
      <source>Internet call</source>
      <translation variants="no">zh_hk #Internet call</translation>
    </message>
    <message numerus="no" id="txt_common_opt_organise">
      <source>Organise</source>
      <translation variants="no">組織</translation>
    </message>
    <message numerus="no" id="txt_common_opt_attachments">
      <source>Attachments</source>
      <translation variants="no">zh_hk #Attachments</translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">zh_hk #Activate loudspeaker</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_folder_name">
      <source>Folder name:</source>
      <translation variants="no">zh_hk #Folder name:</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_end_date">
      <source>End date:</source>
      <translation variants="no">zh_hk #End date:</translation>
    </message>
    <message numerus="no" id="txt_common_info_retrieving">
      <source>Retrieving</source>
      <translation variants="no">zh_hk #Retrieving</translation>
    </message>
    <message numerus="no" id="txt_common_menu_select_all_contents">
      <source>Select all contents</source>
      <translation variants="no">zh_hk #Select all contents</translation>
    </message>
    <message numerus="no" id="txt_common_opt_mark">
      <source>Mark</source>
      <translation variants="no">標記</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_image">
      <source>Add image</source>
      <translation variants="no">zh_hk #Add image</translation>
    </message>
    <message numerus="no" id="txt_common_button_options">
      <source>Options</source>
      <translation variants="no">zh_hk #Options</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from">
      <source>From:</source>
      <translation variants="no">開始時間：</translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate_handsfree">
      <source>Activate handset</source>
      <translation variants="no">zh_hk #Activate handset</translation>
    </message>
    <message numerus="no" id="txt_common_info_buffering">
      <source>Buffering</source>
      <translation variants="no">緩衝處理中</translation>
    </message>
    <message numerus="no" id="txt_common_button_open">
      <source>Open</source>
      <translation variants="no">zh_hk #Open</translation>
    </message>
    <message numerus="no" id="txt_common_button_resume">
      <source>Resume</source>
      <translation variants="no">zh_hk #Resume</translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_off">
      <source>Loudsp. off</source>
      <translation variants="no">zh_hk #Loudsp. off</translation>
    </message>
    <message numerus="no" id="txt_common_button_answer_toolbar">
      <source>Answer</source>
      <translation variants="no">接聽</translation>
    </message>
    <message numerus="no" id="txt_common_info_processing">
      <source>Processing</source>
      <translation variants="no">處理中</translation>
    </message>
    <message numerus="no" id="txt_common_button_define">
      <source>Define</source>
      <translation variants="no">定義</translation>
    </message>
    <message numerus="no" id="txt_common_opt_change">
      <source>Change</source>
      <translation variants="no">更換</translation>
    </message>
    <message numerus="no" id="txt_common_button_save">
      <source>Save</source>
      <translation variants="no">zh_hk #Save</translation>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">關閉揚聲器</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_last_name">
      <source>Last name:</source>
      <translation variants="no">姓：</translation>
    </message>
    <message numerus="no" id="txt_common_button_reject_toolbar">
      <source>Reject</source>
      <translation variants="no">拒絕</translation>
    </message>
    <message numerus="no" id="txt_common_opt_fit_to_screen">
      <source>Fit to screen</source>
      <translation variants="no">調整至螢幕大小</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_user_id">
      <source>User ID:</source>
      <translation variants="no">用戶識別碼：</translation>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_out">
      <source>Zoom out</source>
      <translation variants="no">縮小</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_file_name">
      <source>File name:</source>
      <translation variants="no">zh_hk #File name:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_back">
      <source>Back</source>
      <translation variants="no">返回</translation>
    </message>
    <message numerus="no" id="txt_common_info_disconnecting">
      <source>Disconnecting</source>
      <translation variants="no">zh_hk #Disconnecting</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_new_password">
      <source>Verify new password:</source>
      <translation variants="no">確認新密碼：</translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_item">
      <source>Send</source>
      <translation variants="no">zh_hk #Send</translation>
    </message>
    <message numerus="no" id="txt_common_button_read">
      <source>Read</source>
      <translation variants="no">讀取</translation>
    </message>
    <message numerus="no" id="txt_common_menu_deselect">
      <source>Deselect</source>
      <translation variants="no">zh_hk #Deselect</translation>
    </message>
    <message numerus="no" id="txt_common_opt_cancel_download">
      <source>Cancel download</source>
      <translation variants="no">zh_hk #Cancel download</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_bookmark">
      <source>Add bookmark</source>
      <translation variants="no">加入書籤</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_file">
      <source>Select file:</source>
      <translation variants="no">選擇檔案：</translation>
    </message>
    <message numerus="no" id="txt_common_info_removing">
      <source>Removing</source>
      <translation variants="no">zh_hk #Removing</translation>
    </message>
    <message numerus="no" id="txt_common_opt_move_to_folder">
      <source>Move to folder</source>
      <translation variants="no">移動至資料夾</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_current_password">
      <source>Current password:</source>
      <translation variants="no">目前密碼：</translation>
    </message>
    <message numerus="no" id="txt_common_button_reset">
      <source>Reset</source>
      <translation variants="no">重設</translation>
    </message>
    <message numerus="no" id="txt_common_menu_select">
      <source>Select</source>
      <translation variants="no">zh_hk #Select</translation>
    </message>
    <message numerus="no" id="txt_common_opt_mark_all_items">
      <source>Select all items</source>
      <translation variants="no">選擇所有項目</translation>
    </message>
    <message numerus="no" id="txt_common_button_retry">
      <source>Retry</source>
      <translation variants="no">重試</translation>
    </message>
    <message numerus="no" id="txt_common_opt_move">
      <source>Move</source>
      <translation variants="no">移動</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_folder">
      <source>Add to folder</source>
      <translation variants="no">zh_hk #Add to folder</translation>
    </message>
    <message numerus="no" id="txt_common_opt_settings">
      <source>Settings</source>
      <translation variants="no">zh_hk #Settings</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_duration">
      <source>Duration:</source>
      <translation variants="no">持續時間：</translation>
    </message>
    <message numerus="no" id="txt_common_button_close">
      <source>Close</source>
      <translation variants="no">zh_hk #Close</translation>
    </message>
    <message numerus="no" id="txt_common_button_clear_toolbar">
      <source>Clear</source>
      <translation variants="no">清除</translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_on">
      <source>Loudsp. on</source>
      <translation variants="no">開啟揚聲器</translation>
    </message>
    <message numerus="no" id="txt_common_opt_call_noun">
      <source>Call</source>
      <translation variants="no">撥號</translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_message">
      <source>Send message</source>
      <translation variants="no">傳送訊息</translation>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_in">
      <source>Zoom in</source>
      <translation variants="no">zh_hk #Zoom in</translation>
    </message>
    <message numerus="no" id="txt_common_button_done_single_dialog">
      <source>Done</source>
      <translation variants="no">zh_hk #Done</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="no">zh_hk #OK</translation>
    </message>
    <message numerus="no" id="txt_common_opt_connect">
      <source>Connect</source>
      <translation variants="no">zh_hk #Connect</translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmute">
      <source>Unmute</source>
      <translation variants="no">zh_hk #Unmute</translation>
    </message>
    <message numerus="no" id="txt_common_opt_disable">
      <source>Disable</source>
      <translation variants="no">停用</translation>
    </message>
    <message numerus="no" id="txt_common_opt_copy_to_folder">
      <source>Copy to folder</source>
      <translation variants="no">複製到資料夾</translation>
    </message>
    <message numerus="no" id="txt_common_opt_enable">
      <source>Enable</source>
      <translation variants="no">啟用</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_bookmark_name">
      <source>Bookmark name:</source>
      <translation variants="no">書籤名稱：</translation>
    </message>
    <message numerus="no" id="txt_common_button_menu">
      <source>Menu</source>
      <translation variants="no">功能表</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_memory">
      <source>Select memory:</source>
      <translation variants="no">選擇記憶體：</translation>
    </message>
    <message numerus="no" id="txt_common_menu_copy">
      <source>Copy</source>
      <translation variants="no">複製</translation>
    </message>
    <message numerus="no" id="txt_common_button_mute">
      <source>Mute</source>
      <translation variants="no">靜音</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_user_name">
      <source>User name:</source>
      <translation variants="no">zh_hk #User name:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmark">
      <source>Unmark</source>
      <translation variants="no">取消標記</translation>
    </message>
  </context>
</TS>