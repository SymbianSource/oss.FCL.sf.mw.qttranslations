<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_applib_subtitle_office">
      <source>Collections &gt; Office (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">دفتر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_games">
      <source>Games</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھیل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_office">
      <source>Office</source>
      <translation variants="yes">
        <lengthvariant priority="1">دفتر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_downloads">
      <source>Collections &gt; Recently added (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">ڈاؤن لوڈ شدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_games">
      <source>Collections &gt; Games (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھیل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_collections_user">
      <source>Collections &gt; %1 (%L1)</source>
      <translation variants="no">ur #Collections &gt; %1 (%L1)</translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_downloads">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ ترین شامل کیا گیا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_essentials">
      <source>Collections &gt; Essentials (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہایت ضروری</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_essentials">
      <source>Essentials</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہایت ضروری</lengthvariant>
      </translation>
    </message>
  </context>
</TS>