<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_chinese_vkb_cangjie_landscape_numberandsymbolmode_switcher">
      <source>Number and Symbol</source>
      <translation variants="no">vi ##Number and Symbol</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_cangjie_language_switcher">
      <source>English</source>
      <translation variants="no">vi ##English</translation>
    </message>
  </context>
</TS>