<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_sett_subhead_security">
      <source>Security</source>
      <translation variants="no">ur #Security</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_net">
      <source>Choosing this item may result in compromised privacy or increased network usage costs. Continue? </source>
      <translation variants="no">منتخب ترتیب کے نتیجے میں رازداری میں خلل یا نیٹ ورک استعمال کے اخراجات میں اضافہ ہو سکتا ہے۔ جاری رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_note_security_warn">
      <source>Security warning</source>
      <translation variants="yes">
        <lengthvariant priority="1">حفاظتی انتباہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹھیک ہے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_warn">
      <source>Changing this setting item will cause changes in other settings. Continue? </source>
      <translation variants="no">اس ترتیب کی تبدیلی دوسری ترتیبات میں تبدیلیاں کر دےگی۔ جاری رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">منسوخ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_subhead_general">
      <source>General</source>
      <translation variants="no">ur #General</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_settings_not_available">
      <source>Settings not available</source>
      <translation variants="no">ur #Settings not available</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_sec">
      <source>Choosing this item may cause your privacy to be compromised. Continue? </source>
      <translation variants="no">منتخب ترتیب آپ کی رازداری میں خلل کی وجہ ہو سکتی ہے۔ جاری رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission">
      <source>Permission type</source>
      <translation variants="no">پروگرام تک رسائی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_landmarks">
      <source>Landmarks</source>
      <translation variants="no">نمایاں علامات</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_local_conn">
      <source>Local connectivity</source>
      <translation variants="no">اتصالیت</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_auth">
      <source>Authentication</source>
      <translation variants="no">تصدیق کریں</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_url_start">
      <source>URL start</source>
      <translation variants="no">ویب رسائی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_write_data">
      <source>Write user data</source>
      <translation variants="no">صارف لکھیں</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_call_control">
      <source>Call control</source>
      <translation variants="no">کال کنٹرول</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_blanket">
      <source>Blanket</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہمیشہ اجازت دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_net_access">
      <source>Net access</source>
      <translation variants="no">نیٹ ورک رسائی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_oneshot">
      <source>Oneshot</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہمیشہ دریافت کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_game">
      <source>Game keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھیل کے بٹن </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_user_defined">
      <source>User defined</source>
      <translation variants="no">صارف وضاحت کردہ</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level">
      <source>Security warnings</source>
      <translation variants="no">انتباہات</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_no">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk">
      <source>On-screen-keypad</source>
      <translation variants="no">بٹن پیڈ</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_mm_record">
      <source>Multimedia recording</source>
      <translation variants="no">ملٹیمیڈیا</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_broadcast">
      <source>Broadcast</source>
      <translation variants="no">TV صارف معلومات</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_session">
      <source>Session</source>
      <translation variants="yes">
        <lengthvariant priority="1">صرف پہلی بار دریافت کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_messaging">
      <source>Messaging</source>
      <translation variants="no">پیغام رسانی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_location">
      <source>Location</source>
      <translation variants="no">مقام بندی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_default">
      <source>Default</source>
      <translation variants="no">آغازی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_net">
      <source>Allowing these permissions may result in compromised privacy or increased network usage costs.</source>
      <translation variants="no">ان اجازت ناموں کی اجازت دینے کے نتیجے میں رازداری میں خلل یا نیٹ ورک استعمال کے اخراجات میں اضافہ ہو سکتا ہے</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_nfc_write_access">
      <source>NFC Write access</source>
      <translation variants="no">NFC ٹرانسمٹ</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_sec">
      <source>Allowing these permissions may result in compromised privacy.</source>
      <translation variants="no">ان اجازت ناموں کی اجازت دینے کے نتیجے میں رازداری میں خلل ہو سکتا ہے</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_navigation">
      <source>Navigation keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیویگیشن بٹن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_read_data">
      <source>Read user data</source>
      <translation variants="no">صارف کو پڑھیں</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_restricted_messaging">
      <source>Restricted messaging</source>
      <translation variants="no">بندشی پیغام رسانی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_app_auto_invoc">
      <source>Application auto invocation</source>
      <translation variants="no">پروگرام کا خود کار آغاز</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_smartcard">
      <source>Smart card communication</source>
      <translation variants="no">اسمارٹ کارڈ</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_low_level_net_access">
      <source>Low level network access</source>
      <translation variants="no">کم سطحی نیٹ ورک رسائی</translation>
    </message>
  </context>
</TS>