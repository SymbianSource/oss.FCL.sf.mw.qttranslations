<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_no">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_landmarks">
      <source>Landmarks</source>
      <translation variants="no">نمایاں علامات</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk">
      <source>On-screen-keypad</source>
      <translation variants="no">بٹن پیڈ</translation>
    </message>
    <message numerus="no" id="txt_java_sett_subtitle_general">
      <source>General</source>
      <translation variants="no">عام</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_app_auto_invoc">
      <source>Application auto invocation</source>
      <translation variants="no">پروگرام کا خود کار آغاز</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_network_conn_val_default">
      <source>Default connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">آغازی اتصال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_smartcard">
      <source>Smart card communication</source>
      <translation variants="no">اسمارٹ کارڈ</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_local_conn">
      <source>Local connectivity</source>
      <translation variants="no">اتصالیت</translation>
    </message>
    <message numerus="no" id="txt_java_sett_subtitle_security">
      <source>Security</source>
      <translation variants="no">حفاظت</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_net_access">
      <source>Net access</source>
      <translation variants="no">نیٹ ورک رسائی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_mm_record">
      <source>Multimedia recording</source>
      <translation variants="no">ملٹیمیڈیا</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_broadcast">
      <source>Broadcast</source>
      <translation variants="no">TV صارف معلومات</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_messaging">
      <source>Messaging</source>
      <translation variants="no">پیغام رسانی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_network_conn_val_list">
      <source>List of available connections</source>
      <translation variants="yes">
        <lengthvariant priority="1">دستیاب اتصالات کی فہرست</lengthvariant>
        <lengthvariant priority="2">دستیاب اتصالات فہرست</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_oneshot">
      <source>Oneshot</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہمیشہ دریافت کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_session">
      <source>Session</source>
      <translation variants="yes">
        <lengthvariant priority="1">صرف پہلی بار دریافت کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_location">
      <source>Location</source>
      <translation variants="no">مقام بندی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">صارف وضاحت کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level">
      <source>Security warnings</source>
      <translation variants="no">انتباہات</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_url_start">
      <source>URL start</source>
      <translation variants="no">ویب رسائی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_write_data">
      <source>Write user data</source>
      <translation variants="no">صارف لکھیں</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_call_control">
      <source>Call control</source>
      <translation variants="no">کال کنٹرول</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_navigation">
      <source>Navigation keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیویگیشن بٹن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_read_data">
      <source>Read user data</source>
      <translation variants="no">صارف کو پڑھیں</translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_warn">
      <source>Changing this setting item will cause changes in other settings. Continue? </source>
      <translation variants="no">ur #Changing this setting will cause changes in other settings. Continue?</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_net">
      <source>Choosing this item may result in compromised privacy or increased network usage costs. Continue? </source>
      <translation variants="no">ur #Selected setting may result in compromised privacy or increased network usage costs. Continue?</translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_note_security_warn">
      <source>Security warning</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Security warning</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_sec">
      <source>Allowing these permissions may result in compromised privacy.</source>
      <translation variants="no">ur #Allowing these permissions may result in compromised privacy</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_sec">
      <source>Allowing these permissions may result in compromised privacy.</source>
      <translation variants="no">ur #Allowing these permissions may result in compromised privacy</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_blanket">
      <source>Blanket</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہمیشہ اجازت دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_nfc_write_access">
      <source>NFC Write access</source>
      <translation variants="no">NFC ٹرانسمٹ</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_network_conn_val_ask_user">
      <source>Always ask</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہمیشہ دریافت کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_net">
      <source>Allowing these permissions may result in compromised privacy or increased network usage costs.</source>
      <translation variants="no">ur #Allowing these permissions may result in compromised privacy or increased network usage costs</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_net">
      <source>Allowing these permissions may result in compromised privacy or increased network usage costs.</source>
      <translation variants="no">ur #Allowing these permissions may result in compromised privacy or increased network usage costs</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_game">
      <source>Game keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھیل کے بٹن </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_default">
      <source>Default</source>
      <translation variants="yes">
        <lengthvariant priority="1">آغازی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_low_level_net_access">
      <source>Low level network access</source>
      <translation variants="no">کم سطحی نیٹ ورک رسائی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_auth">
      <source>Authentication</source>
      <translation variants="no">تصدیق کریں</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_network_conn">
      <source>Network connection</source>
      <translation variants="no">نیٹ ورک اتصال</translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission">
      <source>Permission type</source>
      <translation variants="no">پروگرام تک رسائی</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_sec">
      <source>Choosing this item may cause your privacy to be compromised. Continue? </source>
      <translation variants="no">ur #Selected setting may cause your privacy to be compromised. Continue?</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_restricted_messaging">
      <source>Restricted messaging</source>
      <translation variants="no">بندشی پیغام رسانی</translation>
    </message>
  </context>
</TS>