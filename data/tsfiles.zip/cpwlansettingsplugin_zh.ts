<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_scan_for_networks_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自动</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_power_saving">
      <source>Power saving</source>
      <translation variants="no">节电模式</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_wlan_settings">
      <source>WLAN settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_join_wlan_networks_val_known">
      <source>Known</source>
      <translation variants="no">已知</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_scan_interval_minutes">
      <source>Scan interval (minutes)</source>
      <translation variants="no">搜索间隔(分钟)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_scan_for_networks">
      <source>Scan for networks</source>
      <translation variants="no">搜索网络</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_power_saving_val_disabled">
      <source>Disabled</source>
      <translation variants="no">关闭</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_join_wlan_networks">
      <source>Join WLAN networks</source>
      <translation variants="no">切换到WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_join_wlan_networks_val_manual">
      <source>Manual</source>
      <translation variants="no">手动</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_scan_for_networks_val_userdefine">
      <source>User-defined interval</source>
      <translation variants="no">用户自定义间隔</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_power_saving_val_enabled">
      <source>Enabled</source>
      <translation variants="no">启动</translation>
    </message>
  </context>
</TS>