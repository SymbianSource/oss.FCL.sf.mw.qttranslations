<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_chinese_vkb_cangjie_language_switcher">
      <source>English</source>
      <translation variants="no">ur ##English</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_cangjie_landscape_numberandsymbolmode_switcher">
      <source>Number and Symbol</source>
      <translation variants="no">ur ##Number and Symbol</translation>
    </message>
  </context>
</TS>