<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_inst_info_error_cert_unsupported">
      <source>Application has been signed with a certificate that is not supported in this device.</source>
      <translation variants="no">Ứng dụng đã được ký tên bằng chứng chỉ không được thiết bị này hỗ trợ.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_bad_syntax">
      <source>Attribute %1 has bad syntax.</source>
      <translation variants="no">Thuộc tính không hợp lệ '%[98]1'.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_cancel">
      <source>Installation cancelled.</source>
      <translation variants="no">Đã hủy cài đặt.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_net_detail">
      <source>Cannot download installation package from URL %1.</source>
      <translation variants="no">Không thể tải về gói cài đặt từ địa chỉ web:
%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_push_reg">
      <source>Push registration failed.</source>
      <translation variants="no">Không đăng ký được</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_mismatch">
      <source>Attritbute %1 is different in JAD and JAR files.</source>
      <translation variants="no">Thuộc tính '%[98]1' khác nhau trong các tập tin JAD và JAR.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_authentication">
      <source>Application authentication failed.</source>
      <translation variants="no">Không xác thực ứng dụng được.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_different_signers">
      <source>The signers of the update and the already installed applications do not match.</source>
      <translation variants="no">Cập nhật đã được ký tên bằng chứng chỉ khác với chứng chỉ của ứng dụng được cài đặt hiện tại.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_pkg_misuse">
      <source>Package %1 is protected and can not be used.</source>
      <translation variants="no">Gói '%[98]1' được bảo vệ và không thể sử dụng được.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_mem_detail_mb">
      <source>Application requires %L1 MB of memory. You have to remove other applications or data from the device to install the application</source>
      <translation variants="no">Không đủ bộ nhớ. Ứng dụng yêu cầu %L1 MB. Xóa bớt ứng dụng khác hoặc dữ liệu và thử lại.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_missing">
      <source>Mandatory attribute %1 is missing.</source>
      <translation variants="no">Thiếu thuộc tính bắt buộc '%[98]1'.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_authorization">
      <source>Application authorization failed.</source>
      <translation variants="no">Không ủy quyền ứng dụng được.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_internal_error">
      <source>Internal error: %1</source>
      <translation variants="no">Lỗi nội bộ:
%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_uninst_cancel">
      <source>Uninstallation cancelled.</source>
      <translation variants="no">Đã hủy xóa phần mềm</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_mem_detail">
      <source>Application requires %L1 kB of memory. You have to remove other applications or data from the device to install the application</source>
      <translation variants="no">Không đủ bộ nhớ. Ứng dụng yêu cầu %L1 kB. Xóa bớt ứng dụng khác hoặc dữ liệu và thử lại.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_uninst_blocked">
      <source>Uninstallation is blocked by an attribute in application.</source>
      <translation variants="no">Việc xóa phần mềm đã bị ngăn chặn bởi một thuộc tính trong ứng dụng.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_uninst_unexpected">
      <source>Unable to uninstall. Unexpected error.</source>
      <translation variants="no">Không thể xóa phần mềm. Lỗi ngoài mong đợi.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_unsupported_value">
      <source>Attribute %1 has unsupported value.</source>
      <translation variants="no">Giá trị không hợp lệ trong thuộc tính '%[98]1'.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_handling_failed">
      <source>Attribute %1 handling failed.</source>
      <translation variants="no">Không xử lý được thuộc tính '%[98]1'.</translation>
    </message>
  </context>
</TS>