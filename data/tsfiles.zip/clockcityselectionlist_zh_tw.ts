<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_formlabel_city_name">
      <source>City name</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #City name</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_country">
      <source>Country</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Country</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_opt_add_own_city">
      <source>Add own city</source>
      <translation variants="no">zh_tw #Add own city</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_city_list">
      <source>City list</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #City list</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_timezone">
      <source>Timezone</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Timezone</lengthvariant>
      </translation>
    </message>
  </context>
</TS>