<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_common_title_select_tone1">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть тон:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_initialising">
      <source>Initialising</source>
      <translation variants="no">Триває ініціалізація</translation>
    </message>
    <message numerus="no" id="txt_common_button_resume">
      <source>Resume</source>
      <translation variants="yes">
        <lengthvariant priority="1">Продовжити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_audio">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">Попередній перегляд</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_web_address">
      <source>Web address:</source>
      <translation variants="no">Веб-адреса:</translation>
    </message>
    <message numerus="no" id="txt_common_info_opening">
      <source>Opening</source>
      <translation variants="no">Триває відкривання</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_bookmark">
      <source>Add bookmark</source>
      <translation variants="no">Зберегти як закладку</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Скасувати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_uninstall">
      <source>Uninstall</source>
      <translation variants="yes">
        <lengthvariant priority="1">Видалити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_copy">
      <source>Copy</source>
      <translation variants="no">Копіювати</translation>
    </message>
    <message numerus="no" id="txt_common_button_collapse">
      <source>Collapse</source>
      <translation variants="yes">
        <lengthvariant priority="1">Згорнути</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_listen">
      <source>Listen</source>
      <translation variants="yes">
        <lengthvariant priority="1">Прослухати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_message">
      <source>Send message</source>
      <translation variants="no">Надіслати повідомлення</translation>
    </message>
    <message numerus="no" id="txt_common_opt_remove">
      <source>Remove</source>
      <translation variants="no">Видалити</translation>
    </message>
    <message numerus="no" id="txt_common_info_removing">
      <source>Removing</source>
      <translation variants="no">Триває видалення</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name2">
      <source>Name:</source>
      <translation variants="no">Назва:</translation>
    </message>
    <message numerus="no" id="txt_common_title_details">
      <source>Details:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Деталі:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_install">
      <source>Install</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">Додати деталі</translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ні</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_paste">
      <source>Paste</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вставити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_clear">
      <source>Clear</source>
      <translation variants="yes">
        <lengthvariant priority="1">Очистити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_on">
      <source>Automatic find on</source>
      <translation variants="no">Увімкнути автопошук</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_first_name">
      <source>First name:</source>
      <translation variants="no">Прізвище:</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_address">
      <source>Select address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть адресу:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate">
      <source>Deactivate</source>
      <translation variants="no">Вимкнути</translation>
    </message>
    <message numerus="no" id="txt_common_opt_move_to_folder">
      <source>Move to folder</source>
      <translation variants="no">Перемістити в папку</translation>
    </message>
    <message numerus="no" id="txt_common_info_connecting">
      <source>Connecting</source>
      <translation variants="no">Установлення з’єднання</translation>
    </message>
    <message numerus="no" id="txt_common_menu_find">
      <source>Find</source>
      <translation variants="no">Знайти</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_time">
      <source>Time:</source>
      <translation variants="no">Час:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_settings">
      <source>Settings</source>
      <translation variants="no">Установки</translation>
    </message>
    <message numerus="no" id="txt_common_menu_rename_item">
      <source>Rename</source>
      <translation variants="no">Перейменувати</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_thumbnail">
      <source>Add thumbnail</source>
      <translation variants="no">Додати мініатюру</translation>
    </message>
    <message numerus="no" id="txt_common_opt_undo">
      <source>Undo</source>
      <translation variants="no">Скасувати останню дію</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_bookmark">
      <source>Add bookmark</source>
      <translation variants="no">Зберегти як закладку</translation>
    </message>
    <message numerus="no" id="txt_common_opt_install">
      <source>Install</source>
      <translation variants="no">Установити</translation>
    </message>
    <message numerus="no" id="txt_common_button_deactivate">
      <source>Deactivate</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вимкнути</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_disable">
      <source>Disable</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вимкнути</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_cancel_download">
      <source>Cancel download</source>
      <translation variants="no">Скасув. завантаження</translation>
    </message>
    <message numerus="no" id="txt_common_button_unmute">
      <source>Unmute</source>
      <translation variants="yes">
        <lengthvariant priority="1">Увімкнути звук</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_internet_call">
      <source>Internet call</source>
      <translation variants="no">Здійсн. Інтернет-дзвінок</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_folder">
      <source>Select folder:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть папку:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_duration">
      <source>Duration:</source>
      <translation variants="no">Тривалість:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_on">
      <source>Automatic find on</source>
      <translation variants="no">Увімкнути автопошук</translation>
    </message>
    <message numerus="no" id="txt_common_opt_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Роз’єднати</translation>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">Вимкнути гучномовець</translation>
    </message>
    <message numerus="no" id="txt_common_button_answer">
      <source>Answer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Відповісти</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Так</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_copying">
      <source>Copying</source>
      <translation variants="no">Триває копіювання</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_current_password">
      <source>Current password:</source>
      <translation variants="no">Поточний пароль:</translation>
    </message>
    <message numerus="no" id="txt_common_info_processing">
      <source>Processing</source>
      <translation variants="no">Триває обробка</translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmark">
      <source>Unmark</source>
      <translation variants="no">Скасувати позначення</translation>
    </message>
    <message numerus="no" id="txt_common_menu_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Додаткові установки</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_date">
      <source>Date:</source>
      <translation variants="no">Дата:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_print">
      <source>Print</source>
      <translation variants="no">Друк</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_member">
      <source>Add member</source>
      <translation variants="no">Додати учасника</translation>
    </message>
    <message numerus="no" id="txt_common_menu_save">
      <source>Save</source>
      <translation variants="no">Зберегти</translation>
    </message>
    <message numerus="no" id="txt_common_button_show">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">Показати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">Надіслати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_inserting">
      <source>Inserting</source>
      <translation variants="no">Триває вставлення</translation>
    </message>
    <message numerus="no" id="txt_common_menu_move_to_folder">
      <source>Move to folder</source>
      <translation variants="no">Перемістити в папку</translation>
    </message>
    <message numerus="no" id="txt_common_opt_organise">
      <source>Organise</source>
      <translation variants="no">Упорядкувати</translation>
    </message>
    <message numerus="no" id="txt_common_info_requesting">
      <source>Requesting</source>
      <translation variants="no">Триває обробка запиту</translation>
    </message>
    <message numerus="no" id="txt_common_button_help">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">Посібник користувача</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_saving">
      <source>Saving</source>
      <translation variants="no">Триває збереження</translation>
    </message>
    <message numerus="no" id="txt_common_menu_unmark">
      <source>Unmark</source>
      <translation variants="no">Скасувати позначення</translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_message">
      <source>Send message</source>
      <translation variants="no">Надіслати повідомлення</translation>
    </message>
    <message numerus="no" id="txt_common_button_find">
      <source>Find</source>
      <translation variants="yes">
        <lengthvariant priority="1">Знайти</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_process">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">Увімкнути</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_mute">
      <source>Mute</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вимкнути звук</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_unmute">
      <source>Unmute</source>
      <translation variants="no">Увімкнути звук</translation>
    </message>
    <message numerus="no" id="txt_common_button_menu">
      <source>Menu</source>
      <translation variants="yes">
        <lengthvariant priority="1">Меню</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_help">
      <source>Help</source>
      <translation variants="no">Посібник користувача</translation>
    </message>
    <message numerus="no" id="txt_common_opt_call_verb">
      <source>Call</source>
      <translation variants="no">Дзвонити</translation>
    </message>
    <message numerus="no" id="txt_common_button_disconnect">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">Роз’єднати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_uninstall">
      <source>Uninstall</source>
      <translation variants="no">Видалити</translation>
    </message>
    <message numerus="no" id="txt_common_menu_connect">
      <source>Connect</source>
      <translation variants="no">З’єднати</translation>
    </message>
    <message numerus="no" id="txt_common_button_start">
      <source>Start</source>
      <translation variants="yes">
        <lengthvariant priority="1">Почати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_video_call">
      <source>Video call</source>
      <translation variants="no">Здійснити відеодзвінок</translation>
    </message>
    <message numerus="no" id="txt_common_info_registering">
      <source>Registering</source>
      <translation variants="no">Триває реєстрація</translation>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">Вимкнути гучномовець</translation>
    </message>
    <message numerus="no" id="txt_common_button_change">
      <source>Change</source>
      <translation variants="yes">
        <lengthvariant priority="1">Змінити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_attachments">
      <source>Attachments</source>
      <translation variants="no">Вкладення</translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_object">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">Увімкнути</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_copy">
      <source>Copy</source>
      <translation variants="yes">
        <lengthvariant priority="1">Копіювати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_moving">
      <source>Moving</source>
      <translation variants="no">Триває переміщення</translation>
    </message>
    <message numerus="no" id="txt_common_info_deleting">
      <source>Deleting</source>
      <translation variants="no">Триває видалення</translation>
    </message>
    <message numerus="no" id="txt_common_info_buffering">
      <source>Buffering</source>
      <translation variants="no">Триває буферизація</translation>
    </message>
    <message numerus="no" id="txt_common_info_installing">
      <source>Installing</source>
      <translation variants="no">Триває встановлення</translation>
    </message>
    <message numerus="no" id="txt_common_button_retry">
      <source>Retry</source>
      <translation variants="yes">
        <lengthvariant priority="1">Повторити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone2">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть тон:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_cancelling">
      <source>Cancelling</source>
      <translation variants="no">Триває скасування</translation>
    </message>
    <message numerus="no" id="txt_common_button_reply">
      <source>Reply</source>
      <translation variants="yes">
        <lengthvariant priority="1">Відповісти</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_move">
      <source>Move</source>
      <translation variants="no">Перемістити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_chat">
      <source>Chat</source>
      <translation variants="no">Розмова</translation>
    </message>
    <message numerus="no" id="txt_common_opt_attachments">
      <source>Attachments</source>
      <translation variants="no">Вкладення</translation>
    </message>
    <message numerus="no" id="txt_common_button_play_video">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">Відтворити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_play_music">
      <source>Play</source>
      <translation variants="no">Відтворити</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_recipient">
      <source>Add recipient</source>
      <translation variants="no">Додати одержувача</translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">Видалити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_recipient">
      <source>Add recipient</source>
      <translation variants="no">Додати одержувача</translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_on">
      <source>Loudsp. on</source>
      <translation variants="yes">
        <lengthvariant priority="1">Увімкнути гучномовець</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_bookmark_name">
      <source>Bookmark name:</source>
      <translation variants="no">Назва закладки:</translation>
    </message>
    <message numerus="no" id="txt_common_button_select">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вибрати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_user_id">
      <source>User ID:</source>
      <translation variants="no">Ідентифікатор користувача:</translation>
    </message>
    <message numerus="no" id="txt_common_button_options">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">Опції</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_out">
      <source>Zoom out</source>
      <translation variants="no">Зменшити масштаб</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_address">
      <source>Address:</source>
      <translation variants="no">Адреса:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_about_application">
      <source>About application</source>
      <translation variants="no">Про програму</translation>
    </message>
    <message numerus="no" id="txt_common_opt_preview_audio">
      <source>Preview</source>
      <translation variants="no">Попередній перегляд</translation>
    </message>
    <message numerus="no" id="txt_common_opt_save">
      <source>Save</source>
      <translation variants="no">Зберегти</translation>
    </message>
    <message numerus="no" id="txt_common_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Роз’єднати</translation>
    </message>
    <message numerus="no" id="txt_common_opt_mark">
      <source>Mark</source>
      <translation variants="no">Позначити</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_language">
      <source>Select language:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть мову:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_writing_language">
      <source>Writing language:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Мова вводу:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_expand">
      <source>Expand</source>
      <translation variants="yes">
        <lengthvariant priority="1">Розгорнути</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">Увімкнути гучномовець</translation>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_in">
      <source>Zoom in</source>
      <translation variants="no">Збільшити масштаб</translation>
    </message>
    <message numerus="no" id="txt_common_button_reject">
      <source>Reject</source>
      <translation variants="yes">
        <lengthvariant priority="1">Відхилити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_in">
      <source>Zoom in</source>
      <translation variants="no">Збільшити масштаб</translation>
    </message>
    <message numerus="no" id="txt_common_menu_paste">
      <source>Paste</source>
      <translation variants="no">Вставити</translation>
    </message>
    <message numerus="no" id="txt_common_button_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Скинути</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone3">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть тон:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_disable">
      <source>Disable</source>
      <translation variants="no">Вимкнути</translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_item">
      <source>Send</source>
      <translation variants="no">Надіслати</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_from_contacts">
      <source>Add from Contacts</source>
      <translation variants="no">Додати з Контактів</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_new_password">
      <source>Verify new password:</source>
      <translation variants="no">Підтвердьте новий пароль:</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_file_name">
      <source>File name:</source>
      <translation variants="no">Назва файлу:</translation>
    </message>
    <message numerus="no" id="txt_common_button_pause">
      <source>Pause</source>
      <translation variants="yes">
        <lengthvariant priority="1">Пауза</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_internet_call">
      <source>Internet call</source>
      <translation variants="no">Здійсн. Інтернет-дзвінок</translation>
    </message>
    <message numerus="no" id="txt_common_menu_additional_details">
      <source>Additional details</source>
      <translation variants="no">Додаткові деталі</translation>
    </message>
    <message numerus="no" id="txt_common_opt_open">
      <source>Open</source>
      <translation variants="no">Відкрити</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_thumbnail">
      <source>Add thumbnail</source>
      <translation variants="no">Додати мініатюру</translation>
    </message>
    <message numerus="no" id="txt_common_menu_edit">
      <source>Edit</source>
      <translation variants="no">Редагувати</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_password">
      <source>Password:</source>
      <translation variants="no">Пароль:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_create_message">
      <source>Create message</source>
      <translation variants="no">Створити повідомлення</translation>
    </message>
    <message numerus="no" id="txt_common_menu_install">
      <source>Install</source>
      <translation variants="no">Установити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_details">
      <source>Details</source>
      <translation variants="no">Деталі</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="no">Зберегти в Контактах</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_folder">
      <source>Add to folder</source>
      <translation variants="no">Додати до папки</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_phone_number">
      <source>Phone number:</source>
      <translation variants="no">Номер телефону:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_select">
      <source>Select</source>
      <translation variants="no">Вибрати</translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate">
      <source>Activate</source>
      <translation variants="no">Увімкнути</translation>
    </message>
    <message numerus="no" id="txt_common_menu_remove">
      <source>Remove</source>
      <translation variants="no">Видалити</translation>
    </message>
    <message numerus="no" id="txt_common_menu_move">
      <source>Move</source>
      <translation variants="no">Перемістити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_cut">
      <source>Cut</source>
      <translation variants="no">Вирізати</translation>
    </message>
    <message numerus="no" id="txt_common_menu_undo">
      <source>Undo</source>
      <translation variants="no">Скасувати останню дію</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name1">
      <source>Name:</source>
      <translation variants="no">Ім’я:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_pause">
      <source>Pause</source>
      <translation variants="no">Пауза</translation>
    </message>
    <message numerus="no" id="txt_common_menu_continue">
      <source>Continue</source>
      <translation variants="no">Продовжити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">Зберегти в Контактах</translation>
    </message>
    <message numerus="no" id="txt_common_button_play_audio">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">Відтворити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_item">
      <source>Send</source>
      <translation variants="no">Надіслати</translation>
    </message>
    <message numerus="no" id="txt_common_menu_voice_call">
      <source>Voice call</source>
      <translation variants="no">Здійснити голос. дзвінок</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_image">
      <source>Add image</source>
      <translation variants="no">Додати зображення</translation>
    </message>
    <message numerus="no" id="txt_common_opt_exit">
      <source>Exit</source>
      <translation variants="no">Вихід</translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_off">
      <source>Loudsp. off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вимкнути гучномовець</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_quit">
      <source>Quit</source>
      <translation variants="yes">
        <lengthvariant priority="1">Скасувати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_save">
      <source>Save</source>
      <translation variants="yes">
        <lengthvariant priority="1">Зберегти</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_copy_to_folder">
      <source>Copy to folder</source>
      <translation variants="no">Копіювати в папку</translation>
    </message>
    <message numerus="no" id="txt_common_menu_details">
      <source>Details</source>
      <translation variants="no">Деталі</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_detail">
      <source>Add detail</source>
      <translation variants="no">Додати деталі</translation>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_off">
      <source>Automatic find off</source>
      <translation variants="no">Вимкнути автопошук</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_from_contacts">
      <source>Add from Contacts</source>
      <translation variants="no">Додати з Контактів</translation>
    </message>
    <message numerus="no" id="txt_common_menu_video_call">
      <source>Video call</source>
      <translation variants="no">Здійснити відеодзвінок</translation>
    </message>
    <message numerus="no" id="txt_common_opt_insert">
      <source>Insert</source>
      <translation variants="no">Вставити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate">
      <source>Activate</source>
      <translation variants="no">Увімкнути</translation>
    </message>
    <message numerus="no" id="txt_common_menu_insert">
      <source>Insert</source>
      <translation variants="no">Вставити</translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">Відкрити</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name1">
      <source>New name:</source>
      <translation variants="no">Нове ім’я:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_copy">
      <source>Copy</source>
      <translation variants="no">Копіювати</translation>
    </message>
    <message numerus="no" id="txt_common_menu_mark">
      <source>Mark</source>
      <translation variants="no">Позначити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_copy_to_folder">
      <source>Copy to folder</source>
      <translation variants="no">Копіювати в папку</translation>
    </message>
    <message numerus="no" id="txt_common_opt_about_application">
      <source>About application</source>
      <translation variants="no">Про програму</translation>
    </message>
    <message numerus="no" id="txt_common_button_record_video">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">Записати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_retrieving">
      <source>Retrieving</source>
      <translation variants="no">Триває завантаження</translation>
    </message>
    <message numerus="no" id="txt_common_opt_replace">
      <source>Replace</source>
      <translation variants="no">Замінити</translation>
    </message>
    <message numerus="no" id="txt_common_button_record_audio">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">Записати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="no">Додати до Контактів</translation>
    </message>
    <message numerus="no" id="txt_common_opt_edit">
      <source>Edit</source>
      <translation variants="no">Редагувати</translation>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate">
      <source>Deactivate</source>
      <translation variants="no">Вимкнути</translation>
    </message>
    <message numerus="no" id="txt_common_menu_pause">
      <source>Pause</source>
      <translation variants="no">Пауза</translation>
    </message>
    <message numerus="no" id="txt_common_opt_play_video">
      <source>Play</source>
      <translation variants="no">Відтворити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_voice_call">
      <source>Voice call</source>
      <translation variants="no">Здійснити голос. дзвінок</translation>
    </message>
    <message numerus="no" id="txt_common_menu_go_to_web_address">
      <source>Go to web address</source>
      <translation variants="no">Перейти до веб-адреси</translation>
    </message>
    <message numerus="no" id="txt_common_button_mark">
      <source>Mark</source>
      <translation variants="yes">
        <lengthvariant priority="1">Позначити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from">
      <source>From:</source>
      <translation variants="no">Від:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_play_video">
      <source>Play</source>
      <translation variants="no">Відтворити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_enable">
      <source>Enable</source>
      <translation variants="no">Увімкнути</translation>
    </message>
    <message numerus="no" id="txt_common_button_handset">
      <source>Handset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Увімкнути трубку</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_replace">
      <source>Replace</source>
      <translation variants="yes">
        <lengthvariant priority="1">Замінити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_to">
      <source>To:</source>
      <translation variants="no">До:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_fit_to_screen">
      <source>Fit to screen</source>
      <translation variants="no">За розміром екрана</translation>
    </message>
    <message numerus="no" id="txt_common_menu_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">Зберегти в Контактах</translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate_handsfree">
      <source>Activate handset</source>
      <translation variants="no">Увімкнути трубку</translation>
    </message>
    <message numerus="no" id="txt_common_info_adding">
      <source>Adding</source>
      <translation variants="no">Триває додавання</translation>
    </message>
    <message numerus="no" id="txt_common_opt_forward">
      <source>Forward</source>
      <translation variants="no">Переслати</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="no">Підтвердьте пароль:</translation>
    </message>
    <message numerus="no" id="txt_common_button_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Деталі</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_join">
      <source>Join</source>
      <translation variants="yes">
        <lengthvariant priority="1">Приєднатися</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_call_noun">
      <source>Call</source>
      <translation variants="no">Дзвінок</translation>
    </message>
    <message numerus="no" id="txt_common_button_read">
      <source>Read</source>
      <translation variants="yes">
        <lengthvariant priority="1">Прочитати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_closing">
      <source>Closing</source>
      <translation variants="no">Триває закривання</translation>
    </message>
    <message numerus="no" id="txt_common_menu_chat">
      <source>Chat</source>
      <translation variants="no">Розмова</translation>
    </message>
    <message numerus="no" id="txt_common_opt_continue">
      <source>Continue</source>
      <translation variants="no">Продовжити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_rename_item">
      <source>Rename</source>
      <translation variants="no">Перейменувати</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_end_date">
      <source>End date:</source>
      <translation variants="no">Дата завершення:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_select">
      <source>Select</source>
      <translation variants="no">Вибрати</translation>
    </message>
    <message numerus="no" id="txt_common_menu_preview_audio">
      <source>Preview</source>
      <translation variants="no">Попередній перегляд</translation>
    </message>
    <message numerus="no" id="txt_common_button_remove">
      <source>Remove</source>
      <translation variants="yes">
        <lengthvariant priority="1">Видалити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_change">
      <source>Change</source>
      <translation variants="no">Змінити</translation>
    </message>
    <message numerus="no" id="txt_common_info_loading">
      <source>Loading</source>
      <translation variants="no">Триває завантаження</translation>
    </message>
    <message numerus="no" id="txt_common_opt_delete">
      <source>Delete</source>
      <translation variants="no">Видалити</translation>
    </message>
    <message numerus="no" id="txt_common_button_exit">
      <source>Exit</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вихід</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_no_toolbar">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_answer_toolbar">
      <source>Answer</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Answer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_reject_toolbar">
      <source>Reject</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Reject</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_send_toolbar">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel_toolbar">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_delete_toolbar">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_replace_dialog">
      <source>Replace</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Replace</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_retry_dialog">
      <source>Retry</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Retry</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_show_dialog">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Show</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_stop_dialog">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Stop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_select_all_contents">
      <source>Select all contents</source>
      <translation variants="no">uk #Select all contents</translation>
    </message>
    <message numerus="no" id="txt_common_button_expand_dialog">
      <source>Expand</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Expand</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_call_dialog">
      <source>Call</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Call</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_mark_all_items">
      <source>Select all items</source>
      <translation variants="no">uk #Select all items</translation>
    </message>
    <message numerus="no" id="txt_common_button_mute_dialog">
      <source>Mute</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Mute</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_go_to_web_address">
      <source>Go to web address</source>
      <translation variants="no">Перейти до веб-адреси</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_last_name">
      <source>Last name:</source>
      <translation variants="no">uk #Last name:</translation>
    </message>
    <message numerus="no" id="txt_common_button_deselect">
      <source>Deselect</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Deselect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_on_dialog">
      <source>Loudsp. on</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Loudspeaker on</lengthvariant>
        <lengthvariant priority="2">uk #Loudsp. on</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_connect_dialog">
      <source>Connect</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Connect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_done_single_dialog">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Done</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_options_dialog">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Options</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_remove_dialog">
      <source>Remove</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Remove</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_audio_dialog">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Preview</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_continue_dialog">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Continue</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel_singledialog">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_settings_dialog">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_play_video_dialog">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Play</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_unmute_dialog">
      <source>Unmute</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Unmute</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_reset_dialog">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Reset</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_list_unmark_all_items">
      <source>Deselect all items</source>
      <translation variants="no">uk #Deselect all items</translation>
    </message>
    <message numerus="no" id="txt_common_button_back_dialog">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Back</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_disable_dialog">
      <source>Disable</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Disable</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_save_dialog">
      <source>Save</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Save</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_close_dialog">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Close</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_deselect">
      <source>Deselect</source>
      <translation variants="no">uk #Deselect</translation>
    </message>
    <message numerus="no" id="txt_common_button_uninstall_dialog">
      <source>Uninstall</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Uninstall</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_unmark_all_items">
      <source>Deselect all items</source>
      <translation variants="no">uk #Deselect all items</translation>
    </message>
    <message numerus="no" id="txt_common_button_open_dialog">
      <source>Open</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Open</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_find_dialog">
      <source>Find</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Find</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_add_dialog">
      <source>Add</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Add</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_enable_dialog">
      <source>Enable</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Enable</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_read_dialog">
      <source>Read</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Read</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_details_dialog">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Details</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_format">
      <source>Format </source>
      <translation variants="no">uk #Format </translation>
    </message>
    <message numerus="no" id="txt_common_button_deselect_dialog">
      <source>Deselect</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Deselect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmark_all_items">
      <source>Deselect all items</source>
      <translation variants="no">uk #Deselect all items</translation>
    </message>
    <message numerus="no" id="txt_common_button_disconnect_dialog">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Disconnect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_select_all_contents">
      <source>Select all contents</source>
      <translation variants="no">uk #Select all contents</translation>
    </message>
    <message numerus="no" id="txt_common_button_collapse_dialog">
      <source>Collapse</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Collapse</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_help_dialog">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #User guide</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_handset_dialog">
      <source>Handset</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Handset</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_list_mark_all_items">
      <source>Select all items</source>
      <translation variants="no">uk #Select all items</translation>
    </message>
    <message numerus="no" id="txt_common_button_close_singledialog">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Close</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_define_dialog">
      <source>Define</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Define</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_join_dialog">
      <source>Join</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Join</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok_single_dialog">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_done_dialog">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Done</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_listen_dialog">
      <source>Listen</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Listen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_stop_singledialog">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Stop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_change_dialog">
      <source>Change</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Change</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_disconnect_singledialog">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Disconnect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_resume_dialog">
      <source>Resume</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Resume</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_preview_video">
      <source>Preview</source>
      <translation variants="no">Попередній перегляд</translation>
    </message>
    <message numerus="no" id="txt_common_title_web_address">
      <source>Web address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть веб-адресу:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name2">
      <source>New name:</source>
      <translation variants="no">Нова назва:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_find">
      <source>Find</source>
      <translation variants="no">Знайти</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_expires">
      <source>Expires:</source>
      <translation variants="no">Закінчення дії:</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_user_name">
      <source>User name:</source>
      <translation variants="no">Ім’я користувача:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_call_verb">
      <source>Call</source>
      <translation variants="no">Дзвонити</translation>
    </message>
    <message numerus="no" id="txt_common_button_done">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Done</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_unmark_dialog">
      <source>Unmark</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Unmark</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">Увімкнути гучномовець</translation>
    </message>
    <message numerus="no" id="txt_common_menu_organise">
      <source>Organise</source>
      <translation variants="no">Упорядкувати</translation>
    </message>
    <message numerus="no" id="txt_common_menu_call_noun">
      <source>Call</source>
      <translation variants="no">Дзвінок</translation>
    </message>
    <message numerus="no" id="txt_common_info_disconnecting">
      <source>Disconnecting</source>
      <translation variants="no">Триває роз’єднання</translation>
    </message>
    <message numerus="no" id="txt_common_opt_change">
      <source>Change</source>
      <translation variants="no">Змінити</translation>
    </message>
    <message numerus="no" id="txt_common_menu_uninstall">
      <source>Uninstall</source>
      <translation variants="no">Видалити</translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate_handsfree">
      <source>Activate handset</source>
      <translation variants="no">Увімкнути трубку</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_file">
      <source>Select file:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть файл:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_member">
      <source>Add member</source>
      <translation variants="no">Додати учасника</translation>
    </message>
    <message numerus="no" id="txt_common_menu_rename_people">
      <source>Rename</source>
      <translation variants="no">Перейменувати</translation>
    </message>
    <message numerus="no" id="txt_common_menu_fit_to_screen">
      <source>Fit to screen</source>
      <translation variants="no">За розміром екрана</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_password">
      <source>New password:</source>
      <translation variants="no">Новий пароль:</translation>
    </message>
    <message numerus="no" id="txt_common_button_add">
      <source>Add</source>
      <translation variants="yes">
        <lengthvariant priority="1">Додати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">ОК</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_back">
      <source>Back</source>
      <translation variants="no">Назад</translation>
    </message>
    <message numerus="no" id="txt_common_button_edit">
      <source>Edit</source>
      <translation variants="yes">
        <lengthvariant priority="1">Редагувати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_deactivate_dialog">
      <source>Deactivate</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Deactivate</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_call">
      <source>Call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Дзвонити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_move_dialog">
      <source>Move</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Move</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_format">
      <source>Format </source>
      <translation variants="no">uk #Format </translation>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_out">
      <source>Zoom out</source>
      <translation variants="no">Зменшити масштаб</translation>
    </message>
    <message numerus="no" id="txt_common_menu_create_message">
      <source>Create message</source>
      <translation variants="no">Створити повідомлення</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_folder_name">
      <source>Folder name:</source>
      <translation variants="no">Назва папки:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmute">
      <source>Unmute</source>
      <translation variants="no">Увімкнути звук</translation>
    </message>
    <message numerus="no" id="txt_common_opt_disable">
      <source>Disable</source>
      <translation variants="no">Вимкнути</translation>
    </message>
    <message numerus="no" id="txt_common_button_copy_dialog">
      <source>Copy</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Copy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_pause_dialog">
      <source>Pause</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Pause</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_start_dialog">
      <source>Start</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Start</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_unmark">
      <source>Unmark</source>
      <translation variants="yes">
        <lengthvariant priority="1">Скасувати позначення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_stop">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">Зупинити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_define">
      <source>Define</source>
      <translation variants="yes">
        <lengthvariant priority="1">Визначити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">Закрити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_rename_people">
      <source>Rename</source>
      <translation variants="no">Перейменувати</translation>
    </message>
    <message numerus="no" id="txt_common_menu_exit">
      <source>Exit</source>
      <translation variants="no">Вихід</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_folder">
      <source>Add to folder</source>
      <translation variants="no">Додати до папки</translation>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_off">
      <source>Automatic find off</source>
      <translation variants="no">Вимкнути автопошук</translation>
    </message>
    <message numerus="no" id="txt_common_menu_settings">
      <source>Settings</source>
      <translation variants="no">Установки</translation>
    </message>
    <message numerus="no" id="txt_common_menu_preview_video">
      <source>Preview</source>
      <translation variants="no">Попередній перегляд</translation>
    </message>
    <message numerus="no" id="txt_common_button_open">
      <source>Open</source>
      <translation variants="yes">
        <lengthvariant priority="1">Відкрити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_forward">
      <source>Forward</source>
      <translation variants="no">Переслати</translation>
    </message>
    <message numerus="no" id="txt_common_button_insert">
      <source>Insert</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вставити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_enable">
      <source>Enable</source>
      <translation variants="yes">
        <lengthvariant priority="1">Увімкнути</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_image">
      <source>Add image</source>
      <translation variants="no">Додати зображення</translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_video">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">Попередній перегляд</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_replace">
      <source>Replace</source>
      <translation variants="no">Замінити</translation>
    </message>
    <message numerus="no" id="txt_common_opt_connect">
      <source>Connect</source>
      <translation variants="no">З’єднати</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_title">
      <source>Title:</source>
      <translation variants="no">Назва:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_additional_details">
      <source>Additional details</source>
      <translation variants="no">Додаткова інформація</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_memory">
      <source>Select memory:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Виберіть пам’ять:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_enable">
      <source>Enable</source>
      <translation variants="no">Увімкнути</translation>
    </message>
    <message numerus="no" id="txt_common_button_finish">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">Готово</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_hide">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">Сховати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_play_music">
      <source>Play</source>
      <translation variants="no">Відтворити</translation>
    </message>
    <message numerus="no" id="txt_common_menu_cut">
      <source>Cut</source>
      <translation variants="no">Вирізати</translation>
    </message>
    <message numerus="no" id="txt_common_button_connect">
      <source>Connect</source>
      <translation variants="yes">
        <lengthvariant priority="1">З’єднати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_continue">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">Продовжити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_select_dialog">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Select</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_mark_all_items">
      <source>Select all items</source>
      <translation variants="no">uk #Select all items</translation>
    </message>
    <message numerus="no" id="txt_common_button_reply_dialog">
      <source>Reply</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Reply</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_paste_dialog">
      <source>Paste</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Paste</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_hide_single_dialog">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Hide</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_deselect">
      <source>Deselect</source>
      <translation variants="no">uk #Deselect</translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_off_dialog">
      <source>Loudsp. off</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Loudspeaker off</lengthvariant>
        <lengthvariant priority="2">uk #Loudsp. off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_edit_dialog">
      <source>Edit</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Edit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_finish_dialog">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Finish</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_yes_toolbar">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok_toolbar">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_hide_toolbar">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Hide</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_move">
      <source>Move</source>
      <translation variants="yes">
        <lengthvariant priority="1">Перемістити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_paste">
      <source>Paste</source>
      <translation variants="no">Вставити</translation>
    </message>
    <message numerus="no" id="txt_common_menu_print">
      <source>Print</source>
      <translation variants="no">Друк</translation>
    </message>
    <message numerus="no" id="txt_common_info_unistalling">
      <source>Uninstalling</source>
      <translation variants="no">Триває видалення</translation>
    </message>
    <message numerus="no" id="txt_common_button_clear_toolbar">
      <source>Clear</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Clear</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_record_video_dialog">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Record</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_video_dialog">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Preview</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_install_dialog">
      <source>Install</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Install</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_finish_single_dialog">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Finish</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_quit_dialog">
      <source>Quit</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Quit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_play_audio_dialog">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Play</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_process_dialog">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Activate</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_object_dialog">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Activate</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_exit_dialog">
      <source>Exit</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Exit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_insert_dialog">
      <source>Insert</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Insert</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_record_audio_dialog">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Record</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_cancel_download">
      <source>Cancel download</source>
      <translation variants="no">Скасув. завантаження</translation>
    </message>
    <message numerus="no" id="txt_common_info_searching">
      <source>Searching</source>
      <translation variants="no">Триває пошук</translation>
    </message>
    <message numerus="no" id="txt_common_button_back">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">Назад</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Додаткові установки</translation>
    </message>
    <message numerus="no" id="txt_common_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">Видалити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_mark_dialog">
      <source>Mark</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Mark</lengthvariant>
      </translation>
    </message>
  </context>
</TS>