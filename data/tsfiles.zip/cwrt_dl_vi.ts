<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_dm_dialog_no_space_to_download_this_filemak">
      <source>No space to download this file.

Make space for it and retry.</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #No space to download this file.

Make space for it and retry.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_universal_dblist_downloading">
      <source>Downloading</source>
      <translation variants="no">vi #Downloading</translation>
    </message>
    <message numerus="no" id="txt_dm_dialog_l1_kb">
      <source>%L1 KB</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #%L1 KB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dm_dblist_val_l1_mb">
      <source>%L1 MB</source>
      <translation variants="no">vi #%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_dm_title_download_complete">
      <source>Download complete</source>
      <translation variants="no">vi #Download complete</translation>
    </message>
    <message numerus="no" id="txt_dm_list_1_memory_card">
      <source>%1: Memory card</source>
      <translation variants="no">vi #%1: Memory card</translation>
    </message>
    <message numerus="no" id="txt_dm_list_1_mass_storage">
      <source>%1: Mass storage</source>
      <translation variants="no">vi #%1: Mass storage</translation>
    </message>
    <message numerus="no" id="txt_dm_dblist_val_l1_kb">
      <source>%L1 KB</source>
      <translation variants="no">vi #%L1 KB</translation>
    </message>
    <message numerus="no" id="txt_dm_title_unsupported_file">
      <source>Unsupported File</source>
      <translation variants="no">vi #Unsupported File</translation>
    </message>
    <message numerus="no" id="txt_dm_title_no_space_to_download">
      <source>No space to download</source>
      <translation variants="no">vi #No space to download</translation>
    </message>
    <message numerus="no" id="txt_dm_dpophead_downloading">
      <source>Downloading</source>
      <translation variants="no">vi #Downloading</translation>
    </message>
    <message numerus="no" id="txt_dm_setlabel_val_free">
      <source>Free:</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Free:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dm_title_downloading">
      <source>Downloading</source>
      <translation variants="no">vi #Downloading</translation>
    </message>
    <message numerus="no" id="txt_dm_dialog_size">
      <source>Size: </source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Size: </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dm_dpopinfo_download_complete">
      <source>Download complete</source>
      <translation variants="no">vi #Download complete</translation>
    </message>
    <message numerus="no" id="txt_dm_dialog_select_another_location_or_delete_so">
      <source>Select another location or delete some files then retry.</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Select another location or delete some files then retry.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dm_dpopinfo_download_canceled">
      <source>Download canceled</source>
      <translation variants="no">vi #Download canceled</translation>
    </message>
    <message numerus="no" id="txt_dm_title_download_canceled">
      <source>Download canceled</source>
      <translation variants="no">vi #Download canceled</translation>
    </message>
    <message numerus="no" id="txt_dm_title_try_download_again">
      <source>Try download again?</source>
      <translation variants="no">vi #Try download again?</translation>
    </message>
    <message numerus="no" id="txt_dm_list_1_device_memory">
      <source>%1: Device memory</source>
      <translation variants="no">vi #%1: Device memory</translation>
    </message>
    <message numerus="no" id="txt_dm_dialog_l1_mb">
      <source>%L1 MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #%L1 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dm_dpophead_download_complete">
      <source>Download complete</source>
      <translation variants="no">vi #Download complete</translation>
    </message>
    <message numerus="no" id="txt_dm_title_download">
      <source>Download?</source>
      <translation variants="no">vi #Download?</translation>
    </message>
    <message numerus="no" id="txt_dm_dialog_unable_to_download_unsupported_file">
      <source>Unable to download unsupported file.</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unable to download unsupported file.</lengthvariant>
      </translation>
    </message>
  </context>
</TS>