<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="nl">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Source 0</source>
      <translation variants="no">Duur zichtbaarheid wijzigen</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_input_devices">
      <source>Source 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Invoerapparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>Source 2</source>
      <translation variants="no">Alle apparaten</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_phones">
      <source>Source 3</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen telefoons</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_input_devices">
      <source>Source 4</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Gekoppelde invoerapparaten</lengthvariant>
        <lengthvariant priority="2">Bluetooth - Gekop. invoerapparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>Source 5</source>
      <translation variants="no">Details van %1</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Source 6</source>
      <translation variants="no">Italiaans</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Source 7</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gekoppeld</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_paired_devices">
      <source>Source 8</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen andere gekoppelde apparaten</lengthvariant>
        <lengthvariant priority="2">Geen andere gekop. apparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>Source 9</source>
      <translation variants="no">%[15]1 verbonden</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Source 10</source>
      <translation variants="yes">
        <lengthvariant priority="1">Automatisch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Source 11</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gekoppeld, vertrouwd, verbonden</lengthvariant>
        <lengthvariant priority="2">Gekop., vertrouwd, verbonden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Source 12</source>
      <translation variants="yes">
        <lengthvariant priority="1">nl #Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Source 13</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gekoppeld, verbonden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_phones">
      <source>Source 14</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Telefoons</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Source 15</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Alle apparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Source 16</source>
      <translation variants="no">Frans (België)</translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Source 17</source>
      <translation variants="yes">
        <lengthvariant priority="1">Invoerapparaat</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Source 18</source>
      <translation variants="no">Deens</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Source 19</source>
      <translation variants="yes">
        <lengthvariant priority="1">Altijd vragen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>Source 20</source>
      <translation variants="no">VS (internationaal)</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Source 21</source>
      <translation variants="no">Uitgeschakeld</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_input_devices">
      <source>Source 22</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen gekoppelde apparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Source 23</source>
      <translation variants="no">Gekoppelde apparaten</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_devices">
      <source>Source 24</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Andere apparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Source 25</source>
      <translation variants="yes">
        <lengthvariant priority="1">Computer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>Source 26</source>
      <translation variants="yes">
        <lengthvariant priority="1">nl #On and hidden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Source 27</source>
      <translation variants="no">Fins, Zweeds</translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Source 28</source>
      <translation variants="yes">
        <lengthvariant priority="1">Overige</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Source 29</source>
      <translation variants="no">nl #Unpair</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_phones">
      <source>Source 30</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Gekoppelde telefoons</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Source 31</source>
      <translation variants="no">Noors</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Source 32</source>
      <translation variants="no">Portugees</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Source 33</source>
      <translation variants="yes">
        <lengthvariant priority="1">nl #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Source 34</source>
      <translation variants="no">Toetsenbordindeling</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Source 35</source>
      <translation variants="yes">
        <lengthvariant priority="1">Toetsenbordinstellingen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>Source 36</source>
      <translation variants="no">Engels (VK)</translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Source 37</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geblokkeerd</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>Source 38</source>
      <translation variants="no">Duits</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>Source 39</source>
      <translation variants="no">VS (Dvorak)</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Source 40</source>
      <translation variants="no">Spaans</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_audio_devices">
      <source>Source 41</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Audioapparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_computers">
      <source>Source 42</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Computers</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>Source 43</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen gevonden apparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Source 44</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geblokkeerd</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_audio_devices">
      <source>Source 45</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen audioapparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>Source 46</source>
      <translation variants="no">Frans</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_computers">
      <source>Source 47</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen computers</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_audio_devices">
      <source>Source 48</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Gekoppelde audioapparaten</lengthvariant>
        <lengthvariant priority="2">Bluetooth - Gekop. audioapparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Source 49</source>
      <translation variants="no">nl #Search completed</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_paired_devices">
      <source>Source 50</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Andere gekoppelde apparaten</lengthvariant>
        <lengthvariant priority="2">Bluetooth - Andere gekoppelde app.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Source 51</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Geavanceerde instellingen</lengthvariant>
        <lengthvariant priority="2">Bluetooth - Geavanc. instellingen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_audio_devices">
      <source>Source 52</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen gekoppelde audioapparaten</lengthvariant>
        <lengthvariant priority="2">Geen gekop. audioapparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Source 53</source>
      <translation variants="no">nl #Pair</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Source 54</source>
      <translation variants="yes">
        <lengthvariant priority="1">Verbinding</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_1">
      <source>Source 55</source>
      <translation variants="no">Bluetooth - %1</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Source 56</source>
      <translation>
        <numerusform plurality="a">nl #Visible for %Ln minute</numerusform>
        <numerusform plurality="b">nl #Visible for %Ln minutes</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_phones">
      <source>Source 57</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen gekoppelde telefoons</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_devices">
      <source>Source 58</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen andere apparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Source 59</source>
      <translation variants="yes">
        <lengthvariant priority="1">Muisinstellingen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Source 60</source>
      <translation variants="yes">
        <lengthvariant priority="1">nl #Visible and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Source 61</source>
      <translation variants="no">Verwijderen</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>Source 62</source>
      <translation variants="no">Engels (VS)</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Source 63</source>
      <translation variants="no">nl #Searching</translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Source 64</source>
      <translation variants="yes">
        <lengthvariant priority="1">Verbonden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>Source 65</source>
      <translation variants="no">SIM-toegangsprofiel</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Source 66</source>
      <translation variants="no">Gekoppelde app. verwdrn</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Source 67</source>
      <translation variants="no">Ingeschakeld</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Source 68</source>
      <translation variants="no">Geblokkeerde apparaten</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Source 69</source>
      <translation variants="no">nl #Hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Source 70</source>
      <translation variants="no">Russisch</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Source 71</source>
      <translation variants="no">Verbinden</translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Source 72</source>
      <translation variants="no">nl #Disconnect</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Source 73</source>
      <translation variants="no">nl #Device details</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>Source 74</source>
      <translation variants="yes">
        <lengthvariant priority="1">nl #On and visible</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Source 75</source>
      <translation variants="no">Verbinding verbreken</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>Source 76</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen apparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Source 77</source>
      <translation variants="no">nl #Bluetooth - Found devices</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Source 78</source>
      <translation variants="yes">
        <lengthvariant priority="1">Telefoon</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Source 79</source>
      <translation variants="yes">
        <lengthvariant priority="1">nl #Hidden and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Source 80</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Gekoppelde apparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>Source 81</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen gekoppelde apparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_input_devices">
      <source>Source 82</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen invoerapparaten</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Source 83</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gekoppeld, vertrouwd</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Source 84</source>
      <translation variants="no">Geavanc. instellingen</translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Source 85</source>
      <translation variants="no">nl #Connect</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Source 86</source>
      <translation variants="no">nl #Visible</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Source 87</source>
      <translation variants="no">Nederlands</translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Source 88</source>
      <translation variants="yes">
        <lengthvariant priority="1">Audioapparaat</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_computers">
      <source>Source 89</source>
      <translation variants="yes">
        <lengthvariant priority="1">Geen gekoppelde computers</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_computers">
      <source>Source 90</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Gekoppelde computers</lengthvariant>
      </translation>
    </message>
  </context>
</TS>