<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_accessories_dblist_menu_loopset">
      <source>Loopset</source>
      <translation variants="no">vi #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="no">16:9</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">vi #Wired car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headse">
      <source>Headset</source>
      <translation variants="no">Tai nghe</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">vi #Wireless car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">vi #Wireless car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">Tỷ lệ khung hình TV</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headset">
      <source>Headset</source>
      <translation variants="no">vi #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Wired car kit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_wired">
      <source>Wired carkit</source>
      <translation variants="no">vi #Wired car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_automatic">
      <source>Automatic</source>
      <translation variants="no">vi #Automatic</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_loopse">
      <source>Loopset</source>
      <translation variants="no">vi #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headphones">
      <source>Headphones</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Headphones</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headph">
      <source>Headphones</source>
      <translation variants="no">vi #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="yes">
        <lengthvariant priority="1">Text phone</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tai nghe</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Wireless car kit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headphones">
      <source>Headphones</source>
      <translation variants="no">vi #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headset">
      <source>Headset</source>
      <translation variants="no">vi #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="no">4:3</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_on">
      <source>On</source>
      <translation variants="no">vi #On</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_music_stand">
      <source>Music stand</source>
      <translation variants="no">vi #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">Loại phụ kiện</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_loopset">
      <source>Loopset</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Loopset</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_music">
      <source>Music stand</source>
      <translation variants="no">vi #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights">
      <source>Lights</source>
      <translation variants="no">vi #Lights</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_tty">
      <source>TTY</source>
      <translation variants="no">vi #Text phone</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_music_stand">
      <source>Music stand</source>
      <translation variants="no">vi #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_music_stand">
      <source>Music stand</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Music stand</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="no">Text phone</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_loopset">
      <source>Loopset</source>
      <translation variants="no">vi #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_tty">
      <source>TTY</source>
      <translation variants="no">vi #Text phone</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi ##Accessory</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">vi #Wired car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headphones">
      <source>Headphones</source>
      <translation variants="no">vi #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt phụ kiện</lengthvariant>
        <lengthvariant priority="2">vi #Accessory sett.</lengthvariant>
      </translation>
    </message>
  </context>
</TS>