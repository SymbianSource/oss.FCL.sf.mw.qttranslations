<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dblist_usb">
      <source>USB</source>
      <translation variants="yes">
        <lengthvariant priority="1">USB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tws_caption_usb">
      <source>USB</source>
      <translation variants="no">vi #USB</translation>
    </message>
    <message numerus="no" id="txt_usb_subhead_select_connection_type">
      <source>Select connection type</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn loại kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_usb">
      <source>USB</source>
      <translation variants="no">USB</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_mass_storage">
      <source>Mass storage</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ổ đĩa chung</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_media_transfer_val">
      <source>Use this phone as a music or image source to the other device</source>
      <translation variants="no">vi #Use this phone as a source of images or music to the other device</translation>
    </message>
    <message numerus="no" id="txt_short_caption_usb">
      <source>USB</source>
      <translation variants="no">vi #USB</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_phone_as_modem_val">
      <source>Use this phone to connect the other device to the Internet</source>
      <translation variants="no">vi #Use this phone to connect the other device to internet</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_mass_storage_val">
      <source>Use this phone like a memory stick on the other device</source>
      <translation variants="no">vi #Use this phone like a USB drive. Phone content can be mounted on a PC.</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_phone_as_modem">
      <source>Web connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kết nối PC vào internet</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_ovi_suite">
      <source>OVI suite</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nokia Ovi Suite</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_ovi_suite_val">
      <source>Access this phone’s information from OVI Suite</source>
      <translation variants="no">vi #Access this phone´s information with Nokia Ovi Suite</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_media_transfer">
      <source>Media transfer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Truyền media</lengthvariant>
      </translation>
    </message>
  </context>
</TS>