<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ro">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="no">Telefon cu text</translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">Setări accesorii</lengthvariant>
        <lengthvariant priority="2">ro #Accessory sett.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">Accesoriu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="yes">
        <lengthvariant priority="1">CăȘti</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="no">4:3</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headse">
      <source>Headset</source>
      <translation variants="no">CăȘti</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">ProporȚie aspect TV</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="yes">
        <lengthvariant priority="1">Telefon cu text</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="no">16:9</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">Tip de accesoriu</translation>
    </message>
  </context>
</TS>