<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dpopinfo_internal_error">
      <source>Internal error </source>
      <translation variants="no">داخلی غلطی۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_connecting">
      <source>Connecting</source>
      <translation variants="no">اتصال جاری</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_check_connection_settings">
      <source>Check connection settings</source>
      <translation variants="no">اتصال تر. کی جانچ</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_service_unreachable">
      <source>Service unreachable</source>
      <translation variants="no">خدمت پہنچ سے باہر۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_connection_already_active">
      <source>Connection already active</source>
      <translation variants="no">ات. پہلے سے کارآمد۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_configuration_failed">
      <source>Configuration failed</source>
      <translation variants="no">تشکیل. ناکام۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_please_try_again">
      <source>Please try again </source>
      <translation variants="no">دوبارہ کوشش کریں۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_wlan_network_not_found">
      <source>WLAN network not found</source>
      <translation variants="no">WLAN نیٹو. نہیں ملا۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_connection_failed">
      <source>Connection failed</source>
      <translation variants="no">اتصال ناکام۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_check_security_key">
      <source>Check security key</source>
      <translation variants="no">حفاظتی کوڈ کی جانچ۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_connection_unavailable">
      <source>Connection unavailable</source>
      <translation variants="no">اتصال غیر دستیاب۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_sim_card_missing">
      <source>SIM card missing </source>
      <translation variants="no">SIM کارڈ غائب ہے۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_authentication_unsuccessful">
      <source>Authentication unsuccessful</source>
      <translation variants="no">تصدیق کاری ناکام۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_signal_too_weak">
      <source>Signal too weak </source>
      <translation variants="no">سگنل بہت کمزور ہے۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_maximum_connections_in_use">
      <source>Maximum connections in use</source>
      <translation variants="no">اتصال زیر استعمال۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_select_to_manage">
      <source>Select to manage</source>
      <translation variants="no">انتظام کے لیے منتخب۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_permission_denied">
      <source>Permission denied </source>
      <translation variants="no">اجازت سے انکار۔</translation>
    </message>
  </context>
</TS>