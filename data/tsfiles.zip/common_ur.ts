<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_common_button_collapse">
      <source>Collapse</source>
      <translation variants="yes">
        <lengthvariant priority="1">سمیٹیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_removing">
      <source>Removing</source>
      <translation variants="no">نکال رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone1">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹون منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_move_to_folder">
      <source>Move to folder</source>
      <translation variants="no">فولڈر میں منتقل</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_user_name">
      <source>User name:</source>
      <translation variants="no">صارف نام:</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_time">
      <source>Time:</source>
      <translation variants="no">وقت:</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_web_address">
      <source>Web address:</source>
      <translation variants="no">ویب پتہ:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_copy">
      <source>Copy</source>
      <translation variants="no">نقل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_info_opening">
      <source>Opening</source>
      <translation variants="no">کھو ل رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name2">
      <source>Name:</source>
      <translation variants="no">نام:</translation>
    </message>
    <message numerus="no" id="txt_common_button_deactivate">
      <source>Deactivate</source>
      <translation variants="yes">
        <lengthvariant priority="1">غیرکارآمد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_copying">
      <source>Copying</source>
      <translation variants="no">نقل کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_listen">
      <source>Listen</source>
      <translation variants="yes">
        <lengthvariant priority="1">سنیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_details">
      <source>Details:</source>
      <translation variants="yes">
        <lengthvariant priority="1">تفصیلات:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_connecting">
      <source>Connecting</source>
      <translation variants="no">متصل کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_opt_install">
      <source>Install</source>
      <translation variants="no">تنصیب کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_member">
      <source>Add member</source>
      <translation variants="no">ممبر شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_info_requesting">
      <source>Requesting</source>
      <translation variants="no">درخواست کی جا رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_folder">
      <source>Select folder:</source>
      <translation variants="yes">
        <lengthvariant priority="1">فولڈر منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_on">
      <source>Automatic find on</source>
      <translation variants="no">خودکار تلاش چالو</translation>
    </message>
    <message numerus="no" id="txt_common_menu_call_verb">
      <source>Call</source>
      <translation variants="no">کال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_info_saving">
      <source>Saving</source>
      <translation variants="no">حفظ کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_opt_undo">
      <source>Undo</source>
      <translation variants="no">تبدیلی واپس</translation>
    </message>
    <message numerus="no" id="txt_common_opt_help">
      <source>Help</source>
      <translation variants="no">صارف رہنما</translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہاں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_start">
      <source>Start</source>
      <translation variants="yes">
        <lengthvariant priority="1">شروع کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_print">
      <source>Print</source>
      <translation variants="no">چھاپیں</translation>
    </message>
    <message numerus="no" id="txt_common_button_call">
      <source>Call</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_change">
      <source>Change</source>
      <translation variants="yes">
        <lengthvariant priority="1">بدلیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_organise">
      <source>Organise</source>
      <translation variants="no">منظم کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_help">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">صارف رہنما</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_moving">
      <source>Moving</source>
      <translation variants="no">منتقل کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_opt_internet_call">
      <source>Internet call</source>
      <translation variants="no">انٹرنیٹ کال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">تفصیل شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_unmute">
      <source>Unmute</source>
      <translation variants="no">آواز چالو کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_out">
      <source>Zoom out</source>
      <translation variants="no">چھوٹا کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_clear">
      <source>Clear</source>
      <translation variants="yes">
        <lengthvariant priority="1">صاف کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_video_call">
      <source>Video call</source>
      <translation variants="no">ویڈیو کال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_call_noun">
      <source>Call</source>
      <translation variants="no">کال</translation>
    </message>
    <message numerus="no" id="txt_common_opt_disconnect">
      <source>Disconnect</source>
      <translation variants="no">غیر متصل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_info_deleting">
      <source>Deleting</source>
      <translation variants="no">مٹا رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_opt_chat">
      <source>Chat</source>
      <translation variants="no">بات چیت کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_preview_video">
      <source>Preview</source>
      <translation variants="no">پیش جائزہ</translation>
    </message>
    <message numerus="no" id="txt_common_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">ارسال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_attachments">
      <source>Attachments</source>
      <translation variants="no">منسلکات</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_first_name">
      <source>First name:</source>
      <translation variants="no">پہلا نام:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_recipient">
      <source>Add recipient</source>
      <translation variants="no">وصول کنندہ شامل</translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_process">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">کارآمد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_address">
      <source>Address:</source>
      <translation variants="no">پتہ:</translation>
    </message>
    <message numerus="no" id="txt_common_button_select">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_find">
      <source>Find</source>
      <translation variants="no">تلاش کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_uninstall">
      <source>Uninstall</source>
      <translation variants="no">تنصیب رد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_bookmark">
      <source>Add bookmark</source>
      <translation variants="no">بطور نشا. کتاب حفظ</translation>
    </message>
    <message numerus="no" id="txt_common_opt_save">
      <source>Save</source>
      <translation variants="no">حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_object">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">کارآمد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_writing_language">
      <source>Writing language:</source>
      <translation variants="yes">
        <lengthvariant priority="1">تحریر کی زبان:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_disconnecting">
      <source>Disconnecting</source>
      <translation variants="no">غیر متصل کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_button_answer">
      <source>Answer</source>
      <translation variants="yes">
        <lengthvariant priority="1">جواب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_in">
      <source>Zoom in</source>
      <translation variants="no">بڑا کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">لاؤڈاسپیکر فعال</translation>
    </message>
    <message numerus="no" id="txt_common_info_installing">
      <source>Installing</source>
      <translation variants="no">تنصیب ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_common_menu_disable">
      <source>Disable</source>
      <translation variants="no">غیر فعال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_date">
      <source>Date:</source>
      <translation variants="no">تاریخ:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_organise">
      <source>Organise</source>
      <translation variants="no">منظم کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_move">
      <source>Move</source>
      <translation variants="no">منتقل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_additional_details">
      <source>Additional details</source>
      <translation variants="no">اضافی تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_common_menu_create_message">
      <source>Create message</source>
      <translation variants="no">پیغام تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_paste">
      <source>Paste</source>
      <translation variants="no">چسپاں کریں</translation>
    </message>
    <message numerus="no" id="txt_common_info_inserting">
      <source>Inserting</source>
      <translation variants="no">داخل کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_opt_details">
      <source>Details</source>
      <translation variants="no">تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_common_menu_move_to_folder">
      <source>Move to folder</source>
      <translation variants="no">فولڈر میں منتقل</translation>
    </message>
    <message numerus="no" id="txt_common_menu_undo">
      <source>Undo</source>
      <translation variants="no">تبدیلی واپس</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone3">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹون منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_uninstall">
      <source>Uninstall</source>
      <translation variants="no">تنصیب رد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_find">
      <source>Find</source>
      <translation variants="yes">
        <lengthvariant priority="1">تلاش کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_play_music">
      <source>Play</source>
      <translation variants="no">چلائیں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_folder_name">
      <source>Folder name:</source>
      <translation variants="no">فولڈر نام:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_call_verb">
      <source>Call</source>
      <translation variants="no">کال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_thumbnail">
      <source>Add thumbnail</source>
      <translation variants="no">مختصر تصویر شامل</translation>
    </message>
    <message numerus="no" id="txt_common_button_play_audio">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">چلائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_title_select_file">
      <source>Select file:</source>
      <translation variants="yes">
        <lengthvariant priority="1">فائل منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_registering">
      <source>Registering</source>
      <translation variants="no">اندراج کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="no">روابط میں حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_bookmark_name">
      <source>Bookmark name:</source>
      <translation variants="no">نام نشانی کتاب:</translation>
    </message>
    <message numerus="no" id="txt_common_button_save">
      <source>Save</source>
      <translation variants="yes">
        <lengthvariant priority="1">حفظ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_cut">
      <source>Cut</source>
      <translation variants="no">کاٹیں</translation>
    </message>
    <message numerus="no" id="txt_common_info_buffering">
      <source>Buffering</source>
      <translation variants="no">بفر کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_menu_video_call">
      <source>Video call</source>
      <translation variants="no">ویڈیو کال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name1">
      <source>Name:</source>
      <translation variants="no">نام:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_about_application">
      <source>About application</source>
      <translation variants="no">پروگرام کے متعلق</translation>
    </message>
    <message numerus="no" id="txt_common_opt_preview_audio">
      <source>Preview</source>
      <translation variants="no">پیش جائزہ</translation>
    </message>
    <message numerus="no" id="txt_common_button_reply">
      <source>Reply</source>
      <translation variants="yes">
        <lengthvariant priority="1">جواب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_change">
      <source>Change</source>
      <translation variants="no">بدلیں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_recipient">
      <source>Add recipient</source>
      <translation variants="no">وصول کنندہ شامل</translation>
    </message>
    <message numerus="no" id="txt_common_opt_edit">
      <source>Edit</source>
      <translation variants="no">ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_expand">
      <source>Expand</source>
      <translation variants="yes">
        <lengthvariant priority="1">پھیلائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_from_contacts">
      <source>Add from Contacts</source>
      <translation variants="no">روابط سے شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_from">
      <source>From:</source>
      <translation variants="no">از:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate_handsfree">
      <source>Activate handset</source>
      <translation variants="no">ہینڈسیٹ کارآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_open">
      <source>Open</source>
      <translation variants="no">کھولیں</translation>
    </message>
    <message numerus="no" id="txt_common_title_web_address">
      <source>Web address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویب پتہ منتخب کریں: </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_resume">
      <source>Resume</source>
      <translation variants="yes">
        <lengthvariant priority="1">بحال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_voice_call">
      <source>Voice call</source>
      <translation variants="no">صوتی کال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_install">
      <source>Install</source>
      <translation variants="no">تنصیب کریں</translation>
    </message>
    <message numerus="no" id="txt_common_info_initialising">
      <source>Initialising</source>
      <translation variants="no">آغاز کاری ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">منسوخ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_details">
      <source>Details</source>
      <translation variants="no">تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_out">
      <source>Zoom out</source>
      <translation variants="no">چھوٹا کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_fit_to_screen">
      <source>Fit to screen</source>
      <translation variants="no">اسکرین کے مطابق</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_address">
      <source>Select address:</source>
      <translation variants="yes">
        <lengthvariant priority="1">پتہ منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_rename_people">
      <source>Rename</source>
      <translation variants="no">دوبارہ نام دیں</translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_audio">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیشگی مشاہدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_mark">
      <source>Mark</source>
      <translation variants="no">نشان زد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_insert">
      <source>Insert</source>
      <translation variants="no">داخل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_bookmark">
      <source>Add bookmark</source>
      <translation variants="no">بطور نشان کتاب حفظ</translation>
    </message>
    <message numerus="no" id="txt_common_opt_forward">
      <source>Forward</source>
      <translation variants="no">آگے ارسال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_rename_item">
      <source>Rename</source>
      <translation variants="no">دوبارہ نام دیں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_remove">
      <source>Remove</source>
      <translation variants="no">نکال دیں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmute">
      <source>Unmute</source>
      <translation variants="no">آواز چالو کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_call_noun">
      <source>Call</source>
      <translation variants="no">کال</translation>
    </message>
    <message numerus="no" id="txt_common_button_reject">
      <source>Reject</source>
      <translation variants="yes">
        <lengthvariant priority="1">مسترد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_replace">
      <source>Replace</source>
      <translation variants="no">تبدیل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_cancel_download">
      <source>Cancel download</source>
      <translation variants="no">ڈاؤن لوڈ منسوخ کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate">
      <source>Activate</source>
      <translation variants="no">کارآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name2">
      <source>New name:</source>
      <translation variants="no">نیا نام:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_chat">
      <source>Chat</source>
      <translation variants="no">بات چیت کریں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_new_password">
      <source>Verify new password:</source>
      <translation variants="no">نئے لفظ شناخت کی تصدیق:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_play_video">
      <source>Play</source>
      <translation variants="no">چلائیں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_duration">
      <source>Duration:</source>
      <translation variants="no">مدت:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_exit">
      <source>Exit</source>
      <translation variants="no">باہر نکلیں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_current_password">
      <source>Current password:</source>
      <translation variants="no">موجودہ لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_internet_call">
      <source>Internet call</source>
      <translation variants="no">انٹرنیٹ کال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_install">
      <source>Install</source>
      <translation variants="yes">
        <lengthvariant priority="1">تنصیب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_disable">
      <source>Disable</source>
      <translation variants="no">غیر فعال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_off">
      <source>Automatic find off</source>
      <translation variants="no">خودکار تلاش بند</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_to">
      <source>To:</source>
      <translation variants="no">برائے:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">برتر ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_common_opt_create_message">
      <source>Create message</source>
      <translation variants="no">پیغام تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_member">
      <source>Add member</source>
      <translation variants="no">ممبر شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_remove">
      <source>Remove</source>
      <translation variants="no">نکالیں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_message">
      <source>Send message</source>
      <translation variants="no">پیغام ارسال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_paste">
      <source>Paste</source>
      <translation variants="yes">
        <lengthvariant priority="1">چسپاں کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">کھولیں</translation>
    </message>
    <message numerus="no" id="txt_common_button_menu">
      <source>Menu</source>
      <translation variants="yes">
        <lengthvariant priority="1">فہرست</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_continue">
      <source>Continue</source>
      <translation variants="no">جاری رکھیں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_image">
      <source>Add image</source>
      <translation variants="no">شبیہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_find">
      <source>Find</source>
      <translation variants="no">تلاش کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">لاؤڈاسپیکر غیر فعال</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_detail">
      <source>Add detail</source>
      <translation variants="no">تفصیل شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_info_retrieving">
      <source>Retrieving</source>
      <translation variants="no">بازیافت ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name1">
      <source>New name:</source>
      <translation variants="no">نیا نام:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_fit_to_screen">
      <source>Fit to screen</source>
      <translation variants="no">اسکرین مطابق</translation>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate">
      <source>Deactivate</source>
      <translation variants="no">غیرکارآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="no">روابط میں شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_voice_call">
      <source>Voice call</source>
      <translation variants="no">صوتی کال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_attachments">
      <source>Attachments</source>
      <translation variants="no">منسلکات</translation>
    </message>
    <message numerus="no" id="txt_common_button_replace">
      <source>Replace</source>
      <translation variants="yes">
        <lengthvariant priority="1">تبدیل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_go_to_web_address">
      <source>Go to web address</source>
      <translation variants="no">ویب پتے پر جائیں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_thumbnail">
      <source>Add thumbnail</source>
      <translation variants="no">مختصر تصویر شامل</translation>
    </message>
    <message numerus="no" id="txt_common_button_unmute">
      <source>Unmute</source>
      <translation variants="yes">
        <lengthvariant priority="1">آواز چالو کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_handset">
      <source>Handset</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہینڈسیٹ کارآمد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_retry">
      <source>Retry</source>
      <translation variants="yes">
        <lengthvariant priority="1">دوبارہ کوشش کریں</lengthvariant>
        <lengthvariant priority="2">دوبارہ کوشش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_user_id">
      <source>User ID:</source>
      <translation variants="no">صارف شناخت:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate_handsfree">
      <source>Activate handset</source>
      <translation variants="no">ہینڈسیٹ کارآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">غیر متصل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_join">
      <source>Join</source>
      <translation variants="yes">
        <lengthvariant priority="1">شامل ہوں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_in">
      <source>Zoom in</source>
      <translation variants="no">بڑا کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">لاؤڈاسپیکر غیر فعال</translation>
    </message>
    <message numerus="no" id="txt_common_info_closing">
      <source>Closing</source>
      <translation variants="no">بند ہو رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_file_name">
      <source>File name:</source>
      <translation variants="no">فائل نام:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmark">
      <source>Unmark</source>
      <translation variants="no">نشان رد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_show">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">ظاہر کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_unmark">
      <source>Unmark</source>
      <translation variants="no">نشان رد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_folder">
      <source>Add to folder</source>
      <translation variants="no">فولڈر میں شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_mute">
      <source>Mute</source>
      <translation variants="yes">
        <lengthvariant priority="1">آواز بند کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_phone_number">
      <source>Phone number:</source>
      <translation variants="no">فون نمبر:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_pause">
      <source>Pause</source>
      <translation variants="no">موقوف کریں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_new_password">
      <source>New password:</source>
      <translation variants="no">نیا لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_common_menu_connect">
      <source>Connect</source>
      <translation variants="no">متصل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_item">
      <source>Send</source>
      <translation variants="no">ارسال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_add">
      <source>Add</source>
      <translation variants="yes">
        <lengthvariant priority="1">شامل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_copy">
      <source>Copy</source>
      <translation variants="yes">
        <lengthvariant priority="1">نقل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_copy_to_folder">
      <source>Copy to folder</source>
      <translation variants="no">فولڈر میں نقل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_info_cancelling">
      <source>Cancelling</source>
      <translation variants="no">منسوخ کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_opt_activate">
      <source>Activate</source>
      <translation variants="no">کارآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_play_video">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">چلائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_record_video">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">ریکارڈ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_common_button_options">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">اختیارات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_pause">
      <source>Pause</source>
      <translation variants="no">موقوف کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_play_video">
      <source>Play</source>
      <translation variants="no">چلائیں</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_language">
      <source>Select language:</source>
      <translation variants="yes">
        <lengthvariant priority="1">زبان منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">لاؤڈاسپیکر فعال</translation>
    </message>
    <message numerus="no" id="txt_common_menu_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">روابط میں حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">دوبارہ مرتب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_pause">
      <source>Pause</source>
      <translation variants="yes">
        <lengthvariant priority="1">موقوف کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_password">
      <source>Password:</source>
      <translation variants="no">لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_common_button_read">
      <source>Read</source>
      <translation variants="yes">
        <lengthvariant priority="1">پڑھیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_continue">
      <source>Continue</source>
      <translation variants="no">جاری رکھیں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_select">
      <source>Select</source>
      <translation variants="no">منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_quit">
      <source>Quit</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترک کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_back">
      <source>Back</source>
      <translation variants="no">واپس</translation>
    </message>
    <message numerus="no" id="txt_common_button_edit">
      <source>Edit</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترمیم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_insert">
      <source>Insert</source>
      <translation variants="no">داخل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_copy">
      <source>Copy</source>
      <translation variants="no">نقل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_copy_to_folder">
      <source>Copy to folder</source>
      <translation variants="no">فولڈر میں نقل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate">
      <source>Deactivate</source>
      <translation variants="no">غیرکارآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_enable">
      <source>Enable</source>
      <translation variants="no">فعال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_info_adding">
      <source>Adding</source>
      <translation variants="no">شامل کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_button_reject_toolbar">
      <source>Reject</source>
      <translation variants="yes">
        <lengthvariant priority="1">مسترد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_send_toolbar">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">بھیجیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel_toolbar">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">منسوخ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_no_toolbar">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_answer_toolbar">
      <source>Answer</source>
      <translation variants="yes">
        <lengthvariant priority="1">جواب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_uninstall">
      <source>Uninstall</source>
      <translation variants="yes">
        <lengthvariant priority="1">تنصیب رد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_message">
      <source>Send message</source>
      <translation variants="no">پیغام ارسال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_settings">
      <source>Settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_common_button_disable">
      <source>Disable</source>
      <translation variants="yes">
        <lengthvariant priority="1">غیرفعال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_on">
      <source>Automatic find on</source>
      <translation variants="no">خودکار تلاش چالو</translation>
    </message>
    <message numerus="no" id="txt_common_button_move">
      <source>Move</source>
      <translation variants="yes">
        <lengthvariant priority="1">منتقل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_info_processing">
      <source>Processing</source>
      <translation variants="no">عمل جاری</translation>
    </message>
    <message numerus="no" id="txt_common_menu_save">
      <source>Save</source>
      <translation variants="no">حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_details_dialog">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_format">
      <source>Format </source>
      <translation variants="no">فارمیٹ</translation>
    </message>
    <message numerus="no" id="txt_common_button_deactivate_dialog">
      <source>Deactivate</source>
      <translation variants="yes">
        <lengthvariant priority="1">غیرکارآمد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_deselect_dialog">
      <source>Deselect</source>
      <translation variants="yes">
        <lengthvariant priority="1">انتخاب رد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_unmark_all_items">
      <source>Deselect all items</source>
      <translation variants="no">آئیٹمز کا انتخاب رد</translation>
    </message>
    <message numerus="no" id="txt_common_button_disconnect">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">غیر متصل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_disconnect_dialog">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">غیر متصل کریں</lengthvariant>
        <lengthvariant priority="2">غیر متصل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_paste">
      <source>Paste</source>
      <translation variants="no">چسپاں کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_select_all_contents">
      <source>Select all contents</source>
      <translation variants="no">مشمولات منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_continue_dialog">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">جاری رکھیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_collapse_dialog">
      <source>Collapse</source>
      <translation variants="yes">
        <lengthvariant priority="1">سمیٹیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel_singledialog">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">منسوخ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_settings_dialog">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_play_video_dialog">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">چلائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_last_name">
      <source>Last name:</source>
      <translation variants="no">آخری نام:</translation>
    </message>
    <message numerus="no" id="txt_common_button_move_dialog">
      <source>Move</source>
      <translation variants="yes">
        <lengthvariant priority="1">منتقل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_deselect">
      <source>Deselect</source>
      <translation variants="yes">
        <lengthvariant priority="1">انتخاب رد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_help_dialog">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">صارف رہنما</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_unmute_dialog">
      <source>Unmute</source>
      <translation variants="yes">
        <lengthvariant priority="1">آواز چالو کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_handset_dialog">
      <source>Handset</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہینڈسیٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_list_mark_all_items">
      <source>Select all items</source>
      <translation variants="no">ur #Select all items</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_tone2">
      <source>Select tone:</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹون منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_reset_dialog">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">دوبارہ مرتب</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_list_unmark_all_items">
      <source>Deselect all items</source>
      <translation variants="no">ur #Deselect all items</translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_on_dialog">
      <source>Loudsp. on</source>
      <translation variants="yes">
        <lengthvariant priority="1">لاؤڈاسپیکر چالو کریں</lengthvariant>
        <lengthvariant priority="2">اسپیکر چالو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_close_singledialog">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_back_dialog">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">واپس</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_disable_dialog">
      <source>Disable</source>
      <translation variants="yes">
        <lengthvariant priority="1">غیرفعال کریں</lengthvariant>
        <lengthvariant priority="2">غیرفعال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_connect_dialog">
      <source>Connect</source>
      <translation variants="yes">
        <lengthvariant priority="1">متصل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_done_single_dialog">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">مکمل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_format">
      <source>Format </source>
      <translation variants="no">فارمیٹ</translation>
    </message>
    <message numerus="no" id="txt_common_button_options_dialog">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">اختیارات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_save_dialog">
      <source>Save</source>
      <translation variants="yes">
        <lengthvariant priority="1">حفظ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_on">
      <source>Loudsp. on</source>
      <translation variants="yes">
        <lengthvariant priority="1">لاؤڈاسپیکر چالو کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_remove_dialog">
      <source>Remove</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_copy_dialog">
      <source>Copy</source>
      <translation variants="yes">
        <lengthvariant priority="1">نقل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_about_application">
      <source>About application</source>
      <translation variants="no">پروگرام کے متعلق</translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_audio_dialog">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیشگی مشاہدہ</lengthvariant>
        <lengthvariant priority="2">پیش مشاہدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_close_dialog">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_deselect">
      <source>Deselect</source>
      <translation variants="no">انتخاب رد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_item">
      <source>Send</source>
      <translation variants="no">ارسال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_print">
      <source>Print</source>
      <translation variants="no">چھاپیں</translation>
    </message>
    <message numerus="no" id="txt_common_button_uninstall_dialog">
      <source>Uninstall</source>
      <translation variants="yes">
        <lengthvariant priority="1">تنصیب رد کریں</lengthvariant>
        <lengthvariant priority="2">تنصیب رد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_unmark_all_items">
      <source>Deselect all items</source>
      <translation variants="no">آئیٹمز کا انتخاب رد</translation>
    </message>
    <message numerus="no" id="txt_common_button_open_dialog">
      <source>Open</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھولیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_find_dialog">
      <source>Find</source>
      <translation variants="yes">
        <lengthvariant priority="1">تلاش کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_add_dialog">
      <source>Add</source>
      <translation variants="yes">
        <lengthvariant priority="1">شامل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_enable_dialog">
      <source>Enable</source>
      <translation variants="yes">
        <lengthvariant priority="1">فعال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_read_dialog">
      <source>Read</source>
      <translation variants="yes">
        <lengthvariant priority="1">پڑھیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_edit">
      <source>Edit</source>
      <translation variants="no">ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_move">
      <source>Move</source>
      <translation variants="no">منتقل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">روابط میں حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_off">
      <source>Loudsp. off</source>
      <translation variants="yes">
        <lengthvariant priority="1">لاؤڈاسپیکر بند کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_from_contacts">
      <source>Add from Contacts</source>
      <translation variants="no">روابط سے شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_mark">
      <source>Mark</source>
      <translation variants="no">نشان زد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_record_audio">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">ریکارڈ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_mark">
      <source>Mark</source>
      <translation variants="yes">
        <lengthvariant priority="1">نشان زد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_password">
      <source>Verify password:</source>
      <translation variants="no">لفظ شناخت کی تصدیق:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_rename_item">
      <source>Rename</source>
      <translation variants="no">دوبارہ نام دیں</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_end_date">
      <source>End date:</source>
      <translation variants="no">تاریخ اختتام:</translation>
    </message>
    <message numerus="no" id="txt_common_info_unistalling">
      <source>Uninstalling</source>
      <translation variants="no">تنصیب رد ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_common_opt_select">
      <source>Select</source>
      <translation variants="no">منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_preview_audio">
      <source>Preview</source>
      <translation variants="no">پیش جائزہ</translation>
    </message>
    <message numerus="no" id="txt_common_button_remove">
      <source>Remove</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_change">
      <source>Change</source>
      <translation variants="no">بدلیں</translation>
    </message>
    <message numerus="no" id="txt_common_info_loading">
      <source>Loading</source>
      <translation variants="no">لوڈنگ ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_common_opt_delete">
      <source>Delete</source>
      <translation variants="no">مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_common_button_define_dialog">
      <source>Define</source>
      <translation variants="yes">
        <lengthvariant priority="1">وضاحت کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_join_dialog">
      <source>Join</source>
      <translation variants="yes">
        <lengthvariant priority="1">شامل ہوں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok_single_dialog">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹھیک ہے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_done_dialog">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">مکمل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_pause_dialog">
      <source>Pause</source>
      <translation variants="yes">
        <lengthvariant priority="1">موقوف کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_listen_dialog">
      <source>Listen</source>
      <translation variants="yes">
        <lengthvariant priority="1">سنیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_start_dialog">
      <source>Start</source>
      <translation variants="yes">
        <lengthvariant priority="1">شروع کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_stop_singledialog">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">روکیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_change_dialog">
      <source>Change</source>
      <translation variants="yes">
        <lengthvariant priority="1">بدلیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_disconnect_singledialog">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">غیر متصل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_resume_dialog">
      <source>Resume</source>
      <translation variants="yes">
        <lengthvariant priority="1">بحال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_exit">
      <source>Exit</source>
      <translation variants="yes">
        <lengthvariant priority="1">باہر نکلیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_replace_dialog">
      <source>Replace</source>
      <translation variants="yes">
        <lengthvariant priority="1">تبدیل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_retry_dialog">
      <source>Retry</source>
      <translation variants="yes">
        <lengthvariant priority="1">دوبارہ کوشش کریں</lengthvariant>
        <lengthvariant priority="2">پھر کوشش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_show_dialog">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">ظاہر کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_stop_dialog">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">روکیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_select_all_contents">
      <source>Select all contents</source>
      <translation variants="no">مشمولات منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_expand_dialog">
      <source>Expand</source>
      <translation variants="yes">
        <lengthvariant priority="1">پھیلائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_call_dialog">
      <source>Call</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_done">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">مکمل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_mark_all_items">
      <source>Select all items</source>
      <translation variants="no">آئیٹمز منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_unmark_dialog">
      <source>Unmark</source>
      <translation variants="yes">
        <lengthvariant priority="1">نشانرد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_mute_dialog">
      <source>Mute</source>
      <translation variants="yes">
        <lengthvariant priority="1">آواز بند کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_clear_toolbar">
      <source>Clear</source>
      <translation variants="yes">
        <lengthvariant priority="1">صاف کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_delete_toolbar">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">مٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_record_video_dialog">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">ریکارڈ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_select_dialog">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_mark_all_items">
      <source>Select all items</source>
      <translation variants="no">آئیٹمز منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_reply_dialog">
      <source>Reply</source>
      <translation variants="yes">
        <lengthvariant priority="1">جواب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_paste_dialog">
      <source>Paste</source>
      <translation variants="yes">
        <lengthvariant priority="1">چسپاں کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_hide_single_dialog">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">چھپائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_deselect">
      <source>Deselect</source>
      <translation variants="no">انتخاب رد کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_off_dialog">
      <source>Loudsp. off</source>
      <translation variants="yes">
        <lengthvariant priority="1">لاؤڈاسپیکر بند کریں</lengthvariant>
        <lengthvariant priority="2">اسپیکر بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_edit_dialog">
      <source>Edit</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترمیم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_finish_dialog">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">ختم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_go_to_web_address">
      <source>Go to web address</source>
      <translation variants="no">ویب پتے پر جائیں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_cancel_download">
      <source>Cancel download</source>
      <translation variants="no">ڈاؤن لوڈ منسوخ کریں</translation>
    </message>
    <message numerus="no" id="txt_common_info_searching">
      <source>Searching</source>
      <translation variants="no">تلاش کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_expires">
      <source>Expires:</source>
      <translation variants="no">خاتمہ:</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹھیک ہے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_unmark">
      <source>Unmark</source>
      <translation variants="yes">
        <lengthvariant priority="1">نشان رد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_stop">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">روکیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_define">
      <source>Define</source>
      <translation variants="yes">
        <lengthvariant priority="1">وضاحت کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_rename_people">
      <source>Rename</source>
      <translation variants="no">دوبارہ نام دیں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_exit">
      <source>Exit</source>
      <translation variants="no">باہر نکلیں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_folder">
      <source>Add to folder</source>
      <translation variants="no">فولڈر میں شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_off">
      <source>Automatic find off</source>
      <translation variants="no">خودکار تلاش بند</translation>
    </message>
    <message numerus="no" id="txt_common_button_back">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">واپس</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_settings">
      <source>Settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_common_menu_preview_video">
      <source>Preview</source>
      <translation variants="no">پیش جائزہ</translation>
    </message>
    <message numerus="no" id="txt_common_button_open">
      <source>Open</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھولیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_forward">
      <source>Forward</source>
      <translation variants="no">آگے ارسال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_insert">
      <source>Insert</source>
      <translation variants="yes">
        <lengthvariant priority="1">داخل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_enable">
      <source>Enable</source>
      <translation variants="yes">
        <lengthvariant priority="1">فعال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_add_image">
      <source>Add image</source>
      <translation variants="no">شبیہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_video">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیشگی مشاہدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_replace">
      <source>Replace</source>
      <translation variants="no">تبدیل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_connect">
      <source>Connect</source>
      <translation variants="no">متصل کریں</translation>
    </message>
    <message numerus="no" id="txt_common_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">برتر ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_common_dialog_title">
      <source>Title:</source>
      <translation variants="no">عنوان:</translation>
    </message>
    <message numerus="no" id="txt_common_opt_additional_details">
      <source>Additional details</source>
      <translation variants="no">مزید معلومات</translation>
    </message>
    <message numerus="no" id="txt_common_title_select_memory">
      <source>Select memory:</source>
      <translation variants="yes">
        <lengthvariant priority="1">حافظہ منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_enable">
      <source>Enable</source>
      <translation variants="no">فعال کریں</translation>
    </message>
    <message numerus="no" id="txt_common_button_finish">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">ختم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_hide">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">چھپائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">مٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_play_music">
      <source>Play</source>
      <translation variants="no">چلائیں</translation>
    </message>
    <message numerus="no" id="txt_common_menu_cut">
      <source>Cut</source>
      <translation variants="no">کاٹیں</translation>
    </message>
    <message numerus="no" id="txt_common_button_connect">
      <source>Connect</source>
      <translation variants="yes">
        <lengthvariant priority="1">متصل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_continue">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">جاری رکھیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_yes_toolbar">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہاں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok_toolbar">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹھیک ہے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_hide_toolbar">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">چھپائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_preview_video_dialog">
      <source>Preview</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیشگی مشاہدہ</lengthvariant>
        <lengthvariant priority="2">پیش مشاہدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_install_dialog">
      <source>Install</source>
      <translation variants="yes">
        <lengthvariant priority="1">تنصیب کریں</lengthvariant>
        <lengthvariant priority="2">تنصیب</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_finish_single_dialog">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">ختم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_quit_dialog">
      <source>Quit</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترک کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_play_audio_dialog">
      <source>Play</source>
      <translation variants="yes">
        <lengthvariant priority="1">چلائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_process_dialog">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">کارآمد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_activate_object_dialog">
      <source>Activate</source>
      <translation variants="yes">
        <lengthvariant priority="1">کارآمد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_exit_dialog">
      <source>Exit</source>
      <translation variants="yes">
        <lengthvariant priority="1">باہر نکلیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_insert_dialog">
      <source>Insert</source>
      <translation variants="yes">
        <lengthvariant priority="1">داخل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_mark_dialog">
      <source>Mark</source>
      <translation variants="yes">
        <lengthvariant priority="1">نشان زد کریں</lengthvariant>
        <lengthvariant priority="2">نشانزد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_record_audio_dialog">
      <source>Record</source>
      <translation variants="yes">
        <lengthvariant priority="1">ریکارڈ کریں</lengthvariant>
      </translation>
    </message>
  </context>
</TS>