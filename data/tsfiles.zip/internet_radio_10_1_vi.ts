<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_irad_opt_go_to_station">
      <source>Go to station</source>
      <translation variants="no">Chuyển đến trạm</translation>
    </message>
    <message numerus="no" id="txt_irad_info_connecting_timout">
      <source>Connecting timeout</source>
      <translation variants="no">Hết giờ kết nối</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_search_in_music_store">
      <source>Search in music store</source>
      <translation variants="no">Tìm trong Cửa hàng nhạc</translation>
    </message>
    <message numerus="no" id="txt_irad_title_internet_radio">
      <source>Internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">Internet radio</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_favorite_updated">
      <source>Favorite updated</source>
      <translation variants="no">Đã thêm trạm vào mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_long_caption_internetradio">
      <source>Internet Radio</source>
      <translation variants="no">Internet radio</translation>
    </message>
    <message numerus="no" id="txt_irad_info_downloading_logos">
      <source>Downloading logos</source>
      <translation variants="no">Đang tải về biểu tượng</translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_language">
      <source>Stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm theo ngôn ngữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_standard">
      <source>Standard</source>
      <translation variants="no">Chuẩn</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_share">
      <source>Share</source>
      <translation variants="no">Chia sẻ</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_country_region">
      <source>Stations by country/region</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm theo quốc gia/vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_language">
      <source>Stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm theo ngôn ngữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_station_name">
      <source>Station name</source>
      <translation variants="no">Tên trạm</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_songs">
      <source>Songs played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bài hát đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_country_region">
      <source>Stations by country/region</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm theo quốc gia/vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality">
      <source>Download quality</source>
      <translation variants="no">Chất lượng tải về</translation>
    </message>
    <message numerus="no" id="txt_irad_info_music_store_not_available">
      <source>Music store not available</source>
      <translation variants="no">Cửa hàng nhạc không có sẵn</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_from_play_list">
      <source>Stations from play list</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm trong danh sách bài hát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_high">
      <source>High</source>
      <translation variants="no">Cao</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_network_setting">
      <source>Network setting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt mạng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_stations">
      <source>Stations played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_share">
      <source>Share</source>
      <translation variants="no">Chia sẻ</translation>
    </message>
    <message numerus="no" id="txt_irad_info_song_recognition_not_available">
      <source>Song recognition not available</source>
      <translation variants="no">Nhận dạng bài hát không có sẵn</translation>
    </message>
    <message numerus="no" id="txt_irad_info_failed_to_connect">
      <source>Connecting failed</source>
      <translation variants="no">Không thể kết nối</translation>
    </message>
    <message numerus="no" id="txt_irad_info_share_not_available">
      <source>Share not available</source>
      <translation variants="no">Chia sẻ trạm không có sẵn</translation>
    </message>
    <message numerus="no" id="txt_irad_info_details_not_available">
      <source>Details not available</source>
      <translation variants="no">Không có sẵn chi tiết bài hát</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_disclaimer_and_liability">
      <source>DISCLAIMER AND LIABILITY</source>
      <translation variants="no">MIỄN TRỪ TRÁCH NHIỆM VÀ NGHĨA VỤ PHÁP LỸ</translation>
    </message>
    <message numerus="no" id="txt_irad_info_unnamed_station">
      <source>Unnamed station</source>
      <translation variants="no">Chưa đặt tên</translation>
    </message>
    <message numerus="no" id="txt_irad_info_policy_copyright_content">
      <source>If you believe that your copyrighted work has been handled in a way that constitutes copyright infringement, you may notify Nokia by providing a notification including the following:\n\n(1) A physical or electronic signature of a person authorised to act on behalf of the owner of the exclusive right that is allegedly infringed;\n\n(2) Identification or description of the copyrighted work claimed to have been infringed;\n\n(3) Identification or description of the material that is claimed to be infringing and information reasonably sufficient to locate the material;\n\n(4) Your name, address, telephone number, e-mail address and any other information that will permit Nokia to contact you;\n\n(5) A statement that you believe, in good faith, that use of the material in the manner on which this complaint is based is not authorised by the copyright owner, its agent or the law; and\n\n(6) A statement that the information in the notification is accurate and, under penalty of perjury, that you are authorised to act on behalf of the owner of an exclusive right that is allegedly infringed.\n\nThe notification must be sent to our Designated Agent address at:\n\nCopyright.Notices@nokia.com
</source>
      <translation variants="no">Nếu bạn tin rằng tác phẩm có bản quyền của mình đã bị xử lý theo cách cấu thành việc vi phạm bản quyền, bạn có thể thông báo cho Nokia bằng cách cung cấp thông báo bao gồm những điều sau:

(1) Chữ ký thật hoặc chữ ký điện tử của người được ủy quyền hành động thay mặt chủ sở hữu bản quyền duy nhất được cho là bị vi phạm;

(2) Giấy chứng minh hoặc mô tả tác phẩm có bản quyền được cho là đã bị vi phạm;

(3) Giấy chứng minh hoặc mô tả của tài liệu được cho là bị vi phạm và thông tin đủ hợp lý để tìm tài liệu;

(4) Tên, địa chỉ, số điện thoại, địa chỉ e-mail và bất kỳ thông tin nào khác của bạn sẽ cho phép Nokia liên hệ với bạn;

(5) Tuyên bố rằng bạn thành thực tin rằng việc sử dụng tài liệu đó theo cách mà khiếu nại này dựa vào không được chủ sở hữu bản quyền, tác nhân của chủ sở hữu hoặc pháp luật ủy quyền; và

(6) Tuyên bố rằng thông tin trong thông báo chính xác và, theo hình phạt về tội khai man, bạn được ủy quyền để đại diện chủ sở hữu bản quyền duy nhất được cho là bị vi phạm hành động.

Thông báo phải được đến địa chỉ Đại lý Được chỉ định của chúng tôi:

Copyright.Notices@nokia.com
</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_delete_stations">
      <source>Remove stations</source>
      <translation variants="no">Xóa trạm</translation>
    </message>
    <message numerus="no" id="txt_irad_info_disclaimer_and_liability_content_1">
      <source>For your ease of accessibility, Nokia may include links to Internet radio stations that are owned or operated by third parties. Nokia does not guarantee that the links to Internet radio stations will be operational. In addition, the content that is not related to Nokia does not imply whatsoever that Nokia endorses the content as such or the products or services referenced in such content.\n\nYou must review and agree to each station's rules of use, if any, before accessing it. You also agree that Nokia has no control over the content of third-party services and cannot assume any responsibility for the content provided by Internet radio stations.\n\nAccessing the content of Internet radio stations using the Service may involve the transmission of large amounts of data through your service provider's network. Contact your service provider for information about data transmission charges. Note that using the Service with Internet radio stations that are delivering higher bit rate streams to you may incur higher costs associated with data traffic.\n\nThe data traffic associated with the usage of the Service may include the following at least: updating the content of the stations’ directory, streaming data from the Internet radio station, collecting statistical data and upgrading the Internet radio application.\n\nNokia is not liable for the costs of data traffic associated with your use of the Service.\n\n</source>
      <translation variants="no">Để bạn dễ dàng truy cập, Nokia có thể bao gồm các liên kết đến trạm Internet radio do đối tác thứ ba sở hữu và điều hành. Nokia không đảm bảo liên kết đến trạm Internet radio sẽ hoạt động. Ngoài ra, nội dung không có liên quan đến Nokia hoàn toàn không ngụ ý rằng Nokia xác nhận nội dung đó hoặc các sản phẩm hoặc dịch vụ được tham chiếu trong nội dung đó.

Bạn phải xem xét và đồng ý với quy tắc sử dụng của từng trạm, nếu có, trước khi truy cập trạm. Bạn cũng đồng ý rằng Nokia không kiểm soát nội dung của dịch vụ bên thứ ba và không thể thừa nhận mọi trách nhiệm pháp lý đối với nội dung được cung cấp bởi các trạm Internet radio.

Truy cập nội dung trạm Internet radio sử dụng Dịch vụ có thể phát sinh việc truyền một số lượng lớn dữ liệu qua mạng của nhà cung cấp dịch vụ của bạn. Liên hệ với nhà cung cấp dịch vụ của bạn để biết thông tin về chi phí truyền dữ liệu. Lưu ý rằng việc sử dụng Dịch vụ với trạm Internet radio sẽ phân phối các luồng có tốc độ bit cao hơn đến bạn có thể phát sinh cước phí cao hơn kết hợp với lưu lượng truy cập dữ liệu.

Lưu lượng truy cập dữ liệu kết hợp với việc sử dụng Dịch vụ có thể bao gồm ít nhất những phần sau: cập nhật nội dung của danh mục trạm, dữ liệu trực tuyến từ trạm Internet radio, thu thập dữ liệu thống kê và nâng cấp ứng dụng Internet radio.

Nokia không có nghĩa vụ về pháp lý đối với cước phí lưu lượng dữ liệu kết hợp với việc sử dụng Dịch vụ của bạn.

</translation>
    </message>
    <message numerus="no" id="txt_irad_info_governing_law_content">
      <source>As used in these terms and conditions, "Nokia" means Nokia Corporation. Nokia operates and controls the Service from locations within Finland. As such, the information contained on the Service hereby is deemed to be provided in Finland.\n\nExcept where prohibited by applicable law, these terms and conditions shall be governed by the laws of Finland without regard to conflict of law provisions. For US residents: These terms and conditions shall be governed by the laws of Texas.\n\nCopyright © Nokia Corporation 2006. All rights reserved.
</source>
      <translation variants="no">Như được sử dụng trong các điều khoản và điều kiện này, “Nokia” có nghĩa là Nokia Corporation. Nokia điều hành và kiểm soát Dịch vụ từ các địa điểm tại Phần Lan. Như vậy, thông tin có trong tài liệu Dịch vụ này được cho là được cung cấp ở Phần Lan.

Ngoại trừ ở nơi bị luật pháp hiện hành ngăn cấm, những điều khoản và điều kiện này sẽ bị chi phối bởi luật Phần Lan bất kể xung đột của các điều khoản luật. Đối với cư dân Hoa Kỳ: Các điều khoản và điều kiện này có thể bị chi phối bởi luật Texas.

Bản quyền © Nokia Corporation 2006. Đã đăng ký bản quyền.
</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_identify_song">
      <source>Identify song</source>
      <translation variants="no">Nhận diện bài hát</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_l">
      <source>Unknown artist - %1</source>
      <translation variants="no">Nghệ sĩ không biết - %1</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_search_results">
      <source>Search results</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Search results</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_settings">
      <source>Settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_irad_info_delete_station">
      <source>Remove station?</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa trạm?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_station_not_find">
      <source>Station not found</source>
      <translation variants="no">Không tìm thấy trạm</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_definitions">
      <source>DEFINITIONS</source>
      <translation variants="no">ĐỊNH NGHĨA</translation>
    </message>
    <message numerus="no" id="txt_irad_info_definitions_content">
      <source>Internet radio stations are entities that generally produce and distribute audio content and related metadata over the Internet in a stream.\n\nThe link to the Internet radio station is a resource locator or a set of resource locators that enable the user to access the content streamed by the Internet radio station.
</source>
      <translation variants="no">Trạm Internet radio là những thực thể thường tạo và phân phối nội dung âm thanh và siêu dữ liệu có liên quan trong luồng qua Internet.

Liên kết đến trạm Internet radio là bộ định vị tài nguyên hoặc một tập hợp bộ định vị tài nguyên cho phép người dùng truy cập vào nội dung được trực tuyến bởi trạm Internet radio.
</translation>
    </message>
    <message numerus="no" id="txt_irad_list_songs_recently_played">
      <source>Songs played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bài hát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by_val_custom">
      <source>Custom</source>
      <translation variants="no">Tùy chỉnh</translation>
    </message>
    <message numerus="no" id="txt_irad_info_disclaimer_and_liability_content_2">
      <source>NO WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF TITLE OR NON-INFRINGEMENT OR IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, IS MADE IN RELATION TO THE AVAILABILITY, ACCURACY, RELIABILITY OR CONTENT OF THE SERVICE. NOKIA SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR FOR BUSINESS INTERRUPTION ARISING OUT OF THE USE OF OR INABILITY TO USE THE SERVICE, EVEN IF NOKIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. SOME JURISDICTIONS DO NOT ALLOW EXCLUSION OF CERTAIN WARRANTIES OR LIMITATIONS OF LIABILITY, SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. THE LIABILITY OF NOKIA WOULD IN SUCH CASE BE LIMITED TO THE GREATEST EXTENT PERMITTED BY LAW.\n\nNothing contained herein shall prejudice the statutory rights of any party dealing as a consumer. Nothing contained herein limits Nokia's liability in the event of death or personal injury resulting from Nokia's negligence.</source>
      <translation variants="no">HOÀN TOÀN KHÔNG CÓ BẢO HÀNH, RÕ RÀNG HAY NGỤ Ý, BAO GỒM NHƯNG KHÔNG GIỚI HẠN VỀ BẢO HÀNH DANH TÍNH HOẶC KHÔNG XÂM PHẠM HOẶC BẢO ĐẢM NGỤ Ý KHẢ NĂNG BÁN ĐƯỢC HOẶC TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH CỤ THỂ, ĐƯỢC ĐƯA RA CÓ LIÊN QUAN ĐẾN TÍNH KHẢ DỤNG, ĐỘ CHÍNH XÁC, ĐỘ TIN CẬY HOẶC NỘI DUNG CỦA DỊCH VỤ. NOKIA KHÔNG CÓ NGHĨA VỤ VỀ PHÁP LÝ ĐỐI VỚI BẤT KỲ THIỆT HẠI TRỰC TIẾP, GIÁN TIẾP, NGẪU NHIÊN, ĐẶC BIỆT HOẶC DO HẬU QUẢ, MẤT MÁT LỢI NHUẬN HOẶC GIÁN ĐOẠN KINH DOANH PHÁT SINH DO VIỆC SỬ DỤNG HOẶC KHÔNG CÓ KHẢ NĂNG SỬ DỤNG DỊCH VỤ, NGAY CẢ KHI NOKIA ĐÃ ĐƯỢC BIẾT VỀ KHẢ NĂNG CÓ THỂ XẢY RA THIỆT HẠI ĐÓ. MỘT SỐ PHẠM VI QUYỀN LỰC PHÁP LÝ KHÔNG CHO PHÉP LOẠI TRỪ CÁC BẢO HÀNH NHẤT ĐỊNH HOẶC GIỚI HẠN TRÁCH NHIỆM PHÁP LÝ, DO ĐÓ CÁC GIỚI HẠN HOẶC LOẠI TRỪ Ở TRÊN CÓ THỂ KHÔNG ÁP DỤNG CHO BẠN. TRÁCH NHIỆM PHÁP LÝ CỦA NOKIA TRONG TRƯỜNG HỢP NHƯ VẬY SẼ ĐƯỢC GIỚI HẠN ĐẾN MỨC TỐI ĐA ĐƯỢC PHÁP LUẬT CHO PHÉP.

Tài liệu này không chứa bất kỳ điều gì gây tổn hại đến quyền của bất kỳ bên nào với vai trò là khách hàng được luật pháp quy định. Tài liệu này không chứa bất kỳ nội dung gì sẽ giới hạn trách nhiệm pháp lý của Nokia trong trường hợp tử vong hoặc thương tật là kết quả từ tính lơ đễnh của Nokia.</translation>
    </message>
    <message numerus="no" id="txt_irad_info_search">
      <source>Search</source>
      <translation variants="no">Nhập văn bản tìm kiếm</translation>
    </message>
    <message numerus="no" id="txt_irad_info_clear_song_list">
      <source>Clear song list?</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn danh sách bài hát? Tất cả bài hát sẽ bị xóa.</lengthvariant>
        <lengthvariant priority="2">Chọn dsbh? T.c b.h sẽ bị xóa.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_song_p">
      <source>Unknown song</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bài hát không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_nokia_internet_radio">
      <source>Nokia Internet Radio service (“Service”) enables you to discover and experience the content of Internet radio stations. YOU AGREE THAT YOUR USE OF THE SERVICE ACKNOWLEDGES THAT YOU HAVE READ THIS AGREEMENT, YOU HAVE UNDERSTOOD IT AND YOU AGREE TO BE BOUND BY ITS TERMS AND CONDITIONS. If you do not agree, please note that you will not be allowed to use the Service.</source>
      <translation variants="no">Dịch vụ Internet Radio của Nokia (“Dịch vụ”) cho phép bạn khám phá và trải nghiệm nội dung của các trạm Internet radio. BẠN ĐỒNG Ý RẰNG VIỆC BẠN SỬ DỤNG DỊCH VỤ THỪA NHẬN RẰNG BẠN ĐÃ ĐỌC THỎA THUẬN NÀY, BẠN ĐÃ HIỂU VÀ BẠN ĐỒNG Ý CHỊU RÀNG BUỘC BỞI CÁC ĐIỀU KHOẢN VÀ ĐIỀU KIỆN CỦA DỊCH VỤ. Nếu bạn không đồng ý, hãy lưu ý rằng bạn sẽ không được phép sử dụng Dịch vụ.</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_visualization">
      <source>Visualization</source>
      <translation variants="no">Hiệu ứng</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_use_of_the_service">
      <source>USE OF THE SERVICE</source>
      <translation variants="no">SỬ DỤNG DỊCH VỤ</translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_rename">
      <source>Rename</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đổi tên</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by">
      <source>Sort by</source>
      <translation variants="no">Sắp xếp theo</translation>
    </message>
    <message numerus="no" id="txt_irad_info_service_availability_content">
      <source>The Service is provided as a convenience to you. It is provided "as is" and on an "as available" basis. Nokia does not guarantee that the Service shall be uninterrupted or error-free. Nokia reserves the right to revise the Service or withdraw access to it at any time.\n\nNokia may provide upgrades for software applications related to the Service at its sole discretion.
</source>
      <translation variants="no">Dịch vụ được cung cấp theo sự thuận tiện cho bạn. Dịch vụ được cung cấp “theo hiện trạng” và trên cơ sở “như có sẵn”. Nokia không đảm bảo Dịch vụ sẽ không bị gián đoạn hay hoàn toàn không có lỗi. Nokia giữ quyền sửa đổi Dịch vụ hoặc thu hồi quyền truy cập vào Dịch vụ bất kỳ lúc nào.

Nokia có thể nâng cấp các ứng dụng phần mềm có liên quan đến Dịch vụ theo ý riêng của mình.
</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_privacy">
      <source>PRIVACY</source>
      <translation variants="no">SỰ RIÊNG TƯ</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_service_availability">
      <source>SERVICE AVAILABILITY</source>
      <translation variants="no">TÍNH KHẢ DỤNG DỊCH VỤ</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_unknown_song">
      <source>Unknown artist - Unknown song</source>
      <translation variants="no">Bài hát và nghệ sĩ ko biết</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_p">
      <source>Unknown artist</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nghệ sĩ không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_menu_add_to_favorites">
      <source>Add to favorites</source>
      <translation variants="no">Thêm vào mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_irad_info_privacy_content">
      <source>Nokia is committed to protecting user privacy, and thus implements strict confidentiality policies.\n\n In order to monitor the use of and to improve the Service, Nokia may collect usage data including, but not limited to, information about the Internet radio stations accessed, the time spent on each station and the items rated as favourites.\n\nNokia does not collect any information that allows identification of the user of the Service.
</source>
      <translation variants="no">Nokia cam kết bảo vệ sự riêng tư của người dùng và do đó thực hiện các chính sách bảo mật nghiêm ngặt.

Để theo dõi việc sử dụng và để cải thiện Dịch vụ, Nokia có thể thu thập dữ liệu sử dụng bao gồm, nhưng không giới hạn, thông tin về các trạm Internet radio đã truy cập, thời gian bỏ ra trên mỗi trạm và các mục được đánh giá là mục ưa thích.

Nokia không thu thập bất kỳ thông tin nào cho phép nhận dạng người dùng Dịch vụ.
</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by_val_ascending">
      <source>Ascending </source>
      <translation variants="no">Tăng dần</translation>
    </message>
    <message numerus="no" id="txt_irad_info_clear_station_list">
      <source>Clear station list?</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa danh sách trạm? Tất cả trạm sẽ bị xóa.</lengthvariant>
        <lengthvariant priority="2">Xóa ds trạm? T.c tr. sẽ bị xóa.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_matching_station_found">
      <source>No matching station found</source>
      <translation variants="no">Không tìm thấy trạm phù hợp</translation>
    </message>
    <message numerus="no" id="txt_irad_info_max_reached_delete_station_before_adding_new_favorite">
      <source>Max reached. Remove station before adding new favorite</source>
      <translation variants="no">Danh sách ưa thích đầy. Xóa một trạm và thử lại.</translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_recently_played">
      <source>Stations played</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_stations_found">
      <source>No stations found</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #No stations found</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_button_decline">
      <source>Decline</source>
      <translation variants="no">Từ chối</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_internet_radio">
      <source>Internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">Internet radio</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_go_to_station">
      <source>Go to station</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chuyển đến trạm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_max_limit_reached">
      <source>Max limit reached</source>
      <translation variants="no">Đã đạt đến giới hạn tối đa</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_governing_law">
      <source>GOVERNING LAW</source>
      <translation variants="no">LUẬT CHI PHỐI</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_terms_conditions">
      <source>Terms &amp; Conditions</source>
      <translation variants="no">Điều khoản &amp; điều kiện</translation>
    </message>
    <message numerus="no" id="txt_irad_info_the_service_content">
      <source>The Service enables the following:\n\n1. browsing of links to Internet radio stations;\n\n2. accessing the content of Internet radio stations;
</source>
      <translation variants="no">Dịch vụ cho phép:

1. duyệt qua các liên kết đến các trạm Internet radio;

2. truy cập vào nội dung các trạm Internet radio;
</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mục ưa thích</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_use_of_the_service_content">
      <source>Use of the Service is only permitted for your private and non-commercial use. Nokia shall own all intellectual property rights relating to the Service.\n\nNokia reserves the right to change these terms and conditions by informing you of such change.
</source>
      <translation variants="no">Bạn chỉ được phép sử dụng Dịch vụ cho mục đích riêng tư và phi thương mại. Nokia sở hữu tất cả quyền sở hữu trí tuệ có liên quan đến Dịch vụ.

Nokia giữ quyền thay đổi các điều khoản và điều kiện này bằng cách thông báo cho bạn về việc thay đổi như vậy.
</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_content">
      <source>No content</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #No content</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_station_with_new_name_exists">
      <source>Station with new name exists</source>
      <translation variants="no">Trạm có tên này đã tồn tại</translation>
    </message>
    <message numerus="no" id="txt_irad_info_insufficient_disk_space">
      <source>Insufficient disk space  </source>
      <translation variants="no">Không đủ bộ nhớ</translation>
    </message>
    <message numerus="no" id="txt_irad_button_accept">
      <source>Accept</source>
      <translation variants="no">Chấp nhận</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_select_items_to_delete">
      <source>Select items to remove</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn mục cần xóa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_click_the_song_and_find_it_in_music_store">
      <source>Click the song and find it in music store</source>
      <translation variants="no">Nhấp vào bài hát để tìm b.hát từ C.h.Nhạc</translation>
    </message>
    <message numerus="no" id="txt_irad_info_operation_failed">
      <source>Operation failed</source>
      <translation variants="no">Không thể thực hiện thao tác</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by_val_descending">
      <source>Descending</source>
      <translation variants="no">Giảm dần</translation>
    </message>
    <message numerus="yes" id="txt_irad_subtitle_stations">
      <source>%Ln stations</source>
      <translation>
        <numerusform plurality="a">%Ln trạm</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_not_allowed_by_this_station">
      <source>Not allowed by this station</source>
      <translation variants="no">Trạm này không cho phép</translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_station_address">
      <source>Station web address</source>
      <translation variants="no">Địa chỉ web trạm</translation>
    </message>
    <message numerus="no" id="txt_irad_info_added_to_favorites">
      <source>Added to Favorites</source>
      <translation variants="no">Đã thêm vào mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_irad_info_hi_these_are_my_favorite_stations_hope_you_like_them">
      <source>Hi, these are my favorite stations. Hope you like them</source>
      <translation variants="no">Xin chào, đây là các trạm ưa thích của tôi. Tôi hy vọng bạn thích chúng!</translation>
    </message>
    <message numerus="no" id="txt_irad_info_invalid_station_address">
      <source>Invalid station address</source>
      <translation variants="no">Địa chỉ trạm không hợp lệ</translation>
    </message>
    <message numerus="no" id="txt_irad_info_hi_this_is_my_favorite_station_hope_you_like_it">
      <source>Hi, this is my favorite station. Hope you like it</source>
      <translation variants="no">Xin chào, đây là trạm ưa thích của tôi. Tôi hy vọng bạn sẽ thích trạm này!</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_policy_copyright">
      <source>POLICY REGARDING ALLEGATIONS OF COPYRIGHT INFRINGEMENT</source>
      <translation variants="no">CHÍNH SÁCH VỀ CÁC CÁO BUỘC VI PHẠM BẢN QUYỀN</translation>
    </message>
    <message numerus="no" id="txt_irad_connecting_failed_try_next_address">
      <source>Connecting failed, try next address</source>
      <translation variants="no">Không kết nối được. Thử địa chỉ tiếp theo.</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_the_services">
      <source>THE SERVICE</source>
      <translation variants="no">DỊCH VỤ</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_genre">
      <source>Genre</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Genre</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_song_l">
      <source>%1 - Unknown song</source>
      <translation variants="no">%[10]1 - Bài hát không biết</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">Xóa danh sách</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_network_connection">
      <source>No network connection</source>
      <translation variants="no">(không có kết nối mạng)</translation>
    </message>
  </context>
</TS>