<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_short_caption_internetradio">
      <source>internetradio</source>
      <translation variants="no">vi #internetradio</translation>
    </message>
    <message numerus="no" id="txt_long_caption_internetradio">
      <source>internetradio</source>
      <translation variants="no">Internet radio</translation>
    </message>
    <message numerus="no" id="txt_irad_info_can_not_add_more">
      <source>Can't add more</source>
      <translation variants="no">Không đủ bộ nhớ để thêm nội dung</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_search_in_music_store">
      <source>search in music store</source>
      <translation variants="no">Tìm trong Cửa hàng nhạc</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_network_connectiion">
      <source>No network connection</source>
      <translation variants="no">(không có kết nối mạng)</translation>
    </message>
    <message numerus="no" id="txt_irad_info_connecting_timout">
      <source>Connecting timeout</source>
      <translation variants="no">Hết giờ kết nối</translation>
    </message>
    <message numerus="no" id="txt_irad_title_internet_radio">
      <source>internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">Internet radio</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_share_not_available">
      <source>Share not available</source>
      <translation variants="no">Chia sẻ trạm không có sẵn</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_space_on_c_drive_internet_radio_closed">
      <source>No space on C drive, Internet Radio closed</source>
      <translation variants="no">Không đủ bộ nhớ để khởi động Internet radio</translation>
    </message>
    <message numerus="no" id="txt_irad_info_favorite_updated">
      <source>Favorite updated</source>
      <translation variants="no">Đã cập nhật kênh ưa thích</translation>
    </message>
    <message numerus="no" id="txt_irad_info_song_recognition_not_available">
      <source>Song recognition not available</source>
      <translation variants="no">Nhận dạng bài hát không có sẵn</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_go_to_station">
      <source>Go to station</source>
      <translation variants="no">Chuyển đến trạm</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_matching_stations_found">
      <source>No matching stations found</source>
      <translation variants="no">(không tìm thấy trạm phù hợp)</translation>
    </message>
    <message numerus="no" id="txt_irad_info_music_store_not_available">
      <source>Music store not available</source>
      <translation variants="no">Cửa hàng nhạc không có sẵn</translation>
    </message>
    <message numerus="no" id="txt_internetradio_list_unknown_unknown">
      <source>Unknown - Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết - Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_click_the_song_and_find_it_in_nokia_music_store">
      <source>Click the song and find it in nokia music store</source>
      <translation variants="no">Nhấp vào bài hát và tìm b.hát trong Cửa hàng nhạc</translation>
    </message>
    <message numerus="no" id="txt_irad_info_song_info_not_available">
      <source>song info not available</source>
      <translation variants="no">(thông tin bài hát không có sẵn)</translation>
    </message>
    <message numerus="no" id="txt_internetradio_list_1_unknown">
      <source>%1 - Unknown</source>
      <translation variants="no">%1 - Không biết</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_share">
      <source>share</source>
      <translation variants="no">Chia sẻ</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_country_region">
      <source>stations by country(region)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm theo quốc gia/vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_internetradio_list_unknown_1">
      <source>Unknown - %1</source>
      <translation variants="no">Không biết - %1</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_high">
      <source>High</source>
      <translation variants="no">Cao</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_clear_list">
      <source>clear list</source>
      <translation variants="no">vi #clear list</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_internetradio">
      <source>internetradio</source>
      <translation variants="no">vi #internetradio</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_search">
      <source>search</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #search</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_recently_played_songs">
      <source>recently played songs</source>
      <translation variants="no">Bài hát đã phát gần đây</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_search_in_wikipedia">
      <source>search in wikipedia</source>
      <translation variants="no">Tìm trong Wikipedia</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality">
      <source>download quality</source>
      <translation variants="no">Chất lượng tải về</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_add_to_favorite">
      <source>Add to favorite</source>
      <translation variants="no">Thêm vào mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_from_play_list">
      <source>Stations from play list</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm trong danh sách bài hát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_recently_played_stations">
      <source>recently played stations</source>
      <translation variants="no">Trạm đã phát gần đây</translation>
    </message>
    <message numerus="yes" id="txt_irad_setlabel_bit_rate">
      <source>Bit rate: %Ln kbps</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_operation_failed">
      <source>operation failed</source>
      <translation variants="no">Không thể thực hiện thao tác</translation>
    </message>
    <message numerus="no" id="txt_irad_list_recently_played_stations">
      <source>recently played stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_go_to_now_playing">
      <source>Go to Now Playing</source>
      <translation variants="no">Chuyển đến 'Đang phát'</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_search_result">
      <source>search result</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kết quả tìm kiếm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_description">
      <source>Description</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mô tả</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_station_name">
      <source>Station name</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên trạm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_language">
      <source>stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm theo ngôn ngữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_hi_these_are_my_favorite_stations_hope_you_like_them">
      <source>Hi, these are my favortie stations. Hope you like them</source>
      <translation variants="no">Xin chào, đây là các trạm ưa thích của tôi. Tôi hy vọng bạn thích chúng!</translation>
    </message>
    <message numerus="no" id="txt_irad_info_added_to_favorites">
      <source>Added to Favorites</source>
      <translation variants="no">vi #Added to Favorites</translation>
    </message>
    <message numerus="no" id="txt_irad_info_downloading_logos">
      <source>Downloading logos</source>
      <translation variants="no">Đang tải xuống biểu tượng</translation>
    </message>
    <message numerus="no" id="txt_irad_list_recently_played_songs">
      <source>recently played songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bài hát đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_disallowed_by_this_station">
      <source>Disallowed by this station</source>
      <translation variants="no">Trạm này không cho phép</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_language">
      <source>stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm theo ngôn ngữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_failed_to_connect">
      <source>Connecting failed</source>
      <translation variants="no">Không thể kết nối</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_network_setting">
      <source>Network Setting</source>
      <translation variants="no">Cài đặt mạng</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_songs">
      <source>recently played songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bài hát đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_standard">
      <source>Standard</source>
      <translation variants="no">Chuẩn</translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_country_region">
      <source>stations by country(region)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm theo quốc gia/vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_invalid_link_please_change_it">
      <source>invalid URL link, please change it</source>
      <translation variants="no">Địa chỉ web không hợp lệ</translation>
    </message>
    <message numerus="no" id="txt_irad_connecting_failed_try_next_url">
      <source>Connecting failed, try next URL</source>
      <translation variants="no">Không thể kết nối. Thử một địa chỉ web khác.</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_deactivate_stereo">
      <source>Deactivate Stereo</source>
      <translation variants="no">Tắt stereo</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_activate_stereo">
      <source>Activate Stereo</source>
      <translation variants="no">Kích hoạt stereo</translation>
    </message>
    <message numerus="no" id="txt_irad_info_connecting_to_server">
      <source>Connecting to server</source>
      <translation variants="no">Đang kết nối máy chủ</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_share">
      <source>share</source>
      <translation variants="no">Chia sẻ</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_stations">
      <source>recently played stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_network_setting">
      <source>network setting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt mạng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_unnamed">
      <source>Unnamed</source>
      <translation variants="no">Chưa đặt tên</translation>
    </message>
  </context>
</TS>