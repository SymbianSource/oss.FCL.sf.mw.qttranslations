<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_chinese_vkb_stroke_landscape_delimiter">
      <source>Delimiter</source>
      <translation variants="no">uk ##Delimiter</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_stroke_portrait_numbermode_switcher">
      <source>Number</source>
      <translation variants="no">uk ##Number</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_stroke_portrait_delimiter">
      <source>Delimiter</source>
      <translation variants="no">uk ##Delimiter</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_stroke_landscape_language_switcher">
      <source>English</source>
      <translation variants="no">uk ##English</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_stroke_portrait_symbolmode_switcher">
      <source>Symbol</source>
      <translation variants="no">uk ##Symbol</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_stroke_portrait_wildcard">
      <source>Wildcard</source>
      <translation variants="no">uk ##Wildcard</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_stroke_portrait_language_switcher">
      <source>English</source>
      <translation variants="no">uk ##English</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_stroke_landscape_numberandsymbolmode_switcher">
      <source>Number and Symbol</source>
      <translation variants="no">uk ##Number and Symbol</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_stroke_landscape_wildcard">
      <source>Wildcard</source>
      <translation variants="no">uk ##Wildcard</translation>
    </message>
  </context>
</TS>