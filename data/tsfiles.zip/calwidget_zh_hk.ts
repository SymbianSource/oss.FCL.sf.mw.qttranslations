<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_l1_events">
      <source>L%1 events overlapping</source>
      <translation variants="no">%Ln個重複的項目</translation>
    </message>
    <message numerus="no" id="txt_short_caption_calendar_widget">
      <source>Calendar widget</source>
      <translation variants="no">zh_hk #Calendar</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar_widget">
      <source>Calendar widget</source>
      <translation variants="no">日曆</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_no_events_ox">
      <source>No events in next 7 days</source>
      <translation variants="no">7天之內沒有日曆項目</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_no_events_tod">
      <source>No events today</source>
      <translation variants="no">今天沒有項目</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_applib">
      <source>Shows calendar events</source>
      <translation variants="yes">
        <lengthvariant priority="1">在首頁畫面中查看日曆項目</lengthvariant>
        <lengthvariant priority="2">zh_hk #See calendar entries</lengthvariant>
      </translation>
    </message>
  </context>
</TS>