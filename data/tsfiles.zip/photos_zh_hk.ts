<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_fast">
      <source>Fast</source>
      <translation variants="no">快</translation>
    </message>
    <message numerus="no" id="txt_photos_title_photos">
      <source>Photos</source>
      <translation variants="yes">
        <lengthvariant priority="1">照片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_slideshow">
      <source>Slideshow</source>
      <translation variants="no">投影片秀</translation>
    </message>
    <message numerus="yes" id="txt_photos_subtitle_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">%Ln張圖像</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">全部取消標記</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_share">
      <source>Share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_play">
      <source>Play</source>
      <translation variants="no">播放</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_share">
      <source>Share</source>
      <translation variants="no">分享</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect">
      <source>Transistion effect</source>
      <translation variants="no">轉換效果</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_settings">
      <source>Settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">我的最愛</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_medium">
      <source>Medium</source>
      <translation variants="no">普通</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_remove_from_album">
      <source>Remove from album</source>
      <translation variants="no">從相簿移除</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay">
      <source>Transistion delay</source>
      <translation variants="no">轉換速度</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_smooth">
      <source>Smooth Fade</source>
      <translation variants="no">慢慢消去</translation>
    </message>
    <message numerus="no" id="txt_long_caption_photos">
      <source>photos</source>
      <translation variants="no">照片</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_add_to_album">
      <source>Add to album</source>
      <translation variants="no">加入至相簿</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_slideshow">
      <source>Slideshow</source>
      <translation variants="no">投影片秀</translation>
    </message>
    <message numerus="no" id="txt_photos_info_delete_l1_the_files_will_not_be">
      <source>Delete %1? (The files will not be deleted.)</source>
      <translation variants="no">是否刪除%[07]1？已儲存項目不會刪除。</translation>
    </message>
    <message numerus="no" id="txt_photos_info_remove_l1_from_album_the_file_w">
      <source>Remove %1 from album? (The file will not be deleted.)</source>
      <translation variants="no">是否從相簿中移除%[13]1？</translation>
    </message>
    <message numerus="no" id="txt_photos_info_unable_to_open_image">
      <source>Unable to open image</source>
      <translation variants="no">無法開啟圖像</translation>
    </message>
    <message numerus="no" id="txt_photos_grid_no_images">
      <source>No images</source>
      <translation variants="no">zh_hk #(no images)</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_photos">
      <source>Photos</source>
      <translation variants="no">zh_hk #Photos</translation>
    </message>
    <message numerus="yes" id="txt_photos_info_remove_ln_items_from_album_the">
      <source>Remove %Ln items from album? (The files will not be deleted.)</source>
      <translation>
        <numerusform plurality="a">是否從相簿移除%Ln個項目？項目不會從手機中刪除。</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_info_deleting_1">
      <source>Deleting %1?</source>
      <translation variants="no">正在刪除%1</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_description">
      <source>Description</source>
      <translation variants="yes">
        <lengthvariant priority="1">內容說明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_use_image">
      <source>Use image</source>
      <translation variants="no">使用圖像</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album">
      <source>Album</source>
      <translation variants="no">相簿</translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_gb">
      <source>Size: %Ln Gb </source>
      <translation>
        <numerusform plurality="a">大小：%Ln GB</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_mb">
      <source>Size: %Ln Mb</source>
      <translation>
        <numerusform plurality="a">大小：%Ln MB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_grid">
      <source>Grid</source>
      <translation variants="no">格線</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album_l1">
      <source>Album (%L1)</source>
      <translation variants="no">相簿(%L1)</translation>
    </message>
    <message numerus="no" id="txt_photos_list_date_1">
      <source>Date: %1</source>
      <translation variants="no">日期：%1</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_rotate">
      <source>Rotate</source>
      <translation variants="no">旋轉</translation>
    </message>
    <message numerus="no" id="txt_photos_title_enter_name">
      <source>Enter name :</source>
      <translation variants="yes">
        <lengthvariant priority="1">輸入相簿名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view">
      <source>View</source>
      <translation variants="no">檢視</translation>
    </message>
    <message numerus="no" id="txt_photos_list_time_1">
      <source>Time: %1</source>
      <translation variants="no">時間：%1</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_wave">
      <source>Wave</source>
      <translation variants="no">波浪</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_new_album">
      <source>New album</source>
      <translation variants="no">新相簿</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">已拍攝圖像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_slow">
      <source>Slow</source>
      <translation variants="no">慢</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_mark_all">
      <source>Mark all</source>
      <translation variants="no">全部標記</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">已拍攝圖像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_info_no_images_to_play_slideshow">
      <source>No images to play slideshow</source>
      <translation variants="no">無法播放投影片秀</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_add_to_album">
      <source>Add to album</source>
      <translation variants="no">加入至相簿</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_media_wall">
      <source>Media wall</source>
      <translation variants="no">多媒體牆</translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_kb">
      <source>Size: %Ln kB</source>
      <translation>
        <numerusform plurality="a">大小：%Ln KB</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_dblist_my_camera_val_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">%Ln個項目</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_info_delete_ln_items">
      <source>Delete %Ln items?</source>
      <translation>
        <numerusform plurality="a">是否刪除%Ln個項目？</numerusform>
      </translation>
    </message>
  </context>
</TS>