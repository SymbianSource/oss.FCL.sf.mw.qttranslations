<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="Persian">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cam_list_night_portrait">
      <source>Source 0</source>
      <translation variants="yes">
        <lengthvariant priority="1">Persian #Night portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_portrait">
      <source>Source 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">Persian #Portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sports">
      <source>Source 2</source>
      <translation variants="yes">
        <lengthvariant priority="1">Persian #Sport</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer">
      <source>Source 3</source>
      <translation variants="no">تایمر خودکار</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos">
      <source>Source 4</source>
      <translation variants="no">عکس ها</translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode">
      <source>Source 5</source>
      <translation variants="no">Persian #Camera on standby</translation>
    </message>
    <message numerus="no" id="txt_cam_list_landscape">
      <source>Source 6</source>
      <translation variants="yes">
        <lengthvariant priority="1">Persian #Landscape</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation">
      <source>Source 7</source>
      <translation variants="no">جبران نور</translation>
    </message>
    <message numerus="no" id="txt_cam_list_date">
      <source>Source 8</source>
      <translation variants="yes">
        <lengthvariant priority="1">تاریخ</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec">
      <source>Source 9</source>
      <translation>
        <numerusform plurality="a">%Ln ثانیه</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip">
      <source>Source 10</source>
      <translation variants="no">Persian #Delete video clip?</translation>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camcorder">
      <source>Source 11</source>
      <translation variants="yes">
        <lengthvariant priority="1">دوربین دوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus">
      <source>Source 12</source>
      <translation variants="no">+%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video">
      <source>Source 13</source>
      <translation variants="no">نمایش ویدیو ضبط شده</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings">
      <source>Source 14</source>
      <translation variants="no">تنظیمات دوربین</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_flash">
      <source>Source 15</source>
      <translation variants="yes">
        <lengthvariant priority="1">روشن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene">
      <source>Source 16</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_video">
      <source>Source 17</source>
      <translation variants="yes">
        <lengthvariant priority="1">روشن</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds">
      <source>Source 18</source>
      <translation>
        <numerusform plurality="a">%Ln ثانیه</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_camera">
      <source>Source 19</source>
      <translation variants="yes">
        <lengthvariant priority="1">دوربین</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_start">
      <source>Source 20</source>
      <translation variants="no">شروع</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_stabilization">
      <source>Source 21</source>
      <translation variants="no">ثبات ویدیو</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_set_as_default_scene_mode">
      <source>Source 22</source>
      <translation variants="no">تنظیم حالت صحنه</translation>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode">
      <source>Source 23</source>
      <translation variants="no">فلاش</translation>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation">
      <source>Source 24</source>
      <translation variants="no">Persian #Exposure compensation</translation>
    </message>
    <message numerus="no" id="txt_cam_list_reduce_red_eye">
      <source>Source 25</source>
      <translation variants="yes">
        <lengthvariant priority="1">کاهش قرمزی چشم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone">
      <source>Source 26</source>
      <translation variants="no">Persian #Colour tone</translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left">
      <source>Source 27</source>
      <translation>
        <numerusform plurality="a">%Ln تصویر باقیمانده</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_camera">
      <source>Source 28</source>
      <translation variants="no">Persian #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_stabilization">
      <source>Source 29</source>
      <translation variants="no">ثبات ویدیو</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound">
      <source>Source 30</source>
      <translation variants="no">صدای ویدیو</translation>
    </message>
    <message numerus="no" id="txt_cam_list_incandescent">
      <source>Source 31</source>
      <translation variants="yes">
        <lengthvariant priority="1">لامپ رشته ای</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_geotagging">
      <source>Source 32</source>
      <translation variants="no">برچسب جغرافیایی</translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix">
      <source>Source 33</source>
      <translation>
        <numerusform plurality="a">%Ln مگاپیکسل</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sunny">
      <source>Source 34</source>
      <translation variants="yes">
        <lengthvariant priority="1">آفتابی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_white">
      <source>Source 35</source>
      <translation variants="yes">
        <lengthvariant priority="1">سیاه و سفید</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_mass_memory">
      <source>Source 36</source>
      <translation variants="yes">
        <lengthvariant priority="1">حافظه انبوه</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_change_mode">
      <source>Source 37</source>
      <translation variants="no">تغییر حالت</translation>
    </message>
    <message numerus="no" id="txt_cam_other_restore_settings">
      <source>Source 38</source>
      <translation variants="no">Persian #Restore settings?</translation>
    </message>
    <message numerus="yes" id="txt_cam_other_delete_n_items">
      <source>Source 39</source>
      <translation>
        <numerusform plurality="a">Persian #Delete %Ln item?</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_geotagging">
      <source>Source 40</source>
      <translation variants="no">Persian #Geotagging</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_video">
      <source>Source 41</source>
      <translation variants="yes">
        <lengthvariant priority="1">خاموش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_camera ">
      <source>Source 42</source>
      <translation variants="no">دوربین</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_43">
      <source>Source 43</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA ۴:۳</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_face_tracking">
      <source>Source 44</source>
      <translation variants="no">تشخیص صورت</translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_rotation">
      <source>Source 45</source>
      <translation variants="no">چرخش تصویر</translation>
    </message>
    <message numerus="no" id="txt_cam_title_memory_in_use">
      <source>Source 46</source>
      <translation variants="no">حافظه مورد استفاده</translation>
    </message>
    <message numerus="no" id="txt_cam_list_camera">
      <source>Source 47</source>
      <translation variants="yes">
        <lengthvariant priority="1">دوربین</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_flash">
      <source>Source 48</source>
      <translation variants="yes">
        <lengthvariant priority="1">خاموش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_night">
      <source>Source 49</source>
      <translation variants="yes">
        <lengthvariant priority="1">شب</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_video">
      <source>Source 50</source>
      <translation variants="yes">
        <lengthvariant priority="1">بله</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name">
      <source>Source 51</source>
      <translation variants="no">نام پیش فرض</translation>
    </message>
    <message numerus="no" id="txt_cam_title_set_as_default_scene_mode">
      <source>Source 52</source>
      <translation variants="no">تنظیم بعنوان حالت صحنه</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_video">
      <source>Source 53</source>
      <translation variants="yes">
        <lengthvariant priority="1">شب</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_contrast">
      <source>Source 54</source>
      <translation variants="no">Persian #Contrast</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_scene">
      <source>Source 55</source>
      <translation variants="yes">
        <lengthvariant priority="1">روشن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_scene">
      <source>Source 56</source>
      <translation variants="yes">
        <lengthvariant priority="1">خاموش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings">
      <source>Source 57</source>
      <translation variants="no">تنظیمات</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_memory_in_use">
      <source>Source 58</source>
      <translation variants="no">حافظه مورد استفاده</translation>
    </message>
    <message numerus="no" id="txt_cam_title_capture_tone">
      <source>Source 59</source>
      <translation variants="no">آهنگ عکس گرفتن</translation>
    </message>
    <message numerus="no" id="txt_cam_other_please_type_here">
      <source>Source 60</source>
      <translation variants="no">اینجا تایپ کنید</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_video">
      <source>Source 61</source>
      <translation variants="yes">
        <lengthvariant priority="1">خیر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_rotation">
      <source>Source 62</source>
      <translation variants="no">چرخش تصویر</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_phone_memory">
      <source>Source 63</source>
      <translation variants="yes">
        <lengthvariant priority="1">حافظه تلفن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_cancel">
      <source>Source 64</source>
      <translation variants="no">لغو</translation>
    </message>
    <message numerus="no" id="txt_cam_info_no_memory_card_in_device_please_inse">
      <source>Source 65</source>
      <translation variants="no">Persian #No memory card inserted. Insert memory card to capture images.</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality">
      <source>Source 66</source>
      <translation variants="no">کیفیت تصویر</translation>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer">
      <source>Source 67</source>
      <translation variants="no">تایمر خودکار</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_rotate">
      <source>Source 68</source>
      <translation variants="yes">
        <lengthvariant priority="1">خیر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sepia">
      <source>Source 69</source>
      <translation variants="yes">
        <lengthvariant priority="1">قرمز قهوه ای</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity">
      <source>Source 70</source>
      <translation variants="no">حساسیت نور</translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_image_name">
      <source>Source 71</source>
      <translation variants="no">نام تصویر پیش فرض</translation>
    </message>
    <message numerus="no" id="txt_cam_list_closeup">
      <source>Source 72</source>
      <translation variants="yes">
        <lengthvariant priority="1">نمای بسته</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_low_light">
      <source>Source 73</source>
      <translation variants="yes">
        <lengthvariant priority="1">نور ضعیف</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_face">
      <source>Source 74</source>
      <translation variants="yes">
        <lengthvariant priority="1">خاموش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_qcif_sharing">
      <source>Source 75</source>
      <translation variants="yes">
        <lengthvariant priority="1">اشتراک QCIF</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_video_name">
      <source>Source 76</source>
      <translation variants="no">نام ویدیو پیش فرض</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_face">
      <source>Source 77</source>
      <translation variants="yes">
        <lengthvariant priority="1">روشن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_memory_card">
      <source>Source 78</source>
      <translation variants="yes">
        <lengthvariant priority="1">کارت حافظه</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking">
      <source>Source 79</source>
      <translation variants="no">Persian #Face detection</translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_rotate">
      <source>Source 80</source>
      <translation variants="yes">
        <lengthvariant priority="1">بله</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality">
      <source>Source 81</source>
      <translation variants="no">کیفیت تصویر</translation>
    </message>
    <message numerus="no" id="txt_cam_button_iso">
      <source>Source 82</source>
      <translation variants="no">Persian #ISO</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos">
      <source>Source 83</source>
      <translation variants="no">كلیپ های ویدیویی</translation>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone">
      <source>Source 84</source>
      <translation variants="no">درجه رنگ</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name">
      <source>Source 85</source>
      <translation variants="no">نام ویدیو پیش فرض</translation>
    </message>
    <message numerus="no" id="txt_cam_caption_camera">
      <source>Source 86</source>
      <translation variants="no">Persian #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_image">
      <source>Source 87</source>
      <translation variants="yes">
        <lengthvariant priority="1">بله</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone">
      <source>Source 88</source>
      <translation variants="no">آهنگ عکس گرفتن</translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined">
      <source>Source 89</source>
      <translation variants="yes">
        <lengthvariant priority="1">تعیین شده توسط کاربر</lengthvariant>
        <lengthvariant priority="2">تعیین شده کاربر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_negative">
      <source>Source 90</source>
      <translation variants="yes">
        <lengthvariant priority="1">منفی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality">
      <source>Source 91</source>
      <translation variants="no">کیفیت ویدیو</translation>
    </message>
    <message numerus="no" id="txt_cam_other_default_image_name">
      <source>Source 92</source>
      <translation variants="no">نام تصویر پیش فرض</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality">
      <source>Source 93</source>
      <translation variants="no">کیفیت ویدیو</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga">
      <source>Source 94</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_camcorder">
      <source>Source 95</source>
      <translation variants="yes">
        <lengthvariant priority="1">دوربین فیلمبرداری</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_cloudy">
      <source>Source 96</source>
      <translation variants="yes">
        <lengthvariant priority="1">ابری</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_timer">
      <source>Source 97</source>
      <translation variants="yes">
        <lengthvariant priority="1">خاموش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use">
      <source>Source 98</source>
      <translation variants="no">Persian #Camera already in use by another application</translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus">
      <source>Source 99</source>
      <translation variants="no">-%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_whitebal">
      <source>Source 100</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_upload_settings">
      <source>Source 101</source>
      <translation variants="no">تنظیمات بارگذاری</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_exposure_compensation">
      <source>Source 102</source>
      <translation variants="no">جبران نور</translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_sound">
      <source>Source 103</source>
      <translation variants="no">صدای ویدیو</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_settings">
      <source>Source 104</source>
      <translation variants="no">تنظیمات</translation>
    </message>
    <message numerus="no" id="txt_cam_info_error">
      <source>Source 105</source>
      <translation variants="no">Persian #Unexpected error occurred. Restart phone.</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_restore_settings">
      <source>Source 106</source>
      <translation variants="no">بازیابی تنظیمات</translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous">
      <source>Source 107</source>
      <translation variants="yes">
        <lengthvariant priority="1">ممتد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode">
      <source>Source 108</source>
      <translation variants="no">حالت صحنه</translation>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance">
      <source>Source 109</source>
      <translation variants="no">Persian #White balance</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_val_ln_recording_time_left">
      <source>Source 110</source>
      <translation variants="yes">
        <lengthvariant priority="1">زمان ضبط باقیمانده: %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image">
      <source>Source 111</source>
      <translation variants="no">Persian #Show captured image</translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined_scene">
      <source>Source 112</source>
      <translation variants="yes">
        <lengthvariant priority="1">تعیین شده توسط کاربر</lengthvariant>
        <lengthvariant priority="2">تعیین شده کاربر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_169_widescreen">
      <source>Source 113</source>
      <translation variants="yes">
        <lengthvariant priority="1">HD ۷۲۰p ۱۶:۹ صفحه تخت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image">
      <source>Source 114</source>
      <translation variants="no">Persian #Delete image?</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_stabil">
      <source>Source 115</source>
      <translation variants="yes">
        <lengthvariant priority="1">روشن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_normal">
      <source>Source 116</source>
      <translation variants="yes">
        <lengthvariant priority="1">معمولی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_flash">
      <source>Source 117</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_not">
      <source>Source 118</source>
      <translation variants="no">خیر</translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix_widescreen">
      <source>Source 119</source>
      <translation>
        <numerusform plurality="a">%Ln مگ صفحه تخت</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance">
      <source>Source 120</source>
      <translation variants="no">تعادل سفید</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_image">
      <source>Source 121</source>
      <translation variants="yes">
        <lengthvariant priority="1">خیر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_vivid">
      <source>Source 122</source>
      <translation variants="yes">
        <lengthvariant priority="1">واضح</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camera">
      <source>Source 123</source>
      <translation variants="yes">
        <lengthvariant priority="1">دوربین دوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_lightsens">
      <source>Source 124</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image">
      <source>Source 125</source>
      <translation variants="no">نمایش تصویر گرفته شده</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_stabil">
      <source>Source 126</source>
      <translation variants="yes">
        <lengthvariant priority="1">خاموش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_white_balance">
      <source>Source 127</source>
      <translation variants="no">تعادل سفید</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video">
      <source>Source 128</source>
      <translation variants="no">نمایش ویدیو کنونی</translation>
    </message>
    <message numerus="no" id="txt_cam_list_fluorescent">
      <source>Source 129</source>
      <translation variants="yes">
        <lengthvariant priority="1">مهتابی</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video">
      <source>Source 130</source>
      <translation>
        <numerusform plurality="a">%Ln ثانیه</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_contrast">
      <source>Source 131</source>
      <translation variants="no">شفافیت</translation>
    </message>
    <message numerus="no" id="txt_cam_info_captured_photos_and_videos_will_be_ta">
      <source>Source 132</source>
      <translation variants="no">برچسب مکان شما برای عکس ها و فیلم ها قرار داده می شود. اگر عکس ها یا فیلم ها به اشتراک گذاشته شوند، داده مکان نیز در معرض دید اشخاص ثالث قرار داده می شود. تلفن برای گرفتن اطلاعات مکان از شبکه استفاده خواهد کرد. ممکن است هزینه انتقال داده داشته باشد. ذخیره مکان را می توان در بخش تنظیمات غیرفعال کرد.</translation>
    </message>
    <message numerus="no" id="txt_cam_list_not_video">
      <source>Source 133</source>
      <translation variants="yes">
        <lengthvariant priority="1">خیر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video">
      <source>Source 134</source>
      <translation variants="yes">
        <lengthvariant priority="1">ممتد</lengthvariant>
      </translation>
    </message>
  </context>
</TS>