<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_lint_list_recent_map_searches">
      <source>Recent map searches</source>
      <translation variants="no">Недавній пошук на карті</translation>
    </message>
    <message numerus="no" id="txt_lint_list_arrange">
      <source>Arrange</source>
      <translation variants="no">Упорядкувати</translation>
    </message>
    <message numerus="no" id="txt_lint_list_type">
      <source>Type</source>
      <translation variants="no">Тип</translation>
    </message>
    <message numerus="no" id="txt_lint_list_ascending">
      <source>Ascending</source>
      <translation variants="no">За зростанням</translation>
    </message>
    <message numerus="no" id="txt_lint_list_places">
      <source>Places</source>
      <translation variants="no">Розташування</translation>
    </message>
    <message numerus="no" id="txt_lint_list_sort_by">
      <source>Sort by </source>
      <translation variants="no">Сортувати за</translation>
    </message>
    <message numerus="no" id="txt_lint_list_remove_thumbnail">
      <source>Remove thumbnail</source>
      <translation variants="no">Видалити мініатюру</translation>
    </message>
    <message numerus="no" id="txt_lint_list_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="no">Адреси контакту</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_location_entries_present">
      <source>No Location entries present</source>
      <translation variants="no">(немає розташувань)</translation>
    </message>
    <message numerus="no" id="txt_lint_button_done">
      <source>Done</source>
      <translation variants="no">Готово</translation>
    </message>
    <message numerus="no" id="txt_lint_list_descending">
      <source>Descending</source>
      <translation variants="no">За спаданням</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_results">
      <source>No results</source>
      <translation variants="no">(немає результатів)</translation>
    </message>
    <message numerus="no" id="txt_lint_list_calendar_event_locations">
      <source>Calendar event locations</source>
      <translation variants="no">Розташ. у записах календ.</translation>
    </message>
    <message numerus="no" id="txt_lint_title_select_location">
      <source>Select location</source>
      <translation variants="no">Вибір розташування</translation>
    </message>
    <message numerus="no" id="txt_lint_list_details">
      <source>Details</source>
      <translation variants="no">Деталі</translation>
    </message>
  </context>
</TS>