<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_button_options_1">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">选项</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_back_1">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">返回</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_info_alert_confirmation">
      <source>Confirmation</source>
      <translation variants="no">确认</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_escape">
      <source>Qwerty: escape</source>
      <translation variants="no">QWERTY：Escape键</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_star_key">
      <source>ITU-T: *</source>
      <translation variants="no">ITU-T：*</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_up">
      <source>Move up (arrow up)</source>
      <translation variants="no">上移(向上箭头)</translation>
    </message>
    <message numerus="no" id="txt_java_menu_fetch">
      <source>Fetch</source>
      <translation variants="no">提取</translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_stop">
      <source>Stop</source>
      <translation variants="no">停止</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_space">
      <source>Qwerty: space</source>
      <translation variants="no">QWERTY：空格键</translation>
    </message>
    <message numerus="no" id="txt_java_button_options_2">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">选项</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_stop">
      <source>Stop</source>
      <translation variants="no">停止</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_help_2">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">帮助</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_stop_1">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">停止</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_info_alert_warning">
      <source>Warning</source>
      <translation variants="no">警告</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_voice">
      <source>Voice key</source>
      <translation variants="no">语音</translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_cancel">
      <source>Cancel</source>
      <translation variants="no">取消</translation>
    </message>
    <message numerus="no" id="txt_java_info_alert_error">
      <source>Error</source>
      <translation variants="no">错误</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_right">
      <source>Move right (arrow right)</source>
      <translation variants="no">右移(向右箭头)</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_cancel_1">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_help">
      <source>Help</source>
      <translation variants="no">帮助</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_rsk">
      <source>SK2, softkey 2, negative softkey</source>
      <translation variants="no">软键2，负软键</translation>
    </message>
    <message numerus="no" id="txt_java_button_fetch">
      <source>Fetch</source>
      <translation variants="yes">
        <lengthvariant priority="1">提取</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_cancel">
      <source>Cancel</source>
      <translation variants="no">取消</translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_ok">
      <source>Ok</source>
      <translation variants="no">确认</translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_back">
      <source>Back</source>
      <translation variants="no">返回</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_delete">
      <source>Qwerty: delete</source>
      <translation variants="no">QWERTY：Delete键</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_play">
      <source>Media key: play (pause)</source>
      <translation variants="no">多媒体：播放(暂停)</translation>
    </message>
    <message numerus="no" id="txt_java_menu_alert_dismiss">
      <source>Ok</source>
      <translation variants="no">确认</translation>
    </message>
    <message numerus="no" id="txt_java_opt_item_cmd_select">
      <source>Select</source>
      <translation variants="no">选择</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_ok_1">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">确认</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_down">
      <source>Move down (arrow down)</source>
      <translation variants="no">下移(向下箭头)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_left">
      <source>Move left (arrow left)</source>
      <translation variants="no">左移(向左箭头)</translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_ok">
      <source>Ok</source>
      <translation variants="no">确认</translation>
    </message>
    <message numerus="no" id="txt_java_menu_item_cmd_select">
      <source>Select</source>
      <translation variants="no">选择</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_help_1">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">帮助</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_back_2">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">返回</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_enter">
      <source>Qwerty: Enter key</source>
      <translation variants="no">QWERTY：Enter键</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_lsk">
      <source>SK1, softkey 1, positive softkey</source>
      <translation variants="no">软键1，正软键</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_selection_key">
      <source>Selection key (Select)</source>
      <translation variants="no">选择</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_close_2">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">关闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_modifier">
      <source>All modifier keys (e.g. shift, Fn)</source>
      <translation variants="no">修改人</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_next">
      <source>Media key: next (forward)</source>
      <translation variants="no">多媒体：下一个(向前)</translation>
    </message>
    <message numerus="no" id="txt_java_button_item_cmd_select_1">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_call">
      <source>Call</source>
      <translation variants="no">通话</translation>
    </message>
    <message numerus="no" id="txt_java_title_select_bookmark">
      <source>Select bookmark</source>
      <translation variants="no">选择书签</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_cancel_2">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_implicit_list_select">
      <source>Select</source>
      <translation variants="no">选择</translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_close">
      <source>Close</source>
      <translation variants="no">关闭</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_backspace">
      <source>Qwerty: backspace</source>
      <translation variants="no">QWERTY：Backspace键</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_apps">
      <source>Applications key</source>
      <translation variants="no">应用程序</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_send">
      <source>Send key</source>
      <translation variants="no">发送</translation>
    </message>
    <message numerus="no" id="txt_java_info_alert_information">
      <source>Information</source>
      <translation variants="no">信息</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_clear">
      <source>Clear key</source>
      <translation variants="no">清除</translation>
    </message>
    <message numerus="no" id="txt_java_opt_call">
      <source>Call</source>
      <translation variants="no">通话</translation>
    </message>
    <message numerus="no" id="txt_java_button_screen_cmd_select_1">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_close">
      <source>Close</source>
      <translation variants="no">关闭</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_hash_key">
      <source>ITU-T: #</source>
      <translation variants="no">ITU-T：#</translation>
    </message>
    <message numerus="no" id="txt_java_info_alert_alarm">
      <source>Alarm</source>
      <translation variants="no">闹铃</translation>
    </message>
    <message numerus="no" id="txt_java_button_screen_cmd_select_2">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_info_no_data">
      <source>No data</source>
      <translation variants="no">(无数据)</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_close_1">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">关闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_tab">
      <source>Qwerty: tab</source>
      <translation variants="no">QWERTY：Tab键</translation>
    </message>
    <message numerus="no" id="txt_java_opt_screen_cmd_select">
      <source>Select</source>
      <translation variants="no">选择</translation>
    </message>
    <message numerus="no" id="txt_java_button_item_cmd_select_2">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_alert_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">确认</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_end">
      <source>End key</source>
      <translation variants="no">结束</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_previous">
      <source>Media key: previous (rewind)</source>
      <translation variants="no">多媒体：上一个(后退)</translation>
    </message>
    <message numerus="no" id="txt_java_menu_screen_cmd_select">
      <source>Select</source>
      <translation variants="no">选择</translation>
    </message>
    <message numerus="no" id="txt_java_opt_fetch">
      <source>Fetch</source>
      <translation variants="no">提取</translation>
    </message>
    <message numerus="no" id="txt_java_info_alert">
      <source>Alert</source>
      <translation variants="no">提示</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_stop">
      <source>Media key: stop</source>
      <translation variants="no">多媒体：停止</translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_back">
      <source>Back</source>
      <translation variants="no">返回</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_ok_2">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">确认</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_call">
      <source>Call</source>
      <translation variants="yes">
        <lengthvariant priority="1">通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_stop_2">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">停止</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_help">
      <source>Help</source>
      <translation variants="no">帮助</translation>
    </message>
  </context>
</TS>