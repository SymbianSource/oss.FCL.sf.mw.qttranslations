<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="id">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_dblist_repeats_yearly">
      <source>Repeats Yearly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ulang setiap tahun</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Hapus entri berulang:</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Hanya kejadian ini</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_fortnightly">
      <source>Repeats fortnightly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ulang setiap 2 minggu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Keterangan:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_select_location_from">
      <source>Select location from search results</source>
      <translation variants="yes">
        <lengthvariant priority="1">Pilih lokasi dari hasil pencarian</lengthvariant>
        <lengthvariant priority="2">id #Select from search results</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Semua kejadian</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">Hapus catatan agenda?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_select_location">
      <source>Select location :</source>
      <translation variants="no">Pilih lokasi:</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_subject">
      <source>Subject</source>
      <translation variants="yes">
        <lengthvariant priority="1">Subjek:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_find_location_on_map">
      <source>Find location on map</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cari lokasi di peta</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_monthly">
      <source>Repeats monthly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ulang setiap bulan</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tanpa nama</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">Hapus rapat?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_finding_location_on_m">
      <source>Finding location on map…</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mencari lokasi di peta</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_from_1">
      <source>From %1</source>
      <translation variants="no">Dari %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Catatan agenda</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">Tandai belum selesai</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_workdays">
      <source>Repeats workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ulang setiap hari kerja</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_weekly">
      <source>Repeats weekly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ulang setiap minggu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Tandai telah selesai</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Edit:</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kalender</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_location_not_found_on">
      <source>Location not found on map</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lokasi tidak ditemukan di peta</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event ?</source>
      <translation variants="no">Hapus entri sepanjang hari?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily">
      <source>Repeats daily</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ulang setiap hari</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Rapat</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_all_day_event">
      <source>All day event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Entri sepanjang hari</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tanggal penyelesaian:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_until_1">
      <source>Until %1</source>
      <translation variants="no">Hingga %1</translation>
    </message>
  </context>
</TS>