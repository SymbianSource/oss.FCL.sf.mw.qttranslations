<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_inst_title_app_not_cert">
      <source>Application is not certified.</source>
      <translation variants="no">zh_hk #Application is not certified.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_perm_view_details">
      <source>Application asks permissions for:</source>
      <translation variants="no">zh_hk #Application asks permissions for:</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_app_cert">
      <source>Application is certified.</source>
      <translation variants="no">zh_hk #Application is certified.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_dpopinfo_installation_complete">
      <source>Installation complete</source>
      <translation variants="no">安裝完成</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_show">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">顯示</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_hide">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">隱藏</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_dpopinfo_preparing_installation">
      <source>Preparing installation</source>
      <translation variants="no">正在準備安裝</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_ask_me_later">
      <source>Ask me later</source>
      <translation variants="no">稍後再問我</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_allow_always">
      <source>Allow always</source>
      <translation variants="no">長期允許</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_app_name">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_app_suite_name_version">
      <source>%1 (%2)</source>
      <translation variants="no">%[99]1 (%[99]2)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_perm_query">
      <source>Access to protected functionality needed.</source>
      <translation variants="no">需要接入受保護的功能。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_update_query">
      <source>%1 from %2 to %3?</source>
      <translation variants="no">是否將%[99]1從%[99]2更換為%[99]3？</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_vendor">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_mb">
      <source>%1: Unknown (%L2 MB)</source>
      <translation variants="no">%[99]1：未知(%L2 MB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_kb">
      <source>%1: Phone Memory (%L2 kB) </source>
      <translation variants="no">%[99]1：裝置記憶體(%L2 kB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_kb">
      <source>%1: Unknown (%L2 kB)</source>
      <translation variants="no">%[99]1：未知(%L2 kB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown">
      <source>%1: Unknown</source>
      <translation variants="no">%[99]1：未知</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_gb">
      <source>%1: Unknown (%L2 GB)</source>
      <translation variants="no">%[99]1：未知(%L2 GB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_mb">
      <source>%1: Memory card (%L2 MB) </source>
      <translation variants="no">%[99]1：記憶卡(%L2 MB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_manufacturer">
      <source>Manufacturer</source>
      <translation variants="no">製造商</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_operator_pref">
      <source>Operator preferred</source>
      <translation variants="no">網絡營辦商首選</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_operator">
      <source>Operator</source>
      <translation variants="no">網絡營辦商</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_untrusted_third_party">
      <source>Untrusted 3rd party</source>
      <translation variants="no">不信賴的協力廠商</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain">
      <source>Domain: %1</source>
      <translation variants="no">網域：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_trusted_third_party">
      <source>Trusted 3rd party</source>
      <translation variants="no">信賴的協力廠商</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_fingerprint">
      <source>Fingerprint (SHA1): %1</source>
      <translation variants="no">指紋碼(SHA1)：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_issuer">
      <source>Issuer: %1</source>
      <translation variants="no">簽發者：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_organization">
      <source>Organization: %1</source>
      <translation variants="no">機構：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_serial_number">
      <source>Serial number: %1</source>
      <translation variants="no">序號：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_subject">
      <source>Subject: %1</source>
      <translation variants="no">主題：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_valid_from">
      <source>Valid from: %1</source>
      <translation variants="no">有效期起始於：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_valid_until">
      <source>Valid until: %1</source>
      <translation variants="no">有效期結束於：%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_inst_failed">
      <source>Installation failed</source>
      <translation variants="no">安裝失敗</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_install">
      <source>Install?</source>
      <translation variants="no">是否安裝？</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_installation_complete">
      <source>Installed</source>
      <translation variants="no">已安裝</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_ocsp_check_progress">
      <source>Checking certificate validity</source>
      <translation variants="no">正在檢查證書有效期</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_installing">
      <source>Installing</source>
      <translation variants="no">安裝中</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_downloading">
      <source>Downloading</source>
      <translation variants="no">下載中</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_update_query">
      <source>Update?</source>
      <translation variants="no">是否更新？</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_size_kb">
      <source>%L1 kB</source>
      <translation variants="no">%L1 kB</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_update_retain_user_data">
      <source>Retain application data</source>
      <translation variants="yes">
        <lengthvariant priority="1">保留應用程式數據</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_dialog_password">
      <source>Password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_gb">
      <source>%1: Internal Mass Storage (%L2 GB)</source>
      <translation variants="no">%[99]1：大型記憶體(%L2 GB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_auth_yourself">
      <source>To download %1 you need to authenticate yourself</source>
      <translation variants="no">登入以下載"%[99]1"。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_listl_mem_card">
      <source>%1: Memory card</source>
      <translation variants="no">%[99]1：記憶卡</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">關閉</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_view_perm_details">
      <source>Details</source>
      <translation variants="no">資料</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_kb">
      <source>%1: Internal Mass Storage (%L2 kB)</source>
      <translation variants="no">%[99]1：大型記憶體(%L2 kB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem">
      <source>%1: Phone memory</source>
      <translation variants="no">%[99]1：裝置記憶體</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_back_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">確定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem">
      <source>%1: Internal Mass Storage</source>
      <translation variants="no">%[99]1：大型記憶體</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">確定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_gb">
      <source>%1: Memory card (%L2 GB) </source>
      <translation variants="no">%[99]1：記憶卡(%L2 GB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_mb">
      <source>%1: Internal Mass Storage (%L2 MB)</source>
      <translation variants="no">%[99]1：大型記憶體(%L2 MB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_size_mb">
      <source>%L1 MB</source>
      <translation variants="no">%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_cancel_installing">
      <source>Cancel installing</source>
      <translation variants="no">取消安裝</translation>
    </message>
    <message numerus="no" id="txt_java_inst_dialog_username">
      <source>Username:</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_gb">
      <source>%1: Phone Memory (%L2 GB) </source>
      <translation variants="no">%[99]1：裝置記憶體(%L2 GB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_kb">
      <source>%1: Memory card (%L2 kB) </source>
      <translation variants="no">%[99]1：記憶卡(%L2 kB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_inst_pkg_not_cert">
      <source>Application %1 is from an unknown source. </source>
      <translation variants="no">應用程式"%[99]1"來自未知的來源。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">資料</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_mb">
      <source>%1: Phone Memory (%L2 MB) </source>
      <translation variants="no">%[99]1：裝置記憶體(%L2 MB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_downloading">
      <source>Downloading</source>
      <translation variants="no">zh_hk #Downloading</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installation_complete">
      <source>Installation complete</source>
      <translation variants="no">zh_hk #Installation complete</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installing">
      <source>Installing</source>
      <translation variants="no">zh_hk #Installing</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_ocsp_check_progress">
      <source>Checking certificate validity</source>
      <translation variants="no">zh_hk #Checking validity</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_preparing_installation">
      <source>Preparing installation</source>
      <translation variants="no">zh_hk #Preparing</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installing_progress">
      <source>%1 (%2 %)</source>
      <translation variants="no">zh_hk #%[08]1 (%[08]2%)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_push_registration_static">
      <source>Registration for automatic start needed. Note that installation will fail if not allowed.</source>
      <translation variants="no">應用程式將註冊為自動啟動，否則將無法安裝。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_auth_query">
      <source>Connect to</source>
      <translation variants="no">是否連接至伺服器？</translation>
    </message>
  </context>
</TS>