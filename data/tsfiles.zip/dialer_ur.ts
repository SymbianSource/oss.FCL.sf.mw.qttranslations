<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_dialer_ui_dblist_call_duration">
      <source>Call duration</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال کی مدت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_info_call_event_will_be_removed_from">
      <source>Call event will be removed from the list. Continue?</source>
      <translation variants="no">ur #Call event will be removed from list. Continue?</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_change_call_service_sub_cellul">
      <source>Cellular</source>
      <translation variants="no">سیلولر</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_date_and_time">
      <source>Date and time</source>
      <translation variants="yes">
        <lengthvariant priority="1">تاریخ اور وقت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_change_call_service">
      <source>Change call service</source>
      <translation variants="no">کال خدمت بدلیں</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_dialled">
      <source>Dialled</source>
      <translation variants="yes">
        <lengthvariant priority="1">ڈائل شدہ نمبر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_title_dialer">
      <source>Dialer</source>
      <translation variants="yes">
        <lengthvariant priority="1">ڈائلر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_menu_call_details">
      <source>Call details</source>
      <translation variants="no">کال تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_id">
      <source>Caller ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال کنندہ شناخت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_missed_calls">
      <source>Missed calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">چھوٹی کالیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_voip_call">
      <source>VoiP call</source>
      <translation variants="yes">
        <lengthvariant priority="1">انٹرنیٹ کال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_recent_calls">
      <source>Recent calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ کالیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_recent">
      <source>Recent</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ کالیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_menu_open_contact">
      <source>Open contact</source>
      <translation variants="no">رابطہ کارڈ کھولیں</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_info_all_call_events_will_be_remo">
      <source>All call events will be removed from the list. Continue?</source>
      <translation variants="no">ur #All call events will be removed from list. Continue?</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_dialled">
      <source>Dialled</source>
      <translation variants="yes">
        <lengthvariant priority="1">خارجی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_contact_search_off">
      <source>Contact search off</source>
      <translation variants="no">رابطہ تلاش بند</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_subhead_matches">
      <source>Matches</source>
      <translation variants="yes">
        <lengthvariant priority="1">مطابقتیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_missed">
      <source>Missed</source>
      <translation variants="yes">
        <lengthvariant priority="1">چھوٹ گئی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction">
      <source>Call direction</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال کی سمت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_service">
      <source>Call service</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال خدمت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_call_using">
      <source>Call using</source>
      <translation variants="no">کال کریں بذریعے</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_contact_search_on">
      <source>Contact search on</source>
      <translation variants="no">رابطہ تلاش چالو</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_open_contact">
      <source>Open contact</source>
      <translation variants="no">رابطہ کارڈ کھولیں</translation>
    </message>
    <message numerus="no" id="txt_dial_subhead_received_calls">
      <source>Received calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">موصولہ کالیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_id_val_unknown_number">
      <source>Unknown number</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم نمبر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_call_service_sub_cellular">
      <source>Cellular</source>
      <translation variants="no">سیلولر</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_id_val_privat_number">
      <source>Privat number</source>
      <translation variants="yes">
        <lengthvariant priority="1">نجی نمبر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">ڈائلر</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_video_call">
      <source>Video call</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویڈیو کال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_received">
      <source>Received</source>
      <translation variants="yes">
        <lengthvariant priority="1">داخلی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Save as new contact</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">ur ##Dialer</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_line_id_val_line_2">
      <source>%L1, line 2</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1، لائن ۲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_outgoing_line_2">
      <source>Change outgoing line 2</source>
      <translation variants="no">برآمدی لائن ۲ تبدیل</translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_activated_profile_silent">
      <source>Activated profile: silent</source>
      <translation variants="no">ur #Activated profile: Silent</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_last_call_event">
      <source>Last call event</source>
      <translation variants="yes">
        <lengthvariant priority="1">گزشتہ کال واقعہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_activated_profile_general">
      <source>Activated profile: general</source>
      <translation variants="no">ur #Activated profile: General</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_callee_id">
      <source>Callee ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">وصول کنندہ شناخت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_outgoing_line_1">
      <source>Change outgoing line 1</source>
      <translation variants="no">برآمدی لائن ۱ تبدیل</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_line_id">
      <source>Line ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">لائن شناخت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_no_saved_number_for_this_contact">
      <source>No saved number for this contact. Call not possible</source>
      <translation variants="no">ur #Unable to call. Phone number missing.</translation>
    </message>
    <message numerus="no" id="txt_dial_title_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">روابط میں شامل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type">
      <source>Call type</source>
      <translation variants="yes">
        <lengthvariant priority="1">کال کی قسم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_dialled_calls">
      <source>Dialled calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">ڈائل کیے گئے نمبر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_received">
      <source>Received</source>
      <translation variants="yes">
        <lengthvariant priority="1">موصولہ کالیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_voice_call">
      <source>Voice call</source>
      <translation variants="yes">
        <lengthvariant priority="1">صوتی کال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">ur ##Dialer</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_line_id_val_line_1">
      <source>%L1, line 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1، لائن ۱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_no_history_of_calls">
      <source>No history of calls</source>
      <translation variants="no">(کوئی حالیہ کالیں نہیں)</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_service_val_cellular">
      <source>Cellular</source>
      <translation variants="yes">
        <lengthvariant priority="1">سیلولر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">فہرست صاف کریں</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_missed">
      <source>Missed</source>
      <translation variants="yes">
        <lengthvariant priority="1">چھوٹی کالیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_title_delete_event">
      <source>Delete event</source>
      <translation variants="yes">
        <lengthvariant priority="1">فہرست سے کال ہٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Update existing contact</lengthvariant>
        <lengthvariant priority="2">ur #Update existing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_no_matches_found">
      <source>No matches found</source>
      <translation variants="no">(کوئی مطابقتیں نہیں)</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_val_dialer_enable_access_to_recent">
      <source>Dialer enable access to recent calls and dialpad</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Make calls and see recent calls</lengthvariant>
        <lengthvariant priority="2">ur #Make and see recent calls</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_title_clear_list">
      <source>Clear list</source>
      <translation variants="yes">
        <lengthvariant priority="1">فہرست صاف کریں</lengthvariant>
      </translation>
    </message>
  </context>
</TS>