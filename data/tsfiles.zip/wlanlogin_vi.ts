<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_button_continue_wlanlogin">
      <source>Continue</source>
      <translation variants="no">vi #Continue</translation>
    </message>
    <message numerus="no" id="txt_occ_button_cancel_wlanlogin">
      <source>Cancel</source>
      <translation variants="no">vi #Cancel</translation>
    </message>
    <message numerus="no" id="txt_occ_button_next_wlanlogin">
      <source>Next</source>
      <translation variants="no">vi #Next</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_wlan_login">
      <source>WLAN login</source>
      <translation variants="no">vi #WLAN login</translation>
    </message>
  </context>
</TS>