<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_caption_wlan_login">
      <source>WLAN login</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #WLAN login</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_wlan_connection_closed_login_applica">
      <source>WLAN connection closed. Login application will be closed.</source>
      <translation variants="no">vi #WLAN connection closed. Login application will be closed.</translation>
    </message>
  </context>
</TS>