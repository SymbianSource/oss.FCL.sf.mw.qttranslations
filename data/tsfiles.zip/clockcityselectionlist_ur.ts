<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_formlabel_city_name">
      <source>City name</source>
      <translation variants="yes">
        <lengthvariant priority="1">شہر کا نام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_country">
      <source>Country</source>
      <translation variants="yes">
        <lengthvariant priority="1">ملک/علاقہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_city_list">
      <source>City list</source>
      <translation variants="yes">
        <lengthvariant priority="1">شہر کی فہرست</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_opt_add_own_city">
      <source>Add own city</source>
      <translation variants="no">اپنا شہر شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_timezone">
      <source>Timezone</source>
      <translation variants="yes">
        <lengthvariant priority="1">خطۂ وقت</lengthvariant>
      </translation>
    </message>
  </context>
</TS>