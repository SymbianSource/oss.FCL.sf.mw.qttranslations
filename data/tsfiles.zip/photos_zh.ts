<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_photos_formlabel_location_tag">
      <source>Location tag</source>
      <translation variants="no">位置标签</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_fast">
      <source>Fast</source>
      <translation variants="no">快</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_comments">
      <source>Not specified</source>
      <translation variants="no">注释</translation>
    </message>
    <message numerus="no" id="txt_photos_title_photos">
      <source>Photos</source>
      <translation variants="yes">
        <lengthvariant priority="1">照片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_places_ln">
      <source>Places (%ln)</source>
      <translation variants="no">位置(%L1)</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_slideshow">
      <source>Slideshow</source>
      <translation variants="no">幻灯片放映</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_slow">
      <source>Slow</source>
      <translation variants="no">慢</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay">
      <source>Transistion delay</source>
      <translation variants="no">过渡速度</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_smooth">
      <source>Smooth Fade</source>
      <translation variants="no">平滑变弱</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_add_to_album">
      <source>Add to album</source>
      <translation variants="no">增加至相册</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_mark_all">
      <source>Mark all</source>
      <translation variants="no">标记全部</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_share">
      <source>Share</source>
      <translation variants="no">共享</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_view_releated_items">
      <source>View releated items</source>
      <translation variants="no">查看相关图像</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_play">
      <source>Play</source>
      <translation variants="no">播放</translation>
    </message>
    <message numerus="yes" id="txt_photos_subtitle_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">%Ln个图像</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">拍摄的图像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_shared_with">
      <source>Shared with</source>
      <translation variants="no">共享</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">全部取消标记</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_share">
      <source>Share</source>
      <translation variants="no">共享</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_slideshow">
      <source>Slideshow</source>
      <translation variants="no">幻灯片放映</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_places_l1">
      <source>Not specified</source>
      <translation variants="no">位置(%L1个)</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_val_ln_items">
      <source>%Ln items</source>
      <translation variants="no">%Ln个图像</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect">
      <source>Transistion effect</source>
      <translation variants="no">过渡效果</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_settings">
      <source>Settings</source>
      <translation variants="no">设置</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_medium">
      <source>Medium</source>
      <translation variants="no">中</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_remove_from_album">
      <source>Remove from album</source>
      <translation variants="no">从相册中删除</translation>
    </message>
    <message numerus="no" id="txt_short_caption_photos">
      <source>photos</source>
      <translation variants="no">zh #Photos</translation>
    </message>
    <message numerus="no" id="txt_long_caption_photos">
      <source>photos</source>
      <translation variants="no">照片</translation>
    </message>
    <message numerus="no" id="txt_photos_info_delete_l1_the_files_will_not_be">
      <source>Delete %1? (The files will not be deleted.)</source>
      <translation variants="no">删除%[10]1？将不删除已存储项。</translation>
    </message>
    <message numerus="no" id="txt_photos_info_remove_l1_from_album_the_file_w">
      <source>Remove %1 from album? (The file will not be deleted.)</source>
      <translation variants="no">从相册删除%[16]1？</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_use_image">
      <source>Use image</source>
      <translation variants="no">使用图像</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album">
      <source>Album</source>
      <translation variants="no">相册</translation>
    </message>
    <message numerus="no" id="txt_photos_info_deleting_1">
      <source>Deleting %1?</source>
      <translation variants="no">正在删除%[18]1</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_description">
      <source>Description</source>
      <translation variants="yes">
        <lengthvariant priority="1">说明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_drm_license_info">
      <source>DRM License Info</source>
      <translation variants="no">zh #License details</translation>
    </message>
    <message numerus="no" id="txt_photos_info_no_images_to_play_slideshow">
      <source>No images to play slideshow</source>
      <translation variants="no">zh #No images to play slideshow</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album_ln">
      <source>Album (%Ln)</source>
      <translation variants="no">zh #Album (%Ln)</translation>
    </message>
    <message numerus="no" id="txt_photos_info_unable_to_open_image">
      <source>Unable to open image</source>
      <translation variants="no">zh #Unable to open image</translation>
    </message>
    <message numerus="no" id="txt_photos_grid_no_images">
      <source>No images</source>
      <translation variants="no">zh #No images</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_val_view_details">
      <source>View Details</source>
      <translation variants="no">zh #View Details</translation>
    </message>
    <message numerus="no" id="txt_photos_list_size_1">
      <source>Size: %Ln </source>
      <translation variants="no">zh #Size: %Ln </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_kb">
      <source>Size: %Ln kB</source>
      <translation>
        <numerusform plurality="a">zh #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_grid">
      <source>Grid</source>
      <translation variants="no">zh #Grid</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album_l1">
      <source>Album (%L1)</source>
      <translation variants="no">zh #Album (%L1)</translation>
    </message>
    <message numerus="yes" id="txt_photos_dblist_my_camera_val_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">zh #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_list_date_1">
      <source>Date: %1</source>
      <translation variants="no">zh #Date: %1</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_no_image_or_videos_to_display">
      <source>Not specified</source>
      <translation variants="no">(无图像或视频片段)</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view">
      <source>View</source>
      <translation variants="no">zh #View</translation>
    </message>
    <message numerus="no" id="txt_photos_title_enter_name">
      <source>Enter name :</source>
      <translation variants="yes">
        <lengthvariant priority="1">输入相册名称：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_menu_add_to_album">
      <source>Add to album</source>
      <translation variants="no">增加至相册</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">拍摄的图像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_list_time_1">
      <source>Time: %1</source>
      <translation variants="no">zh #Time: %1</translation>
    </message>
    <message numerus="yes" id="txt_photos_info_delete_ln_items">
      <source>Delete %Ln items?</source>
      <translation>
        <numerusform plurality="a">删除%Ln项？</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_media_wall">
      <source>Media wall</source>
      <translation variants="no">zh #Media wall</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_photos">
      <source>Photos</source>
      <translation variants="no">zh #Photos</translation>
    </message>
    <message numerus="yes" id="txt_photos_info_remove_ln_items_from_album_the">
      <source>Remove %Ln items from album? (The files will not be deleted.)</source>
      <translation>
        <numerusform plurality="a">从相册删除%Ln项？不会从手机上删除这些项。</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_gb">
      <source>Size: %Ln Gb </source>
      <translation>
        <numerusform plurality="a">zh #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_mb">
      <source>Size: %Ln Mb</source>
      <translation>
        <numerusform plurality="a">zh #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_rotate">
      <source>Rotate</source>
      <translation variants="no">zh #Rotate</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_wave">
      <source>Wave</source>
      <translation variants="no">波浪</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_new_album">
      <source>New album</source>
      <translation variants="no">新建相册</translation>
    </message>
  </context>
</TS>