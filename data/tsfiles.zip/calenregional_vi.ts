<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_preview_title_xiao_han">
      <source>Xiao Han</source>
      <translation variants="no">vi #Xiao Han</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_rabbit">
      <source>Year of the Rabbit</source>
      <translation variants="no">vi #Year of the Rabbit</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_mang_zhong">
      <source>Mang Zhong</source>
      <translation variants="no">vi #Mang Zhong</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_gui">
      <source>Gui</source>
      <translation variants="no">vi #Gui</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_gu_yu">
      <source>Gu Yu</source>
      <translation variants="no">vi #Gu Yu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_seventh_night_fest">
      <source>Seventh night festival</source>
      <translation variants="no">vi #Seventh night festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xing">
      <source>Xing</source>
      <translation variants="no">vi #Xing</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_ox">
      <source>Year of the Ox</source>
      <translation variants="no">vi #Year of the Ox</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_bing">
      <source>Bing</source>
      <translation variants="no">vi #Bing</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_xue">
      <source>Xiao Xue</source>
      <translation variants="no">vi #Xiao Xue</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_wu">
      <source>Wu</source>
      <translation variants="no">vi #Wu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_qiu">
      <source>Li Qiu</source>
      <translation variants="no">vi #Li Qiu</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_year">
      <source>%1 %2</source>
      <translation variants="no">vi #%[65]1%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_mid_autumn_fest">
      <source>Mid autumn festival</source>
      <translation variants="no">vi #Mid autumn festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_dog">
      <source>Year of the Dog</source>
      <translation variants="no">vi #Year of the Dog</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_eigth_day_fest">
      <source>Eighth day of twelfth month festival</source>
      <translation variants="no">vi #Eighth day of twelfth month festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_shu">
      <source>Xiao Shu</source>
      <translation variants="no">vi #Xiao Shu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_monkey">
      <source>Year of the Monkey</source>
      <translation variants="no">vi #Year of the Monkey</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_chen">
      <source>Chen</source>
      <translation variants="no">vi #Chen</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_sheep">
      <source>Year of the Sheep</source>
      <translation variants="no">vi #Year of the Sheep</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_chou">
      <source>Chou</source>
      <translation variants="no">vi #Chou</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_dragon">
      <source>Year of the Dragon</source>
      <translation variants="no">vi #Year of the Dragon</translation>
    </message>
    <message numerus="no" id="txt_calendar_animal_year">
      <source>Animal year:</source>
      <translation variants="no">vi #Animal year:</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_hai">
      <source>Hai</source>
      <translation variants="no">vi #Hai</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_new_year_fest">
      <source>New year's eve</source>
      <translation variants="no">vi #New year's eve</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_wu">
      <source>Wu</source>
      <translation variants="no">vi #Wu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_si">
      <source>Si</source>
      <translation variants="no">vi #Si</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_xu">
      <source>Xu</source>
      <translation variants="no">vi #Xu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_yi">
      <source>Yi</source>
      <translation variants="no">vi #Yi</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_reng">
      <source>Reng</source>
      <translation variants="no">vi #Reng</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_dong_zhi">
      <source>Dong Zhi</source>
      <translation variants="no">vi #Dong Zhi</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_cale_separator">
      <source>, </source>
      <translation variants="no">vi # , </translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_shaung_jiang">
      <source>Shaung Jiang</source>
      <translation variants="no">vi #Shaung Jiang</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_han_lu">
      <source>Han Lu</source>
      <translation variants="no">vi #Han Lu</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_leap_date">
      <source>%1L%2</source>
      <translation variants="no">vi #Month (leap) %[57]1, Day %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_da_han">
      <source>Da Han</source>
      <translation variants="no">vi #Da Han</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_mao">
      <source>Mao</source>
      <translation variants="no">vi #Mao</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_you">
      <source>You</source>
      <translation variants="no">vi #You</translation>
    </message>
    <message numerus="no" id="txt_calendar_gregorian_date">
      <source>Gregorian date:</source>
      <translation variants="no">vi #Gregorian date:</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_double_fest">
      <source>Double ninth festival</source>
      <translation variants="no">vi #Double ninth festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_bai_lu">
      <source>Bai Lu</source>
      <translation variants="no">vi #Bai Lu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_yin">
      <source>Yin</source>
      <translation variants="no">vi #Yin</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_123242526">
      <source>%1%2%3%2%4%2%5%2%6</source>
      <translation variants="no">vi #%[71]1%[71]2%[71]3%[70]2%[70]4%[70]2%[70]5%[70]2%6</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_shen">
      <source>Shen</source>
      <translation variants="no">vi #Shen</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_qiu_fen">
      <source>Qiu Fen</source>
      <translation variants="no">vi #Qiu Fen</translation>
    </message>
    <message numerus="no" id="txt_calendar_solar_term">
      <source>Solar term:</source>
      <translation variants="no">vi #Solar term:</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_chun">
      <source>Li Chun</source>
      <translation variants="no">vi #Li Chun</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_ghost_fest">
      <source>Ghost festival</source>
      <translation variants="no">vi #Ghost festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_chun_fen">
      <source>Chun Fen</source>
      <translation variants="no">vi #Chun Fen</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_horse">
      <source>Year of the Horse</source>
      <translation variants="no">vi #Year of the Horse</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_jing_zhe">
      <source>Jing Zhe</source>
      <translation variants="no">vi #Jing Zhe</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_geng">
      <source>Geng</source>
      <translation variants="no">vi #Geng</translation>
    </message>
    <message numerus="no" id="txt_calendar_lunar_date">
      <source>Lunar date:</source>
      <translation variants="no">vi #Lunar date:</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_tiger">
      <source>Year of the Tiger</source>
      <translation variants="no">vi #Year of the Tiger</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_zi">
      <source>Zi</source>
      <translation variants="no">vi #Zi</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_qing_ming">
      <source>Qing Ming</source>
      <translation variants="no">vi #Qing Ming</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_rat">
      <source>Year of the Rat</source>
      <translation variants="no">vi #Year of the Rat</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_chu_shu">
      <source>Chu Shu</source>
      <translation variants="no">vi #Chu Shu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_da_shu">
      <source>Da Shu</source>
      <translation variants="no">vi #Da Shu</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_dragon_fest">
      <source>Dragon boat festival</source>
      <translation variants="no">vi #Dragon boat festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_tbranch_wei">
      <source>Wei</source>
      <translation variants="no">vi #Wei</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_pig">
      <source>Year of the Pig</source>
      <translation variants="no">vi #Year of the Pig</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_yu_shui">
      <source>Yu Shui</source>
      <translation variants="no">vi #Yu Shui</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_ding">
      <source>Ding</source>
      <translation variants="no">vi #Ding</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_snake">
      <source>Year of the Snake</source>
      <translation variants="no">vi #Year of the Snake</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_ji">
      <source>Ji</source>
      <translation variants="no">vi #Ji</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xia_zhi">
      <source>Xia Zhi</source>
      <translation variants="no">vi #Xia Zhi</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_dong">
      <source>Li Dong</source>
      <translation variants="no">vi #Li Dong</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_lantern_fest">
      <source>Lantern festival</source>
      <translation variants="no">vi #Lantern festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_festival">
      <source>Festival:</source>
      <translation variants="no">vi #Festival:</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_jia">
      <source>Jia</source>
      <translation variants="no">vi #Jia</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_year_of_the_rooster">
      <source>Year of the Rooster</source>
      <translation variants="no">vi #Year of the Rooster</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_lunar_calendar">
      <source>Lunar calendar</source>
      <translation variants="no">vi #Lunar calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_da_xue">
      <source>Da Xue</source>
      <translation variants="no">vi #Da Xue</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_spring_fest">
      <source>Spring festival</source>
      <translation variants="no">vi #Spring festival</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_date">
      <source>%1%2</source>
      <translation variants="no">vi #Month %[60]1, Day %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_lunar_full_date">
      <source>%1%2</source>
      <translation variants="no">vi #%[64]1, %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_li_xia">
      <source>Li Xia</source>
      <translation variants="no">vi #Li Xia</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_title_xiao_man">
      <source>Xiao Man</source>
      <translation variants="no">vi #Xiao Man</translation>
    </message>
  </context>
</TS>