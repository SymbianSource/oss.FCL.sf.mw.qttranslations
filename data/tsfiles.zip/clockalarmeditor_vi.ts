<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clk_setlabel_day">
      <source>Day</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_daily">
      <source>Repeat daily</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hàng ngày</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_weekly">
      <source>Repeat weekly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hàng tuần</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_alarm_will_occur_at_1_after_au">
      <source>Alarm will occur at %1 after automatic daylight saving update</source>
      <translation variants="no">Âm báo sẽ lặp lại lúc %[61]1 sau khi cập nhật tự động tiết kiệm giờ ban ngày</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_alarm_occurs_every_day_at_1">
      <source>Alarm occurs every day at %1</source>
      <translation variants="no">Âm báo xảy ra hàng ngày lúc %1</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">Loại bỏ thay đổi</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_alarm_sound">
      <source>Alarm sound</source>
      <translation variants="no">Âm thanh âm báo</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hr_and_2_mins">
      <source>Time to alarm %1 hour and %2 minutes</source>
      <translation variants="no">T.gian cho đến khi â.báo: %[07]1 giờ %[06]2 phút</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_once">
      <source>Once</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_opt_delete">
      <source>Delete</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hrs_and_2_min">
      <source>Time to alarm %1 hours and %2 minute</source>
      <translation variants="no">T.gian cho đến khi â.báo: %[07]1 giờ %[06]2 phút</translation>
    </message>
    <message numerus="no" id="txt_clock_note_alarm_occurs_workdays_at_1">
      <source>Alarm occurs workdays at %1</source>
      <translation variants="no">Âm báo xảy ra vào các ngày làm việc lúc %1</translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày phát âm báo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_note_alarm_occurs_once_only_on_next_1_a">
      <source>Alarm occurs once only on next %1 at %2</source>
      <translation variants="no">Â.báo chỉ xảy ra một lần, %[05]1 tiếp theo lúc %2</translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_time">
      <source>Time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời gian</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_time">
      <source>Time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời gian</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hrs_and_2_mins">
      <source>Time to alarm %1 hours and %2 minutes</source>
      <translation variants="no">T.gian cho đến khi â.báo: %[07]1 giờ %[06]2 phút</translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_note_alarm_occurs_every_week_on_1_at_2">
      <source>Alarm occurs every week on %1 at %2</source>
      <translation variants="no">Âm báo xảy ra mỗi tuần vào %[07]1 lúc %2</translation>
    </message>
    <message numerus="no" id="txt_clock_title_clock3">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đồng hồ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_occurence">
      <source>Occurence</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lặp lại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_val_alarm">
      <source>Alarm</source>
      <translation variants="no">Âm báo</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hr_and_2_min">
      <source>Time to alarm %1 hour and %2 minute</source>
      <translation variants="no">T.gian cho đến khi â.báo: %[07]1 giờ %[06]2 phút</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_on_workdays">
      <source>Repeat on workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày làm việc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời gian phát âm báo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_description">
      <source>Description</source>
      <translation variants="no">Mô tả</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_new_alarm">
      <source>New alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo mới</lengthvariant>
      </translation>
    </message>
  </context>
</TS>