<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_button_digital">
      <source>Digital</source>
      <translation variants="no">zh #Digital</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_format">
      <source>Date format</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Date format</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_use_network_date_time">
      <source>Use network date &amp; time</source>
      <translation variants="no">zh #Use network time and date</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time_separator">
      <source>Time separator</source>
      <translation variants="no">zh #Time separator</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour">
      <source>24 hour</source>
      <translation variants="no">zh #24-hour</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_sunday">
      <source>Sunday</source>
      <translation variants="no">zh #Sunday</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date">
      <source>Date</source>
      <translation variants="no">zh #Date</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_date_time">
      <source>Date &amp; time</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Time and date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_friday">
      <source>Friday</source>
      <translation variants="no">zh #Friday</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy">
      <source>dd mm yyyy</source>
      <translation variants="no">zh #dd mm yyyy</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_week_starts_on">
      <source>Week starts on</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Week starts on</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time">
      <source>Time</source>
      <translation variants="no">zh #Time</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_clock_type">
      <source>Clock Type</source>
      <translation variants="no">zh #Clock type</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_info_date_info">
      <source>%1, %2</source>
      <translation variants="no">zh #%[12]1, %2</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_monday">
      <source>Monday</source>
      <translation variants="no">zh #Monday</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date">
      <source>Time &amp; date</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Time and date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy">
      <source>mm dd yyyy</source>
      <translation variants="no">zh #mm dd yyyy</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_separator">
      <source>Date separator</source>
      <translation variants="no">zh #Date separator</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_workdays">
      <source>Workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Workdays</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_clock_list_ln_minutes">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">zh #%Ln minute</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">zh #Wednesday</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time_format">
      <source>Time format</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Time format</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Regional time and date settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">zh #Tuesday</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour">
      <source>12 hour</source>
      <translation variants="no">zh #12-hour</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_thursday">
      <source>Thursday</source>
      <translation variants="no">zh #Thursday</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_saturday">
      <source>Saturday</source>
      <translation variants="no">zh #Saturday</translation>
    </message>
    <message numerus="no" id="txt_clock_button_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="no">zh #Regional time and date settings</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_place">
      <source>Place</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Place</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd">
      <source>yyyy mm dd</source>
      <translation variants="no">zh #yyyy mm dd</translation>
    </message>
    <message numerus="no" id="txt_clock_button_analog">
      <source>Analog</source>
      <translation variants="no">zh #Analogue</translation>
    </message>
  </context>
</TS>