<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dblist_wireless_lan_val_applib">
      <source>Show WLAN status</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Show WLAN status</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_wireless_lan_applib">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Wireless LAN</lengthvariant>
      </translation>
    </message>
  </context>
</TS>