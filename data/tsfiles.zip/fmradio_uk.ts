<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_rad_info_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">uk #FM Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_search_from_other_store">
      <source>Search from %1</source>
      <translation variants="no">uk #Search from %1</translation>
    </message>
    <message numerus="no" id="qtl_grid_taskswitcher_tiny">
      <source>FM Radio</source>
      <translation variants="no">uk #FM Radio</translation>
    </message>
    <message numerus="no" id="txt_fmradio_list_fm_radio_homescreen_widget">
      <source>FM Radio homescreen widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #FM Radio homescreen widget</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dialog_new_name">
      <source>New name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Нова назва:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_you_can_add_song_to_the_tagged_songs">
      <source>You can add song to the tagged songs list from Recently played songs or from main view if song is identified by FM Radio. </source>
      <translation variants="no">uk #Son can be added to favourites from 'Recently played songs' of from main view if song is identified by Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_opt_play_history">
      <source>Play history</source>
      <translation variants="no">Журнал відтворення</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_tagged_songs_list">
      <source>Clear Tagged songs list?</source>
      <translation variants="no">Видалити всі пісні з обраного?</translation>
    </message>
    <message numerus="no" id="txt_rad_info_remove_song_from_tagged_songs">
      <source>Remove song from tagged songs?</source>
      <translation variants="no">Видалити пісню з обраного?</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_val_l1_mhz">
      <source>%L1 MHz</source>
      <translation variants="no">%L1 МГц</translation>
    </message>
    <message numerus="no" id="txt_fmradio_info_fm_radio_could_not_be_started">
      <source>FM Radio could not be started. </source>
      <translation variants="no">Неможливо ввімкнути радіо</translation>
    </message>
    <message numerus="no" id="txt_rad_list_seeking">
      <source>Seeking</source>
      <translation variants="no">uk #Scanning</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_connect_wired_headset">
      <source>Connect wired headset.</source>
      <translation variants="no">Приєднайте дротову гарнітуру</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_recently_played_songs_list">
      <source>Clear Recently played songs list?</source>
      <translation variants="no">Очистити список недавно відтворюваних пісень?</translation>
    </message>
    <message numerus="no" id="txt_rad_info_recently_played_songs_collects_song2">
      <source>Recently played songs collects song information from radio stations which send the song information using RDS+ technology.</source>
      <translation variants="no">uk #Recently played songs collects song information from radio stations which send the song information using RDS+ technology.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_connect_wired_headset1">
      <source>Connect wired headset.</source>
      <translation variants="no">uk #Connect wired headset</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_favourite_stations_list">
      <source>Clear Favourite stations list?</source>
      <translation variants="no">Видалити всі станції з обраного?</translation>
    </message>
    <message numerus="no" id="txt_rad_button_recently_played_songs">
      <source>Recently played songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Недавно відтворювані</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_jazz_music">
      <source>Jazz Music</source>
      <translation variants="no">uk #Jazz music</translation>
    </message>
    <message numerus="no" id="txt_rad_button_identify_song">
      <source>Identify song</source>
      <translation variants="no">uk #Identify song</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_folk_music">
      <source>Folk Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Народна музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_favourites">
      <source>Favourite stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Обране</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_leisure">
      <source>Leisure</source>
      <translation variants="yes">
        <lengthvariant priority="1">Дозвілля</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_news">
      <source>News</source>
      <translation variants="yes">
        <lengthvariant priority="1">Новини</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_phone_in">
      <source>Phone In</source>
      <translation variants="no">uk #Phone in</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_alarm_test">
      <source>Alarm Test</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тест сигналу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_classic_rock">
      <source>Classic rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Класичний рок</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_light_classical">
      <source>Light classical</source>
      <translation variants="no">uk #Light classical</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_science">
      <source>Science</source>
      <translation variants="yes">
        <lengthvariant priority="1">Наука</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_information">
      <source>Information</source>
      <translation variants="no">uk #Information</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_rhythm_and_blues">
      <source>Rhythm and blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ритм і блюз</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_play_history_is_empty">
      <source>(No songs)</source>
      <translation variants="no">uk #(no songs)</translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_favorite_stations">
      <source>Favorite stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Обране</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_tag_song">
      <source>Tag song</source>
      <translation variants="no">uk #Add to favourites</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_light_classical">
      <source>Light classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">Легка класична музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_documentary">
      <source>Documentary</source>
      <translation variants="no">uk #Documentary</translation>
    </message>
    <message numerus="no" id="txt_rad_list_l1_mhz_small">
      <source>%L1 MHz</source>
      <translation variants="no">uk #%L1 MHz</translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_all_stations">
      <source>All stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Усі станції</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">uk #Deactivate loudspeaker</translation>
    </message>
    <message numerus="no" id="txt_rad_info_travel">
      <source>Travel</source>
      <translation variants="no">uk #Travel</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_country_music">
      <source>Country Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Кантрі</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_easy_listening">
      <source>Easy Listening</source>
      <translation variants="yes">
        <lengthvariant priority="1">Легка музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_talk">
      <source>Religious talk</source>
      <translation variants="no">uk #Religious talk</translation>
    </message>
    <message numerus="no" id="txt_rad_info_folk_music">
      <source>Folk Music</source>
      <translation variants="no">uk #Folk music</translation>
    </message>
    <message numerus="no" id="txt_rad_button_search_all_stations">
      <source>Search all stations</source>
      <translation variants="no">uk #Scan stations</translation>
    </message>
    <message numerus="no" id="txt_rad_info_culture">
      <source>Culture</source>
      <translation variants="no">uk #Culture</translation>
    </message>
    <message numerus="no" id="txt_rad_button_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">uk #Activate</translation>
    </message>
    <message numerus="no" id="txt_rad_info_national_music">
      <source>National Music</source>
      <translation variants="no">uk #National music</translation>
    </message>
    <message numerus="no" id="txt_rad_button_cancel">
      <source>Cancel</source>
      <translation variants="no">uk #Cancel</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_song_was_added_to_favorite_songs">
      <source>Song was added to Tagged songs.</source>
      <translation variants="no">Пісню додано до обраного</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_tag_song">
      <source>Tag song</source>
      <translation variants="no">Додати до обраного</translation>
    </message>
    <message numerus="no" id="txt_rad_info_college">
      <source>College</source>
      <translation variants="no">uk #College</translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_play_history">
      <source>Play history</source>
      <translation variants="yes">
        <lengthvariant priority="1">Журнал відтворення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_menu_remove_tag">
      <source>Remove tag</source>
      <translation variants="no">Видалити з обраного</translation>
    </message>
    <message numerus="no" id="txt_rad_info_country_music">
      <source>Country Music</source>
      <translation variants="no">uk #Country music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_social_affairs">
      <source>Social Affairs</source>
      <translation variants="no">uk #Social affairs</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_other_music">
      <source>Other Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Інша музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_music">
      <source>Religious music</source>
      <translation variants="no">uk #Religious music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_education">
      <source>Education</source>
      <translation variants="no">uk #Education</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_favourite_stations">
      <source>(No favourite stations)</source>
      <translation variants="no">uk #(no favourites)</translation>
    </message>
    <message numerus="no" id="txt_rad_info_continue_using_the_radio_in_offline">
      <source>Continue using the Radio in off-line mode?</source>
      <translation variants="no">Продовжити використання радіо в автономному режимі?</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_travel">
      <source>Travel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Подорожі</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">Класична музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_easy_listening">
      <source>Easy Listening</source>
      <translation variants="no">uk #Easy listening</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_no_stations_found_try_searching">
      <source>No stations found. Try searching stations by scrolling the frequency strip.</source>
      <translation variants="no">Не знайдено станцій. Скорист. смугою частот.</translation>
    </message>
    <message numerus="no" id="txt_rad_button_tagged_songs">
      <source>Tagged songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Обране</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">Очистити список</translation>
    </message>
    <message numerus="no" id="txt_long_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">Радіо</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_remove_favourite">
      <source>Remove from favourites</source>
      <translation variants="no">Видалити з обраного</translation>
    </message>
    <message numerus="no" id="txt_rad_list_searching_all_available_stations_ple">
      <source>Searching all available stations. Please wait.</source>
      <translation variants="no">uk #Scanning available stations</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_public">
      <source>Public</source>
      <translation variants="yes">
        <lengthvariant priority="1">Публічна</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_classical">
      <source>Classical</source>
      <translation variants="no">uk #Classical</translation>
    </message>
    <message numerus="no" id="txt_rad_info_rock_music">
      <source>Rock Music</source>
      <translation variants="no">uk #Rock music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_news">
      <source>News</source>
      <translation variants="no">uk #News</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_nostalgia">
      <source>Nostalgia</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ностальгія</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_language">
      <source>Language</source>
      <translation variants="no">uk #Language</translation>
    </message>
    <message numerus="no" id="txt_rad_info_science">
      <source>Science</source>
      <translation variants="no">uk #Science</translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm">
      <source>Alarm</source>
      <translation variants="no">uk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_rad_info_childrens_programmes">
      <source>Children’s programmes</source>
      <translation variants="no">uk #Children's programmes</translation>
    </message>
    <message numerus="no" id="txt_rad_info_leisure">
      <source>Leisure</source>
      <translation variants="no">uk #Leisure</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_information">
      <source>Information</source>
      <translation variants="yes">
        <lengthvariant priority="1">Інформація</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz2">
      <source>%L1 MHz</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 МГц</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_college">
      <source>College</source>
      <translation variants="yes">
        <lengthvariant priority="1">Коледж</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_language">
      <source>Language</source>
      <translation variants="yes">
        <lengthvariant priority="1">Мова</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_weather">
      <source>Weather</source>
      <translation variants="no">uk #Weather</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rock">
      <source>Soft rock</source>
      <translation variants="no">uk #Soft rock</translation>
    </message>
    <message numerus="no" id="txt_rad_info_nostalgia">
      <source>Nostalgia</source>
      <translation variants="no">uk #Nostalgia</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rhythm_and_blues">
      <source>Soft rhythm and blues</source>
      <translation variants="no">uk #Soft rhythm and blues</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_favourites_add_favourites_to_see">
      <source>You can mark your favourite stations in All stations view by long tapping the station and selecting Add favourite. You can also tap the favourite icon in main view to mark it as a favorite.</source>
      <translation variants="no">uk #You can add a station to favourites by selecting and holding the station and selecting 'Add to favourites'. You can also tap the star icon in main view to add a station to favourites.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_adult_hits">
      <source>Adult hits</source>
      <translation variants="no">uk #Adult hits</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_varied">
      <source>Varied</source>
      <translation variants="yes">
        <lengthvariant priority="1">Різне</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_education">
      <source>Education</source>
      <translation variants="yes">
        <lengthvariant priority="1">Освіта</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_jazz_music">
      <source>Jazz Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Джаз</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_top_40">
      <source>Top 40</source>
      <translation variants="yes">
        <lengthvariant priority="1">40 кращих</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_current_affairs">
      <source>Current affairs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Поточні події</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft">
      <source>Soft</source>
      <translation variants="no">uk #Soft</translation>
    </message>
    <message numerus="no" id="txt_rad_info_rhythm_and_blues">
      <source>Rhythm and blues</source>
      <translation variants="no">uk #Rhythm and blues</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religious_talk">
      <source>Religious talk</source>
      <translation variants="yes">
        <lengthvariant priority="1">Релігійні передачі</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_weather">
      <source>Weather</source>
      <translation variants="yes">
        <lengthvariant priority="1">Погода</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_drama">
      <source>Drama</source>
      <translation variants="yes">
        <lengthvariant priority="1">Драма</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_varied">
      <source>Varied</source>
      <translation variants="no">uk #Varied</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religion">
      <source>Religion</source>
      <translation variants="yes">
        <lengthvariant priority="1">Релігія</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_talk">
      <source>Talk</source>
      <translation variants="yes">
        <lengthvariant priority="1">Розмова</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_finance">
      <source>Finance</source>
      <translation variants="yes">
        <lengthvariant priority="1">Фінанси</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_all_stations_in_stations_list_will_be">
      <source>Stations in station list will be replaced. Favourite stations won't be touched. Continue?</source>
      <translation variants="no">Усі встановлені станції у списку станцій буде замінено. Обрані станції не зміняться. Продовжити?</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_stations_search_stations_automat">
      <source>Search stations automatically by tapping here.</source>
      <translation variants="no">uk #Scan stations automatically by tapping here</translation>
    </message>
    <message numerus="no" id="txt_rad_info_recently_played_songs_collects_song_i">
      <source>Recently played songs collects song information from radio stations which send the song information using RDS+ technology.
Also songs which are identified with ”Identify song” functionality in main view are displayed here.</source>
      <translation variants="no">uk #Recently played songs collects song information from radio stations which send the song information using RDS+ technology.
Also songs which are identified with ”Identify song” functionality in main view are displayed here.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm_test">
      <source>Alarm Test</source>
      <translation variants="no">uk #Alarm test</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_documentary">
      <source>Documentary</source>
      <translation variants="yes">
        <lengthvariant priority="1">Документальні передачі</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft_rock">
      <source>Soft rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">М’який рок</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_pop_music">
      <source>Pop Music</source>
      <translation variants="no">uk #Pop music</translation>
    </message>
    <message numerus="no" id="txt_rad_info_current_affairs">
      <source>Current affairs</source>
      <translation variants="no">uk #Current affairs</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft_rhythm_and_blues">
      <source>Soft rhythm and blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">М’який ритм і блюз</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_delete_station">
      <source>Delete station?</source>
      <translation variants="no">Видалити станцію?</translation>
    </message>
    <message numerus="no" id="txt_rad_info_sport">
      <source>Sport</source>
      <translation variants="no">uk #Sport</translation>
    </message>
    <message numerus="no" id="txt_rad_list_l1_mhz_big">
      <source>%L1 MHz</source>
      <translation variants="no">uk #%L1 MHz</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_search_from_music_store">
      <source>Search from Ovi Music</source>
      <translation variants="no">Перейти до "Музика Ovi"</translation>
    </message>
    <message numerus="no" id="txt_rad_info_top_40">
      <source>Top 40</source>
      <translation variants="no">uk #Top 40</translation>
    </message>
    <message numerus="no" id="txt_fmradio_info_local_frequency_band_automaticall">
      <source>Local frequency band automatically set for radio.</source>
      <translation variants="no">uk #Local frequency band automatically set for radio.</translation>
    </message>
    <message numerus="no" id="txt_rad_button_stations">
      <source>Stations</source>
      <translation variants="no">uk #Station list</translation>
    </message>
    <message numerus="no" id="txt_rad_info_activate_radio_in_offline_mode">
      <source>Activate Fm Radio in off-line mode?</source>
      <translation variants="no">Відкрити радіо в автономному режимі?</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz">
      <source>%L1 MHz</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 МГц</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_personality">
      <source>Personality</source>
      <translation variants="no">uk #Personality</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_phone_in">
      <source>Phone In</source>
      <translation variants="yes">
        <lengthvariant priority="1">Дзвінки у студію</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_classic_rock">
      <source>Classic rock</source>
      <translation variants="no">uk #Classic rock</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_stations">
      <source>(No stations)</source>
      <translation variants="no">uk #(no stations)</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religion">
      <source>Religion</source>
      <translation variants="no">uk #Religion</translation>
    </message>
    <message numerus="no" id="txt_rad_info_station_list_is_full_please_remove_s">
      <source>Station list is full. Please remove some stations and try again.</source>
      <translation variants="no">uk #Station list is full. Please remove some stations and try again.</translation>
    </message>
    <message numerus="no" id="txt_fmradio_list_quick_access_for_fm_radio_in_your">
      <source>Quick access for FM radio in your homescreen.</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Quick access for FM radio in your homescreen.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_rock_music">
      <source>Rock Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Рок</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_national_music">
      <source>National Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Національна музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_oldies_music">
      <source>Oldies Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Стара популярна музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dialog_long_press_arrow_keys_to_search_str">
      <source>Mark favourite stations by pressing the star icon to enable navigation with short arrow presses. You can also swipe here to navigate between all stations. Long press arrow keys to search strong signal stations. </source>
      <translation variants="no">uk #Add stations to favourites by selecting and holding the start icon. You can also swipe here to navigate between all stations. Select and hold arrow keys to scan strong signal stations.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_other_music">
      <source>Other Music</source>
      <translation variants="no">uk #Other music</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_add_to_favourites">
      <source>Add to favourites</source>
      <translation variants="no">Додати до обраного</translation>
    </message>
    <message numerus="no" id="txt_rad_list_unknown">
      <source>(Unknown) - %1</source>
      <translation variants="no">(невідомо) %1</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_pop_music">
      <source>Pop Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Поп-музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_sport">
      <source>Sport</source>
      <translation variants="yes">
        <lengthvariant priority="1">Спорт</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_personality">
      <source>Personality</source>
      <translation variants="yes">
        <lengthvariant priority="1">Персони</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_serious_classical">
      <source>Serious classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">Серйозна класична музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_all_stations_list">
      <source>Clear All stations list?</source>
      <translation variants="no">Очистити список станцій? Усі станції буде видалено.</translation>
    </message>
    <message numerus="no" id="txt_rad_opt_search_all_stations">
      <source>Search all stations</source>
      <translation variants="no">Пошук станцій</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft">
      <source>Soft</source>
      <translation variants="yes">
        <lengthvariant priority="1">М’яка музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_1_2">
      <source>%1 - %2</source>
      <translation variants="no">uk #kkkkkkkkkk - kkkkkkkkkk</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_unknown">
      <source>(Unknown)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(невідомо)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_adult_hits">
      <source>Adult hits</source>
      <translation variants="yes">
        <lengthvariant priority="1">Хіти для дорослих</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_title_fm_radio">
      <source>FM Radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">Радіо</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_finance">
      <source>Finance</source>
      <translation variants="no">uk #Finance</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_childrens_programmes">
      <source>Children’s programmes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Передачі для дітей</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_public">
      <source>Public</source>
      <translation variants="no">uk #Public</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_culture">
      <source>Culture</source>
      <translation variants="yes">
        <lengthvariant priority="1">Культура</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_menu_search_via_shazam">
      <source>Search via Shazam</source>
      <translation variants="no">Ідентиф. пісню в Shazam</translation>
    </message>
    <message numerus="no" id="txt_rad_info_talk">
      <source>Talk</source>
      <translation variants="no">uk #Talk</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">Сигнал</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_social_affairs">
      <source>Social Affairs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Суспільні події</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religious_music">
      <source>Religious music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Релігійна музика</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_drama">
      <source>Drama</source>
      <translation variants="no">uk #Drama</translation>
    </message>
    <message numerus="no" id="txt_rad_info_serious_classical">
      <source>Serious classical</source>
      <translation variants="no">uk #Serious classical</translation>
    </message>
    <message numerus="no" id="txt_short_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">uk #Radio</translation>
    </message>
    <message numerus="no" id="txt_rad_info_searching_local_stations_please_wait">
      <source>Searching local stations. Please wait.</source>
      <translation variants="no">Пошук місцевих станцій</translation>
    </message>
    <message numerus="no" id="txt_rad_info_oldies_music">
      <source>Oldies Music</source>
      <translation variants="no">uk #Oldies music</translation>
    </message>
    <message numerus="no" id="txt_rad_button_local_stations">
      <source>All stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Усі станції</lengthvariant>
      </translation>
    </message>
  </context>
</TS>