<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_randomizer_checkbox_same_numbers">
      <source>Same numbers</source>
      <translation variants="yes">
        <lengthvariant priority="1">使用同个号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_randomizer_button_clear">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">恢复</lengthvariant>
        <lengthvariant priority="2">zh #New message</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_randomizer_button_generate">
      <source>Generate</source>
      <translation variants="yes">
        <lengthvariant priority="1">产生号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_randomizer_checkbox_invert_display_colors">
      <source>Invert display colors</source>
      <translation variants="yes">
        <lengthvariant priority="1">转换显示屏颜色</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_randomizer_title_random_generator">
      <source>Randomizer</source>
      <translation variants="yes">
        <lengthvariant priority="1">号码产生器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_randomizer_checkbox_generate_even_numbers">
      <source>Generate even numbers</source>
      <translation variants="yes">
        <lengthvariant priority="1">产生双数号码</lengthvariant>
      </translation>
    </message>
  </context>
</TS>