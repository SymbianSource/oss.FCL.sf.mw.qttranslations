<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_notes_menu_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="no">更換至待辦事項</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">從我的最愛移除</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">%[32]1到期</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="no">加至我的最愛</translation>
    </message>
    <message numerus="no" id="txt_notes_list_todos">
      <source>To-do's</source>
      <translation variants="no">待辦事項</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">標記為未完成</translation>
    </message>
    <message numerus="no" id="txt_notes_title_notes">
      <source>Notes</source>
      <translation variants="no">備註</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">標記為已完成</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_completed_on_1">
      <source>Completed on %1</source>
      <translation variants="no">完成日期為%1</translation>
    </message>
    <message numerus="no" id="txt_long_caption_notes">
      <source>Notes</source>
      <translation variants="no">備註</translation>
    </message>
    <message numerus="no" id="txt_notes_list_due_date">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_notes_button_new_todo">
      <source>New To-do </source>
      <translation variants="no">新增待辦事項</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_new_note">
      <source>New note</source>
      <translation variants="no">新增備註</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_at_time">
      <source>Modified at %1</source>
      <translation variants="no">修改時間為%1</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_created_on_1_2">
      <source>Created on %1 %2</source>
      <translation variants="no">建立於%[13]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_at_time">
      <source>Created at %1</source>
      <translation variants="no">建立時間為%1</translation>
    </message>
    <message numerus="yes" id="txt_notes_subhead_ln_notes">
      <source>%Ln Notes</source>
      <translation>
        <numerusform plurality="a">%Ln備註</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_description">
      <source>Description:</source>
      <translation variants="no">內容說明：</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_subject">
      <source>Subject:</source>
      <translation variants="no">主題：</translation>
    </message>
    <message numerus="no" id="txt_notes_list_note_count">
      <source>[ %1 ]</source>
      <translation variants="no">[ %[24]1 ]</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_completed_date_val_1">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">標記為未完成</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="no">完成日期：</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_plain_notes">
      <source>Plain notes</source>
      <translation variants="no">純備註</translation>
    </message>
    <message numerus="no" id="txt_notes_list_favorites">
      <source>Favorites</source>
      <translation variants="no">我的最愛</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_note">
      <source>Delete note?</source>
      <translation variants="yes">
        <lengthvariant priority="1">是否刪除備註？</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="yes">
        <lengthvariant priority="1">是否刪除待辦事項？</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_list_no_notes_available">
      <source>No notes available</source>
      <translation variants="no">(沒有備註)</translation>
    </message>
    <message numerus="no" id="txt_notes_list_plain_notes">
      <source>Plain notes</source>
      <translation variants="no">純備註</translation>
    </message>
    <message numerus="no" id="txt_notes_list_alarm_date">
      <source>%1 %2</source>
      <translation variants="no">%[12]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_on_date">
      <source>Created on %1</source>
      <translation variants="no">建立日期為%1</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_notes">
      <source>Delete To-do notes?</source>
      <translation variants="no">是否刪除待辦事項？</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_notes">
      <source>Notes</source>
      <translation variants="no">備註</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_modified_on_1_2">
      <source>Modified on %1 %2</source>
      <translation variants="no">修改於%[13]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_notes">
      <source>Delete notes?</source>
      <translation variants="no">是否刪除備註？</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_favorites">
      <source>Favorites</source>
      <translation variants="no">我的最愛</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="no">未命名</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">標記為已完成</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_on_date">
      <source>Modified on %1</source>
      <translation variants="no">修改日期為%1</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="no">未命名</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_moved_to_todos">
      <source>Note moved to To-do's</source>
      <translation variants="no">備註已移動至待辦事項清單</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_removed_from_favorites">
      <source>Removed from favorites</source>
      <translation variants="no">已從我的最愛移除</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_todos">
      <source>To-do's</source>
      <translation variants="no">待辦事項</translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">zh_hk #Open</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="no">zh_hk #Cancel</translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_item">
      <source>Send</source>
      <translation variants="no">zh_hk #Send</translation>
    </message>
    <message numerus="no" id="txt_common_button_delete">
      <source>Delete</source>
      <translation variants="no">zh_hk #Delete</translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">zh_hk #Delete</translation>
    </message>
    <message numerus="no" id="txt_common_menu_edit">
      <source>Edit</source>
      <translation variants="no">zh_hk #Edit</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>Ok</source>
      <translation variants="no">zh_hk #OK</translation>
    </message>
  </context>
</TS>