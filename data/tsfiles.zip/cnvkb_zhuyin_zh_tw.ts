<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_chinese_vkb_zhuyin_portrait_numbermode_switcher">
      <source>Number</source>
      <translation variants="no">zh_tw #Number</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_zhuyin_landscape_numberandsymbolmode_switcher">
      <source>Number and Symbol</source>
      <translation variants="no">zh_tw #Number and Symbol</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_zhuyin_portrait_language_switcher">
      <source>English</source>
      <translation variants="no">zh_tw #English</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_zhuyin_landscape_language_switcher">
      <source>English</source>
      <translation variants="no">zh_tw #English</translation>
    </message>
    <message numerus="no" id="txt_chinese_vkb_zhuyin_portrait_symbolmode_switcher">
      <source>Symbol</source>
      <translation variants="no">zh_tw #Symbol</translation>
    </message>
  </context>
</TS>