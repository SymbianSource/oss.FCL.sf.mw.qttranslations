<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="it">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Source 0</source>
      <translation variants="no">Cambia durata visibilità</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_input_devices">
      <source>Source 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Dispositivi di immissione</lengthvariant>
        <lengthvariant priority="2">Bluetooth - Disp. di immissione</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>Source 2</source>
      <translation variants="no">Tutti i dispositivi</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_phones">
      <source>Source 3</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun telefono</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_input_devices">
      <source>Source 4</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Dispositivi di immissione associati</lengthvariant>
        <lengthvariant priority="2">Bluetooth - Disp. immiss. associati</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>Source 5</source>
      <translation variants="no">%1 dettagli</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Source 6</source>
      <translation variants="no">Italiano</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Source 7</source>
      <translation variants="yes">
        <lengthvariant priority="1">Associato</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_paired_devices">
      <source>Source 8</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun altro dispositivo associato</lengthvariant>
        <lengthvariant priority="2">Nessun altro disp. associato</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>Source 9</source>
      <translation variants="no">%[16]1 connesso</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Source 10</source>
      <translation variants="yes">
        <lengthvariant priority="1">Automatica</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Source 11</source>
      <translation variants="yes">
        <lengthvariant priority="1">Associato, attendibile, connesso</lengthvariant>
        <lengthvariant priority="2">Associato, attendibile, conn.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Source 12</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Source 13</source>
      <translation variants="yes">
        <lengthvariant priority="1">Associato, connesso</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_phones">
      <source>Source 14</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Telefoni</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Source 15</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Tutti i dispositivi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Source 16</source>
      <translation variants="no">Francese belga</translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Source 17</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dispositivo di immissione</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Source 18</source>
      <translation variants="no">Danese</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Source 19</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chiedi sempre</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>Source 20</source>
      <translation variants="no">US-Internazionale</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Source 21</source>
      <translation variants="no">Disattivato</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_input_devices">
      <source>Source 22</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun dispositivo associato</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Source 23</source>
      <translation variants="no">Dispositivi associati</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_devices">
      <source>Source 24</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Altri dispositivi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Source 25</source>
      <translation variants="yes">
        <lengthvariant priority="1">Computer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>Source 26</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #On and hidden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Source 27</source>
      <translation variants="no">Finlandese, Svedese</translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Source 28</source>
      <translation variants="yes">
        <lengthvariant priority="1">Altro</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Source 29</source>
      <translation variants="no">it #Unpair</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_phones">
      <source>Source 30</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Telefoni associati</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Source 31</source>
      <translation variants="no">Norvegese</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Source 32</source>
      <translation variants="no">Portoghese</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Source 33</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Source 34</source>
      <translation variants="no">Layout tastiera</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Source 35</source>
      <translation variants="yes">
        <lengthvariant priority="1">Impostazioni tastiera</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>Source 36</source>
      <translation variants="no">Regno Unito</translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Source 37</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bloccato</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>Source 38</source>
      <translation variants="no">Tedesco</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>Source 39</source>
      <translation variants="no">US Dvorak</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Source 40</source>
      <translation variants="no">Spagnolo</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_audio_devices">
      <source>Source 41</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Dispositivi audio</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_computers">
      <source>Source 42</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Computer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>Source 43</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun dispositivo trovato</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Source 44</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bloccata</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_audio_devices">
      <source>Source 45</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun dispositivo audio</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>Source 46</source>
      <translation variants="no">Francese</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_computers">
      <source>Source 47</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun computer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_audio_devices">
      <source>Source 48</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Dispositivi audio associati</lengthvariant>
        <lengthvariant priority="2">Bluetooth - Disp. audio associati</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Source 49</source>
      <translation variants="no">it #Search completed</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_paired_devices">
      <source>Source 50</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Altri dispositivi associati</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Source 51</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Impostazioni avanzate</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_audio_devices">
      <source>Source 52</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun dispositivo audio associato</lengthvariant>
        <lengthvariant priority="2">Nessun disp. audio associato</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Source 53</source>
      <translation variants="no">it #Pair</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Source 54</source>
      <translation variants="yes">
        <lengthvariant priority="1">Connessione</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_1">
      <source>Source 55</source>
      <translation variants="no">Bluetooth - %1</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Source 56</source>
      <translation>
        <numerusform plurality="a">it #Visible for %Ln minute</numerusform>
        <numerusform plurality="b">it #Visible for %Ln minutes</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_phones">
      <source>Source 57</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun telefono associato</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_devices">
      <source>Source 58</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun altro dispositivo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Source 59</source>
      <translation variants="yes">
        <lengthvariant priority="1">Impostazioni mouse</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Source 60</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #Visible and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Source 61</source>
      <translation variants="no">Rimuovi</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>Source 62</source>
      <translation variants="no">US Inglese</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Source 63</source>
      <translation variants="no">it #Searching</translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Source 64</source>
      <translation variants="yes">
        <lengthvariant priority="1">Connesso</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>Source 65</source>
      <translation variants="no">Profilo di accesso SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Source 66</source>
      <translation variants="no">Rimuovi disp. associati</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Source 67</source>
      <translation variants="no">Attivato</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Source 68</source>
      <translation variants="no">Dispositivi bloccati</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Source 69</source>
      <translation variants="no">it #Hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Source 70</source>
      <translation variants="no">Russo</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Source 71</source>
      <translation variants="no">Connetti</translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Source 72</source>
      <translation variants="no">it #Disconnect</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Source 73</source>
      <translation variants="no">it #Device details</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>Source 74</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #On and visible</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Source 75</source>
      <translation variants="no">Disconnetti</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>Source 76</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun dispositivo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Source 77</source>
      <translation variants="no">it #Bluetooth - Found devices</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Source 78</source>
      <translation variants="yes">
        <lengthvariant priority="1">Telefono</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Source 79</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #Hidden and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Source 80</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Dispositivi associati</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>Source 81</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun dispositivo associato</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_input_devices">
      <source>Source 82</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun dispositivo di immissione</lengthvariant>
        <lengthvariant priority="2">Nessun disp. di immissione</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Source 83</source>
      <translation variants="yes">
        <lengthvariant priority="1">Associato, attendibile</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Source 84</source>
      <translation variants="no">Impostazioni avanzate</translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Source 85</source>
      <translation variants="no">it #Connect</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Source 86</source>
      <translation variants="no">it #Visible</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Source 87</source>
      <translation variants="no">Olandese</translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Source 88</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dispositivo audio</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_computers">
      <source>Source 89</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nessun computer associato</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_computers">
      <source>Source 90</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Computer associati</lengthvariant>
      </translation>
    </message>
  </context>
</TS>