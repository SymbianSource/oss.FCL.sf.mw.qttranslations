<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv0">
      <source>PEAPv0</source>
      <translation variants="no">zh ##PEAPv0</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate_val_not_in">
      <source>(not in use)</source>
      <translation variants="no">zh ##(not in use)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate">
      <source>Authority certificate</source>
      <translation variants="no">zh ##Authority certificate</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_certificate">
      <source>User certificate</source>
      <translation variants="no">zh ##User certificate</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_provisioning_enabled">
      <source>Enabled</source>
      <translation variants="no">zh ##Enabled</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_cipher_suites">
      <source>Cipher suites</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Cipher suites</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_realm_val_generate_automatically">
      <source>Generate automatically</source>
      <translation variants="no">zh ##Generate automatically</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password">
      <source>PAC store password</source>
      <translation variants="no">zh ##PAC store password</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authenticated_provisioning">
      <source>Authenticated provisioning</source>
      <translation variants="no">zh ##Authenticated provisioning</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_generate_automatica">
      <source>Generate automatically</source>
      <translation variants="no">zh ##Generate automatically</translation>
    </message>
    <message numerus="no" id="txt_occ_button_reset_pac_store">
      <source>Reset PAC store</source>
      <translation variants="no">zh ##Reset PAC store</translation>
    </message>
    <message numerus="no" id="txt_occ_button_inner_eap_type">
      <source>Configure inner EAP type</source>
      <translation variants="no">zh ##Configure inner EAP type</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy_val_on">
      <source>On</source>
      <translation variants="no">zh ##On</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version">
      <source>PEAP version</source>
      <translation variants="no">zh ##PEAP version</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate_val_select">
      <source>Select automatically</source>
      <translation variants="no">zh ##Select automatically</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_realm">
      <source>Realm</source>
      <translation variants="no">zh ##Realm</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unauthenticated_provisioning">
      <source>Unauthenticated provisioning</source>
      <translation variants="no">zh ##Unauthenticated provisioning</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv1">
      <source>PEAPv1</source>
      <translation variants="no">zh ##PEAPv1</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv0_or_peapv1">
      <source>PEAPv0 or PEAPv1</source>
      <translation variants="no">zh ##PEAPv0 or PEAPv1</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_certificate_val_not_in_use">
      <source>(not in use)</source>
      <translation variants="no">zh ##(not in use)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password_val_prompt">
      <source>Prompt</source>
      <translation variants="no">zh ##Prompt</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_pac_store">
      <source>PAC store</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##PAC store</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_eap_module_settings">
      <source>%1 settings</source>
      <translation variants="no">zh ##%1 settings</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_inner_eap_type">
      <source>Inner EAP type</source>
      <translation variants="no">zh ##Inner EAP type</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy">
      <source>TLS privacy</source>
      <translation variants="no">zh ##TLS privacy</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy_val_off">
      <source>Off</source>
      <translation variants="no">zh ##Off</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password_val_user_defin">
      <source>User defined</source>
      <translation variants="no">zh ##User defined</translation>
    </message>
  </context>
</TS>