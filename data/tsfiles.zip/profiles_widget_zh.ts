<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_profileswidget_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">会议</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_profileswidget_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">标准</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_grid_profiles_widget">
      <source>Profiles widget</source>
      <translation variants="no">zh #Profiles widget</translation>
    </message>
    <message numerus="no" id="txt_applib_list_profiles_widget">
      <source>Profiles widget</source>
      <translation variants="no">情景模式</translation>
    </message>
  </context>
</TS>