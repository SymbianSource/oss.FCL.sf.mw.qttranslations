<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phob_list_mycard">
      <source>MyCard</source>
      <translation variants="no">میرا کارڈ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_number">
      <source>Conference number</source>
      <translation variants="no">کانفرنس کا نمبر</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_phone_number">
      <source>Edit phone number</source>
      <translation variants="no">فون نمبر میں ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_groups">
      <source>Delete groups</source>
      <translation variants="no">گروپس مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">تبدیلیاں مسترد</translation>
    </message>
    <message numerus="no" id="txt_phob_list_missed_call">
      <source>Missed call</source>
      <translation variants="no">چھوٹی کال</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_address">
      <source>Address</source>
      <translation variants="no">پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_pager">
      <source>Call Pager</source>
      <translation variants="no">پیجر پر کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_fetch_from_1">
      <source>Fetch from %1</source>
      <translation variants="no">%1 سے بازیافت</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_work">
      <source>Phone (work)</source>
      <translation variants="no">ٹیلی فون (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">رابطہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name_separator">
      <source>Last name, First name</source>
      <translation variants="no">آحر کا نام، پہلا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile">
      <source>Call Mobile</source>
      <translation variants="no">موبائل پر کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites_val_no_favorites_selecte">
      <source>No favorites selected</source>
      <translation variants="no">پسندیدہ رابطے نہیں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_choose_from_my_contacts">
      <source>Choose from my contacts</source>
      <translation variants="no">رابطوں سے منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_pager">
      <source>Pager</source>
      <translation variants="no">پیجر</translation>
    </message>
    <message numerus="no" id="txt_phob_info_clear_communications_history_with_1">
      <source>Delete communications history with %1?</source>
      <translation variants="no">%[63]1 سے مواصلات کی تفصیل مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_to_homescreen_as_widget">
      <source>Send to homescreen</source>
      <translation variants="no">ہوم اسکرین میں شامل</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_work">
      <source>Call Fax (work)</source>
      <translation variants="no">فیکس (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contact_1_saved">
      <source>Contact %1 created</source>
      <translation variants="no">رابطہ %[14]1 تشکیل دیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_email_address">
      <source>Email address</source>
      <translation variants="no">میل پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="no">کار فون پر کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number">
      <source>Video call</source>
      <translation variants="no">ویڈیو کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email">
      <source>Send email</source>
      <translation variants="no">میل بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">میرا کارڈ تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_take_a_new_photo">
      <source>Take a new photo</source>
      <translation variants="no">نئی شبیہ کھینچیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_assistant">
      <source>Assistant</source>
      <translation variants="no">معاون نمبر</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites">
      <source>Favorites</source>
      <translation variants="no">پسندیدہ رابطے</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_work">
      <source>Email (work)</source>
      <translation variants="no">میل پتہ (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="no">موبائل پر کال (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">آخر کا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">(%[22]1) سے بات چیت  کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_birthday">
      <source>Birthday</source>
      <translation variants="no">یوم پیدائش</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_pager">
      <source>Pager</source>
      <translation variants="no">پیجر</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">منصب</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone">
      <source>Phone</source>
      <translation variants="no">ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_home">
      <source>Call Fax (home)</source>
      <translation variants="no">فیکس بھیجیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_new_group_name">
      <source>New group name:</source>
      <translation variants="no">گروپ نام:</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_set_as_favorite">
      <source>Set as favorite</source>
      <translation variants="no">سندیدہ راب. میں شامل</translation>
    </message>
    <message numerus="no" id="txt_phob_list_note">
      <source>Note</source>
      <translation variants="no">نوٹ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">گھنٹی کی ٹون</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile">
      <source>Mobile</source>
      <translation variants="no">موبائل</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">درمیانی نام</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_my_card">
      <source>My card</source>
      <translation variants="no">میرا کارڈ</translation>
    </message>
    <message numerus="no" id="txt_phob_button_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">رابطے درآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_street">
      <source>Street</source>
      <translation variants="no">اسٹریٹ</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">رابطے درآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_work">
      <source>Phone (work)</source>
      <translation variants="no">ٹیلی فون (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile">
      <source>Mobile</source>
      <translation variants="no">موبائل</translation>
    </message>
    <message numerus="yes" id="txt_phob_dblist_val_ln_numbers">
      <source>%Ln number</source>
      <translation>
        <numerusform plurality="a">%Ln نمبر</numerusform>
        <numerusform plurality="b">%Ln نمبر</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone">
      <source>Phone</source>
      <translation variants="no">ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_number">
      <source>Set as default number</source>
      <translation variants="no">بطور آغازی نمبر مرتب</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_home">
      <source>Email (home)</source>
      <translation variants="no">میل بھیجیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message">
      <source>Send message</source>
      <translation variants="no">پیغام بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create">
      <source>Create</source>
      <translation variants="no">تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_assistant">
      <source>Assistant</source>
      <translation variants="no">معاون کا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit_group_details">
      <source>Edit group details</source>
      <translation variants="no">گروپ تفصیل ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_group_1_created">
      <source>New group %1 created</source>
      <translation variants="no">نیا گروپ %[11]1 تشکیل دیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_group_name">
      <source>Group name</source>
      <translation variants="no">گروپ کا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_home">
      <source>Phone (home)</source>
      <translation variants="no">ٹیلی فون (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_yesterday_1">
      <source>yesterday %1</source>
      <translation variants="no">گذشتہ کل %1</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name">
      <source>Last name First name</source>
      <translation variants="no">آخر کا نام پہلا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show">
      <source>Show</source>
      <translation variants="no">دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts">
      <source>Contacts</source>
      <translation variants="no">روابط</translation>
    </message>
    <message numerus="no" id="txt_short_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">روابط</translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_to_contacts">
      <source>Add to contacts</source>
      <translation variants="no">روابط میں شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_name">
      <source>Enter name</source>
      <translation variants="no">نام</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="no">موبائل (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_create_own_card_to_share_it_with_fri">
      <source>Create own card to share it with friends</source>
      <translation variants="no">اپنی تفصیلات کے ساتھ میرا کارڈ تشکیل دیں اور اس میں دوستوں کے ساتھ شراکت کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_updated_1">
      <source>Imported %1</source>
      <translation variants="no">تجدید کی گئی: %1</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_assistant">
      <source>Call assistant</source>
      <translation variants="no">معاون کو کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_favorites">
      <source>Favorites</source>
      <translation variants="no">پسندیدہ</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_url_address">
      <source>Url address</source>
      <translation variants="no">ویب پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url">
      <source>URL</source>
      <translation variants="no">ویب پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url">
      <source>URL</source>
      <translation variants="no">ویب پتے پر جائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_work">
      <source>Address (work)</source>
      <translation variants="no">پتہ (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_province">
      <source>Province</source>
      <translation variants="no">صوبہ</translation>
    </message>
    <message numerus="no" id="txt_phob_list_chooce_from_gallery">
      <source>Chooce from gallery</source>
      <translation variants="no">تصویروں سے انتخاب کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="no">موبائل (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_pager">
      <source>Call Pager</source>
      <translation variants="no">پیجر پر کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_my_card">
      <source>Save My card</source>
      <translation variants="no">میرا کارڈ حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_title_members_of_1_group">
      <source>%1 members</source>
      <translation variants="no">%[17]1 ممبران</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">رابطے درآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_personal_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">گھنٹی کی ٹون</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_history">
      <source>Delete history</source>
      <translation variants="no">تفصیل صاف کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="no">موبائل (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">پسندیدہ سے ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_email">
      <source>Set as default email</source>
      <translation variants="no">بطور آغازی میل مرتب</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sufix">
      <source>Suffix</source>
      <translation variants="no">لاحقہ</translation>
    </message>
    <message numerus="no" id="txt_phob_list_address">
      <source>Address</source>
      <translation variants="no">پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_date">
      <source>Edit date</source>
      <translation variants="no">تاریخ میں ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_company_details">
      <source>Company details</source>
      <translation variants="no">کمپنی تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_work">
      <source>Email (work)</source>
      <translation variants="no">میل بھیجیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_work">
      <source>Video call (work)</source>
      <translation variants="no">ویڈیو کال کریں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_favorites">
      <source>Favorites</source>
      <translation variants="no">پسندیدہ رابطے</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_a_new_contact">
      <source>Create a new contact</source>
      <translation variants="no">نیا رابطہ تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_home">
      <source>URL (home)</source>
      <translation variants="no">ویب پتے جائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_car">
      <source>Car</source>
      <translation variants="no">کار  کا فون</translation>
    </message>
    <message numerus="no" id="txt_phob_title_your_phonebook_is_empty_you_can_ch">
      <source>Your Phonebook is empty</source>
      <translation variants="no">کوئی رابطہ نہیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_image">
      <source>Remove image</source>
      <translation variants="no">شبیہ ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_change_picture">
      <source>Change picture</source>
      <translation variants="no">شبیہ بدلیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_home">
      <source>Call Fax (home)</source>
      <translation variants="no">فیکس بھیجیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">شوہر/بیوی</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_home">
      <source>Address (home)</source>
      <translation variants="no">پتہ (گھر)</translation>
    </message>
    <message numerus="no" id="txt_long_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">روابط</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="no">موبائل پر کال کریں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company">
      <source>Company</source>
      <translation variants="no">کمپنی</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_conference_call">
      <source>Conference call</source>
      <translation variants="no">کانفرنس کال</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_message">
      <source>Send message</source>
      <translation variants="no">پیغام بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_home">
      <source>URL (home)</source>
      <translation variants="no">ویب پتہ (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_new">
      <source>Create new</source>
      <translation variants="no">نیا تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax">
      <source>Call Fax</source>
      <translation variants="no">فیکس بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order">
      <source>Name display order</source>
      <translation variants="no">نام ظاہر کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_work">
      <source>URL (work)</source>
      <translation variants="no">ویب پتے جائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone">
      <source>Call phone</source>
      <translation variants="no">ٹیلی فون پر کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email">
      <source>Email</source>
      <translation variants="no">میل بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard">
      <source>MyCard</source>
      <translation variants="no">میرا کارڈ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_to_homescreen">
      <source>Send to homescreen</source>
      <translation variants="no">ہوم اسکرین میں شامل</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_children">
      <source>Children</source>
      <translation variants="no">بچے</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_presentation_settings">
      <source>Presentation settings</source>
      <translation variants="no">ترتیبات رابطہ</translation>
    </message>
    <message numerus="no" id="txt_phob_list_dialled_call">
      <source>Dialled call</source>
      <translation variants="no">ڈائل شدہ کال</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_your_own_card">
      <source>Create your own card</source>
      <translation variants="no">میرا کارڈ تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_city">
      <source>City</source>
      <translation variants="no">شہر</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">پہلا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_work">
      <source>Send mail (Work)</source>
      <translation variants="no">میل بھیجیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_group_details">
      <source>Edit group details</source>
      <translation variants="no">گروپ تفصیلات میں ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address">
      <source>Address</source>
      <translation variants="no">پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_all_contacts">
      <source>Find: All contacts</source>
      <translation variants="no">تلاش کریں: تمام رابطے</translation>
    </message>
    <message numerus="yes" id="txt_phob_list_ln_numbers">
      <source>%Ln number</source>
      <translation>
        <numerusform plurality="a">%Ln نمبر</numerusform>
        <numerusform plurality="b">%Ln عدد</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard_val_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">میرا کارڈ تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email">
      <source>Email</source>
      <translation variants="no">میل پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_family_details">
      <source>Edit family details</source>
      <translation variants="no">خاندان کی تفصیلات میں ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_nick_name">
      <source>Nick name</source>
      <translation variants="no">عرفیت</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_group">
      <source>Remove from group</source>
      <translation variants="no">گروپ سے ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_home">
      <source>Video call (home)</source>
      <translation variants="no">ویڈیو کال کریں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_as_a_business_card">
      <source>Send as a business card</source>
      <translation variants="no">بطور بز. کارڈ بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_details">
      <source>Details</source>
      <translation variants="no">تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="no">موبائل پر کال کریں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_address_details">
      <source>Edit address details</source>
      <translation variants="no">پتے کی تفصیلات میں ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phob_list_family">
      <source>Family details</source>
      <translation variants="no">خاندان کی تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="no">موبائل (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax">
      <source>Call Fax</source>
      <translation variants="no">فیکس بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_unknown">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_work">
      <source>URL (work)</source>
      <translation variants="no">ویب پتہ (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_date">
      <source>Date</source>
      <translation variants="no">تاریخ</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_groups">
      <source>Groups</source>
      <translation variants="no">گروپس</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_department">
      <source>Department</source>
      <translation variants="no">شعبہ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">بات چیت کریں (%[06]1)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="no">موبائل پر کال (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_assistant">
      <source>Call assistant</source>
      <translation variants="no">معاون کو کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone">
      <source>Call Phone</source>
      <translation variants="no">ٹیلی فون پر کال</translation>
    </message>
    <message numerus="no" id="txt_phob_list_no_favorites_selected">
      <source>No favorites selected</source>
      <translation variants="no">پسندیدہ رابطے نہیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_home">
      <source>Phone (home)</source>
      <translation variants="no">ٹیلی فون (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_your_name">
      <source>Enter your name</source>
      <translation variants="no">آپ کا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_assistant">
      <source>Assistant</source>
      <translation variants="no">معاون کا نمبر</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_home">
      <source>Send mail (home)</source>
      <translation variants="no">میل بھیجیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">عہدہ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_note">
      <source>Note</source>
      <translation variants="no">نوٹ</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile">
      <source>Call mobile</source>
      <translation variants="no">موبائل پر کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_email">
      <source>Email</source>
      <translation variants="no">میل پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_list_number">
      <source>Number</source>
      <translation variants="no">فون نمبر</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_car">
      <source>Car</source>
      <translation variants="no">کار فون</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_email">
      <source>Add email</source>
      <translation variants="no">میل پتہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_no_sim_contacts">
      <source>No SIM contacts</source>
      <translation variants="no">کوئی SIM رابطے نہیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_url">
      <source>URL</source>
      <translation variants="no">ویب پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">تفصیل شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_note">
      <source>Edit note</source>
      <translation variants="no">نوٹ میں ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_contact_card_image_to_business_c">
      <source>Add contact card image to Business card?</source>
      <translation variants="no">رابطہ کارڈ کی شبیہ کو بھی شامل کریں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="no">کار فون پر کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_delete_1">
      <source>Delete %1?</source>
      <translation variants="no">%[91]1 مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_home">
      <source>Call phone (home)</source>
      <translation variants="no">ٹیلی فون پر کال کریں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_field">
      <source>Add detail</source>
      <translation variants="no">تفصیل شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone_val_default">
      <source>Default</source>
      <translation variants="no">آغازی ٹون</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company_details">
      <source>Company Details</source>
      <translation variants="no">کمپنی کی تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_and_phonenumber">
      <source>Name and phonenumber</source>
      <translation variants="no">نام اور فون نمبر</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_phone_number">
      <source>Phone number</source>
      <translation variants="no">فون نمبر</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_work">
      <source>Call phone (work)</source>
      <translation variants="no">ٹیلی فون پر کال کریں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_home">
      <source>Address (home)</source>
      <translation variants="no">پتہ (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_company_details">
      <source>Edit company details</source>
      <translation variants="no">کمپنی تفصیلات میں ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_name">
      <source>Edit name</source>
      <translation variants="no">رابطے کے نام میں ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_work">
      <source>Call Fax (work)</source>
      <translation variants="no">فیکس بھیجیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_group">
      <source>Delete group</source>
      <translation variants="no">گروپ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_ln_contacts_imported">
      <source>%L1 / %L2 contacts imported</source>
      <translation variants="no">%L1/%L2 رابطے درآمد</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">سالگرہ</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_contact">
      <source>New contact</source>
      <translation variants="no">نیا رابطہ</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_first_nam">
      <source>First name Last name</source>
      <translation variants="no">پہلا نام آخر کا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_list_creating_1_group">
      <source>Creating %1 group</source>
      <translation variants="no">%1 گ. تشکیل</translation>
    </message>
    <message numerus="no" id="txt_phob_button_select_location">
      <source>Select location</source>
      <translation variants="no">مقام منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_val_no_members_selected">
      <source>No members selected</source>
      <translation variants="no">کسی ممبر کا انتخاب نہیں کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_formlabel_val_formlabel_v">
      <source>Find location</source>
      <translation variants="no">مقام تلاش کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_title_select_location">
      <source>Select location</source>
      <translation variants="no">مقام کا انتخاب کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_keep_existing_map_location">
      <source>Keep existing location on Map? </source>
      <translation variants="no">موجودہ مقام کو نقشے پر رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_list_no_members_selected">
      <source>No members selected</source>
      <translation variants="no">کوئی نمبر منتخب نہیں کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_home">
      <source>Email (home)</source>
      <translation variants="no">میل پتہ (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contacts_1_updated">
      <source>Contact %1 updated</source>
      <translation variants="no">رابطہ %[11]1 کی تجدید کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phob_title_anniversary">
      <source>Anniversary</source>
      <translation variants="no">سالگرہ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_formlabel_val_no_date_set">
      <source>No date set</source>
      <translation variants="no">(کوئی تاریخ مرتب نہیں)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_contacts">
      <source>Delete contacts</source>
      <translation variants="no">رابطے مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_unable_to_access_contacts_in_memory">
      <source>Unable to access contacts in memory: %1</source>
      <translation variants="no">%[52]1 پر حفظ کیے گئے رابطوں تک رسائی سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_phob_list_email2">
      <source>Email</source>
      <translation variants="no">بذریعے میل</translation>
    </message>
    <message numerus="no" id="txt_phob_title_address_changed">
      <source>Address changed</source>
      <translation variants="no">پتہ تبدیل ہو گیا</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_phob_list_link_in_profile">
      <source>Link in profile</source>
      <translation variants="no">ربط پروفائل</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_countryregion">
      <source>Country/Region</source>
      <translation variants="no">ملک/خطہ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_stateprovince">
      <source>State/Province</source>
      <translation variants="no">ریاست/صوبہ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_postal_codezip_code">
      <source>Postal code/ZIP code</source>
      <translation variants="no">پوسٹل/زپ کوڈ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url">
      <source>URL</source>
      <translation variants="no">ویب پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_delete_1_group">
      <source>Delete %1 group?</source>
      <translation variants="no">گروپ %[10]1 مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_search_for_matched_contacts">
      <source>Search for matched contacts</source>
      <translation variants="no">مطابقتوں تلاش کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_image">
      <source>Remove image</source>
      <translation variants="no">شبیہ ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_group">
      <source>New group</source>
      <translation variants="no">نیا گروپ</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_history_with_1">
      <source>History with %1</source>
      <translation variants="no">%1 سے گفتگو</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message_val_members">
      <source>Members</source>
      <translation variants="no">ممبران</translation>
    </message>
    <message numerus="no" id="txt_phob_list_received">
      <source>Received call</source>
      <translation variants="no">موصولہ کال</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">ایکسٹینشن</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_work">
      <source>Fax (work)</source>
      <translation variants="no">فیکس (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_change_image">
      <source>Change image</source>
      <translation variants="no">شبیہ تبدیل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_you_can_restore_linking_at_any_tim">
      <source>You can restore linking at any time by `Link profile´ or in Service view.</source>
      <translation variants="no">'ربط پروفائل' کا انتخاب کر کے یا خدمت منظر میں ربط کو کسی بھی وقت بحال کیا جا سکتا ہے۔</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">روابط</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="no">(بے نام)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_services">
      <source>Manage services</source>
      <translation variants="no">خدمات کا انتظام کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_matching_contacts">
      <source>(no matching contacts)</source>
      <translation variants="no">(کوئی مطابقتیں نہیں)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_home">
      <source>URL (home)</source>
      <translation variants="no">ویب پتہ (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_home">
      <source>Email (home)</source>
      <translation variants="no">میل پتہ (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_cancel">
      <source>Cancel</source>
      <translation variants="no">منسوخ کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email">
      <source>Email</source>
      <translation variants="no">میل پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_status_update">
      <source>Status update</source>
      <translation variants="no">حیثیت</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_work">
      <source>Call Phone (work)</source>
      <translation variants="no">فون پر کال (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_home">
      <source>Call Phone (home)</source>
      <translation variants="no">فون پر کال (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_only_group_will_be_removed_contac">
      <source>Only group will be removed. Contacts can be found from all contacts list.</source>
      <translation variants="no">صرف گروپ کو مٹایا جائے گا۔ رابطے تمام رابطہ فہرستوں میں مل سکتے ہیں۔</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_car">
      <source>Delete Car</source>
      <translation variants="no">کار فون مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_spouse">
      <source>Delete Spouse details</source>
      <translation variants="no">شریکحیات نام مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_date">
      <source>Add Date</source>
      <translation variants="no">تاریخ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_pager">
      <source>Delete Pager</source>
      <translation variants="no">پیجر مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_work">
      <source>Delete Phone (work)</source>
      <translation variants="no">فون مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_sync_with_ovi">
      <source>Sync with OVI</source>
      <translation variants="no">Ovi روابط سے ہمزمانہ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_home">
      <source>Delete Address (home)</source>
      <translation variants="no">پتہ مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_assistant">
      <source>Delete Assistant number</source>
      <translation variants="no">معاون کا نمبر مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_sim">
      <source>Import from SIM</source>
      <translation variants="no">SIM کارڈ سے درآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_home">
      <source>Delete Email (home)</source>
      <translation variants="no">میل پتہ مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax">
      <source>Delete Fax</source>
      <translation variants="no">فیکس مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_ringing_tone">
      <source>Delete Ringing tone</source>
      <translation variants="no">گھنٹی ٹون مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_home">
      <source>Delete Fax (home)</source>
      <translation variants="no">فیکس مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_sip">
      <source>Delete SIP</source>
      <translation variants="no">SIP مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_company_details">
      <source>Add Company details</source>
      <translation variants="no">کمپنی تفصیل شامل</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_family_details">
      <source>Add Family details</source>
      <translation variants="no">خاندان تفصیلات شامل</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_image_not_added">
      <source>Image not included.</source>
      <translation variants="no">شبیہ شامل نہیں کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_device">
      <source>Importing contacts from Device</source>
      <translation variants="no">آلے سے رابطوں کی درآمد ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_phob_title_manage_services">
      <source>Manage services</source>
      <translation variants="no">خدمات کا انتظام کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_work">
      <source>Delete Mobile (work)</source>
      <translation variants="no">موبائل مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_work">
      <source>Delete Internet telephone (work)</source>
      <translation variants="no">نیٹ ف. مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address">
      <source>Delete Address</source>
      <translation variants="no">پتہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax">
      <source>Fax</source>
      <translation variants="no">فیکس</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_pobox">
      <source>P.O.Box</source>
      <translation variants="no">پوسٹ آفس باکس</translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts_sync">
      <source>Contacts sync</source>
      <translation variants="no">روابط کی ہمزمانگی کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_sign_out">
      <source>Sign out</source>
      <translation variants="no">سائن آؤٹ کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_link_to_phonebook">
      <source>Link to phonebook</source>
      <translation variants="no">روابط سے مربوط کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_with_ovi_by_nokia_you_can_access_you">
      <source>With Ovi by Nokia you can access your favourite social networks and make your Contacts social.</source>
      <translation variants="no">Ovi کے ساتھ Nokia سے آپ اپنے پسندیدہ سماجی نیٹ ورکس تک رسائی کر سکتے اور اپنے روابط کو سماجی بنا سکتے ہین۔</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_company_details">
      <source>Delete Company Details</source>
      <translation variants="no">کمپنی تفص. مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_email">
      <source>Add Email</source>
      <translation variants="no">میل پتہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_address">
      <source>Add Address</source>
      <translation variants="no">پتہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_children">
      <source>Delete Children details</source>
      <translation variants="no">بچوں کے نام مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_birthday">
      <source>Delete Birthday</source>
      <translation variants="no">یوم پیدائش مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_no_sim_card">
      <source>No SIM card</source>
      <translation variants="no">کوئی SIM کارڈ نہیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_my_card">
      <source>Clear My card</source>
      <translation variants="no">میرا کارڈ صاف کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_title_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">رابطے درآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_manage_services">
      <source>Manage services</source>
      <translation variants="no">خدمات کا انتظام کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_device">
      <source>Import from Device</source>
      <translation variants="no">آلے سے درآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_my_details">
      <source>Edit My details</source>
      <translation variants="no">میرا کارڈ تفصیلات میں ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_sign_in">
      <source>Sign in</source>
      <translation variants="no">سائن ان کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_remove_all_personal_data_from_my_c">
      <source>Remove all personal data from My card?</source>
      <translation variants="no">میرا کارڈ سے تمام ذاتی ڈیٹا صاف کریں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_work">
      <source>Delete Fax (work)</source>
      <translation variants="no">فیکس مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_home">
      <source>Delete URL (home)</source>
      <translation variants="no">ویب پتہ مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_home">
      <source>Delete Phone (home)</source>
      <translation variants="no">فون مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_manage_services">
      <source>Manage services</source>
      <translation variants="no">خدمات منظم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi">
      <source>OVI contacts sync</source>
      <translation variants="no">Ovi روابط سے ہمزمانگی</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_number">
      <source>Add Number</source>
      <translation variants="no">فون نمبر شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_home">
      <source>Delete Internet telephone (home)</source>
      <translation variants="no">نیٹ فون مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_note">
      <source>Delete Note</source>
      <translation variants="no">نوٹ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile">
      <source>Delete Mobile</source>
      <translation variants="no">موبائل مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone">
      <source>Delete Phone</source>
      <translation variants="no">ٹیلی فون مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">رابطہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">پسندیدہ سے ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_contact">
      <source>Save contact</source>
      <translation variants="no">رابطہ حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_web_address">
      <source>Edit web address</source>
      <translation variants="no">ویب پتے میں ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_email_address">
      <source>Edit email address</source>
      <translation variants="no">میل پتے میں ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_title_birthday">
      <source>Birthday</source>
      <translation variants="no">یوم پیدائش</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_phone_number_for_1">
      <source>No phone number for %1</source>
      <translation variants="no">%[51]1 کے لیے کسی فون نمبر کی وضاحت نہیں کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phob_list_business_card">
      <source>Business card</source>
      <translation variants="no">بزنس کارڈ</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_favorites">
      <source>Manage favorites</source>
      <translation variants="no">پسندیدہ رابطے منظم</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_sign_in_to_res">
      <source>Sign in to OVI</source>
      <translation variants="no">Nokia اکاؤنٹ میں سائن ان</translation>
    </message>
    <message numerus="no" id="txt_phob_list_searching_1">
      <source>Searching %1</source>
      <translation variants="no">تلاش برائے '%[51]1'</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sync_with_ovi_contacts">
      <source>Sync with OVI contacts</source>
      <translation variants="no">روابط کی ہمزمانگی  جاری</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_conference_call">
      <source>Conference call</source>
      <translation variants="no">کانفرنس کال</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts2">
      <source>All contacts</source>
      <translation variants="no">تمام رابطے</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="no">Mail for Exchange</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_mail">
      <source>Send mail</source>
      <translation variants="no">میل بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="no">Mail for Exchange</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_method">
      <source>Select method</source>
      <translation variants="no">بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_find_from">
      <source>Find from:</source>
      <translation variants="no">تلاش کریں از:</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_internet_number">
      <source>Edit internet number</source>
      <translation variants="no">انٹرنیٹ فون تفص. میں ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_groups">
      <source>Delete groups</source>
      <translation variants="no">گروپس مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_number">
      <source>Add number</source>
      <translation variants="no">نمبر شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_mycard_image_to_business_card">
      <source>Add MyCard image to Business card?</source>
      <translation variants="no">میرے کارڈ کی شبیہ بھی شامل کریں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_favorites">
      <source>Add favorites</source>
      <translation variants="no">پسندیدہ رابطے شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_title_favorite_contacts">
      <source>Favorite contacts</source>
      <translation variants="no">پسندیدہ رابطے</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">ٹیلی فون (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_mail_for_exchange">
      <source>Find: Mail for Exchange</source>
      <translation variants="no">تلاش کریں:  Mail for Exchange</translation>
    </message>
    <message numerus="no" id="txt_phob_list_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">بذریعہ Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_phob_button_link_profiles">
      <source>Link profiles</source>
      <translation variants="no">لنک پروفائلز</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_message">
      <source>Send message</source>
      <translation variants="no">پیغام بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_only">
      <source>Name only</source>
      <translation variants="no">صرف نام</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_work">
      <source>Address (work)</source>
      <translation variants="no">پتہ (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_select_contact">
      <source>Select contact</source>
      <translation variants="no">رابطہ منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_work">
      <source>URL (work)</source>
      <translation variants="no">ویب پتہ (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_link_in_1">
      <source>Link in %1</source>
      <translation variants="no">%1 سے مربوط کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_unlink">
      <source>Unlink</source>
      <translation variants="no">ربط ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_service">
      <source>Select service</source>
      <translation variants="no">خدمت کا اتنخاب کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_title_remove_link">
      <source>Remove link? </source>
      <translation variants="no">ربط ہٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_list_unnamed">
      <source>Unnamed</source>
      <translation variants="no">(بے نام)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_address2">
      <source>Address</source>
      <translation variants="no">پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_home">
      <source>Delete Mobile (home)</source>
      <translation variants="no">موبائل مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email">
      <source>Delete Email</source>
      <translation variants="no">میل پتہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_work">
      <source>Delete Email (work)</source>
      <translation variants="no">پتہ مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_sim">
      <source>Importing contacts from SIM</source>
      <translation variants="no">SIM سے رابطوں کی درآمد ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_work">
      <source>Delete Address (work)</source>
      <translation variants="no">پتہ مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_details">
      <source>Edit contact details</source>
      <translation variants="no">رابطہ تفصیلات میں ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_work">
      <source>Delete URL (work)</source>
      <translation variants="no">و. پتہ مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_note">
      <source>Add note</source>
      <translation variants="no">شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_search_results">
      <source>Show results</source>
      <translation variants="no">نتائج دکھائیں</translation>
    </message>
    <message numerus="yes" id="txt_phob_dpophead_ln_contacts_linked">
      <source>%Ln contacts linked</source>
      <translation>
        <numerusform plurality="a">%Ln رابطہ مربوط</numerusform>
        <numerusform plurality="b">%Ln رابطے مربوط</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="no">نیا رابطہ تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_services_activated_would_you_lik">
      <source>No services activated, would you like to do it now?</source>
      <translation variants="no">خدمات کارآمد نہیں کی گئیں۔ اب کارآمد کریں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete_selected">
      <source>Delete selected</source>
      <translation variants="no">مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_val_not_logged_in">
      <source>Not logged in</source>
      <translation variants="no">سائن ان نہیں کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_transfer_via_b">
      <source>Transfer via bluetooth</source>
      <translation variants="no">Bluetooth سے بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sim_card_error">
      <source>SIM card error </source>
      <translation variants="no">SIM کارڈ کی غلطی</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_work">
      <source>Email (work)</source>
      <translation variants="no">میل پتہ (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_1_group">
      <source>%1 group</source>
      <translation variants="no">گروپ %[25]1</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_home">
      <source>Fax (home)</source>
      <translation variants="no">فیکس (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_anniversary">
      <source>Delete Anniversary</source>
      <translation variants="no">سالگرہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_url">
      <source>Add URL</source>
      <translation variants="no">ویب پتہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url">
      <source>Delete URL</source>
      <translation variants="no">ویب پتہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts">
      <source>All contacts</source>
      <translation variants="no">تمام رابطے</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_services_activated">
      <source>No services activated.</source>
      <translation variants="no">کوئی خدمت کارآمد نہیں کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone">
      <source>Delete Internet telephone</source>
      <translation variants="no">انٹرنیٹ فون مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_favorites_selected_select_your_p">
      <source>No favorites selected, select your preferrred contacts</source>
      <translation variants="no">کوئی پسندیدہ رابطہ نشان زد نہیں کیا گیا۔ پسندیدہ رابطوں میں اپنے ترجیحی رابطے شامل کریں۔</translation>
    </message>
    <message numerus="no" id="txt_phob_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="no">موجودہ رابطے کی تجدید کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_close">
      <source>Close</source>
      <translation variants="no">بند کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_message">
      <source>Message</source>
      <translation variants="no">بذریعہ پیغام</translation>
    </message>
    <message numerus="yes" id="txt_phob_title_l1_matches_found">
      <source>%Ln Matches found</source>
      <translation>
        <numerusform plurality="a">%Ln مطابقتیں ملیں</numerusform>
        <numerusform plurality="b">ur #%Ln matches found</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_url">
      <source>Add Url</source>
      <translation variants="no">ویب پتہ شامل کریں</translation>
    </message>
  </context>
</TS>