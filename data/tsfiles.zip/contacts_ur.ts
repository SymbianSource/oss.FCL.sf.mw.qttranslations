<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phob_info_no_services_activated_would_you_lik">
      <source>No services activated, would you like to do it now?</source>
      <translation variants="no">خدمات کارآمد نہیں کی گئیں۔ اب کارآمد کریں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_home">
      <source>Email (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل پتہ (گھر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_no_sim_contacts">
      <source>No SIM contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی SIM رابطے نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویب پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">تفصیل شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_note">
      <source>Edit note</source>
      <translation variants="yes">
        <lengthvariant priority="1">نوٹ میں ترمیم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_contact_card_image_to_business_c">
      <source>Add contact card image to Business card?</source>
      <translation variants="no">رابطہ کارڈ کی شبیہ کو بھی شامل کریں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_matches">
      <source>No matches</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_url">
      <source>Add URL</source>
      <translation variants="no">ویب پتہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url">
      <source>Delete URL</source>
      <translation variants="no">ویب پتہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts">
      <source>All contacts</source>
      <translation variants="no">تمام رابطے</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_services_activated">
      <source>No services activated.</source>
      <translation variants="no">کوئی خدمت کارآمد نہیں کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone">
      <source>Delete Internet telephone</source>
      <translation variants="no">انٹرنیٹ فون مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_pager">
      <source>Delete Pager</source>
      <translation variants="no">پیجر مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_sim">
      <source>Import from SIM</source>
      <translation variants="yes">
        <lengthvariant priority="1">SIM کارڈ سے درآمد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_home">
      <source>Delete Email (home)</source>
      <translation variants="no">میل پتہ مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_car">
      <source>Delete Car</source>
      <translation variants="no">کار فون مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax">
      <source>Delete Fax</source>
      <translation variants="no">فیکس مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_spouse">
      <source>Delete Spouse</source>
      <translation variants="no">شریکحیات نام مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_date">
      <source>Add Date</source>
      <translation variants="no">تاریخ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_work">
      <source>Delete Phone (work)</source>
      <translation variants="no">فون مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_ringing_tone">
      <source>Delete Ringing tone</source>
      <translation variants="no">گھنٹی ٹون مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_assistant">
      <source>Delete Assistant</source>
      <translation variants="no">معاون کا نمبر مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_sign_out">
      <source>Sign out</source>
      <translation variants="no">سائن آؤٹ کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_manage_services">
      <source>Manage services</source>
      <translation variants="yes">
        <lengthvariant priority="1">خدمات کا انتظام کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_sip">
      <source>Delete SIP</source>
      <translation variants="no">SIP مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_my_details">
      <source>Edit My details</source>
      <translation variants="yes">
        <lengthvariant priority="1">میرا کارڈ تفصیلات میں ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_company_details">
      <source>Add Company details</source>
      <translation variants="no">کمپنی تفصیل شامل</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_remove_all_personal_data_from_my_c">
      <source>Remove all personal data from My card</source>
      <translation variants="no">میرا کارڈ سے تمام ذاتی ڈیٹا صاف کریں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_company_details">
      <source>Delete Company Details</source>
      <translation variants="no">کمپنی تفص. مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_work">
      <source>Delete Fax (work)</source>
      <translation variants="no">فیکس مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts_sync">
      <source>Contacts sync</source>
      <translation variants="yes">
        <lengthvariant priority="1">روابط کی ہمزمانگی کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_home">
      <source>Delete Phone (home)</source>
      <translation variants="no">فون مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_device">
      <source>Importing contacts from Device</source>
      <translation variants="no">فون سے رابطوں کی درآمد ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_phob_button_manage_services">
      <source>Manage services</source>
      <translation variants="no">خدمات منظم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_work">
      <source>Delete Mobile (work)</source>
      <translation variants="no">موبائل مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_ovi">
      <source>Importing contacts from OVI</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi">
      <source>Import from OVI</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ovi روابط سے ہمزمانگی</lengthvariant>
        <lengthvariant priority="2">ur #Sync with Ovi Contacts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_email">
      <source>Add Email</source>
      <translation variants="no">میل پتہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_number">
      <source>Add Number</source>
      <translation variants="no">فون نمبر شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_children">
      <source>Delete Children</source>
      <translation variants="no">بچوں کے نام مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_home">
      <source>Delete Internet telephone (home)</source>
      <translation variants="no">نیٹ فون مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_no_sim_card">
      <source>No SIM card</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی SIM کارڈ نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_birthday">
      <source>Delete Birthday</source>
      <translation variants="no">یوم پیدائش مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_note">
      <source>Delete Note</source>
      <translation variants="no">نوٹ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile">
      <source>Delete Mobile</source>
      <translation variants="no">موبائل مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone">
      <source>Delete Phone</source>
      <translation variants="no">ٹیلی فون مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_business_card">
      <source>Business card</source>
      <translation variants="no">ur #Business card</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_video_call">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_video_call_work">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_video_call_home">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_home">
      <source>URL (home)</source>
      <translation variants="no">ویب پتہ (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_home">
      <source>Email (home)</source>
      <translation variants="no">میل پتہ (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_only_group_will_be_removed_contac">
      <source>Only group will be removed. Contacts can be found from all contacts list.</source>
      <translation variants="no">صرف گروپ کو مٹایا جائے گا۔ رابطے تمام رابطہ فہرستوں میں مل سکتے ہیں۔</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_countryregion">
      <source>Country/Region</source>
      <translation variants="no">ملک/خطہ</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_1_group">
      <source>%1 group</source>
      <translation variants="no">گروپ %1</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_image_not_added">
      <source>Image not included.</source>
      <translation variants="no">شبیہ شامل نہیں کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_stateprovince">
      <source>State/Province</source>
      <translation variants="no">ریاست/صوبہ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_work">
      <source>Fax (work)</source>
      <translation variants="no">فیکس (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url">
      <source>URL</source>
      <translation variants="no">ویب پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_home">
      <source>Fax (home)</source>
      <translation variants="no">فیکس (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_manage_services">
      <source>Manage services</source>
      <translation variants="yes">
        <lengthvariant priority="1">خدمات کا انتظام کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_group">
      <source>New group</source>
      <translation variants="no">نیا گروپ</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_delete_1_group">
      <source>Delete %1 group?</source>
      <translation variants="no">گروپ %[10]1 مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_image">
      <source>Remove image</source>
      <translation variants="no">شبیہ ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message_val_members">
      <source>Members</source>
      <translation variants="yes">
        <lengthvariant priority="1">ممبران</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_history_with_1">
      <source>History with %1</source>
      <translation variants="no">%1 سے گفتگو</translation>
    </message>
    <message numerus="no" id="txt_phob_list_received">
      <source>Received</source>
      <translation variants="no">ur #Received call</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_services">
      <source>Manage services</source>
      <translation variants="no">خدمات کا انتظام کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_matching_contacts">
      <source>(no matching contacts)</source>
      <translation variants="no">ur #(no matches)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_you_can_restore_linking_at_any_tim">
      <source>You can restore linking at any time by `Link profile´ or in Service view.</source>
      <translation variants="no">'ربط پروفائل' یا اندرون خدمت منظر کا انتخاب کر کے ربط کو کسی بھی وقت بحال کیا جا سکتا ہے۔</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">ur #Contacts</translation>
    </message>
    <message numerus="no" id="txt_phob_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">منسوخ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">ایکسٹینشن</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">(بے نام)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email">
      <source>Email</source>
      <translation variants="no">میل پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_status_update">
      <source>Status update</source>
      <translation variants="no">حیثیت</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company_details_val_fax">
      <source>Fax</source>
      <translation variants="no">ur #Fax</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ovi_val_connected_to_1">
      <source>Connected to %1</source>
      <translation variants="no">%[09]1 سے اتصال شدہ</translation>
    </message>
    <message numerus="no" id="txt_phob_title_favorite_contacts">
      <source>Favorite contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">پسندیدہ رابطے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_1_group_created">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">ٹیلی فون (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_mail_for_exchange">
      <source>Find: Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">تلاش کریں:  Mail for Exchange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_message">
      <source>Message</source>
      <translation variants="yes">
        <lengthvariant priority="1">بذریعہ پیغام</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_phob_title_l1_matches_found">
      <source>%L1 Matches found</source>
      <translation>
        <numerusform plurality="a">%Ln مطابقت ملا</numerusform>
        <numerusform plurality="b">ur #%Ln matches found</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_url">
      <source>Add Url</source>
      <translation variants="no">ویب پتہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_sign_in_to_res">
      <source>Sign in to restore or create account</source>
      <translation variants="yes">
        <lengthvariant priority="1">اپنے Nokia اکاؤنٹ میں سائن ان  کریں</lengthvariant>
        <lengthvariant priority="2">Nokia اکاؤنٹ میں سائن ان</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_searching_1">
      <source>Searching %1</source>
      <translation variants="no">تلاش برائے '%[51]1'</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ovi">
      <source>Ovi</source>
      <translation variants="no">Nokia اکاؤنٹ</translation>
    </message>
    <message numerus="no" id="txt_phob_list_conference_call">
      <source>Conference call</source>
      <translation variants="no">کانفرنس کال</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_mail">
      <source>Send mail</source>
      <translation variants="no">میل بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts2">
      <source>All contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">تمام رابطے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mail for Exchange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_import_contacts">
      <source>Import contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">رابطے درآمد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_method">
      <source>Select method</source>
      <translation variants="yes">
        <lengthvariant priority="1">بھیجیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_groups">
      <source>Delete groups</source>
      <translation variants="yes">
        <lengthvariant priority="1">گروپس مٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">بذریعہ Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_link_profiles">
      <source>Link profiles</source>
      <translation variants="yes">
        <lengthvariant priority="1">لنک پروفائلز</lengthvariant>
        <lengthvariant priority="2">ل. پروفائلز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_message">
      <source>Send message</source>
      <translation variants="no">پیغام بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_online">
      <source>Not specified</source>
      <translation variants="no">آن لائن</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_home">
      <source>Address (home)</source>
      <translation variants="no">پتہ (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_company_details">
      <source>Not specified</source>
      <translation variants="yes">
        <lengthvariant priority="1">کمپنی تفصیلات میں ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_online2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_home">
      <source>Call phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹیلی فون پر کال کریں (گھر)</lengthvariant>
        <lengthvariant priority="2">فون پر کال (گھر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_work">
      <source>Call phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹیلی فون پر کال کریں (دفتر)</lengthvariant>
        <lengthvariant priority="2">فون پر کال (دفتر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete2">
      <source>Delete</source>
      <translation variants="no">مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_work">
      <source>Address (work)</source>
      <translation variants="no">پتہ (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number">
      <source>Video call</source>
      <translation variants="no">ویڈیو کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_work">
      <source>Email (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل پتہ (گھر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_contact_to_homescreen">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_address">
      <source>Add address</source>
      <translation variants="yes">
        <lengthvariant priority="1">پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_note">
      <source>Note</source>
      <translation variants="yes">
        <lengthvariant priority="1">نوٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_phone_number">
      <source>Edit phone number</source>
      <translation variants="yes">
        <lengthvariant priority="1">فون نمبر میں ترمیم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_work">
      <source>Phone (work)</source>
      <translation variants="no">ٹیلی فون (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_find2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_default_saving_memory_val_phone">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile">
      <source>Mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">موبائل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">ur ##Contacts</translation>
    </message>
    <message numerus="no" id="txt_phob_missing_phonebook">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_assistant">
      <source>Assistant</source>
      <translation variants="no">معاون کا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_take_a_new_photo">
      <source>Take a new photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">نئی شبیہ کھینچیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">موبائل (دفتر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">تبدیلیاں مسترد</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_my_card">
      <source>Save My card</source>
      <translation variants="no">میرا کارڈ حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_my_card">
      <source>Not specified</source>
      <translation variants="no">میرا کارڈ بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites">
      <source>Favorites</source>
      <translation variants="no">پسندیدہ رابطے</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile">
      <source>Call mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">موبائل پر کال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_internet_call_work">
      <source>Call internet call (work)</source>
      <translation variants="no">انٹرنیٹ کال کریں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_merge3">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_conflicts_resolving">
      <source>Conflicts resolving</source>
      <translation variants="no">متضاد تفصیلات حل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_phone_local_contacts">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">پسندیدہ سے ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_import_contacts">
      <source>Import contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">رابطے درآمد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_note2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">مٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_account">
      <source>Not specified</source>
      <translation variants="no">اکاؤنٹ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_date">
      <source>Edit date</source>
      <translation variants="yes">
        <lengthvariant priority="1">تاریخ میں ترمیم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_personal_ringing_tone_val_default">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">میرا کارڈ تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_do_you_want_to_delete_selected_con">
      <source>Do you want to delete selected contacts?</source>
      <translation variants="no">منتخب رابطوں کو مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_home">
      <source>Email (home)</source>
      <translation variants="no">میل بھیجیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">(%[22]1) سے بات چیت  کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importin_contacts_from_1">
      <source>Importing contacts from %1</source>
      <translation variants="no">ur #Importing contacts from %1</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_ptt">
      <source>SIP</source>
      <translation variants="no">PTT شروع کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_1_group_members">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_info_you_can_choose_any_of_the_following">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_internet_call">
      <source>Call internet call</source>
      <translation variants="no">انٹرنیٹ کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_company">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_reorder_favorites">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_home2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_group_name">
      <source>Group name</source>
      <translation variants="no">گروپ کا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ringing_tone">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_clear_history">
      <source>Not specified</source>
      <translation variants="no">تفصیل صاف کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_title_your_phonebook_is_empty_you_can_ch">
      <source>Your Phonebook is empty</source>
      <translation variants="no">کوئی رابطہ نہیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">گھنٹی کی ٹون</translation>
    </message>
    <message numerus="yes" id="txt_phob_dblist_val_ln_numbers">
      <source>%Ln numbers</source>
      <translation>
        <numerusform plurality="a">ur #%Ln number</numerusform>
        <numerusform plurality="b">ur #%Ln numbers</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_default_saving_memory">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show">
      <source>Show</source>
      <translation variants="no">دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_name">
      <source>Enter name</source>
      <translation variants="no">ur #Name</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_disconnect_all">
      <source>Not specified</source>
      <translation variants="no">تمام اتصالات منقطع</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_syncronization_val_private">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create">
      <source>Create</source>
      <translation variants="yes">
        <lengthvariant priority="1">تشکیل دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">پسندیدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_synchronization_details">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_field">
      <source>Add field</source>
      <translation variants="yes">
        <lengthvariant priority="1">تفصیل شامل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_internet_call_work">
      <source>Call internet call (work)</source>
      <translation variants="no"> انٹرنیٹ کال (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_contact_card">
      <source>Not specified</source>
      <translation variants="no">ur #Save contact</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_job_title">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_work">
      <source>URL (work)</source>
      <translation variants="no">ویب پتے جائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_phone_number">
      <source>Add phone number</source>
      <translation variants="yes">
        <lengthvariant priority="1">فون نمبر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_syncronization_val_public">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_email">
      <source>Set as default email</source>
      <translation variants="no">بطور آغازی میل مرتب</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_children">
      <source>Children</source>
      <translation variants="no">بچے</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1">
      <source>Import from %1</source>
      <translation variants="no">ur #Import from %1</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_picture">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_name">
      <source>Edit contact name</source>
      <translation variants="yes">
        <lengthvariant priority="1">رابطے کے نام میں ترمیم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_assistant">
      <source>Call assistant</source>
      <translation variants="no">معاون کو کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_public">
      <source>Public</source>
      <translation variants="no">ur #Public</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">پہلا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_home">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_work">
      <source>Video call (work)</source>
      <translation variants="no">ویڈیو کال کریں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_anniversary">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_work">
      <source>Fax (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">فیکس بھیجیں (دفتر)</lengthvariant>
        <lengthvariant priority="2">فیکس بھیج (دفتر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_1_deleted">
      <source>Not specified</source>
      <translation variants="no">ur #%[30]1 deleted</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_pager">
      <source>Call Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیجر پر کال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete3">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_internet_call_home">
      <source>Call internet call (home)</source>
      <translation variants="no"> انٹرنیٹ کال (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_video_call">
      <source>Not specified</source>
      <translation variants="no">ویڈیو کال</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sufix">
      <source>Suffix</source>
      <translation variants="no">لاحقہ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_group">
      <source>Delete group</source>
      <translation variants="no">گروپ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_nick_name">
      <source>Nick name</source>
      <translation variants="no">عرفیت</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">موبائل پر کال کریں (گھر)</lengthvariant>
        <lengthvariant priority="2">موبائل پر کال (گھر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_address">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone_val_default">
      <source>Default</source>
      <translation variants="no">آغازی ٹون</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_manage_contacts">
      <source>Manage contacts</source>
      <translation variants="no">رابطوں کو منظم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_home">
      <source>Video call (home)</source>
      <translation variants="no">ویڈیو کال کریں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_ln_contacts_imported">
      <source>%Ln contacts imported</source>
      <translation variants="no">%L1/%L2 رابطے درآمد</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_new">
      <source>Create new</source>
      <translation variants="no">نیا تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_in_progress_l">
      <source>In progress (%L1/%L2)</source>
      <translation variants="no">رابطوں کو درآمد کر رہا ہے  (%L1/%L2)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_missing_all_contacts">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">سالگرہ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_street2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_favorites">
      <source>Favorites</source>
      <translation variants="no">پسندیدہ رابطے</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_and_phonenumber">
      <source>Name and phonenumber</source>
      <translation variants="no">نام اور فون نمبر</translation>
    </message>
    <message numerus="no" id="txt_phob_list_family">
      <source>Family</source>
      <translation variants="yes">
        <lengthvariant priority="1">خاندان کی تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_change_picture">
      <source>Change picture</source>
      <translation variants="no">شبیہ بدلیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_reorder_groups">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_im">
      <source>Not specified</source>
      <translation variants="no">بات چیت کی تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_first_nam">
      <source>First name Last name</source>
      <translation variants="no">پہلا نام آخر کا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_button_select_location">
      <source>Select location</source>
      <translation variants="no">ur #Find on map</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_birthday">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email">
      <source>Email</source>
      <translation variants="no">میل بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization_val_none">
      <source>none</source>
      <translation variants="no">کوئی نہیں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_dublicated_contacts">
      <source>Dublicated contacts</source>
      <translation variants="no">مشابہ رابطے</translation>
    </message>
    <message numerus="no" id="txt_phob_button_activity_stream">
      <source>Activity stream</source>
      <translation variants="no">سماجی فیڈز</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_image">
      <source>Image</source>
      <translation variants="no">شبیہ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_country">
      <source>Country</source>
      <translation variants="no">ملک/علاقہ</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_work">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_refresh">
      <source>Refresh</source>
      <translation variants="no">دوبارہ تازہ کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_home">
      <source>Delete Mobile (home)</source>
      <translation variants="no">موبائل مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_work">
      <source>URL (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویب پتہ (دفتر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email">
      <source>Delete Email</source>
      <translation variants="no">میل پتہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_service">
      <source>Add service</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax">
      <source>Fax</source>
      <translation variants="no">فیکس بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage">
      <source>Manage contacts</source>
      <translation variants="no">رابطوں کو  منظم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_presentation_settings">
      <source>Presentation settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات رابطہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization_val_public">
      <source>public</source>
      <translation variants="no">عوامی</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_number">
      <source>Conference number</source>
      <translation variants="no">کانفرنس کا نمبر</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_work">
      <source>Send mail (Work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل بھیجیں (دفتر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name_separator">
      <source>Last name, First name</source>
      <translation variants="no">آحر کا نام، پہلا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_list_missed_call">
      <source>Missed call</source>
      <translation variants="no">ur #Missed call</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_pager">
      <source>Call Pager</source>
      <translation variants="no">پیجر پر کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">کار فون پر کال کریں</lengthvariant>
        <lengthvariant priority="2">کار فون پر کال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_field2">
      <source>Not specified</source>
      <translation variants="no">فیلڈ شامل کریں</translation>
    </message>
    <message numerus="yes" id="txt_phob_list_ln_numbers">
      <source>%Ln number</source>
      <translation>
        <numerusform plurality="a">%Ln نمبر</numerusform>
        <numerusform plurality="b">%Ln عدد</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_clear_communications_history_with_1">
      <source>Delete communications history with %1?</source>
      <translation variants="no">%[63]1 سے مواصلات کی تفصیل مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_sim">
      <source>Importing contacts from SIM</source>
      <translation variants="no">SIM سے رابطوں کی درآمد ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_phob_list_fetch_from_1">
      <source>Fetch from %1</source>
      <translation variants="no">%1 سے بازیافت</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_assistant">
      <source>Assistant</source>
      <translation variants="no">معاون نمبر</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_dublicates_found_see_contacts_tha">
      <source>Dublicates found. See contacts that have several dublicates in Contacts list?</source>
      <translation variants="no">مشابہ رابطے مل گئے۔ ان رابطوں کو دیکھیں جن کے مشابہ رابطے رابطہ فہرست میں موجود ہیں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_home">
      <source>Fax (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">فیکس بھیجیں (گھر)</lengthvariant>
        <lengthvariant priority="2">فیکس بھیج (گھر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_email_address">
      <source>Add email address</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email">
      <source>Send email</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل بھیجیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_mark_all">
      <source>Mark all</source>
      <translation variants="no">سب نشان زد کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile">
      <source>Call Mobile</source>
      <translation variants="no">موبائل پر کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_work">
      <source>Delete Address (work)</source>
      <translation variants="no">پتہ مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_choose_from_my_contacts">
      <source>Choose from my contacts</source>
      <translation variants="no">رابطوں سے منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="no">موبائل پر کال (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_group_1_created">
      <source>New group %1 created</source>
      <translation variants="no">نیا گروپ %[11]1 تشکیل دیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phob_list_yesterday_1">
      <source>yesterday %L1</source>
      <translation variants="no">ur #Yesterday %L1</translation>
    </message>
    <message numerus="no" id="txt_missing_button_add_to_contacts">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile">
      <source>Mobile</source>
      <translation variants="no">موبائل</translation>
    </message>
    <message numerus="no" id="txt_phob_button_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">رابطے درآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_work">
      <source>Fax (work)</source>
      <translation variants="no">فیکس (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_to_contacts">
      <source>Add to contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">روابط میں شامل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_url_address">
      <source>Add url address</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویب پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹیلی فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_contact_saving">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_country2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_personal_ringing_tone">
      <source>Personal ringing tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">گھنٹی کی ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name">
      <source>Last name First name</source>
      <translation variants="no">آخر کا نام پہلا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_field">
      <source>Not specified</source>
      <translation variants="no">تفصیل شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_title_show_in_contacts_list">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone">
      <source>Phone</source>
      <translation variants="no">ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_number">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_1">
      <source>Add %1</source>
      <translation variants="no">%[10]1 شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_create_own_card_to_share_it_with_fri">
      <source>Create own card to share it with friends</source>
      <translation variants="no">اپنی تفصیلات کے ساتھ میرا کارڈ تشکیل دیں اور اس میں دوستوں کے ساتھ شراکت کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_to_homescreen">
      <source>Send to homescreen</source>
      <translation variants="no">ہوم اسکرین میں شامل</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message">
      <source>Send message</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیغام بھیجیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_chooce_from_gallery">
      <source>Chooce from gallery</source>
      <translation variants="yes">
        <lengthvariant priority="1">تصویروں سے انتخاب کریں</lengthvariant>
        <lengthvariant priority="2">تصویروں سے انتخاب</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_department">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_you_are_merging">
      <source>You are merging:</source>
      <translation variants="no">رابطوں کو ملانا جاری:</translation>
    </message>
    <message numerus="no" id="txt_phob_list_online">
      <source>Not specified</source>
      <translation variants="no">آن لائن</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_group_details">
      <source>Edit group details</source>
      <translation variants="yes">
        <lengthvariant priority="1">گروپ تفصیلات میں ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویب پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_work">
      <source>Email (work)</source>
      <translation variants="no">میل بھیجیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address">
      <source>Address</source>
      <translation variants="no">پتہ</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_car">
      <source>Car</source>
      <translation variants="yes">
        <lengthvariant priority="1">کار  کا فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_online">
      <source>Not specified</source>
      <translation variants="no">آن لائن</translation>
    </message>
    <message numerus="no" id="txt_phob_list_favorites2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_home">
      <source>Address (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">پتہ (گھر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_internet_call">
      <source>Call internet call</source>
      <translation variants="no">انٹرنیٹ کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">موبائل پر کال کریں (دفتر)</lengthvariant>
        <lengthvariant priority="2">موبائل کال (دفتر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_message">
      <source>Send message</source>
      <translation variants="no">پیغام بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_clear">
      <source>Not specified</source>
      <translation variants="no">صاف کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit_my_card">
      <source>Not specified</source>
      <translation variants="no">میرے کارڈ میں ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_province2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_home">
      <source>URL (home)</source>
      <translation variants="no">ویب پتے جائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_to_group">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone">
      <source>Call phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹیلی فون پر کال کریں</lengthvariant>
        <lengthvariant priority="2">ٹیلی فون پر کال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">روابط</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_details">
      <source>Edit contact details</source>
      <translation variants="yes">
        <lengthvariant priority="1">رابطہ تفصیلات میں ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">رابطہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_importing_contacts_val_in_progress">
      <source>In progress (%L1/%L2)</source>
      <translation variants="no">رابطوں کو درآمد کر رہا ہے  (%L1/%L2)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_1">
      <source>Find: %1</source>
      <translation variants="no">تلاش کریں: %[18]1</translation>
    </message>
    <message numerus="no" id="txt_phob_button_merge">
      <source>Merge</source>
      <translation variants="no">ملائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_conference_call">
      <source>Conference call</source>
      <translation variants="yes">
        <lengthvariant priority="1">کانفرنس کال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">(%[06]1) بات چیت کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_none">
      <source>None</source>
      <translation variants="no">ur #None</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_video_number">
      <source>Call video number</source>
      <translation variants="no">ویڈیو کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_l1_contacts_deleted">
      <source>Not specified</source>
      <translation variants="no">ur #%Ln contact deleted</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_assistant">
      <source>Call assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">معاون کو کال کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_your_own_card">
      <source>Create your own card</source>
      <translation variants="no">میرا کارڈ تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">عہدہ</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_all_contacts">
      <source>Not specified</source>
      <translation variants="yes">
        <lengthvariant priority="1">تلاش کریں: تمام رابطے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_note">
      <source>Note</source>
      <translation variants="no">نوٹ</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_search_for_dublicates">
      <source>Search for dublicates</source>
      <translation variants="no">مشابہ کی تلاش کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_history">
      <source>History</source>
      <translation variants="no">تفصیل</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_favorites_selected_select_your_p">
      <source>No favorites selected, select your preferrred contacts</source>
      <translation variants="no">کوئی پسندیدہ رابطہ نشان زد نہیں کیا گیا۔ پسندیدہ رابطوں میں اپنے ترجیحی رابطے شامل کریں۔</translation>
    </message>
    <message numerus="no" id="txt_phob_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="no">ur #Update existing contact</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_as_a_business_card">
      <source>Send as a business card</source>
      <translation variants="no">بطور بز. کارڈ بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete_group">
      <source>Delete group</source>
      <translation variants="no">گروپ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_email_address">
      <source>Edit email address</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل پتے میں ترمیم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_merge2">
      <source>Merge</source>
      <translation variants="no">ملائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_group_actions">
      <source>Group actions</source>
      <translation variants="no">گروپ اختیارات</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contacts_1_updated">
      <source>Contact %1 updated</source>
      <translation variants="no">رابطہ %[11]1 کی تجدید کی گئی</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_home">
      <source>Delete Address (home)</source>
      <translation variants="no">پتہ مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sim_card_error">
      <source>SIM card error </source>
      <translation variants="no">ur #SIM card error </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_formlabel_val_no_date_set">
      <source>No date set</source>
      <translation variants="no">(کوئی تاریخ مرتب نہیں)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_sign_in">
      <source>Sign in</source>
      <translation variants="no">سائن ان کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sync_with_ovi_contacts">
      <source>Sync with OVI contacts</source>
      <translation variants="no">روابط کی ہمزمانگی  جاری</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_home">
      <source>Delete URL (home)</source>
      <translation variants="no">ویب پتہ مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_anniversary">
      <source>Delete Anniversary</source>
      <translation variants="no">سالگرہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_phonebook">
      <source>Phonebook</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_web_address">
      <source>Edit web address</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویب پتے میں ترمیم کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_home">
      <source>Call Phone (home)</source>
      <translation variants="no">فون پر کال (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_mycard_image_to_business_card">
      <source>Add MyCard image to Business card?</source>
      <translation variants="no">میرے کارڈ کی شبیہ بھی شامل کریں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax">
      <source>Fax</source>
      <translation variants="no">فیکس</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_restore_default_settings">
      <source>Not specified</source>
      <translation variants="no">آغازی ترتیبات بحال</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_work">
      <source>Delete Internet telephone (work)</source>
      <translation variants="no">نیٹ ف. مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address">
      <source>Delete Address</source>
      <translation variants="no">پتہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_cancel_merge">
      <source>Cancel merge</source>
      <translation variants="no">ملانا منسوخ کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_send_my_card">
      <source>Send My card</source>
      <translation variants="no">میرا کارڈ بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_favorites">
      <source>Manage favorites</source>
      <translation variants="no">پسندیدہ رابطے منظم</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_work">
      <source>Email (work)</source>
      <translation variants="no">میل پتہ (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_postal_codezip_code">
      <source>Postal code/ZIP code</source>
      <translation variants="no">پوسٹل/زپ کوڈ</translation>
    </message>
    <message numerus="no" id="txt_missing_list_save_as_a_new_contact">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_contacts">
      <source>Delete contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Delete contacts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_to_homescreen_as_widget">
      <source>Send to homescreen</source>
      <translation variants="no">ہوم اسکرین میں شامل</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit_group_details">
      <source>Edit group details</source>
      <translation variants="no">گروپ تفصیل ترمیم</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_province">
      <source>Province</source>
      <translation variants="no">صوبہ</translation>
    </message>
    <message numerus="no" id="txt_phob_list_number">
      <source>Number</source>
      <translation variants="yes">
        <lengthvariant priority="1">فون نمبر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contact_1_saved">
      <source>Contact %1 saved</source>
      <translation variants="no">رابطہ %[14]1 تشکیل دیا گیا</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company">
      <source>Company</source>
      <translation variants="no">کمپنی</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_filter">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">رابطے درآمد کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_assistant">
      <source>Assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">معاون کا نمبر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_all_contacts">
      <source>All contacts</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="no">کار فون پر کال کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_creating_1_group">
      <source>Creating %1 group</source>
      <translation variants="no">%1 گروپ تشکیل کیا جا رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_email">
      <source>Add email</source>
      <translation variants="no">میل پتہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_sync_with_ovi">
      <source>Sync with OVI</source>
      <translation variants="no">Ovi روابط سے ہمزمانہ</translation>
    </message>
    <message numerus="no" id="txt_phob_list_sychronization">
      <source>Sychronization</source>
      <translation variants="no">ہمزمانگی</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_change_image">
      <source>Change image</source>
      <translation variants="yes">
        <lengthvariant priority="1">شبیہ تبدیل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_link_to_phonebook">
      <source>Link to phonebook</source>
      <translation variants="no">روابط سے مربوط کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_delete_contacts">
      <source>Delete contacts</source>
      <translation variants="no">ur #Delete contacts?</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_my_card">
      <source>Clear My card</source>
      <translation variants="no">میرا کارڈ صاف کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_info_with_ovi_by_nokia_you_can_access_you">
      <source>With Ovi by Nokia you can access your favourite social networks and make your Contacts social. Sign in with your Nokia account to get started.</source>
      <translation variants="no">Ovi کے ساتھ Nokia سے آپ اپنے پسندیدہ سماجی نیٹ ورکس تک رسائی کر سکتے اور اپنے روابط کو مقبول بنا سکتے ہین۔ آغاز کرنے کے لیے اپنے Nokia اکاؤنٹ میں سائن ان کریں۔</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_address">
      <source>Add Address</source>
      <translation variants="no">پتہ شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_search_for_matched_contacts">
      <source>Search for matched contacts</source>
      <translation variants="no">مطابقتوں تلاش کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_device">
      <source>Import from Device</source>
      <translation variants="yes">
        <lengthvariant priority="1">فون سے درآمد کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_family_details">
      <source>Add Family details</source>
      <translation variants="no">خاندان تفصیلات شامل</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_accounts">
      <source>Accounts</source>
      <translation variants="no">اکاؤنٹس</translation>
    </message>
    <message numerus="no" id="txt_phob_button_find">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_internet_number">
      <source>Edit internet number</source>
      <translation variants="yes">
        <lengthvariant priority="1">انٹرنیٹ فون تفص. میں ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_street">
      <source>Street</source>
      <translation variants="no">اسٹریٹ</translation>
    </message>
    <message numerus="no" id="txt_phob_title_members_of_1_group">
      <source>%1 members</source>
      <translation variants="no">%[17]1 ممبران</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_pager">
      <source>Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیجر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_new_group_name">
      <source>New group name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">گروپ نام:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_edit_members">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_history">
      <source>Delete history</source>
      <translation variants="no">تفصیل صاف کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_stop_import">
      <source>Stop import</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">درمیانی نام</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_work">
      <source>Phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹیلی فون (دفتر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="no">موبائل (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">پسندیدہ سے ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">منصب</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_only">
      <source>Name only</source>
      <translation variants="no">صرف نام</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_image">
      <source>Remove image</source>
      <translation variants="no">شبیہ ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard_val_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">ur #Create my card</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_home">
      <source>Delete Fax (home)</source>
      <translation variants="no">فیکس مٹائیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_home">
      <source>URL (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویب پتہ (گھر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_car">
      <source>Car</source>
      <translation variants="no">کار فون</translation>
    </message>
    <message numerus="no" id="txt_phob_info_delete_1">
      <source>Delete %1?</source>
      <translation variants="no">%[91]1 مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company_details">
      <source>Company Details</source>
      <translation variants="no">کمپنی کی تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_contact">
      <source>New contact</source>
      <translation variants="no">نیا رابطہ</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_group">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax">
      <source>Fax</source>
      <translation variants="yes">
        <lengthvariant priority="1">فیکس بھیجیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_number">
      <source>Add number</source>
      <translation variants="no">نمبر شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_group_mail">
      <source>Not specified</source>
      <translation variants="no">گروپ میل بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_post_code">
      <source>Post code</source>
      <translation variants="no">پوسٹل کوڈ</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_favorites">
      <source>Add favorites</source>
      <translation variants="no">پسندیدہ رابطے شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_home">
      <source>Send mail (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل بھیجیں (گھر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mail for Exchange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_number">
      <source>Set as default number</source>
      <translation variants="no">بطور آغازی نمبر مرتب</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_home">
      <source>Fax (home)</source>
      <translation variants="no">فیکس بھیجیں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_contact">
      <source>Save contact</source>
      <translation variants="no">رابطہ حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_pobox">
      <source>P.O.Box</source>
      <translation variants="no">پوسٹ آفس باکس</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_pin">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_title_anniversary">
      <source>Anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">سالگرہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites_val_no_favorites_selecte">
      <source>No favorites selected</source>
      <translation variants="no">پسندیدہ رابطے نہیں</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_birthday">
      <source>Birthday</source>
      <translation variants="no">یوم پیدائش</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_group_message">
      <source>Not specified</source>
      <translation variants="no">گروپ پیغام بھیجیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_home">
      <source>Phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹیلی فون (گھر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url">
      <source>URL</source>
      <translation variants="no">ویب پتے پر جائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_video_call_work">
      <source>Not specified</source>
      <translation variants="no">ویڈیو کال (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_work">
      <source>Call Phone (work)</source>
      <translation variants="no">فون پر کال (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_edit">
      <source>Edit</source>
      <translation variants="no">ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_find_from">
      <source>Find from:</source>
      <translation variants="yes">
        <lengthvariant priority="1">تلاش کریں از:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_unable_to_access_contacts_in_memory">
      <source>Unable to access contacts in memory: %1</source>
      <translation variants="no">ur #Unable to access contacts saved to %1</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_social_view">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">آخر کا نام</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_updated_1">
      <source>Updated %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">تجدید کی گئی: %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_work">
      <source>Address (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">پتہ (دفتر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order">
      <source>Name display order</source>
      <translation variants="no">نام ظاہر کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_dialled_call">
      <source>Dialled call</source>
      <translation variants="no">ur #Dialled call</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_family_details">
      <source>Edit family details</source>
      <translation variants="yes">
        <lengthvariant priority="1">خاندان کی تفصیلات میں ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_group">
      <source>Remove from group</source>
      <translation variants="no">گروپ سے ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_video_number_home">
      <source>Call video number (home)</source>
      <translation variants="no">ویڈیو کال کریں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_groups">
      <source>Delete groups</source>
      <translation variants="no">گروپس مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_list_company_details">
      <source>Company Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">کمپنی تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_video_number_work">
      <source>Call video number (work)</source>
      <translation variants="no">ویڈیو کال کریں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_unknown">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_home">
      <source>Phone (home)</source>
      <translation variants="no">ٹیلی فون (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_select_contact">
      <source>Select contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">رابطہ منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_work">
      <source>URL (work)</source>
      <translation variants="no">ویب پتہ (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_link_in_1">
      <source>Link in %1</source>
      <translation variants="no">%1 سے مربوط کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_unlink">
      <source>Unlink</source>
      <translation variants="yes">
        <lengthvariant priority="1">ربط ہٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_unnamed">
      <source>Unnamed</source>
      <translation variants="no">ur #(unnamed)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_field">
      <source>Add field</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_email2">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">بذریعے میل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete_selected">
      <source>Delete selected</source>
      <translation variants="yes">
        <lengthvariant priority="1">مٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_id">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization_val_private">
      <source>private</source>
      <translation variants="no">ذاتی</translation>
    </message>
    <message numerus="no" id="txt_phob_list_mycard">
      <source>MyCard</source>
      <translation variants="no">میرا کارڈ</translation>
    </message>
    <message numerus="no" id="txt_phob_missing_find_1">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_pager">
      <source>Pager</source>
      <translation variants="no">پیجر</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_set_as_favorite">
      <source>Set as favorite</source>
      <translation variants="no">سندیدہ راب. میں شامل</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_1_details">
      <source>Edit %1 details</source>
      <translation variants="no">تفصیلات رابطہ  میں ترمیم کریں: %[22]1</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_my_card">
      <source>My card</source>
      <translation variants="yes">
        <lengthvariant priority="1">میرا کارڈ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_video_call_home">
      <source>Not specified</source>
      <translation variants="no">ویڈیو کال (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_call_voice_mail_box">
      <source>Not specified</source>
      <translation variants="no">صوتی میلباکس کال</translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">روابط</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">موبائل (گھر)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_a_new_contact">
      <source>Create a new contact</source>
      <translation variants="no">نیا رابطہ تشکیل دیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address_work2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_missing_list_update_existing_contact">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_importing_contacts">
      <source>Importing contacts</source>
      <translation variants="no">رابطےدرآمد ہو ر ہے ہیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_1_group_created_l2_contac">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_city">
      <source>City</source>
      <translation variants="no">شہر</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_city2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_address_details">
      <source>Edit address details</source>
      <translation variants="yes">
        <lengthvariant priority="1">پتے کی تفصیلات میں ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="no">موبائل (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">تاریخ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_1">
      <source>Delete %1</source>
      <translation variants="no">%[14]1 مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_groups">
      <source>Groups</source>
      <translation variants="yes">
        <lengthvariant priority="1">گروپس</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_department">
      <source>Department</source>
      <translation variants="no">شعبہ</translation>
    </message>
    <message numerus="no" id="txt_phob_list_no_favorites_selected">
      <source>No favorites selected</source>
      <translation variants="no">پسندیدہ رابطے نہیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_address2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_internet_call_home">
      <source>Call internet call (home)</source>
      <translation variants="no">انٹرنیٹ کال کریں (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_children">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_list_private">
      <source>Private</source>
      <translation variants="no">ur #Private</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">انٹرنیٹ ٹیلی فون</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_spouse">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="yes" id="txt_phob_dpophead_ln_contacts_linked">
      <source>%Ln contacts linked</source>
      <translation>
        <numerusform plurality="a">%Ln رابطہ مربوط</numerusform>
        <numerusform plurality="b">%Ln رابطے مربوط</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="no">ur #Create new contact</translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_to_contacts">
      <source>Add to contacts</source>
      <translation variants="no">روابط میں شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_button_manage_members">
      <source>Manage members</source>
      <translation variants="no">گروپ منظم کریں</translation>
    </message>
    <message numerus="no" id="txt_phob_title_birthday">
      <source>Birthday</source>
      <translation variants="yes">
        <lengthvariant priority="1">یوم پیدائش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_phone_number_for_1">
      <source>No phone number for %1</source>
      <translation variants="no">ur #No phone number defined for %1</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_transfer_via_b">
      <source>Transfer via bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth سے بھیجیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_syncronization">
      <source>Syncronization</source>
      <translation variants="no">ہمزمانگی</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_ptt">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_post_code2">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">شوہر/بیوی</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_view">
      <source>Not specified</source>
      <translation variants="no">شبیہ دیکھیں</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone">
      <source>Call Phone</source>
      <translation variants="no">ٹیلی فون پر کال</translation>
    </message>
    <message numerus="no" id="txt_phob_list_address2">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_work">
      <source>Delete Email (work)</source>
      <translation variants="no">پتہ مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_work">
      <source>Delete URL (work)</source>
      <translation variants="no">و. پتہ مٹائیں (دفتر)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_service">
      <source>Select service</source>
      <translation variants="yes">
        <lengthvariant priority="1">خدمت کا اتنخاب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_remove_link">
      <source>Remove link? </source>
      <translation variants="yes">
        <lengthvariant priority="1">ربط ہٹائیں؟</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_val_not_logged_in">
      <source>Not logged in</source>
      <translation variants="yes">
        <lengthvariant priority="1">سائن ان نہیں کیا گیا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">رابطہ مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_syncronization_val_none">
      <source>Not specified</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard">
      <source>MyCard</source>
      <translation variants="no">ur #My card</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="no">موبائل پر کال (گھر)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_your_name">
      <source>Enter your name</source>
      <translation variants="no">ur #Your name</translation>
    </message>
  </context>
</TS>