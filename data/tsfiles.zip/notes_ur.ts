<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_notes_dblist_note_modified_at_time">
      <source>Modified at %1</source>
      <translation variants="no">%[10]1 پر ترمیم کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_notes_list_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">پسندیدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_list_alarm_date">
      <source>%1 %2</source>
      <translation variants="no">%[11]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_button_dialog_delete">
      <source>Delete</source>
      <translation variants="no">مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_completed_date_val_1">
      <source>0.01</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_note">
      <source>Delete note?</source>
      <translation variants="no">نوٹ مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">مکمل کیا گیا:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_on_date">
      <source>Created on %1</source>
      <translation variants="no">%1 کو تشکیل کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_notes_list_note_count">
      <source>[ %1 ]</source>
      <translation variants="no">[ %[24]1 ]</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_notes">
      <source>Notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">بے نام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_collections">
      <source>Collections</source>
      <translation variants="no">­مجموعے</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_moved_to_todos">
      <source>Note moved to To-do's</source>
      <translation variants="no">نوٹ اہم کام نوٹ کی  فہرست میں منتقل</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_modified_on_1_2">
      <source>Modified on %1 %2</source>
      <translation variants="no">%[05]1 %2 کو ترمیم کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_created_on_1_2">
      <source>Created on %1 %2</source>
      <translation variants="no">%[07]1 %2 کو تشکیل</translation>
    </message>
    <message numerus="yes" id="txt_notes_subhead_todos_ln_pending">
      <source>To-do's (%Ln Pending )</source>
      <translation>
        <numerusform plurality="a">اہم کام نوٹ (%Ln زیر التوا)</numerusform>
        <numerusform plurality="b">اہم کام نوٹس (%Ln زیر التوا)</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">بطور غیر مکمل نشان</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_on_date">
      <source>Modified on %1</source>
      <translation variants="no">%[10]1 کو ترمیم کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_add_to_calendar">
      <source>Add to Calendar</source>
      <translation variants="no">کیلنڈر میں شامل</translation>
    </message>
    <message numerus="no" id="txt_notes_list_due_date">
      <source>0.01</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_new_todo">
      <source>New To-do </source>
      <translation variants="no">نیا اہم کام</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">تفصیل:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_subject">
      <source>Subject:</source>
      <translation variants="yes">
        <lengthvariant priority="1">موضوع:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_all_notes">
      <source>All notes</source>
      <translation variants="no">تمام نوٹس</translation>
    </message>
    <message numerus="no" id="txt_notes_list_plain_notes">
      <source>Plain notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">سادہ نوٹس</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_notes">
      <source>Delete notes?</source>
      <translation variants="no">نوٹس مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">پسندیدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_notes">
      <source>Notes</source>
      <translation variants="no">نوٹس</translation>
    </message>
    <message numerus="no" id="txt_short_caption_notes">
      <source>Notes</source>
      <translation variants="no">ur #Notes</translation>
    </message>
    <message numerus="no" id="txt_notes_button_find">
      <source>Find</source>
      <translation variants="no">تلاش کریں</translation>
    </message>
    <message numerus="no" id="txt_notes_button_new_note">
      <source>New note</source>
      <translation variants="no">نیا نوٹ</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_plain_notes">
      <source>Plain notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">سادہ نوٹس</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_notes">
      <source>Delete To-do notes?</source>
      <translation variants="no">اہم کام نوٹس مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_notes_button_edit">
      <source>Edit</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترمیم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">ur #Due on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_list_todos">
      <source>To-do's</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #To-do notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_menu_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="no">ur #Change to to-do note</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">ur #Remove from favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">ur #Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_completed_on_1">
      <source>Completed on %1</source>
      <translation variants="no">ur #Completed on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">ur #Mark as done</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_collections">
      <source>Collections</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Folders</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="no">ur #Add to favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_title_notes">
      <source>Notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_at_time">
      <source>Created at %1</source>
      <translation variants="no">%1 پر تشکیل کیا گیا</translation>
    </message>
    <message numerus="yes" id="txt_notes_subhead_ln_notes">
      <source>%Ln Notes</source>
      <translation>
        <numerusform plurality="a">%Ln نوٹ</numerusform>
        <numerusform plurality="b">%Ln نوٹس</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">اہم کام نوٹ مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_notes_list_no_notes_available">
      <source>No notes available</source>
      <translation variants="no">ur ##No notes available</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">بطور مکمل نشان زد</translation>
    </message>
  </context>
</TS>