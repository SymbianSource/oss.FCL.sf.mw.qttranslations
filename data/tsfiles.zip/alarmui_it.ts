<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="it">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_button_alarm_dialog_snooze">
      <source>Source 0</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #Stop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_slide_down_to_stop">
      <source>Source 1</source>
      <translation variants="no">it #Slide down to stop</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Source 2</source>
      <translation variants="no">it #Switch phone on ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_time">
      <source>Source 3</source>
      <translation variants="no">it #%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_snooze">
      <source>Source 4</source>
      <translation variants="no">it #Snooze</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_silence">
      <source>Source 5</source>
      <translation variants="no">it #Silence</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snooxed_for_ln_minute">
      <source>Source 6</source>
      <translation>
        <numerusform plurality="a">it #MISSING</numerusform>
        <numerusform plurality="b">it #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Source 7</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #Silence</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Source 8</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #Snooze</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_date">
      <source>Source 9</source>
      <translation variants="no">it #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_time">
      <source>Source 10</source>
      <translation variants="no">it #%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_date">
      <source>Source 11</source>
      <translation variants="no">it #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>Source 12</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #To-do note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Source 13</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #Calendar alarm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Source 14</source>
      <translation variants="yes">
        <lengthvariant priority="1">it #Clock alarm</lengthvariant>
      </translation>
    </message>
  </context>
</TS>