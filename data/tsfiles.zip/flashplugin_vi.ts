<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_flashplugin_menu_unmute">
      <source>Unmute</source>
      <translation variants="no">vi #Unmute</translation>
    </message>
    <message numerus="no" id="text_flite_query_trust">
      <source>Allow application to access %1. Application will be restarted?</source>
      <translation variants="no">vi #Allow application to access %1. Application will be restarted?</translation>
    </message>
    <message numerus="no" id="text_flite_plugin_normalscreen">
      <source>Normal screen</source>
      <translation variants="no">vi #Normal screen</translation>
    </message>
    <message numerus="no" id="text_flite_plugin_note_iad_update_complete">
      <source>Restart browser for the update to take effect</source>
      <translation variants="no">vi #Restart browser for the update to take effect</translation>
    </message>
    <message numerus="no" id="text_flite_plugin_tip_normalscreen">
      <source>Click on video to go back to Normal screen</source>
      <translation variants="no">vi #Click on video to go back to Normal screen</translation>
    </message>
    <message numerus="no" id="txt_flashplugin_menu_mute">
      <source>Mute</source>
      <translation variants="no">vi #Mute</translation>
    </message>
    <message numerus="no" id="text_flite_error_not_authorized">
      <source>Flash Player not supported by the device</source>
      <translation variants="no">vi #Flash Player not supported by the device</translation>
    </message>
    <message numerus="no" id="text_flite_plugin_tip_fullscreen">
      <source>Click on video to watch full screen</source>
      <translation variants="no">vi #Click on video to watch full screen</translation>
    </message>
    <message numerus="no" id="text_flite_plugin_fullscreen">
      <source>FullScreen</source>
      <translation variants="no">vi #FullScreen</translation>
    </message>
    <message numerus="no" id="text_flite_error_in_content">
      <source>Flash content Error</source>
      <translation variants="no">vi #Flash content Error</translation>
    </message>
    <message numerus="no" id="text_flite_option_about">
      <source>About</source>
      <translation variants="no">vi #About</translation>
    </message>
    <message numerus="no" id="text_flite_error_in_version">
      <source>Flash Version %L1 not supported.</source>
      <translation variants="no">vi #Flash Version %L1 not supported.</translation>
    </message>
    <message numerus="no" id="text_flite_option_about_text">
      <source>Contains Adobe Flash® Lite ™ 4.0\n ©1995-2010 Adobe Macromedia Software LLC.\nAll rights reserved.</source>
      <translation variants="no">vi #Contains Adobe Flash® Lite ™ 4.0\n ©1995-2010 Adobe Macromedia Software LLC.\nAll rights reserved.</translation>
    </message>
    <message numerus="no" id="text_flite_query_network_access">
      <source>The current Flash content needs a network connection. Accept?</source>
      <translation variants="no">vi #The current Flash content needs a network connection. Accept?</translation>
    </message>
  </context>
</TS>