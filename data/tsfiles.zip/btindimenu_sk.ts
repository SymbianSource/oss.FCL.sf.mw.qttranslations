<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="sk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_dblist_receiving_files">
      <source>Receiving files</source>
      <translation variants="no">Prijímajú sa súbory</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_paired">
      <source>%1 paired</source>
      <translation variants="no">„%[09]1“ spárované</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="no">Zapnutý (viditeľný)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="no">Zapnutý (skrytý)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_computer">
      <source>Computer</source>
      <translation variants="no">Počítač</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_phone">
      <source>Phone</source>
      <translation variants="no">Telefón</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="no">Pripojený (skrytý)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="no">Vypnutý</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_connected">
      <source>%1 connected</source>
      <translation variants="no">„%[10]1“ pripojené</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_other_device">
      <source>Other device</source>
      <translation variants="no">Iné zariadenie</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_usign_sim_access_profi">
      <source>usign SIM access profile</source>
      <translation variants="no">Režim vzdialenej SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="no">Pripojený (viditeľný)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_sending_files">
      <source>Sending files</source>
      <translation variants="no">Posielajú sa súbory</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_audio_device">
      <source>Audio device</source>
      <translation variants="no">Zvukové zariadenie</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_input_device">
      <source>Input device</source>
      <translation variants="no">Vstupné zariadenie</translation>
    </message>
  </context>
</TS>