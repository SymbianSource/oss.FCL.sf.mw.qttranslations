<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_viewer_opt_reply_all">
      <source>Reply all</source>
      <translation variants="no">全部回复</translation>
    </message>
    <message numerus="no" id="txt_mail_forward_subject_prefix">
      <source>Fw:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Fw:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_sending_failed">
      <source>Sending mail %[]1 failed. Try to send it again or press back to cancel</source>
      <translation variants="no">发送失败：
%[27]1。
尝试再次发送，或按"返回"取消。</translation>
    </message>
    <message numerus="no" id="txt_mail_status_menu_new_mail">
      <source>New Mail</source>
      <translation variants="no">zh #New Mail</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_yes">
      <source>Yes</source>
      <translation variants="no">是</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_reply">
      <source>Reply</source>
      <translation variants="no">回复</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_server_settings_incorrect">
      <source>Server settings are incorrect. Do you want to check the settings?</source>
      <translation variants="no">服务器设置不正确。检查设置？</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no">
      <source>No</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_mail_shareui_sending_please_wait">
      <source>Sending, please wait</source>
      <translation variants="no">正在发送</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_address_or_password_incorrect">
      <source>Mail address or password is incorrect. Do you want to check the settings?</source>
      <translation variants="no">电子邮件地址或密码不正确。检查设置？</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_delete">
      <source>Delete</source>
      <translation variants="no">删除</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_hide_cc_bcc">
      <source>Hide cc / bcc</source>
      <translation variants="no">隐藏抄/密送</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_1_deleted">
      <source>%[]1 deleted.</source>
      <translation variants="no">已删除：
%[56]1</translation>
    </message>
    <message numerus="no" id="txt_mail_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">其他</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_new_photo">
      <source>New photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">新图像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_deleting_mailbox">
      <source>Deleting mailbox</source>
      <translation variants="no">正在删除信箱</translation>
    </message>
    <message numerus="no" id="txt_common_menu_remove">
      <source>Remove</source>
      <translation variants="no">zh ##Remove</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_cc">
      <source>Cc:</source>
      <translation variants="no">抄送：</translation>
    </message>
    <message numerus="no" id="txt_mail_reply_subject_prefix">
      <source>Re:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Re:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_select_file">
      <source>Select file</source>
      <translation variants="no">zh #Select file</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_show_cc_bcc">
      <source>Show cc / bcc</source>
      <translation variants="no">显示抄/密送</translation>
    </message>
    <message numerus="no" id="txt_common_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_photo">
      <source>Photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">图像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_text_attachment">
      <source>attachment</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #attachment</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_subject">
      <source>Subject:</source>
      <translation variants="no">主题：</translation>
    </message>
    <message numerus="no" id="txt_mail_subhead_inbox">
      <source>Inbox </source>
      <translation variants="no">zh ##Inbox </translation>
    </message>
    <message numerus="no" id="txt_mail_list_searching">
      <source>Seaching</source>
      <translation variants="no">zh #Seaching</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no_mailboxes_defined">
      <source>No mailboxes defined</source>
      <translation variants="no">zh ##</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_mark_as_read">
      <source>Mark as read</source>
      <translation variants="no">标记为已读</translation>
    </message>
    <message numerus="no" id="txt_short_caption_mail">
      <source>Mail</source>
      <translation variants="no">zh ##Mail</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_open_attachment_file_ty">
      <source>Unable to open. Attachment file type not supported</source>
      <translation variants="no">无法打开。不支持此附件文件类型。</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_val_no_subject">
      <source>(No Subject)</source>
      <translation variants="no">zh ##(No Subject)</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_loading_mail_content">
      <source>Loading mail content</source>
      <translation variants="no">正在加载电子邮件内容</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance">
      <source>Importance:</source>
      <translation variants="no">重要性：</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_invalid_mail_address">
      <source>Invalid mail address: %[]1</source>
      <translation variants="no">电子邮件地址无效：
%1</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_still_sending">
      <source>Still sending mail %[]1. Please wait operation to complete</source>
      <translation variants="no">仍在发送电子邮件%[54]1。等待操作完成。</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no_mailboxes_create_new">
      <source>No mailboxes have been defined. Would you like to create a new mailbox?</source>
      <translation variants="no">尚未定义信箱。新建信箱？</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance_low">
      <source>Low</source>
      <translation variants="no">低</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_inbox">
      <source>Inbox </source>
      <translation variants="no">收件箱</translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">zh ##Open</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_send_and_receive_now">
      <source>Refresh</source>
      <translation variants="no">刷新</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_forward">
      <source>Forward</source>
      <translation variants="no">转发</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_low">
      <source>Low</source>
      <translation variants="no">低</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_add_attachment">
      <source>Unable to add attachment </source>
      <translation variants="no">无法添加附件</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_mark_as_unread">
      <source>Mark as unread</source>
      <translation variants="no">标记为未读</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_save_message_to_drafts">
      <source>Do you want to save this message to drafts?</source>
      <translation variants="no">zh #Do you want to save this message to drafts?</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_to">
      <source>To:</source>
      <translation variants="no">收信人：</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance_high">
      <source>High</source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_drafts">
      <source>Drafts</source>
      <translation variants="no">草稿</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_mail_connection_error">
      <source>Mail connection error.</source>
      <translation variants="no">电子邮件连接错误</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority">
      <source>Add priority</source>
      <translation variants="no">添加优先级</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_to">
      <source>To:</source>
      <translation variants="no">zh ##To:</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_cc">
      <source>Cc:</source>
      <translation variants="no">zh ##Cc:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_sending_mail">
      <source>Sending mail</source>
      <translation variants="no">正在发送电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_downloading_canceled">
      <source>Not enough memory - downloading canceled</source>
      <translation variants="no">已取消下载。存储不足。</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_remove_all">
      <source>Remove all</source>
      <translation variants="no">全部删除</translation>
    </message>
    <message numerus="no" id="txt_mail_list_cc">
      <source>Cc:</source>
      <translation variants="no">抄送：</translation>
    </message>
    <message numerus="yes" id="txt_mail_dialog_you_can_not_send_more_than_l1_att">
      <source>You can not send more than %Ln attachments at a time </source>
      <translation>
        <numerusform plurality="a">zh #Unable to send more than %L1 attachments at a time</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">zh ##Delete</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_attachments_should_be_smaller_than">
      <source>Attachments should be smaller than %L1 Mb</source>
      <translation variants="no">附件应小于%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_mail_list_to">
      <source>To:</source>
      <translation variants="no">收信人：</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_bcc">
      <source>Bcc:</source>
      <translation variants="no">zh ##Bcc:</translation>
    </message>
    <message numerus="no" id="txt_mail_title_mail">
      <source>Mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_you_can_not_send_more_than_l1_kb">
      <source>You can not send more than %L1 Mb as attachments </source>
      <translation variants="no">无法发送总大小超过%L1 MB的附件</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_subject">
      <source>Subject:</source>
      <translation variants="no">zh ##Subject:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_opening_mail_editor">
      <source>Opening mail editor</source>
      <translation variants="no">正在打开电子邮件编辑器</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_outbox">
      <source>Outbox</source>
      <translation variants="no">发件箱</translation>
    </message>
    <message numerus="no" id="txt_mail_list_search_results">
      <source>%L1 results</source>
      <translation variants="no">zh #%L1 results</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_normal">
      <source>Normal</source>
      <translation variants="no">普通</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_high">
      <source>High</source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mail">
      <source>Mail</source>
      <translation variants="no">电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mail_dpophead_1_deleted">
      <source>Mailbox deleted. </source>
      <translation variants="no">信箱已删除</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_complete_command">
      <source>Unable to complete the command</source>
      <translation variants="no">无法执行操作</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_sent">
      <source>Sent</source>
      <translation variants="no">已发邮件</translation>
    </message>
    <message numerus="no" id="txt_mail_button_attach">
      <source>Attach</source>
      <translation variants="yes">
        <lengthvariant priority="1">附加</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_send_via">
      <source>Send via</source>
      <translation variants="no">发送途径</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_no_messages">
      <source>(No messages)</source>
      <translation variants="no">zh #(no messages)</translation>
    </message>
    <message numerus="no" id="txt_mail_dpophead_loading_mail_content">
      <source>Loading mail content</source>
      <translation variants="no">正在加载电子邮件内容</translation>
    </message>
    <message numerus="no" id="txt_mail_list_video">
      <source>Video</source>
      <translation variants="yes">
        <lengthvariant priority="1">视频</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_invalid_mail_address_send">
      <source>Invalid mail address: %[]1. Send anyway?</source>
      <translation variants="no">电子邮件地址无效：
%[41]1。
仍然发送？</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_original_msg">
      <source>---- Original message ----</source>
      <translation variants="no">-----原信息-----</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_no_messages_matched_your_search">
      <source>No messages matched your search. Try another search term. </source>
      <translation variants="no">zh #No messages matched your search. Try another search term. </translation>
    </message>
    <message numerus="no" id="txt_common_opt_settings">
      <source>Settings</source>
      <translation variants="no">zh ##Settings</translation>
    </message>
    <message numerus="no" id="txt_mail_list_l1_mb">
      <source>(%L1 Mb)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_from">
      <source>From:</source>
      <translation variants="no">发信人：</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_delete_mail">
      <source>Delete mail?</source>
      <translation variants="no">删除电子邮件？</translation>
    </message>
    <message numerus="no" id="txt_mail_shareui_send_as_mail">
      <source>Send as new mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Send as new mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_new_video">
      <source>New video</source>
      <translation variants="yes">
        <lengthvariant priority="1">新视频</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_do_you_want_to_delete_the_mailbox">
      <source>Do you want to delete the mailbox and all mail messages?</source>
      <translation variants="no">删除信箱及其所有信息？</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_do_you_want_to_delete_mfe">
      <source>Do you want to delete all mail, calendar, contacts and tasks data related to this account?</source>
      <translation variants="no">删除与此帐户相关的所有电子邮件、日历、名片和任务数据？</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_sent">
      <source>Sent:</source>
      <translation variants="no">发送日期：</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_deleted">
      <source>Deleted items</source>
      <translation variants="no">已删邮件</translation>
    </message>
    <message numerus="no" id="txt_mail_select_contacts">
      <source>Select contacts</source>
      <translation variants="no">zh #Select contacts</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_no_subject">
      <source>(No Subject)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(无主题)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_cannot_download_attachment_1">
      <source>Cannot download attachment: %[]1 </source>
      <translation variants="no">无法下载附件：%1 </translation>
    </message>
    <message numerus="no" id="txt_mail_button_new_mail">
      <source>New</source>
      <translation variants="yes">
        <lengthvariant priority="1">新建</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_title_control_panel">
      <source>Mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_status_menu_waiting_to_send">
      <source>Waiting to send (%L1)</source>
      <translation variants="no">zh #Waiting to send (%L1)</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_from">
      <source>From:</source>
      <translation variants="no">发信人：</translation>
    </message>
  </context>
</TS>