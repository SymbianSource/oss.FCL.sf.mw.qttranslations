<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_editor_reply_to">
      <source>To:</source>
      <translation variants="no">zh #To:</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance_high">
      <source>High</source>
      <translation variants="no">zh #High</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_subject">
      <source>Subject:</source>
      <translation variants="no">zh #Subject:</translation>
    </message>
    <message numerus="no" id="txt_mail_subhead_inbox">
      <source>Inbox </source>
      <translation variants="no">zh #Inbox </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_invalid_mail_address_send">
      <source>Invalid mail address: %[]1. Send anyway?</source>
      <translation variants="no">zh #Invalid mail address: %[]1. Send anyway?</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_original_msg">
      <source>---- Original message ----</source>
      <translation variants="no">zh #---- Original message ----</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_cc">
      <source>Cc:</source>
      <translation variants="no">zh #Cc:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_delete_message">
      <source>Delete message?</source>
      <translation variants="no">zh #Delete message?</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_sent">
      <source>Sent:</source>
      <translation variants="no">zh #Sent:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_loading_mail_content">
      <source>Loading mail content</source>
      <translation variants="no">zh #Loading mail content</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance">
      <source>Importance:</source>
      <translation variants="no">zh #Importance:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_still_sending">
      <source>Still sending mail %[]1. Please wait operation to complete</source>
      <translation variants="no">zh #Still sending mail %[]1. Please wait operation to complete</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_sending failed">
      <source>Sending mail %[]1 failed. Try to send it again or press back to cancel</source>
      <translation variants="no">zh #Sending mail %[]1 failed. Try to send it again or press back to cancel</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance_low">
      <source>Low</source>
      <translation variants="no">zh #Low</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_mailbox_name_val_mon">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_6_months_backwards">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no_mailboxes_defined">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_mark_as_read">
      <source>Mark as read</source>
      <translation variants="no">标记为已读</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_manually">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_short_caption_mail">
      <source>Mail</source>
      <translation variants="no">zh #Mail</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_data_has_been_deleted_to_protect_a">
      <source>Data has been deleted to protect against theft or loss. Contact you system administrator</source>
      <translation variants="no">zh #Data has been deleted to protect against theft or loss. Contact you system administrator</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_account_disabled_due_to_security_i">
      <source>Account disabled due to security issues. Contact your system administrator.</source>
      <translation variants="no">zh #Account disabled due to security issues. Contact your system administrator.</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_open_attachment_file_ty">
      <source>Unable to open. Attachment file type not supported</source>
      <translation variants="no">zh #Unable to open. Attachment file type not supported</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_val_no_subject">
      <source>(No Subject)</source>
      <translation variants="no">zh #(No Subject)</translation>
    </message>
    <message numerus="no" id="txt_mail_subhead_credentials">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_signature">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_day_start_time">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_mail_connection_error">
      <source>Mail connection error.</source>
      <translation variants="no">zh #Mail connection error.</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_mail_address_or_password_is_incorr">
      <source>Mail address or password is incorrect, check the settings ( &lt;-link)</source>
      <translation variants="no">zh #Mail address or password is incorrect, check the settings ( &lt;-link)</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_outgoing_mail_server">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_show_mail_in_other_folders">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_refresh_mail_val_on">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority">
      <source>Add priority</source>
      <translation variants="no">添加优先级</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_when_i_use_mail">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_to">
      <source>To:</source>
      <translation variants="no">zh #To:</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_secure_connection">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_cc">
      <source>Cc:</source>
      <translation variants="no">zh #Cc:</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_battery_optimized">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_mailbox_name_val_sat">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_username">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_sending_mail">
      <source>Sending mail</source>
      <translation variants="no">正在发送电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_password_expired_new_security_cre">
      <source>Password expired. New security credentials must be created on your computer.</source>
      <translation variants="no">zh #Password expired. New security credentials must be created on your computer.</translation>
    </message>
    <message numerus="no" id="txt_mail_dpophead _1_deleted">
      <source>Mailbox deleted. </source>
      <translation variants="no">zh #Mailbox deleted. </translation>
    </message>
    <message numerus="no" id="txt_mail_menu_remove_all">
      <source>Remove all</source>
      <translation variants="no">全部删除</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_server_settings_incorrect_link">
      <source>Server settings are incorrect. (&lt;-link)</source>
      <translation variants="no">zh #Server settings are incorrect. (&lt;-link)</translation>
    </message>
    <message numerus="no" id="txt_mail_list_cc">
      <source>Cc:</source>
      <translation variants="no">zh #Cc:</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_destination">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_you_can_not_send_more_than_l1_att">
      <source>You can not send more than %L1 attachments at a time </source>
      <translation variants="no">zh #You can not send more than %L1 attachments at a time </translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">zh #Delete</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_attachments_should_be_smaller_than">
      <source>Attachments should be smaller than %L1 Mb</source>
      <translation variants="no">zh #Attachments should be smaller than %L1 Mb</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_attachment_download_cancelled">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_list_to">
      <source>To:</source>
      <translation variants="no">zh #To:</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_out_of_office">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_keep_uptodate">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_bcc">
      <source>Bcc:</source>
      <translation variants="no">zh #Bcc:</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_day_end_time">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_normal">
      <source>Normal</source>
      <translation variants="no">普通</translation>
    </message>
    <message numerus="no" id="txt_mail_title_mail">
      <source>Mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_every_4_hours">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_3_months_backwards">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_incoming_mail_server">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_inbox_path">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_common_opt_settings">
      <source>Settings</source>
      <translation variants="no">zh #Settings</translation>
    </message>
    <message numerus="no" id="txt_mail_list_l1_mb">
      <source>(%L1 Mb)</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_from">
      <source>From:</source>
      <translation variants="no">zh #From:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_cannot_open_the_attachment_deleted">
      <source>Cannot open the attachment deleted on the server</source>
      <translation variants="no">zh #Cannot open the attachment deleted on the server</translation>
    </message>
    <message numerus="no" id="txt_mail_subhead_server_settings">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_delete_mail">
      <source>Delete mail?</source>
      <translation variants="no">zh #Delete mail?</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_refresh_mail">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_uptodate">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_no_subject">
      <source>(No Subject)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(无主题)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_1_month_backwards">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_cannot_download_attachment_1">
      <source>Cannot download attachment: %[]1 </source>
      <translation variants="no">zh #Cannot download attachment: %[]1 </translation>
    </message>
    <message numerus="no" id="txt_mail_subhead_what_to_sync">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_mail_address">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_you_can_not_send_more_than_l1_kb">
      <source>You can not send more than %L1 Mb as attachments </source>
      <translation variants="no">zh #You can not send more than %L1 Mb as attachments </translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_day_end_time_val_off">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_subhead_synchronization">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_show_mail_in_inbox">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_subject">
      <source>Subject:</source>
      <translation variants="no">zh #Subject:</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_outgoing_mail_authentication">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_mailbox_name">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_receiving_weekdays">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_conversion_error_unable_to_show_t">
      <source>Conversion error. Unable to show the content properly</source>
      <translation variants="no">zh #Conversion error. Unable to show the content properly</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_high">
      <source>High</source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_my_name">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_inbox_path_sub_default">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_reply_to_address">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_mailbox_name_val_tue">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_day_end_time_val_on_slltls">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_server">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_user_defined">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_button_reply">
      <source>Reply</source>
      <translation variants="no">回复</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_domain">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_button_new_mail">
      <source>New</source>
      <translation variants="yes">
        <lengthvariant priority="1">新建</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_version_l1">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mail">
      <source>Mail</source>
      <translation variants="no">电子邮件</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_mailbox_name_val_thu">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_button_reply_all">
      <source>Reply all</source>
      <translation variants="no">全回</translation>
    </message>
    <message numerus="no" id="txt_mail_button_forward">
      <source>Forward</source>
      <translation variants="no">转发</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_refresh_mail_val_off">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_title_control_panel">
      <source>Mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_outgoing_mail_authentication_none">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_mailbox_name_val_wed">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_subhead_preferences">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_outgoing_mail_authentication_same">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_mailbox_name_val_fri">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_opening_mail_editor">
      <source>Opening mail editor</source>
      <translation variants="no">正在打开电子邮件编辑器</translation>
    </message>
    <message numerus="no" id="txt_common_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_menu_search_from_server">
      <source>search from server</source>
      <translation variants="no">zh #search from server</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_send_mail">
      <source>send mail</source>
      <translation variants="no">zh #send mail</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_search_from_service">
      <source>search from service</source>
      <translation variants="no">zh #search from service</translation>
    </message>
    <message numerus="no" id="txt_mail_list_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_opt_show_cc_bcc">
      <source>Show cc / bcc</source>
      <translation variants="no">显示抄/密送</translation>
    </message>
    <message numerus="no" id="txt_mail_list_photo">
      <source>Photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">图像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_invalid_mail_address">
      <source>Invalid mail address: %[]1</source>
      <translation variants="no">zh #Invalid mail address: %[]1</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no_mailboxes_create_new">
      <source>No mailboxes have been defined. Would you like to create a new mailbox?</source>
      <translation variants="no">zh #No mailboxes have been defined. Would you like to create a new mailbox?</translation>
    </message>
    <message numerus="no" id="txt_mail_list_fw">
      <source>Fw:</source>
      <translation variants="no">zh #Fw:</translation>
    </message>
    <message numerus="no" id="txt_mail_list_new_video">
      <source>New video</source>
      <translation variants="yes">
        <lengthvariant priority="1">新视频</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_do_you_want_to_delete_the_mailbox">
      <source>Do you want to delete the mailbox and all mail messages?</source>
      <translation variants="no">zh #Do you want to delete the mailbox and all mail messages?</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_do_you_want_to_delete_mfe">
      <source>Do you want to delete all mail, calendar, contacts and notes data related to this account?</source>
      <translation variants="no">zh #Do you want to delete all mail, calendar, contacts and notes data related to this account?</translation>
    </message>
    <message numerus="no" id="txt_mail_dpophead_loading_mail_content">
      <source>Loading mail content</source>
      <translation variants="no">正在加载电子邮件内容</translation>
    </message>
    <message numerus="no" id="txt_mail_list_video">
      <source>Video</source>
      <translation variants="yes">
        <lengthvariant priority="1">视频</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_opt_hide_cc_bcc">
      <source>Hide cc / bcc</source>
      <translation variants="no">隐藏抄/密送</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_1_deleted">
      <source>%[]1 deleted.</source>
      <translation variants="no">zh #%[]1 deleted.</translation>
    </message>
    <message numerus="no" id="txt_mail_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">其他</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_new_photo">
      <source>New photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">新图像</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_address_or_password_incorrect">
      <source>Mail address or password is incorrect. Do you want to check the settings?</source>
      <translation variants="no">zh #Mail address or password is incorrect. Do you want to check the settings?</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_server_settings_incorrect">
      <source>Server settings are incorrect. Do you want to check the settings?</source>
      <translation variants="no">zh #Server settings are incorrect. Do you want to check the settings?</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_from">
      <source>From:</source>
      <translation variants="no">zh #From:</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_delete">
      <source>Delete</source>
      <translation variants="no">zh #Delete</translation>
    </message>
    <message numerus="no" id="txt_mail_shareui_sending_please_wait">
      <source>Sending, please wait</source>
      <translation variants="no">zh #Sending, please wait</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_every_1_hour">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_refresh_during_other_times">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_every_15_minutes">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_1_is_disabled_enable">
      <source>%1 is disabled, enable?</source>
      <translation variants="no">zh #%1 is disabled, enable?</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_forward">
      <source>Forward</source>
      <translation variants="no">zh #Forward</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_no_messages">
      <source>(No messages)</source>
      <translation variants="no">zh #(No messages)</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_mailbox_name_val_every_day">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_list_re">
      <source>Re:</source>
      <translation variants="no">zh #Re:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_invalid_mail_address_1">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_send_via">
      <source>Send via</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送途径</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_outgoing_mail_authentication_user">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_1_week_backwards">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_complete_command">
      <source>Unable to complete the command</source>
      <translation variants="no">zh #Unable to complete the command</translation>
    </message>
    <message numerus="no" id="txt_mail_button_delete">
      <source>Delete</source>
      <translation variants="no">删除</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_open_contact_card">
      <source>open contact card</source>
      <translation variants="no">zh #open contact card</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_day_end_time_val_on_starttls">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_common_menu_move_to_folder">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_mailbox_name_val_sun">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_change_folder">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_setlabel_val_3_days_backwards">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">zh #Open</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_send_and_receive_now">
      <source>Refresh</source>
      <translation variants="no">刷新</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_low">
      <source>Low</source>
      <translation variants="no">低</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_add_attachment">
      <source>Unable to add attachment </source>
      <translation variants="no">zh #Unable to add attachment </translation>
    </message>
    <message numerus="no" id="txt_mail_menu_mark_as_unread">
      <source>Mark as unread</source>
      <translation variants="no">标记为未读</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_security">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_deleting_mailbox">
      <source>Deleting mailbox</source>
      <translation variants="no">正在删除信箱</translation>
    </message>
    <message numerus="no" id="txt_common_menu_remove">
      <source>Remove</source>
      <translation variants="no">zh #Remove</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_reply_all">
      <source>Reply all</source>
      <translation variants="no">zh #Reply all</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_sending_failed">
      <source>Sending mail %[]1 failed. Try to send it again or press back to cancel</source>
      <translation variants="no">zh #Sending mail %[]1 failed. Try to send it again or press back to cancel</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_reply">
      <source>Reply</source>
      <translation variants="no">zh #Reply</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_password">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_button_attach">
      <source>Attach</source>
      <translation variants="yes">
        <lengthvariant priority="1">附加</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_port">
      <source>Not specified</source>
      <translation variants="no">zh #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_dpophead_1_deleted">
      <source>Mailbox deleted. </source>
      <translation variants="no">zh #Mailbox deleted. </translation>
    </message>
  </context>
</TS>