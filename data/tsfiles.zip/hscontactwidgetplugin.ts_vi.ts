<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_friend_widget_info_you_can_not_use_this_widge">
      <source>You can not use this  widget, because your phonebook is empty. Open Phonebook to add contacts?</source>
      <translation variants="no">Không thể sử dụng Danh bạ Nhỏ bởi vì không có số liên lạc trong ứng dụng Danh bạ. Mở ứng dụng Danh bạ?</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget_val_quickly">
      <source>Quickly communicate with a contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">Liên lạc nhanh với một số liên lạc</lengthvariant>
        <lengthvariant priority="2">L.lạc nhanh với một số l.lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_friend">
      <source>Contact widget</source>
      <translation variants="no">vi #Mini Contacts</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget">
      <source>Contact widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">Danh bạ Nhỏ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_friend_widget_title_select_contact">
      <source>Select contact:</source>
      <translation variants="no">Chọn số liên lạc</translation>
    </message>
  </context>
</TS>