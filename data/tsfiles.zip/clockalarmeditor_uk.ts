<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_note_alarm_occurs_every_week_on_1_at_2">
      <source>Alarm occurs every week on %1 at %2</source>
      <translation variants="no">Сигнал відбувається що­тижня в %[06]1 о %2</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_occurence">
      <source>Occurence</source>
      <translation variants="yes">
        <lengthvariant priority="1">Повтор</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_friday">
      <source>Friday</source>
      <translation variants="no">П’ятниця</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_sunday">
      <source>Sunday</source>
      <translation variants="no">Неділя</translation>
    </message>
    <message numerus="no" id="txt_clock_note_alarm_occurs_once_only_on_next_1_a">
      <source>Alarm occurs once only on next %1 at %2</source>
      <translation variants="no">Сигнал відбув. один раз, наступ. %[07]1 о %2</translation>
    </message>
    <message numerus="no" id="txt_clock_note_alarm_occurs_workdays_at_1">
      <source>Alarm occurs workdays at %1</source>
      <translation variants="no">Сигнал відбувається в робочі дні о %1</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_saturday">
      <source>Saturday</source>
      <translation variants="no">Субота</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hrs_and_2_min">
      <source>Time to alarm %1 hours and %2 minute</source>
      <translation variants="no">Час до сигналу: %[08]1 год. %[08]2 хвилина</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_once">
      <source>Once</source>
      <translation variants="no">Немає</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hr_and_2_mins">
      <source>Time to alarm %1 hour and %2 minutes</source>
      <translation variants="no">Час до сигналу: %[09]1 година %[09]2 хв.</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_alarm_will_occur_at_1_after_au">
      <source>Alarm will occur at %1 after automatic daylight saving update</source>
      <translation variants="no">uk #Alarm will occur at %1 after automatic daylight saving update</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_alarm_sound">
      <source>Alarm sound</source>
      <translation variants="no">Звук сигналу</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_alarm_occurs_every_day_at_1">
      <source>Alarm occurs every day at %1</source>
      <translation variants="no">Сигнал відбувається щодня о %1</translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_time">
      <source>Time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Час</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_time">
      <source>Time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Час</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Дата</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hrs_and_2_mins">
      <source>Time to alarm %1 hours and %2 minutes</source>
      <translation variants="no">Час до сигналу: %[11]1 год. %[10]2 хв.</translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Дата сигналу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_val_alarm">
      <source>Alarm</source>
      <translation variants="no">Сигнал</translation>
    </message>
    <message numerus="no" id="txt_tumbler_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Час сигналу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_thursday">
      <source>Thursday</source>
      <translation variants="no">Четвер</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_on_workdays">
      <source>Repeat on workdays</source>
      <translation variants="no">Робочі дні</translation>
    </message>
    <message numerus="no" id="txt_clock_dpopinfo_time_to_alarm_1_hr_and_2_min">
      <source>Time to alarm %1 hour and %2 minute</source>
      <translation variants="no">Час до сигналу: %[07]1 година %[06]2 хвилина</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_description">
      <source>Description</source>
      <translation variants="no">Опис</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_delete">
      <source>Delete</source>
      <translation variants="no">Видалити</translation>
    </message>
    <message numerus="no" id="txt_clock_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">Скасувати зміни</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_monday">
      <source>Monday</source>
      <translation variants="no">Понеділок</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">Вівторок</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">Середа</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_new_alarm">
      <source>New alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">Новий сигнал</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">Сигнал</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_daily">
      <source>Repeat daily</source>
      <translation variants="no">Щодня</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_day">
      <source>Day</source>
      <translation variants="yes">
        <lengthvariant priority="1">День</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_weekly">
      <source>Repeat weekly</source>
      <translation variants="no">Щотижня</translation>
    </message>
  </context>
</TS>