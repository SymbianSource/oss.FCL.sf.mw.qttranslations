<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_secur_button_prompt_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">是</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cert_disabling">
      <source>Disabling a certificate may prevent you from installing or running some applications. Continue?</source>
      <translation variants="no">停用憑證可能會無法安裝或執行部分應用程式。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_title_cert_disabling">
      <source>Certificate management </source>
      <translation variants="yes">
        <lengthvariant priority="1">憑證管理</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_prompt_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cert_deleting">
      <source>Deleting a certificate may prevent you from installing or running some applications. Continue?</source>
      <translation variants="no">刪除憑證可能會無法安裝或執行部分應用程式。是否繼續？</translation>
    </message>
  </context>
</TS>