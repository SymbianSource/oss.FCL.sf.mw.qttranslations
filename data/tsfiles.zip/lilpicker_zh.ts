<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_lint_list_no_location_entries_present">
      <source>No Location entries present</source>
      <translation variants="yes">
        <lengthvariant priority="1">(无位置)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_title_select_location">
      <source>Select location</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择位置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_places">
      <source>Places</source>
      <translation variants="yes">
        <lengthvariant priority="1">位置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_button_done">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">完成</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_results">
      <source>No results</source>
      <translation variants="yes">
        <lengthvariant priority="1">(未找到对应项)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="yes">
        <lengthvariant priority="1">联系人地址</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by_sub_type">
      <source>Type</source>
      <translation variants="no">类型</translation>
    </message>
    <message numerus="no" id="txt_lint_opt_arrange">
      <source>Arrange</source>
      <translation variants="no">排列</translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by">
      <source>Sort by </source>
      <translation variants="no">排序方式</translation>
    </message>
    <message numerus="no" id="txt_lint_menu_details">
      <source>Details</source>
      <translation variants="no">详情</translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_calendar_event_locations">
      <source>Calendar locations</source>
      <translation variants="yes">
        <lengthvariant priority="1">日历项位置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_calendar_locations">
      <source>Calendar locations</source>
      <translation variants="yes">
        <lengthvariant priority="1">日历位置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="yes">
        <lengthvariant priority="1">联系人地址</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_lint_list_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">%Ln项</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by_sub_ascending">
      <source>Ascending</source>
      <translation variants="no">升序</translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_recent_map_searches">
      <source>Map searches</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近的地图搜索</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_opt_sort_by_sub_descending">
      <source>Descending</source>
      <translation variants="no">降序</translation>
    </message>
    <message numerus="no" id="txt_lint_subhead_places">
      <source>Places</source>
      <translation variants="yes">
        <lengthvariant priority="1">位置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_list_map_searches">
      <source>Map searches</source>
      <translation variants="yes">
        <lengthvariant priority="1">地图搜索</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_dblist_places_val_no_items">
      <source>No items</source>
      <translation variants="yes">
        <lengthvariant priority="1">无项目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_lint_menu_select">
      <source>Select</source>
      <translation variants="no">zh #Select</translation>
    </message>
  </context>
</TS>