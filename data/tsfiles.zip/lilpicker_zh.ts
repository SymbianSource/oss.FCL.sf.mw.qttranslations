<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_lint_list_recent_map_searches">
      <source>Recent map searches</source>
      <translation variants="no">最近的地图搜索</translation>
    </message>
    <message numerus="no" id="txt_lint_list_arrange">
      <source>Arrange</source>
      <translation variants="no">整理</translation>
    </message>
    <message numerus="no" id="txt_lint_list_type">
      <source>Type</source>
      <translation variants="no">类型</translation>
    </message>
    <message numerus="no" id="txt_lint_list_ascending">
      <source>Ascending</source>
      <translation variants="no">升序</translation>
    </message>
    <message numerus="no" id="txt_lint_list_places">
      <source>Places</source>
      <translation variants="no">位置</translation>
    </message>
    <message numerus="no" id="txt_lint_list_sort_by">
      <source>Sort by </source>
      <translation variants="no">排序方式</translation>
    </message>
    <message numerus="no" id="txt_lint_list_remove_thumbnail">
      <source>Remove thumbnail</source>
      <translation variants="no">删除微缩图像</translation>
    </message>
    <message numerus="no" id="txt_lint_list_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="no">联系人地址</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_location_entries_present">
      <source>No Location entries present</source>
      <translation variants="no">(无位置)</translation>
    </message>
    <message numerus="no" id="txt_lint_button_done">
      <source>Done</source>
      <translation variants="no">完成</translation>
    </message>
    <message numerus="no" id="txt_lint_list_descending">
      <source>Descending</source>
      <translation variants="no">降序</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_results">
      <source>No results</source>
      <translation variants="no">(未找到结果)</translation>
    </message>
    <message numerus="no" id="txt_lint_list_calendar_event_locations">
      <source>Calendar event locations</source>
      <translation variants="no">日历项位置</translation>
    </message>
    <message numerus="no" id="txt_lint_title_select_location">
      <source>Select location</source>
      <translation variants="no">选择位置</translation>
    </message>
    <message numerus="no" id="txt_lint_list_details">
      <source>Details</source>
      <translation variants="no">详情</translation>
    </message>
  </context>
</TS>