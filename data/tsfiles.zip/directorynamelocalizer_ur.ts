<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_links">
      <source>Links</source>
      <translation variants="no">ربط</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_install">
      <source>Install files</source>
      <translation variants="no">نصب شدہ فائلیں</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_sounds">
      <source>Sound files</source>
      <translation variants="no">صوتی فائلیں</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_contacts">
      <source>Contats</source>
      <translation variants="no">روابط</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_games">
      <source>Games</source>
      <translation variants="no">کھیل</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_others">
      <source>Others</source>
      <translation variants="no">دیگر</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_digital_tones">
      <source>Sound clips</source>
      <translation variants="no">صوتی کلپس</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_pres_logos">
      <source>Presence logos</source>
      <translation variants="no">موجودگی لوگوز</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_mms_bc">
      <source>Wallpapers</source>
      <translation variants="no">وال پیپر</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_gms_pict">
      <source>Picture messages</source>
      <translation variants="no">تصویری پیغامات</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_videos">
      <source>Video clips</source>
      <translation variants="no">ویڈیو کلپس</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_images">
      <source>Images</source>
      <translation variants="no">شبیہات</translation>
    </message>
    <message numerus="no" id="txt_directorynamelocalizer_foldername_simple_tones">
      <source>Ringing tones</source>
      <translation variants="no">گھنٹی ٹونز</translation>
    </message>
  </context>
</TS>