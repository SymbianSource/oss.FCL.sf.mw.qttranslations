<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mus_list_shuffle">
      <source>Shuffle</source>
      <translation variants="no">پھینٹیں</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_audio_effects">
      <source>Audio effects</source>
      <translation variants="yes">
        <lengthvariant priority="1">آڈیو تاثرات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="yes" id="txt_mus_subhead_ln_songs">
      <source>%Ln songs</source>
      <translation>
        <numerusform plurality="a">%Ln گانا</numerusform>
        <numerusform plurality="b">%Ln گانے</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_on">
      <source>On</source>
      <translation variants="no">چالو</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown_all">
      <source>Unknown - All</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم - تمام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ شامل کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">جاز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_1_all">
      <source>%1 - All</source>
      <translation variants="no">%1 - تمام</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">پاپ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">سب کو نشان رد کریں</translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ شامل کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_mark_all">
      <source>Mark all</source>
      <translation variants="no">سب کو نشان زد کریں</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_audio_effects">
      <source>Audio effects</source>
      <translation variants="no">آڈیو تاثرات</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown4">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_mus_list_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">اکثر چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_equalizer">
      <source>Equalizer</source>
      <translation variants="no">برابری لانے والا</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">موسیقی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_menu_view_details">
      <source>View details</source>
      <translation variants="no">تفصیلات دیکھیں</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_all_songs">
      <source>All songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">تمام گانے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">کلاسیکی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">اکثر چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_inspire_me">
      <source>Inspire me</source>
      <translation variants="yes">
        <lengthvariant priority="1">مجھے ترغیب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown2">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_long_caption_music">
      <source>Music</source>
      <translation variants="no">موسیقی</translation>
    </message>
    <message numerus="no" id="txt_mus_menu_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">پلے فہر. میں شامل</translation>
    </message>
    <message numerus="no" id="txt_mus_list_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_song_details">
      <source>Song details </source>
      <translation variants="yes">
        <lengthvariant priority="1">گانے کی تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_off">
      <source>Repeat off</source>
      <translation variants="no">دہرانا بند</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_playlist">
      <source>Select playlist:</source>
      <translation variants="yes">
        <lengthvariant priority="1">پلے فہرست منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_shuffle">
      <source>Shuffle</source>
      <translation variants="yes">
        <lengthvariant priority="1">کہیں سے بھی چلائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_off">
      <source>Off</source>
      <translation variants="no">بند</translation>
    </message>
    <message numerus="no" id="txt_mus_list_bass_booster">
      <source>Bass booster</source>
      <translation variants="yes">
        <lengthvariant priority="1">باس بوسٹر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_playlist">
      <source>Delete playlist?</source>
      <translation variants="no">پلے فہرست مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name">
      <source>Enter name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">نام:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_album">
      <source>Delete album?</source>
      <translation variants="no">البم مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_list_ovi_music">
      <source>Ovi music store</source>
      <translation variants="yes">
        <lengthvariant priority="1">میوزک اسٹور</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_button_new">
      <source>New</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_balance">
      <source>Balance</source>
      <translation variants="no">توازن</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_preset">
      <source>Select preset:</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیش مرتب منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">جاز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_out_of_disk_space">
      <source>Out of disk space.</source>
      <translation variants="no">تازہ کاری منسوخ۔ حافظے سے خارج۔</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_quick_access_to_your_music">
      <source>Quick access to your music</source>
      <translation variants="yes">
        <lengthvariant priority="1">آپ کی موسیقی تک فوری رسائی</lengthvariant>
        <lengthvariant priority="2">موسیقی تک رسائی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_removing_songs">
      <source>Removing songs…</source>
      <translation variants="no">گانے ہٹائے جارہے ہیں</translation>
    </message>
    <message numerus="no" id="txt_mus_info_adding_songs">
      <source>Adding songs...</source>
      <translation variants="no">گانے شامل کیے جارہے ہیں</translation>
    </message>
    <message numerus="no" id="txt_mus_info_music_may_need_to_be_refreshed">
      <source>Music may need to be refreshed due to recent USB sync. Refresh now?</source>
      <translation variants="no">حالیہ USB ہمزمانہ کے سبب موسیقی کی تازہ کاری درکار ہے۔ ابھی تازہ کاری کریں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown10">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre">
      <source>Genre</source>
      <translation variants="yes">
        <lengthvariant priority="1">صنف</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_file_is_corrupt">
      <source>File is corrupt. Operation cancelled.</source>
      <translation variants="no">فائل خراب ہے۔ عمل منسوخ کیا گیا۔</translation>
    </message>
    <message numerus="no" id="txt_mus_info_unable_to_play_selection">
      <source>Unable to play selection. Operation cancelled.</source>
      <translation variants="no">انتخاب چلانے سے قاصر۔ عمل منسوخ کیا گیا۔</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_there_are_no_recommendations">
      <source>There are no recommendations for this track</source>
      <translation variants="no">اس ٹریک کے لیے کوئی سفارش نہیں</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_sampling_rate_val_ln_hz">
      <source>%Ln hz</source>
      <translation>
        <numerusform plurality="a">%Ln ہرٹز</numerusform>
        <numerusform plurality="b">%Ln ہرٹز</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_spoken">
      <source>Spoken</source>
      <translation variants="yes">
        <lengthvariant priority="1">بولا ہوا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">کلاسیکل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_easy_listening">
      <source>Easy Listening</source>
      <translation variants="yes">
        <lengthvariant priority="1">آسان سماعت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_no_music">
      <source>(No music)</source>
      <translation variants="no">(کوئی موسیقی نہیں)</translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_mb">
      <source>%Ln MB</source>
      <translation>
        <numerusform plurality="a">%Ln م ب</numerusform>
        <numerusform plurality="b">%Ln م ب</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown8">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_licences">
      <source>Licences</source>
      <translation variants="yes">
        <lengthvariant priority="1">لائسنسز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_metal">
      <source>Metal</source>
      <translation variants="yes">
        <lengthvariant priority="1">میٹل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_year">
      <source>Year</source>
      <translation variants="yes">
        <lengthvariant priority="1">سال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_bitrate">
      <source>Bitrate</source>
      <translation variants="yes">
        <lengthvariant priority="1">بٹ ریٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_refreshingnln_songs_added">
      <source>Refreshing…</source>
      <translation variants="yes">
        <lengthvariant priority="1">تازہ کاری ہو رہی ہے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_music_player">
      <source>Music player</source>
      <translation variants="yes">
        <lengthvariant priority="1">میوزک پلیئر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_world">
      <source>World</source>
      <translation variants="yes">
        <lengthvariant priority="1">دنیا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_file_name">
      <source>File name</source>
      <translation variants="yes">
        <lengthvariant priority="1">فائل کا نام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_latin">
      <source>Latin</source>
      <translation variants="yes">
        <lengthvariant priority="1">لاطینی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_format">
      <source>Format</source>
      <translation variants="yes">
        <lengthvariant priority="1">فارمیٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_duration">
      <source>Duration</source>
      <translation variants="yes">
        <lengthvariant priority="1">مدت</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_gb">
      <source>%Ln GB</source>
      <translation>
        <numerusform plurality="a">%Ln گ ب</numerusform>
        <numerusform plurality="b">%Ln گ ب</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_licences_val_click_for_details">
      <source>Click for details</source>
      <translation variants="yes">
        <lengthvariant priority="1">تفصیلات کے لیے کلک کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown_1">
      <source>Unknown - %1</source>
      <translation variants="no">نامعلوم: %1</translation>
    </message>
    <message numerus="no" id="txt_mus_title_arrange">
      <source>Arrange</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_cancelled">
      <source>Refresh cancelled</source>
      <translation variants="no">تازہ کاری منسوخ کی گئی</translation>
    </message>
    <message numerus="no" id="txt_mus_info_please_note_that_using_media_transfer">
      <source>Please note that using Media Transfer mode to transfer your music will optimize your music experience. To learn more, please go to %1. Remind me later?</source>
      <translation variants="no">یاد رکھیں کہ آپ موسیقی کی منتقلی کے لیے میڈیا منتقلی وضع کا استعمال آپ کی موسیقی کے لطف کو زیادہ سے زیادہ کر دے گا۔ مزید جاننے کے لیے %[99]1 پر جائیں۔ مجھے بعد میں یاد دلائیں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_soundtrack">
      <source>Soundtrack</source>
      <translation variants="yes">
        <lengthvariant priority="1">ساؤنڈ ٹریک</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_dance">
      <source>Dance</source>
      <translation variants="yes">
        <lengthvariant priority="1">رقص</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_an_error_occurred">
      <source>An error occurred. Sharing is not currently available.</source>
      <translation variants="no">ایک غلطی واقع ہوئی۔ شراکت فی الحال دستیاب نہیں۔</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_kb">
      <source>%Ln kB</source>
      <translation>
        <numerusform plurality="a">%Ln ک ب</numerusform>
        <numerusform plurality="b">%Ln ک ب</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown7">
      <source>Unknown </source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown1">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_complete">
      <source>Refresh complete</source>
      <translation variants="no">تازہ کاری مکمل</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">پاپ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_refresh_cancelled">
      <source>Refresh cancelled</source>
      <translation variants="yes">
        <lengthvariant priority="1">تازہ کاری منسوخ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown3">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown3">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_b">
      <source>%Ln B</source>
      <translation>
        <numerusform plurality="a">%Ln ب</numerusform>
        <numerusform plurality="b">%Ln ب</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_share">
      <source>Share</source>
      <translation variants="no">شراکت کریں</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_size">
      <source>Size</source>
      <translation variants="yes">
        <lengthvariant priority="1">سائز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_country">
      <source>Country</source>
      <translation variants="yes">
        <lengthvariant priority="1">دیہی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown9">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_reggae">
      <source>Reggae</source>
      <translation variants="yes">
        <lengthvariant priority="1">ریگّے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_songs">
      <source>Select songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">گانے منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_electronic">
      <source>Electronic</source>
      <translation variants="yes">
        <lengthvariant priority="1">برقی</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_info_ln_songs_found">
      <source>%Ln songs found</source>
      <translation>
        <numerusform plurality="a">%Ln گانے مل گئے</numerusform>
        <numerusform plurality="b">%Ln گانا مل گیا</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown6">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_refresh_library">
      <source>Refresh library</source>
      <translation variants="no">لائبریری کی تازہ کاری</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_modified">
      <source>Modified</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترمیم شدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">راک</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_song_number">
      <source>Song number</source>
      <translation variants="yes">
        <lengthvariant priority="1">گانا نمبر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_select_a_song">
      <source>Select a song</source>
      <translation variants="yes">
        <lengthvariant priority="1">گانا منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_deleting">
      <source>Deleting..</source>
      <translation variants="no">مٹا رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness">
      <source>Loudness</source>
      <translation variants="no">آواز کی تیزی</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">دیگر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_music">
      <source>Music</source>
      <translation variants="no">موسیقی</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">پلے فہر. میں شامل</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_new_playlist">
      <source>New playlist</source>
      <translation variants="no">نئی پلے فہرست</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name_entry_playlist_l1">
      <source>Playlist %L1</source>
      <translation variants="no">پلے فہرست %L1</translation>
    </message>
    <message numerus="no" id="txt_mus_list_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">راک</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_on">
      <source>Repeat on</source>
      <translation variants="no">دہرانا چالو</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_acoustic">
      <source>Acoustic</source>
      <translation variants="yes">
        <lengthvariant priority="1">سمعی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_new_age">
      <source>New Age</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا دور</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_composer">
      <source>Composer</source>
      <translation variants="yes">
        <lengthvariant priority="1">نغمہ ساز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown5">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown4">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_blues">
      <source>Blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">بلیوز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_copyright">
      <source>Copyright</source>
      <translation variants="yes">
        <lengthvariant priority="1">حق اشاعت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_sampling_rate">
      <source>Sampling rate</source>
      <translation variants="yes">
        <lengthvariant priority="1">شرح نمونہ کاری</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_remove_songs">
      <source>Remove songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">گانے نکالیں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_send_via_bluetooth">
      <source>Send via Bluetooth</source>
      <translation variants="no">بذریعے Bluetooth ارسال</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_song">
      <source>Delete song?</source>
      <translation variants="no">گانا مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_info_usb_conn_in_progress">
      <source>USB connection in progress</source>
      <translation variants="no">USB اتصال جاری ہے</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_folk">
      <source>Folk</source>
      <translation variants="yes">
        <lengthvariant priority="1">عوامی</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_bitrate_val_ln_kbps">
      <source>%Ln Kbps</source>
      <translation>
        <numerusform plurality="a">%Ln ک بٹ  فی سیکنڈ</numerusform>
        <numerusform plurality="b">%Ln ک بٹ/سیکنڈ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_web_site">
      <source>Web site</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویب پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_alternative">
      <source>Alternative</source>
      <translation variants="yes">
        <lengthvariant priority="1">متبادل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_hiphop">
      <source>Hip-Hop</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہپ-ہاپ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown5">
      <source>Unknown</source>
      <translation variants="no">نامعلوم</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_rap">
      <source>Rap</source>
      <translation variants="yes">
        <lengthvariant priority="1">ریپ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_rb">
      <source>R&amp;B</source>
      <translation variants="yes">
        <lengthvariant priority="1">آر و بی</lengthvariant>
      </translation>
    </message>
  </context>
</TS>