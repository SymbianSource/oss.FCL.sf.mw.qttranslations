<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="yes" id="txt_mus_subhead_ln_songs">
      <source>%Ln songs</source>
      <translation>
        <numerusform plurality="a">%Ln گانا</numerusform>
        <numerusform plurality="b">%Ln گانے</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_on">
      <source>On</source>
      <translation variants="no">چالو</translation>
    </message>
    <message numerus="no" id="txt_mus_list_shuffle">
      <source>Shuffle</source>
      <translation variants="no">ur #Shuffle</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ شامل کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">ur #Unmark all</translation>
    </message>
    <message numerus="no" id="txt_mus_list_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">اکثر چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">کلاسیکی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_inspire_me">
      <source>Inspire me</source>
      <translation variants="yes">
        <lengthvariant priority="1">مجھے ترغیب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">پلے فہر. میں شامل</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_new_playlist">
      <source>New playlist</source>
      <translation variants="no">نئی پلے فہرست</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name_entry_playlist_l1">
      <source>Playlist %L1</source>
      <translation variants="no">ur #Playlist %L1</translation>
    </message>
    <message numerus="no" id="txt_long_caption_music">
      <source>Music</source>
      <translation variants="no">موسیقی</translation>
    </message>
    <message numerus="no" id="txt_mus_menu_view_details">
      <source>View details</source>
      <translation variants="no">تفصیلات دیکھیں</translation>
    </message>
    <message numerus="no" id="txt_mus_list_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">راک</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_menu_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">پلے فہر. میں شامل</translation>
    </message>
    <message numerus="no" id="txt_mus_list_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_1_all">
      <source>%1 - All</source>
      <translation variants="no">%1 - تمام</translation>
    </message>
    <message numerus="no" id="txt_mus_list_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">پاپ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_off">
      <source>Repeat off</source>
      <translation variants="no">دہرانا بند</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_on">
      <source>Repeat on</source>
      <translation variants="no">دہرانا چالو</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_audio_effects">
      <source>Audio effects</source>
      <translation variants="yes">
        <lengthvariant priority="1">آڈیو تاثرات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_mark_all">
      <source>Mark all</source>
      <translation variants="no">ur #Mark all</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown4">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_equalizer">
      <source>Equalizer</source>
      <translation variants="no">برابری لانے والا</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown_all">
      <source>Unknown - All</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم - تمام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_all_songs">
      <source>All songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">تمام گانے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">جاز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">اکثر چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown2">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ شامل کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_audio_effects">
      <source>Audio effects</source>
      <translation variants="no">آڈیو تاثرات</translation>
    </message>
    <message numerus="no" id="txt_mus_title_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">موسیقی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_year">
      <source>Year</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Year</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_bitrate">
      <source>Bitrate</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Bit rate</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_world">
      <source>World</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #World</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_format">
      <source>Format</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Format</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_duration">
      <source>Duration</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Duration</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_gb">
      <source>%Ln GB</source>
      <translation>
        <numerusform plurality="a">ur #%Ln GB</numerusform>
        <numerusform plurality="b">ur #%Ln GB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_licences_val_click_for_details">
      <source>Click for details</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Click for details</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown_1">
      <source>Unknown - %1</source>
      <translation variants="no">ur #Unknown: %1</translation>
    </message>
    <message numerus="no" id="txt_mus_info_usb_conn_in_progress">
      <source>USB connection in progress</source>
      <translation variants="no">ur #USB connection in progress</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_folk">
      <source>Folk</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Folk</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_bitrate_val_ln_kbps">
      <source>%Ln Kbps</source>
      <translation>
        <numerusform plurality="a">ur #%Ln kbps</numerusform>
        <numerusform plurality="b">ur #%Ln kbps</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_web_site">
      <source>Web site</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Web address</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Unknown</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_alternative">
      <source>Alternative</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Alternative</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_hiphop">
      <source>Hip-Hop</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Hip-hop</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_mb">
      <source>%Ln MB</source>
      <translation>
        <numerusform plurality="a">ur #%Ln MB</numerusform>
        <numerusform plurality="b">ur #%Ln MB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown8">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_licences">
      <source>Licences</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Licences</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_metal">
      <source>Metal</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Metal</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_refreshingnln_songs_added">
      <source>Refreshing…</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Refreshing…</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_music_player">
      <source>Music player</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Music player</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_file_name">
      <source>File name</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #File name</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_latin">
      <source>Latin</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Latin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_arrange">
      <source>Arrange</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Arrange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_cancelled">
      <source>Refresh cancelled</source>
      <translation variants="no">ur #Refresh cancelled</translation>
    </message>
    <message numerus="no" id="txt_mus_info_please_note_that_using_media_transfer">
      <source>Please note that using Media Transfer mode to transfer your music will optimize your music experience. To learn more, please go to %1. Remind me later?</source>
      <translation variants="no">ur #Please note that using Media Transfer mode to transfer your music will optimize your music experience. To learn more, please go to %1. Remind me later?</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_soundtrack">
      <source>Soundtrack</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Soundtrack</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_dance">
      <source>Dance</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Dance</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_an_error_occurred">
      <source>An error occurred. Sharing is not currently available.</source>
      <translation variants="no">ur #An error occurred. Sharing is not currently available.</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_kb">
      <source>%Ln kB</source>
      <translation>
        <numerusform plurality="a">ur #%Ln kB</numerusform>
        <numerusform plurality="b">ur #%Ln kB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Jazz</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_out_of_disk_space">
      <source>Out of disk space.</source>
      <translation variants="no">ur #Refresh cancelled. Out of memory.</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_quick_access_to_your_music">
      <source>Quick access to your music</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Quick access to your music</lengthvariant>
        <lengthvariant priority="2">ur #Quick access to music</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_removing_songs">
      <source>Removing songs…</source>
      <translation variants="no">ur #Removing songs</translation>
    </message>
    <message numerus="no" id="txt_mus_info_adding_songs">
      <source>Adding songs...</source>
      <translation variants="no">ur #Adding songs</translation>
    </message>
    <message numerus="no" id="txt_mus_info_music_may_need_to_be_refreshed">
      <source>Music may need to be refreshed due to recent USB sync. Refresh now?</source>
      <translation variants="no">ur #Music may need to be refreshed due to recent USB sync. Refresh now?</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown10">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre">
      <source>Genre</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Genre</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_file_is_corrupt">
      <source>File is corrupt. Operation cancelled.</source>
      <translation variants="no">ur #File is corrupt. Operation cancelled.</translation>
    </message>
    <message numerus="no" id="txt_mus_info_unable_to_play_selection">
      <source>Unable to play selection. Operation cancelled.</source>
      <translation variants="no">ur #Unable to play selection. Operation cancelled.</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_there_are_no_recommendations">
      <source>There are no recommendations for this track</source>
      <translation variants="no">ur #No recommendations for this track</translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_sampling_rate_val_ln_hz">
      <source>%Ln hz</source>
      <translation>
        <numerusform plurality="a">ur #%Ln Hz</numerusform>
        <numerusform plurality="b">ur #%Ln Hz</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_spoken">
      <source>Spoken</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Spoken</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Classical</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_easy_listening">
      <source>Easy Listening</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Easy Listening</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_complete">
      <source>Refresh complete</source>
      <translation variants="no">تازہ کاری مکمل ہوگئی</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown5">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown7">
      <source>Unknown </source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown1">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_playlist">
      <source>Delete playlist?</source>
      <translation variants="no">پلے فہرست مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name">
      <source>Enter name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">نام:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_share">
      <source>Share</source>
      <translation variants="no">ur #Share</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_album">
      <source>Delete album?</source>
      <translation variants="no">البم مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_list_ovi_music">
      <source>Ovi music store</source>
      <translation variants="yes">
        <lengthvariant priority="1">میوزک اسٹور</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_button_new">
      <source>New</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_balance">
      <source>Balance</source>
      <translation variants="no">توازن</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_preset">
      <source>Select preset:</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیش مرتب منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_no_music">
      <source>(No music)</source>
      <translation variants="no">ur #(no music)</translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_rap">
      <source>Rap</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Rap</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_rb">
      <source>R&amp;B</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #R&amp;B</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_modified">
      <source>Modified</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Modified</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_refresh_library">
      <source>Refresh library</source>
      <translation variants="no">لائبریری کی تازہ کاری</translation>
    </message>
    <message numerus="no" id="txt_mus_info_deleting">
      <source>Deleting..</source>
      <translation variants="no">ur #Deleting</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Rock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_song_number">
      <source>Song number</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Song number</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_songs">
      <source>Select songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">گانے منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_select_a_song">
      <source>Select a song</source>
      <translation variants="yes">
        <lengthvariant priority="1">گانا منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_acoustic">
      <source>Acoustic</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Acoustic</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_new_age">
      <source>New Age</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #New Age</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_composer">
      <source>Composer</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Composer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown5">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Unknown</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown4">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Unknown</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_blues">
      <source>Blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Blues</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_copyright">
      <source>Copyright</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Copyright</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_sampling_rate">
      <source>Sampling rate</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Sampling rate</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown3">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown3">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_electronic">
      <source>Electronic</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Electronic</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_info_ln_songs_found">
      <source>%Ln songs found</source>
      <translation>
        <numerusform plurality="a">ur #%Ln song found</numerusform>
        <numerusform plurality="b">ur #%Ln songs found</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_remove_songs">
      <source>Remove songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">گانے نکالیں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_send_via_bluetooth">
      <source>Send via Bluetooth</source>
      <translation variants="no">بذریعے Bluetooth ارسال</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_song_details">
      <source>Song details </source>
      <translation variants="yes">
        <lengthvariant priority="1">گانے کی تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_playlist">
      <source>Select playlist:</source>
      <translation variants="yes">
        <lengthvariant priority="1">پلے فہرست منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_shuffle">
      <source>Shuffle</source>
      <translation variants="yes">
        <lengthvariant priority="1">کہیں سے بھی چلائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_off">
      <source>Off</source>
      <translation variants="no">بند</translation>
    </message>
    <message numerus="no" id="txt_mus_list_bass_booster">
      <source>Bass booster</source>
      <translation variants="yes">
        <lengthvariant priority="1">باس بوسٹر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_song">
      <source>Delete song?</source>
      <translation variants="no">گانا مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Pop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_refresh_cancelled">
      <source>Refresh cancelled</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Refresh cancelled</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_dblist_size_val_ln_b">
      <source>%Ln B</source>
      <translation>
        <numerusform plurality="a">ur #%Ln B</numerusform>
        <numerusform plurality="b">ur #%Ln B</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_size">
      <source>Size</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Size</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_country">
      <source>Country</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Country</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown9">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_reggae">
      <source>Reggae</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Reggae</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown6">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness">
      <source>Loudness</source>
      <translation variants="no">آواز کی تیزی</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_genre_val_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Other</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_music">
      <source>Music</source>
      <translation variants="no">ur #Music</translation>
    </message>
  </context>
</TS>