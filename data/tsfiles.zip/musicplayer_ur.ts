<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mus_other_unknown5">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown6">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown7">
      <source>Unknown </source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown1">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="yes" id="txt_mus_info_ln_songs_added">
      <source>%Ln songs added</source>
      <translation>
        <numerusform plurality="a">%Ln گانا شامل کیا گیا</numerusform>
        <numerusform plurality="b">%Ln گانے شامل کیے گئے</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_remove_songs">
      <source>Remove songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">گانے نکالیں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_send_via_bluetooth">
      <source>Send via Bluetooth</source>
      <translation variants="no">بذریعے Bluetooth ارسال</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_complete">
      <source>Refresh complete</source>
      <translation variants="yes">
        <lengthvariant priority="1">تازہ کاری مکمل ہوگئی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_no_music">
      <source>(No music)</source>
      <translation variants="no">ur #(no music)</translation>
    </message>
    <message numerus="no" id="txt_mus_other_more_recommendations">
      <source>More recommendations</source>
      <translation variants="no">ur #More recommendations</translation>
    </message>
    <message numerus="yes" id="txt_mus_dpopinfo_ln_songs_added">
      <source>%Ln songs added</source>
      <translation>
        <numerusform plurality="a">%Ln گانا شامل کیا گیا</numerusform>
        <numerusform plurality="b">%Ln گانے شامل کیے گئے</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_title_refreshing">
      <source>Refreshing...</source>
      <translation variants="yes">
        <lengthvariant priority="1">تازہ کاری</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_share">
      <source>Share</source>
      <translation variants="no">ur #Share</translation>
    </message>
    <message numerus="no" id="txt_mus_dpophead_refresh_stopped">
      <source>Refresh stopped</source>
      <translation variants="yes">
        <lengthvariant priority="1">تازہ کاری روک دی گئی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_info_to_get_music_visit_ovi_music">
      <source>To get music, visit Ovi Music.</source>
      <translation variants="no">ur #To get music, visit Music store.</translation>
    </message>
    <message numerus="no" id="txt_mus_button_shuffle">
      <source>Shuffle</source>
      <translation variants="yes">
        <lengthvariant priority="1">کہیں سے بھی چلائیں</lengthvariant>
        <lengthvariant priority="2">ک. س. چلائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_audio_effects">
      <source>Audio effects</source>
      <translation variants="yes">
        <lengthvariant priority="1">آڈیو تاثرات</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_mus_subhead_ln_songs">
      <source>%Ln songs</source>
      <translation>
        <numerusform plurality="a">%Ln گانا</numerusform>
        <numerusform plurality="b">%Ln گانے</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_on">
      <source>On</source>
      <translation variants="no">چالو</translation>
    </message>
    <message numerus="no" id="txt_mus_title_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ شامل کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">ur #Unmark all</translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_left">
      <source>Left</source>
      <translation variants="yes">
        <lengthvariant priority="1">بایاں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">اکثر چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown_all">
      <source>Unknown - All</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم - تمام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_menu_view_details">
      <source>View details</source>
      <translation variants="no">تفصیلات دیکھیں</translation>
    </message>
    <message numerus="no" id="txt_mus_list_jazz">
      <source>Jazz</source>
      <translation variants="yes">
        <lengthvariant priority="1">جاز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_added">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ شامل کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_audio_effects">
      <source>Audio effects</source>
      <translation variants="no">آڈیو تاثرات</translation>
    </message>
    <message numerus="no" id="txt_mus_caption_music">
      <source>Music</source>
      <translation variants="no">ur #Music</translation>
    </message>
    <message numerus="no" id="txt_mus_title_music">
      <source>Music</source>
      <translation variants="no">موسیقی</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown2">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_mark_all">
      <source>Mark all</source>
      <translation variants="no">ur #Mark all</translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_left_l1">
      <source>Left %L1%</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Left %L1%</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown4">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_song_details">
      <source>Song details </source>
      <translation variants="yes">
        <lengthvariant priority="1">گانے کی تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_equalizer">
      <source>Equalizer</source>
      <translation variants="no">برابری لانے والا</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_all_songs">
      <source>All songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">تمام گانے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">پلے فہر. میں شامل</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_playlist">
      <source>Select playlist:</source>
      <translation variants="yes">
        <lengthvariant priority="1">پلے فہرست منتخب کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_most_played">
      <source>Most played</source>
      <translation variants="yes">
        <lengthvariant priority="1">اکثر چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown2">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_opt_new_playlist">
      <source>New playlist</source>
      <translation variants="no">نئی پلے فہرست</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name_entry_playlist_l1">
      <source>Playlist %L1</source>
      <translation variants="no">ur #Playlist %L1</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_rock">
      <source>Rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">راک</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_centre">
      <source>Centre</source>
      <translation variants="yes">
        <lengthvariant priority="1">مرکز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_on">
      <source>Repeat on</source>
      <translation variants="no">دہرانا چالو</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_shuffle">
      <source>Shuffle</source>
      <translation variants="yes">
        <lengthvariant priority="1">کہیں سے بھی چلائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_music">
      <source>Music</source>
      <translation variants="no">ur #Music</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness_val_off">
      <source>Off</source>
      <translation variants="no">بند</translation>
    </message>
    <message numerus="no" id="txt_mus_list_bass_booster">
      <source>Bass booster</source>
      <translation variants="yes">
        <lengthvariant priority="1">باس بوسٹر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_shuffle">
      <source>Shuffle</source>
      <translation variants="no">ur #Shuffle</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_list_recently_played">
      <source>Recently played</source>
      <translation variants="yes">
        <lengthvariant priority="1">حالیہ چلائے گئے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_right_l1">
      <source>Right %L1%</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Right %L1%</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_1_all">
      <source>%1 - All</source>
      <translation variants="no">%1 - تمام</translation>
    </message>
    <message numerus="no" id="txt_mus_list_pop">
      <source>Pop</source>
      <translation variants="yes">
        <lengthvariant priority="1">پاپ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_playlist">
      <source>Delete playlist?</source>
      <translation variants="no">پلے فہرست مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_dialog_enter_name">
      <source>Enter name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">نام:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_delete_album">
      <source>Delete album?</source>
      <translation variants="no">البم مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_list_ovi_music">
      <source>Ovi Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">میوزک اسٹور</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_button_new">
      <source>New</source>
      <translation variants="no">نیا</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_balance">
      <source>Balance</source>
      <translation variants="no">توازن</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_preset">
      <source>Select preset:</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیش مرتب منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_stereo_widening">
      <source>Stereo widening</source>
      <translation variants="no">اسٹیریو چوڑائی</translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_select_a_song">
      <source>Select a song:</source>
      <translation variants="yes">
        <lengthvariant priority="1">گانا منتخب کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_slidervalue_right">
      <source>Right</source>
      <translation variants="yes">
        <lengthvariant priority="1">داہنا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_refresh_library">
      <source>Refresh library</source>
      <translation variants="no">لائبریری کی تازہ کاری</translation>
    </message>
    <message numerus="no" id="txt_mus_setlabel_loudness">
      <source>Loudness</source>
      <translation variants="no">آواز کی تیزی</translation>
    </message>
    <message numerus="no" id="txt_mus_other_unknown3">
      <source>Unknown</source>
      <translation variants="no">ur #Unknown</translation>
    </message>
    <message numerus="no" id="txt_mus_delete_song">
      <source>Delete song?</source>
      <translation variants="no">گانا مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_mus_dblist_val_unknown3">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_list_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">کلاسیکی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_subtitle_inspire_me">
      <source>Inspire me</source>
      <translation variants="yes">
        <lengthvariant priority="1">مجھے ترغیب دیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_music">
      <source>Music</source>
      <translation variants="no">موسیقی</translation>
    </message>
    <message numerus="no" id="txt_mus_menu_add_to_playlist">
      <source>Add to playlist</source>
      <translation variants="no">پلے فہر. میں شامل</translation>
    </message>
    <message numerus="no" id="txt_mus_list_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mus_opt_repeat_off">
      <source>Repeat off</source>
      <translation variants="no">دہرانا بند</translation>
    </message>
    <message numerus="no" id="txt_mus_title_select_songs">
      <source>Select songs:</source>
      <translation variants="yes">
        <lengthvariant priority="1">گانے منتخب کریں:</lengthvariant>
      </translation>
    </message>
  </context>
</TS>