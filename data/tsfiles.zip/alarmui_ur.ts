<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Calendar alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">کیلنڈر الارم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>To-do note</source>
      <translation variants="yes">
        <lengthvariant priority="1">اہم کام نوٹ الارم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_silence">
      <source>Silence</source>
      <translation variants="no">ur ##Silence</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">خاموشی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Snooze</source>
      <translation variants="yes">
        <lengthvariant priority="1">ملتوی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_time">
      <source>%2</source>
      <translation variants="no">ur ##%2</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snooxed_for_ln_minute">
      <source>Alarm snooxed for %Ln minutes</source>
      <translation>
        <numerusform plurality="a">الارم %Ln منٹ کے لیے ملتوی  کیا گیا</numerusform>
        <numerusform plurality="b">الارم %Ln منٹ کے لیے ملتوی  کیے گئے</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_dialog_snooze">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">روکیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_date">
      <source>%1</source>
      <translation variants="no">ur ##%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_date">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_slide_down_to_stop">
      <source>Slide down to stop</source>
      <translation variants="no">ur ##Slide down to stop</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Clock alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">گھڑی الارم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_snooze">
      <source>Snooze</source>
      <translation variants="no">ur ##Snooze</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Switch phone on ?</source>
      <translation variants="no">آلے کو سوئچ آن کریں/چالو کریں؟</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_time">
      <source>%2</source>
      <translation variants="no">%2</translation>
    </message>
  </context>
</TS>