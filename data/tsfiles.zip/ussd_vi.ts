<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_ussd_info_there_are_still_unread_notifications">
      <source>There are still unread notifications.Exit anyway?</source>
      <translation variants="no">Vẫn còn tin nhắn chưa đọc. Vẫn thoát?</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_exit">
      <source>Exit </source>
      <translation variants="yes">
        <lengthvariant priority="1">Thoát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_not_completed">
      <source>Request not completed</source>
      <translation variants="no">Yêu cầu chưa được hoàn tất</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_unable_to_use_network_phone_is">
      <source>Unable to use network. Phone is currently in offline mode.</source>
      <translation variants="no">Không thể sử dụng mạng ở c.độ offline</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">Không được phép</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_not_confirmed">
      <source>Request not confirmed</source>
      <translation variants="no">Yêu cầu chưa được xác nhận</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_message">
      <source>Message:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tin nhắn đã nhận:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_no_service">
      <source>No service</source>
      <translation variants="no">Không có dịch vụ</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_service_commands">
      <source>Service commands</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lệnh dịch vụ</lengthvariant>
        <lengthvariant priority="2">vi #Service comms.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_done">
      <source>Done</source>
      <translation variants="no">Xong</translation>
    </message>
    <message numerus="no" id="txt_ussd_button_next">
      <source>Next</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kế tiếp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_button_reply">
      <source>Reply </source>
      <translation variants="yes">
        <lengthvariant priority="1">Trả lời</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_request_completed">
      <source>Request completed</source>
      <translation variants="no">Đã hoàn tất yêu cầu</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_unconfirmed">
      <source>Unconfirmed</source>
      <translation variants="no">vi ##Unconfirmed</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_offline_not_possible">
      <source>Offline not possible</source>
      <translation variants="no">vi ##Offline not possible</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_sending">
      <source>Sending</source>
      <translation variants="no">Đang gửi lệnh dịch vụ</translation>
    </message>
    <message numerus="no" id="txt_long_caption_service_commands">
      <source>Service commands</source>
      <translation variants="no">Lệnh dịch vụ</translation>
    </message>
    <message numerus="no" id="txt_ussd_title_reply">
      <source>Reply:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trả lời:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_not_done">
      <source>Not done</source>
      <translation variants="no">Chưa xong</translation>
    </message>
    <message numerus="no" id="txt_ussd_dpopinfo_result_unknown">
      <source>Result unknown</source>
      <translation variants="no">Tín hiệu hồi đáp chưa xác định</translation>
    </message>
  </context>
</TS>