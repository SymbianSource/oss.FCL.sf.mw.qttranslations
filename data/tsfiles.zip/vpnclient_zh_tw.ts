<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_delete_vp">
      <source>Policy installation failed. Delete VPN policies from settings and try again.</source>
      <translation variants="no">zh_tw #Policy installation failed. First delete a policy then try again.</translation>
    </message>
    <message numerus="no" id="txt_occ_button_download">
      <source>Download</source>
      <translation variants="no">zh_tw #Download</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_policy_fi">
      <source>Policy installation failed. Policy file error.</source>
      <translation variants="no">zh_tw #Policy installation failed. Policy file error.</translation>
    </message>
    <message numerus="no" id="txt_occ_list_no_vpn_policies_installed">
      <source>No VPN policies installed.</source>
      <translation variants="no">zh_tw #No VPN policies installed</translation>
    </message>
    <message numerus="no" id="txt_occ_incorrect_password">
      <source>Incorrect password</source>
      <translation variants="no">zh_tw #Incorrect password.</translation>
    </message>
    <message numerus="no" id="txt_occ_list_tap_on_a_policy_to_set_a_default">
      <source>Tap on a policy to set a default.</source>
      <translation variants="no">zh_tw #Tap a policy to set it as the default policy:</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_pkcs12_password">
      <source>PKCS#12 password:</source>
      <translation variants="no">zh_tw #PKCS#12 password:</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_password">
      <source>Password:</source>
      <translation variants="no">zh_tw #Password:</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed">
      <source>Policy installation failed</source>
      <translation variants="no">zh_tw #Policy installation failed</translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vpn_button_disconnect_vpn">
      <source>Disconnect VPN</source>
      <translation variants="no">zh_tw #Disconnect VPN</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_vpn_policy_download">
      <source>VPN policy download</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #VPN policy download</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_installing_vpn_policy">
      <source>Installing VPN policy</source>
      <translation variants="no">zh_tw #Installing VPN policy</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn_val_always">
      <source>Always</source>
      <translation variants="no">zh_tw #Always on</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_vpn_user_name">
      <source>VPN user name:</source>
      <translation variants="no">zh_tw #VPN username:</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_download_failed">
      <source>Download failed</source>
      <translation variants="no">zh_tw #Download failed.</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn_val_when_needed">
      <source>When needed</source>
      <translation variants="no">zh_tw #When needed</translation>
    </message>
    <message numerus="no" id="txt_occ_info_downloading_vpn_policy">
      <source>Downloading VPN policy</source>
      <translation variants="no">zh_tw #Downloading VPN policy</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn">
      <source>VPN</source>
      <translation variants="no">zh_tw #VPN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_policy_server_address">
      <source>Policy server address</source>
      <translation variants="no">zh_tw #Policy server address:</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_vpn">
      <source>VPN</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #VPN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_delete_vpn_policy">
      <source>Delete VPN policy '%1'?</source>
      <translation variants="no">zh_tw #Delete VPN policy?
%1</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_service_not_available">
      <source>Policy server not available</source>
      <translation variants="no">zh_tw #Policy server not available.</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_securid_pin">
      <source>SecurID PIN:</source>
      <translation variants="no">zh_tw #SecurID PIN:</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_cert">
      <source>Policy installation failed. Unable to store certificates.</source>
      <translation variants="no">zh_tw #Policy installation failed. Unable to store certificates.</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_vpn_connection">
      <source>VPN connection</source>
      <translation variants="no">zh_tw #VPN connection</translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">zh_tw #Delete</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_ap">
      <source>Policy installation failed. Unable to create VPN access point.</source>
      <translation variants="no">zh_tw #Policy installation failed. Unable to create VPN access point.</translation>
    </message>
  </context>
</TS>