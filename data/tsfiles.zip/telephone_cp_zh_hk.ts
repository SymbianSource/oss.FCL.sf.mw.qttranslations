<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_setlabel_if_not_answered">
      <source>If not answered</source>
      <translation variants="no">如無人接聽</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_ask_first">
      <source>Ask first</source>
      <translation variants="no">先詢問</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_video_call_settings">
      <source>Video call settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">視像電話設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting_val_on">
      <source>On</source>
      <translation variants="no">已啟動</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting">
      <source>Call waiting</source>
      <translation variants="no">來電等候</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_val_line_2">
      <source>Line 2</source>
      <translation variants="no">線路號碼2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_out_of_reach">
      <source>If out of reach</source>
      <translation variants="no">如超出通訊範圍</translation>
    </message>
    <message numerus="no" id="txt_phone_list_incoming_calls">
      <source>Incoming calls</source>
      <translation variants="no">來電</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_send_my_caller_id">
      <source>Send my caller id</source>
      <translation variants="no">傳送我的本機號碼</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_delay">
      <source>Delay</source>
      <translation variants="no">zh_hk #Delay</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking">
      <source>Phone line blocking</source>
      <translation variants="no">線路號碼更換</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_barring">
      <source>Call barring</source>
      <translation variants="yes">
        <lengthvariant priority="1">通話限制</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_val_user_defined">
      <source>User defined</source>
      <translation variants="no">用戶自定義</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_ip_mbx">
      <source>%1 mailbox</source>
      <translation variants="no">zh_hk #%[]1 mailbox</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_voice_mbx_line_2">
      <source>Voice mailbox line 2</source>
      <translation variants="no">留言信箱線路號碼2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_voice_mbx">
      <source>Voice mailbox</source>
      <translation variants="no">留言信箱</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_val_line_1">
      <source>Line 1</source>
      <translation variants="no">線路號碼1</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_no">
      <source>No</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting_val_off">
      <source>Off</source>
      <translation variants="no">未啟動</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx">
      <source>Default mailbox</source>
      <translation variants="no">預設</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking_val_off">
      <source>Off</source>
      <translation variants="no">停用</translation>
    </message>
    <message numerus="no" id="txt_phone_list_incoming_call_when_abroad">
      <source>Incoming call when abroad</source>
      <translation variants="no">漫遊時限制來電</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking_val_on">
      <source>On</source>
      <translation variants="no">啟用</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_busy">
      <source>If busy</source>
      <translation variants="no">如線路繁忙</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_settings">
      <source>Call settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">通話設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_mbx">
      <source>Call mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">通話郵箱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_list_international_calls">
      <source>International calls</source>
      <translation variants="no">國際電話</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_received_call">
      <source>Own video in received call</source>
      <translation variants="no">來電時我的視像</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_ip">
      <source>Not specified</source>
      <translation variants="no">zh_hk #%1</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_call">
      <source>Image in video call</source>
      <translation variants="no">視像電話中的圖像</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_soft_reject_val_default_text">
      <source>Hi, I’m busy at the moment, but I contact you a bit later.</source>
      <translation variants="no">zh_hk #Hi, I’m busy at the moment, but I contact you a bit later.</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_not_available">
      <source>If not available</source>
      <translation variants="no">如無法接通</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_default">
      <source>Default</source>
      <translation variants="no">由網絡設定</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service_val_video_divert">
      <source>Video divert</source>
      <translation variants="no">視像電話轉接</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_voice">
      <source>Voice</source>
      <translation variants="no">留言信箱</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als">
      <source>Phone line in use</source>
      <translation variants="no">使用中的線路號碼</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting">
      <source>Internet call waiting</source>
      <translation variants="no">互聯網通話等候中</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_voice_line_2">
      <source>Voice line 2</source>
      <translation variants="no">語音線路號碼2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service">
      <source>Service</source>
      <translation variants="no">服務</translation>
    </message>
    <message numerus="no" id="txt_phone_info_current_password">
      <source>Current password</source>
      <translation variants="no">目前密碼：</translation>
    </message>
    <message numerus="no" id="txt_phone_info_password_changed">
      <source>Password changed</source>
      <translation variants="no">密碼已更換</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_waiting_activated">
      <source>Call waiting activated</source>
      <translation variants="no">來電等候已啟動</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_waiting_deactivated">
      <source>Call waiting deactivated</source>
      <translation variants="no">來電等候已關閉</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_rejected">
      <source>Request rejected</source>
      <translation variants="no">要求被拒絕</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_not_confirmed">
      <source>Request not confirmed</source>
      <translation variants="no">要求未確認</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_deactivated">
      <source>Barring deactivated</source>
      <translation variants="no">通話限制已關閉</translation>
    </message>
    <message numerus="no" id="txt_phone_info_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">不允許</translation>
    </message>
    <message numerus="no" id="txt_phone_info_requesting">
      <source>Requesting</source>
      <translation variants="no">要求中</translation>
    </message>
    <message numerus="no" id="txt_phone_info_result_unknown">
      <source>Result unknown</source>
      <translation variants="no">未知結果</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_operation_not_successful">
      <source>Barring operation not successful. Contact your service provider</source>
      <translation variants="no">通話限制作業不成功。請聯絡服務供應商。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_new_password">
      <source>New password</source>
      <translation variants="no">新密碼：</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_activated">
      <source>Barring activated</source>
      <translation variants="no">通話限制已啟動</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_not_completed">
      <source>Request not completed</source>
      <translation variants="no">要求未完成</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_password">
      <source>Barring password</source>
      <translation variants="no">通話限制密碼：</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_lost_select_network">
      <source>Network lost. Select network?</source>
      <translation variants="no">zh_hk #Network lost. Select network?</translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">zh_hk #Invalid phone number</translation>
    </message>
    <message numerus="no" id="txt_phone_list_to_voice_mailbox">
      <source>To voice mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #To voice mailbox</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_list_enter_number_manually">
      <source>Enter number manually</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Enter number manually</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_number">
      <source>Number:</source>
      <translation variants="no">zh_hk #Number:</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_out_of_reach">
      <source>If out of reach:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #If out of reach:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_diverts_activated">
      <source>Diverts activated</source>
      <translation variants="no">zh_hk #Diverts activated</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_not_available">
      <source>If not available:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #If not available:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_title_all_calls">
      <source>All calls:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #All calls:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_not_answered">
      <source>If not answered:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #If not answered:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_dont_show">
      <source>Don't show</source>
      <translation variants="no">不要再顯示</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_available_in_current_lo">
      <source>Service not available in current location</source>
      <translation variants="no">服務在目前的方位無法使用</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_on">
      <source>On</source>
      <translation variants="no">已啟動</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service_val_voice_divert">
      <source>Voice divert</source>
      <translation variants="no">語音通話轉接</translation>
    </message>
    <message numerus="no" id="txt_phone_info_verify_new_password">
      <source>Verify new password</source>
      <translation variants="no">確認新密碼：</translation>
    </message>
    <message numerus="no" id="txt_phone_info_divert_activated">
      <source>Divert activated</source>
      <translation variants="no">來電轉接已啟動</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_val_none">
      <source>None</source>
      <translation variants="no">無</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_edit_barring_password">
      <source>Edit barring password</source>
      <translation variants="no">修改通話限制密碼</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_all_calls">
      <source>All calls</source>
      <translation variants="no">所有來電</translation>
    </message>
    <message numerus="no" id="txt_phone_list_international_calls_except_to_home">
      <source>International calls except to home country</source>
      <translation variants="no">本國外的國際電話</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_video">
      <source>Video</source>
      <translation variants="no">視像郵箱</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_divert">
      <source>Call divert</source>
      <translation variants="yes">
        <lengthvariant priority="1">來電轉接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_yes">
      <source>Yes</source>
      <translation variants="no">是</translation>
    </message>
    <message numerus="no" id="txt_phone_list_outgoing_calls">
      <source>Outgoing calls</source>
      <translation variants="no">撥出電話</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_show_automatic">
      <source>Show automatically</source>
      <translation variants="no">自動顯示</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_soft_reject">
      <source>Reject call with message</source>
      <translation variants="no">以訊息拒絕來電</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_video_mbx">
      <source>Video mailbox</source>
      <translation variants="no">視像郵箱</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_off">
      <source>Off</source>
      <translation variants="no">未啟動</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conflict_error">
      <source>Conflict error</source>
      <translation variants="no">衝突錯誤</translation>
    </message>
    <message numerus="no" id="txt_phone_info_divert_deactivated">
      <source>Divert deactivated</source>
      <translation variants="no">來電轉接已關閉</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_edit_barring_password_val_edit">
      <source>Edit</source>
      <translation variants="no">修改</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_password_blocked">
      <source>Barring password blocked</source>
      <translation variants="no">限制密碼已鎖</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_busy">
      <source>If busy:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #If busy:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_diverts_deactivated">
      <source>Diverts deactivated</source>
      <translation variants="no">zh_hk #Diverts deactivated</translation>
    </message>
  </context>
</TS>