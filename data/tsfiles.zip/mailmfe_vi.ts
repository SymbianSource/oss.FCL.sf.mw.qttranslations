<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailmfe_list_version_l1">
      <source>Version: %[]1</source>
      <translation variants="no">vi #Version: %[512]1</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_calendar">
      <source>Calendar</source>
      <translation variants="no">Lịch</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_1_month_back">
      <source>1 month back</source>
      <translation variants="no">1 tháng</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_username">
      <source>Username</source>
      <translation variants="no">Tên người dùng</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_my_name">
      <source>My name</source>
      <translation variants="no">Tên tôi</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_password">
      <source>Password</source>
      <translation variants="no">Mật khẩu</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_3_days_back">
      <source>3 days back</source>
      <translation variants="no">3 ngày</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_show_mail_in_other_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">H.thị e-mail trg thư mục khác</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_1_week_back">
      <source>1 week back</source>
      <translation variants="no">1 tuần</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_fri">
      <source>Fri</source>
      <translation variants="no">Thứ Sáu</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_as_defined">
      <source>The mailbox is refreshed as defined by the user</source>
      <translation variants="no">Nội dung hộp thư được làm mới theo xác định của người dùng</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_every_15_mi">
      <source>The mailbox is refreshed every 15 minutes during daytime</source>
      <translation variants="no">Nội dung hộp thư được làm mới mỗi 15 phút trong ngày</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_secure_connection">
      <source>Secure connection</source>
      <translation variants="no">Kết nối an toàn</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_tasks">
      <source>Tasks</source>
      <translation variants="no">Ghi chú công việc</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_refreshed_only_by_use">
      <source>The mailbox is refreshed only by user request</source>
      <translation variants="no">Nội dung hộp thư chỉ được làm mới khi người dùng bắt đầu</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_server_info">
      <source>Server info</source>
      <translation variants="no">Cài đặt máy chủ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_day_end_time">
      <source>Day end time</source>
      <translation variants="no">Thời gian kết thúc ngày</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_during_daytime_val_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_receiving_schedule">
      <source>Receiving Schedule</source>
      <translation variants="no">Lịch biểu tải</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_preferences">
      <source>Preferences</source>
      <translation variants="no">Cài đặt tài khoản</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_contacts">
      <source>Contacts</source>
      <translation variants="no">Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="no">Mỗi 4 giờ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">Làm mới hộp thư</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_keep_uptodat">
      <source>Keep up-to-date</source>
      <translation variants="no">Luôn cập nhật</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_sun">
      <source>Sun</source>
      <translation variants="no">Chủ Nhật</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_receiving_weekdays">
      <source>Receiving weekdays</source>
      <translation variants="no">Số ngày tải</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_every_day">
      <source>Every day</source>
      <translation variants="no">Mỗi ngày</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_user_defined">
      <source>User defined</source>
      <translation variants="no">Người dùng xác định</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_connection">
      <source>Connection</source>
      <translation variants="no">Kết nối</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_3_months_back">
      <source>3 months back</source>
      <translation variants="no">3 tháng</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_tue">
      <source>Tue</source>
      <translation variants="no">Thứ Ba</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_6_months_back">
      <source>6 months back</source>
      <translation variants="no">6 tháng</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_day_start_time">
      <source>Day start time</source>
      <translation variants="no">Thời gian bắt đầu ngày</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_button_delete_mailbox">
      <source>Delete mailbox</source>
      <translation variants="no">Xóa hộp thư</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_port">
      <source>Port</source>
      <translation variants="no">Cổng</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_notes">
      <source>Notes</source>
      <translation variants="no">Ghi chú</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_fetch_manually">
      <source>Fetch manually</source>
      <translation variants="no">Tải e-mail thủ công</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode">
      <source>Selected mode</source>
      <translation variants="no">Làm mới t.chọn đang s.dụng</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_mailbox_name">
      <source>Mailbox name</source>
      <translation variants="no">Tên hộp thư</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_keep_uptodate">
      <source>Keep up-to-date</source>
      <translation variants="no">Luôn cập nhật</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">Địa chỉ e-mail</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_refresh_during_daytime_val_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_server">
      <source>Server</source>
      <translation variants="no">Máy chủ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_received_items">
      <source>Received items</source>
      <translation variants="no">Các mục cần đồng bộ</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_sat">
      <source>Sat</source>
      <translation variants="no">Thứ Bảy</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_1_hour">
      <source>Every 1 hour</source>
      <translation variants="no">vi #Every 1 hour</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_mon">
      <source>Mon</source>
      <translation variants="no">Thứ Hai</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_subhead_user_info">
      <source>User info</source>
      <translation variants="no">Cài đặt người dùng</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_thu">
      <source>Thu</source>
      <translation variants="no">Thứ Năm</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_show_mail_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">H.thị e-mail trong h.thư đến</translation>
    </message>
    <message numerus="no" id="txt_mailnmfe_setlabel_signature">
      <source>Signature</source>
      <translation variants="no">vi #Signature</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_domain">
      <source>Domain</source>
      <translation variants="no">Tên miền</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_selected_mode_val_save_energy">
      <source>Save energy</source>
      <translation variants="no">Tiết kiệm pin</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_mail">
      <source>Mail</source>
      <translation variants="no">E-mail</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_list_the_mailbox_is_uptodate_during_day">
      <source>The mailbox is up-to-date during daytime</source>
      <translation variants="no">Nội dung hộp thư được cập nhật trong ngày</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="no">Mỗi 15 phút</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_download_images_val_wed">
      <source>Wed</source>
      <translation variants="no">Thứ Tư</translation>
    </message>
    <message numerus="no" id="txt_mailmfe_setlabel_val_when_i_open_mailbox">
      <source>When I open mailbox</source>
      <translation variants="no">Khi tôi mở hộp thư</translation>
    </message>
  </context>
</TS>