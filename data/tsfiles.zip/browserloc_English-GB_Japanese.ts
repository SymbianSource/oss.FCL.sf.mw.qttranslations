<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="en_x_jp">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_browser_error_dialog_close_some">
      <source>Close some browser windows or applications.</source>
      <translation variants="no">Close some browser windows or applications.</translation>
    </message>
    <message numerus="no" id="txt_long_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">Browser</translation>
    </message>
    <message numerus="no" id="txt_browser_tag_error_tag_file_could_not_be_downloaded">
      <source>Error: %1 could not be downloaded</source>
      <translation variants="no">Unable to download '%[99]1'</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_save_forms_passwords">
      <source>Save Forms/Passwords</source>
      <translation variants="no">Save forms and passwords</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding_unicode">
      <source>Unicode</source>
      <translation variants="no">Unicode</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_about">
      <source>About Browser</source>
      <translation variants="no">About Browser</translation>
    </message>
    <message numerus="no" id="txt_browser_offline">
      <source>Offline</source>
      <translation variants="no">Offline</translation>
    </message>
    <message numerus="no" id="txt_browser_input_dial_add_bm">
      <source>Add Bookmark</source>
      <translation variants="no">Add bookmark</translation>
    </message>
    <message numerus="no" id="txt_browser_history_this_week">
      <source>This Week</source>
      <translation variants="no">This week</translation>
    </message>
    <message numerus="no" id="txt_browser_history_delete_are_you_sure">
      <source>Are you sure you want to permanently delete your history?</source>
      <translation variants="no">Permanently delete history?</translation>
    </message>
    <message numerus="no" id="txt_browser_error_generic_error_msg">
      <source>Network error</source>
      <translation variants="no">Network error</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_page">
      <source>Page</source>
      <translation variants="no">Page</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_settings">
      <source>Settings</source>
      <translation variants="no">Settings</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">Bookmarks</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_browser">
      <source>Browser</source>
      <translation variants="no">Browser</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_cancel">
      <source>Cancel</source>
      <translation variants="no">Cancel</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection_no">
      <source>No</source>
      <translation variants="no">No</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_navigation">
      <source>Navigation</source>
      <translation variants="no">Navigation</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_all">
      <source>Clear All</source>
      <translation variants="no">Clear all</translation>
    </message>
    <message numerus="no" id="txt_short_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">Browser</translation>
    </message>
    <message numerus="no" id="txt_browser_windows_new_window">
      <source>New Window</source>
      <translation variants="no">New window</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding_automatic">
      <source>Automatic</source>
      <translation variants="no">Automatic</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings">
      <source>General Settings</source>
      <translation variants="no">General settings</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_cookies">
      <source>Cookies</source>
      <translation variants="no">Cookies</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data">
      <source>Clear Data</source>
      <translation variants="no">Clear data</translation>
    </message>
    <message numerus="no" id="txt_browser_input_dial_edit_bm">
      <source>Edit Bookmark</source>
      <translation variants="no">Edit bookmark</translation>
    </message>
    <message numerus="no" id="txt_browser_history_today">
      <source>Today</source>
      <translation variants="no">Today</translation>
    </message>
    <message numerus="no" id="txt_browser_downloading_file">
      <source>Downloading %1</source>
      <translation variants="no">Downloading %1</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_link_image">
      <source>Link/Image</source>
      <translation variants="no">Image-links</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_block_popups">
      <source>Block Popups</source>
      <translation variants="no">Block pop-ups</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_windows">
      <source>Windows</source>
      <translation variants="no">Windows</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_exit">
      <source>Exit Browser</source>
      <translation variants="no">Exit Browser</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">Bookmarks</translation>
    </message>
    <message numerus="no" id="txt_browser_most_visited_title_most_visited">
      <source>Most Visited</source>
      <translation variants="no">Most visited</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_share">
      <source>Share</source>
      <translation variants="no">Share</translation>
    </message>
    <message numerus="no" id="txt_browser_error_dialog_device_low">
      <source>Device Low On Memory</source>
      <translation variants="no">Device memory low.</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">Browser</translation>
    </message>
    <message numerus="no" id="txt_browser_windows_windows">
      <source>Windows</source>
      <translation variants="no">Windows</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_settings">
      <source>Settings</source>
      <translation variants="no">Settings</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_save_browser_history">
      <source>Save Browser History</source>
      <translation variants="no">Save history</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_form_data">
      <source>Form Data</source>
      <translation variants="no">Form data</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">Bookmarks</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection">
      <source>%1 is now in range.  Switch connection?</source>
      <translation variants="no">%[99]1 now in range. Switch connection?</translation>
    </message>
    <message numerus="no" id="txt_browser_history_yesterday">
      <source>Yesterday</source>
      <translation variants="no">Yesterday</translation>
    </message>
    <message numerus="no" id="txt_browser_history_this_month">
      <source>This Month</source>
      <translation variants="no">This month</translation>
    </message>
    <message numerus="no" id="txt_browser_file_has_finished_downloading">
      <source>%1 has finished downloading</source>
      <translation variants="no">Download finished: %1</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_image">
      <source>Image</source>
      <translation variants="no">Image</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_add_bookmark">
      <source>Add Bookmark</source>
      <translation variants="no">Add bookmark</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_history">
      <source>History</source>
      <translation variants="no">History</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_link_open_link">
      <source>Open Link in New Window</source>
      <translation variants="no">Open link in new window</translation>
    </message>
    <message numerus="no" id="txt_browser_chrome_suggests_search_for">
      <source>Search for %1</source>
      <translation variants="no">Search for %1</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_link_share_link">
      <source>Share Link</source>
      <translation variants="no">Share link</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_yes">
      <source>Yes</source>
      <translation variants="no">Yes</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_no">
      <source>No</source>
      <translation variants="no">No</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_history">
      <source>History</source>
      <translation variants="no">History</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding">
      <source>Character Encoding</source>
      <translation variants="no">Character encoding</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_cache">
      <source>Cache</source>
      <translation variants="no">Cache</translation>
    </message>
    <message numerus="no" id="txt_browser_history_history">
      <source>History</source>
      <translation variants="no">History</translation>
    </message>
    <message numerus="no" id="txt_browser_error_page_load_failed">
      <source>Unable to load page</source>
      <translation variants="no">Unable to load page</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_new_window">
      <source>New Window</source>
      <translation variants="no">New window</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_link">
      <source>Link</source>
      <translation variants="no">Link</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_allow_popups">
      <source>Allow Pop-ups</source>
      <translation variants="no">Allow pop-ups</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_image_save_image">
      <source>Save Image</source>
      <translation variants="no">Save image</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_done">
      <source>Done</source>
      <translation variants="no">Done</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection_yes">
      <source>Yes</source>
      <translation variants="no">Yes</translation>
    </message>
  </context>
</TS>