<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_operator_widget_title_select_info">
      <source>Select info</source>
      <translation variants="no">معلومات منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_long_caption_operator_widget">
      <source>Operator widget</source>
      <translation variants="no">ur #Operator widget</translation>
    </message>
    <message numerus="no" id="txt_long_caption_operator _widget">
      <source>Operator widget</source>
      <translation variants="no">ur ##Operator widget</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_list_spn">
      <source>Service provider name</source>
      <translation variants="no">خدمت فراہم کار کا نام</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_info_select_one">
      <source>Select at least one item</source>
      <translation variants="no">کم از کم ایک آئیٹم منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_list_show_homezone">
      <source>Show Homezone</source>
      <translation variants="no">ur #Show Homezone</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_list_cell_information">
      <source>Cell information</source>
      <translation variants="no">سیل معلومات</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_list_sat_idle_mode_text">
      <source>SAT idle mode text</source>
      <translation variants="no">SIM خدمات کا متن</translation>
    </message>
    <message numerus="no" id="txt_operatorwidget_list_line_in_use">
      <source>Line in use</source>
      <translation variants="no">ur #Line in use</translation>
    </message>
  </context>
</TS>