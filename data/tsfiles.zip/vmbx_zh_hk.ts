<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_caption_voice_mailbox">
      <source>Voice mailbox</source>
      <translation variants="no">zh_hk ##Voice mailbox</translation>
    </message>
    <message numerus="yes" id="txt_vmbx_dblist_ln_voice_messages">
      <source>%Ln voice messages</source>
      <translation>
        <numerusform plurality="a">%Ln語音訊息</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_vmbx_dpopinfo_ln_voice_messages">
      <source>%Ln new voice messages</source>
      <translation>
        <numerusform plurality="a">%Ln則新語音訊息</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_dpopinfo_voice_mailbox_number_saved">
      <source>Voice mailbox number saved</source>
      <translation variants="no">留言信箱號碼已儲存</translation>
    </message>
    <message numerus="no" id="txt_vmbx_dpopinfo_define_video_mailbox_number">
      <source>Define video mailbox number</source>
      <translation variants="no">定義視像郵箱號碼</translation>
    </message>
    <message numerus="no" id="txt_vmbx_dpopinfo_video_mailbox_number_saved">
      <source>Video mailbox number saved</source>
      <translation variants="no">視像郵箱號碼已儲存</translation>
    </message>
    <message numerus="no" id="txt_vmbx_dpopinfo_define_voice_mailbox_number">
      <source>Define voice mailbox number</source>
      <translation variants="no">定義留言信箱號碼</translation>
    </message>
    <message numerus="no" id="txt_vmbx_title_select_mailbox">
      <source>Select mailbox:</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇郵箱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_title_voice_mailbox_number">
      <source>Voice mailbox number:</source>
      <translation variants="yes">
        <lengthvariant priority="1">留言信箱號碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_dpopinfo_voice_mailbox_not_provisioned">
      <source>Voice mailbox not provisioned</source>
      <translation variants="no">留言信箱號碼未定義</translation>
    </message>
    <message numerus="no" id="txt_vmbx_list_voice_mailbox">
      <source>Voice mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">留言信箱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_title_video_mailbox_number">
      <source>Video mailbox number:</source>
      <translation variants="yes">
        <lengthvariant priority="1">視像郵箱號碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_list_video_mailbox">
      <source>Video mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">視像郵箱</lengthvariant>
      </translation>
    </message>
  </context>
</TS>