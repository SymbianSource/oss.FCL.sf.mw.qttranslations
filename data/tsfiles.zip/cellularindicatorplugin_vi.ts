<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dblist_cellular_data_val_1_connected">
      <source>'%1' connected</source>
      <translation variants="no">vi ##'%1' connected</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_cellular_data_val_l1_connections">
      <source>%L1 connections</source>
      <translation variants="no">vi ##%L1 connections</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_cellular_data">
      <source>Cellular data</source>
      <translation variants="no">vi ##Cellular data</translation>
    </message>
  </context>
</TS>