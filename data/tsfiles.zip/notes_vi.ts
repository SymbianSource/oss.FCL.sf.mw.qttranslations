<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_notes_dblist_val_completed_on_1">
      <source>Completed on %1</source>
      <translation variants="no">vi #Completed on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">vi #Mark as done</translation>
    </message>
    <message numerus="no" id="txt_notes_list_todos">
      <source>To-do's</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #To-do notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_menu_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="no">vi #Change to to-do note</translation>
    </message>
    <message numerus="no" id="txt_notes_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">vi #Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">vi #Discard changes</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">vi #Remove from favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="no">vi #Add to favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">vi #Due on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="no">vi #Change to to-do note</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="no">vi #Add to favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_title_notes">
      <source>Notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời gian phát âm báo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã hoàn tất vào:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_alarm_date">
      <source>%2</source>
      <translation variants="no">%2</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_notes">
      <source>Notes</source>
      <translation variants="no">vi ##Notes</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chưa đặt tên</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_moved_to_todos">
      <source>Note moved to To-do's</source>
      <translation variants="no">Đã chuyển ghi chú vào d.sách ghi chú công việc</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_at_time">
      <source>Modified at %1</source>
      <translation variants="no">Đã sửa đổi lúc %1</translation>
    </message>
    <message numerus="no" id="txt_notes_list_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mục ưa thích</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_edit_time">
      <source>%1 %2</source>
      <translation variants="no">vi ##%1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_list_alarm_date">
      <source>%1 %2</source>
      <translation variants="no">%[11]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_title_due_date">
      <source>Due date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày hết hạn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_new_note">
      <source>New note</source>
      <translation variants="no">Ghi chú mới</translation>
    </message>
    <message numerus="no" id="txt_notes_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày phát âm báo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_completed_date_val_1">
      <source>%1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_on_date">
      <source>Created on %1</source>
      <translation variants="no">Đã tạo vào %1</translation>
    </message>
    <message numerus="no" id="txt_notes_button_alarm_time">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_todo_note_saved">
      <source>To-do note saved</source>
      <translation variants="no">Đã lưu lại ghi chú công việc</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">Xóa mô tả</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_saved">
      <source>Note saved</source>
      <translation variants="no">Đã lưu lại ghi chú</translation>
    </message>
    <message numerus="no" id="txt_notes_list_due_date">
      <source>%1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_list_note_count">
      <source>[ %1 ]</source>
      <translation variants="no">[ %[24]1 ]</translation>
    </message>
    <message numerus="no" id="txt_notes_button_new_todo">
      <source>New To-do </source>
      <translation variants="yes">
        <lengthvariant priority="1">Công việc mới</lengthvariant>
        <lengthvariant priority="2">vi #New to-do note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_high">
      <source>High</source>
      <translation variants="no">Cao</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mô tả:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_collections">
      <source>Collections</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bộ sưu tập</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_subject">
      <source>Subject:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chủ đề:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority">
      <source>Priority</source>
      <translation variants="no">Ưu tiên:</translation>
    </message>
    <message numerus="no" id="txt_notes_button_all_notes">
      <source>All notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tất cả ghi chú</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_list_plain_notes">
      <source>Plain notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú đơn giản</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_notes">
      <source>Notes</source>
      <translation variants="no">Ghi chú</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_notes">
      <source>Delete notes?</source>
      <translation variants="no">Xóa ghi chú?</translation>
    </message>
    <message numerus="yes" id="txt_notes_subhead_todos_ln_pending">
      <source>To-do's (%Ln Pending )</source>
      <translation>
        <numerusform plurality="a">Ghi chú công việc (%Ln đang chờ xử lý)</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_created_on_1_2">
      <source>Created on %1 %2</source>
      <translation variants="no">Đã tạo vào %[08]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">Ngày kết thúc:</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">Đánh dấu chưa xong</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_new_note_saved">
      <source>New note saved</source>
      <translation variants="no">Đã lưu lại ghi chú mới</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_new_todo">
      <source>New To-do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú công việc mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_on_date">
      <source>Modified on %1</source>
      <translation variants="no">Đã sửa đổi vào %1</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_add_to_calendar">
      <source>Add to Calendar</source>
      <translation variants="no">Thêm vào Lịch</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">Âm báo</translation>
    </message>
    <message numerus="no" id="txt_short_caption_notes">
      <source>Notes</source>
      <translation variants="no">vi #Notes</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_todo">
      <source>To-do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú công việc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_low">
      <source>Low</source>
      <translation variants="no">Thấp</translation>
    </message>
    <message numerus="no" id="txt_notes_button_dialog_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">vi #Remove from favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_modified_on_1_2">
      <source>Modified on %1 %2</source>
      <translation variants="no">Đã sửa đổi vào %[07]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_note">
      <source>Delete note?</source>
      <translation variants="no">Xóa ghi chú?</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mục ưa thích</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_normal">
      <source>Normal</source>
      <translation variants="no">Bình thường</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="no">Ngày giờ phát âm báo:</translation>
    </message>
    <message numerus="no" id="txt_notes_button_add_to_calendar">
      <source>Add to Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Save to Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_find">
      <source>Find</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tìm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_new_note">
      <source>New note</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_due_date">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_plain_notes">
      <source>Plain notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú đơn giản</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_notes">
      <source>Delete To-do notes?</source>
      <translation variants="no">Xóa ghi chú công việc?</translation>
    </message>
    <message numerus="no" id="txt_notes_button_edit">
      <source>Edit</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_new_todo_note_saved">
      <source>New To-do note saved</source>
      <translation variants="no">Đã lưu lại ghi chú công việc mới</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_val_description">
      <source>Description</source>
      <translation variants="no">Mô tả</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">Chủ đề</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_at_time">
      <source>Created at %1</source>
      <translation variants="no">Đã tạo lúc %1</translation>
    </message>
    <message numerus="yes" id="txt_notes_subhead_ln_notes">
      <source>%Ln Notes</source>
      <translation>
        <numerusform plurality="a">%Ln ghi chú</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_add_description">
      <source>Add description</source>
      <translation variants="no">Thêm mô tả:</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">Xóa ghi chú công việc?</translation>
    </message>
    <message numerus="no" id="txt_notes_list_no_notes_available">
      <source>No notes available</source>
      <translation variants="no">vi ##No notes available</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chưa đặt tên</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Đánh dấu xong</translation>
    </message>
  </context>
</TS>