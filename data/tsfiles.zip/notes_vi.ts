<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_notes_menu_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="no">vi #Change to to-do note</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">vi #Remove from favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">vi #Due on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="no">vi #Add to favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_list_todos">
      <source>To-do's</source>
      <translation variants="no">vi #To-do notes</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">vi #Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_notes_title_notes">
      <source>Notes</source>
      <translation variants="no">vi #Notes</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">vi #Mark as done</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_completed_on_1">
      <source>Completed on %1</source>
      <translation variants="no">vi #Completed on %1</translation>
    </message>
    <message numerus="no" id="txt_long_caption_notes">
      <source>Notes</source>
      <translation variants="no">Ghi chú</translation>
    </message>
    <message numerus="no" id="txt_notes_list_due_date">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_notes_button_new_todo">
      <source>New To-do </source>
      <translation variants="no">Công việc mới</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_new_note">
      <source>New note</source>
      <translation variants="no">Ghi chú mới</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_at_time">
      <source>Modified at %1</source>
      <translation variants="no">Đã sửa đổi lúc %1</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_created_on_1_2">
      <source>Created on %1 %2</source>
      <translation variants="no">Đã tạo vào %[08]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_at_time">
      <source>Created at %1</source>
      <translation variants="no">Đã tạo lúc %1</translation>
    </message>
    <message numerus="yes" id="txt_notes_subhead_ln_notes">
      <source>%Ln Notes</source>
      <translation>
        <numerusform plurality="a">%Ln ghi chú</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_description">
      <source>Description:</source>
      <translation variants="no">Mô tả:</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_subject">
      <source>Subject:</source>
      <translation variants="no">Chủ đề:</translation>
    </message>
    <message numerus="no" id="txt_notes_list_note_count">
      <source>[ %1 ]</source>
      <translation variants="no">[ %[24]1 ]</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_completed_date_val_1">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">Đánh dấu chưa xong</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="no">Đã hoàn tất vào:</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_plain_notes">
      <source>Plain notes</source>
      <translation variants="no">Ghi chú đơn giản</translation>
    </message>
    <message numerus="no" id="txt_notes_list_favorites">
      <source>Favorites</source>
      <translation variants="no">Mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_note">
      <source>Delete note?</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa ghi chú?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa ghi chú công việc?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_list_no_notes_available">
      <source>No notes available</source>
      <translation variants="no">vi #(no notes)</translation>
    </message>
    <message numerus="no" id="txt_notes_list_plain_notes">
      <source>Plain notes</source>
      <translation variants="no">Ghi chú đơn giản</translation>
    </message>
    <message numerus="no" id="txt_notes_list_alarm_date">
      <source>%1 %2</source>
      <translation variants="no">%[11]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_on_date">
      <source>Created on %1</source>
      <translation variants="no">Đã tạo vào %1</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_notes">
      <source>Delete To-do notes?</source>
      <translation variants="no">Xóa ghi chú công việc?</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_notes">
      <source>Notes</source>
      <translation variants="no">vi #Notes</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_modified_on_1_2">
      <source>Modified on %1 %2</source>
      <translation variants="no">Đã sửa đổi vào %[07]1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_notes">
      <source>Delete notes?</source>
      <translation variants="no">Xóa ghi chú?</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_favorites">
      <source>Favorites</source>
      <translation variants="no">Mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="no">Chưa đặt tên</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Đánh dấu xong</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_on_date">
      <source>Modified on %1</source>
      <translation variants="no">Đã sửa đổi vào %1</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="no">Chưa đặt tên</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_moved_to_todos">
      <source>Note moved to To-do's</source>
      <translation variants="no">Đã chuyển ghi chú vào d.sách ghi chú công việc</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_removed_from_favorites">
      <source>Removed from favorites</source>
      <translation variants="no">Đã xóa khỏi mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_todos">
      <source>To-do's</source>
      <translation variants="no">Ghi chú công việc</translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">vi #Open</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="no">vi #Cancel</translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_item">
      <source>Send</source>
      <translation variants="no">vi #Send</translation>
    </message>
    <message numerus="no" id="txt_common_button_delete">
      <source>Delete</source>
      <translation variants="no">vi #Delete</translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">vi #Delete</translation>
    </message>
    <message numerus="no" id="txt_common_menu_edit">
      <source>Edit</source>
      <translation variants="no">vi #Edit</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>Ok</source>
      <translation variants="no">vi #OK</translation>
    </message>
  </context>
</TS>