<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_fmgr_menu_eject">
      <source>Eject</source>
      <translation variants="no">移除</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_usb_memory">
      <source>%1 USB memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1大容量儲存裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_gb">
      <source>Free: %L1 GB</source>
      <translation variants="yes">
        <lengthvariant priority="1">可用：%L1 GB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_size_file">
      <source>Size:</source>
      <translation variants="no">大小：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_remove_password">
      <source>Remove password</source>
      <translation variants="no">移除密碼</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_free_memory">
      <source>Free:</source>
      <translation variants="no">可用：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_set_password">
      <source>Set password</source>
      <translation variants="no">設定密碼</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1記憶卡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_name">
      <source>Name</source>
      <translation variants="no">名稱</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_size_memory">
      <source>Size:</source>
      <translation variants="no">大小：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_type_file">
      <source>Type:</source>
      <translation variants="no">類型：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_free_l1_1">
      <source>Free: %L1 %1</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Free: %L1 %[22]1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_val_size_l1_gb">
      <source>Size: %L1 GB</source>
      <translation variants="yes">
        <lengthvariant priority="1">大小：%L1 GB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1記憶卡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_name_file">
      <source>Name:</source>
      <translation variants="no">名稱：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_mb">
      <source>Free: %L1 MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">可用：%L1 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_file_manager">
      <source>File Manager</source>
      <translation variants="yes">
        <lengthvariant priority="1">檔案管理</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_send">
      <source>Send</source>
      <translation variants="no">傳送</translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_find">
      <source>Find</source>
      <translation variants="no">找尋</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_files">
      <source>Files:</source>
      <translation variants="no">檔案：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_kb">
      <source>Free: %L1 kB</source>
      <translation variants="yes">
        <lengthvariant priority="1">可用：%L1 kB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1大容量儲存裝置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_size_folder">
      <source>Size:</source>
      <translation variants="no">大小：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_delete">
      <source>Delete</source>
      <translation variants="no">刪除</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1大容量儲存裝置</lengthvariant>
        <lengthvariant priority="2">%1大容量儲存</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_view_details_file">
      <source>View details</source>
      <translation variants="no">資料</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_time_file">
      <source>Time:</source>
      <translation variants="no">時間：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_val_size_l1_mb">
      <source>Size: %L1 MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">大小：%L1 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_date_file">
      <source>Date:</source>
      <translation variants="no">日期：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_copy">
      <source>Copy</source>
      <translation variants="no">複製</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_name_folder">
      <source>Name:</source>
      <translation variants="no">名稱：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1裝置記憶體</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_move">
      <source>Move</source>
      <translation variants="no">移動</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_memory_name">
      <source>Memory name:</source>
      <translation variants="no">名稱：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_subfolders">
      <source>Subfolders:</source>
      <translation variants="no">子資料夾：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1裝置記憶體</lengthvariant>
        <lengthvariant priority="2">zh_hk #%1 Device mem.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_file_manager_caption_file_manager">
      <source>File Manager</source>
      <translation variants="no">zh_hk #File manager</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_view_details_memory">
      <source>View details</source>
      <translation variants="no">資料</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_date_folder">
      <source>Date:</source>
      <translation variants="no">日期：</translation>
    </message>
    <message numerus="no" id="txt_file_manager_list_file_manager">
      <source>File Manager</source>
      <translation variants="no">檔案管理</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_rename">
      <source>Rename</source>
      <translation variants="no">重新命名</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_size_l1_1">
      <source>Size: %L1 %1</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Size: %L1 %[22]1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_2">
      <source>%1 %2</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #%[22]1 %[21]2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_memory_details">
      <source>Memory details:</source>
      <translation variants="no">資料：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_2">
      <source>%1 %2</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #%[17]1 %[16]2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_restore">
      <source>Restore</source>
      <translation variants="no">恢復</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_file_details">
      <source>File details:</source>
      <translation variants="no">資料：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_time_folder">
      <source>Time:</source>
      <translation variants="no">時間：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_backup">
      <source>Backup</source>
      <translation variants="no">備份</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_change_password">
      <source>Change password</source>
      <translation variants="no">更換密碼</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_format">
      <source>Format</source>
      <translation variants="no">格式化</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_folder_details">
      <source>Folder details:</source>
      <translation variants="no">資料：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_b">
      <source>Free: %L1 B</source>
      <translation variants="yes">
        <lengthvariant priority="1">可用：%L1 B</lengthvariant>
      </translation>
    </message>
  </context>
</TS>