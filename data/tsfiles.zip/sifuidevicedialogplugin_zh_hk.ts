<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_installer_title_items_to_install">
      <source>Items to install:</source>
      <translation variants="no">要安裝的項目：</translation>
    </message>
    <message numerus="no" id="txt_installer_title_install">
      <source>Install?</source>
      <translation variants="no">是否安裝？</translation>
    </message>
    <message numerus="no" id="txt_installer_list_unknown_language">
      <source>Unknown language</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知的語言</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_installer_list_appname_version">
      <source>%1 (v %2)</source>
      <translation variants="no">%[99]1 (v %[99]2)</translation>
    </message>
    <message numerus="no" id="txt_installer_button_show">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">顯示</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_installer_title_select_language">
      <source>Select language:</source>
      <translation variants="no">選擇語言：</translation>
    </message>
    <message numerus="no" id="txt_installer_info_installation_failed">
      <source>Installation failed</source>
      <translation variants="no">安裝失敗</translation>
    </message>
    <message numerus="no" id="txt_installer_list_appsize_mb">
      <source>%L1 MB</source>
      <translation variants="no">%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_installer_list_appsize_kb">
      <source>%L1 kB</source>
      <translation variants="no">%L1 kB</translation>
    </message>
    <message numerus="no" id="txt_installer_list_appsize_b">
      <source>%L1 B</source>
      <translation variants="no">%L1 B</translation>
    </message>
    <message numerus="no" id="txt_installer_title_installed">
      <source>Installed</source>
      <translation variants="no">已安裝</translation>
    </message>
    <message numerus="no" id="txt_installer_title_installing">
      <source>Installing</source>
      <translation variants="no">安裝中</translation>
    </message>
    <message numerus="no" id="txt_installer_button_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">資料</lengthvariant>
      </translation>
    </message>
  </context>
</TS>