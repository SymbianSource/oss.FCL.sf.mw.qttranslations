<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ro">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_dblist_receiving_files">
      <source>Receiving files</source>
      <translation variants="no">RecepȚionare fiȘiere în curs</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_paired">
      <source>%1 paired</source>
      <translation variants="no">%[14]1 asociat</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="no">Activat (vizibil)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="no">Activat (ascuns)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_computer">
      <source>Computer</source>
      <translation variants="no">Computer</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_phone">
      <source>Phone</source>
      <translation variants="no">Telefon</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="no">Conectat (ascuns)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="no">Dezactivat</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_connected">
      <source>%1 connected</source>
      <translation variants="no">%[13]1 conectat</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_other_device">
      <source>Other device</source>
      <translation variants="no">Alt aparat</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_usign_sim_access_profi">
      <source>usign SIM access profile</source>
      <translation variants="no">Mod SIM la distanȚă</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="no">Conectat (vizibil)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_sending_files">
      <source>Sending files</source>
      <translation variants="no">Expediere fiȘiere în curs</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_audio_device">
      <source>Audio device</source>
      <translation variants="no">Aparat audio</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_input_device">
      <source>Input device</source>
      <translation variants="no">Aparat intrare</translation>
    </message>
  </context>
</TS>