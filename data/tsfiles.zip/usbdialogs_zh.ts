<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dpinfo_headset_in_use">
      <source>headset in use</source>
      <translation variants="no">话务式耳机在使用中</translation>
    </message>
    <message numerus="no" id="txt_usb_info_hubs_are_not_supported_disconnect_us">
      <source>Hubs are not supported. Disconnect device.</source>
      <translation variants="no">集线器不受支持。断开设备连接。</translation>
    </message>
    <message numerus="no" id="txt_usb_info_memory_full_close_some_applications">
      <source>Memory full. Close some applications and try to connect USB cable again.</source>
      <translation variants="no">存储空间已满。先关闭一些应用程序，然后再次连接USB数据线。</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_safe_to_remove">
      <source>Safe to remove</source>
      <translation variants="no">安全地删除</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unsupported_usb_device_disconnect_de">
      <source>Unsupported USB device. Disconnect device.</source>
      <translation variants="no">USB设备不受支持。断开设备连接。</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_media_transfer">
      <source>as media transfer</source>
      <translation variants="no">多媒体传送模式</translation>
    </message>
    <message numerus="no" id="txt_usb_info_partially_supported_usb_device_connec">
      <source>Partially supported USB device connected. All functionality might not work.</source>
      <translation variants="no">部分受支持的USB设备已连接。所有功能可能无法运行。</translation>
    </message>
    <message numerus="no" id="txt_usb_dpophead_usb_disconnected">
      <source>USB disconnected</source>
      <translation variants="no">USB已断开连接</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_show_a_memory_to_other_devi">
      <source>Unable to show a memory to other device.</source>
      <translation variants="no">无法向其他设备显示存储</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_ovi_suite">
      <source>to OVI suite</source>
      <translation variants="no">Nokia Ovi Suite</translation>
    </message>
    <message numerus="no" id="txt_usb_info_disk_full_remove_some_files_and_try">
      <source>Disk full. Remove some files and try connect USB cable again</source>
      <translation variants="no">磁盘已满。删除部分文件后再次连接USB数据线。</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_use_file_system_in_device">
      <source>Unable to use file system in device. Disconnect device.</source>
      <translation variants="no">无法使用设备中的文件系统。断开数据线。</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_mass_storage">
      <source>as mass storage</source>
      <translation variants="no">大容量存储模式</translation>
    </message>
    <message numerus="no" id="txt_usb_info_error_in_usb_connection_disconnect_d">
      <source>Error in USB connection. Disconnect device.</source>
      <translation variants="no">USB连接错误。断开设备连接。</translation>
    </message>
    <message numerus="no" id="txt_usb_info_remove_usb_cable_or_connect_a_device">
      <source>Remove USB cable or connect a device.</source>
      <translation variants="no">拔掉USB数据线或连接设备。</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_phone_as_modem">
      <source>as web connection</source>
      <translation variants="no">连接PC与互联网模式</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_eject_the_usb_device_some">
      <source>Unable to eject the USB device. Some of the applications may still be using it.</source>
      <translation variants="no">无法弹出USB设备。一些应用程序可能仍在使用它。</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unknown_file_system_disconnect_devic">
      <source>Unknown file system. Disconnect device.</source>
      <translation variants="no">未知文件系统。断开设备连接。</translation>
    </message>
    <message numerus="no" id="txt_usb_dpophead_usb_connected">
      <source>USB connected</source>
      <translation variants="no">USB已连接</translation>
    </message>
  </context>
</TS>