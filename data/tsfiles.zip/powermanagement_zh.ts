<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_power_management_dpopinfo_psm_activated_automa">
      <source>Power Save Mode activated</source>
      <translation variants="no">节电模式已开</translation>
    </message>
    <message numerus="no" id="txt_power_setlabel_val_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_dpopinfo_unplug_charger_to_save_energy">
      <source>Unplug charger to save energy</source>
      <translation variants="no">拔掉充电器</translation>
    </message>
    <message numerus="no" id="txt_power_list_activate_power_save_mode_automatica">
      <source>Activate power save mode automatically when low power. Turns off automatically when charger is connected.</source>
      <translation variants="no">电量不足时自动启动节电模式？设备充电时将自动关闭此模式。</translation>
    </message>
    <message numerus="no" id="txt_power_list_activating_power_save_mode_will_con">
      <source>Activating power save mode will consumes minimal power. Turns off all power consuming operations/features like Bluetooth, WLAN, Vibra, Tactile feedback, Key tones, Screensaver, Wallpapers and also dimming screen brightness, Switching Network from 3G to 2G.Turns off automatically when charger is connected.</source>
      <translation variants="no">启动节电模式可延长电池的使用时间。此时所有的非重要功能，如蓝牙、WLAN、触摸屏振动和触觉反馈、按键音和屏幕保护等都将关闭。同时显示屏也变暗，设备开始使用2G网络。设备充电时将自动关闭此模式。</translation>
    </message>
    <message numerus="no" id="txt_power_management_dpophead_100_full">
      <source>100% Full</source>
      <translation variants="no">100%充满</translation>
    </message>
    <message numerus="no" id="txt_power_list_power_save_mode">
      <source>Power Save Mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">节电模式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_management_dpopinfo_low_battery">
      <source>Low Battery</source>
      <translation variants="no">电量不足</translation>
    </message>
    <message numerus="no" id="txt_power_setlabel_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_management_subhead_power_management">
      <source>Power Management</source>
      <translation variants="yes">
        <lengthvariant priority="1">电源管理</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_powermgt_dblist_charging">
      <source>Charging</source>
      <translation variants="no">zh #Charging</translation>
    </message>
  </context>
</TS>