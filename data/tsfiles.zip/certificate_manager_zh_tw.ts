<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_certificate_manager_list_personal_certificates">
      <source>Personal certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Personal certificates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_move_to_personal_cert">
      <source>Move to personal certificates</source>
      <translation variants="no">zh_tw ##Move to personal certificates</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_verify_keystore_pin">
      <source>Verify Keystore PIN:</source>
      <translation variants="no">zh_tw ##Verify Keystore PIN:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_trust_settings">
      <source>Trust settings</source>
      <translation variants="no">zh_tw ##Trust settings</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_keystore_pin">
      <source>Keystore PIN</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Keystore PIN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_authority_certific">
      <source>Authority certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Authority certificates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_info_move">
      <source>Move.......</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Move.......</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_device_certificate">
      <source>Device certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Device certificates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_unable_to_use_priva">
      <source>Unable to use private key. Set keystore PIN:</source>
      <translation variants="no">zh_tw ##Unable to use private key. Set keystore PIN:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_enter_keystore_pin">
      <source>Enter keystore PIN:</source>
      <translation variants="no">zh_tw ##Enter keystore PIN:</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_trusted_site_certific">
      <source>Trusted site certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Trusted site certificates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_setlabel_advanced_security">
      <source>Advanced security</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Advanced security</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_authority_certificate">
      <source>Authority certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Authority certificates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_menu_move_to_device_certif">
      <source>Move to device certificates</source>
      <translation variants="no">zh_tw ##Move to device certificates</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_list_device_certificates">
      <source>Device certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Device certificates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dialog_set">
      <source>Set</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Set</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_setlabel_certificates">
      <source>Certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Certificates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_personal_certifica">
      <source>Personal certificate</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Personal certificate</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_dpopinfo_keystore_pin_does">
      <source>Keystore PIN does not match</source>
      <translation variants="no">zh_tw ##Keystore PIN does not match</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_info_device_certificates_c">
      <source>Device certificates can be used without user confirmation. Use of device lock recommended. Proceed?</source>
      <translation variants="no">zh_tw ##Device certificates can be used without user confirmation. Use of device lock recommended. Proceed?</translation>
    </message>
    <message numerus="no" id="txt_certificate_manager_subhead_trusted_site_certi">
      <source>Trusted site certificates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Trusted site certificates</lengthvariant>
      </translation>
    </message>
  </context>
</TS>