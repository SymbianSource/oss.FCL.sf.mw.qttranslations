<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_notes_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">于%1到期</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">标记为已完成</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_completed_on_1">
      <source>Completed on %1</source>
      <translation variants="no">已于%1完成</translation>
    </message>
    <message numerus="no" id="txt_notes_list_todos">
      <source>To-do's</source>
      <translation variants="yes">
        <lengthvariant priority="1">待办事项</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_menu_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="no">更改为待办事项</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">标记为未完成</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">从收藏夹删除</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="no">加至收藏夹</translation>
    </message>
    <message numerus="no" id="txt_notes_title_notes">
      <source>Notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">记事本</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_notes">
      <source>Notes</source>
      <translation variants="no">记事本</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_at_time">
      <source>Created at %1</source>
      <translation variants="no">于%1创建</translation>
    </message>
    <message numerus="yes" id="txt_notes_subhead_ln_notes">
      <source>%Ln Notes</source>
      <translation>
        <numerusform plurality="a">%Ln条备忘</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_list_note_count">
      <source>[ %1 ]</source>
      <translation variants="no">[ %[24]1 ]</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_todos">
      <source>To-do's</source>
      <translation variants="yes">
        <lengthvariant priority="1">待办事项</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_on_date">
      <source>Created on %1</source>
      <translation variants="no">于%[25]1创建</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_new_todo_note">
      <source>New To-do note</source>
      <translation variants="no">新待办事项</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_new_note">
      <source>New note</source>
      <translation variants="no">新备忘</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_at_time">
      <source>Modified at %1</source>
      <translation variants="no">于%[25]1修改</translation>
    </message>
    <message numerus="no" id="txt_notes_list_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_delete_all">
      <source>Delete all</source>
      <translation variants="no">全部删除</translation>
    </message>
    <message numerus="no" id="txt_notes_list_no_notes">
      <source>No notes</source>
      <translation variants="no">(无备忘)</translation>
    </message>
    <message numerus="no" id="txt_notes_list_plain_notes">
      <source>Plain notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">普通备忘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_all_notes">
      <source>Delete all notes?</source>
      <translation variants="no">删除全部备忘？</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_moved_to_todos">
      <source>Note moved to To-do's</source>
      <translation variants="no">备忘已移至待办事项列表</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">(未命名)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_notes">
      <source>Notes</source>
      <translation variants="no">记事本</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_removed_from_favorites">
      <source>Removed from favorites</source>
      <translation variants="no">已从常用联系人删除</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_on_date">
      <source>Modified on %1</source>
      <translation variants="no">于%[25]1修改</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_notes_count">
      <source>( %1 )</source>
      <translation variants="no">(%[99]1)</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_plain_notes">
      <source>Plain notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">普通备忘</lengthvariant>
      </translation>
    </message>
  </context>
</TS>