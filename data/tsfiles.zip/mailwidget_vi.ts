<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_widget_list_l1">
      <source>(%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_widget_info_no_messages">
      <source>(No messages)</source>
      <translation variants="no">vi #(no messages)</translation>
    </message>
  </context>
</TS>