<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">zh_tw #Delete To-do note?</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_fr">
      <source>Fr</source>
      <translation variants="no">zh_tw #Fr</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_settings">
      <source>Settings</source>
      <translation variants="no">zh_tw #Settings</translation>
    </message>
    <message numerus="no" id="txt_task_switcher_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">zh_tw #Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_main_view">
      <source>Calendar main view</source>
      <translation variants="no">zh_tw #Calendar main view</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_new_event">
      <source>New event</source>
      <translation variants="no">zh_tw #New calendar entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_biweekly">
      <source>Bi-weekly</source>
      <translation variants="no">zh_tw #Fortnightly</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Repeat</source>
      <translation variants="no">zh_tw #Repeat</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_from">
      <source>From</source>
      <translation variants="no">zh_tw #From</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Location</source>
      <translation variants="no">zh_tw #Location</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_attachment">
      <source>Add attachment</source>
      <translation variants="no">zh_tw #Add attachment</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">zh_tw #Repeat until</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_hour">
      <source>Before %Ln hours</source>
      <translation variants="no">zh_tw #%Ln hour before</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_all_entries">
      <source>All entries</source>
      <translation variants="no">zh_tw #All entries</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Yearly</source>
      <translation variants="no">zh_tw #Yearly</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_days">
      <source>Before %Ln days</source>
      <translation variants="no">zh_tw #%Ln day before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Weekly</source>
      <translation variants="no">zh_tw #Weekly</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_daydate">
      <source>&lt;Day&gt;&lt;Date&gt;</source>
      <translation variants="no">zh_tw #Day date</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_description">
      <source>Description</source>
      <translation variants="no">zh_tw #Description</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>End date</source>
      <translation variants="no">zh_tw #End date</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_time">
      <source>&lt;Time&gt;</source>
      <translation variants="no">zh_tw #Time</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_minu">
      <source>Before %Ln minutes</source>
      <translation variants="no">zh_tw #%Ln minute before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Monthly</source>
      <translation variants="no">zh_tw #Monthly</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_daydate">
      <source>&lt;Day&gt;&lt;Date&gt;</source>
      <translation variants="no">zh_tw #Day date</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>All day event</source>
      <translation variants="no">zh_tw #All-day event</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">zh_tw #Add description</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Start date</source>
      <translation variants="no">zh_tw #Start date</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_new_event">
      <source>New event</source>
      <translation variants="no">zh_tw #New entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_event">
      <source>Delete event</source>
      <translation variants="no">zh_tw #Delete entry</translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Not specified</source>
      <translation variants="no">zh_tw #Delete</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_entries">
      <source>Delete entries</source>
      <translation variants="no">zh_tw #Delete entries</translation>
    </message>
    <message numerus="no" id="txt_calendar_toggle_yes">
      <source>Yes</source>
      <translation variants="no">zh_tw #Shown</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_event">
      <source>New event</source>
      <translation variants="no">zh_tw #New entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_date">
      <source>Go to date</source>
      <translation variants="no">zh_tw #Go to date</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_before_date">
      <source>Before date</source>
      <translation variants="no">zh_tw #Before selected date</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_settings">
      <source>Calendar settings</source>
      <translation variants="no">zh_tw #Settings</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_val_ln_minutes">
      <source>%Ln minutes</source>
      <translation variants="no">zh_tw #%Ln minute</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_undone">
      <source>Mark as undone</source>
      <translation variants="no">zh_tw #Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">zh_tw #Mark as done</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time">
      <source>Alarm snooze time</source>
      <translation variants="no">zh_tw #Alarm snooze time</translation>
    </message>
    <message numerus="no" id="txt_short_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">zh_tw #Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">zh_tw #Delete meeting?</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_calendar_settings">
      <source>Calendar settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Calendar settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_meeting">
      <source>New meeting</source>
      <translation variants="no">zh_tw #New meeting</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_30">
      <source>30 minutes</source>
      <translation variants="no">zh_tw #30 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_regional_information">
      <source>Regional information</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Regional information</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_10">
      <source>10 minutes</source>
      <translation variants="no">zh_tw #10 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_sa">
      <source>Sa</source>
      <translation variants="no">zh_tw #Sa</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Edit :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_today">
      <source>Go to today</source>
      <translation variants="no">zh_tw #Go to today</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_15_min">
      <source>15 minutes</source>
      <translation variants="no">zh_tw #15 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_set_date">
      <source>Set date</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Set date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_snooze_time_val_ln">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">zh_tw #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_mo">
      <source>Mo</source>
      <translation variants="no">zh_tw #Mo</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">zh_tw #%1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Delete entries ?</source>
      <translation variants="no">zh_tw #Delete entries ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_yes">
      <source>Yes</source>
      <translation variants="no">zh_tw #Yes</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_no">
      <source>No</source>
      <translation variants="no">zh_tw #No</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">zh_tw #Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Unnamed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_event">
      <source>Event</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Event</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Delete repeated entry :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_anniversary">
      <source>New anniversary</source>
      <translation variants="no">zh_tw #New anniversary</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_we">
      <source>We</source>
      <translation variants="no">zh_tw #We</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_wk">
      <source>Wk</source>
      <translation variants="no">zh_tw #Wk</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_15">
      <source>15 minutes</source>
      <translation variants="no">zh_tw #15 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_unnamed">
      <source>Unnamed</source>
      <translation variants="no">zh_tw #Unnamed</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_1_2">
      <source>%1 -%2</source>
      <translation variants="no">zh_tw #%1 -%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_no_entries">
      <source>No entries for today</source>
      <translation variants="no">zh_tw #No entries for today</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_5_minu">
      <source>5 minutes</source>
      <translation variants="no">zh_tw #5 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_ln_mi">
      <source>%Ln minutes</source>
      <translation variants="no">zh_tw #%Ln minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Delete anniversary?</source>
      <translation variants="no">zh_tw #Delete anniversary?</translation>
    </message>
    <message numerus="no" id="txt_calendar_month_label_title_12">
      <source>%1%2</source>
      <translation variants="no">zh_tw #%1%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_tu">
      <source>Tu</source>
      <translation variants="no">zh_tw #Tu</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_lunar_calendar">
      <source>Show lunar calendar</source>
      <translation variants="no">zh_tw #Show lunar calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_no">
      <source>No</source>
      <translation variants="no">zh_tw #No</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Start time</source>
      <translation variants="no">zh_tw #Start time</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_to">
      <source>To</source>
      <translation variants="no">zh_tw #To</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_week">
      <source>Before %Ln weeks</source>
      <translation variants="no">zh_tw #%Ln week before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_week_numbers">
      <source>Show week numbers</source>
      <translation variants="no">zh_tw #Week numbers</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_monthyear">
      <source>&lt;Month&gt;&lt;Year&gt;</source>
      <translation variants="no">zh_tw #Month year</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_send">
      <source>Send</source>
      <translation variants="no">zh_tw #Send</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Reminder</source>
      <translation variants="no">zh_tw #Reminder</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_no">
      <source>No</source>
      <translation variants="no">zh_tw #No</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_empty_list_no_entries">
      <source>No entries for today</source>
      <translation variants="no">zh_tw #No entries for today</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_10_min">
      <source>10 minutes</source>
      <translation variants="no">zh_tw #10 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Close</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">zh_tw #Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_th">
      <source>Th</source>
      <translation variants="no">zh_tw #Th</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_buddhist_year">
      <source>Show buddhist year</source>
      <translation variants="no">zh_tw #Show buddhist year</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time">
      <source>Reminder snooze time</source>
      <translation variants="no">zh_tw #Reminder snooze time</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_calendar_settings">
      <source>Calendar settings</source>
      <translation variants="no">zh_tw #Settings</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Only once</source>
      <translation variants="no">zh_tw #Not repeated</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Daily</source>
      <translation variants="no">zh_tw #Daily</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>End time</source>
      <translation variants="no">zh_tw #End time</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">zh_tw #Subject</translation>
    </message>
    <message numerus="no" id="txt_common_opt_help">
      <source>Not specified</source>
      <translation variants="no">zh_tw #Help</translation>
    </message>
    <message numerus="no" id="txt_calendar_toggle_no">
      <source>No</source>
      <translation variants="no">zh_tw #Hidden</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_su">
      <source>Su</source>
      <translation variants="no">zh_tw #Su</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_30_min">
      <source>30 minutes</source>
      <translation variants="no">zh_tw #30 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">zh_tw #This occurrence only</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_yes">
      <source>Yes</source>
      <translation variants="no">zh_tw #Yes</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">zh_tw #All occurences</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_all_calendar_entries">
      <source>Delete all calendar entries?</source>
      <translation variants="no">zh_tw #Delete all calendar entries?</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_yes">
      <source>Yes</source>
      <translation variants="no">zh_tw #Yes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_5_m">
      <source>5 minutes</source>
      <translation variants="no">zh_tw #5 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">zh_tw #Due on %1</translation>
    </message>
  </context>
</TS>