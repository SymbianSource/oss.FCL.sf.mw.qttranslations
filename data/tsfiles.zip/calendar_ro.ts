<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ro">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_list_start_end_time">
      <source>%1 -%2</source>
      <translation variants="no">%[14]1 - %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_main_view">
      <source>Calendar main view</source>
      <translation variants="no">Salt la ecr. princ. Agendă</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_friday">
      <source>Friday</source>
      <translation variants="no">ro #Friday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">ro #Wednesday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Da</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">Agendă</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_settings">
      <source>Settings</source>
      <translation variants="no">Setări</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Fără nume</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Agendă</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">Termen: %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_all_entries">
      <source>All entries</source>
      <translation variants="no">Toate înregistrările</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_mo">
      <source>Mo</source>
      <translation variants="no">Lu</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Ștergere înregistrare repetată:</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_date">
      <source>Go to date</source>
      <translation variants="no">Salt la data</translation>
    </message>
    <message numerus="no" id="txt_calendar_empty_list_no_entries">
      <source>No entries for today</source>
      <translation variants="no">Nicio înregistrare pentru azi</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_we">
      <source>We</source>
      <translation variants="no">Mi</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_lunar_calendar">
      <source>Show lunar calendar</source>
      <translation variants="no">AfiȘare calendar lunar</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_su">
      <source>Su</source>
      <translation variants="no">Du</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_sa">
      <source>Sa</source>
      <translation variants="no">Sâ</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_15">
      <source>15 minutes</source>
      <translation variants="no">15 minute</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">ȘtergeȚi întâlnirea?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_10">
      <source>10 minutes</source>
      <translation variants="no">10 minute</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Setări</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_tu">
      <source>Tu</source>
      <translation variants="no">Ma</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Editare:</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_all_calendar_entries">
      <source>Delete all calendar entries?</source>
      <translation variants="no">ȘtergeȚi toate înregistrările din agendă?</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_wk">
      <source>Wk</source>
      <translation variants="no">Săpt</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">ȘtergeȚi nota de rezolvat?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_monday">
      <source>Monday</source>
      <translation variants="no">ro #Monday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on">
      <source>Week starts on</source>
      <translation variants="no">ro #Week starts on</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">Agendă</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_thursday">
      <source>Thursday</source>
      <translation variants="no">ro #Thursday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_unnamed">
      <source>Unnamed</source>
      <translation variants="no">Fără nume</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_switch_to_day_view">
      <source>Switch to Day view</source>
      <translation variants="no">Comutare pe ecran-zi</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_5_m">
      <source>5 minutes</source>
      <translation variants="no">5 minute</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event?</source>
      <translation variants="no">ȘtergeȚi înregistrare întreaga zi?</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[28]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Numai această programare</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_entries">
      <source>Delete entries</source>
      <translation variants="no">Ștergere înregistrări</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Toate programările</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_fr">
      <source>Fr</source>
      <translation variants="no">Vi</translation>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_snooze_time_val_ln">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">%Ln minut</numerusform>
        <numerusform plurality="b">%Ln minute</numerusform>
        <numerusform plurality="c">%Ln de minute</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_show_lunar_data">
      <source>Show lunar data</source>
      <translation variants="no">AfiȘare date lunare</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_event">
      <source>New event</source>
      <translation variants="no">Înregistrare nouă</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_before_date">
      <source>Before date</source>
      <translation variants="no">Înainte de data selectată</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_th">
      <source>Th</source>
      <translation variants="no">Jo</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_buddhist_year">
      <source>Show buddhist year</source>
      <translation variants="no">AfiȘare an budist</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time">
      <source>Reminder snooze time</source>
      <translation variants="no">Durată amânare alarmă</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_week_numbers">
      <source>Show week numbers</source>
      <translation variants="no">Numere săptămâni</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_no_entries">
      <source>No entries for today</source>
      <translation variants="no">Nicio înregistrare pentru azi</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Marcare ca rezolvată</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_today">
      <source>Go to today</source>
      <translation variants="no">Salt la astăzi</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_switch_to_agenda_view">
      <source>Switch to Agenda view</source>
      <translation variants="no">Comutare pe ecran-agendă</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_30">
      <source>30 minutes</source>
      <translation variants="no">30 de minute</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_saturday">
      <source>Saturday</source>
      <translation variants="no">ro #Saturday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_sunday">
      <source>Sunday</source>
      <translation variants="no">ro #Sunday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">ro #Tuesday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Da</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Da</lengthvariant>
      </translation>
    </message>
  </context>
</TS>