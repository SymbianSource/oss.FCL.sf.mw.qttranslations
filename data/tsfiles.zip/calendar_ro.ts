<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ro">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_opt_sub_all_entries">
      <source>Source 0</source>
      <translation variants="no">ro #All entries</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_new_event">
      <source>Source 1</source>
      <translation variants="no">ro #New calendar entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_settings">
      <source>Source 2</source>
      <translation variants="no">ro #Settings</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_event">
      <source>Source 3</source>
      <translation variants="no">ro #New entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_val_ln_minutes">
      <source>Source 4</source>
      <translation variants="no">ro #%Ln minute</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time">
      <source>Source 5</source>
      <translation variants="no">ro #Alarm snooze time</translation>
    </message>
    <message numerus="no" id="txt_calendar_toggle_no">
      <source>Source 6</source>
      <translation variants="no">ro #Hidden</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_before_date">
      <source>Source 7</source>
      <translation variants="no">ro #Before selected date</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_week_numbers">
      <source>Source 8</source>
      <translation variants="no">ro #Week numbers</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_date">
      <source>Source 9</source>
      <translation variants="no">ro #Go to date</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_undone">
      <source>Source 10</source>
      <translation variants="no">ro #Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_send">
      <source>Source 11</source>
      <translation variants="no">ro #Send</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Source 12</source>
      <translation variants="no">ro #Mark as done</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_entries">
      <source>Source 13</source>
      <translation variants="no">ro #Delete entries</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Source 14</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_toggle_yes">
      <source>Source 15</source>
      <translation variants="no">ro #Shown</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Source 16</source>
      <translation variants="no">ro #Monthly</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_attachment">
      <source>Source 17</source>
      <translation variants="no">ro #Add attachment</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_daydate">
      <source>Source 18</source>
      <translation variants="no">ro #Day date</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Source 19</source>
      <translation variants="no">ro #Start date</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Source 20</source>
      <translation variants="no">ro #Yearly</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_biweekly">
      <source>Source 21</source>
      <translation variants="no">ro #Fortnightly</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_days">
      <source>Source 22</source>
      <translation variants="no">ro #%Ln day before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Source 23</source>
      <translation variants="no">ro #Repeat</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Source 24</source>
      <translation variants="no">ro #Reminder</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_description">
      <source>Source 25</source>
      <translation variants="no">ro #Description</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_new_event">
      <source>Source 26</source>
      <translation variants="no">ro #New entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Source 27</source>
      <translation variants="no">ro #Start time</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_calendar_settings">
      <source>Source 28</source>
      <translation variants="no">ro #Settings</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_minu">
      <source>Source 29</source>
      <translation variants="no">ro #%Ln minute before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_to">
      <source>Source 30</source>
      <translation variants="no">ro #To</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Source 31</source>
      <translation variants="no">ro #Not repeated</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Source 32</source>
      <translation variants="no">ro #Daily</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_event">
      <source>Source 33</source>
      <translation variants="no">ro #Delete entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>Source 34</source>
      <translation variants="no">ro #End date</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Source 35</source>
      <translation variants="no">ro #Repeat until</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_time">
      <source>Source 36</source>
      <translation variants="no">ro #Time</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Source 37</source>
      <translation variants="no">ro #Weekly</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_from">
      <source>Source 38</source>
      <translation variants="no">ro #From</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_daydate">
      <source>Source 39</source>
      <translation variants="no">ro #Day date</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Source 40</source>
      <translation variants="no">ro #Location</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>Source 41</source>
      <translation variants="no">ro #All-day event</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_hour">
      <source>Source 42</source>
      <translation variants="no">ro #%Ln hour before</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Source 43</source>
      <translation variants="no">ro #Add description</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_monthyear">
      <source>Source 44</source>
      <translation variants="no">ro #Month year</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>Source 45</source>
      <translation variants="no">ro #End time</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Source 46</source>
      <translation variants="no">ro #Subject</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_week">
      <source>Source 47</source>
      <translation variants="no">ro #%Ln week before</translation>
    </message>
    <message numerus="no" id="txt_short_caption_calendar">
      <source>Source 48</source>
      <translation variants="no">ro #Calendar</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar">
      <source>Source 49</source>
      <translation variants="no">ro #Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_settings">
      <source>Source 50</source>
      <translation variants="no">ro #Settings</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Source 51</source>
      <translation variants="no">ro #Delete To-do note?</translation>
    </message>
    <message numerus="no" id="txt_task_switcher_caption_calendar">
      <source>Source 52</source>
      <translation variants="no">ro #Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_fr">
      <source>Source 53</source>
      <translation variants="no">ro #Fr</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_main_view">
      <source>Source 54</source>
      <translation variants="no">ro #Calendar main view</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_unnamed">
      <source>Source 55</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Unnamed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_due_on_1">
      <source>Source 56</source>
      <translation variants="no">ro #Due on %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_su">
      <source>Source 57</source>
      <translation variants="no">ro #Su</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_event">
      <source>Source 58</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Event</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_10_min">
      <source>Source 59</source>
      <translation variants="no">ro #10 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_unnamed">
      <source>Source 60</source>
      <translation variants="no">ro #Unnamed</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_sa">
      <source>Source 61</source>
      <translation variants="no">ro #Sa</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_th">
      <source>Source 62</source>
      <translation variants="no">ro #Th</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Source 63</source>
      <translation variants="no">ro #Delete meeting?</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Source 64</source>
      <translation variants="no">ro #Delete anniversary?</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_calendar_settings">
      <source>Source 65</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Calendar settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_month_label_title_12">
      <source>Source 66</source>
      <translation variants="no">ro #%1%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_1_2">
      <source>Source 67</source>
      <translation variants="no">ro #%1 -%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_mo">
      <source>Source 68</source>
      <translation variants="no">ro #Mo</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_15_min">
      <source>Source 69</source>
      <translation variants="no">ro #15 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_1_2">
      <source>Source 70</source>
      <translation variants="no">ro #%1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_30_min">
      <source>Source 71</source>
      <translation variants="no">ro #30 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Source 72</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Delete repeated entry :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_anniversary">
      <source>Source 73</source>
      <translation variants="no">ro #New anniversary</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>Source 74</source>
      <translation variants="no">ro #This occurrence only</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_yes">
      <source>Source 75</source>
      <translation variants="no">ro #Yes</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_set_date">
      <source>Source 76</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Set date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Source 77</source>
      <translation variants="no">ro #Delete entries ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_no_entries">
      <source>Source 78</source>
      <translation variants="no">ro #No entries for today</translation>
    </message>
    <message numerus="no" id="txt_calendar_empty_list_no_entries">
      <source>Source 79</source>
      <translation variants="no">ro #No entries for today</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_meeting">
      <source>Source 80</source>
      <translation variants="no">ro #New meeting</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Source 81</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_no">
      <source>Source 82</source>
      <translation variants="no">ro #No</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_tu">
      <source>Source 83</source>
      <translation variants="no">ro #Tu</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Source 84</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Edit :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_5_minu">
      <source>Source 85</source>
      <translation variants="no">ro #5 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_today">
      <source>Source 86</source>
      <translation variants="no">ro #Go to today</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Source 87</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>Source 88</source>
      <translation variants="no">ro #All occurences</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_all_calendar_entries">
      <source>Source 89</source>
      <translation variants="no">ro #Delete all calendar entries?</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_we">
      <source>Source 90</source>
      <translation variants="no">ro #We</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_wk">
      <source>Source 91</source>
      <translation variants="no">ro #Wk</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_ln_mi">
      <source>Source 92</source>
      <translation variants="no">ro #%Ln minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_yes">
      <source>Source 93</source>
      <translation variants="no">ro #Yes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_30">
      <source>Source 94</source>
      <translation variants="no">ro #30 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_lunar_calendar">
      <source>Source 95</source>
      <translation variants="no">ro #Show lunar calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_regional_information">
      <source>Source 96</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Regional information</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_no">
      <source>Source 97</source>
      <translation variants="no">ro #No</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_10">
      <source>Source 98</source>
      <translation variants="no">ro #10 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time">
      <source>Source 99</source>
      <translation variants="no">ro #Reminder snooze time</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_no">
      <source>Source 100</source>
      <translation variants="no">ro #No</translation>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_snooze_time_val_ln">
      <source>Source 101</source>
      <translation>
        <numerusform plurality="a">ro #MISSING</numerusform>
        <numerusform plurality="b">ro #MISSING</numerusform>
        <numerusform plurality="c">ro #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_close">
      <source>Source 102</source>
      <translation variants="yes">
        <lengthvariant priority="1">ro #Close</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_yes">
      <source>Source 103</source>
      <translation variants="no">ro #Yes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_15">
      <source>Source 104</source>
      <translation variants="no">ro #15 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_buddhist_year">
      <source>Source 105</source>
      <translation variants="no">ro #Show buddhist year</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_5_m">
      <source>Source 106</source>
      <translation variants="no">ro #5 minutes</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_calendar">
      <source>Source 107</source>
      <translation variants="no">ro #Calendar</translation>
    </message>
  </context>
</TS>