<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_pimtodo_formlabel_synchronization">
      <source>Synchronisation</source>
      <translation variants="no">同步處理</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_pobox">
      <source>P.O. Box</source>
      <translation variants="no">郵政信箱</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">最後修改</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_borthday">
      <source>Birthday</source>
      <translation variants="no">生日</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">職位名稱</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_default">
      <source>Default</source>
      <translation variants="no">預設</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_date">
      <source>Date</source>
      <translation variants="no">日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">主題</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_uid">
      <source>UID</source>
      <translation variants="no">唯一識別項</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_company">
      <source>Company</source>
      <translation variants="no">公司</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">姓</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_location">
      <source>Location</source>
      <translation variants="no">方位</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">最後修改</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_assistant_name">
      <source>Assistant's name</source>
      <translation variants="no">助理的姓名</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_picture">
      <source>Picture</source>
      <translation variants="no">圖片</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_video_number">
      <source>Video number</source>
      <translation variants="no">視像電話</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_completed">
      <source>Completed</source>
      <translation variants="no">已完成</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">名</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_car_phone">
      <source>Car phone</source>
      <translation variants="no">汽車電話</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_department">
      <source>Department</source>
      <translation variants="no">部門</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">週年紀念日</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_pager">
      <source>Pager</source>
      <translation variants="no">傳呼</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_priority">
      <source>Priority</source>
      <translation variants="no">優先順序</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_synchronization">
      <source>Synchronisation</source>
      <translation variants="no">同步處理</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_telephone">
      <source>Telephone</source>
      <translation variants="no">電話</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">詳細地址</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">到期日</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_mobile">
      <source>Mobile</source>
      <translation variants="no">流動電話</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_wv_user_id">
      <source>WV User ID</source>
      <translation variants="no">WV用戶識別碼</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_postalcode">
      <source>Postal code</source>
      <translation variants="no">郵政編碼</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_end_date">
      <source>End date</source>
      <translation variants="no">結束日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_end_time_and_date">
      <source>End time and date</source>
      <translation variants="no">結束時間和日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_state">
      <source>State</source>
      <translation variants="no">州/省</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_fax">
      <source>Fax</source>
      <translation variants="no">傳真</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">頭銜</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_appointments">
      <source>Appointments</source>
      <translation variants="yes">
        <lengthvariant priority="1">會議</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_occasion">
      <source>Occasion</source>
      <translation variants="no">主題</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_formatted_name">
      <source>Name</source>
      <translation variants="no">名稱</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_start_time_and_date">
      <source>Start time and date</source>
      <translation variants="no">開始時間和日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_suffix">
      <source>Suffix</source>
      <translation variants="no">稱謂</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_street">
      <source>Street</source>
      <translation variants="no">街道</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_name">
      <source>Name</source>
      <translation variants="no">名稱</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">配偶</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_anniversaries">
      <source>Anniversaries</source>
      <translation variants="yes">
        <lengthvariant priority="1">週年紀念日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_address">
      <source>Address</source>
      <translation variants="no">地址</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_other">
      <source>Other</source>
      <translation variants="no">其他</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_uid">
      <source>UID</source>
      <translation variants="no">唯一識別項</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_city">
      <source>City</source>
      <translation variants="no">城市</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_description">
      <source>Description</source>
      <translation variants="no">內容說明</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_assistant_phone">
      <source>Assistant's phone</source>
      <translation variants="no">助理的電話號碼</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_note">
      <source>Note</source>
      <translation variants="no">備註</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_sms">
      <source>SMS</source>
      <translation variants="no">短訊</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_synchronisation">
      <source>Synchronisation</source>
      <translation variants="no">同步處理</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_uid">
      <source>UID</source>
      <translation variants="no">唯一識別項</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_children">
      <source>Children</source>
      <translation variants="no">小孩</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">中間名</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_completion_date">
      <source>Completion date</source>
      <translation variants="no">完成日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_description">
      <source>Description</source>
      <translation variants="no">內容說明</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">主題</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">響鬧</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">最後修改</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_start_date">
      <source>Start date</source>
      <translation variants="no">開始日期</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_country">
      <source>Country</source>
      <translation variants="no">國家或地區</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_url">
      <source>URL address</source>
      <translation variants="no">網址</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_title_to_do_notes">
      <source>To-do notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">待辦事項</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_tel_internet">
      <source>Tel. Internet</source>
      <translation variants="no">互聯網電話</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">鈴聲</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_nickname">
      <source>Nickname</source>
      <translation variants="no">暱稱</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_email">
      <source>E-Mail</source>
      <translation variants="no">電郵地址</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_dtmf">
      <source>DTMF</source>
      <translation variants="no">DTMF</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_title_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">通訊錄</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_push_to_talk">
      <source>Push to talk</source>
      <translation variants="no">對講機</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">響鬧</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_share_view">
      <source>Share view</source>
      <translation variants="no">分享視像</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_business">
      <source>Business</source>
      <translation variants="no">辦公室</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_home">
      <source>Home</source>
      <translation variants="no">住宅</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_first_name_reading">
      <source>First name reading</source>
      <translation variants="no">名字讀音</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_last_name_reading">
      <source>Last name reading</source>
      <translation variants="no">姓氏讀音</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_momos">
      <source>Memos</source>
      <translation variants="yes">
        <lengthvariant priority="1">備註</lengthvariant>
      </translation>
    </message>
  </context>
</TS>