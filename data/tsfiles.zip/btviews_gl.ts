<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="gl">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Source 0</source>
      <translation variants="no">Cambiar duración visibilidade</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_input_devices">
      <source>Source 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Dispositivos de entrada</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>Source 2</source>
      <translation variants="no">Todos os dispositivos</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_phones">
      <source>Source 3</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai teléfonos</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_input_devices">
      <source>Source 4</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Dispositivos de entrada vinculados</lengthvariant>
        <lengthvariant priority="2">Bluetooth - Disp. entrada vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>Source 5</source>
      <translation variants="no">%1 detalles</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Source 6</source>
      <translation variants="no">Italiano</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Source 7</source>
      <translation variants="yes">
        <lengthvariant priority="1">Vinculado</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_paired_devices">
      <source>Source 8</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai outros dispositivos vinculados</lengthvariant>
        <lengthvariant priority="2">Non hai outr. disp. vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>Source 9</source>
      <translation variants="no">%[15]1 conectado</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Source 10</source>
      <translation variants="yes">
        <lengthvariant priority="1">Automática</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Source 11</source>
      <translation variants="yes">
        <lengthvariant priority="1">Vinculado, seguro, conectado</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Source 12</source>
      <translation variants="yes">
        <lengthvariant priority="1">gl #Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Source 13</source>
      <translation variants="yes">
        <lengthvariant priority="1">Vinculado, conectado</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_phones">
      <source>Source 14</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Teléfonos</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Source 15</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth -  Todos os dispositivos</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Source 16</source>
      <translation variants="no">Francés belga</translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Source 17</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dispositivo de entrada</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Source 18</source>
      <translation variants="no">Danés</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Source 19</source>
      <translation variants="yes">
        <lengthvariant priority="1">Preguntar sempre</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>Source 20</source>
      <translation variants="no">EEUU Internacional</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Source 21</source>
      <translation variants="no">Desactivado</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_input_devices">
      <source>Source 22</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai dispositivos vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Source 23</source>
      <translation variants="no">Dispositivos vinculados</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_devices">
      <source>Source 24</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Outros dispositivos</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Source 25</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ordenador</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>Source 26</source>
      <translation variants="yes">
        <lengthvariant priority="1">gl #On and hidden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Source 27</source>
      <translation variants="no">Finés, Suecia</translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Source 28</source>
      <translation variants="yes">
        <lengthvariant priority="1">Outro</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Source 29</source>
      <translation variants="no">gl #Unpair</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_phones">
      <source>Source 30</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Teléfonos vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Source 31</source>
      <translation variants="no">Noruegués</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Source 32</source>
      <translation variants="no">Portugués</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Source 33</source>
      <translation variants="yes">
        <lengthvariant priority="1">gl #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Source 34</source>
      <translation variants="no">Deseño do teclado</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Source 35</source>
      <translation variants="yes">
        <lengthvariant priority="1">Axustes do teclado</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>Source 36</source>
      <translation variants="no">Reino Unido</translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Source 37</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bloqueado</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>Source 38</source>
      <translation variants="no">Alemán</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>Source 39</source>
      <translation variants="no">Dvorak EEUU</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Source 40</source>
      <translation variants="no">Español</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_audio_devices">
      <source>Source 41</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Dispositivos de audio</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_computers">
      <source>Source 42</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Ordenadores</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>Source 43</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non se atoparon dispositivos</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Source 44</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bloqueada</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_audio_devices">
      <source>Source 45</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai dispositivos de audio</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>Source 46</source>
      <translation variants="no">Francés</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_computers">
      <source>Source 47</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai ordenadores</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_audio_devices">
      <source>Source 48</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Dispositivos de audio vinculados</lengthvariant>
        <lengthvariant priority="2">Bluetooth - Disp. audio vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Source 49</source>
      <translation variants="no">gl #Search completed</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_paired_devices">
      <source>Source 50</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Outros dispositivos vinculados</lengthvariant>
        <lengthvariant priority="2">Bluetooth - Outros disp. vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Source 51</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Axustes avanzados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_audio_devices">
      <source>Source 52</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai dispositivos de audio vinculados</lengthvariant>
        <lengthvariant priority="2">Non hai disp. audio vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Source 53</source>
      <translation variants="no">gl #Pair</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Source 54</source>
      <translation variants="yes">
        <lengthvariant priority="1">Conexión</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_1">
      <source>Source 55</source>
      <translation variants="no">Bluetooth - %1</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Source 56</source>
      <translation>
        <numerusform plurality="a">gl #Visible for %Ln minute</numerusform>
        <numerusform plurality="b">gl #Visible for %Ln minutes</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_phones">
      <source>Source 57</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai teléfonos vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_devices">
      <source>Source 58</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai outros dispositivos</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Source 59</source>
      <translation variants="yes">
        <lengthvariant priority="1">Axustes do rato</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Source 60</source>
      <translation variants="yes">
        <lengthvariant priority="1">gl #Visible and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Source 61</source>
      <translation variants="no">Eliminar</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>Source 62</source>
      <translation variants="no">Inglés EEUU</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Source 63</source>
      <translation variants="no">gl #Searching</translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Source 64</source>
      <translation variants="yes">
        <lengthvariant priority="1">Conectado</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>Source 65</source>
      <translation variants="no">Perfil de acceso da SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Source 66</source>
      <translation variants="no">Elim. disposit. vinculados</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Source 67</source>
      <translation variants="no">Activado</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Source 68</source>
      <translation variants="no">Dispositivos bloqueados</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Source 69</source>
      <translation variants="no">gl #Hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Source 70</source>
      <translation variants="no">Ruso</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Source 71</source>
      <translation variants="no">Conectar</translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Source 72</source>
      <translation variants="no">gl #Disconnect</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Source 73</source>
      <translation variants="no">gl #Device details</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>Source 74</source>
      <translation variants="yes">
        <lengthvariant priority="1">gl #On and visible</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Source 75</source>
      <translation variants="no">Desconectar</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>Source 76</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai dispositivos</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Source 77</source>
      <translation variants="no">gl #Bluetooth - Found devices</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Source 78</source>
      <translation variants="yes">
        <lengthvariant priority="1">Teléfono</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Source 79</source>
      <translation variants="yes">
        <lengthvariant priority="1">gl #Hidden and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Source 80</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Dispositivos vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>Source 81</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai dispositivos vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_input_devices">
      <source>Source 82</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai dispositivos de entrada</lengthvariant>
        <lengthvariant priority="2">Non hai dispositivos entrada</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Source 83</source>
      <translation variants="yes">
        <lengthvariant priority="1">Vinculado, seguro</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Source 84</source>
      <translation variants="no">Axustes avanzados</translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Source 85</source>
      <translation variants="no">gl #Connect</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Source 86</source>
      <translation variants="no">gl #Visible</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Source 87</source>
      <translation variants="no">Holandés</translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Source 88</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dispositivo de audio</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_computers">
      <source>Source 89</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non hai ordenadores vinculados</lengthvariant>
        <lengthvariant priority="2">Non hai ordenad. vinculados</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_computers">
      <source>Source 90</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth - Ordenadores vinculados</lengthvariant>
      </translation>
    </message>
  </context>
</TS>