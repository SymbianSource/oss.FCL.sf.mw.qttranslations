<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_blanket">
      <source>Blanket</source>
      <translation variants="yes">
        <lengthvariant priority="1">总是允许</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission">
      <source>Permission type</source>
      <translation variants="no">程序接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_note_security_warn">
      <source>Security warning</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Security warning</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_net">
      <source>Choosing this item may result in compromised privacy or increased network usage costs. Continue? </source>
      <translation variants="no">zh #Choosing this item may result in compromised privacy or increased network usage costs. Continue? </translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Ok</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_warn">
      <source>Changing this setting item will cause changes in other settings. Continue? </source>
      <translation variants="no">zh #Changing this setting item will cause changes in other settings. Continue? </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_sec">
      <source>Choosing this item may cause your privacy to be compromised. Continue? </source>
      <translation variants="no">zh #Choosing this item may cause your privacy to be compromised. Continue? </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_landmarks">
      <source>Landmarks</source>
      <translation variants="no">标记</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_network_conn">
      <source>Network connection</source>
      <translation variants="no">网络连接</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_local_conn">
      <source>Local connectivity</source>
      <translation variants="no">连接功能</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_net_access">
      <source>Net access</source>
      <translation variants="no">网络接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_oneshot">
      <source>Oneshot</source>
      <translation variants="yes">
        <lengthvariant priority="1">总是询问</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_auth">
      <source>Authentication</source>
      <translation variants="no">鉴定</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_game">
      <source>Game keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">游戏键</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_url_start">
      <source>URL start</source>
      <translation variants="no">网络接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_write_data">
      <source>Write user data</source>
      <translation variants="no">编辑用户</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">用户自定义</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_call_control">
      <source>Call control</source>
      <translation variants="no">通话控制</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_network_conn_val_default">
      <source>Default connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">预设连接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_network_conn_val_list">
      <source>List of available connections</source>
      <translation variants="yes">
        <lengthvariant priority="1">可用连接列表</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level">
      <source>Security warnings</source>
      <translation variants="no">警告</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_app_auto_invoc">
      <source>Application auto invocation</source>
      <translation variants="no">程序自动启动</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_sec">
      <source>Allowing these permissions may result in compromised privacy.</source>
      <translation variants="no">zh #Allowing these permissions may result in compromised privacy.</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_sec">
      <source>Allowing these permissions may result in compromised privacy.</source>
      <translation variants="no">zh #Allowing these permissions may result in compromised privacy.</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_smartcard">
      <source>Smart card communication</source>
      <translation variants="no">智能卡</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_low_level_net_access">
      <source>Low level network access</source>
      <translation variants="no">低级网络接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_subtitle_security">
      <source>Security</source>
      <translation variants="no">安全</translation>
    </message>
    <message numerus="no" id="txt_java_sett_subtitle_general">
      <source>General</source>
      <translation variants="no">标准</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_navigation">
      <source>Navigation keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">导航键</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_read_data">
      <source>Read user data</source>
      <translation variants="no">读取用户</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_messaging">
      <source>Messaging</source>
      <translation variants="no">信息</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_location">
      <source>Location</source>
      <translation variants="no">定位</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_net">
      <source>Allowing these permissions may result in compromised privacy or increased network usage costs.</source>
      <translation variants="no">zh #Allowing these permissions may result in compromised privacy or increased network usage costs.</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_net">
      <source>Allowing these permissions may result in compromised privacy or increased network usage costs.</source>
      <translation variants="no">zh #Allowing these permissions may result in compromised privacy or increased network usage costs.</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_default">
      <source>Default</source>
      <translation variants="yes">
        <lengthvariant priority="1">预设</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_restricted_messaging">
      <source>Restricted messaging</source>
      <translation variants="no">重启信息</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_nfc_write_access">
      <source>NFC Write access</source>
      <translation variants="no">NFC发射</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_network_conn_val_ask_user">
      <source>Always ask</source>
      <translation variants="yes">
        <lengthvariant priority="1">总是询问</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_no">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">无</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk">
      <source>On-screen-keypad</source>
      <translation variants="no">键盘</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_mm_record">
      <source>Multimedia recording</source>
      <translation variants="no">多媒体</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_broadcast">
      <source>Broadcast</source>
      <translation variants="no">电视用户数据</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_session">
      <source>Session</source>
      <translation variants="yes">
        <lengthvariant priority="1">仅第一次询问</lengthvariant>
      </translation>
    </message>
  </context>
</TS>