<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_sec">
      <source>Allowing these permissions may result in compromised privacy.</source>
      <translation variants="no">允许这些权限可能导致损害隐私</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_blanket">
      <source>Blanket</source>
      <translation variants="yes">
        <lengthvariant priority="1">总是允许</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission">
      <source>Permission type</source>
      <translation variants="no">程序接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_subhead_security">
      <source>Security</source>
      <translation variants="no">zh #Security</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_net">
      <source>Allowing these permissions may result in compromised privacy or increased network usage costs.</source>
      <translation variants="no">允许这些权限可能导致损害隐私或增加网络使用费</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_nfc_write_access">
      <source>NFC Write access</source>
      <translation variants="no">NFC发射</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_messaging">
      <source>Messaging</source>
      <translation variants="no">信息</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_location">
      <source>Location</source>
      <translation variants="no">定位</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_net_access">
      <source>Net access</source>
      <translation variants="no">网络接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_oneshot">
      <source>Oneshot</source>
      <translation variants="yes">
        <lengthvariant priority="1">总是询问</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_game">
      <source>Game keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">游戏键</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_user_defined">
      <source>User defined</source>
      <translation variants="no">用户自定义</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level">
      <source>Security warnings</source>
      <translation variants="no">警告</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_auth">
      <source>Authentication</source>
      <translation variants="no">鉴定</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_url_start">
      <source>URL start</source>
      <translation variants="no">网络接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_write_data">
      <source>Write user data</source>
      <translation variants="no">编辑用户</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_call_control">
      <source>Call control</source>
      <translation variants="no">通话控制</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_no">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">无</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk">
      <source>On-screen-keypad</source>
      <translation variants="no">键盘</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_landmarks">
      <source>Landmarks</source>
      <translation variants="no">标记</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_mm_record">
      <source>Multimedia recording</source>
      <translation variants="no">多媒体</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_broadcast">
      <source>Broadcast</source>
      <translation variants="no">电视用户数据</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_local_conn">
      <source>Local connectivity</source>
      <translation variants="no">连接功能</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_session">
      <source>Session</source>
      <translation variants="yes">
        <lengthvariant priority="1">仅第一次询问</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_default">
      <source>Default</source>
      <translation variants="no">预设</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_restricted_messaging">
      <source>Restricted messaging</source>
      <translation variants="no">重启信息</translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_net">
      <source>Choosing this item may result in compromised privacy or increased network usage costs. Continue? </source>
      <translation variants="no">所选设置可能导致损害隐私或增加网络使用费。继续？</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_navigation">
      <source>Navigation keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">导航键</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_read_data">
      <source>Read user data</source>
      <translation variants="no">读取用户</translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">确认</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_warn">
      <source>Changing this setting item will cause changes in other settings. Continue? </source>
      <translation variants="no">更改此设置会导致其他设置也发生变化。继续？</translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_note_security_warn">
      <source>Security warning</source>
      <translation variants="no">安全警告</translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_subhead_general">
      <source>General</source>
      <translation variants="no">zh #General</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_settings_not_available">
      <source>Settings not available</source>
      <translation variants="no">zh #Settings not available</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_sec">
      <source>Choosing this item may cause your privacy to be compromised. Continue? </source>
      <translation variants="no">所选设置可能导致您的隐私受损害。继续？</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_app_auto_invoc">
      <source>Application auto invocation</source>
      <translation variants="no">程序自动启动</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_smartcard">
      <source>Smart card communication</source>
      <translation variants="no">智能卡</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_low_level_net_access">
      <source>Low level network access</source>
      <translation variants="no">低级网络接入</translation>
    </message>
  </context>
</TS>