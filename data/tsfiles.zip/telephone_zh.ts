<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_info_phone_not_allowed_mm_6">
      <source>Phone not allowed MM #6 </source>
      <translation variants="no">zh #Phone not allowed MM #6 </translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_reboot_required">
      <source>Phone reboot required %L1</source>
      <translation variants="no">zh #Phone reboot required %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_rejected">
      <source>Call rejected %L1</source>
      <translation variants="no">zh #Call rejected %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_request_rejected_l1">
      <source>Request rejected %L1 </source>
      <translation variants="no">zh #Request rejected %L1 </translation>
    </message>
    <message numerus="no" id="txt_phone_info_sim_invalid">
      <source>Sim invalid %L1</source>
      <translation variants="no">zh #Sim invalid %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_smartchip_not_provisioned_mm_2">
      <source>Smartchip not provisioned MM #2 </source>
      <translation variants="no">zh #Smartchip not provisioned MM #2 </translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_failed_mm_4">
      <source>Call Failed MM #4 </source>
      <translation variants="no">zh #Call Failed MM #4 </translation>
    </message>
    <message numerus="no" id="txt_phone_info_sim_unaccepted">
      <source>Sim unaccepted %L1</source>
      <translation variants="no">zh #Sim unaccepted %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sim_rejected">
      <source>Sim rejected %L1</source>
      <translation variants="no">zh #Sim rejected %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_grid_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Telephone</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_sim_removed">
      <source>Sim removed %L1</source>
      <translation variants="no">zh #Sim removed %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected">
      <source>Connected</source>
      <translation variants="no">zh #Connected</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_l1_call">
      <source>Incoming %1 call</source>
      <translation variants="no">zh #Incoming %1 call</translation>
    </message>
    <message numerus="no" id="txt_phone_dblist_ongoing_call">
      <source>Ongoing call</source>
      <translation variants="yes">
        <lengthvariant priority="1">正在通话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_unknown_number">
      <source>Unknown number</source>
      <translation variants="no">未知号码</translation>
    </message>
    <message numerus="yes" id="txt_phone_dblist_ln_missed_calls">
      <source>%Ln missed calls</source>
      <translation>
        <numerusform plurality="a">%Ln个未接电话</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_not_allowed_mm_5">
      <source>Phone not allowed MM #5 </source>
      <translation variants="no">zh #Phone not allowed MM #5 </translation>
    </message>
    <message numerus="no" id="txt_phone_other_payphone">
      <source>Payphone</source>
      <translation variants="no">zh #Payphone</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_video_call">
      <source>Incoming video call</source>
      <translation variants="no">zh #Incoming video call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_l1">
      <source>Call %L1?</source>
      <translation variants="no">zh #Call %L1?</translation>
    </message>
    <message numerus="no" id="txt_phone_other_disconnected">
      <source>Disconnected</source>
      <translation variants="no">已断开</translation>
    </message>
    <message numerus="no" id="txt_phone_other_on_hold">
      <source>On hold</source>
      <translation variants="no">等待接听</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_call">
      <source>Incoming call</source>
      <translation variants="yes">
        <lengthvariant priority="1">来电</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling">
      <source>Calling</source>
      <translation variants="no">正在呼叫</translation>
    </message>
    <message numerus="no" id="txt_long_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">电话</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_transfer">
      <source>Transfer</source>
      <translation variants="no">传送</translation>
    </message>
    <message numerus="no" id="txt_phone_title_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_attempting">
      <source>Attempting</source>
      <translation variants="yes">
        <lengthvariant priority="1">正在紧急呼叫</lengthvariant>
        <lengthvariant priority="2">zh #Attempting emergency cl.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_emergency_call">
      <source>Emergency call</source>
      <translation variants="yes">
        <lengthvariant priority="1">紧急呼叫</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_no_network_coverage">
      <source>No network coverage %L1</source>
      <translation variants="no">无网络信号</translation>
    </message>
    <message numerus="no" id="txt_phone_other_waiting">
      <source>Waiting</source>
      <translation variants="no">正在等待</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_end_all_calls">
      <source>End all calls</source>
      <translation variants="no">结束所有通话</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_not_allowed">
      <source>Not allowed %L1</source>
      <translation variants="no">不允许</translation>
    </message>
    <message numerus="no" id="txt_phone_info_called_number_has_barred_incoming">
      <source>Called number has barred incoming calls %L1</source>
      <translation variants="no">被叫方已禁止来电</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_use">
      <source>Number not in use %L1</source>
      <translation variants="no">此号码为空号</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_network_services">
      <source>Check network services %L1</source>
      <translation variants="no">请检查网络服务</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_answer">
      <source>No answer %L1</source>
      <translation variants="no">对方无应答</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_calls_only">
      <source>Emergency calls only %L1</source>
      <translation variants="no">仅紧急呼叫</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_busy">
      <source>Network busy %L1</source>
      <translation variants="no">网络正忙</translation>
    </message>
    <message numerus="no" id="txt_phone_info_videocall_only_possible_under_3g">
      <source>Videocall only possible under 3G coverage %L1</source>
      <translation variants="no">在3G网络服务范围外不支持视频通话</translation>
    </message>
    <message numerus="no" id="txt_phone_info_serial_no">
      <source>Serial No.\n%L1</source>
      <translation variants="no">序列号：
%1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_unable_to_make_video_call_not_supp">
      <source>Unable to make video call. Not supported by other phone or network. %L1</source>
      <translation variants="no">无法进行视频通话。对方设备或网络不支持此功能。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_error_in_connection">
      <source>Error in connection %L1</source>
      <translation variants="no">连接错误</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected_to_1">
      <source>Connected to %L1</source>
      <translation variants="no">已连接至%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_diverting">
      <source>Diverting</source>
      <translation variants="no">正在转接</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_all_incoming_calls_diver">
      <source>Note:  all incoming calls diverted</source>
      <translation variants="no">注意：全部来电被转接</translation>
    </message>
    <message numerus="no" id="txt_phone_info_activate_own_number_sending">
      <source>Activate own number sending %L1</source>
      <translation variants="no">本机号码发送启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_not_allowed_during_resto">
      <source>Video call not allowed during restore %L1</source>
      <translation variants="no">执行恢复期间无法进行视频通话</translation>
    </message>
    <message numerus="no" id="txt_phone_info_life_timer">
      <source>Life timer\n%L1</source>
      <translation variants="no">总定时器：
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_call_failed">
      <source>Emergency call failed %L1</source>
      <translation variants="no">紧急呼叫失败</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conference_call_active">
      <source>Conference call active</source>
      <translation variants="no">会议通话已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_barred">
      <source>Number barred %L1</source>
      <translation variants="no">号码被限制</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_own_number_sending">
      <source>Check own number sending %L1</source>
      <translation variants="no">请检查本机号码发送</translation>
    </message>
    <message numerus="no" id="txt_phone_info_send_string">
      <source>Send string:\n%L1</source>
      <translation variants="no">发送双音多频： %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_switched_off_or_out_of_3g">
      <source>Phone switched off or out of 3G coverage %L1</source>
      <translation variants="no">无法进行视频通话。对方设备关机或不在3G网络内。</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_barrings">
      <source>Note: you have active barrings</source>
      <translation variants="no">注意：呼叫限制已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_closed_group">
      <source>Number not in closed group %L1</source>
      <translation variants="no">zh #Number not in closed group %L1</translation>
    </message>
    <message numerus="no" id="txt_short_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">zh ##Telephone</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_share_video">
      <source>Share content</source>
      <translation variants="no">共享视频</translation>
    </message>
    <message numerus="no" id="txt_phone_other_conference_call">
      <source>Conference call</source>
      <translation variants="no">会议通话</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_on_hold">
      <source>On hold</source>
      <translation variants="no">zh #On hold</translation>
    </message>
    <message numerus="no" id="txt_phone_info_smartchip_not_allowed_mm_3">
      <source>Smartchip not allowed MM #3 </source>
      <translation variants="no">zh #Smartchip not allowed MM #3 </translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number %L1</source>
      <translation variants="no">手机号无效</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_not_allowed_fixed_dialling">
      <source>Call not allowed, fixed dialling active %L1</source>
      <translation variants="no">不允许拨号。当前正处于固定拨号模式。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_didnt_succeed_to_called">
      <source>Video call didn't succeed to called end %L1</source>
      <translation variants="no">无法进行视频通话。对方设备或网络不支持此功能。</translation>
    </message>
    <message numerus="no" id="txt_phone_other_private_number">
      <source>Private number</source>
      <translation variants="no">私人号码</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_busy">
      <source>Number busy %L1</source>
      <translation variants="no">号码占线</translation>
    </message>
    <message numerus="no" id="txt_phone_info_could_not_send_own_number">
      <source>Could not send own number %L1</source>
      <translation variants="no">无法发送本机号码</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending">
      <source>Sending\n%L1</source>
      <translation variants="no">正在发送
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_other_remote_sim">
      <source>Remote SIM</source>
      <translation variants="no">远程SIM卡</translation>
    </message>
  </context>
</TS>