<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_other_call_ln">
      <source>Call %L1</source>
      <translation variants="no">zh #Call %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_button_drop">
      <source>Drop</source>
      <translation variants="no">zh #Drop</translation>
    </message>
    <message numerus="no" id="txt_phone_other_attempting">
      <source>Attempting</source>
      <translation variants="no">zh #Attempting</translation>
    </message>
    <message numerus="no" id="txt_phone_other_on_hold">
      <source>On hold</source>
      <translation variants="no">zh #On hold</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_call">
      <source>Incoming call</source>
      <translation variants="no">zh #Incoming call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_swap">
      <source>Swap</source>
      <translation variants="no">zh #Swap</translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling">
      <source>Calling</source>
      <translation variants="no">zh #Calling</translation>
    </message>
    <message numerus="no" id="txt_phone_other_waiting">
      <source>Waiting</source>
      <translation variants="no">zh #Waiting</translation>
    </message>
    <message numerus="no" id="txt_phone_other_swipe_down_to_answer">
      <source>Swipe down to answer</source>
      <translation variants="no">zh #Swipe down to answer</translation>
    </message>
    <message numerus="no" id="txt_long_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">电话</translation>
    </message>
    <message numerus="no" id="txt_phone_button_replace_active_call">
      <source>Replace active call</source>
      <translation variants="no">zh #Replace active call</translation>
    </message>
    <message numerus="no" id="txt_phone_other_private_number">
      <source>Private number</source>
      <translation variants="no">zh #Private number</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_transfer">
      <source>Transfer</source>
      <translation variants="no">传送</translation>
    </message>
    <message numerus="no" id="txt_phone_title_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_opt_share_video">
      <source>Share video</source>
      <translation variants="no">共享视频</translation>
    </message>
    <message numerus="no" id="txt_phone_other_conference_call">
      <source>Conference call</source>
      <translation variants="no">zh #Conference call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_end_call">
      <source>End call</source>
      <translation variants="no">zh #End call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_hold">
      <source>Hold</source>
      <translation variants="no">zh #Hold</translation>
    </message>
    <message numerus="no" id="txt_phone_button_send_message">
      <source>Send message</source>
      <translation variants="yes">
        <lengthvariant priority="1">发送信息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_button_join">
      <source>Join</source>
      <translation variants="no">zh #Join</translation>
    </message>
    <message numerus="no" id="txt_phone_other_disconnected">
      <source>Disconnected</source>
      <translation variants="no">zh #Disconnected</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_ended">
      <source>Call ended</source>
      <translation variants="no">通话已断开</translation>
    </message>
    <message numerus="no" id="txt_phone_info_called_number_has_barred_incoming">
      <source>Called number has barred incoming calls</source>
      <translation variants="no">无法进行视频通话。对方手机已禁止来电。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_use">
      <source>Number not in use</source>
      <translation variants="no">此号码为空号</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_own_number_sending">
      <source>Check own number sending</source>
      <translation variants="no">请检查本机号码发送</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_terminated">
      <source>Call Terminated</source>
      <translation variants="no">通话报告</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_answer">
      <source>No answer</source>
      <translation variants="no">对方无应答</translation>
    </message>
    <message numerus="no" id="txt_phone_other_call">
      <source>Call</source>
      <translation variants="no">zh #Call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_send_string">
      <source>Send string:\n%L1</source>
      <translation variants="no">发送双音多频： %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_barred_in_closed_group">
      <source>Call barred in closed group</source>
      <translation variants="no">呼叫被限制在封闭用户组</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending_file_to_1">
      <source>Sending file to %L1</source>
      <translation variants="no">正在发送信息至%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_barrings">
      <source>Note: you have active barrings</source>
      <translation variants="no">注意：呼叫限制已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">仅紧急呼叫</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_busy">
      <source>Network busy</source>
      <translation variants="no">网络正忙</translation>
    </message>
    <message numerus="no" id="txt_phone_info_unable_to_make_video_call_not_supp">
      <source>Unable to make video call. Not supported by other phone or network.</source>
      <translation variants="no">无法进行视频通话。对方手机或网络不支持此功能。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_transfer_in_progress">
      <source>Transfer in progress</source>
      <translation variants="no">正在传送</translation>
    </message>
    <message numerus="no" id="txt_phone_info_could_not_send_own_number">
      <source>Could not send own number</source>
      <translation variants="no">无法发送本机号码</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_rf_loopback_enabled">
      <source>Bluetooth RF loopback enabled</source>
      <translation variants="no">蓝牙测试模式</translation>
    </message>
    <message numerus="no" id="txt_phone_info_closed_group_unknown">
      <source>Closed group unknown</source>
      <translation variants="no">未知封闭用户组</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected">
      <source>Connected</source>
      <translation variants="no">已连接</translation>
    </message>
    <message numerus="no" id="txt_phone_info_wlan_mac_address_1">
      <source>WLAN MAC address: %L1</source>
      <translation variants="no">WLAN MAC地址：%1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_select_closed_group">
      <source>Select closed group</source>
      <translation variants="no">选择封闭用户组</translation>
    </message>
    <message numerus="no" id="txt_phone_info_time">
      <source>Time</source>
      <translation variants="no">时间：</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_diverts">
      <source>Note:  you have active diverts</source>
      <translation variants="no">注意：来电转接已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_not_allowed_during_resto">
      <source>Video call not allowed during restore</source>
      <translation variants="no">执行恢复操作期间无法进行视频通话</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_network_services">
      <source>Check network services</source>
      <translation variants="no">请检查网络服务</translation>
    </message>
    <message numerus="no" id="txt_phone_info_transferred">
      <source>Transferred</source>
      <translation variants="no">已传送</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending">
      <source>Sending\n%L1</source>
      <translation variants="no">正在发送
〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃</translation>
    </message>
    <message numerus="no" id="txt_phone_other_remote_sim">
      <source>Remote SIM</source>
      <translation variants="no">zh #Remote SIM</translation>
    </message>
    <message numerus="no" id="txt_phone_info_videocall_only_possible_under_3g">
      <source>Videocall only possible under 3G coverage</source>
      <translation variants="no">视频通话在3G网络服务范围外不受支持</translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">手机号无效</translation>
    </message>
    <message numerus="no" id="txt_phone_info_life_timer">
      <source>Life timer\n%L1</source>
      <translation variants="no">总定时器：
〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃</translation>
    </message>
    <message numerus="no" id="txt_phone_info_serial_no">
      <source>Serial No.\n%L1</source>
      <translation variants="no">序列号：
〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃〃</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_rejected">
      <source>Call rejected</source>
      <translation variants="no">通话被拒绝</translation>
    </message>
    <message numerus="no" id="txt_phone_info_closed_group_1_in_use">
      <source>Closed group %L1 in use</source>
      <translation variants="no">封闭用户组%L1已使用</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_number_stored_in_location_1">
      <source>No number stored in location %L1</source>
      <translation variants="no">无号码存至SIM卡位置%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_not_allowed_fixed_dialling">
      <source>Call not allowed, fixed dialling active</source>
      <translation variants="no">不允许拨号。当前正处于固定拨号模式。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_closed_user_group">
      <source>Check closed user group</source>
      <translation variants="no">请检查封闭用户组</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_in_progress">
      <source>Call in progress</source>
      <translation variants="no">正在通话</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_call_failed">
      <source>Emergency call failed</source>
      <translation variants="no">紧急呼叫失败</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected_to_1">
      <source>Connected to %L1</source>
      <translation variants="no">已连接至%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_didnt_succeed_to_called">
      <source>Video call didn't succeed to called end</source>
      <translation variants="no">无法进行视频通话。对方手机或网络不支持此功能。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conference_call_active">
      <source>Conference call active</source>
      <translation variants="no">会议通话已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_network_support_for_video_call">
      <source>No network support for video call</source>
      <translation variants="no">网络不支持视频通话</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_no_network_coverage">
      <source>No network coverage</source>
      <translation variants="no">zh #No network coverage</translation>
    </message>
    <message numerus="no" id="txt_phone_button_silence">
      <source>Silence</source>
      <translation variants="no">zh #Silence</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_end_all_calls">
      <source>End all calls</source>
      <translation variants="no">结束所有通话</translation>
    </message>
    <message numerus="no" id="txt_phone_title_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">离线</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_switched_off_or_out_of_3g">
      <source>Phone switched off or out of 3G coverage</source>
      <translation variants="no">无法进行视频通话。对方手机已关机或位于3G网络服务范围外。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_rf_loopback_disabled">
      <source>Bluetooth RF loopback disabled</source>
      <translation variants="no">蓝牙测试模式</translation>
    </message>
    <message numerus="no" id="txt_phone_info_error_in_connection">
      <source>Error in connection</source>
      <translation variants="no">连接错误</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_busy">
      <source>Number busy</source>
      <translation variants="no">号码占线</translation>
    </message>
    <message numerus="no" id="txt_short_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">zh #Telephone</translation>
    </message>
    <message numerus="no" id="txt_phone_info_end_gprs_connection_first">
      <source>End GPRS connection first</source>
      <translation variants="no">请先断开分组数据连接</translation>
    </message>
    <message numerus="no" id="txt_phone_other_emergency_call">
      <source>Emergency call</source>
      <translation variants="no">zh #Emergency call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_setup_failed">
      <source>Video call setup failed</source>
      <translation variants="no">无法进行视频通话</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_barred">
      <source>Number barred</source>
      <translation variants="no">号码被限制</translation>
    </message>
    <message numerus="no" id="txt_phone_button_private">
      <source>Private</source>
      <translation variants="no">zh #Private</translation>
    </message>
    <message numerus="no" id="txt_phone_button_unlock">
      <source>Unlock</source>
      <translation variants="no">zh #Unlock</translation>
    </message>
    <message numerus="no" id="txt_phone_button_unhold">
      <source>Unhold</source>
      <translation variants="no">zh #Unhold</translation>
    </message>
    <message numerus="no" id="txt_phone_other_diverted_call">
      <source>Diverted call</source>
      <translation variants="no">zh #Diverted call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_closed_group">
      <source>Number not in closed group</source>
      <translation variants="no">此号码不属于封闭用户组</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_possible_in_this_group">
      <source>Service not possible in this group</source>
      <translation variants="no">在封闭用户组内无法使用此服务</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_all_incoming_calls_diver">
      <source>Note:  all incoming calls diverted</source>
      <translation variants="no">注意：全部来电被转接</translation>
    </message>
    <message numerus="no" id="txt_phone_info_tty_call_active_volume_control_not">
      <source>TTY call active. Volume control not available</source>
      <translation variants="no">使用聋哑人通讯器时无法控制音量</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_device_address_1">
      <source>Bluetooth device address: %L1</source>
      <translation variants="no">蓝牙设备地址：%1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_activate_own_number_sending">
      <source>Activate own number sending</source>
      <translation variants="no">本机号码发送启动</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">zh #Not allowed</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_diverting">
      <source>Diverting</source>
      <translation variants="no">正在转接</translation>
    </message>
  </context>
</TS>