<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_dpopinfo_no_network_coverage">
      <source>No network coverage</source>
      <translation variants="no">zh #No network coverage</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">zh #Not allowed</translation>
    </message>
    <message numerus="no" id="txt_phone_other_attempting">
      <source>Attempting</source>
      <translation variants="no">zh #Attempting emergency call</translation>
    </message>
    <message numerus="no" id="txt_phone_other_private_number">
      <source>Private number</source>
      <translation variants="no">zh #Private number</translation>
    </message>
    <message numerus="no" id="txt_phone_other_on_hold">
      <source>On hold</source>
      <translation variants="no">zh #on hold</translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling">
      <source>Calling</source>
      <translation variants="no">zh #Calling</translation>
    </message>
    <message numerus="no" id="txt_long_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">电话</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_transfer">
      <source>Transfer</source>
      <translation variants="no">传送</translation>
    </message>
    <message numerus="no" id="txt_phone_title_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_other_waiting">
      <source>Waiting</source>
      <translation variants="no">zh #waiting</translation>
    </message>
    <message numerus="no" id="txt_phone_info_called_number_has_barred_incoming">
      <source>Called number has barred incoming calls</source>
      <translation variants="no">无法进行视频通话。对方手机已禁止来电。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_use">
      <source>Number not in use</source>
      <translation variants="no">此号码为空号</translation>
    </message>
    <message numerus="no" id="txt_phone_info_could_not_send_own_number">
      <source>Could not send own number</source>
      <translation variants="no">无法发送本机号码</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_not_allowed_during_resto">
      <source>Video call not allowed during restore</source>
      <translation variants="no">执行恢复操作期间无法进行视频通话</translation>
    </message>
    <message numerus="no" id="txt_phone_info_life_timer">
      <source>Life timer\n%L1</source>
      <translation variants="no">总定时器：
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_call_failed">
      <source>Emergency call failed</source>
      <translation variants="no">紧急呼叫失败</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending">
      <source>Sending\n%L1</source>
      <translation variants="no">正在发送
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_other_remote_sim">
      <source>Remote SIM</source>
      <translation variants="no">zh #Remote SIM</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">仅紧急呼叫</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_busy">
      <source>Network busy</source>
      <translation variants="no">网络正忙</translation>
    </message>
    <message numerus="no" id="txt_phone_info_unable_to_make_video_call_not_supp">
      <source>Unable to make video call. Not supported by other phone or network.</source>
      <translation variants="no">无法进行视频通话。对方手机或网络不支持此功能。</translation>
    </message>
    <message numerus="no" id="txt_phone_dblist_ongoing_call">
      <source>Ongoing call</source>
      <translation variants="no">zh #Ongoing call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_videocall_only_possible_under_3g">
      <source>Videocall only possible under 3G coverage</source>
      <translation variants="no">视频通话在3G网络服务范围外不受支持</translation>
    </message>
    <message numerus="no" id="txt_phone_info_serial_no">
      <source>Serial No.\n%L1</source>
      <translation variants="no">序列号：
%1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected_to_1">
      <source>Connected to %L1</source>
      <translation variants="no">已连接至%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_send_string">
      <source>Send string:\n%L1</source>
      <translation variants="no">发送双音多频： %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_all_incoming_calls_diver">
      <source>Note:  all incoming calls diverted</source>
      <translation variants="no">注意：全部来电被转接</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_barrings">
      <source>Note: you have active barrings</source>
      <translation variants="no">注意：呼叫限制已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_other_emergency_call">
      <source>Emergency call</source>
      <translation variants="no">zh #Emergency call</translation>
    </message>
    <message numerus="yes" id="txt_phone_dblist_ln_missed_calls">
      <source>%Ln missed calls</source>
      <translation>
        <numerusform plurality="a">zh ##%Ln missed calls</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_barred">
      <source>Number barred</source>
      <translation variants="no">号码被限制</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_busy">
      <source>Number busy</source>
      <translation variants="no">号码占线</translation>
    </message>
    <message numerus="no" id="txt_phone_other_unknown_number">
      <source>Unknown number</source>
      <translation variants="no">zh #Unknown number</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_call">
      <source>Incoming call</source>
      <translation variants="no">zh #calling</translation>
    </message>
    <message numerus="no" id="txt_phone_info_error_in_connection">
      <source>Error in connection</source>
      <translation variants="no">连接错误</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_end_all_calls">
      <source>End all calls</source>
      <translation variants="no">结束所有通话</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_answer">
      <source>No answer</source>
      <translation variants="no">对方无应答</translation>
    </message>
    <message numerus="no" id="txt_phone_other_disconnected">
      <source>Disconnected</source>
      <translation variants="no">zh #disconnected</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conference_call_active">
      <source>Conference call active</source>
      <translation variants="no">会议通话已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_switched_off_or_out_of_3g">
      <source>Phone switched off or out of 3G coverage</source>
      <translation variants="no">无法进行视频通话。对方手机已关机或位于3G网络服务范围外。</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_diverting">
      <source>Diverting</source>
      <translation variants="no">正在转接</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_network_services">
      <source>Check network services</source>
      <translation variants="no">请检查网络服务</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_own_number_sending">
      <source>Check own number sending</source>
      <translation variants="no">请检查本机号码发送</translation>
    </message>
    <message numerus="no" id="txt_phone_info_activate_own_number_sending">
      <source>Activate own number sending</source>
      <translation variants="no">本机号码发送启动</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_share_video">
      <source>Share video</source>
      <translation variants="no">共享视频</translation>
    </message>
    <message numerus="no" id="txt_phone_other_conference_call">
      <source>Conference call</source>
      <translation variants="no">zh #Conference call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">手机号无效</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_not_allowed_fixed_dialling">
      <source>Call not allowed, fixed dialling active</source>
      <translation variants="no">不允许拨号。当前正处于固定拨号模式。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_didnt_succeed_to_called">
      <source>Video call didn't succeed to called end</source>
      <translation variants="no">无法进行视频通话。对方手机或网络不支持此功能。</translation>
    </message>
    <message numerus="no" id="txt_short_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">zh ##Telephone</translation>
    </message>
  </context>
</TS>