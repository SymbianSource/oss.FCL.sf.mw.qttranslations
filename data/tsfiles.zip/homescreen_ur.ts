<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_homescreen_opt_refresh">
      <source>Refresh</source>
      <translation variants="no">تازہ کاری کریں</translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_in_car_control">
      <source>In car control</source>
      <translation variants="yes">
        <lengthvariant priority="1">کار. متصل</lengthvariant>
        <lengthvariant priority="2">ur #Car kit conn.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_info_page_and_content_will_be_remov">
      <source>Page and content will be removed</source>
      <translation variants="no">ہوم اسکرین اور  اس کے مشمولات مٹا دیے جائیں گے۔ جاری رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_homescreen_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">منسوخ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">ٹھیک ہے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_no_service">
      <source>No service</source>
      <translation variants="yes">
        <lengthvariant priority="1">خدمت د. نہیں</lengthvariant>
        <lengthvariant priority="2">ur #No service</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_remove_page">
      <source>Remove page</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہوم اسکرین مٹائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_remove_page">
      <source>Remove page</source>
      <translation variants="no">ہوم اسکرین مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_clean_up_page">
      <source>Clean up page</source>
      <translation variants="no">خود نظمی مشمولات</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_add_page">
      <source>Add page</source>
      <translation variants="no">ہوم اسکرین شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_change_wallpaper">
      <source>Change wallpaper</source>
      <translation variants="no">وال پیپر بدلیں</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_change_wallpaper">
      <source>Change wallpaper</source>
      <translation variants="no">وال پیپر تبدیل کریں</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_home_screen_to_offline">
      <source>Home screen to offline</source>
      <translation variants="no">مشمو. آفلائن وضع پر</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_add_content">
      <source>Add content</source>
      <translation variants="no">مشمولات شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_home_screen_to_online">
      <source>Home screen to online</source>
      <translation variants="no">مشمو. آنلائن وضع پر</translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">آف لائن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_task_switcher">
      <source>Task switcher</source>
      <translation variants="no">مبدل افعال</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_add_page">
      <source>Add page</source>
      <translation variants="no">ہوم اسکرین شامل کریں</translation>
    </message>
  </context>
</TS>