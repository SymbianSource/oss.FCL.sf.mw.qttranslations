<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_none">
      <source>None</source>
      <translation variants="no">zh #None</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password_val_none">
      <source>None</source>
      <translation variants="no">zh #None</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password_val_prompt">
      <source>Prompt</source>
      <translation variants="no">zh #Prompt</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ip_settings">
      <source>IP settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #IP settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ipv6_settings">
      <source>IPv6 settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #IPv6 settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ipv4_settings">
      <source>IPv4 settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #IPv4 settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name">
      <source>User name</source>
      <translation variants="no">zh #User name</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_primary_name_server">
      <source>Primary name server</source>
      <translation variants="no">主DNS地址</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_secondary_name_server">
      <source>Secondary name server</source>
      <translation variants="no">次DNS地址</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_secondary_name_server_val_automat">
      <source>Automatic</source>
      <translation variants="no">自动</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_port_number_val_not_define">
      <source>(not defined)</source>
      <translation variants="no">(未定义)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_subnet_mask_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">(未定义)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status_val_hidden">
      <source>Hidden</source>
      <translation variants="no">隐性</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_open">
      <source>Open</source>
      <translation variants="no">打开</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_primary_name_server_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自动</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_homepage_val_none">
      <source>None</source>
      <translation variants="no">zh #None</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode">
      <source>WLAN network mode</source>
      <translation variants="no">WLAN模式</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_base_station_val_stay_in_fir">
      <source>Stay in first</source>
      <translation variants="no">使用最先找到的</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode_val_infrastruct">
      <source>Infrastructure</source>
      <translation variants="no">基础网络</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_default_gateway_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">(未定义)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wapi">
      <source>WAPI</source>
      <translation variants="no">WAPI</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpawpa2">
      <source>WPA/WPA2</source>
      <translation variants="no">WPA/WPA2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自动</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_name">
      <source>WLAN network name</source>
      <translation variants="no">WLAN名称</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_wellknown">
      <source>Well-known</source>
      <translation variants="no">熟知地址</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_proxy_settings">
      <source>Proxy settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">代理设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name_val_vpn">
      <source>VPN</source>
      <translation variants="no">zh #VPN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_server_address">
      <source>Proxy server address</source>
      <translation variants="no">代理服务器地址</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_port_number">
      <source>Proxy port number</source>
      <translation variants="no">代理端口号码</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode">
      <source>WLAN security mode</source>
      <translation variants="no">WLAN安全模式</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_subnet_mask">
      <source>Subnet mask</source>
      <translation variants="no">子网掩码</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_base_station_selection">
      <source>WLAN base station selection</source>
      <translation variants="no">WLAN站点选择</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode_val_adhoc">
      <source>Ad-hoc</source>
      <translation variants="no">特殊</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_adhoc_channel">
      <source>Ad-hoc channel</source>
      <translation variants="no">特殊频道</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_base_station_val_roam_to_bes">
      <source>Roam to best</source>
      <translation variants="no">漫游到信号最佳的</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status">
      <source>Network status</source>
      <translation variants="no">网络状态</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_default_gateway">
      <source>Default gateway</source>
      <translation variants="no">预设网关</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自动</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wep">
      <source>WEP</source>
      <translation variants="no">WEP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_homepage">
      <source>Homepage</source>
      <translation variants="no">主页</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses">
      <source>DNS addresses</source>
      <translation variants="no">DNS地址</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_server_address_val_not_def">
      <source>(not defined)</source>
      <translation variants="no">(未定义)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password">
      <source>Password</source>
      <translation variants="no">zh #Password</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">zh #Advanced settings</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication_val_normal">
      <source>Normal</source>
      <translation variants="no">zh #Normal</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication_val_secure">
      <source>Secure</source>
      <translation variants="no">zh #Secure</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication">
      <source>Authentication</source>
      <translation variants="no">zh #Authentication</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_phone_ip_address">
      <source>Phone IP address</source>
      <translation variants="no">手机IP地址</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status_val_public">
      <source>Public</source>
      <translation variants="no">公共</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_access_point_name">
      <source>Access point name</source>
      <translation variants="no">zh #Access point name</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name">
      <source>Connection name</source>
      <translation variants="no">连接名称</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_access_point_settings">
      <source>Access point settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">接入点设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name_val_connection">
      <source>Connection</source>
      <translation variants="no">zh #Connection</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_adhoc_channel_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自动</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpa2_only">
      <source>WPA2 only</source>
      <translation variants="no">仅WPA2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_8021x">
      <source>802.1X</source>
      <translation variants="no">802.1X</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_user_defined">
      <source>User defined</source>
      <translation variants="no">用户自定义</translation>
    </message>
  </context>
</TS>