<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="text_flite_error_in_version">
      <source>Flash Version %L1 not supported.</source>
      <translation variants="no">不支持Flash版本%L1</translation>
    </message>
    <message numerus="no" id="text_flite_option_about">
      <source>About</source>
      <translation variants="no">关于此程序</translation>
    </message>
    <message numerus="no" id="text_flite_error_not_authorized">
      <source>Flash Player not supported by the device</source>
      <translation variants="no">设备不支持Flash播放器</translation>
    </message>
    <message numerus="no" id="text_flite_plugin_tip_fullscreen">
      <source>Click on video to watch full screen</source>
      <translation variants="no">长按视频以在全屏模式下播放</translation>
    </message>
    <message numerus="no" id="text_flite_error_in_content">
      <source>Flash content Error</source>
      <translation variants="no">Flash内容错误</translation>
    </message>
    <message numerus="no" id="text_flite_plugin_fullscreen">
      <source>FullScreen</source>
      <translation variants="no">全屏</translation>
    </message>
    <message numerus="no" id="text_flite_plugin_normalscreen">
      <source>Normal screen</source>
      <translation variants="no">标准屏幕</translation>
    </message>
    <message numerus="no" id="text_flite_plugin_note_iad_update_complete">
      <source>Restart browser for the update to take effect</source>
      <translation variants="no">重新启动浏览器后更新才能生效</translation>
    </message>
    <message numerus="no" id="text_flite_query_trust">
      <source>Allow application to access %1. Application will be restarted?</source>
      <translation variants="no">允许应用程序访问域%[52]1？应用程序将重新启动。</translation>
    </message>
    <message numerus="no" id="txt_flashplugin_menu_unmute">
      <source>Unmute</source>
      <translation variants="no">取消静音</translation>
    </message>
    <message numerus="no" id="txt_flashplugin_menu_mute">
      <source>Mute</source>
      <translation variants="no">静音</translation>
    </message>
    <message numerus="no" id="text_flite_plugin_tip_normalscreen">
      <source>Click on video to go back to Normal screen</source>
      <translation variants="no">长按视频以在标准屏幕模式下播放</translation>
    </message>
    <message numerus="no" id="text_flite_query_network_access">
      <source>The current Flash content needs a network connection. Accept?</source>
      <translation variants="no">允许Flash内容建立网络连接？</translation>
    </message>
    <message numerus="no" id="text_flite_option_about_text">
      <source>Contains Adobe Flash® Lite ™ 4.0\n ©1995-2010 Adobe Macromedia Software LLC.\nAll rights reserved.</source>
      <translation variants="no">包含Adobe® Flash® Lite™ 4.0 © 1995-2010 Adobe Macromedia Software LLC。保留所有权利。</translation>
    </message>
  </context>
</TS>