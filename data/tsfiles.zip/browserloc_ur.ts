<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_browser_tag_error_tag_file_could_not_be_downloaded">
      <source>Error: %1 could not be downloaded</source>
      <translation variants="no">%[99]1' ڈاون لوڈ کرنے سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection">
      <source>%1 is now in range.  Switch connection?</source>
      <translation variants="no">%[99]1اب حد میں ہے۔ اتصال تبدیل کریں؟</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_image_save_image">
      <source>Save Image</source>
      <translation variants="no">شبیہ حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_history">
      <source>History</source>
      <translation variants="no">تفصیل</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_browser">
      <source>Browser</source>
      <translation variants="no">براؤزر</translation>
    </message>
    <message numerus="no" id="txt_browser_windows_windows">
      <source>Windows</source>
      <translation variants="no">ونڈو</translation>
    </message>
    <message numerus="no" id="txt_browser_history_this_month">
      <source>This Month</source>
      <translation variants="no">یہ مہینہ</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_cancel">
      <source>Cancel</source>
      <translation variants="no">منسوخ کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_navigation">
      <source>Navigation</source>
      <translation variants="no">نیویگیشن</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_link_open_link">
      <source>Open Link in New Window</source>
      <translation variants="no">نئی ونڈو میں لنک/ربط کھولیں</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_windows">
      <source>Windows</source>
      <translation variants="no">ونڈو</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_cookies">
      <source>Cookies</source>
      <translation variants="no">کوکیز</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_allow_popups">
      <source>Allow Pop-ups</source>
      <translation variants="no">پاپ اپ کی اجازت دیں</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_all">
      <source>Clear All</source>
      <translation variants="no">سب کو صاف کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings">
      <source>General Settings</source>
      <translation variants="no">عام ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_browser_windows_new_window">
      <source>New Window</source>
      <translation variants="no">نئی ونڈو</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_share">
      <source>Share</source>
      <translation variants="no">شرکت کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_exit">
      <source>Exit Browser</source>
      <translation variants="no">براؤزر سے باہر نکلیں</translation>
    </message>
    <message numerus="no" id="txt_short_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">براؤزر</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_save_browser_history">
      <source>Save Browser History</source>
      <translation variants="no">تفصیل حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_long_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">براؤزر</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_settings">
      <source>Settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_link">
      <source>Link</source>
      <translation variants="no">لنک</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">نشانات کتاب</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_image">
      <source>Image</source>
      <translation variants="no">شبیہ</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_link_share_link">
      <source>Share Link</source>
      <translation variants="no">لنک میں شرکت کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_link_image">
      <source>Link/Image</source>
      <translation variants="no">شبیہ لنکس</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data">
      <source>Clear Data</source>
      <translation variants="no">ڈیٹا صاف کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_cache">
      <source>Cache</source>
      <translation variants="no">مخفی حافظہ</translation>
    </message>
    <message numerus="no" id="txt_browser_file_has_finished_downloading">
      <source>%1 has finished downloading</source>
      <translation variants="no">ڈاؤن لوڈ مکمل: %1</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding">
      <source>Character Encoding</source>
      <translation variants="no">حروف رمز نگاری</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_yes">
      <source>Yes</source>
      <translation variants="no">ہاں</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_done">
      <source>Done</source>
      <translation variants="no">مکمل کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_save_forms_passwords">
      <source>Save Forms/Passwords</source>
      <translation variants="no">شکلیں اور الفاظ شناخت حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_history_delete_are_you_sure">
      <source>Are you sure you want to permanently delete your history?</source>
      <translation variants="no">تفصیل مستقل طور پر مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">نشانات کتاب</translation>
    </message>
    <message numerus="no" id="txt_browser_history_history">
      <source>History</source>
      <translation variants="no">تفصیل</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_settings">
      <source>Settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_browser_history_today">
      <source>Today</source>
      <translation variants="no">آج</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_no">
      <source>No</source>
      <translation variants="no">نہیں</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_history">
      <source>History</source>
      <translation variants="no">تفصیل</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_add_bookmark">
      <source>Add Bookmark</source>
      <translation variants="no">نشانی کتاب شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_history_yesterday">
      <source>Yesterday</source>
      <translation variants="no">گزشتہ کل</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">نشانات کتاب</translation>
    </message>
    <message numerus="no" id="txt_browser_downloading_file">
      <source>Downloading %1</source>
      <translation variants="no">%1 کی ڈاؤن لوڈنگ جاری</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding_automatic">
      <source>Automatic</source>
      <translation variants="no">خود کار</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_page">
      <source>Page</source>
      <translation variants="no">صفحہ</translation>
    </message>
    <message numerus="no" id="txt_browser_history_this_week">
      <source>This Week</source>
      <translation variants="no">یہ ہفتہ</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">براؤزر</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding_unicode">
      <source>Unicode</source>
      <translation variants="no">یک رمزی</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_form_data">
      <source>Form Data</source>
      <translation variants="no">فام ڈیٹا</translation>
    </message>
    <message numerus="no" id="txt_browser_error_page_load_failed">
      <source>Unable to load page</source>
      <translation variants="no">صفحہ لوڈ کرنے سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_browser_chrome_suggests_search_for">
      <source>Search for %1</source>
      <translation variants="no">%1 کی تلاش کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_error_generic_error_msg">
      <source>Network error</source>
      <translation variants="no">نیٹ ورک کی غلطی</translation>
    </message>
    <message numerus="no" id="txt_browser_offline">
      <source>Offline</source>
      <translation variants="no">آف لائن</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_new_window">
      <source>New Window</source>
      <translation variants="no">نئی ونڈو</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_about">
      <source>About Browser</source>
      <translation variants="no">براؤزر سے متعلق</translation>
    </message>
    <message numerus="no" id="txt_browser_input_dial_add_bm">
      <source>Add Bookmark</source>
      <translation variants="no">نشانی کتاب شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_block_popups">
      <source>Block Popups</source>
      <translation variants="no">پاپ اپ بلاک کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_input_dial_edit_bm">
      <source>Edit Bookmark</source>
      <translation variants="no">شانی کتاب میں ترمیم کریں</translation>
    </message>
    <message numerus="no" id="txt_browser_most_visited_title_most_visited">
      <source>Most Visited</source>
      <translation variants="no">سب سے زیادہ دیکھا گیا</translation>
    </message>
    <message numerus="no" id="txt_browser_error_dialog_close_some">
      <source>Close some browser windows or applications.</source>
      <translation variants="no">کچھ براؤزر ونڈو یا پروگراموں کو بند کریں۔</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection_yes">
      <source>Yes</source>
      <translation variants="no">ہاں</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection_no">
      <source>No</source>
      <translation variants="no">نہیں</translation>
    </message>
    <message numerus="no" id="txt_browser_error_dialog_device_low">
      <source>Device Low On Memory</source>
      <translation variants="no">آلہ حافظہ کم ہے۔</translation>
    </message>
  </context>
</TS>