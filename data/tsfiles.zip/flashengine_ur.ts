<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="text_flite_mmc_access_error">
      <source>Memory card cannot be accessed. Operation will terminate</source>
      <translation variants="no">ur #Memory card cannot be accessed. Operation will terminate</translation>
    </message>
    <message numerus="no" id="text_flite_error_insert_memory_card">
      <source>Not enough memory to play selected video. Insert memory card and play again</source>
      <translation variants="no">ur #Not enough memory to play selected video. Insert memory card and play again</translation>
    </message>
    <message numerus="no" id="text_flite_note_insufficient_memory_mmc_needed">
      <source>Phone memory not sufficient, memory card required for optimal playback</source>
      <translation variants="no">ur #Phone memory not sufficient, memory card required for optimal playback</translation>
    </message>
    <message numerus="no" id="text_flite_error_video_too_large">
      <source>Video memory requirements exceed phone capacity. Video will terminate</source>
      <translation variants="no">ur #Video memory requirements exceed phone capacity. Video will terminate</translation>
    </message>
    <message numerus="no" id="text_flite_error_not_enough_memory_video_terminates">
      <source>Memory card full.Video will terminate.Delete some data and play again</source>
      <translation variants="no">ur #Memory card full.Video will terminate.Delete some data and play again</translation>
    </message>
    <message numerus="no" id="text_flite_note_mmc_memory_low">
      <source>For optimal playback, delete some data from memory card</source>
      <translation variants="no">ur #For optimal playback, delete some data from memory card</translation>
    </message>
  </context>
</TS>