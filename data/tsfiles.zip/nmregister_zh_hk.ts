<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_widget_l_dblist_preview_of_recent_mail">
      <source>Preview of recent mail</source>
      <translation variants="no">最近電郵預覽</translation>
    </message>
    <message numerus="no" id="txt_mail_widget_dblist_preview_of_recent_mail">
      <source>Preview of recent mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近電郵預覽</lengthvariant>
      </translation>
    </message>
  </context>
</TS>