<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_authentication">
      <source>Authentication</source>
      <translation variants="no">ur ##Authentication</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_access_point_name">
      <source>Access point name</source>
      <translation variants="no">ur ##Access point name</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication_val_normal">
      <source>Normal</source>
      <translation variants="no">ur ##Normal</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication_val_secure">
      <source>Secure</source>
      <translation variants="no">ur ##Secure</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_none">
      <source>None</source>
      <translation variants="no">ur ##None</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password_val_none">
      <source>None</source>
      <translation variants="no">ur ##None</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password_val_prompt">
      <source>Prompt</source>
      <translation variants="no">ur ##Prompt</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ipv4_settings">
      <source>IPv4 settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##IPv4 settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name">
      <source>User name</source>
      <translation variants="no">ur ##User name</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password">
      <source>Password</source>
      <translation variants="no">ur ##Password</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">ur ##Advanced settings</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_primary_name_server">
      <source>Primary name server</source>
      <translation variants="no">ابتدائی DNS پتہ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_secondary_name_server">
      <source>Secondary name server</source>
      <translation variants="no">ثانوی DNS پتہ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_default_gateway_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">(وضاحت شدہ نہیں)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_secondary_name_server_val_automat">
      <source>Automatic</source>
      <translation variants="no">خودبخود</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_port_number_val_not_define">
      <source>(not defined)</source>
      <translation variants="no">(وضاحت شدہ نہیں)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_automatic">
      <source>Automatic</source>
      <translation variants="no">خودبخود</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_subnet_mask_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">(وضاحت شدہ نہیں)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_base_station_selection">
      <source>WLAN base station selection</source>
      <translation variants="no">WLAN اسٹیشن کا انتخاب</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_default_gateway">
      <source>Default gateway</source>
      <translation variants="no">آغازی گیٹ وے</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_base_station_val_roam_to_bes">
      <source>Roam to best</source>
      <translation variants="no">بہترین پر رومنگ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_automatic">
      <source>Automatic</source>
      <translation variants="no">خودبخود</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wep">
      <source>WEP</source>
      <translation variants="no">WEP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_server_address_val_not_def">
      <source>(not defined)</source>
      <translation variants="no">(وضاحت شدہ نہیں)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_open">
      <source>Open</source>
      <translation variants="no">کھولیں</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_primary_name_server_val_automatic">
      <source>Automatic</source>
      <translation variants="no">خودبخود</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode">
      <source>WLAN network mode</source>
      <translation variants="no">WLAN وضع</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpawpa2">
      <source>WPA/WPA2</source>
      <translation variants="no">WPA/WPA۲</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_wellknown">
      <source>Well-known</source>
      <translation variants="no">معروف</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_homepage_val_none">
      <source>None</source>
      <translation variants="no">ur ##None</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name_val_connection">
      <source>Connection</source>
      <translation variants="no">ur ##Connection</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_adhoc_channel_val_automatic">
      <source>Automatic</source>
      <translation variants="no">خودبخود</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_port_number">
      <source>Proxy port number</source>
      <translation variants="no">پراکسی پورٹ نمبر</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode">
      <source>WLAN security mode</source>
      <translation variants="no">WLAN حفاظتی وضع</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpa2_only">
      <source>WPA2 only</source>
      <translation variants="no">صرف WPA۲</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_8021x">
      <source>802.1X</source>
      <translation variants="no">۸۰۲.۱X</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_adhoc_channel">
      <source>Ad-hoc channel</source>
      <translation variants="no">عارضی چینل</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wapi">
      <source>WAPI</source>
      <translation variants="no">WAPI</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name_val_vpn">
      <source>VPN</source>
      <translation variants="no">ur ##VPN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode_val_adhoc">
      <source>Ad-hoc</source>
      <translation variants="no">عارضی</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_access_point_settings">
      <source>Access point settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">نقطہ رسائی ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name">
      <source>Connection name</source>
      <translation variants="no">اتصال کا نام</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ipv6_settings">
      <source>IPv6 settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##IPv6 settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status_val_public">
      <source>Public</source>
      <translation variants="no">عوامی</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_phone_ip_address">
      <source>Phone IP address</source>
      <translation variants="no">فون IP پتہ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status_val_hidden">
      <source>Hidden</source>
      <translation variants="no">چھپا ہوا</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_user_defined">
      <source>User defined</source>
      <translation variants="no">صارف کا وضاحت کردہ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode_val_infrastruct">
      <source>Infrastructure</source>
      <translation variants="no">بنیادی ساخت</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_base_station_val_stay_in_fir">
      <source>Stay in first</source>
      <translation variants="no">پہلے پر رکیں</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_proxy_settings">
      <source>Proxy settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">پراکسی ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_server_address">
      <source>Proxy server address</source>
      <translation variants="no">پراکسی سرور پتہ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_name">
      <source>WLAN network name</source>
      <translation variants="no">WLAN کا نام</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_subnet_mask">
      <source>Subnet mask</source>
      <translation variants="no">ذیلی نیٹ ماسکہ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status">
      <source>Network status</source>
      <translation variants="no">نیٹ ورک کی حیثیت</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses">
      <source>DNS addresses</source>
      <translation variants="no">DNS پتے</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ip_settings">
      <source>IP settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##IP settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_homepage">
      <source>Homepage</source>
      <translation variants="no">بنیادی صفحہ</translation>
    </message>
  </context>
</TS>