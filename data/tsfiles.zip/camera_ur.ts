<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cam_title_geotagging">
      <source>Geotagging</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Geotagging</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_169_widescreen">
      <source>VGA 16:9 widescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #VGA 16:9 widescreen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode_video">
      <source>Scene mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Scene mode</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_geotagging_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene_video">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Automatic</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_camera">
      <source>Camera</source>
      <translation variants="no">ur #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_grid_sharpness">
      <source>Sharpness</source>
      <translation variants="no">ur #Sharpness</translation>
    </message>
    <message numerus="no" id="txt_cam_list_flash_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_flash_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #On</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_fullscreen_imagesleft">
      <source>%L1</source>
      <translation variants="no">ur #%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_title_sharpness">
      <source>Sharpness</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Sharpness</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_contrast">
      <source>Contrast</source>
      <translation variants="yes">
        <lengthvariant priority="1">تضاد</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sports">
      <source>Sports</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Sport</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode">
      <source>Camera in stand-by mode</source>
      <translation variants="no">کیمرا اسٹینڈ بائی پر ہے</translation>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="yes">
        <lengthvariant priority="1">اکسپوژر توازن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_landscape">
      <source>Landscape</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Landscape</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_never">
      <source>Never</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Never</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_portrait">
      <source>Portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings">
      <source>Camera settings</source>
      <translation variants="no">کیمرا ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_short_caption_camera">
      <source>Camera</source>
      <translation variants="no">ur #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_video">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">رات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">منسوخ کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">صارف واضح کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">مسلسل</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds">
      <source>%Ln seconds</source>
      <translation>
        <numerusform plurality="a">%Ln سیک</numerusform>
        <numerusform plurality="b">%Ln سیکنڈ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image">
      <source>Delete image?</source>
      <translation variants="no">شبیہ مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip">
      <source>Delete video clip?</source>
      <translation variants="no">ویڈیو کلپ مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_cam_list_white">
      <source>Black and white</source>
      <translation variants="yes">
        <lengthvariant priority="1">سیاہ و سفید</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_night">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">رات</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left">
      <source>%Ln images left</source>
      <translation>
        <numerusform plurality="a">باقی %Ln شبیہ</numerusform>
        <numerusform plurality="b">%Ln شبیہات باقی ہیں</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer">
      <source>Self timer</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار ٹائمر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_whitebal">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_start">
      <source>Start</source>
      <translation variants="yes">
        <lengthvariant priority="1">شروع کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings">
      <source>General settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_flash">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_contrast">
      <source>Contrast</source>
      <translation variants="no">ur #Contrast</translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality">
      <source>Image quality</source>
      <translation variants="yes">
        <lengthvariant priority="1">شبیہ کا معیار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">مسلسل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_negative">
      <source>Negative</source>
      <translation variants="yes">
        <lengthvariant priority="1">منفی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality">
      <source>Video quality</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویڈیو کا معیار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality">
      <source>Video quality</source>
      <translation variants="no">ویڈیو کا معیار</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_169_widescreen">
      <source>HD 720p 16:9 widescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">۷۲۰HD پکسل۱۶:۹چوڑا اسکرین</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_val_ln_recording_time_left">
      <source>Recording time left: %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">بچا ہوا ریکارڈنگ کا وقت: %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance">
      <source>White balance</source>
      <translation variants="yes">
        <lengthvariant priority="1">سفیدی کا توازن</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln سیک</numerusform>
        <numerusform plurality="b">%Ln سیکنڈ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_not_video">
      <source>Not</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_incandescent">
      <source>Incandescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">تاباں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_geotagging">
      <source>Geotagging</source>
      <translation variants="no">ur #Geotagging</translation>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity">
      <source>Light sensitivity</source>
      <translation variants="yes">
        <lengthvariant priority="1">روشنی کی حساسیت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_closeup">
      <source>Close-up</source>
      <translation variants="yes">
        <lengthvariant priority="1">کلوز اپ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sunny">
      <source>Sunny</source>
      <translation variants="yes">
        <lengthvariant priority="1">دھوپ دار</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln سیک</numerusform>
        <numerusform plurality="b">%Ln سیکنڈ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">ur #Exposure compensation</translation>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone">
      <source>Color tone</source>
      <translation variants="no">ur #Colour tone</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_timer">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name">
      <source>Default image name</source>
      <translation variants="no">آغازی شبیہ کا نام</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_43">
      <source>VGA 4:3</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA ۴:۳</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_qcif_sharing">
      <source>QCIF Sharing</source>
      <translation variants="yes">
        <lengthvariant priority="1">QCIF اشتراک</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_fluorescent">
      <source>Fluorescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">فلوریسنٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality">
      <source>Image quality</source>
      <translation variants="no">شبیہ کا معیار</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga">
      <source>VGA</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance">
      <source>White balance</source>
      <translation variants="no">ur #White balance</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sepia">
      <source>Sepia</source>
      <translation variants="yes">
        <lengthvariant priority="1">سرخی مائل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">شبیہ دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos">
      <source>Go to 'Videos'</source>
      <translation variants="no">ویڈیو کلپس</translation>
    </message>
    <message numerus="no" id="txt_cam_list_scene_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #On</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_lightsens">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone">
      <source>Color tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">رنگ کی ٹون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_iso_l1">
      <source>ISO %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #ISO %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_cloudy">
      <source>Cloudy</source>
      <translation variants="yes">
        <lengthvariant priority="1">ابر آلود</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video">
      <source>Show captured video</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھینچا گیا ویڈیو دکھائیں</lengthvariant>
        <lengthvariant priority="2">کھینچا ویڈیو دکھائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking">
      <source>Face tracking</source>
      <translation variants="no">ur #Face detection</translation>
    </message>
    <message numerus="no" id="txt_cam_list_vivid">
      <source>Vivid</source>
      <translation variants="yes">
        <lengthvariant priority="1">واضح</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus">
      <source>-%L1</source>
      <translation variants="no">-%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_portrait">
      <source>Night portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Night portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">ویڈیو دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_cam_list_reduce_red_eye">
      <source>Reduce red eye</source>
      <translation variants="yes">
        <lengthvariant priority="1">سرخ چشم تخفیف</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_camera">
      <source>Camera</source>
      <translation variants="no">کیمرا</translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode">
      <source>Scene mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">منظر وضع</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image">
      <source>Show captured image</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھینچی شبیہ دکھائیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_iso">
      <source>ISO</source>
      <translation variants="no">ur #ISO</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name">
      <source>Default video name</source>
      <translation variants="no">آغازی ویڈیو کا نام</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">کیمرا</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix">
      <source>%Ln Mpix</source>
      <translation>
        <numerusform plurality="a">%Ln میگاپکسل</numerusform>
        <numerusform plurality="b">%Ln میگاپکسلس</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_set_as_default_scene_mode">
      <source>Set as default scene mode</source>
      <translation variants="no">آغازی منظر وضع مرتب</translation>
    </message>
    <message numerus="no" id="txt_cam_list_normal">
      <source>Normal</source>
      <translation variants="yes">
        <lengthvariant priority="1">عام</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix_widescreen">
      <source>%Ln Mpix widescreen</source>
      <translation>
        <numerusform plurality="a">%Lnم. پکسل چوڑا اسکرین</numerusform>
        <numerusform plurality="b">%Lnمیگاپکسلس چوڑا اسکرین</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">کھینچنے کی ٹون</translation>
    </message>
    <message numerus="no" id="txt_cam_list_geotagging_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #On</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer">
      <source>Self timer</source>
      <translation variants="no">خود کار ٹائمر</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos">
      <source>Go to Photos</source>
      <translation variants="no">تصاویر</translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus">
      <source>+%L1</source>
      <translation variants="no">+%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode">
      <source>Flash mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">فلیش</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound">
      <source>Video sound</source>
      <translation variants="no">ویڈیو کی آواز</translation>
    </message>
    <message numerus="no" id="txt_cam_list_low_light">
      <source>Low light</source>
      <translation variants="yes">
        <lengthvariant priority="1">کم روشنی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use">
      <source>Camera already in use</source>
      <translation variants="no">کیمرے پہلے سے دوسرے پروگرام میں زیر استعمال</translation>
    </message>
    <message numerus="no" id="txt_cam_list_scene_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_error">
      <source>Unexpected error occurred. Power off the device and restart</source>
      <translation variants="no">غیر متوقع غلطی واقع ہوئی۔ فون دوبارہ شروع کریں۔</translation>
    </message>
  </context>
</TS>