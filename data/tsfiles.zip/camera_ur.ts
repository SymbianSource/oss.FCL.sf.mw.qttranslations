<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cam_list_night_portrait">
      <source>Night portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Night portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sports">
      <source>Sports</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Sport</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_portrait">
      <source>Portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer">
      <source>Self timer</source>
      <translation variants="no">خود کار ٹائمر</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos">
      <source>Go to Photos</source>
      <translation variants="no">تصاویر</translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode">
      <source>Camera in stand-by mode</source>
      <translation variants="no">کیمرا اسٹینڈ بائی پر ہے</translation>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">اکسپوژر توازن</translation>
    </message>
    <message numerus="no" id="txt_cam_list_landscape">
      <source>Landscape</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Landscape</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings">
      <source>Camera settings</source>
      <translation variants="no">کیمرا ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_stabilization">
      <source>Video stabilization</source>
      <translation variants="no">ویڈیو استحکام</translation>
    </message>
    <message numerus="no" id="txt_short_caption_camera">
      <source>Camera</source>
      <translation variants="no">ur #Camera</translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln سیک</numerusform>
        <numerusform plurality="b">%Ln سیکنڈ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">ur #Exposure compensation</translation>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone">
      <source>Color tone</source>
      <translation variants="no">ur #Colour tone</translation>
    </message>
    <message numerus="no" id="txt_cam_title_memory_in_use">
      <source>Memory in use</source>
      <translation variants="no">زیر استعمال حافظہ</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_video">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_video">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">رات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_43">
      <source>VGA 4:3</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA ۴:۳</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_memory_in_use">
      <source>Memory in use</source>
      <translation variants="no">زیر استعمال حافظہ</translation>
    </message>
    <message numerus="no" id="txt_cam_button_cancel">
      <source>Cancel</source>
      <translation variants="no">منسوخ کریں</translation>
    </message>
    <message numerus="no" id="txt_cam_other_please_type_here">
      <source>Please type here</source>
      <translation variants="no">یہاں ٹائپ کریں</translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_image_name">
      <source>Default image name</source>
      <translation variants="no">آغازی شبیہ کا نام</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_qcif_sharing">
      <source>QCIF Sharing</source>
      <translation variants="yes">
        <lengthvariant priority="1">QCIF اشتراک</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_memory_card">
      <source>Memory card</source>
      <translation variants="yes">
        <lengthvariant priority="1">حافظہ کارڈ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_face">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">صارف واضح کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_sound">
      <source>Video sound</source>
      <translation variants="no">ویڈیو کی آواز</translation>
    </message>
    <message numerus="no" id="txt_cam_other_default_image_name">
      <source>Default image name</source>
      <translation variants="no">آغازی شبیہ کا نام</translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">مسلسل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga">
      <source>VGA</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance">
      <source>White balance</source>
      <translation variants="no">ur #White balance</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">شبیہ دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image">
      <source>Delete image?</source>
      <translation variants="no">شبیہ مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_image">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_lightsens">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">ویڈیو دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_stabil">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus">
      <source>+%L1</source>
      <translation variants="no">+%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_list_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">تاریخ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode">
      <source>Flash mode</source>
      <translation variants="no">فلیش</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_video">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound">
      <source>Video sound</source>
      <translation variants="no">ویڈیو کی آواز</translation>
    </message>
    <message numerus="no" id="txt_cam_title_change_mode">
      <source>Change mode</source>
      <translation variants="no">تبدیلی وضع</translation>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camcorder">
      <source>Secondary camcorder</source>
      <translation variants="yes">
        <lengthvariant priority="1">ثانوی ویڈیو کیمرا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip">
      <source>Delete video clip?</source>
      <translation variants="no">ویڈیو کلپ مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_flash">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_flash">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds">
      <source>%Ln seconds</source>
      <translation>
        <numerusform plurality="a">%Ln سیک</numerusform>
        <numerusform plurality="b">%Ln سیکنڈ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_start">
      <source>Start</source>
      <translation variants="no">شروع کریں</translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_stabilization">
      <source>Video stabilization</source>
      <translation variants="no">ویڈیو استحکام</translation>
    </message>
    <message numerus="no" id="txt_cam_list_reduce_red_eye">
      <source>Reduce red eye</source>
      <translation variants="yes">
        <lengthvariant priority="1">سرخ چشم تخفیف</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_set_as_default_scene_mode">
      <source>Set as default scene mode</source>
      <translation variants="no">آغازی منظر وضع مرتب</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_geotagging">
      <source>Geotagging</source>
      <translation variants="no">جیوٹیگنگ</translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_rotation">
      <source>Image rotation</source>
      <translation variants="no">شبیہ کو گھمائیں</translation>
    </message>
    <message numerus="no" id="txt_cam_list_incandescent">
      <source>Incandescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">تاباں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">مسلسل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_white">
      <source>Black and white</source>
      <translation variants="yes">
        <lengthvariant priority="1">سیاہ و سفید</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">کیمرا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_contrast">
      <source>Contrast</source>
      <translation variants="no">ur #Contrast</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_scene">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality">
      <source>Image quality</source>
      <translation variants="no">شبیہ کا معیار</translation>
    </message>
    <message numerus="no" id="txt_cam_other_restore_settings">
      <source>Restore settings?</source>
      <translation variants="no">ترتیبات بحال کریں؟</translation>
    </message>
    <message numerus="no" id="txt_cam_button_geotagging">
      <source>Geotagging</source>
      <translation variants="no">ur #Geotagging</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_rotation">
      <source>Image rotation</source>
      <translation variants="no">شبیہ گھمانا</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">رات</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left">
      <source>%Ln images left</source>
      <translation>
        <numerusform plurality="a">باقی %Ln شبیہ</numerusform>
        <numerusform plurality="b">%Ln شبیہات باقی ہیں</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_low_light">
      <source>Low light</source>
      <translation variants="yes">
        <lengthvariant priority="1">کم روشنی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_video">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہاں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">کھینچنے کی ٹون</translation>
    </message>
    <message numerus="no" id="txt_long_caption_camera ">
      <source>Camera</source>
      <translation variants="no">کیمرا</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_phone_memory">
      <source>Phone memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">فون حافظہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_face_tracking">
      <source>Face tracking</source>
      <translation variants="no">چہرے کا سراغ</translation>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer">
      <source>Self timer</source>
      <translation variants="no">خودکار ٹائمر</translation>
    </message>
    <message numerus="no" id="txt_cam_list_negative">
      <source>Negative</source>
      <translation variants="yes">
        <lengthvariant priority="1">منفی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_no_memory_card_in_device_please_inse">
      <source>No memory card in device. Please insert memory card in order to capture images.</source>
      <translation variants="no">کوئی حافظہ کارڈ داخل نہیں کیا گیا۔ شبیہ کھینچنے کے لیے حافظہ کارڈ داخل کریں۔</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings">
      <source>General settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_rotate">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہاں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_169_widescreen">
      <source>HD 720p 16:9 widescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">۷۲۰HD پکسل۱۶:۹چوڑا اسکرین</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity">
      <source>Light sensitivity</source>
      <translation variants="no">روشنی کی حساسیت</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_video">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_image">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہاں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_rotate">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_stabil">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">چالو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_iso">
      <source>ISO</source>
      <translation variants="no">ur #ISO</translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use">
      <source>Camera already in use</source>
      <translation variants="no">کیمرے پہلے سے دوسرے پروگرام میں زیر استعمال</translation>
    </message>
    <message numerus="no" id="txt_cam_list_closeup">
      <source>Close-up</source>
      <translation variants="yes">
        <lengthvariant priority="1">کلوز اپ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name">
      <source>Default video name</source>
      <translation variants="no">آغازی ویڈیو کا نام</translation>
    </message>
    <message numerus="no" id="txt_cam_caption_camera">
      <source>Camera</source>
      <translation variants="no">ur #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_face">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance">
      <source>White balance</source>
      <translation variants="no">سفیدی کا توازن</translation>
    </message>
    <message numerus="no" id="txt_cam_list_camcorder">
      <source>Camcorder</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویڈیو کیمرا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_whitebal">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality">
      <source>Video quality</source>
      <translation variants="no">ویڈیو کا معیار</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_timer">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality">
      <source>Video quality</source>
      <translation variants="no">ویڈیو کا معیار</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_flash">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_settings">
      <source>Settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode">
      <source>Scene mode</source>
      <translation variants="no">منظر وضع</translation>
    </message>
    <message numerus="no" id="txt_cam_list_not">
      <source>Not specified</source>
      <translation variants="no">نہیں</translation>
    </message>
    <message numerus="no" id="txt_cam_info_error">
      <source>Unexpected error occurred. Power off the device and restart</source>
      <translation variants="no">غیر متوقع غلطی واقع ہوئی۔ فون دوبارہ شروع کریں۔</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_val_ln_recording_time_left">
      <source>Recording time left: %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">بچا ہوا ریکارڈنگ کا وقت: %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_restore_settings">
      <source>Restore settings</source>
      <translation variants="no">ترتیبات بحال کریں</translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined_scene">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">صارف واضح کردہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">کھینچی شبیہ دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camera">
      <source>Secondary camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">ثانوی کیمرا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_fluorescent">
      <source>Fluorescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">فلوریسنٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_white_balance">
      <source>White balance</source>
      <translation variants="no">سفیدی کا توازن</translation>
    </message>
    <message numerus="no" id="txt_cam_list_not_video">
      <source>Not</source>
      <translation variants="yes">
        <lengthvariant priority="1">نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln سیک</numerusform>
        <numerusform plurality="b">%Ln سیکنڈ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_captured_photos_and_videos_will_be_ta">
      <source>Captured photos and videos will be tagged with your location. If photos or videos are shared, the location data may also be visible to third parties. Phone will use network to get the location data. Data transfer charges may apply. Location recording can be disabled in settings.</source>
      <translation variants="no">کھینچی گئی تصویریں اور ویڈیوز کو آپ کے مقام سے منسلک کر دیا جائے گا۔ اگر تصویریں یا ویڈیوز مشترک ہیں تو مقام کا ڈیٹا تیسرے فریقین بھی دیکھ سکتے ہیں۔ مقام کا ڈیٹا حاصل کرنے کے لیے فون نیٹ ورک کا استعمال کرے گا۔  ڈیٹا منتقلئ کی اجرتوں کا اطلاق ہو سکتا ہے۔ ترتیبات میں مقام کی ریکارڈنگ میں غیر فعال ہو سکتی ہے۔</translation>
    </message>
    <message numerus="no" id="txt_cam_title_contrast">
      <source>Contrast</source>
      <translation variants="no">تضاد</translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">کھینچا گیا ویڈیو دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_mass_memory">
      <source>Mass memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">مجموعی حافظہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_scene">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">بند</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking">
      <source>Face tracking</source>
      <translation variants="no">ur #Face detection</translation>
    </message>
    <message numerus="no" id="txt_cam_list_vivid">
      <source>Vivid</source>
      <translation variants="yes">
        <lengthvariant priority="1">واضح</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus">
      <source>-%L1</source>
      <translation variants="no">-%L1</translation>
    </message>
    <message numerus="yes" id="txt_cam_other_delete_n_items">
      <source>Delete %Ln items?</source>
      <translation>
        <numerusform plurality="a">کیا %Ln آئیٹم مٹائیں؟</numerusform>
        <numerusform plurality="b">%Ln آئیٹم مٹائیں؟</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_cloudy">
      <source>Cloudy</source>
      <translation variants="yes">
        <lengthvariant priority="1">ابر آلود</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">کھینچنے کی ٹون</translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_video_name">
      <source>Default video name</source>
      <translation variants="no">آغازی ویڈیو کا نام</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sunny">
      <source>Sunny</source>
      <translation variants="yes">
        <lengthvariant priority="1">دھوپ دار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name">
      <source>Default image name</source>
      <translation variants="no">آغازی شبیہ کا نام</translation>
    </message>
    <message numerus="no" id="txt_cam_title_set_as_default_scene_mode">
      <source>Set as default scene mode</source>
      <translation variants="no">بطور آغازی منظر وضع مرتب کریں</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality">
      <source>Image quality</source>
      <translation variants="no">شبیہ کا معیار</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sepia">
      <source>Sepia</source>
      <translation variants="yes">
        <lengthvariant priority="1">سرخی مائل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos">
      <source>Go to 'Videos'</source>
      <translation variants="no">ویڈیو کلپس</translation>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone">
      <source>Color tone</source>
      <translation variants="no">رنگ کی ٹون</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_upload_settings">
      <source>Upload settings</source>
      <translation variants="no">ترتیبات اپ لوڈ کریں</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">خودکار</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">کیمرا</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix">
      <source>%Ln Mpix</source>
      <translation>
        <numerusform plurality="a">%Ln میگاپکسل</numerusform>
        <numerusform plurality="b">%Ln میگاپکسلس</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">اکسپوژر توازن</translation>
    </message>
    <message numerus="no" id="txt_cam_list_normal">
      <source>Normal</source>
      <translation variants="yes">
        <lengthvariant priority="1">عام</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix_widescreen">
      <source>%Ln Mpix widescreen</source>
      <translation>
        <numerusform plurality="a">%Lnم. پکسل چوڑا اسکرین</numerusform>
        <numerusform plurality="b">%Lnمیگاپکسلس چوڑا اسکرین</numerusform>
      </translation>
    </message>
  </context>
</TS>