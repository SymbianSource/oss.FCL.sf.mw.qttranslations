<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">vi ##SIM Services</translation>
    </message>
    <message numerus="no" id="txt_simatk_title_sim_services">
      <source>SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dịch vụ SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_sim_services">
      <source>SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dịch vụ SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_entern1_digit_09">
      <source>Enter:\n(1 digit 0-9) </source>
      <translation variants="no">Nhập: (1 số từ 0-9)</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_enternnumber">
      <source>Enter:\n(number)</source>
      <translation variants="no">Nhập: (số)</translation>
    </message>
    <message numerus="no" id="txt_short_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">vi ##SIM Services</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_entern1_character">
      <source>Enter:\n(1 character) </source>
      <translation variants="no">Nhập: (1 ký tự)</translation>
    </message>
    <message numerus="no" id="txt_simatk_dblist_val_sim_service_information_on_h">
      <source>Sim service information on Homescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #SIM services information on Home screen</lengthvariant>
        <lengthvariant priority="2">vi #SIM servs. on Home screen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_request_not_allowed">
      <source>Request not allowed</source>
      <translation variants="no">Không được phép yêu cầu</translation>
    </message>
    <message numerus="no" id="txt_simatk_dialog_enter">
      <source>Enter:</source>
      <translation variants="no">Nhập:</translation>
    </message>
    <message numerus="no" id="txt_long_caption_sim_services">
      <source>SIM Services</source>
      <translation variants="no">Dịch vụ SIM</translation>
    </message>
    <message numerus="no" id="txt_simatk_titlw_cmcc_sim_services">
      <source>CMCC SIM Services</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dịch vụ SIM CMCC</lengthvariant>
        <lengthvariant priority="2">D.vụ SIM CMCC</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_simatk_info_sending">
      <source>Sending</source>
      <translation variants="no">Đang gửi dữ liệu</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_1_about_to_call">
      <source>%1 about to call</source>
      <translation variants="no">%[93]1 sắp gọi</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_sim_services_not_available">
      <source>SIM services not available</source>
      <translation variants="no">Dịch vụ SIM không có sẵn</translation>
    </message>
    <message numerus="no" id="txt_simatk_info_open_connection">
      <source>Open connection?</source>
      <translation variants="no">Kết nối?</translation>
    </message>
    <message numerus="no" id="txt_simatk_dpopinfo_request_modified">
      <source>Request modified</source>
      <translation variants="no">Đã sửa đổi yêu cầu</translation>
    </message>
  </context>
</TS>