<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en_us" language="es_419">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_dblist_repeats_yearly">
      <source>Repeats Yearly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Se repite anualmente</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Eliminar entrada repetida:</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Sólo esta ocurrencia</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_fortnightly">
      <source>Repeats fortnightly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Se repite quincenalmente</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Descripción:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_select_location_from">
      <source>Select location from search results</source>
      <translation variants="yes">
        <lengthvariant priority="1">Seleccionar ubicación de resultados de la búsqueda</lengthvariant>
        <lengthvariant priority="2">Selec. ubicación de resultados búsqueda</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Todas las ocurrencias</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">¿Eliminar nota de tareas?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_select_location">
      <source>Select location :</source>
      <translation variants="no">Seleccionar ubicación:</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_subject">
      <source>Subject</source>
      <translation variants="yes">
        <lengthvariant priority="1">Asunto:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_find_location_on_map">
      <source>Find location on map</source>
      <translation variants="yes">
        <lengthvariant priority="1">Buscar ubicación en el mapa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_monthly">
      <source>Repeats monthly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Se repite mensualmente</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sin nombre</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">¿Eliminar reunión?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_finding_location_on_m">
      <source>Finding location on map…</source>
      <translation variants="yes">
        <lengthvariant priority="1">Buscando ubicación en el mapa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_from_1">
      <source>From %1</source>
      <translation variants="no">Desde %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nota de tareas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">Marcar como no hecha</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_workdays">
      <source>Repeats workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">Se repite los días hábiles</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_weekly">
      <source>Repeats weekly</source>
      <translation variants="yes">
        <lengthvariant priority="1">Se repite semanalmente</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Marcar como hecha</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Editar:</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Agenda</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_location_not_found_on">
      <source>Location not found on map</source>
      <translation variants="yes">
        <lengthvariant priority="1">No se encontró la ubicación en el mapa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event ?</source>
      <translation variants="no">¿Eliminar entrada para todo el día?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily">
      <source>Repeats daily</source>
      <translation variants="yes">
        <lengthvariant priority="1">Se repite diariamente</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">Reunión</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_all_day_event">
      <source>All day event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Entrada para todo el día</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Fecha en que se completó:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_until_1">
      <source>Until %1</source>
      <translation variants="no">Hasta %1</translation>
    </message>
  </context>
</TS>