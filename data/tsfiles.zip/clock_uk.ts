<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy">
      <source>Not specified</source>
      <translation variants="no">дд мм рррр</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_weekly">
      <source>Not specified</source>
      <translation variants="no">Щотижня</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_wednesday">
      <source>Not specified</source>
      <translation variants="no">Середа</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_thursday">
      <source>Not specified</source>
      <translation variants="no">Четвер</translation>
    </message>
    <message numerus="no" id="txt_clk_formlabel_val_alarm">
      <source>Not specified</source>
      <translation variants="no">Сигнал</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour">
      <source>Not specified</source>
      <translation variants="no">24 години</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_menu_delete_alarm">
      <source>Delete alarm</source>
      <translation variants="no">Видалити сигнал</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_once">
      <source>Not specified</source>
      <translation variants="no">Без повторів</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_friday">
      <source>Not specified</source>
      <translation variants="no">П’ятниця</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_saturday">
      <source>Not specified</source>
      <translation variants="no">Субота</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_settings">
      <source>Settings</source>
      <translation variants="no">Установки</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy">
      <source>Not specified</source>
      <translation variants="no">мм дд рррр</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_tuesday">
      <source>Not specified</source>
      <translation variants="no">Вівторок</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_monday">
      <source>Not specified</source>
      <translation variants="no">Понеділок</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd">
      <source>Not specified</source>
      <translation variants="no">рррр мм дд</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_workdays">
      <source>Workdays</source>
      <translation variants="no">uk ##Workdays</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_world_clock">
      <source>World Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Світовий час</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date">
      <source>Not specified</source>
      <translation variants="no">Дата і час</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_gmt_1">
      <source>GMT %1</source>
      <translation variants="no">uk ##GMT %1</translation>
    </message>
    <message numerus="no" id="txt_short_caption_clock">
      <source>Clock</source>
      <translation variants="no">Годинник</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_deactivated">
      <source>Alarm Deactivated</source>
      <translation variants="no">Сигнал вимкнено</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hrs_2_mins">
      <source>%1 hrs %2 mins</source>
      <translation variants="no">uk ##%1 hrs %2 mins</translation>
    </message>
    <message numerus="no" id="txt_long_caption_clk">
      <source>Not specified</source>
      <translation variants="no">Годинник</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_title_control_panel">
      <source>Not specified</source>
      <translation variants="no">Панель керув.</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_info_date_info">
      <source>Not specified</source>
      <translation variants="no">Час, дата</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2mins">
      <source>In %1hrs %2mins</source>
      <translation variants="no">uk ##In %1hrs %2mins</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dpopinfo_alarm_activated">
      <source>Alarm Activated</source>
      <translation variants="no">Сигнал увімкнено</translation>
    </message>
    <message numerus="no" id="txt_common_common_clock">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Годинник</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2mins">
      <source>In %1hr %2mins</source>
      <translation variants="no">uk ##In %1hr %2mins</translation>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_no_alarms_set">
      <source>No alarms set</source>
      <translation variants="yes">
        <lengthvariant priority="1">(немає встановлених сигналів)</lengthvariant>
        <lengthvariant priority="2">(немає встановл. сигналів)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_hr">
      <source>%1 hr</source>
      <translation variants="no">uk ##%1 hr</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hr_2min">
      <source>In %1hr %2min</source>
      <translation variants="no">uk ##In %1hr %2min</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1days">
      <source>In %1days</source>
      <translation variants="no">uk ##In %1days</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_hrs">
      <source>%1 hrs</source>
      <translation variants="no">uk ##%1 hrs</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_set_as_current_location">
      <source>Set as current location</source>
      <translation variants="no">Уст. як поточне розташ.</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_show_on_homescreen">
      <source>Show on homescreen</source>
      <translation variants="no">Показув. на Гол. екрані</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour">
      <source>Not specified</source>
      <translation variants="no">12 годин</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily">
      <source>Daily</source>
      <translation variants="no">uk ##Daily</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_daily">
      <source>Not specified</source>
      <translation variants="no">Щодня</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_on_workdays">
      <source>Not specified</source>
      <translation variants="no">Робочі дні</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_sunday">
      <source>Not specified</source>
      <translation variants="no">Неділя</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_in_1hrs_2min">
      <source>In %1hrs %2min</source>
      <translation variants="no">uk ##In %1hrs %2min</translation>
    </message>
    <message numerus="no" id="txt_long_caption_clock">
      <source>Clock</source>
      <translation variants="no">Годинник</translation>
    </message>
    <message numerus="no" id="txt_clk_menu_delete">
      <source>Delete</source>
      <translation variants="no">Видалити</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_subtitle_device">
      <source>Not specified</source>
      <translation variants="no">Телефон</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_daily_val_1_hr_2_mins">
      <source>%1 hr %2 mins</source>
      <translation variants="no">uk ##%1 hr %2 mins</translation>
    </message>
    <message numerus="no" id="txt_clock_dblist_val_1_mins">
      <source>%1 mins</source>
      <translation variants="no">uk ##%1 mins</translation>
    </message>
    <message numerus="no" id="txt_common_common_gmt">
      <source>GMT</source>
      <translation variants="no">uk ##GMT</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_setlabel_every_1">
      <source>Every %1</source>
      <translation variants="no">uk ##Every %1</translation>
    </message>
    <message numerus="no" id="txt_clock_main_view_dblist_daily_val_today">
      <source>Today</source>
      <translation variants="no">uk ##Today</translation>
    </message>
  </context>
</TS>