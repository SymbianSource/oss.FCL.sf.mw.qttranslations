<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_rad_info_rock_music">
      <source>Rock Music</source>
      <translation variants="no">Nhạc rock</translation>
    </message>
    <message numerus="no" id="txt_rad_info_personality">
      <source>Personality</source>
      <translation variants="no">Nhân vật nổi tiếng</translation>
    </message>
    <message numerus="no" id="txt_rad_opt_play_history">
      <source>Play history</source>
      <translation variants="no">Lịch sử phát</translation>
    </message>
    <message numerus="no" id="txt_rad_info_news">
      <source>News</source>
      <translation variants="no">Tin tức</translation>
    </message>
    <message numerus="no" id="txt_rad_info_culture">
      <source>Culture</source>
      <translation variants="no">Văn hóa</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft_rhythm_and_blues">
      <source>Soft rhythm and blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">R&amp;B nhẹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_country_music">
      <source>Country Music</source>
      <translation variants="no">Nhạc đồng quê</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_val_l1_mhz">
      <source>%L1 MHz</source>
      <translation variants="no">%L1 MHz</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_rock_music">
      <source>Rock Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc rock</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_tagged_songs">
      <source>Tagged songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bài hát được gắn tag</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rock">
      <source>Soft rock</source>
      <translation variants="no">Rock nhẹ</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_culture">
      <source>Culture</source>
      <translation variants="yes">
        <lengthvariant priority="1">Văn hóa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_add_to_favourites">
      <source>Add to favourites</source>
      <translation variants="no">Thêm vào mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_rad_info_nostalgia">
      <source>Nostalgia</source>
      <translation variants="no">Hoài cổ</translation>
    </message>
    <message numerus="no" id="txt_rad_info_social_affairs">
      <source>Social Affairs</source>
      <translation variants="no">Các vấn đề về xã hội</translation>
    </message>
    <message numerus="no" id="txt_rad_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">Xóa danh sách</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_other_music">
      <source>Other Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc khác</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_rhythm_and_blues">
      <source>Rhythm and blues</source>
      <translation variants="no">Nhạc R&amp;B</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religious_talk">
      <source>Religious talk</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc nói chuyện về tôn giáo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_activate_loudspeaker">
      <source>Activate loudspeaker</source>
      <translation variants="no">Kích hoạt loa</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_nostalgia">
      <source>Nostalgia</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hoài cổ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_language">
      <source>Language</source>
      <translation variants="no">Ngôn ngữ</translation>
    </message>
    <message numerus="no" id="txt_rad_info_talk">
      <source>Talk</source>
      <translation variants="no">Trò chuyện</translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft_rhythm_and_blues">
      <source>Soft rhythm and blues</source>
      <translation variants="no">R&amp;B nhẹ</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_national_music">
      <source>National Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc dân tộc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_science">
      <source>Science</source>
      <translation variants="no">Khoa học</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_weather">
      <source>Weather</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời tiết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_drama">
      <source>Drama</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_national_music">
      <source>National Music</source>
      <translation variants="no">Nhạc dân tộc</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_music">
      <source>Religious music</source>
      <translation variants="no">Nhạc tôn giáo</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_oldies_music">
      <source>Oldies Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc xưa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_education">
      <source>Education</source>
      <translation variants="no">Giáo dục</translation>
    </message>
    <message numerus="no" id="txt_rad_info_adult_hits">
      <source>Adult hits</source>
      <translation variants="no">Adult hits</translation>
    </message>
    <message numerus="no" id="txt_rad_button_stations">
      <source>Stations</source>
      <translation variants="no">Danh sách kênh</translation>
    </message>
    <message numerus="no" id="txt_rad_info_pop_music">
      <source>Pop Music</source>
      <translation variants="no">Nhạc pop</translation>
    </message>
    <message numerus="no" id="txt_fmradio_button_remove_from_favourites">
      <source>Remove from favourites</source>
      <translation variants="no">Xóa khỏi mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_rad_info_varied">
      <source>Varied</source>
      <translation variants="no">Loại khác</translation>
    </message>
    <message numerus="no" id="txt_rad_info_other_music">
      <source>Other Music</source>
      <translation variants="no">Nhạc khác</translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm">
      <source>Alarm</source>
      <translation variants="no">Âm báo</translation>
    </message>
    <message numerus="no" id="txt_rad_info_childrens_programmes">
      <source>Children’s programmes</source>
      <translation variants="no">Chương trình dành cho trẻ em</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_varied">
      <source>Varied</source>
      <translation variants="yes">
        <lengthvariant priority="1">Loại khác</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_leisure">
      <source>Leisure</source>
      <translation variants="no">Giải trí</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">Báo nguy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_information">
      <source>Information</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thông tin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_menu_remove_favourite">
      <source>Remove from favourites</source>
      <translation variants="no">Xóa khỏi mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_rad_button_cancel">
      <source>Cancel</source>
      <translation variants="no">Hủy</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religion">
      <source>Religion</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tôn giáo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_menu_add_to_favourites">
      <source>Add to favourites</source>
      <translation variants="no">Thêm vào mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_rad_info_current_affairs">
      <source>Current affairs</source>
      <translation variants="no">Công việc hiện tại</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_social_affairs">
      <source>Social Affairs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Các vấn đề về xã hội</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_education">
      <source>Education</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giáo dục</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_jazz_music">
      <source>Jazz Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc jazz</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_religious_music">
      <source>Religious music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc tôn giáo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_list_unknown">
      <source>(Unknown) - %1</source>
      <translation variants="no">Không biết - %1</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_travel">
      <source>Travel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Du lịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_classical">
      <source>Classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cổ điển</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_talk">
      <source>Talk</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trò chuyện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_finance">
      <source>Finance</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tài chính</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_searching_local_stations_please_wait">
      <source>Searching local stations. Please wait.</source>
      <translation variants="no">Đang tìm trạm cục bộ</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz2">
      <source>%L1 MHz</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 MHz</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_drama">
      <source>Drama</source>
      <translation variants="no">Kịch</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_top_40">
      <source>Top 40</source>
      <translation variants="yes">
        <lengthvariant priority="1">Top 40</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_list_searching_all_available_stations_ple">
      <source>Searching all available stations. Please wait.</source>
      <translation variants="no">Đang tìm các trạm có sẵn</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_college">
      <source>College</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đoàn thể</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_college">
      <source>College</source>
      <translation variants="no">Đoàn thể</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_pop_music">
      <source>Pop Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc pop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_public">
      <source>Public</source>
      <translation variants="yes">
        <lengthvariant priority="1">Công chúng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_serious_classical">
      <source>Serious classical</source>
      <translation variants="no">Cổ điển nghiêm túc</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religion">
      <source>Religion</source>
      <translation variants="no">Tôn giáo</translation>
    </message>
    <message numerus="no" id="txt_rad_info_easy_listening">
      <source>Easy Listening</source>
      <translation variants="no">Dễ nghe</translation>
    </message>
    <message numerus="no" id="txt_rad_info_classical">
      <source>Classical</source>
      <translation variants="no">Cổ điển</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_sport">
      <source>Sport</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thể thao</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_play_history">
      <source>Play history</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lịch sử phát</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_menu_remove_tag">
      <source>Remove tag</source>
      <translation variants="no">Xóa khỏi tag</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_personality">
      <source>Personality</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhân vật nổi tiếng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_language">
      <source>Language</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngôn ngữ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_current_affairs">
      <source>Current affairs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Công việc hiện tại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_soft">
      <source>Soft</source>
      <translation variants="no">Nhẹ nhàng</translation>
    </message>
    <message numerus="no" id="txt_rad_button_local_stations">
      <source>All stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tất cả trạm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_serious_classical">
      <source>Serious classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cổ điển nghiêm túc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_sport">
      <source>Sport</source>
      <translation variants="no">Thể thao</translation>
    </message>
    <message numerus="no" id="txt_rad_info_weather">
      <source>Weather</source>
      <translation variants="no">Thời tiết</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_science">
      <source>Science</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khoa học</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_classic_rock">
      <source>Classic rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Rock cổ điển</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft_rock">
      <source>Soft rock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Rock nhẹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_light_classical">
      <source>Light classical</source>
      <translation variants="no">Nhạc cổ điển nhẹ</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_folk_music">
      <source>Folk Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc dân gian</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_phone_in">
      <source>Phone In</source>
      <translation variants="no">Hộp thư truyền hình</translation>
    </message>
    <message numerus="no" id="txt_rad_button_favourites">
      <source>Favourite stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trạm radio ưa thích</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_1_2">
      <source>%1 - %2</source>
      <translation variants="no">%[10]1 - %2</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_leisure">
      <source>Leisure</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giải trí</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_alarm_test">
      <source>Alarm Test</source>
      <translation variants="no">Kiểm tra âm báo</translation>
    </message>
    <message numerus="no" id="txt_rad_button_recently_played_songs">
      <source>Recently played songs</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã phát gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_jazz_music">
      <source>Jazz Music</source>
      <translation variants="no">Nhạc jazz</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_soft">
      <source>Soft</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhẹ nhàng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_information">
      <source>Information</source>
      <translation variants="no">Thông tin</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_alarm_test">
      <source>Alarm Test</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thử nghiệm báo nguy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_rhythm_and_blues">
      <source>Rhythm and blues</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc R&amp;B</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_unknown">
      <source>(Unknown)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không biết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_adult_hits">
      <source>Adult hits</source>
      <translation variants="yes">
        <lengthvariant priority="1">Adult hits</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_list_seeking">
      <source>Seeking</source>
      <translation variants="no">Đang tìm</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_documentary">
      <source>Documentary</source>
      <translation variants="yes">
        <lengthvariant priority="1">Phim tài liệu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_top_40">
      <source>Top 40</source>
      <translation variants="no">Top 40</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_news">
      <source>News</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tin tức</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_connect_wired_headset1">
      <source>Connect wired headset.</source>
      <translation variants="no">Kết nối tai nghe có dây</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_easy_listening">
      <source>Easy Listening</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dễ nghe</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_finance">
      <source>Finance</source>
      <translation variants="no">Tài chính</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_childrens_programmes">
      <source>Children’s programmes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chương trình dành cho trẻ em</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_documentary">
      <source>Documentary</source>
      <translation variants="no">Phim tài liệu</translation>
    </message>
    <message numerus="no" id="txt_rad_info_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">Radio FM</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_light_classical">
      <source>Light classical</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc cổ điển nhẹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_button_deactivate_loudspeaker">
      <source>Deactivate loudspeaker</source>
      <translation variants="no">Tắt loa</translation>
    </message>
    <message numerus="no" id="txt_rad_info_religious_talk">
      <source>Religious talk</source>
      <translation variants="no">Cuộc nói chuyện về tôn giáo</translation>
    </message>
    <message numerus="no" id="txt_rad_info_travel">
      <source>Travel</source>
      <translation variants="no">Du lịch</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_phone_in">
      <source>Phone In</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hộp thư truyền hình</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_oldies_music">
      <source>Oldies Music</source>
      <translation variants="no">Nhạc xưa</translation>
    </message>
    <message numerus="no" id="txt_rad_info_public">
      <source>Public</source>
      <translation variants="no">Chung</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz">
      <source>%L1 MHz</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1 MHz</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_list_l1_mhz_small">
      <source>%L1 MHz</source>
      <translation variants="no">%L1 MHz</translation>
    </message>
    <message numerus="no" id="txt_rad_dblist_l1_mhz_val_country_music">
      <source>Country Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc đồng quê</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_classic_rock">
      <source>Classic rock</source>
      <translation variants="no">Rock cổ điển</translation>
    </message>
    <message numerus="no" id="txt_rad_info_folk_music">
      <source>Folk Music</source>
      <translation variants="no">Nhạc dân gian</translation>
    </message>
    <message numerus="no" id="txt_rad_dialog_new_name">
      <source>New name:</source>
      <translation variants="no">Tên mới:</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_recently_played_songs_list">
      <source>Clear Recently played songs list?</source>
      <translation variants="no">Xóa danh sách bài hát được phát gần đây?</translation>
    </message>
    <message numerus="no" id="txt_rad_opt_search_all_stations">
      <source>Search all stations</source>
      <translation variants="no">Tìm trạm</translation>
    </message>
    <message numerus="no" id="txt_fmradio_info_local_frequency_band_automaticall">
      <source>Local frequency band automatically set for radio.</source>
      <translation variants="no">Băng tần địa phương được cài tự động</translation>
    </message>
    <message numerus="no" id="txt_rad_info_station_list_is_full_please_remove_s">
      <source>Station list is full. Please remove some stations and try again.</source>
      <translation variants="no">Danh sách trạm đầy. Xóa bớt trạm và thử lại.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_favourite_stations_list">
      <source>Clear Favourite stations list?</source>
      <translation variants="no">Xóa danh sách trạm ưa thích?</translation>
    </message>
    <message numerus="no" id="txt_rad_info_delete_station">
      <source>Delete station?</source>
      <translation variants="no">Xóa trạm?</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_all_stations_list">
      <source>Clear All stations list?</source>
      <translation variants="no">Xóa danh sách trạm? Tất cả trạm sẽ bị xóa.</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_song_was_added_to_favorite_songs">
      <source>Song was added to Tagged songs.</source>
      <translation variants="no">Đã thêm bài hát vào 'B.hát được gắn tag'</translation>
    </message>
    <message numerus="no" id="txt_rad_info_clear_tagged_songs_list">
      <source>Clear Tagged songs list?</source>
      <translation variants="no">Xóa danh sách 'Bài hát được gắn tag'?</translation>
    </message>
    <message numerus="no" id="txt_rad_info_all_stations_in_stations_list_will_be">
      <source>Stations in station list will be replaced. Favourite stations won't be touched. Continue?</source>
      <translation variants="no">Tất cả trạm cài sẵn trong danh sách trạm sẽ được thay thế. Trạm ưa thích sẽ không thay đổi. Tiếp tục?</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_no_stations_found_try_searching">
      <source>No stations found. Try searching stations by scrolling the frequency strip.</source>
      <translation variants="no">Ko tìm thấy trạm. Thử lại bằng thanh tần số.</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">Radio FM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_menu_search_from_music_store">
      <source>Search from Ovi Music</source>
      <translation variants="no">Tìm kiếm từ Âm nhạc Ovi</translation>
    </message>
    <message numerus="no" id="txt_rad_dpophead_connect_wired_headset">
      <source>Connect wired headset.</source>
      <translation variants="no">Kết nối tai nghe có dây</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_search_from_other_store">
      <source>Search from %1</source>
      <translation variants="no">Tìm kiếm từ %1</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_favourites_add_favourites_to_see">
      <source>Tap the star icon or Add to favourite button in main view to mark currently playing station as a favorite.</source>
      <translation variants="no">Bạn có thể thêm trạm vào mục ưa thích bằng cách chọn và giữ trạm, đồng thời chọn 'Thêm vào mục ưa thích'. Bạn cũng có thể chạm vào biểu tượng ngôi sao trong giao diện chính để thêm trạm vào mục ưa thích.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_favourite_stations">
      <source>(No favourite stations)</source>
      <translation variants="no">(không có mục ưa thích)</translation>
    </message>
    <message numerus="no" id="txt_rad_info_you_can_add_song_to_the_tagged_songs">
      <source>You can add song to the tagged songs list from Recently played songs or from main view if song information is available. </source>
      <translation variants="no">Bạn chỉ có thể thêm bài hát vào 'Bài hát được tag' từ 'Được phát gần đây' khi bài hát đã được nhận dạng.</translation>
    </message>
    <message numerus="no" id="txt_rad_info_song_information_is_collected_automat">
      <source>Song information is collected automatically from radio stations which send the song information using the RDS+ technology.</source>
      <translation variants="no">Thông tin bài hát được thu thập tự động từ các trạm radio gửi thông tin bằng công nghệ RDS+</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_stations_search_stations_automat">
      <source>Search stations automatically by tapping here.</source>
      <translation variants="no">Tìm trạm tự động bằng cách chạm vào đây</translation>
    </message>
    <message numerus="no" id="txt_rad_info_no_stations">
      <source>(No stations)</source>
      <translation variants="no">(không có trạm)</translation>
    </message>
    <message numerus="no" id="txt_rad_info_play_history_is_empty">
      <source>(No songs)</source>
      <translation variants="no">(không có bài hát)</translation>
    </message>
    <message numerus="no" id="txt_long_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">Radio FM</translation>
    </message>
    <message numerus="no" id="txt_rad_title_fm_radio">
      <source>FM Radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">Radio FM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_rad_info_continue_using_the_radio_in_offline">
      <source>Continue using the Radio in off-line mode?</source>
      <translation variants="no">Tiếp tục sử dụng radio FM ở chế độ offline?</translation>
    </message>
    <message numerus="no" id="txt_rad_info_activate_radio_in_offline_mode">
      <source>Activate Fm Radio in off-line mode?</source>
      <translation variants="no">Mở radio FM ở chế độ offline?</translation>
    </message>
    <message numerus="no" id="txt_rad_menu_tag_song">
      <source>Tag song</source>
      <translation variants="no">Gắn tag bài hát</translation>
    </message>
    <message numerus="no" id="txt_fmradio_info_fm_radio_could_not_be_started">
      <source>FM Radio could not be started. </source>
      <translation variants="no">Không thể bật radio FM</translation>
    </message>
    <message numerus="no" id="txt_short_caption_fm_radio">
      <source>FM Radio</source>
      <translation variants="no">Radio FM</translation>
    </message>
    <message numerus="no" id="txt_rad_info_remove_song_from_tagged_songs">
      <source>Remove song from tagged songs?</source>
      <translation variants="no">Xóa bài hát khỏi 'Bài hát được gắn tag'?</translation>
    </message>
    <message numerus="no" id="txt_rad_subhead_stations">
      <source>Stations</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lịch sử phát</lengthvariant>
      </translation>
    </message>
  </context>
</TS>