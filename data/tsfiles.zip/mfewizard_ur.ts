<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mfe_mail_setup_dpophead_incorrect_server_for">
      <source>Incorrect server format</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Incorrect server format</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_formlabel_mail_server">
      <source>Mail server</source>
      <translation variants="no">ur #Mail server</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_formlabel_contacts">
      <source>Contacts</source>
      <translation variants="no">ur #Contacts</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_formlabel_calendar">
      <source>Calendar</source>
      <translation variants="no">ur #Calendar</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dpophead_incorrect_mail_addre">
      <source>Incorrect mail address format</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Incorrect mail address format</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_formlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">ur #Mail address</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_formlabel_mail">
      <source>Mail</source>
      <translation variants="no">ur #Mail</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_formlabel_password">
      <source>Password</source>
      <translation variants="no">ur #Password</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_setlabel_by_selecting_ok_you">
      <source>By selecting OK, you agree to the service terms and privacy policy.</source>
      <translation variants="no">ur #By selecting OK, you agree to the service terms and privacy policy.</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dblist_add_mailbox_details">
      <source>Add mailbox details</source>
      <translation variants="no">ur #Add mailbox details</translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dialog_check_the_exchange_ser">
      <source>Check the Exchange server format to continue the mail setup.</source>
      <translation variants="no">ur #Check the Exchange server format to continue the mail setup.</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_setlabel_important_it_is_rec">
      <source>Important! It is recommended not to use any other sync application to synchronize contacts, calendar or tasks after setting up Mail for Exchange on your device.  Simultaneous use of other sync applications may cause data loss, duplication, or corruption.</source>
      <translation variants="no">ur #Important! It is recommended not to use any other sync application to synchronize contacts, calendar or tasks after setting up Mail for Exchange on your device.  Simultaneous use of other sync applications may cause data loss, duplication, or corruption.</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_formlabel_domain">
      <source>Domain</source>
      <translation variants="no">ur #Domain</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_button_previous">
      <source>Previous</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Previous</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dblist_add_mailbox_details_va">
      <source>Mail address and password</source>
      <translation variants="no">ur #Mail address and password</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_formlabel_todo">
      <source>To-Do</source>
      <translation variants="no">ur #To-Do</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dialog_check_the_mail_address">
      <source>Check the mail address to continue the mail setup.</source>
      <translation variants="no">ur #Check the mail address to continue the mail setup.</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dblist_would_you_like_to_sele">
      <source>Would you like to select other items to sync?</source>
      <translation variants="no">ur #Would you like to select other items to sync?</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dialog_domain">
      <source>Domain</source>
      <translation variants="no">ur #Domain</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_button_finish">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Finish</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dblist_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Mail for Exchange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dpopinfo_you_have_reached_the">
      <source>You have reached the maximum limit of Mail for Exchange mailboxes. Please delete existing mailbox to create new.</source>
      <translation variants="no">ur #You have reached the maximum limit of Mail for Exchange mailboxes. Please delete existing mailbox to create new.</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dpophead_all_mailboxes_in_use">
      <source>All mailboxes in use</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #All mailboxes in use</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_l_button_next">
      <source>Next</source>
      <translation variants="no">ur #Next</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_button_replace_all">
      <source>Replace all</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Replace all</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_la_button_cancel">
      <source>Cancel</source>
      <translation variants="no">ur #Cancel</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dialog_mail_server">
      <source>Mail server</source>
      <translation variants="no">ur #Mail server</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dialog_password">
      <source>Password</source>
      <translation variants="no">ur #Password</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_l_dblist_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="no">ur #Mail for Exchange</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_l_button_previous">
      <source>Previous</source>
      <translation variants="no">ur #Previous</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_l_button_finish">
      <source>Finish</source>
      <translation variants="no">ur #Finish</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_button_ok">
      <source>OK</source>
      <translation variants="no">ur #OK</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_l_button_cancel">
      <source>Cancel</source>
      <translation variants="no">ur #Cancel</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dblist_what_do_you_want_to_do">
      <source>Would you like to replace your existing calendar and contacts on the mobile with the ones on the server? Keeping the existing items may lead to duplicate data.</source>
      <translation variants="no">ur #Would you like to replace your existing calendar and contacts on the mobile with the ones on the server? Keeping the existing items may lead to duplicate data.</translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_title_items_to_keep_in_phone">
      <source>Items to keep in phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Items to keep in phone</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_button_keep_the_items">
      <source>Keep the items</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Keep the items</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_button_next">
      <source>Next</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Next</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dialog_check_the_exchange_ent">
      <source>Mail server</source>
      <translation variants="no">ur #Mail server</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_subtitle_mail_setup">
      <source>Mail setup</source>
      <translation variants="no">ur #Mail setup</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dialog_check_the_mail_entry_m">
      <source>Mail address</source>
      <translation variants="no">ur #Mail address</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_formlabel_username">
      <source>Username</source>
      <translation variants="no">ur #Username</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dialog_mail_address">
      <source>Mail address</source>
      <translation variants="no">ur #Mail address</translation>
    </message>
    <message numerus="no" id="txt_mfe_mail_setup_dialog_username">
      <source>Username</source>
      <translation variants="no">ur #Username</translation>
    </message>
  </context>
</TS>