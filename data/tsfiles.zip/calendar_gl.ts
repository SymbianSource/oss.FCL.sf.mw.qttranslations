<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="gl">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_list_start_end_time">
      <source>%1 -%2</source>
      <translation variants="no">%[14]1 - %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_main_view">
      <source>Calendar main view</source>
      <translation variants="no">Ir vista princ. Calendario</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_friday">
      <source>Friday</source>
      <translation variants="no">gl #Friday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">gl #Wednesday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Si</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">Calendario</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_settings">
      <source>Settings</source>
      <translation variants="no">Axustes</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sen nome</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Calendario</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">Data de vencemento: %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_all_entries">
      <source>All entries</source>
      <translation variants="no">Todas as entradas</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_mo">
      <source>Mo</source>
      <translation variants="no">Lu</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Borrar entrada repetida:</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_date">
      <source>Go to date</source>
      <translation variants="no">Ir á data</translation>
    </message>
    <message numerus="no" id="txt_calendar_empty_list_no_entries">
      <source>No entries for today</source>
      <translation variants="no">Non hai entradas para hoxe</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_we">
      <source>We</source>
      <translation variants="no">Me</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_lunar_calendar">
      <source>Show lunar calendar</source>
      <translation variants="no">Amosar calendario lunar</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_su">
      <source>Su</source>
      <translation variants="no">Do</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_sa">
      <source>Sa</source>
      <translation variants="no">Sa</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_15">
      <source>15 minutes</source>
      <translation variants="no">15 minutos</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">Borrar xuntanza</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_10">
      <source>10 minutes</source>
      <translation variants="no">10 minutos</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Axustes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_tu">
      <source>Tu</source>
      <translation variants="no">Ma</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Editar:</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_all_calendar_entries">
      <source>Delete all calendar entries?</source>
      <translation variants="no">Borrar todas as entradas do calendario?</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_wk">
      <source>Wk</source>
      <translation variants="no">Se</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">Borrar nota de tarefas?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_monday">
      <source>Monday</source>
      <translation variants="no">gl #Monday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on">
      <source>Week starts on</source>
      <translation variants="no">gl #Week starts on</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">Calendario</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_thursday">
      <source>Thursday</source>
      <translation variants="no">gl #Thursday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_unnamed">
      <source>Unnamed</source>
      <translation variants="no">Sen nome</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_switch_to_day_view">
      <source>Switch to Day view</source>
      <translation variants="no">Cambiar á vista do día</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_5_m">
      <source>5 minutes</source>
      <translation variants="no">5 minutos</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event?</source>
      <translation variants="no">Borrar a entrada de todo o día?</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[28]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Só este caso</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_entries">
      <source>Delete entries</source>
      <translation variants="no">Borrar entradas</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Todos os casos</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_fr">
      <source>Fr</source>
      <translation variants="no">Ve</translation>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_snooze_time_val_ln">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">%Ln minuto</numerusform>
        <numerusform plurality="b">%Ln minutos</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Non</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_show_lunar_data">
      <source>Show lunar data</source>
      <translation variants="no">Amosar información lunar</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_event">
      <source>New event</source>
      <translation variants="no">Nova entrada</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_before_date">
      <source>Before date</source>
      <translation variants="no">Antes data seleccionada</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_th">
      <source>Th</source>
      <translation variants="no">Xo</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_buddhist_year">
      <source>Show buddhist year</source>
      <translation variants="no">Amosar ano budista</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time">
      <source>Reminder snooze time</source>
      <translation variants="no">Tempo repetición alarma</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_week_numbers">
      <source>Show week numbers</source>
      <translation variants="no">Números da semana</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_no_entries">
      <source>No entries for today</source>
      <translation variants="no">Non hai entradas para hoxe</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Marcar como feita</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_today">
      <source>Go to today</source>
      <translation variants="no">Ir a hoxe</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_switch_to_agenda_view">
      <source>Switch to Agenda view</source>
      <translation variants="no">Cambiar á vista da axenda</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_30">
      <source>30 minutes</source>
      <translation variants="no">30 minutos</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_saturday">
      <source>Saturday</source>
      <translation variants="no">gl #Saturday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_sunday">
      <source>Sunday</source>
      <translation variants="no">gl #Sunday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">gl #Tuesday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Si</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Si</lengthvariant>
      </translation>
    </message>
  </context>
</TS>