<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ro">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dblist_cellular_data_val_l1_connections">
      <source>Source 0</source>
      <translation variants="no">ro #%L1 connections</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_cellular_data_val_1_connected">
      <source>Source 1</source>
      <translation variants="no">ro #'%1' connected</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_cellular_data">
      <source>Source 2</source>
      <translation variants="no">ro #Cellular data</translation>
    </message>
  </context>
</TS>