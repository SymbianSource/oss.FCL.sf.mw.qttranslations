<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_dial_opt_change_outgoing_line_2">
      <source>Change outgoing line 2</source>
      <translation variants="no">Змінити вихідну лінію 2</translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_activated_profile_silent">
      <source>Activated profile: silent</source>
      <translation variants="no">uk ##Activated profile: silent</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_line_id">
      <source>Line ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ідентифікатор лінії</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_callee_id">
      <source>Callee ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ідентифікатор одержувача</lengthvariant>
        <lengthvariant priority="2">Ідентифік. одержувача</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_no_saved_number_for_this_contact">
      <source>No saved number for this contact. Call not possible</source>
      <translation variants="no">uk ##No saved number for this contact. Call not possible</translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_outgoing_line_1">
      <source>Change outgoing line 1</source>
      <translation variants="no">Змінити вихідну лінію 1</translation>
    </message>
    <message numerus="no" id="txt_dial_list_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_dial_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Save as a new contact</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_button_cancel">
      <source>Cancel</source>
      <translation variants="no">Скасувати</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">uk ##Dialer</translation>
    </message>
    <message numerus="no" id="txt_dialer_info_call_event_will_be_removed_from">
      <source>Call event will be removed from the list. Continue?</source>
      <translation variants="no">uk #Call event will be removed from list. Continue?</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_date_and_time">
      <source>Date and time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Дата й час</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_menu_call_details">
      <source>Call details</source>
      <translation variants="no">Деталі дзвінка</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_voip_call">
      <source>VoiP call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Інтернет-дзвінок</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_recent_calls">
      <source>Recent calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">Недавні дзвінки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_no_history_of_calls">
      <source>No history of calls</source>
      <translation variants="no">(немає недавніх дзвінків)</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_service_val_cellular">
      <source>Cellular</source>
      <translation variants="yes">
        <lengthvariant priority="1">Стільникова мережа</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">Очистити список</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_missed">
      <source>Missed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Пропущені дзвінки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_title_delete_event">
      <source>Delete event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Видалити дзвінок зі списку</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_missed">
      <source>Missed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Пропущений</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_service">
      <source>Call service</source>
      <translation variants="yes">
        <lengthvariant priority="1">Послуга дзвінків</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_dialled">
      <source>Dialled</source>
      <translation variants="yes">
        <lengthvariant priority="1">Набрані номери</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_dialer_ui_dblist_ln_missed_calls">
      <source>%Ln missed calls</source>
      <translation>
        <numerusform plurality="a">%Ln пропущений дзвінок</numerusform>
        <numerusform plurality="b">%Ln пропущених дзвінка</numerusform>
        <numerusform plurality="c">%Ln пропущених дзвінків</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_recent">
      <source>Recent</source>
      <translation variants="yes">
        <lengthvariant priority="1">Недавні дзвінки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_info_all_call_events_will_be_remo">
      <source>All call events will be removed from the list. Continue?</source>
      <translation variants="no">uk #All call events will be removed from list. Continue?</translation>
    </message>
    <message numerus="no" id="txt_dial_title_dialer">
      <source>Dialer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Набір</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_contact_search_on">
      <source>Contact search on</source>
      <translation variants="no">Увімкнути пошук конт.</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_id">
      <source>Caller ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">Дані абонента</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_open_contact">
      <source>Open contact</source>
      <translation variants="no">Відкр. картку контакту</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_subhead_matches">
      <source>Matches</source>
      <translation variants="yes">
        <lengthvariant priority="1">Збіги</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_id_val_unknown_number">
      <source>Unknown number</source>
      <translation variants="yes">
        <lengthvariant priority="1">Невідомий номер</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_call_using">
      <source>Call using</source>
      <translation variants="no">Дзвінок за допомогою</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_line_id_val_line_1">
      <source>%L1, line 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1, лінія 1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_duration">
      <source>Call duration</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тривалість дзвінка</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_change_call_service_sub_cellul">
      <source>Cellular</source>
      <translation variants="no">Стільникова мережа</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_change_call_service">
      <source>Change call service</source>
      <translation variants="no">Змінити послугу дзв.</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_contact_search_off">
      <source>Contact search off</source>
      <translation variants="no">Вимкн. пошук контактів</translation>
    </message>
    <message numerus="no" id="txt_long_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">Набір</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_title_clear_list">
      <source>Clear list</source>
      <translation variants="yes">
        <lengthvariant priority="1">Очистити список</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_last_call_event">
      <source>Last call event</source>
      <translation variants="yes">
        <lengthvariant priority="1">Остання подія дзвінка</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_activated_profile_general">
      <source>Activated profile: general</source>
      <translation variants="no">uk ##Activated profile: general</translation>
    </message>
    <message numerus="no" id="txt_dial_list_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type">
      <source>Call type</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тип дзвінка</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_dialled_calls">
      <source>Dialled calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">Набрані номери</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_subhead_received_calls">
      <source>Received calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">Отримані дзвінки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Update existing contact</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_received">
      <source>Received</source>
      <translation variants="yes">
        <lengthvariant priority="1">Отримані дзвінки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_voice_call">
      <source>Voice call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Голосовий дзвінок</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">uk ##Dialer</translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_missed_calls">
      <source>Missed calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">Пропущені дзвінки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction">
      <source>Call direction</source>
      <translation variants="yes">
        <lengthvariant priority="1">Напрям дзвінка</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_line_id_val_line_2">
      <source>%L1, line 2</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1, лінія 2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_dialled">
      <source>Dialled</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вихідний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_menu_open_contact">
      <source>Open contact</source>
      <translation variants="no">Відкр. картку контакту</translation>
    </message>
    <message numerus="no" id="txt_dial_title_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Додати до Контактів</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_call_service_sub_cellular">
      <source>Cellular</source>
      <translation variants="no">Стільникова мережа</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_id_val_privat_number">
      <source>Privat number</source>
      <translation variants="yes">
        <lengthvariant priority="1">Приватний номер</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_video_call">
      <source>Video call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Відеодзвінок</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_received">
      <source>Received</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вхідний</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_no_matches_found">
      <source>No matches found</source>
      <translation variants="no">(немає збігів)</translation>
    </message>
  </context>
</TS>