<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="lv">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_list_start_end_time">
      <source>%1 -%2</source>
      <translation variants="no">%[14]1 - %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_main_view">
      <source>Calendar main view</source>
      <translation variants="no">Atv. kalendāra galv. skatu</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_friday">
      <source>Friday</source>
      <translation variants="no">lv #Friday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">lv #Wednesday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Jā</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nē</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">Kalendārs</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_settings">
      <source>Settings</source>
      <translation variants="no">Uzstādījumi</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nenosaukts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kalendārs</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">Termiņš: %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_all_entries">
      <source>All entries</source>
      <translation variants="no">Visi ieraksti</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_mo">
      <source>Mo</source>
      <translation variants="no">Pr</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Atkārtota ieraksta dzēšana:</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_date">
      <source>Go to date</source>
      <translation variants="no">Pāriet uz datumu</translation>
    </message>
    <message numerus="no" id="txt_calendar_empty_list_no_entries">
      <source>No entries for today</source>
      <translation variants="no">Šodien nav neviena ieraksta</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_we">
      <source>We</source>
      <translation variants="no">Tr</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_lunar_calendar">
      <source>Show lunar calendar</source>
      <translation variants="no">Rādīt lunāro kalendāru</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_su">
      <source>Su</source>
      <translation variants="no">Sv</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_sa">
      <source>Sa</source>
      <translation variants="no">Se</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_15">
      <source>15 minutes</source>
      <translation variants="no">15 minūtes</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">Vai izdzēst sapulci?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_10">
      <source>10 minutes</source>
      <translation variants="no">10 minūtes</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Uzstādījumi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_tu">
      <source>Tu</source>
      <translation variants="no">Ot</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Rediģēšana:</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_all_calendar_entries">
      <source>Delete all calendar entries?</source>
      <translation variants="no">Vai izdzēst visus kalendāra ierakstus?</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_wk">
      <source>Wk</source>
      <translation variants="no">N.</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">Vai izdzēst uzdevumu?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_monday">
      <source>Monday</source>
      <translation variants="no">lv #Monday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on">
      <source>Week starts on</source>
      <translation variants="no">lv #Week starts on</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">Kalendārs</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_thursday">
      <source>Thursday</source>
      <translation variants="no">lv #Thursday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nē</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_unnamed">
      <source>Unnamed</source>
      <translation variants="no">Nenosaukta</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_switch_to_day_view">
      <source>Switch to Day view</source>
      <translation variants="no">Pārslēgties uz dienas skatu</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_5_m">
      <source>5 minutes</source>
      <translation variants="no">5 minūtes</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event?</source>
      <translation variants="no">Vai dzēst visas dienas ierakstu?</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[28]1, %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Tikai šo gadījumu</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_entries">
      <source>Delete entries</source>
      <translation variants="no">Dzēst ierakstus</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Visus gadījumus</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_fr">
      <source>Fr</source>
      <translation variants="no">Pk</translation>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_snooze_time_val_ln">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">%Ln minūte</numerusform>
        <numerusform plurality="b">%Ln minūtes</numerusform>
        <numerusform plurality="c">%Ln minūšu</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nē</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_show_lunar_data">
      <source>Show lunar data</source>
      <translation variants="no">Rādīt mēness datus</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_event">
      <source>New event</source>
      <translation variants="no">Jauns ieraksts</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_before_date">
      <source>Before date</source>
      <translation variants="no">Pirms izvēlētā datuma</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_th">
      <source>Th</source>
      <translation variants="no">Ce</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_buddhist_year">
      <source>Show buddhist year</source>
      <translation variants="no">Rādīt budistu kalendāru</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time">
      <source>Reminder snooze time</source>
      <translation variants="no">Atgādin. atlikšanas laiks</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_week_numbers">
      <source>Show week numbers</source>
      <translation variants="no">Nedēļu numuri</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_no_entries">
      <source>No entries for today</source>
      <translation variants="no">Šodien nav neviena ieraksta</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Atzīmēt kā pabeigtu</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_today">
      <source>Go to today</source>
      <translation variants="no">Atvērt šodienu</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_switch_to_agenda_view">
      <source>Switch to Agenda view</source>
      <translation variants="no">Switch to agenda-view</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_30">
      <source>30 minutes</source>
      <translation variants="no">30 minūtes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_saturday">
      <source>Saturday</source>
      <translation variants="no">lv #Saturday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_sunday">
      <source>Sunday</source>
      <translation variants="no">lv #Sunday</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">lv #Tuesday</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Jā</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Jā</lengthvariant>
      </translation>
    </message>
  </context>
</TS>