<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_lint_button_done">
      <source>Done</source>
      <translation variants="no">کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_lint_list_descending">
      <source>Descending</source>
      <translation variants="no">گھٹتی ترتیب</translation>
    </message>
    <message numerus="no" id="txt_lint_list_sort_by">
      <source>Sort by </source>
      <translation variants="no">سے چھانٹیں</translation>
    </message>
    <message numerus="no" id="txt_lint_list_contact_addresses">
      <source>Contact addresses</source>
      <translation variants="no">رابطے کے پتے</translation>
    </message>
    <message numerus="no" id="txt_lint_list_remove_thumbnail">
      <source>Remove thumbnail</source>
      <translation variants="no">مخت. تصویر ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_lint_list_arrange">
      <source>Arrange</source>
      <translation variants="no">منظم کریں</translation>
    </message>
    <message numerus="no" id="txt_lint_list_ascending">
      <source>Ascending</source>
      <translation variants="no">بڑھتی ترتیب</translation>
    </message>
    <message numerus="no" id="txt_lint_list_type">
      <source>Type</source>
      <translation variants="no">قسم</translation>
    </message>
    <message numerus="no" id="txt_lint_list_places">
      <source>Places</source>
      <translation variants="no">مقامات</translation>
    </message>
    <message numerus="no" id="txt_lint_list_recent_map_searches">
      <source>Recent map searches</source>
      <translation variants="no">حالیہ نقشے کی تلاشیں</translation>
    </message>
    <message numerus="no" id="txt_lint_list_details">
      <source>Details</source>
      <translation variants="no">تفصیلات</translation>
    </message>
    <message numerus="no" id="txt_lint_list_calendar_event_locations">
      <source>Calendar event locations</source>
      <translation variants="no">کیلنڈر اندراج کے مقامات</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_results">
      <source>No results</source>
      <translation variants="no">(کوئی نتیجہ نہیں ملا)</translation>
    </message>
    <message numerus="no" id="txt_lint_list_no_location_entries_present">
      <source>No Location entries present</source>
      <translation variants="no">(کوئی مقام نہیں)</translation>
    </message>
    <message numerus="no" id="txt_lint_title_select_location">
      <source>Select location</source>
      <translation variants="no">مقام منتخب</translation>
    </message>
  </context>
</TS>