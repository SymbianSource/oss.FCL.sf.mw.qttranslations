<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_inst_info_error_cert_unsupported">
      <source>Application has been signed with a certificate that is not supported in this device.</source>
      <translation variants="no">本裝置不支援簽署此應用程式的證書。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_bad_syntax">
      <source>Attribute %1 has bad syntax.</source>
      <translation variants="no">"%[98]1"屬性無效。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_cancel">
      <source>Installation cancelled.</source>
      <translation variants="no">已取消安裝。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_net_detail">
      <source>Cannot download installation package from URL %1.</source>
      <translation variants="no">無法從此網址下載安裝套件：
%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_push_reg">
      <source>Push registration failed.</source>
      <translation variants="no">註冊失敗。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_mismatch">
      <source>Attritbute %1 is different in JAD and JAR files.</source>
      <translation variants="no">JAD和JAR檔案中的"%[98]1"屬性不同。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_authentication">
      <source>Application authentication failed.</source>
      <translation variants="no">應用程式認證失敗。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_different_signers">
      <source>The signers of the update and the already installed applications do not match.</source>
      <translation variants="no">簽署更新的證書與目前已安裝應用程式的證書不同。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_pkg_misuse">
      <source>Package %1 is protected and can not be used.</source>
      <translation variants="no">套件"%[98]1"受到保護而且無法使用。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_mem_detail_mb">
      <source>Application requires %L1 MB of memory. You have to remove other applications or data from the device to install the application</source>
      <translation variants="no">記憶體不足。應用程式需要%L1 MB。請移除一些其他應用程式或數據並重試。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_missing">
      <source>Mandatory attribute %1 is missing.</source>
      <translation variants="no">缺少必要的"%[98]1"屬性。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_authorization">
      <source>Application authorization failed.</source>
      <translation variants="no">應用程式授權失敗。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_internal_error">
      <source>Internal error: %1</source>
      <translation variants="no">內部錯誤：
%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_uninst_cancel">
      <source>Uninstallation cancelled.</source>
      <translation variants="no">已取消軟件移除。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_mem_detail">
      <source>Application requires %L1 kB of memory. You have to remove other applications or data from the device to install the application</source>
      <translation variants="no">記憶體不足。應用程式需要%L1 kB。請移除一些其他應用程式或數據並重試。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_uninst_blocked">
      <source>Uninstallation is blocked by an attribute in application.</source>
      <translation variants="no">應用程式中的一項屬性不允許移除軟件。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_uninst_unexpected">
      <source>Unable to uninstall. Unexpected error.</source>
      <translation variants="no">無法移除軟件。發生未預期的錯誤。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_unsupported_value">
      <source>Attribute %1 has unsupported value.</source>
      <translation variants="no">"%[98]1"屬性中的值無效。</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_handling_failed">
      <source>Attribute %1 handling failed.</source>
      <translation variants="no">"%[98]1"屬性的處理失敗。</translation>
    </message>
  </context>
</TS>