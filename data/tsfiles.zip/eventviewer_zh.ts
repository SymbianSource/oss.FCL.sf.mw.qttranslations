<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_dblist_repeats_weekly">
      <source>Repeats weekly</source>
      <translation variants="no">每周重复</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_fortnightly">
      <source>Repeats fortnightly</source>
      <translation variants="no">每两周重复</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_find_location_on_map">
      <source>Find location on map</source>
      <translation variants="no">在地图上查找位置</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_all_day_event">
      <source>All day event</source>
      <translation variants="no">全天日历项</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_subject">
      <source>Subject</source>
      <translation variants="no">主题：</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_description">
      <source>Description:</source>
      <translation variants="no">描述：</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_monthly">
      <source>Repeats monthly</source>
      <translation variants="no">每月重复</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">仅此次</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">编辑重复项：</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_yearly">
      <source>Repeats Yearly</source>
      <translation variants="no">每年重复</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">删除待办事项？</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="no">日历</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_from_1">
      <source>From %1</source>
      <translation variants="no">从%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_finding_location_on_m">
      <source>Finding location on map…</source>
      <translation variants="no">正在地图上查找位置</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_location_not_found_on">
      <source>Location not found on map</source>
      <translation variants="no">未在地图上找到位置</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">标记为完成</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_workdays">
      <source>Repeats workdays</source>
      <translation variants="no">工作日重复</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily">
      <source>Repeats daily</source>
      <translation variants="no">每天重复</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">标记为未完成</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="no">(未命名)</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">删除会议？</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="no">待办事项</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_until_1">
      <source>Until %1</source>
      <translation variants="no">至%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_select_location">
      <source>Select location :</source>
      <translation variants="no">选择位置：</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="no">完成日期：</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="no">会议</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">全部重复项目</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event ?</source>
      <translation variants="no">删除重复项：</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">删除重复项：</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_location_val_select_location_from">
      <source>Select location from search results</source>
      <translation variants="no">选择位置</translation>
    </message>
  </context>
</TS>