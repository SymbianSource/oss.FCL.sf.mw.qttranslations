<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_sett_setlabel_low_level_net_access">
      <source>Low level network access</source>
      <translation variants="no">低階網絡接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_app_auto_invoc">
      <source>Application auto invocation</source>
      <translation variants="no">應用程式自動啟動</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_smartcard">
      <source>Smart card communication</source>
      <translation variants="no">智慧卡</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_url_start">
      <source>URL start</source>
      <translation variants="no">網絡接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_write_data">
      <source>Write user data</source>
      <translation variants="no">寫入用戶數據</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_auth">
      <source>Authentication</source>
      <translation variants="no">認證</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_net">
      <source>Choosing this item may result in compromised privacy or increased network usage costs. Continue? </source>
      <translation variants="no">所選的設定可能會洩露私隱或增加網絡使用費用。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_call_control">
      <source>Call control</source>
      <translation variants="no">通話控制</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_oneshot">
      <source>Oneshot</source>
      <translation variants="yes">
        <lengthvariant priority="1">長期請求</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_net_access">
      <source>Net access</source>
      <translation variants="no">網絡接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_user_defined">
      <source>User defined</source>
      <translation variants="no">用戶自定義</translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_game">
      <source>Game keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">遊戲鍵</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level">
      <source>Security warnings</source>
      <translation variants="no">警告</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_net">
      <source>Allowing these permissions may result in compromised privacy or increased network usage costs.</source>
      <translation variants="no">允許這些權限可能會洩露私隱或增加網絡使用費用</translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_note_security_warn">
      <source>Security warning</source>
      <translation variants="no">安全性警告</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission">
      <source>Permission type</source>
      <translation variants="no">應用程式接入</translation>
    </message>
    <message numerus="no" id="txt_java_sett_title_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_security_level_val_default">
      <source>Default</source>
      <translation variants="no">預設</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_landmarks">
      <source>Landmarks</source>
      <translation variants="no">地標</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_local_conn">
      <source>Local connectivity</source>
      <translation variants="no">連接</translation>
    </message>
    <message numerus="no" id="txt_java_sett_button_settings_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">確定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_warn">
      <source>Changing this setting item will cause changes in other settings. Continue? </source>
      <translation variants="no">更換本設定將造成其他設定的變更。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_blanket">
      <source>Blanket</source>
      <translation variants="yes">
        <lengthvariant priority="1">長期允許</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_messaging">
      <source>Messaging</source>
      <translation variants="no">訊息</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_location">
      <source>Location</source>
      <translation variants="no">定位</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_no">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">無</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk">
      <source>On-screen-keypad</source>
      <translation variants="no">鍵盤</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_mm_record">
      <source>Multimedia recording</source>
      <translation variants="no">多媒體</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_broadcast">
      <source>Broadcast</source>
      <translation variants="no">電視用戶數據</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_permission_val_session">
      <source>Session</source>
      <translation variants="yes">
        <lengthvariant priority="1">僅第一次請求</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_nfc_write_access">
      <source>NFC Write access</source>
      <translation variants="no">NFC發送</translation>
    </message>
    <message numerus="no" id="txt_java_sett_subhead_general">
      <source>General</source>
      <translation variants="no">一般</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_settings_not_available">
      <source>Settings not available</source>
      <translation variants="no">(設定無法使用)</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_query_perm_sec">
      <source>Choosing this item may cause your privacy to be compromised. Continue? </source>
      <translation variants="no">所選的設定可能會洩露您的私隱。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_restricted_messaging">
      <source>Restricted messaging</source>
      <translation variants="no">限定訊息</translation>
    </message>
    <message numerus="no" id="txt_java_sett_info_inst_query_perm_sec">
      <source>Allowing these permissions may result in compromised privacy.</source>
      <translation variants="no">允許這些權限可能會洩露私隱</translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_osk_val_navigation">
      <source>Navigation keys</source>
      <translation variants="yes">
        <lengthvariant priority="1">瀏覽鍵</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_sett_setlabel_read_data">
      <source>Read user data</source>
      <translation variants="no">讀取用戶數據</translation>
    </message>
    <message numerus="no" id="txt_java_sett_subhead_security">
      <source>Security</source>
      <translation variants="no">安全性</translation>
    </message>
  </context>
</TS>