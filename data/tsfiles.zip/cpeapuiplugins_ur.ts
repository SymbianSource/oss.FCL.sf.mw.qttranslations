<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_user_certificate">
      <source>User certificate</source>
      <translation variants="no">ذاتی سند</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv0">
      <source>PEAPv0</source>
      <translation variants="no">PEAPv۰</translation>
    </message>
    <message numerus="no" id="txt_occ_button_reset_pac_store">
      <source>Reset PAC store</source>
      <translation variants="no">PAC اسٹور کو دوبارہ مرتب کریں</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy">
      <source>TLS privacy</source>
      <translation variants="no">TLS راز داری</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_realm_val_generate_automatically">
      <source>Generate automatically</source>
      <translation variants="no">خودکار طور پر ساخت کریں</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_provisioning_enabled">
      <source>Enabled</source>
      <translation variants="no">فعال شدہ</translation>
    </message>
    <message numerus="no" id="txt_occ_info_remove_pac_store_all_credentials_wil">
      <source>Remove PAC store? All credentials will be lost.</source>
      <translation variants="no">PAC اسٹور ہٹائیں؟ تمام صداقت نامے ضائع ہو جائیں گے۔</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password_val_user_defin">
      <source>User defined</source>
      <translation variants="no">صارف وضاحت کردہ</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_cipher_suites">
      <source>Cipher suites</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cipher suites</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_second_inner_eap_type">
      <source>Second inner EAP type</source>
      <translation variants="no">دوسرا اندرونی EAP ٹائپ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version">
      <source>PEAP version</source>
      <translation variants="no">PEAP ورژن</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv0_or_peapv1">
      <source>PEAPv0 or PEAPv1</source>
      <translation variants="no">PEAPv۰ یا PEAPv۱</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password">
      <source>PAC store password</source>
      <translation variants="no">PAC اسٹور لفظ شناخت</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy_val_on">
      <source>On</source>
      <translation variants="no">چالو</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_pac_store">
      <source>PAC store</source>
      <translation variants="yes">
        <lengthvariant priority="1">PAC اسٹور</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate_val_not_in">
      <source>(not in use)</source>
      <translation variants="no">زیر استعمال نہیں</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate">
      <source>Authority certificate</source>
      <translation variants="no">تصدیقی سند</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_second_inner_eap_val_not_in_use">
      <source>(not in use)</source>
      <translation variants="no">(استعمال میں نہیں)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_tls_privacy_val_off">
      <source>Off</source>
      <translation variants="no">بند</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_certificate_val_not_in_use">
      <source>(not in use)</source>
      <translation variants="no">زیر استعمال نہیں</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_generate_automatica">
      <source>Generate automatically</source>
      <translation variants="no">خودکار طور پر ساخت کریں</translation>
    </message>
    <message numerus="no" id="txt_occ_info_pac_store_password_will_no_longer_be">
      <source>PAC store password will no longer be stored in phone and should be memorised. Continue?</source>
      <translation variants="no">PAC اسٹور لفظ شناخت آلے میں مزید نہیں رکھا جائے گا اور اسے یاد رکھنا چاہیے۔ جاری رکھیں؟</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_pac_store_password_val_prompt">
      <source>Prompt</source>
      <translation variants="no">ہدایت</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_eap_module_settings">
      <source>%1 settings</source>
      <translation variants="no">%[15]1 ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authority_certificate_val_select">
      <source>Select automatically</source>
      <translation variants="no">خودکار طور پر منتخب کریں</translation>
    </message>
    <message numerus="no" id="txt_occ_button_inner_eap_type">
      <source>Configure inner EAP type</source>
      <translation variants="no">داخلی EAP قسم کی تشکیل کریں</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_realm">
      <source>Realm</source>
      <translation variants="no">منطقہ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unauthenticated_provisioning">
      <source>Unauthenticated provisioning</source>
      <translation variants="no">غیر محفوظ فراہمی</translation>
    </message>
    <message numerus="no" id="txt_occ_info_existing_password_cannot_be_changed">
      <source>Existing password cannot be changed. Select 'Reset PAC store' to reset the store and password.</source>
      <translation variants="no">موجودہ لفظ. بدلا نہیں جا سکتا۔ اسٹور و لفظ. ہٹانے کیلیے PAC' اسٹور ہٹائیں' منتخب۔</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authenticated_provisioning">
      <source>Authenticated provisioning</source>
      <translation variants="no">محفوظ فراہمی</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_peap_version_val_peapv1">
      <source>PEAPv1</source>
      <translation variants="no">PEAPv۱</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_inner_eap_type">
      <source>Inner EAP type</source>
      <translation variants="no">داخلی EAP قسم</translation>
    </message>
  </context>
</TS>