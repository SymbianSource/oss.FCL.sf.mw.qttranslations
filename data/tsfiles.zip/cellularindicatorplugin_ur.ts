<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="yes" id="txt_occ_dblist_cellular_data_val_l1_connections">
      <source>%Ln connections</source>
      <translation>
        <numerusform plurality="a">%Ln اتصال</numerusform>
        <numerusform plurality="b">%Ln اتصالات</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_cellular_data">
      <source>Cellular data</source>
      <translation variants="no">سیلولر ڈیٹا</translation>
    </message>
  </context>
</TS>