<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="sl">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Source 0</source>
      <translation variants="no">Spremeni čas vidnosti</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_input_devices">
      <source>Source 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ vhodne naprave</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>Source 2</source>
      <translation variants="no">Vse naprave</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_phones">
      <source>Source 3</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni telefonov</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_input_devices">
      <source>Source 4</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ seznanjene vhodne naprave</lengthvariant>
        <lengthvariant priority="2">Bluetooth ‐ seznan. vhod. naprave</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>Source 5</source>
      <translation variants="no">Podrobnosti naprave %1</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Source 6</source>
      <translation variants="no">italijanščina</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Source 7</source>
      <translation variants="yes">
        <lengthvariant priority="1">Seznanjena</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_paired_devices">
      <source>Source 8</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni drugih seznanjenih naprav</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>Source 9</source>
      <translation variants="no">Povezana z napravo %[07]1</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Source 10</source>
      <translation variants="yes">
        <lengthvariant priority="1">Samodejno</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Source 11</source>
      <translation variants="yes">
        <lengthvariant priority="1">Seznanjena, preverjena, povezana</lengthvariant>
        <lengthvariant priority="2">Seznanjena, preverjena, povez.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Source 12</source>
      <translation variants="yes">
        <lengthvariant priority="1">sl #Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Source 13</source>
      <translation variants="yes">
        <lengthvariant priority="1">Seznanjena, povezana</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_phones">
      <source>Source 14</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ telefoni</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Source 15</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ vse naprave</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Source 16</source>
      <translation variants="no">belgijska francoščina</translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Source 17</source>
      <translation variants="yes">
        <lengthvariant priority="1">Vhodna naprava</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Source 18</source>
      <translation variants="no">danščina</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Source 19</source>
      <translation variants="yes">
        <lengthvariant priority="1">Vedno vprašaj</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>Source 20</source>
      <translation variants="no">ZDA – mednarodna</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Source 21</source>
      <translation variants="no">Onemogočeno</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_input_devices">
      <source>Source 22</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni seznanjenih naprav</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Source 23</source>
      <translation variants="no">Seznanjene naprave</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_devices">
      <source>Source 24</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ druge naprave</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Source 25</source>
      <translation variants="yes">
        <lengthvariant priority="1">Računalnik</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>Source 26</source>
      <translation variants="yes">
        <lengthvariant priority="1">sl #On and hidden</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Source 27</source>
      <translation variants="no">finščina, švedščina</translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Source 28</source>
      <translation variants="yes">
        <lengthvariant priority="1">Drugo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Source 29</source>
      <translation variants="no">sl #Unpair</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_phones">
      <source>Source 30</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ seznanjeni telefoni</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Source 31</source>
      <translation variants="no">norveščina</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Source 32</source>
      <translation variants="no">portugalščina</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Source 33</source>
      <translation variants="yes">
        <lengthvariant priority="1">sl #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Source 34</source>
      <translation variants="no">Razporeditev tipkovnice</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Source 35</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nastavitve tipkovnice</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>Source 36</source>
      <translation variants="no">Združeno kraljestvo</translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Source 37</source>
      <translation variants="yes">
        <lengthvariant priority="1">Blokirano</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>Source 38</source>
      <translation variants="no">nemščina</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>Source 39</source>
      <translation variants="no">ZDA – Dvorakova</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Source 40</source>
      <translation variants="no">španščina</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_audio_devices">
      <source>Source 41</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ zvočne naprave</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_computers">
      <source>Source 42</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ računalniki</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>Source 43</source>
      <translation variants="yes">
        <lengthvariant priority="1">Naprav ni mogoče najti</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Source 44</source>
      <translation variants="yes">
        <lengthvariant priority="1">Blokirano</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_audio_devices">
      <source>Source 45</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni zvočnih naprav</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>Source 46</source>
      <translation variants="no">francoščina</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_computers">
      <source>Source 47</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni računalnikov</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_audio_devices">
      <source>Source 48</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ seznanjene zvočne naprave</lengthvariant>
        <lengthvariant priority="2">Bluetooth ‐ seznan. zvočne naprave</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Source 49</source>
      <translation variants="no">sl #Search completed</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_other_paired_devices">
      <source>Source 50</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ druge seznanjene naprave</lengthvariant>
        <lengthvariant priority="2">Bluetooth ‐ druge seznan. naprave</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Source 51</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ dodatne nastavitve</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_audio_devices">
      <source>Source 52</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni drugih seznanjenih zvočnih naprav</lengthvariant>
        <lengthvariant priority="2">Ni drugih sezn. zvočn. naprav</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Source 53</source>
      <translation variants="no">sl #Pair</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Source 54</source>
      <translation variants="yes">
        <lengthvariant priority="1">Povezava</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_1">
      <source>Source 55</source>
      <translation variants="no">Bluetooth ‐ %1</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Source 56</source>
      <translation>
        <numerusform plurality="a">sl #Visible for %Ln minute</numerusform>
        <numerusform plurality="b">sl #Visible for %Ln minutes</numerusform>
        <numerusform plurality="c">sl #MISSING</numerusform>
        <numerusform plurality="d">sl #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_phones">
      <source>Source 57</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni seznanjenih telefonov</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_other_devices">
      <source>Source 58</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni drugih naprav</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Source 59</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nastavitve miške</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Source 60</source>
      <translation variants="yes">
        <lengthvariant priority="1">sl #Visible and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Source 61</source>
      <translation variants="no">Odstrani</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>Source 62</source>
      <translation variants="no">ZDA ‐ angleščina</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Source 63</source>
      <translation variants="no">sl #Searching</translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Source 64</source>
      <translation variants="yes">
        <lengthvariant priority="1">Povezana</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>Source 65</source>
      <translation variants="no">Način dostopa do kartice SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Source 66</source>
      <translation variants="no">Odstrani seznan. naprave</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Source 67</source>
      <translation variants="no">Omogočeno</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Source 68</source>
      <translation variants="no">Blokirane naprave</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Source 69</source>
      <translation variants="no">sl #Hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Source 70</source>
      <translation variants="no">ruščina</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Source 71</source>
      <translation variants="no">Vzpostavi povezavo</translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Source 72</source>
      <translation variants="no">sl #Disconnect</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Source 73</source>
      <translation variants="no">sl #Device details</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>Source 74</source>
      <translation variants="yes">
        <lengthvariant priority="1">sl #On and visible</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Source 75</source>
      <translation variants="no">Prekini povezavo</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>Source 76</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni naprav</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Source 77</source>
      <translation variants="no">sl #Bluetooth - Found devices</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Source 78</source>
      <translation variants="yes">
        <lengthvariant priority="1">Telefon</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Source 79</source>
      <translation variants="yes">
        <lengthvariant priority="1">sl #Hidden and connected</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Source 80</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ seznanjene naprave</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>Source 81</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni seznanjenih naprav</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_input_devices">
      <source>Source 82</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni vhodnih naprav</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Source 83</source>
      <translation variants="yes">
        <lengthvariant priority="1">Seznanjena, preverjena</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Source 84</source>
      <translation variants="no">Dodatne nastavitve</translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Source 85</source>
      <translation variants="no">sl #Connect</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Source 86</source>
      <translation variants="no">sl #Visible</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Source 87</source>
      <translation variants="no">nizozemščina</translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Source 88</source>
      <translation variants="yes">
        <lengthvariant priority="1">Zvočna naprava</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_computers">
      <source>Source 89</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ni seznanjenih računalnikov</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_computers">
      <source>Source 90</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bluetooth ‐ seznanjeni računalniki</lengthvariant>
      </translation>
    </message>
  </context>
</TS>