<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dblist_wireless_lan_applib">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">LAN Không dây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_wireless_lan_val_applib">
      <source>Show WLAN status</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hiển thị trạng thái WLAN trên Màn hình chính</lengthvariant>
        <lengthvariant priority="2">H.thị tr.t WLAN trên M.h.chính</lengthvariant>
      </translation>
    </message>
  </context>
</TS>