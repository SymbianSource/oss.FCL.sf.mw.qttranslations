<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_power_management_subhead_power_management">
      <source>Power Management</source>
      <translation variants="yes">
        <lengthvariant priority="1">Quản lý nguồn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_management_dpopinfo_low_battery">
      <source>Low Battery</source>
      <translation variants="no">Pin yếu</translation>
    </message>
    <message numerus="no" id="txt_power_setlabel_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_setlabel_val_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bật</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_powermgt_title_power_management">
      <source>Power Management</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Power Management</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_powermgt_dblist_power_save_mode_enabled">
      <source>Power Save Mode enabled </source>
      <translation variants="no">vi #Power saving mode on</translation>
    </message>
    <message numerus="no" id="txt_power_management_dpophead_100_full">
      <source>100% Full</source>
      <translation variants="no">100% Đầy</translation>
    </message>
    <message numerus="no" id="txt_power_dpopinfo_unplug_charger_to_save_energy">
      <source>Unplug charger to save energy</source>
      <translation variants="no">Tháo bộ sạc</translation>
    </message>
    <message numerus="no" id="txt_powermgt_dblist_charging">
      <source>Charging</source>
      <translation variants="no">Đang sạc</translation>
    </message>
    <message numerus="no" id="txt_power_list_activate_power_save_mode_automatica">
      <source>Activate power save mode automatically when low power. Turns off automatically when charger is connected.</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tự động kích hoạt chế độ tiết kiệm pin khi pin yếu? Sạc thiết bị sẽ tự động vô hiệu chế độ này.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_list_activating_power_save_mode_will_con">
      <source>Activating power save mode will consumes minimal power. Turns off all power consuming operations/features like Bluetooth, WLAN, Vibra, Tactile feedback, Key tones, Screensaver, Wallpapers and also dimming screen brightness, Switching Network from 3G to 2G.Turns off automatically when charger is connected.</source>
      <translation variants="no">Kích hoạt chế độ tiết kiệm pin sẽ làm cho pin kéo dài lâu hơn. Điện thoại sẽ tắt tất cả các tính năng không cần thiết như Bluetooth, WLAN, rung, âm bàn phím và màn hình bảo vệ. Điện thoại cũng sẽ làm mờ màn hình và chuyển thiết bị sang sử dụng mạng 2G. Sạc thiết bị sẽ tự động vô hiệu chế độ này.</translation>
    </message>
    <message numerus="no" id="txt_power_list_power_save_mode">
      <source>Power Save Mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chế độ tiết kiệm pin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_management_dpopinfo_psm_activated_automa">
      <source>Power Save Mode activated</source>
      <translation variants="no">Bật chế độ tiết kiệm pin</translation>
    </message>
  </context>
</TS>