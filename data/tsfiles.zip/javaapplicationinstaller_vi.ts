<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_inst_dpopinfo_installation_complete">
      <source>Installation complete</source>
      <translation variants="no">Cài đặt hoàn tất</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_mb">
      <source>%1: Phone Memory (%L2 MB) </source>
      <translation variants="no">%[99]1: Bộ nhớ thiết bị (%L2 MB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_app_suite_name_version">
      <source>%1 (%2)</source>
      <translation variants="no">%[99]1 (%[99]2)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_downloading">
      <source>Downloading</source>
      <translation variants="no">Đang tải về</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_serial_number">
      <source>Serial number: %1</source>
      <translation variants="no">Số sê-ri: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_inst_pkg_not_cert">
      <source>Application %1 is from an unknown source. </source>
      <translation variants="no">Ứng dụng '%[99]1' từ nguồn không biết.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_kb">
      <source>%1: Memory card (%L2 kB) </source>
      <translation variants="no">%[99]1: Thẻ nhớ (%L2 kB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_mb">
      <source>%1: Unknown (%L2 MB)</source>
      <translation variants="no">%[99]1: Không biết (%L2 MB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_gb">
      <source>%1: Phone Memory (%L2 GB) </source>
      <translation variants="no">%[99]1: Bộ nhớ thiết bị (%L2 GB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_installation_complete">
      <source>Installed</source>
      <translation variants="no">Đã cài đặt</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_show">
      <source>Show</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hiển thị</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_dialog_username">
      <source>Username:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên người dùng:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_hide">
      <source>Hide</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ẩn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_manufacturer">
      <source>Manufacturer</source>
      <translation variants="no">Nhà sản xuất</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_downloading">
      <source>Downloading</source>
      <translation variants="no">vi #Downloading</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_app_name">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_valid_until">
      <source>Valid until: %1</source>
      <translation variants="no">Hợp lệ đến: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_install">
      <source>Install?</source>
      <translation variants="no">Cài đặt?</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_cancel_installing">
      <source>Cancel installing</source>
      <translation variants="no">Hủy cài đặt</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_perm_query">
      <source>Access to protected functionality needed.</source>
      <translation variants="no">Cần truy cập vào chức năng được bảo vệ.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_size_mb">
      <source>%L1 MB</source>
      <translation variants="no">%L1 MB</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_organization">
      <source>Organization: %1</source>
      <translation variants="no">Tổ chức: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installation_complete">
      <source>Installation complete</source>
      <translation variants="no">vi #Installation complete</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_mb">
      <source>%1: Internal Mass Storage (%L2 MB)</source>
      <translation variants="no">%[99]1: Bộ nhớ chung (%L2 MB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_gb">
      <source>%1: Memory card (%L2 GB) </source>
      <translation variants="no">%[99]1: Thẻ nhớ (%L2 GB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem">
      <source>%1: Internal Mass Storage</source>
      <translation variants="no">%[99]1: Bộ nhớ chung</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_ask_me_later">
      <source>Ask me later</source>
      <translation variants="no">Hỏi tôi sau</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_app_cert">
      <source>Application is certified.</source>
      <translation variants="no">vi #Application is certified.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_back_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_ocsp_check_progress">
      <source>Checking certificate validity</source>
      <translation variants="no">Đang kiểm tra hiệu lực chứng chỉ</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_operator_pref">
      <source>Operator preferred</source>
      <translation variants="no">Ưu tiên nhà điều hành</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem_kb">
      <source>%1: Phone Memory (%L2 kB) </source>
      <translation variants="no">%[99]1: Bộ nhớ thiết bị (%L2 kB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_ocsp_check_progress">
      <source>Checking certificate validity</source>
      <translation variants="no">vi #Checking validity</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_inst_failed">
      <source>Installation failed</source>
      <translation variants="no">Không cài đặt được</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_update_query">
      <source>Update?</source>
      <translation variants="no">Cập nhật?</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_auth_query">
      <source>Connect to</source>
      <translation variants="no">vi #Connect to server?</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_issuer">
      <source>Issuer: %1</source>
      <translation variants="no">Nhà phát hành: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_vendor">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_kb">
      <source>%1: Unknown (%L2 kB)</source>
      <translation variants="no">%[99]1: Không biết (%L2 kB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_dpopinfo_preparing_installation">
      <source>Preparing installation</source>
      <translation variants="no">Đang chuẩn bị cài đặt</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_phone_mem">
      <source>%1: Phone memory</source>
      <translation variants="no">%[99]1: Bộ nhớ thiết bị</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_valid_from">
      <source>Valid from: %1</source>
      <translation variants="no">Hợp lệ từ: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_kb">
      <source>%1: Internal Mass Storage (%L2 kB)</source>
      <translation variants="no">%[99]1: Bộ nhớ chung (%L2 kB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_view_perm_details">
      <source>Details</source>
      <translation variants="no">Chi tiết</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_operator">
      <source>Operator</source>
      <translation variants="no">Nhà điều hành</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_untrusted_third_party">
      <source>Untrusted 3rd party</source>
      <translation variants="no">Bên thứ ba không tin cậy</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đóng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_listl_mem_card">
      <source>%1: Memory card</source>
      <translation variants="no">%[99]1: Thẻ nhớ</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain">
      <source>Domain: %1</source>
      <translation variants="no">Tên miền: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_perm_view_details">
      <source>Application asks permissions for:</source>
      <translation variants="no">vi #Application asks permissions for:</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_update_query">
      <source>%1 from %2 to %3?</source>
      <translation variants="no">%[99]1 từ %[99]2 đến %[99]3?</translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_installing">
      <source>Installing</source>
      <translation variants="no">Đang cài đặt</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installing">
      <source>Installing</source>
      <translation variants="no">vi #Installing</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_cert_domain_val_trusted_third_party">
      <source>Trusted 3rd party</source>
      <translation variants="no">Bên thứ ba tin cậy</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_auth_yourself">
      <source>To download %1 you need to authenticate yourself</source>
      <translation variants="no">Đăng nhập để tải về '%[99]1'.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown">
      <source>%1: Unknown</source>
      <translation variants="no">%[99]1: Không biết</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_perm_allow_always">
      <source>Allow always</source>
      <translation variants="no">Luôn cho phép</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_push_registration_static">
      <source>Registration for automatic start needed. Note that installation will fail if not allowed.</source>
      <translation variants="no">vi #Application will be registered for auto-start otherwise installation will fail.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mass_mem_gb">
      <source>%1: Internal Mass Storage (%L2 GB)</source>
      <translation variants="no">%[99]1: Bộ nhớ chung (%L2 GB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_unknown_gb">
      <source>%1: Unknown (%L2 GB)</source>
      <translation variants="no">%[99]1: Không biết (%L2 GB)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_preparing_installation">
      <source>Preparing installation</source>
      <translation variants="no">vi #Preparing</translation>
    </message>
    <message numerus="no" id="txt_java_inst_dialog_password">
      <source>Password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mật khẩu:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_update_retain_user_data">
      <source>Retain application data</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giữ dữ liệu ứng dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_size_kb">
      <source>%L1 kB</source>
      <translation variants="no">%L1 kB</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_mem_card_mb">
      <source>%1: Memory card (%L2 MB) </source>
      <translation variants="no">%[99]1: Thẻ nhớ (%L2 MB) </translation>
    </message>
    <message numerus="no" id="txt_java_inst_title_app_not_cert">
      <source>Application is not certified.</source>
      <translation variants="no">vi #Application is not certified.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_list_installing_progress">
      <source>%1 (%2 %)</source>
      <translation variants="no">vi #%[08]1 (%[08]2%)</translation>
    </message>
    <message numerus="no" id="txt_java_inst_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hủy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_subject">
      <source>Subject: %1</source>
      <translation variants="no">Chủ đề: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_setlabel_fingerprint">
      <source>Fingerprint (SHA1): %1</source>
      <translation variants="no">Dấu vân tay (SHA1): %1</translation>
    </message>
  </context>
</TS>