<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_pin_code_dialog_upin_code">
      <source>UPIN code:</source>
      <translation variants="no">UPIN碼：</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dialog_verify_new_pin_code">
      <source>Retype PIN code:</source>
      <translation variants="no">確認PIN碼：</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">只允許緊急通話</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_operation_not_allowed">
      <source>Operation not Allowed</source>
      <translation variants="no">不允許執行操作</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dialog_new_pin_code">
      <source>New PIN code:</source>
      <translation variants="no">新PIN碼：</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_pin2_rejected">
      <source>PIN2 rejected</source>
      <translation variants="no">zh_hk #PIN2 blocked. Contact SIM provider.</translation>
    </message>
    <message numerus="yes" id="txt_pin_code_dpopinfo_ln_attempts_remaining">
      <source> %Ln attempts remaining</source>
      <translation>
        <numerusform plurality="a">還可嘗試%Ln次</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpophead_last_attempt">
      <source>Last attempt</source>
      <translation variants="no">最後一次嘗試</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dialog_pin_code">
      <source>PIN code:</source>
      <translation variants="no">PIN碼：</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dialog_retype_upin_code">
      <source>Retype UPIN code:</source>
      <translation variants="no">確認UPIN碼：</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_upin_not_allowed">
      <source>UPIN not Allowed</source>
      <translation variants="no">zh_hk #SIM card does not support use of UPIN</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_gsm_invalid_parameter">
      <source>Gsm Invalid Parameter</source>
      <translation variants="no">不能執行操作</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpophead_wrong_pin_code">
      <source>Wrong PIN code</source>
      <translation variants="no">PIN碼不正確</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_insert_sim">
      <source>Insert SIM</source>
      <translation variants="no">插入SIM卡</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dialog_new_upin_code">
      <source>New UPIN code:</source>
      <translation variants="no">新UPIN碼：</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_operation_not_supported">
      <source>Operation not supported</source>
      <translation variants="no">不能執行操作</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_security_blocked">
      <source>Security Blocked</source>
      <translation variants="no">zh_hk #Code blocked. Contact Nokia Care.</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dialog_pin2_code">
      <source>PIN2 code:</source>
      <translation variants="no">PIN2碼：</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_autolock_must_be_active">
      <source>Autolock must be active</source>
      <translation variants="no">必須啟用自動鎖定</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_access_denied">
      <source>Access Denied</source>
      <translation variants="no">密碼不正確</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_if_failed_be_ready_with_puk">
      <source>If failed call customer care to get PUK code</source>
      <translation variants="no">zh_hk #If this does not work, call your network operator to get a PIN Unblock Code (PUK)</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dialog_puk_code">
      <source>PUK code:</source>
      <translation variants="no">PUK碼：</translation>
    </message>
    <message numerus="no" id="txt_pin_code_dpopinfo_code_chaged">
      <source>Code chaged</source>
      <translation variants="no">密碼已更換</translation>
    </message>
  </context>
</TS>