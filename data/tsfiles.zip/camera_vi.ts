<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cam_list_portrait">
      <source>Portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer">
      <source>Self timer</source>
      <translation variants="no">Hẹn giờ chụp tự động</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_portrait">
      <source>Night portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Night portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sports">
      <source>Sports</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Sport</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode">
      <source>Camera in stand-by mode</source>
      <translation variants="no">Camera ở chế độ chờ</translation>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bù trừ độ phơi sáng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_landscape">
      <source>Landscape</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Landscape</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos">
      <source>Go to Photos</source>
      <translation variants="no">Hình ảnh</translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln giây</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">vi #Exposure compensation</translation>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone">
      <source>Color tone</source>
      <translation variants="no">vi #Colour tone</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_43">
      <source>VGA 4:3</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA 4:3</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_qcif_sharing">
      <source>QCIF Sharing</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chia sẻ QCIF</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga">
      <source>VGA</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance">
      <source>White balance</source>
      <translation variants="no">vi #White balance</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">Hiển thị hình ảnh đã chụp</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_lightsens">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tự động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_incandescent">
      <source>Incandescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sáng chói</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_geotagging">
      <source>Geotagging</source>
      <translation variants="no">vi #Geotagging</translation>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity">
      <source>Light sensitivity</source>
      <translation variants="yes">
        <lengthvariant priority="1">Độ nhạy sáng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_closeup">
      <source>Close-up</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cận cảnh</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_timer">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings">
      <source>Camera settings</source>
      <translation variants="no">Cài đặt camera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_fluorescent">
      <source>Fluorescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ánh đèn trắng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_camera">
      <source>Camera</source>
      <translation variants="no">vi #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_video">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ban đêm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hủy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">Người dùng xác định</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tiếp tục</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip">
      <source>Delete video clip?</source>
      <translation variants="no">Xóa video clip?</translation>
    </message>
    <message numerus="no" id="txt_cam_button_start">
      <source>Start</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bắt đầu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image">
      <source>Delete image?</source>
      <translation variants="no">Xóa hình ảnh?</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_set_as_default_scene_mode">
      <source>Set as default scene mode</source>
      <translation variants="no">Đ.làm c.đ c.cảnh m.định</translation>
    </message>
    <message numerus="no" id="txt_cam_button_contrast">
      <source>Contrast</source>
      <translation variants="no">vi #Contrast</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">Hiển thị video đã ghi</translation>
    </message>
    <message numerus="no" id="txt_cam_list_reduce_red_eye">
      <source>Reduce red eye</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giảm mắt đỏ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality">
      <source>Image quality</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chất lượng hình ảnh</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">Âm chụp</translation>
    </message>
    <message numerus="no" id="txt_cam_list_negative">
      <source>Negative</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm bản</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_169_widescreen">
      <source>HD 720p 16:9 widescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">Màn hình rộng HD 720p 16:9</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sunny">
      <source>Sunny</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhiều nắng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name">
      <source>Default image name</source>
      <translation variants="no">Tên hình ảnh mặc định</translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left">
      <source>%Ln images left</source>
      <translation>
        <numerusform plurality="a">Còn lại %Ln hình ảnh</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_camera">
      <source>Camera</source>
      <translation variants="no">vi #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_grid_sharpness">
      <source>Sharpness</source>
      <translation variants="no">vi #Sharpness</translation>
    </message>
    <message numerus="no" id="txt_long_caption_camera">
      <source>Camera</source>
      <translation variants="no">Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tiếp tục</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance">
      <source>White balance</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cân bằng trắng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings">
      <source>General settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality">
      <source>Image quality</source>
      <translation variants="no">Chất lượng hình ảnh</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sepia">
      <source>Sepia</source>
      <translation variants="yes">
        <lengthvariant priority="1">Màu nâu đỏ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos">
      <source>Go to 'Videos'</source>
      <translation variants="no">Video clip</translation>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone">
      <source>Color tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tông màu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality">
      <source>Video quality</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chất lượng video</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality">
      <source>Video quality</source>
      <translation variants="no">Chất lượng video</translation>
    </message>
    <message numerus="no" id="txt_cam_list_geotagging_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode">
      <source>Scene mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chế độ chụp cảnh</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_val_ln_recording_time_left">
      <source>Recording time left: %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời gian ghi còn lại: %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_not_video">
      <source>Not</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image">
      <source>Show captured image</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hiển thị hình ảnh đã chụp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode_video">
      <source>Scene mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Scene mode</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene_video">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Automatic</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_fullscreen_imagesleft">
      <source>%L1</source>
      <translation variants="no">vi #%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_list_geotagging_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #On</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_flash_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_flash_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #On</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_sharpness">
      <source>Sharpness</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Sharpness</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video">
      <source>Show captured video</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hiển thị video đã ghi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking">
      <source>Face tracking</source>
      <translation variants="no">vi #Face detection</translation>
    </message>
    <message numerus="no" id="txt_cam_list_vivid">
      <source>Vivid</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sặc sỡ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_cloudy">
      <source>Cloudy</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhiều mây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_iso_l1">
      <source>ISO %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #ISO %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tự động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">Camera</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix">
      <source>%Ln Mpix</source>
      <translation>
        <numerusform plurality="a">%Ln Mpix</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_never">
      <source>Never</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Never</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_normal">
      <source>Normal</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bình thường</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix_widescreen">
      <source>%Ln Mpix widescreen</source>
      <translation>
        <numerusform plurality="a">Màn hình rộng %Ln Mpix</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus">
      <source>+%L1</source>
      <translation variants="no">+%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode">
      <source>Flash mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">Flash</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound">
      <source>Video sound</source>
      <translation variants="no">Âm thanh video</translation>
    </message>
    <message numerus="no" id="txt_cam_list_low_light">
      <source>Low light</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ánh sáng yếu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use">
      <source>Camera already in use</source>
      <translation variants="no">Camera đã được một ứng dụng khác sử dụng</translation>
    </message>
    <message numerus="no" id="txt_cam_list_scene_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #On</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_error">
      <source>Unexpected error occurred. Power off the device and restart</source>
      <translation variants="no">Xảy ra lỗi ngoài ý muốn. Khởi động lại điện thoại.</translation>
    </message>
    <message numerus="no" id="txt_cam_list_scene_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_contrast">
      <source>Contrast</source>
      <translation variants="yes">
        <lengthvariant priority="1">Độ tương phản</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds">
      <source>%Ln seconds</source>
      <translation>
        <numerusform plurality="a">%Ln giây</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_white">
      <source>Black and white</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trắng đen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_night">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ban đêm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer">
      <source>Self timer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hẹn giờ chụp tự động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_iso">
      <source>ISO</source>
      <translation variants="no">vi #ISO</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name">
      <source>Default video name</source>
      <translation variants="no">Tên video mặc định</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_whitebal">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tự động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_flash">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tự động</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln giây</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_geotagging">
      <source>Geotagging</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Geotagging</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_169_widescreen">
      <source>VGA 16:9 widescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #VGA 16:9 widescreen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus">
      <source>-%L1</source>
      <translation variants="no">-%L1</translation>
    </message>
  </context>
</TS>