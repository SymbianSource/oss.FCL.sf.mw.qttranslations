<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ja">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_dblist_meeting_date">
      <source>Source 0</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Source 1</source>
      <translation variants="no">Delete To-do note?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_from_1">
      <source>Source 2</source>
      <translation variants="no">From %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>Source 3</source>
      <translation variants="yes">
        <lengthvariant priority="1">To do</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_not_done">
      <source>Source 4</source>
      <translation variants="no">Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_reminder_time_date">
      <source>Source 5</source>
      <translation variants="no">%1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_event">
      <source>Source 6</source>
      <translation variants="yes">
        <lengthvariant priority="1">Event</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_occasion">
      <source>Source 7</source>
      <translation variants="yes">
        <lengthvariant priority="1">Occasion:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_fortnightly">
      <source>Source 8</source>
      <translation variants="yes">
        <lengthvariant priority="1">Repeats fortnightly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily">
      <source>Source 9</source>
      <translation variants="yes">
        <lengthvariant priority="1">Repeats daily</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_send">
      <source>Source 10</source>
      <translation variants="no">Send</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_description">
      <source>Source 11</source>
      <translation variants="yes">
        <lengthvariant priority="1">Description:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Source 12</source>
      <translation variants="yes">
        <lengthvariant priority="1">Meeting</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_anniversary">
      <source>Source 13</source>
      <translation variants="yes">
        <lengthvariant priority="1">Anniversary</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_unnamed">
      <source>Source 14</source>
      <translation variants="yes">
        <lengthvariant priority="1">Unnamed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_end_time_date">
      <source>Source 15</source>
      <translation variants="no">- %1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Source 16</source>
      <translation variants="no">Delete meeting?</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_until_1">
      <source>Source 17</source>
      <translation variants="no">Until %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_start_end_time">
      <source>Source 18</source>
      <translation variants="no">%1 - %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Source 19</source>
      <translation variants="no">Delete anniversary?</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_delete">
      <source>Source 20</source>
      <translation variants="no">Delete</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_yearly">
      <source>Source 21</source>
      <translation variants="yes">
        <lengthvariant priority="1">Repeats Yearly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_subject">
      <source>Source 22</source>
      <translation variants="yes">
        <lengthvariant priority="1">Subject:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Source 23</source>
      <translation variants="yes">
        <lengthvariant priority="1">Delete repeated entry :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>Source 24</source>
      <translation variants="no">This occurrence only</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_edit">
      <source>Source 25</source>
      <translation variants="no">Edit</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_reminder_time">
      <source>Source 26</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_start_time_date">
      <source>Source 27</source>
      <translation variants="no">%1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_save_to_calendar">
      <source>Source 28</source>
      <translation variants="no">Save to calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_weekly">
      <source>Source 29</source>
      <translation variants="yes">
        <lengthvariant priority="1">Repeats weekly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_monthly">
      <source>Source 30</source>
      <translation variants="yes">
        <lengthvariant priority="1">Repeats monthly</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_completed_date">
      <source>Source 31</source>
      <translation variants="yes">
        <lengthvariant priority="1">Completed date:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Source 32</source>
      <translation variants="yes">
        <lengthvariant priority="1">Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Source 33</source>
      <translation variants="no">Mark as done</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Source 34</source>
      <translation variants="yes">
        <lengthvariant priority="1">Edit :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Source 35</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>Source 36</source>
      <translation variants="no">All occurences</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Source 37</source>
      <translation variants="yes">
        <lengthvariant priority="1">Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_workdays">
      <source>Source 38</source>
      <translation variants="yes">
        <lengthvariant priority="1">Repeats workdays</lengthvariant>
      </translation>
    </message>
  </context>
</TS>