<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_setlabel_time_format">
      <source>Time format</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقت کا فارمیٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_button_digital">
      <source>Digital</source>
      <translation variants="yes">
        <lengthvariant priority="1">ڈیجٹل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date">
      <source>Time &amp; date</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقت اور تاریخ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy">
      <source>mm dd yyyy</source>
      <translation variants="yes">
        <lengthvariant priority="1">مہینہ دن سال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_button_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">علاقاتی وقت اور تاریخ کی ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_format">
      <source>Date format</source>
      <translation variants="yes">
        <lengthvariant priority="1">تاریخ کا فارمیٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">علاقاتی وقت اور تاریخ کی ترتیبات</lengthvariant>
        <lengthvariant priority="2">علاقاتی وقت و تاریخ ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_place">
      <source>Place</source>
      <translation variants="yes">
        <lengthvariant priority="1">جگہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour">
      <source>24 hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">۲۴ گھنٹہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_button_analog">
      <source>Analog</source>
      <translation variants="yes">
        <lengthvariant priority="1">انالاگ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_week_starts_on">
      <source>Week starts on</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہفتہ شروع از</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd">
      <source>yyyy mm dd</source>
      <translation variants="yes">
        <lengthvariant priority="1">سال مہینہ دن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_use_network_date_time">
      <source>Use network date &amp; time</source>
      <translation variants="no">نیٹ ورک وقت اور تاریخ استعمال کریں</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time_separator">
      <source>Time separator</source>
      <translation variants="no">وقت علاحدہ کنندہ</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_separator">
      <source>Date separator</source>
      <translation variants="no">تاریخ علاحدہ کنندہ</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_workdays">
      <source>Workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">کام کے دن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date">
      <source>Date</source>
      <translation variants="no">تاریخ</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time">
      <source>Time</source>
      <translation variants="no">وقت</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour">
      <source>12 hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">۱۲ گھنٹہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_clock_type">
      <source>Clock Type</source>
      <translation variants="no">گھڑی کی قسم</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_date_time">
      <source>Date &amp; time</source>
      <translation variants="yes">
        <lengthvariant priority="1">وقت اور تاریخ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy">
      <source>dd mm yyyy</source>
      <translation variants="yes">
        <lengthvariant priority="1">دن مہینہ سال</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_alarm_snooze_time">
      <source>Alarm snooze time</source>
      <translation variants="no">الارم کے بند کرنے کا وقت</translation>
    </message>
    <message numerus="no" id="txt_clock_title_clock2">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">گھڑی</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_clock_setlabel_ln_mins">
      <source>%Ln mins</source>
      <translation>
        <numerusform plurality="a">%Ln منٹ</numerusform>
        <numerusform plurality="b">%Ln منٹ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_title_control_panel">
      <source>Control Panel</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Control panel</lengthvariant>
      </translation>
    </message>
  </context>
</TS>