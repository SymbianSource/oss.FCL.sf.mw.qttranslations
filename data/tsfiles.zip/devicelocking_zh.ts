<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_common_button_call">
      <source>Call</source>
      <translation variants="no">zh #Call</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_must_include_letters_and_nu">
      <source>Must include letters and numbers</source>
      <translation variants="no">必须包括字母和数字</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_new_lock_code">
      <source>New lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">输入新锁码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_lock_code_created">
      <source>Lock code created</source>
      <translation variants="no">锁码已创建</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_remote_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_code_must_not_contain_conse">
      <source>Code must not contain consecutive characters</source>
      <translation variants="no">锁码中不得包含连续字符</translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="no">zh #OK</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_30_minutes">
      <source>30 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">30分钟</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_characters_cannot_be_repeat">
      <source>Characters cannot be repeated</source>
      <translation variants="no">字符不能重复</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_subhead_remote_locking">
      <source>Remote locking</source>
      <translation variants="no">远程锁闭</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_lock_code">
      <source>Lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">锁码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_dialog_retype_locking_message">
      <source>Retype locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">验证新锁闭信息：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_devicelocking_info_lock_code_cannot_be_same_as">
      <source>Lock code cannot be same as previous  %Ln lock codes</source>
      <translation>
        <numerusform plurality="a">此锁码已在最后%Ln个锁码中使用过。重试。</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_remote_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_locking_message_created">
      <source>Locking message created</source>
      <translation variants="no">锁闭信息已创建</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_lock_when_sim_changed">
      <source>Lock when SIM changed</source>
      <translation variants="yes">
        <lengthvariant priority="1">SIM卡改变时锁闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_lock_code_unlock">
      <source>Not specified</source>
      <translation variants="no">锁码</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_wrong_lock_code">
      <source>Wrong lock code</source>
      <translation variants="no">锁码不正确。</translation>
    </message>
    <message numerus="no" id="txt_device_dialog_new_locking_message">
      <source>New locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">输入新锁闭信息：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_more_than_two_consecutive_n">
      <source>More than two consecutive numbers not allowed</source>
      <translation variants="no">不允许有两个以上连续数字</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_60_minutes">
      <source>60 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">60分钟</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_lock_code_can_be_changed_l">
      <source>Lock code can be changed %L1n times in %L2n hours</source>
      <translation variants="no">zh #Security code can be changed %[99]1 times in %[99]2 hours</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_automatic_locking">
      <source>Automatic locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">自动锁闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_5_minutes">
      <source>5 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">5分钟</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_lock_code_is_expired">
      <source>Lock code is expired.</source>
      <translation variants="no">锁码过期。</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_must_be_at_least_l1_charac">
      <source>Must be at least %L1 characters</source>
      <translation variants="no">锁码必须至少包含%Ln个字符</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_the_locking_message_and_the">
      <source>The locking message and the lock code should not be equal</source>
      <translation variants="no">锁闭信息和锁码应当不同</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_subhead_device_locking">
      <source>Device Locking</source>
      <translation variants="no">设备锁闭</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_code_must_contain_at_least">
      <source>Code must contain at least %L1 special characters</source>
      <translation variants="no">锁码必须至少包含%Ln个特殊字符</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_code_must_not_contain_singl">
      <source>Code must not contain single repeated character</source>
      <translation variants="no">单个字符不能在一行中重复多次</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_create_lock_code">
      <source>Create lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">创建锁码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_cannot_contain_more_than_l">
      <source>Cannot contain more than %L1 characters</source>
      <translation variants="no">锁码不能包含%Ln个以上字符</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_lock_code">
      <source>Lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">输入当前锁码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_messages_do_not_match">
      <source>Messages do not match</source>
      <translation variants="no">信息不一致</translation>
    </message>
    <message numerus="no" id="txt_remotelocking_button_sim_changed_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_button_sim_changed_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">仅紧急呼叫</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpopinfo_try_again">
      <source>Try again</source>
      <translation variants="no">重试。</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_the_security_code_must_be_a">
      <source>The security code must be alphanumeric</source>
      <translation variants="no">锁码必须为字母数字</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_lock_code_is_blocked">
      <source>Lock code is blocked</source>
      <translation variants="no">锁码被阻止。</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_lock_code_can_be_used_for_p">
      <source>Lock code can be used for protecting the device from unauthorized use</source>
      <translation variants="no">可以使用锁码来防止他人未经许可使用您的设备</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_remote_locking">
      <source>Remote locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">远程锁闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_information_included_in_the">
      <source>Information included in the lock code is not allowed</source>
      <translation variants="no">zh #New code contains characters that are not permitted</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_locking_message">
      <source>Locking message</source>
      <translation variants="yes">
        <lengthvariant priority="1">锁闭信息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dialog_retype_new_lock_code">
      <source>Retype new lock code</source>
      <translation variants="yes">
        <lengthvariant priority="1">验证新锁码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_characters_cannot_be_rep_no">
      <source>Characters cannot be repeated more than %L1 times</source>
      <translation variants="no">zh #Characters cannot be repeated more than %Ln time</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_setlabel_val_when_keys_screen">
      <source>When keys &amp; screen locked</source>
      <translation variants="yes">
        <lengthvariant priority="1">当键和屏幕锁闭时</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="no">zh #Cancel</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_device_lock">
      <source>Device lock</source>
      <translation variants="yes">
        <lengthvariant priority="1">设备锁</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_dpophead_codes_do_not_match">
      <source>Codes do not match</source>
      <translation variants="no">密码不一致</translation>
    </message>
    <message numerus="yes" id="txt_devicelocking_dpopinfo_wait_ln_minutes">
      <source>Wait %Ln minutes</source>
      <translation>
        <numerusform plurality="a">等待%Ln分钟。</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_formlabel_device_locking">
      <source>Device locking</source>
      <translation variants="yes">
        <lengthvariant priority="1">设备锁闭</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_must_include_upper_and_lowe">
      <source>Must include upper and lower case characters</source>
      <translation variants="no">必须包括大小写字符</translation>
    </message>
    <message numerus="no" id="txt_devicelocking_info_incorrect_lock_code_one_at">
      <source>Incorrect lock code. One attempt left before data is erased.</source>
      <translation variants="no">锁码错误。只剩一次尝试机会，之后数据将被删除。</translation>
    </message>
  </context>
</TS>