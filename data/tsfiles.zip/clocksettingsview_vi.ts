<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_setlabel_time_format">
      <source>Time format</source>
      <translation variants="yes">
        <lengthvariant priority="1">Định dạng thời gian</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date">
      <source>Time &amp; date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày giờ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_format">
      <source>Date format</source>
      <translation variants="yes">
        <lengthvariant priority="1">Định dạng ngày</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt ngày giờ theo vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_place">
      <source>Place</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa điểm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_week_starts_on">
      <source>Week starts on</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tuần bắt đầu vào</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_use_network_date_time">
      <source>Use network date &amp; time</source>
      <translation variants="no">Sử dụng ngày và giờ mạng</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time_separator">
      <source>Time separator</source>
      <translation variants="no">Dấu phân cách thời gian</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_separator">
      <source>Date separator</source>
      <translation variants="no">Dấu phân cách ngày</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_workdays">
      <source>Workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày làm việc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date">
      <source>Date</source>
      <translation variants="no">Ngày</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time">
      <source>Time</source>
      <translation variants="no">Thời gian</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_clock_type">
      <source>Clock Type</source>
      <translation variants="no">Dạng đồng hồ</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_date_time">
      <source>Date &amp; time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày giờ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_title_clock2">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đồng hồ</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_clock_setlabel_ln_mins">
      <source>%Ln mins</source>
      <translation>
        <numerusform plurality="a">%Ln phút</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_alarm_snooze_time">
      <source>Alarm snooze time</source>
      <translation variants="no">Thời gian báo thức lại</translation>
    </message>
    <message numerus="no" id="txt_clock_button_digital">
      <source>Digital</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đồng hồ số</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_button_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt ngày giờ theo vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour">
      <source>12 hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">12 giờ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour">
      <source>24 hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">24 giờ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_button_analog">
      <source>Analog</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đồng hồ kim</lengthvariant>
      </translation>
    </message>
  </context>
</TS>