<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="yes" id="txt_clock_list_ln_minutes">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">%Ln phút</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_button_analog">
      <source>Analog</source>
      <translation variants="no">Đồng hồ kim</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">Thứ Tư</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_week_starts_on">
      <source>Week starts on</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tuần bắt đầu vào</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd">
      <source>yyyy mm dd</source>
      <translation variants="no">nnnn tt nn</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time">
      <source>Time</source>
      <translation variants="no">Thời gian</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_clock_type">
      <source>Clock Type</source>
      <translation variants="no">Dạng đồng hồ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour">
      <source>24 hour</source>
      <translation variants="no">24 giờ</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_sunday">
      <source>Sunday</source>
      <translation variants="no">Chủ Nhật</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date">
      <source>Date</source>
      <translation variants="no">Ngày</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_date_time">
      <source>Date &amp; time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày giờ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_info_date_info">
      <source>%1, %2</source>
      <translation variants="no">%[25]1, %2</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_monday">
      <source>Monday</source>
      <translation variants="no">Thứ Hai</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date">
      <source>Time &amp; date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày giờ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy">
      <source>mm dd yyyy</source>
      <translation variants="no">tt nn nnnn</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_separator">
      <source>Date separator</source>
      <translation variants="no">Dấu phân cách ngày</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_workdays">
      <source>Workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày làm việc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_friday">
      <source>Friday</source>
      <translation variants="no">Thứ Sáu</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy">
      <source>dd mm yyyy</source>
      <translation variants="no">nn tt nnnn</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_place">
      <source>Place</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa điểm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_thursday">
      <source>Thursday</source>
      <translation variants="no">Thứ Năm</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_saturday">
      <source>Saturday</source>
      <translation variants="no">Thứ Bảy</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time_format">
      <source>Time format</source>
      <translation variants="yes">
        <lengthvariant priority="1">Định dạng thời gian</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt ngày giờ theo vùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">Thứ Ba</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour">
      <source>12 hour</source>
      <translation variants="no">12 giờ</translation>
    </message>
    <message numerus="no" id="txt_clock_button_digital">
      <source>Digital</source>
      <translation variants="no">Đồng hồ số</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_format">
      <source>Date format</source>
      <translation variants="yes">
        <lengthvariant priority="1">Định dạng ngày</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_use_network_date_time">
      <source>Use network date &amp; time</source>
      <translation variants="no">Sử dụng ngày và giờ mạng</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time_separator">
      <source>Time separator</source>
      <translation variants="no">Dấu phân cách thời gian</translation>
    </message>
    <message numerus="no" id="txt_clock_button_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="no">Cài đặt ngày giờ theo vùng</translation>
    </message>
  </context>
</TS>