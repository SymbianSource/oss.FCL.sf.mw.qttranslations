<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_4">
      <source>#4</source>
      <translation variants="no">۴#</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wep">
      <source>WEP</source>
      <translation variants="no">WEP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2_val_eap">
      <source>EAP</source>
      <translation variants="no">EAP</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_authentication">
      <source>WAPI authentication</source>
      <translation variants="no">WAPI تصدیق کاری</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2_val_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">یش اشتراک شدہ کوڈ</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_root_certificate">
      <source>WAPI root certificate</source>
      <translation variants="no">WAPI اصل سند</translation>
    </message>
    <message numerus="no" id="txt_occ_ascii">
      <source>ASCII</source>
      <translation variants="no">ASCII</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpa2_only">
      <source>WPA2 only</source>
      <translation variants="no">صرف WPA۲</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_use">
      <source>WEP key in use</source>
      <translation variants="no">WEP کوڈ زیر استعمال</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_root_cert_not_defined">
      <source>(not defined)</source>
      <translation variants="no">وضاحت شدہ نہیں</translation>
    </message>
    <message numerus="no" id="txt_occ_certificate">
      <source>Certificate</source>
      <translation variants="no">سند</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wapi">
      <source>WAPI</source>
      <translation variants="no">WAPI</translation>
    </message>
    <message numerus="no" id="txt_occ_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">پیش اشتراک شدہ کوڈ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_8021x">
      <source>802.1X</source>
      <translation variants="no">۸۰۲٫۱X</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_preshared_key_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">وضاحت شدہ نہیں</translation>
    </message>
    <message numerus="no" id="txt_occ_preshared_key_format">
      <source>Pre-shared key format</source>
      <translation variants="no">پیش اش. شدہ کوڈ فارمیٹ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_type">
      <source>EAP type</source>
      <translation variants="no">EAP قسم</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unencrypted_connection">
      <source>Unencrypted connection</source>
      <translation variants="no">غیر رمز شدہ اتصال</translation>
    </message>
    <message numerus="no" id="txt_occ_button_eap_type_settings">
      <source>EAP type settings</source>
      <translation variants="no">EAP قسم کی ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unencrypted_connection_val_allowe">
      <source>Allowed</source>
      <translation variants="no">اجازت ہے</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_3">
      <source>#3</source>
      <translation variants="no">۳#</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_2">
      <source>#2</source>
      <translation variants="no">۲#</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_1">
      <source>#1</source>
      <translation variants="no">۱#</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpawpa2">
      <source>WPA/WPA2</source>
      <translation variants="no">WPA/WPA۲</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_client_certificate">
      <source>WAPI client certificate</source>
      <translation variants="no">WAPI گاہک سند</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_client_cert_not_defined">
      <source>(not defined)</source>
      <translation variants="no">وضاحت شدہ نہیں</translation>
    </message>
    <message numerus="no" id="txt_occ_button_remove_certificate_store">
      <source>Remove certificate store</source>
      <translation variants="no">سند اسٹور ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_4">
      <source>WEP key #4</source>
      <translation variants="no">WEP کوڈ ۴#:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_3">
      <source>WEP key #3</source>
      <translation variants="no">WEP کوڈ ۳#:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_1">
      <source>WEP key #1</source>
      <translation variants="no">WEP کوڈ ۱#:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_2">
      <source>WEP key #2</source>
      <translation variants="no">WEP کوڈ ۲#:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2">
      <source>Authentication mode</source>
      <translation variants="no">تصدیق کاری وضع</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">پیش اشتراک شدہ کوڈ:</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_security_settings">
      <source>Security settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">حفاظتی ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_hexadecimal">
      <source>Hexadecimal</source>
      <translation variants="no">ششدہی نظام</translation>
    </message>
  </context>
</TS>