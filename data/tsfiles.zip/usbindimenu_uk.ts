<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dpinfo_click_to_eject">
      <source>Click to eject</source>
      <translation variants="no">Від’єднати пристрій USB</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem_val_not_enough_memory">
      <source>Not enough memory</source>
      <translation variants="no">Недостатньо пам’яті</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_media_transfer">
      <source>as media transfer</source>
      <translation variants="no">Режим передачі мультимедіа</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected">
      <source>USB connected</source>
      <translation variants="no">USB з’єднано</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem">
      <source>USB problem</source>
      <translation variants="no">Помилка з’єднання USB</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem_val_connection_type_not">
      <source>Connection type not supported</source>
      <translation variants="no">Тип з’єднання не підтримується</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_phone_as_modem">
      <source>as web connection</source>
      <translation variants="no">З’єднання комп’ютера з Інтернетом</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_ovi_suite">
      <source>to OVI suite</source>
      <translation variants="no">Nokia Ovi Suite</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_mass_storage">
      <source>as mass storage</source>
      <translation variants="no">Режим накопичувача</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connecting">
      <source>USB connecting</source>
      <translation variants="no">Триває встановлення з’єднання USB</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_disconnecting">
      <source>USB disconnecting</source>
      <translation variants="no">Триває закриття з’єднання USB</translation>
    </message>
  </context>
</TS>