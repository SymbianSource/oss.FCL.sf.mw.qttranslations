<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_region_CA">
      <source>Canada</source>
      <translation variants="no">zh_tw #Canada</translation>
    </message>
    <message numerus="no" id="txt_region_VN">
      <source>Việt Nam</source>
      <translation variants="no">zh_tw #Việt Nam</translation>
    </message>
    <message numerus="no" id="txt_region_IS">
      <source>Ísland</source>
      <translation variants="no">zh_tw #Ísland</translation>
    </message>
    <message numerus="no" id="txt_region_RU">
      <source>Россия</source>
      <translation variants="no">zh_tw #Россия</translation>
    </message>
    <message numerus="no" id="txt_region_BG">
      <source>България</source>
      <translation variants="no">zh_tw #България</translation>
    </message>
    <message numerus="no" id="txt_region_IR">
      <source>ایران</source>
      <translation variants="no">zh_tw #ایران</translation>
    </message>
    <message numerus="no" id="txt_region_PK">
      <source>Pakistan</source>
      <translation variants="no">zh_tw #Pakistan</translation>
    </message>
    <message numerus="no" id="txt_region_FI">
      <source>Suomi</source>
      <translation variants="no">zh_tw #Suomi</translation>
    </message>
    <message numerus="no" id="txt_region_SK">
      <source>Slovensko</source>
      <translation variants="no">zh_tw #Slovensko</translation>
    </message>
    <message numerus="no" id="txt_region_BR">
      <source>Brasil</source>
      <translation variants="no">zh_tw #Brasil</translation>
    </message>
    <message numerus="no" id="txt_region_RS">
      <source>Srbija</source>
      <translation variants="no">zh_tw #Srbija</translation>
    </message>
    <message numerus="no" id="txt_region_NL">
      <source>Nederland</source>
      <translation variants="no">zh_tw #Nederland</translation>
    </message>
    <message numerus="no" id="txt_region_PT">
      <source>Portugal</source>
      <translation variants="no">zh_tw #Portugal</translation>
    </message>
    <message numerus="no" id="txt_region_JP">
      <source>日本</source>
      <translation variants="no">zh_tw #日本</translation>
    </message>
    <message numerus="no" id="txt_region_IN">
      <source>भारत</source>
      <translation variants="no">zh_tw #भारत</translation>
    </message>
    <message numerus="no" id="txt_region_US">
      <source>United States</source>
      <translation variants="no">zh_tw #United States</translation>
    </message>
    <message numerus="no" id="txt_region_RO">
      <source>România</source>
      <translation variants="no">zh_tw #România</translation>
    </message>
    <message numerus="no" id="txt_region_CZ">
      <source>Český</source>
      <translation variants="no">zh_tw #Český</translation>
    </message>
    <message numerus="no" id="txt_region_TR">
      <source>Türkiye</source>
      <translation variants="no">zh_tw #Türkiye</translation>
    </message>
    <message numerus="no" id="txt_region_HU">
      <source>Magyarország</source>
      <translation variants="no">zh_tw #Magyarország</translation>
    </message>
    <message numerus="no" id="txt_region_HR">
      <source>Hrvatska</source>
      <translation variants="no">zh_tw #Hrvatska</translation>
    </message>
    <message numerus="no" id="txt_region_EE">
      <source>Eesti</source>
      <translation variants="no">zh_tw #Eesti</translation>
    </message>
    <message numerus="no" id="txt_region_PH">
      <source>Pilipinas</source>
      <translation variants="no">zh_tw #Pilipinas</translation>
    </message>
    <message numerus="no" id="txt_region_ID">
      <source>Indonesia</source>
      <translation variants="no">zh_tw #Indonesia</translation>
    </message>
    <message numerus="no" id="txt_region_FR">
      <source>France</source>
      <translation variants="no">zh_tw #France</translation>
    </message>
    <message numerus="no" id="txt_region_TH">
      <source>ประเทศไทย</source>
      <translation variants="no">zh_tw #ประเทศไทย</translation>
    </message>
    <message numerus="no" id="txt_region_IL">
      <source>ישראל</source>
      <translation variants="no">zh_tw #ישראל</translation>
    </message>
    <message numerus="no" id="txt_region_DE">
      <source>Deutschland</source>
      <translation variants="no">zh_tw #Deutschland</translation>
    </message>
    <message numerus="no" id="txt_region_DK">
      <source>Danmark</source>
      <translation variants="no">zh_tw #Danmark</translation>
    </message>
    <message numerus="no" id="txt_region_SI">
      <source>Slovenija</source>
      <translation variants="no">zh_tw #Slovenija</translation>
    </message>
    <message numerus="no" id="txt_region_HK">
      <source>香港</source>
      <translation variants="no">zh_tw #香港</translation>
    </message>
    <message numerus="no" id="txt_region_LT">
      <source>Lietuva</source>
      <translation variants="no">zh_tw #Lietuva</translation>
    </message>
    <message numerus="no" id="txt_region_IT">
      <source>Italia</source>
      <translation variants="no">zh_tw #Italia</translation>
    </message>
    <message numerus="no" id="txt_region_KR">
      <source>한국</source>
      <translation variants="no">zh_tw #한국</translation>
    </message>
    <message numerus="no" id="txt_region_ES">
      <source>España</source>
      <translation variants="no">zh_tw #España</translation>
    </message>
    <message numerus="no" id="txt_region_SE">
      <source>Sverige</source>
      <translation variants="no">zh_tw #Sverige</translation>
    </message>
    <message numerus="no" id="txt_region_TW">
      <source>台灣</source>
      <translation variants="no">zh_tw #台灣</translation>
    </message>
    <message numerus="no" id="txt_region_CN">
      <source>中国</source>
      <translation variants="no">zh_tw #中国</translation>
    </message>
    <message numerus="no" id="txt_region_LV">
      <source>Latvija</source>
      <translation variants="no">zh_tw #Latvija</translation>
    </message>
    <message numerus="no" id="txt_region_MY">
      <source>Malaysia</source>
      <translation variants="no">zh_tw #Malaysia</translation>
    </message>
    <message numerus="no" id="txt_region_GB">
      <source>United Kingdom</source>
      <translation variants="no">zh_tw #United Kingdom</translation>
    </message>
    <message numerus="no" id="txt_region_AE">
      <source>الإمارات العربية المتحدة</source>
      <translation variants="no">zh_tw #الإمارات العربية المتحدة</translation>
    </message>
    <message numerus="no" id="txt_region_UA">
      <source>Україна</source>
      <translation variants="no">zh_tw #Україна</translation>
    </message>
    <message numerus="no" id="txt_region_PL">
      <source>Polska</source>
      <translation variants="no">zh_tw #Polska</translation>
    </message>
    <message numerus="no" id="txt_region_GR">
      <source>Ελλάδα</source>
      <translation variants="no">zh_tw #Ελλάδα</translation>
    </message>
    <message numerus="no" id="txt_region_NO">
      <source>Norge</source>
      <translation variants="no">zh_tw #Norge</translation>
    </message>
  </context>
</TS>