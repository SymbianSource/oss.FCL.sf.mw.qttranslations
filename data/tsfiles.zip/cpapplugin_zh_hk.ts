<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_homepage_val_none">
      <source>None</source>
      <translation variants="no">未定義</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_port_number">
      <source>Proxy port number</source>
      <translation variants="no">Proxy端口號碼</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode">
      <source>WLAN security mode</source>
      <translation variants="no">WLAN安全模式</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_adhoc_channel">
      <source>Ad-hoc channel</source>
      <translation variants="no">臨機操作頻道</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status_val_public">
      <source>Public</source>
      <translation variants="no">公開</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode_val_infrastruct">
      <source>Infrastructure</source>
      <translation variants="no">基礎結構</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name">
      <source>Connection name</source>
      <translation variants="no">連接名稱</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_default_gateway_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">未定義</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自動</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_default_gateway">
      <source>Default gateway</source>
      <translation variants="no">預設閘道</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_open">
      <source>Open</source>
      <translation variants="no">開啟</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode">
      <source>WLAN network mode</source>
      <translation variants="no">WLAN模式</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_access_point_settings">
      <source>Access point settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">接入點設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自動</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_server_address_val_not_def">
      <source>(not defined)</source>
      <translation variants="no">未定義</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_wellknown">
      <source>Well-known</source>
      <translation variants="no">已知伺服器</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode_val_adhoc">
      <source>Ad-hoc</source>
      <translation variants="no">臨機操作</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_phone_ip_address">
      <source>Phone IP address</source>
      <translation variants="no">裝置IP位址</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_proxy_settings">
      <source>Proxy settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">代理設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_server_address">
      <source>Proxy server address</source>
      <translation variants="no">Proxy伺服器位址</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_primary_name_server">
      <source>Primary name server</source>
      <translation variants="no">主網域DNS位址</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_subnet_mask_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">未定義</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status_val_hidden">
      <source>Hidden</source>
      <translation variants="no">隱藏</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_secondary_name_server">
      <source>Secondary name server</source>
      <translation variants="no">次網域DNS位址</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_port_number_val_not_define">
      <source>(not defined)</source>
      <translation variants="no">未定義</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_adhoc_channel_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自動</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_user_defined">
      <source>User defined</source>
      <translation variants="no">用戶自定義</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_none">
      <source>None</source>
      <translation variants="no">未定義</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password_val_none">
      <source>None</source>
      <translation variants="no">未定義</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ipv4_settings">
      <source>IPv4 settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">IPv4設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name">
      <source>User name</source>
      <translation variants="no">用戶名稱：</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">進階設定</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password">
      <source>Password</source>
      <translation variants="no">密碼：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_subnet_mask">
      <source>Subnet mask</source>
      <translation variants="no">子網路遮罩</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status">
      <source>Network status</source>
      <translation variants="no">網絡狀態</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses">
      <source>DNS addresses</source>
      <translation variants="no">DNS位址</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_homepage">
      <source>Homepage</source>
      <translation variants="no">主頁</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_name">
      <source>WLAN network name</source>
      <translation variants="no">WLAN名稱</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_type_val_ipv4">
      <source>IPv4</source>
      <translation variants="no">IPv4</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication_val_secure">
      <source>Secure</source>
      <translation variants="no">安全</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_type_val_ipv6">
      <source>IPv6</source>
      <translation variants="no">IPv6</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication">
      <source>Authentication</source>
      <translation variants="no">認證</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication_val_normal">
      <source>Normal</source>
      <translation variants="no">一般</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_access_point_name">
      <source>Access point name</source>
      <translation variants="no">接入點名稱：</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ipv6_settings">
      <source>IPv6 settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">IPv6設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ip_settings">
      <source>IP settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">IP設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_type">
      <source>Network type</source>
      <translation variants="no">網絡類型</translation>
    </message>
  </context>
</TS>