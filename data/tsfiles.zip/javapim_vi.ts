<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_pimtodo_formlabel_synchronization">
      <source>Synchronisation</source>
      <translation variants="no">Đồng bộ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_pobox">
      <source>P.O. Box</source>
      <translation variants="no">Hộp thư Bưu điện</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">Sửa đổi mới nhất</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_borthday">
      <source>Birthday</source>
      <translation variants="no">Sinh nhật</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">Chức vụ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_default">
      <source>Default</source>
      <translation variants="no">Mặc định</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_date">
      <source>Date</source>
      <translation variants="no">Ngày</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">Chủ đề</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_uid">
      <source>UID</source>
      <translation variants="no">UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_company">
      <source>Company</source>
      <translation variants="no">Công ty</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">Họ</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_location">
      <source>Location</source>
      <translation variants="no">Vị trí</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">Âm báo</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">Sửa đổi mới nhất</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_assistant_name">
      <source>Assistant's name</source>
      <translation variants="no">Tên của người trợ lý</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_picture">
      <source>Picture</source>
      <translation variants="no">Hình ảnh</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_video_number">
      <source>Video number</source>
      <translation variants="no">Điện thoại video</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_completed">
      <source>Completed</source>
      <translation variants="no">Đã hoàn tất</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_push_to_talk">
      <source>Push to talk</source>
      <translation variants="no">Bộ đàm</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">Tên</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_car_phone">
      <source>Car phone</source>
      <translation variants="no">Điện thoại trên xe</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_department">
      <source>Department</source>
      <translation variants="no">Bộ phận</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_first_name_reading">
      <source>First name reading</source>
      <translation variants="no">vi ##First name reading</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">Ngày kỷ niệm</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_last_name_reading">
      <source>Last name reading</source>
      <translation variants="no">vi ##Last name reading</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_pager">
      <source>Pager</source>
      <translation variants="no">Nhắn tin</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_priority">
      <source>Priority</source>
      <translation variants="no">Ưu tiên</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_synchronization">
      <source>Synchronisation</source>
      <translation variants="no">Đồng bộ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_title_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Danh bạ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_home">
      <source>Home</source>
      <translation variants="no">vi ##Home</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_telephone">
      <source>Telephone</source>
      <translation variants="no">Điện thoại</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">Phần mở rộng</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">Ngày hết hạn</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_mobile">
      <source>Mobile</source>
      <translation variants="no">Di động</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_wv_user_id">
      <source>WV User ID</source>
      <translation variants="no">ID người dùng WV</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_postalcode">
      <source>Postal code</source>
      <translation variants="no">Mã bưu điện/Zip</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_end_date">
      <source>End date</source>
      <translation variants="no">Ngày kết thúc</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_business">
      <source>Business</source>
      <translation variants="no">vi ##Business</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_end_time_and_date">
      <source>End time and date</source>
      <translation variants="no">Ngày giờ kết thúc</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_dtmf">
      <source>DTMF</source>
      <translation variants="no">DTMF</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_state">
      <source>State</source>
      <translation variants="no">Vợ/chồng</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_fax">
      <source>Fax</source>
      <translation variants="no">Fax</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_email">
      <source>E-Mail</source>
      <translation variants="no">Địa chỉ e-mail</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">Tiêu đề</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_share_view">
      <source>Share view</source>
      <translation variants="no">Chia sẻ video</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_appointments">
      <source>Appointments</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc họp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_occasion">
      <source>Occasion</source>
      <translation variants="no">Dịp</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_nickname">
      <source>Nickname</source>
      <translation variants="no">Bí danh</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">Nhạc chuông</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_formatted_name">
      <source>Name</source>
      <translation variants="no">Tên</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_start_time_and_date">
      <source>Start time and date</source>
      <translation variants="no">Ngày giờ bắt đầu</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_suffix">
      <source>Suffix</source>
      <translation variants="no">Chức vị</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_street">
      <source>Street</source>
      <translation variants="no">Đường</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_tel_internet">
      <source>Tel. Internet</source>
      <translation variants="no">Điện thoại internet</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_momos">
      <source>Memos</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Reminders</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_name">
      <source>Name</source>
      <translation variants="no">Tên</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">Vợ/chồng</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_anniversaries">
      <source>Anniversaries</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày kỷ niệm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_address">
      <source>Address</source>
      <translation variants="no">Địa chỉ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_other">
      <source>Other</source>
      <translation variants="no">Khác</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_title_to_do_notes">
      <source>To-do notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú công việc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_uid">
      <source>UID</source>
      <translation variants="no">UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_city">
      <source>City</source>
      <translation variants="no">Thành phố</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_description">
      <source>Description</source>
      <translation variants="no">Mô tả</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_assistant_phone">
      <source>Assistant's phone</source>
      <translation variants="no">Số của người trợ lý</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_url">
      <source>URL address</source>
      <translation variants="no">Địa chỉ web</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_note">
      <source>Note</source>
      <translation variants="no">Ghi chú</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_sms">
      <source>SMS</source>
      <translation variants="no">Tin nhắn văn bản</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_synchronisation">
      <source>Synchronisation</source>
      <translation variants="no">Đồng bộ</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_uid">
      <source>UID</source>
      <translation variants="no">UID</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_children">
      <source>Children</source>
      <translation variants="no">Con</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">Tên lót</translation>
    </message>
    <message numerus="no" id="txt_java_pimtodo_formlabel_completion_date">
      <source>Completion date</source>
      <translation variants="no">Ngày hoàn tất</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_description">
      <source>Description</source>
      <translation variants="no">Mô tả</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_subject">
      <source>Subject</source>
      <translation variants="no">Chủ đề</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_title_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_revision">
      <source>Revision</source>
      <translation variants="no">Sửa đổi mới nhất</translation>
    </message>
    <message numerus="no" id="txt_java_pimevent_formlabel_start_date">
      <source>Start date</source>
      <translation variants="no">Ngày bắt đầu</translation>
    </message>
    <message numerus="no" id="txt_java_pimcm_formlabel_country">
      <source>Country</source>
      <translation variants="no">Quốc gia/Vùng</translation>
    </message>
  </context>
</TS>