<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_fmgr_opt_backup">
      <source>Backup</source>
      <translation variants="no">Sao lưu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_change_password">
      <source>Change password</source>
      <translation variants="no">Đổi mật khẩu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_format">
      <source>Format</source>
      <translation variants="no">Định dạng</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_file_details">
      <source>File details:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết tập tin:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_folder_details">
      <source>Folder details:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết thư mục:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_set_password">
      <source>Set password</source>
      <translation variants="no">Đặt mật khẩu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_name">
      <source>Name</source>
      <translation variants="no">Tên</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_type_file">
      <source>Type:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Loại:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="no">Thẻ nhớ %1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_file_manager">
      <source>File Manager</source>
      <translation variants="yes">
        <lengthvariant priority="1">Quản lý tập tin</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_fmgr_dblist_val_size_l1_gb">
      <source>%Ln GB</source>
      <translation>
        <numerusform plurality="a">Kích cỡ: %L1 GB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_view_details_memory">
      <source>View details</source>
      <translation variants="no">Chi tiết</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="no">Thẻ nhớ %1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="no">Ổ đĩa chung %1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_files">
      <source>Files:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tập tin:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_find">
      <source>Find</source>
      <translation variants="no">Tìm</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_eject">
      <source>Eject</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_free_memory">
      <source>Free:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trống:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_remove_password">
      <source>Remove password</source>
      <translation variants="no">Xóa mật khẩu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_usb_memory">
      <source>%1 USB memory</source>
      <translation variants="no">Ổ đĩa chung %1</translation>
    </message>
    <message numerus="yes" id="txt_fmgr_dblist_val_size_l1_mb">
      <source>%Ln MB</source>
      <translation>
        <numerusform plurality="a">Kích cỡ: %L1 MB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_memory_name">
      <source>Memory name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="no">Ổ đĩa chung %1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_subfolders">
      <source>Subfolders:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thư mục con:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="no">Bộ nhớ máy %1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="no">Bộ nhớ máy %1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dialog_entry_new_folder">
      <source>New folder</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thư mục mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_backup_created_1">
      <source>Backup created %1</source>
      <translation variants="no">Đã tạo sao lưu %1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_completed">
      <source>Backup completed</source>
      <translation variants="no">Đã hoàn tất sao lưu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_scheduling">
      <source>Backup scheduling</source>
      <translation variants="no">Lập lịch sao lưu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_creating_backup">
      <source>Creating backup</source>
      <translation variants="no">Đang sao lưu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpopinfo_saved_to_1_mass_storage">
      <source>Saved to %1 Mass storage</source>
      <translation variants="no">Đã lưu vào Ổ đĩa chung %[22]1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_contacts">
      <source>Contacts</source>
      <translation variants="no">Số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_file_manager_info_this_device_does_not_support">
      <source>This device does not support locked memory cards</source>
      <translation variants="no">Thẻ nhớ đã khóa không được hỗ trợ</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_date">
      <source>Date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_val_total_size">
      <source>Size: %1</source>
      <translation variants="no">Kích cỡ: %1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_info_backup_unavailable">
      <source>Unable to perform backup. %1 not available</source>
      <translation variants="no">Không thể thực hiện sao lưu. %[99]1 không có sẵn.</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_scheduling_val_daily">
      <source>Daily</source>
      <translation variants="no">Hàng ngày</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpopinfo_try_again">
      <source>Try again</source>
      <translation variants="no">Thử lại.</translation>
    </message>
    <message numerus="no" id="txt_fmgr_info_backup_locked">
      <source>Unable to perform backup. %1 locked</source>
      <translation variants="no">Không thể thực hiện sao lưu. %[99]1 bị khóa.</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_sort_by_time">
      <source>Sort by time</source>
      <translation variants="no">Sắp xếp theo thời gian</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_delete_backup">
      <source>Delete backup</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa sao lưu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpopinfo_saved_to_1_memory_card">
      <source>Saved to %1 Memory card</source>
      <translation variants="no">Đã lưu vào Thẻ nhớ %[25]1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_info_folder_exsit">
      <source>This folder already contains a folder named 1%.Would you like to save this file as 2%？</source>
      <translation variants="no">'%[99]1' đã tồn tại. Lưu dạng '%[99]2'?</translation>
    </message>
    <message numerus="no" id="txt_fmgr_subhead_copy_to">
      <source>Copy to</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sao chép vào:</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_fmgr_info_l1_kb">
      <source>%Ln kB</source>
      <translation>
        <numerusform plurality="a">vi #%Ln kB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_button_restore">
      <source>Restore</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khôi phục</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_subhead_save_to">
      <source>Save to</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lưu vào:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_search_from">
      <source>Search from</source>
      <translation variants="no">Tìm kiếm từ:</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="no">Ổ đĩa chung %[99]1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpophead_passwords_do_not_match">
      <source>Passwords do not match</source>
      <translation variants="no">Mật khẩu ko khớp.</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_bookmarks">
      <source>Bookmarks</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bookmark</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpopinfo_saved_to_1_2">
      <source>Saved to %1 %2</source>
      <translation variants="no">Đã lưu vào %2 %[16]1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_new_folder">
      <source>New folder</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thư mục mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_button_start_bakcup">
      <source>Start bakcup</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bắt đầu sao lưu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_info_backup_corrupted">
      <source>Unable to perform backup. %1 corrupted</source>
      <translation variants="no">Không thể thực hiện sao lưu. %[99]1 bị lỗi.</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_backup">
      <source>Backup</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sao lưu</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_new_folder">
      <source>New folder</source>
      <translation variants="no">Thư mục mới</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_time">
      <source>Time:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giờ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpophead_wrong_password">
      <source>Wrong password</source>
      <translation variants="no">Mật khẩu sai.</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_messages">
      <source>Messages</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tin nhắn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_sort_by_name">
      <source>Sort by name</source>
      <translation variants="no">Sắp xếp theo tên</translation>
    </message>
    <message numerus="yes" id="txt_fmgr_info_l1_mb">
      <source>%Ln MB</source>
      <translation>
        <numerusform plurality="a">vi #%Ln MB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_file_manager">
      <source>File Manager</source>
      <translation variants="no">vi #File manager</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_no_previous_backups_created">
      <source>No previous backups created</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có sẵn sao lưu trước đó</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_delete_backup">
      <source>Delete backup</source>
      <translation variants="no">Xóa sao lưu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_weekday">
      <source>Weekday</source>
      <translation variants="no">Ngày trong tuần</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_destination">
      <source>Backup destination</source>
      <translation variants="no">Đích sao lưu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_button_paste">
      <source>Paste</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dán</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_settings">
      <source>Settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_scheduling_val_not_schedu">
      <source>Not scheduled</source>
      <translation variants="no">Chưa lập lịch</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_sort_by_size">
      <source>Sort by size</source>
      <translation variants="no">Sắp xếp theo kích cỡ</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="no">Thẻ nhớ %[99]1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_info_file_exsit">
      <source>This folder already contains a file named 1%.Would you like to save this file as 2%？</source>
      <translation variants="no">'%[99]1' đã tồn tại. Lưu dạng '%[99]2'?</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_messages">
      <source>Messages</source>
      <translation variants="no">Tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_destination_val_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[12]1 %2</translation>
    </message>
    <message numerus="no" id="txt_file_info_other_functions_are_unavailable_duri">
      <source>Other functions are unavailable during the backup</source>
      <translation variants="no">Đang khôi phục dữ liệu. Các ứng dụng khác không có sẵn.</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_preparing_for_backup">
      <source>Preparing for backup</source>
      <translation variants="no">Đang chuẩn bị sao lưu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_reenter_memory_card_password">
      <source>Re-enter new memory card password</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xác minh mật khẩu thẻ nhớ mới:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_file_manager">
      <source>File Manager</source>
      <translation variants="no">Quản lý tập tin</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_restore_data">
      <source>Restore data</source>
      <translation variants="no">Khôi phục dữ liệu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">Bookmark</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_scheduling_val_weekly">
      <source>Weekly</source>
      <translation variants="no">Hàng tuần</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_enter_new_memory_card_password">
      <source>Enter new memory card password</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhập mật khẩu thẻ nhớ mới:</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_fmgr_info_l1_gb">
      <source>%Ln GB</source>
      <translation>
        <numerusform plurality="a">vi #%Ln GB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_calendar">
      <source>Calendar</source>
      <translation variants="no">Lịch</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_user_files">
      <source>User files</source>
      <translation variants="no">Tập tin người dùng</translation>
    </message>
    <message numerus="yes" id="txt_fmgr_dblist_val_size_l1_kb">
      <source>%Ln kB</source>
      <translation>
        <numerusform plurality="a">vi #%Ln kB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_delete_backups">
      <source>Delete backups</source>
      <translation variants="no">vi #Delete backup</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_val_free_size">
      <source>Free: %2</source>
      <translation variants="no">Trống: %2</translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_start_bakcup">
      <source>Start bakcup</source>
      <translation variants="no">Bắt đầu sao lưu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents">
      <source>Backup contents</source>
      <translation variants="no">Nội dung sao lưu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_scheduling_val_never">
      <source>Never</source>
      <translation variants="no">Không bao giờ</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_sort_by_type">
      <source>Sort by type</source>
      <translation variants="no">Sắp xếp theo loại</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_size">
      <source>Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích cỡ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">Lịch</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_name">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_user_files">
      <source>User files</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tập tin người dùng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_destination_val_1_memory">
      <source>%1 Memory card</source>
      <translation variants="no">Thẻ nhớ %[16]1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="no">Bộ nhớ thiết bị %[99]1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_rename">
      <source>Rename</source>
      <translation variants="no">Đổi tên</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_memory_details">
      <source>Memory details:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết bộ nhớ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_restore">
      <source>Restore</source>
      <translation variants="no">Khôi phục</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[07]1 %2</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[11]1 %2</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpopinfo_saved_to_1_device_memory">
      <source>Saved to %1 Device memory</source>
      <translation variants="no">Đã lưu vào Bộ nhớ thiết bị %[19]1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_sort">
      <source>Sort</source>
      <translation variants="no">Sắp xếp</translation>
    </message>
    <message numerus="no" id="txt_tws_caption_file_manager">
      <source>File Manager</source>
      <translation variants="yes">
        <lengthvariant priority="1">Quản lý tập tin</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_fmgr_info_l1_b">
      <source>%Ln B</source>
      <translation>
        <numerusform plurality="a">vi #%Ln B</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_new_name_folder">
      <source>Rename:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đổi tên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_all">
      <source>All</source>
      <translation variants="no">Tất cả</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[99]1 %2</translation>
    </message>
    <message numerus="yes" id="txt_fmgr_dblist_val_size_l1_b">
      <source>%Ln B</source>
      <translation>
        <numerusform plurality="a">vi #%Ln B</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_formlabel_time">
      <source>Time</source>
      <translation variants="no">Thời gian</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_restore">
      <source>Restore</source>
      <translation variants="yes">
        <lengthvariant priority="1">Khôi phục</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_subhead_copying_1">
      <source>Copying %1</source>
      <translation variants="no">Sao chép '%[99]1'</translation>
    </message>
  </context>
</TS>