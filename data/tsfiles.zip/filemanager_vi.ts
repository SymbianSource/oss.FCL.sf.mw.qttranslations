<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_fmgr_dblist_val_size_l1_gb">
      <source>Size: %L1 GB</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích cỡ: %L1 GB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card">
      <source>%[]1 Memory card</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thẻ nhớ %1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_set_password">
      <source>Set password</source>
      <translation variants="no">Đặt mật khẩu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_name_file">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_mb">
      <source>Free: %L1 MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dung lượng trống: %L1 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_memory_card">
      <source>%[]1 Memory card</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thẻ nhớ %1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_view_details_memory">
      <source>View details</source>
      <translation variants="no">Chi tiết</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_name">
      <source>Name</source>
      <translation variants="no">Tên</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_file_manager">
      <source>File Manager</source>
      <translation variants="yes">
        <lengthvariant priority="1">Quản lý tập tin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_size_memory">
      <source>Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích cỡ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_type_file">
      <source>Type:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Loại:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_free_l1_1">
      <source>Free: %L1 %[]1</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Free: %L1 %[22]1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_send">
      <source>Send</source>
      <translation variants="no">Gửi</translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_find">
      <source>Find</source>
      <translation variants="no">Tìm</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_name_folder">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_eject">
      <source>Eject</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_files">
      <source>Files:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tập tin:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_kb">
      <source>Free: %L1 kB</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dung lượng trống: %L1 kB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_device_memory">
      <source>%[]1 Device memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bộ nhớ máy %1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_move">
      <source>Move</source>
      <translation variants="no">Chuyển</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_usb_memory">
      <source>%[]1 USB memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ổ đĩa chung %1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_file_manager_caption_file_manager">
      <source>File Manager</source>
      <translation variants="no">vi #File manager</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_mass_storage">
      <source>%[]1 Mass storage</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ổ đĩa chung %1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_memory_name">
      <source>Memory name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_gb">
      <source>Free: %L1 GB</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dung lượng trống: %L1 GB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_size_folder">
      <source>Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích cỡ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_subfolders">
      <source>Subfolders:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thư mục con:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_size_file">
      <source>Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích cỡ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_remove_password">
      <source>Remove password</source>
      <translation variants="no">Xóa mật khẩu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_free_memory">
      <source>Free:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Trống:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_device_memory">
      <source>%[]1 Device memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bộ nhớ máy %1</lengthvariant>
        <lengthvariant priority="2">vi #%1 Device mem.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_delete">
      <source>Delete</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_mass_storage">
      <source>%[]1 Mass storage</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ổ đĩa chung %1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_date_folder">
      <source>Date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_view_details_file">
      <source>View details</source>
      <translation variants="no">Chi tiết</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_time_file">
      <source>Time:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giờ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_val_size_l1_mb">
      <source>Size: %L1 MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kích cỡ: %L1 MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_date_file">
      <source>Date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_copy">
      <source>Copy</source>
      <translation variants="no">Sao chép</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_new_folder">
      <source>New folder</source>
      <translation variants="no">vi #New folder</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dialog_entry_1_l1">
      <source>1% (%L1)</source>
      <translation variants="no">vi #1% (%L1)</translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_new_folder">
      <source>New folder</source>
      <translation variants="no">vi #New folder</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dialog_entry_new_folder_l1">
      <source>New folder (%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #New folder (%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_file_manager_list_file_manager">
      <source>File Manager</source>
      <translation variants="yes">
        <lengthvariant priority="1">Quản lý tập tin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_restore">
      <source>Restore</source>
      <translation variants="no">Khôi phục</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_rename">
      <source>Rename</source>
      <translation variants="no">Đổi tên</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_size_l1_1">
      <source>Size: %L1 %[]1</source>
      <translation variants="no">vi #Size: %L1 %[22]1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_2">
      <source>%1 %[]2</source>
      <translation variants="no">vi #%[22]1 %[21]2</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_memory_details">
      <source>Memory details:</source>
      <translation variants="no">Chi tiết:</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_2">
      <source>%[]1 %[]2</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #%[17]1 %[16]2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dialog_entry_001">
      <source>0.01</source>
      <translation variants="no">vi #0.01</translation>
    </message>
    <message numerus="no" id="txt_file_info_other_functions_are_unavailable_duri">
      <source>Other functions are unavailable during the restore</source>
      <translation variants="no">vi #Other functions are unavailable during the restore</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_new_name_folder">
      <source>Rename:</source>
      <translation variants="no">vi #Rename:</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_file_details">
      <source>File details:</source>
      <translation variants="no">Chi tiết:</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_time_folder">
      <source>Time:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Giờ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_backup">
      <source>Backup</source>
      <translation variants="no">Sao lưu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_change_password">
      <source>Change password</source>
      <translation variants="no">Đổi mật khẩu</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_format">
      <source>Format</source>
      <translation variants="no">Định dạng</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card_val_b">
      <source>Free: %L B</source>
      <translation variants="yes">
        <lengthvariant priority="1">Dung lượng trống: %L1 B</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_folder_details">
      <source>Folder details:</source>
      <translation variants="no">Chi tiết:</translation>
    </message>
    <message numerus="no" id="txt_file_manager_info_this_device_does_not_support">
      <source>This device does not support locked memory cards</source>
      <translation variants="no">vi #This device does not support locked memory cards</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dialog_entry_new_folder">
      <source>New folder</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #New folder</lengthvariant>
      </translation>
    </message>
  </context>
</TS>