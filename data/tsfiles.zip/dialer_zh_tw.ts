<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">zh_tw #Dialer</translation>
    </message>
    <message numerus="no" id="txt_dial_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新現有的連絡人</lengthvariant>
        <lengthvariant priority="2">zh_tw #Update existing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_title_add_to_contacts">
      <source>Add to Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">加入至通訊錄</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_info_call_event_will_be_removed_from">
      <source>Call event will be removed from the list. Continue?</source>
      <translation variants="no">通話事件將會從清單中移除。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_date_and_time">
      <source>Date and time</source>
      <translation variants="yes">
        <lengthvariant priority="1">日期與時間</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_menu_call_details">
      <source>Call details</source>
      <translation variants="no">通話詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_voip_call">
      <source>VoiP call</source>
      <translation variants="yes">
        <lengthvariant priority="1">網際網路通話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_recent_calls">
      <source>Recent calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近通話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_menu_open_contact">
      <source>Open contact</source>
      <translation variants="no">開啟連絡人卡片</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_subhead_matches">
      <source>Matches</source>
      <translation variants="yes">
        <lengthvariant priority="1">相符項目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_recent">
      <source>Recent</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近通話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_info_all_call_events_will_be_remo">
      <source>All call events will be removed from the list. Continue?</source>
      <translation variants="no">所有通話事件將會從清單中移除。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_missed">
      <source>Missed</source>
      <translation variants="yes">
        <lengthvariant priority="1">未接來電</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_service">
      <source>Call service</source>
      <translation variants="yes">
        <lengthvariant priority="1">通話服務</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_contact_search_on">
      <source>Contact search on</source>
      <translation variants="no">連絡人搜尋開啟</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_open_contact">
      <source>Open contact</source>
      <translation variants="no">開啟連絡人卡片</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_duration">
      <source>Call duration</source>
      <translation variants="yes">
        <lengthvariant priority="1">通話時間</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_change_call_service_sub_cellul">
      <source>Cellular</source>
      <translation variants="no">行動</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_change_call_service">
      <source>Change call service</source>
      <translation variants="no">變更通話服務</translation>
    </message>
    <message numerus="no" id="txt_dial_subhead_received_calls">
      <source>Received calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">已接來電</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_id_val_unknown_number">
      <source>Unknown number</source>
      <translation variants="yes">
        <lengthvariant priority="1">不明號碼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_no_history_of_calls">
      <source>No history of calls</source>
      <translation variants="no">無最近通話</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_dialled">
      <source>Dialled</source>
      <translation variants="yes">
        <lengthvariant priority="1">發出</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_contact_search_off">
      <source>Contact search off</source>
      <translation variants="no">連絡人搜尋關閉</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_service_val_cellular">
      <source>Cellular</source>
      <translation variants="yes">
        <lengthvariant priority="1">行動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">清除清單</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_missed">
      <source>Missed</source>
      <translation variants="yes">
        <lengthvariant priority="1">未接來電</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_title_delete_event">
      <source>Delete event</source>
      <translation variants="yes">
        <lengthvariant priority="1">從清單中移除通話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">撥號器</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_line_id">
      <source>Line ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">線路識別</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_no_saved_number_for_this_contact">
      <source>No saved number for this contact. Call not possible</source>
      <translation variants="no">無法撥號。缺少電話號碼。</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_last_call_event">
      <source>Last call event</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近的通話事件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_activated_profile_general">
      <source>Activated profile: general</source>
      <translation variants="no">啟動的操作模式：標準</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_line_id_val_line_2">
      <source>%L1, line 2</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1，號碼2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_outgoing_line_2">
      <source>Change outgoing line 2</source>
      <translation variants="no">變更撥出線路為號碼2</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_callee_id">
      <source>Callee ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">受話方識別</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_outgoing_line_1">
      <source>Change outgoing line 1</source>
      <translation variants="no">變更撥出線路為號碼1</translation>
    </message>
    <message numerus="no" id="txt_dial_dpopinfo_activated_profile_silent">
      <source>Activated profile: silent</source>
      <translation variants="no">啟動的操作模式：無聲</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_received">
      <source>Received</source>
      <translation variants="yes">
        <lengthvariant priority="1">已接來電</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_voice_call">
      <source>Voice call</source>
      <translation variants="yes">
        <lengthvariant priority="1">語音通話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_dialer">
      <source>Dialer</source>
      <translation variants="no">zh_tw #Dialer</translation>
    </message>
    <message numerus="no" id="txt_dial_opt_change_call_service_sub_cellular">
      <source>Cellular</source>
      <translation variants="no">行動</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_call_id_val_privat_number">
      <source>Privat number</source>
      <translation variants="yes">
        <lengthvariant priority="1">私人號碼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type_val_video_call">
      <source>Video call</source>
      <translation variants="yes">
        <lengthvariant priority="1">視訊電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction_val_received">
      <source>Received</source>
      <translation variants="yes">
        <lengthvariant priority="1">接收</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_dialled_calls">
      <source>Dialled calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">已撥電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_title_clear_list">
      <source>Clear list</source>
      <translation variants="yes">
        <lengthvariant priority="1">清除清單</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">另存為新連絡人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_line_id_val_line_1">
      <source>%L1, line 1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%L1，號碼1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_dialled">
      <source>Dialled</source>
      <translation variants="yes">
        <lengthvariant priority="1">已撥電話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_title_dialer">
      <source>Dialer</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_id">
      <source>Caller ID</source>
      <translation variants="yes">
        <lengthvariant priority="1">本機號碼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_subhead_missed_calls">
      <source>Missed calls</source>
      <translation variants="yes">
        <lengthvariant priority="1">未接來電</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_direction">
      <source>Call direction</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號方向</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dial_opt_call_using">
      <source>Call using</source>
      <translation variants="no">撥號以</translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_list_no_matches_found">
      <source>No matches found</source>
      <translation variants="no">無相符項目</translation>
    </message>
    <message numerus="no" id="txt_dial_dblist_val_dialer_enable_access_to_recent">
      <source>Dialer enable access to recent calls and dialpad</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥打電話和查看最近通話</lengthvariant>
        <lengthvariant priority="2">zh_tw #Make and see recent calls</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_dialer_ui_dblist_call_type">
      <source>Call type</source>
      <translation variants="yes">
        <lengthvariant priority="1">通話類型</lengthvariant>
      </translation>
    </message>
  </context>
</TS>