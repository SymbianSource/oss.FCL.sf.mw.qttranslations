<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_secur_info_reading_todos">
      <source>Allow this application to read to-dos? </source>
      <translation variants="no">是否允許此應用程式讀取待辦事項？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_writing_user_data">
      <source>Allow this application to write user data?</source>
      <translation variants="no">是否允許此應用程式寫入使用者資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_jar_not_found">
      <source>Application's deployment package not found.</source>
      <translation variants="no">找不到應用程式資料。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_mms_opening">
      <source>Allow this application to open a MMS connection? </source>
      <translation variants="no">是否允許此應用程式開啟多媒體訊息連線？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_events">
      <source>Allow this application to read events?</source>
      <translation variants="no">是否允許此應用程式讀取項目清單？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_auto_invocation">
      <source>Allow this application to be started automatically?</source>
      <translation variants="no">是否允許此應用程式自動啟動？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_manage_user_data">
      <source>Allow this application to manage user data?</source>
      <translation variants="no">是否允許此應用程式管理使用者資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_deleting_calendar">
      <source>Allow this application to delete the calendar file %1? </source>
      <translation variants="no">是否允許此應用程式刪除行事曆檔案%[33]1？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_location_data">
      <source>Allow this application to access location information? </source>
      <translation variants="no">是否允許此應用程式存取定位資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_title_app_name">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_unhandled_details">
      <source>Unhandled error. %1</source>
      <translation variants="no">未處理的例外狀況：
%1</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_drm_rights_not_valid">
      <source>No digital rights to launch application.</source>
      <translation variants="no">無法開啟應用程式。無可用的授權。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_bluetooth_usage">
      <source>Allow this application to be activated by a Bluetooth device %1?</source>
      <translation variants="no">是否允許此應用程式由藍牙裝置%[33]1啟動？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_url_start">
      <source>Allow this application to be started? </source>
      <translation variants="no">是否允許此應用程式啟動？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_jar_not_found_details">
      <source>Possible reasons for the missing files: the files might reside on a memory card which is not currently present or has been formatted.</source>
      <translation variants="no">遺失檔案的可能原因：檔案可能位於其他記憶卡上，或記憶卡已經格式化。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_push_registration_dynamic">
      <source>Registration for automatic start needed.</source>
      <translation variants="no">是否允許此應用程式註冊自動啟動？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_mms_single_sending">
      <source>Allow this application to send MMS? </source>
      <translation variants="no">是否允許此應用程式傳送多媒體訊息？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_ocsp_warning">
      <source>Unable to verify supplier. Continue installation anyway?</source>
      <translation variants="no">無法驗證供應商。是否仍要安裝？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_prompt_allow">
      <source>Allow </source>
      <translation variants="no">允許</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cbs_opening">
      <source>Allow this application to open a CBS connection?</source>
      <translation variants="no">是否允許此應用程式使用系統業者訊息功能？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_positioning_data_usage">
      <source>Allow this application to use positioning data?</source>
      <translation variants="no">是否允許此應用程式使用定位資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_sms_receiving">
      <source>Allow this application to receive SMSs?</source>
      <translation variants="no">是否允許此應用程式接收簡訊？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_ocsp_settings">
      <source>The online revocation checking of the certificate used to sign the application could not be conducted. Check your settings. </source>
      <translation variants="no">無法線上檢查憑證的有效性。請檢查設定。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_sms_sending">
      <source>Allow this application to send %L1 SMSs to %2?</source>
      <translation variants="no">是否允許此應用程式傳送%Ln則簡訊給%[99]1？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_prompt_deny">
      <source>Deny</source>
      <translation variants="no">拒絕</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_net_restr_violation_details">
      <source>The application is not allowed to be executed within the current network. This is due to roaming or SIM change. </source>
      <translation variants="no">因為漫遊或更換SIM卡，無法使用應用程式</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_smartcard">
      <source>Allow this application to access the smart card?</source>
      <translation variants="no">是否允許應用程式使用智慧卡？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_local_connectivity">
      <source>Allow this application to use local connectivity services? </source>
      <translation variants="no">是否允許此應用程式使用本端連線服務？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_jar_tampered_details">
      <source>The application’s deployment package has been modified, Application is not trusted anymore therefore it can not be used. You may want to uninstall the application. </source>
      <translation variants="no">應用程式已不再受信任且無法繼續使用。相關資料已經損毀，您可能會想解除安裝應用程式。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_app_cannot_start">
      <source>Launching the application failed. </source>
      <translation variants="no">應用程式啟動失敗</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_updating_category">
      <source>Allow this application to update category %1 in %2?</source>
      <translation variants="no">是否允許此應用程式更新%[17]2中的%[17]1類別？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_modifying_todos">
      <source>Allow this application to modify to-dos?</source>
      <translation variants="no">是否允許此應用程式修改待辦事項？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_orientation_data_usage">
      <source>Allow this application to use orientation data?</source>
      <translation variants="no">是否允許此應用程式使用物理定向資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_deleting_item">
      <source>Allow this application to delete this item from %1?</source>
      <translation variants="no">是否允許此應用程式從%[33]1中刪除此項目？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_adding_calendar">
      <source>Allow this application to create a new calendar?</source>
      <translation variants="no">是否允許此應用程式新增行事曆？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cbs_receiving">
      <source>Allow this application to receive CBSs?</source>
      <translation variants="no">是否允許此應用程式接收系統業者訊息？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_mms_single_send_multiple_dest">
      <source>Allow this application to send MMS to %L1 recipients?</source>
      <translation variants="no">是否允許此應用程式傳送多媒體訊息至%Ln位收件者？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_prompt_ok">
      <source>Ok</source>
      <translation variants="no">確定</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_contacts">
      <source>Allow this application to read contacts? </source>
      <translation variants="no">是否允許此應用程式讀取連絡人清單？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_deleting_unnamed_item">
      <source>Allow this application to delete unnamed item from %1?</source>
      <translation variants="no">是否允許此應用程式從%[30]1中刪除此未命名項目？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_net_restr_violation">
      <source>Network restriction violation. </source>
      <translation variants="no">在目前的系統中無法使用應用程式</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_tv_broadcast_user_data_access">
      <source>Allow this application to access TV broadcast user data? </source>
      <translation variants="no">是否允許此應用程式讀取與編輯電視訂閱以及檢視資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_modifying_events">
      <source>Allow this application to modify events?</source>
      <translation variants="no">是否允許此應用程式修改項目清單？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_error_details">
      <source>Details</source>
      <translation variants="no">詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_updating_unnamed_item">
      <source>Allow this application to update unnamed item in %1? </source>
      <translation variants="no">是否允許此應用程式更新%[31]1中的未命名項目？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_network_usage_via_plat_req">
      <source>Allow this application to use network for sending/receiving data? </source>
      <translation variants="no">是否允許此應用程式使用網路來傳送和接收資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_unhandled">
      <source>Application error. Application will be closed. </source>
      <translation variants="no">應用程式錯誤。應用程式即將關閉。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_landmarks_data_usage">
      <source>Allow this application to use landmarks data?</source>
      <translation variants="no">是否允許此應用程式使用地標資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_unexpected_error">
      <source>Unexpected error. </source>
      <translation variants="no">發生錯誤</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cert_deleted">
      <source>The certificate used to authenticate the application has been deleted therefore the application cannot be used anymore.  You should uninstall the application.</source>
      <translation variants="no">應用程式已無法繼續使用。用來驗證應用程式的憑證已刪除，且應用程式可能已被解除安裝。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_file">
      <source>Allow this application to open %1?</source>
      <translation variants="no">是否允許此應用程式開啟%[38]1？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_updating_item">
      <source>Allow this application to update this item in %1?</source>
      <translation variants="no">是否允許應用程式更新%[34]1中的此項目？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_auth_services_usage">
      <source>Allow this application to access authentication services?</source>
      <translation variants="no">是否允許此應用程式存取驗證服務？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_listing_calendars">
      <source>Allow this application to list the calendars available on phone?</source>
      <translation variants="no">是否允許此應用程式列出裝置上可用的行事曆？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_unidentified_application">
      <source>The application can not be identified. You may want to uninstall the application. </source>
      <translation variants="no">無法識別的應用程式。您可能會想解除安裝應用程式。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_sms_single_sending">
      <source>Allow this application to send SMS to %1?</source>
      <translation variants="no">是否允許此應用程式傳送簡訊給%[35]1？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_button_prompt_close">
      <source>Close</source>
      <translation variants="no">關閉</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cert_disabled">
      <source>The certificate used to authenticate the application has been disabled. You may want to enable the certificate or uninstall the application. </source>
      <translation variants="no">用來驗證此應用程式的憑證已停用。請啟用憑證或解除安裝應用程式。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_user_data">
      <source>Allow this application to read user data?</source>
      <translation variants="no">是否允許此應用程式讀取使用者資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_network_usage">
      <source>Allow this application to use network for sending/receiving data?</source>
      <translation variants="no">是否允許此應用程式使用網路來傳送和接收資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_ocsp_revoked">
      <source>Online certificate check failed. The certificate used to sign the application has been revoked either permanently or temporarily (on hold). </source>
      <translation variants="no">線上憑證檢查失敗。憑證已被永久或暫時撤銷。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_reading_landmark_data">
      <source>Allow this application to access landmark data?</source>
      <translation variants="no">是否允許此應用程式存取地標資料？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_jar_tampered">
      <source>The application has been tampered. </source>
      <translation variants="no">應用程式資料已損毀</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_deleting_category">
      <source>Allow this application to delete category %1 from %2? </source>
      <translation variants="no">是否允許此應用程式從%[17]2中刪除%[17]1類別？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_receive_send_messages">
      <source>Allow this application to receive and send messages?</source>
      <translation variants="no">是否允許此應用程式接收與傳送訊息？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_sms_opening">
      <source>Allow this application to open a SMS connection? </source>
      <translation variants="no">是否允許此應用程式使用簡訊功能？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_modifying_contacts">
      <source>Allow this application to modify contacts?</source>
      <translation variants="no">是否允許此應用程式修改連絡人？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_app_launch_via_plat_req">
      <source>Allow this application to start an application?</source>
      <translation variants="no">是否允許此應用程式啟動其他應用程式？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_proximity_listener_reg">
      <source>Allow this application to register a proximity listener? </source>
      <translation variants="no">是否允許此應用程式接收與位置相關的資訊？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_sim_changed">
      <source>The certificate used to authenticate the application resides on a SIM which is not currently available.  You may want to reinsert the correct SIM or uninstall the application.</source>
      <translation variants="no">用來驗證此應用程式的憑證位於其他SIM卡上。請重新插入SIM卡或解除安裝應用程式。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_nfc_ndef_tag_write">
      <source>Allow this application to write into a tag?</source>
      <translation variants="no">是否允許此應用程式寫入NFC標籤？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_error_ocsp_general_details">
      <source>Online certificate check failed. The revocation state of the certificate used to sign the application could not be determined. </source>
      <translation variants="no">線上憑證檢查失敗。無法判斷憑證是否有效。</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_audio_video_recording">
      <source>Allow this application to access camera, video player or audio features?</source>
      <translation variants="no">是否允許此應用程式存取攝影機、影片播放機和聲音功能？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_modifying_file">
      <source>Allow this application to modify %1?</source>
      <translation variants="no">是否允許此應用程式修改%[38]1？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_mms_receiving">
      <source>Allow this application to receive MMSs?</source>
      <translation variants="no">是否允許此應用程式接收多媒體訊息？</translation>
    </message>
    <message numerus="no" id="txt_java_secur_info_cert_not_available">
      <source>The certificate is not available.</source>
      <translation variants="no">憑證無法使用</translation>
    </message>
  </context>
</TS>