<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking">
      <source>Phone line blocking</source>
      <translation variants="no">线路更改</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als">
      <source>Phone line in use</source>
      <translation variants="no">使用中的线路</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service">
      <source>Service</source>
      <translation variants="no">服务</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_voice_line_2">
      <source>Voice line 2</source>
      <translation variants="no">语音线路2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_default">
      <source>Default</source>
      <translation variants="no">网络预设</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service_val_video_divert">
      <source>Video divert</source>
      <translation variants="no">视频通话转接</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_barring">
      <source>Call barring</source>
      <translation variants="yes">
        <lengthvariant priority="1">呼叫限制</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_out_of_reach">
      <source>If out of reach</source>
      <translation variants="no">无网络或关机时</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_received_call">
      <source>Own video in received call</source>
      <translation variants="no">视频通话时发送视频</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_service_val_voice_divert">
      <source>Voice divert</source>
      <translation variants="no">语音通话转接</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_ip_mbx">
      <source>%1 mailbox</source>
      <translation variants="no">zh #%[17]1 mailbox</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx">
      <source>Default mailbox</source>
      <translation variants="no">预设</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_voice">
      <source>Voice</source>
      <translation variants="no">语音信箱</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_dont_show">
      <source>Don't show</source>
      <translation variants="no">不显示</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_val_line_1">
      <source>Line 1</source>
      <translation variants="no">线路1</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_val_user_defined">
      <source>User defined</source>
      <translation variants="no">用户自定义</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting">
      <source>Internet call waiting</source>
      <translation variants="no">互联网通话等待</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_voice_mbx_line_2">
      <source>Voice mailbox line 2</source>
      <translation variants="no">语音信箱线路2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_not_available">
      <source>If not available</source>
      <translation variants="no">无法接通时</translation>
    </message>
    <message numerus="no" id="txt_phone_list_international_calls">
      <source>International calls</source>
      <translation variants="no">禁止拨出国际长途</translation>
    </message>
    <message numerus="no" id="txt_phone_list_incoming_call_when_abroad">
      <source>Incoming call when abroad</source>
      <translation variants="no">漫游时禁止来电</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting">
      <source>Call waiting</source>
      <translation variants="no">呼叫等待</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_send_my_caller_id">
      <source>Send my caller id</source>
      <translation variants="no">发送本机号码</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_busy">
      <source>If busy</source>
      <translation variants="no">手机占线时</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_no">
      <source>No</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">电话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_if_not_answered">
      <source>If not answered</source>
      <translation variants="no">无人接听时</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_val_line_2">
      <source>Line 2</source>
      <translation variants="no">线路2</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_all_calls">
      <source>All calls</source>
      <translation variants="no">全部通话</translation>
    </message>
    <message numerus="no" id="txt_phone_list_incoming_calls">
      <source>Incoming calls</source>
      <translation variants="no">禁止来电</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_ask_first">
      <source>Ask first</source>
      <translation variants="no">先询问</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_internet_call_waiting_val_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_list_international_calls_except_to_home">
      <source>International calls except to home country</source>
      <translation variants="no">禁止本国外的国际长途</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_soft_reject">
      <source>Reject call with message</source>
      <translation variants="no">通过信息拒绝通话</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_default_mbx_val_video">
      <source>Video</source>
      <translation variants="no">视频信箱</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_divert">
      <source>Call divert</source>
      <translation variants="yes">
        <lengthvariant priority="1">呼叫转接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_yes">
      <source>Yes</source>
      <translation variants="no">是</translation>
    </message>
    <message numerus="no" id="txt_phone_list_outgoing_calls">
      <source>Outgoing calls</source>
      <translation variants="no">禁止拨出电话</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_video_mbx">
      <source>Video mailbox</source>
      <translation variants="no">视频信箱</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_own_video_in_val_show_automatic">
      <source>Show automatically</source>
      <translation variants="no">自动显示</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_not_available">
      <source>If not available:</source>
      <translation variants="yes">
        <lengthvariant priority="1">无法接通时：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_diverts_activated">
      <source>Diverts activated</source>
      <translation variants="no">呼叫转接已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_divert_activated">
      <source>Divert activated</source>
      <translation variants="no">呼叫转接已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">不允许</translation>
    </message>
    <message numerus="no" id="txt_phone_info_result_unknown">
      <source>Result unknown</source>
      <translation variants="no">未知结果</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_lost_select_network">
      <source>Network lost. Select network?</source>
      <translation variants="no">网络丢失。搜索可用网络？</translation>
    </message>
    <message numerus="no" id="txt_phone_info_verify_new_password">
      <source>Verify new password</source>
      <translation variants="yes">
        <lengthvariant priority="1">验证新密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_deactivated">
      <source>Barring deactivated</source>
      <translation variants="no">呼叫限制已关闭</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_out_of_reach">
      <source>If out of reach:</source>
      <translation variants="yes">
        <lengthvariant priority="1">无网络或关机时：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_waiting_activated">
      <source>Call waiting activated</source>
      <translation variants="no">呼叫等待已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_edit_barring_password">
      <source>Edit barring password</source>
      <translation variants="no">编辑呼叫限制密码</translation>
    </message>
    <message numerus="no" id="txt_phone_list_to_voice_mailbox">
      <source>To voice mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">转至语音信箱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">手机号无效</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_not_confirmed">
      <source>Request not confirmed</source>
      <translation variants="no">请求未确认</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number">
      <source>Number:</source>
      <translation variants="yes">
        <lengthvariant priority="1">号码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_waiting_deactivated">
      <source>Call waiting deactivated</source>
      <translation variants="no">呼叫等待已关闭</translation>
    </message>
    <message numerus="no" id="txt_phone_list_enter_number_manually">
      <source>Enter number manually</source>
      <translation variants="yes">
        <lengthvariant priority="1">输入号码</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_rejected">
      <source>Request rejected</source>
      <translation variants="no">请求被拒绝</translation>
    </message>
    <message numerus="no" id="txt_phone_info_current_password">
      <source>Current password</source>
      <translation variants="yes">
        <lengthvariant priority="1">当前密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_password_changed">
      <source>Password changed</source>
      <translation variants="no">密码已改</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_busy">
      <source>If busy:</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机占线时：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_password_blocked">
      <source>Barring password blocked</source>
      <translation variants="no">呼叫限制密码已锁</translation>
    </message>
    <message numerus="no" id="txt_phone_info_divert_deactivated">
      <source>Divert deactivated</source>
      <translation variants="no">呼叫转接已关闭</translation>
    </message>
    <message numerus="no" id="txt_phone_info_diverts_deactivated">
      <source>Diverts deactivated</source>
      <translation variants="no">呼叫转接已关闭</translation>
    </message>
    <message numerus="no" id="txt_phone_title_if_not_answered">
      <source>If not answered:</source>
      <translation variants="yes">
        <lengthvariant priority="1">无人接听时：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_activated">
      <source>Barring activated</source>
      <translation variants="no">呼叫限制已启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_password">
      <source>Barring password:</source>
      <translation variants="yes">
        <lengthvariant priority="1">呼叫限制密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_conflict_error">
      <source>Conflict error</source>
      <translation variants="no">发生冲突</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_edit_barring_password_val_edit">
      <source>Edit</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_als_line_blocking_val_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_settings">
      <source>Call settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">通话设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_call_mbx">
      <source>Call mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">留言信箱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_soft_reject_val_default_text">
      <source>Hi, I’m busy at the moment, but I contact you a bit later.</source>
      <translation variants="no">对不起，正忙。稍后再给您电话。</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_val_none">
      <source>None</source>
      <translation variants="no">无</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_image_in_video_call">
      <source>Image in video call</source>
      <translation variants="no">视频通话时发送图像</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_voice_mbx">
      <source>Voice mailbox</source>
      <translation variants="no">语音信箱</translation>
    </message>
    <message numerus="no" id="txt_phone_title_delay">
      <source>Delay:</source>
      <translation variants="yes">
        <lengthvariant priority="1">延时：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_accounts">
      <source>Accounts</source>
      <translation variants="yes">
        <lengthvariant priority="1">帐户</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_dblist_active_diverts">
      <source>Active diverts</source>
      <translation variants="no">当前转接</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_network_services">
      <source>Check network services</source>
      <translation variants="no">zh #Check network services</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_data_usage_when_roaming">
      <source>Data usage when roaming</source>
      <translation variants="no">zh #Data usage when abroad</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_available_in_curren">
      <source>Service not available in current location</source>
      <translation variants="no">服务在当前位置不可用</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_data_usage_in_val_disabled">
      <source>Disabled</source>
      <translation variants="no">zh #Disabled</translation>
    </message>
    <message numerus="no" id="txt_phone_info_voice_calls">
      <source>Voice calls</source>
      <translation variants="no">语音通话</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_disabled">
      <source>Disabled</source>
      <translation variants="no">zh #Disabled</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_operator_selection">
      <source>Operator selection</source>
      <translation variants="no">运营商选择</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_call_waiting_val_check_status">
      <source>Check status</source>
      <translation variants="yes">
        <lengthvariant priority="1">检查状态</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_show_call_duration_val_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">开</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_title_select_operator">
      <source>Select operator</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择运营商：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_call_waiting_not_active">
      <source>Call waiting not active</source>
      <translation variants="no">呼叫等待未启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_operator_selection_not_possible_in">
      <source>Operator selection not possible in offline mode</source>
      <translation variants="no">无法在离线模式下选择运营商</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_show_call_duration_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_title_active_for">
      <source>Active for</source>
      <translation variants="yes">
        <lengthvariant priority="1">已启动：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_network_mode">
      <source>Network mode</source>
      <translation variants="no">网络模式</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_automatic">
      <source>Automatic</source>
      <translation variants="no">zh #Automatic</translation>
    </message>
    <message numerus="yes" id="txt_phone_setlabel_divert_delay_ln_seconds">
      <source>Divert delay %Ln seconds</source>
      <translation>
        <numerusform plurality="a">转接延时：%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_network_mode_val_dual_mode">
      <source>Dual mode</source>
      <translation variants="no">zh #Dual mode</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_home_network_selected">
      <source>Home network selected</source>
      <translation variants="no">注册网络已选</translation>
    </message>
    <message numerus="no" id="txt_phone_info_offline_not_allowed">
      <source>Offline, not allowed</source>
      <translation variants="no">无法在离线模式下执行操作</translation>
    </message>
    <message numerus="no" id="txt_phone_info_active_calls_must_be_disconnected_b">
      <source>Active calls must be disconnected before operator selection</source>
      <translation variants="no">结束所有当前通话然后选择运营商</translation>
    </message>
    <message numerus="no" id="txt_phone_formlabel_show_call_duration">
      <source>Show call duration</source>
      <translation variants="no">显示通话时间</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_network_coverage">
      <source>No network coverage</source>
      <translation variants="no">zh #No network coverage</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_call_waiting_active">
      <source>Call waiting active</source>
      <translation variants="no">呼叫等待启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_updating_operator_list">
      <source>Updating operator list</source>
      <translation variants="no">正在更新运营商列表</translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_add_new_accounts">
      <source>Add new accounts</source>
      <translation variants="yes">
        <lengthvariant priority="1">新增帐户</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_val_confirm">
      <source>Confirm</source>
      <translation variants="no">zh #Confirm</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_data_usage_in_val_confirm">
      <source>Confirm</source>
      <translation variants="no">zh #Confirm</translation>
    </message>
    <message numerus="no" id="txt_phone_info_fax">
      <source>Fax</source>
      <translation variants="no">传真</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_calls">
      <source>Video calls</source>
      <translation variants="no">视频通话</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_operator_selection_val_automati">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Automatic</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_data_usage_in_val_automatic">
      <source>Automatic</source>
      <translation variants="no">zh #Automatic</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_operators_found">
      <source>No operators found</source>
      <translation variants="no">未找到网络</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_divert_not_active">
      <source>Divert not active</source>
      <translation variants="no">呼叫转接未启动</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_access_to_operators_network">
      <source>No access to operator's network</source>
      <translation variants="no">不允许访问此网络</translation>
    </message>
    <message numerus="no" id="txt_phone_info_password_error">
      <source>Password error</source>
      <translation variants="no">zh #Password error</translation>
    </message>
    <message numerus="no" id="txt_phone_info_to_numbernl1">
      <source>To number:\n%L1</source>
      <translation variants="no">转接至号码：
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_selected_network_l">
      <source>Selected network: %1</source>
      <translation variants="no">已选网络：%1</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_network_mode_val_gsm">
      <source>GSM</source>
      <translation variants="no">zh #GSM</translation>
    </message>
    <message numerus="no" id="txt_phone_info_barring_operation_not_successful">
      <source>Barring operation not successful. Contact your service provider</source>
      <translation variants="no">呼叫限制操作未成功。请向服务提供商咨询。</translation>
    </message>
    <message numerus="no" id="txt_phone_info_request_not_completed">
      <source>Request not completed</source>
      <translation variants="no">请求未完成</translation>
    </message>
    <message numerus="no" id="txt_phone_title_all_calls">
      <source>All calls:</source>
      <translation variants="yes">
        <lengthvariant priority="1">所有通话：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_new_password">
      <source>New password</source>
      <translation variants="yes">
        <lengthvariant priority="1">新密码：</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_phone_list_ln_seconds">
      <source>%Ln seconds</source>
      <translation>
        <numerusform plurality="a">%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_phone_info_delay_timenln_seconds">
      <source>Delay time:\n%Ln seconds</source>
      <translation>
        <numerusform plurality="a">延迟时间：
%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_data_usage_in_home_network">
      <source>Data usage in home network</source>
      <translation variants="no">zh #Data usage in home network</translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_operator_selection_val_manual">
      <source>Manual</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Manual</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_subhead_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">移动网络</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_setlabel_network_mode_val_umts">
      <source>UMTS</source>
      <translation variants="no">zh #UMTS</translation>
    </message>
  </context>
</TS>