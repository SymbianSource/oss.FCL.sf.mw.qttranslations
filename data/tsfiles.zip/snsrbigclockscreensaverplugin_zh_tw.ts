<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_screensaver_title_slide_down_to_open">
      <source>Slide down to open</source>
      <translation variants="no">zh_tw #Slide down to open</translation>
    </message>
  </context>
</TS>