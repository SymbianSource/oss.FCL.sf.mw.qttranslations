<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_wrt_info_media">
      <source>Media</source>
      <translation variants="no">zh_hk #Media</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_signature_invalid">
      <source>Signature invalid</source>
      <translation variants="no">zh_hk #Signature invalid</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_uninstall">
      <source>Uninstall</source>
      <translation variants="no">zh_hk #Uninstall</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_videoplayer">
      <source>VideoPlayer</source>
      <translation variants="no">zh_hk #VideoPlayer</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_messaging">
      <source>Messaging</source>
      <translation variants="no">zh_hk #Messaging</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_widget_uninstall">
      <source>Widget uninstall</source>
      <translation variants="no">zh_hk #Widget uninstall</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_install_failure">
      <source>Install Failure</source>
      <translation variants="no">zh_hk #Install Failure</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_widget_successfully_installed">
      <source>Widget successfully installed</source>
      <translation variants="no">zh_hk #Widget successfully installed</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_audioplayer">
      <source>AudioPlayer</source>
      <translation variants="no">zh_hk #AudioPlayer</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_widget_install_error">
      <source>Widget install error</source>
      <translation variants="no">zh_hk #Widget install error</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_sensor">
      <source>Sensor</source>
      <translation variants="no">zh_hk #Sensor</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_to_access">
      <source>to access:</source>
      <translation variants="no">zh_hk #to access:</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_telephony">
      <source>Telephony</source>
      <translation variants="no">zh_hk #Telephony</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_sysinfo">
      <source>Sysinfo</source>
      <translation variants="no">zh_hk #Sysinfo</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_calendar">
      <source>Calendar</source>
      <translation variants="no">zh_hk #Calendar</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_uninstall_successful">
      <source>Uninstall Successful</source>
      <translation variants="no">zh_hk #Uninstall Successful</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_uninstall_failed">
      <source>Uninstall Failed</source>
      <translation variants="no">zh_hk #Uninstall Failed</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_camera">
      <source>Camera</source>
      <translation variants="no">zh_hk #Camera</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_install_cancelation">
      <source>Install Cancelation</source>
      <translation variants="no">zh_hk #Install Cancelation</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_installation_failed">
      <source>Installation failed</source>
      <translation variants="no">zh_hk #Installation failed</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_landmark">
      <source>Landmark</source>
      <translation variants="no">zh_hk #Landmark</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_uninstall_error">
      <source>Uninstall Error</source>
      <translation variants="no">zh_hk #Uninstall Error</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_do_you_want_to_remove_1">
      <source>Do you want to remove %1?</source>
      <translation variants="no">zh_hk #Do you want to remove %1?</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_contact">
      <source>Contact</source>
      <translation variants="no">zh_hk #Contact</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_communication_logs">
      <source>Communication Logs</source>
      <translation variants="no">zh_hk #Communication Logs</translation>
    </message>
    <message numerus="no" id="txt_wrt_button_allow">
      <source>Allow</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Allow</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_wrt_info_do_you_want_to_install_1">
      <source>Do you want to install %1?</source>
      <translation variants="no">zh_hk #Do you want to install %1?</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_filesystem">
      <source>Filesystem</source>
      <translation variants="no">zh_hk #Filesystem</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_unknown_error">
      <source>Unknown error</source>
      <translation variants="no">zh_hk #Unknown error</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_do_you_still_want_to_install">
      <source>Do you still want to install?</source>
      <translation variants="no">zh_hk #Do you still want to install?</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_replace_existing_widget">
      <source>Replace existing widget?</source>
      <translation variants="no">zh_hk #Replace existing widget?</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_security_warning">
      <source>Security Warning</source>
      <translation variants="no">zh_hk #Security Warning</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_location">
      <source>Location</source>
      <translation variants="no">zh_hk #Location</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_installation_cancelled">
      <source>Installation cancelled</source>
      <translation variants="no">zh_hk #Installation cancelled</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_widget_install">
      <source>Widget install</source>
      <translation variants="no">zh_hk #Widget install</translation>
    </message>
    <message numerus="no" id="txt_widgetmanager_info_do_you_want_to_install_thi">
      <source>Do you want to install %1? This application is from an un-trusted source and can be harmful</source>
      <translation variants="no">zh_hk #Do you want to install %1? This application is from an un-trusted source and can be harmful</translation>
    </message>
    <message numerus="no" id="txt_wrt_info_allow">
      <source>Allow</source>
      <translation variants="no">zh_hk #Allow</translation>
    </message>
    <message numerus="no" id="txt_wrt_title_install_error">
      <source>Install Error</source>
      <translation variants="no">zh_hk #Install Error</translation>
    </message>
  </context>
</TS>