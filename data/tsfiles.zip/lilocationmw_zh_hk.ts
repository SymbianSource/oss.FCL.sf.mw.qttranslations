<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_loe_list_use_1">
      <source>Use %1</source>
      <translation variants="no">使用%1</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_day_and_l2_hour">
      <source>Updates every %L1 day and %L2 hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1天%L2小時</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_hour_and_l2_minute">
      <source>Updates every %L1 hour and %L2 minute</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1小時%L2分鐘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_wifi">
      <source>Wi-Fi</source>
      <translation variants="no">WLAN</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_minute_and_l2_seco">
      <source>Updates every %L1 minute and %L2 second</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1分鐘%L2秒</lengthvariant>
        <lengthvariant priority="2">zh_hk #Update interval: %L1 min. %L2 sec.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_enable_for_most_accurate_positioning">
      <source>Enable for most accurate positioning</source>
      <translation variants="no">GPS是最精準的方法</translation>
    </message>
    <message numerus="no" id="txt_loe_list_assisted_gps">
      <source>Assisted GPS</source>
      <translation variants="no">輔助GPS</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_positioning_settings">
      <source>Positioning settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">定位設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_location_was_requested_by">
      <source>Location was requested by : </source>
      <translation variants="no">您的方位要求來自於：</translation>
    </message>
    <message numerus="no" id="txt_loe_list_valid_until_1">
      <source>Valid until %1</source>
      <translation variants="no">有效期結束於%1</translation>
    </message>
    <message numerus="no" id="txt_loe_list_upd_every_l1_hour_and_l2_minute">
      <source>Updates every %L1 hour and %L2 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1小時%L2分鐘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_background_positioning">
      <source>Background positioning</source>
      <translation variants="no">背景定位</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_hours_and_l2_minut">
      <source>Updates every %L1 hours and %L2 minute</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1小時%L2分鐘</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_months">
      <source>Updates every %Ln months</source>
      <translation>
        <numerusform plurality="a">更新間隔：%Ln個月</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_minutes_and_l2_sec">
      <source>Updates every %L1 minutes and %L2 second</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1分鐘%L2秒</lengthvariant>
        <lengthvariant priority="2">zh_hk #Update interval: %L1 mins. %L2 sec.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_months_and_l2_days">
      <source>Updates every %L1 months and %L2 days</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1個月%L2天</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_month_and_l2_days">
      <source>Updates every %L1 month and %L2 days</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1個月%L2天</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_unknown_requestor">
      <source>Unknown requestor</source>
      <translation variants="no">未知</translation>
    </message>
    <message numerus="no" id="txt_loe_list_up_every_l1_hours_and_l2_minut">
      <source>Updates every %L1 hours and %L2 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1小時%L2分鐘</lengthvariant>
        <lengthvariant priority="2">zh_hk #Update interval: %L1 hrs %L2 mins.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_button_done">
      <source>Done</source>
      <translation variants="yes">
        <lengthvariant priority="1">完成</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_info_ln_unknown_requestors">
      <source>%Ln Unknown requestors</source>
      <translation>
        <numerusform plurality="a">%Ln個未知的要求者</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_stop_service_1">
      <source>Stop service %1</source>
      <translation variants="no">是否停止服務？
%1</translation>
    </message>
    <message numerus="no" id="txt_loe_dpophead_your_location_not_sent_to">
      <source>Your location not sent to :</source>
      <translation variants="no">您的方位未傳送至：</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_days_and_l2_hour">
      <source>Updates every %L1 days and %L2 hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1天%L2小時</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_button_accept">
      <source>Accept</source>
      <translation variants="no">接受</translation>
    </message>
    <message numerus="no" id="txt_loe_list_cellular_network">
      <source>Cellular network</source>
      <translation variants="no">流動網絡</translation>
    </message>
    <message numerus="no" id="txt_loe_opt_delete_server">
      <source>Delete server</source>
      <translation variants="no">刪除伺服器</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_days_and_l2_hours">
      <source>Updates every %L1 days and %L2 hours</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1天%L2小時</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_dpophead_your_location_sent_to">
      <source>Your location sent to :</source>
      <translation variants="no">您的方位已傳送至：</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_positioning_methods">
      <source>Positioning methods</source>
      <translation variants="yes">
        <lengthvariant priority="1">定位方法</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_hours">
      <source>Updates every %Ln hours</source>
      <translation>
        <numerusform plurality="a">更新間隔：%Ln小時</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_internal_gps">
      <source>Internal GPS</source>
      <translation variants="no">內建GPS</translation>
    </message>
    <message numerus="no" id="txt_loe_info_use_wifi_and_mobile_networks_to_get">
      <source>Use only WI-FI and mobile networks to get position information</source>
      <translation variants="no">WLAN和流動網路也可以判斷您的位置</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_positioning_servers">
      <source>Positioning servers</source>
      <translation variants="yes">
        <lengthvariant priority="1">定位伺服器</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_select_server_to_delete">
      <source>Select server to delete</source>
      <translation variants="no">選擇要刪除的伺服器：</translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_not_be_shared_peri">
      <source>Your location will not be shared periodically by default if you don't respond</source>
      <translation variants="no">依照預設，如果您不回覆，則不會定期分享您的方位。</translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_background_positioning">
      <source>Background positioning</source>
      <translation variants="yes">
        <lengthvariant priority="1">背景定位</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_subtitle_advanced_positioning_settings">
      <source>Advanced positioning settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">進階定位設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_be_shared_with">
      <source>Your location will be shared with :</source>
      <translation variants="no">您的方位將與下列對象分享：</translation>
    </message>
    <message numerus="no" id="txt_loe_list_gps">
      <source>GPS</source>
      <translation variants="no">GPS</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_day_and_l2_hours">
      <source>Updates every %L1 day and %L2 hours</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1天%L2小時</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_bluetooth_gps">
      <source>Bluetooth GPS</source>
      <translation variants="no">藍牙GPS</translation>
    </message>
    <message numerus="no" id="txt_loe_list_wireless_networks">
      <source>Wireless networks</source>
      <translation variants="no">無線網絡</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_month_and_l2_day">
      <source>Updates every %L1 month and %L2 day</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1個月%L2天</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_days">
      <source>Updates every %Ln days</source>
      <translation>
        <numerusform plurality="a">更新間隔：%Ln天</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_up_every_l1_minutes_and_l2_sec">
      <source>Updates every %L1 minutes and %L2 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1分鐘%L2秒</lengthvariant>
        <lengthvariant priority="2">zh_hk #Updates interval: %L1 mins. %L2 secs.</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_ln_minutes">
      <source>Updates every %Ln minutes</source>
      <translation>
        <numerusform plurality="a">更新間隔：%Ln分鐘</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_info_enable_applications_and_services_upda">
      <source>Enable applications and services update and retrieve location information on the background</source>
      <translation variants="no">啟用應用程式和服務以在背景中更新並擷取方位資料</translation>
    </message>
    <message numerus="no" id="txt_loe_list_updates_every_l1_months_and_l2_day">
      <source>Updates every %L1 months and %L2 day</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1個月%L2天</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_upd_every_l1_minute_and_l2_seco">
      <source>Updates every %L1 minute and %L2 seconds</source>
      <translation variants="yes">
        <lengthvariant priority="1">更新間隔：%L1分鐘%L2秒</lengthvariant>
        <lengthvariant priority="2">zh_hk #Update interval: %L1 min. %L2 secs.</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_updates_every_l1_seconds">
      <source>Updates every %Ln seconds</source>
      <translation>
        <numerusform plurality="a">zh_hk #Update interval: %L1 seconds</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_dblist_positioning">
      <source>Current location</source>
      <translation variants="yes">
        <lengthvariant priority="1">定位</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_button_advanced">
      <source>Advanced</source>
      <translation variants="yes">
        <lengthvariant priority="1">進階設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_title_positioning">
      <source>Current location</source>
      <translation variants="no">定位</translation>
    </message>
    <message numerus="no" id="txt_loe_title_save_as">
      <source>Save as</source>
      <translation variants="no">另存新檔</translation>
    </message>
    <message numerus="no" id="txt_loe_title_location_request">
      <source>Location request</source>
      <translation variants="no">方位要求</translation>
    </message>
    <message numerus="no" id="txt_loe_dblist_positioning_val_acquiring_position">
      <source>Acquiring position</source>
      <translation variants="yes">
        <lengthvariant priority="1">正在取得位置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_positioning_val_change_positioning_s">
      <source>Change positioning settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">更換定位設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_positioning">
      <source>Positioning</source>
      <translation variants="yes">
        <lengthvariant priority="1">定位</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_location_button_close">
      <source>Close</source>
      <translation variants="no">關閉</translation>
    </message>
    <message numerus="no" id="txt_loe_button_save">
      <source>Save</source>
      <translation variants="no">儲存</translation>
    </message>
    <message numerus="no" id="txt_loe_button_settings">
      <source>Settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="yes" id="txt_loe_list_accuracy_ln_kilometers">
      <source>Accuracy: %Ln kilometers</source>
      <translation>
        <numerusform plurality="a">精確度：%Ln公里</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_loe_list_accuracy_ln_meters">
      <source>Accuracy: %Ln meters</source>
      <translation>
        <numerusform plurality="a">精確度：%Ln米</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4e">
      <source>%L1˚%L2'%L3.%L4"E</source>
      <translation variants="no">%L1˚%L2'%L3.%L4"E</translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4n">
      <source>%L1˚%L2'%L3.%L4"N</source>
      <translation variants="no">%L1˚%L2'%L3.%L4"N</translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4s">
      <source>%L1˚%L2'%L3.%L4"S</source>
      <translation variants="no">%L1˚%L2'%L3.%L4"S</translation>
    </message>
    <message numerus="no" id="txt_loe_list_l1l2l3l4w">
      <source>%L1˚%L2'%L3.%L4"W</source>
      <translation variants="no">%L1˚%L2'%L3.%L4"W</translation>
    </message>
    <message numerus="no" id="txt_loe_list_last_update_1">
      <source>Updated: %1</source>
      <translation variants="no">更新時間：%1</translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_be_shared_by_defau">
      <source>Your location will be shared by default if you don’t respond</source>
      <translation variants="no">依預設，如您未回應，將分享您的方位。</translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_be_shared_periodic">
      <source>Your location will be shared periodically by default if you don’t respond.</source>
      <translation variants="no">依預設，如您未回應，將定期分享您的方位。</translation>
    </message>
    <message numerus="no" id="txt_loe_info_you_location_will_be_shared_periodica">
      <source>You location will be shared periodically with :</source>
      <translation variants="no">依預設，將定期以下列方式分享您的方位：</translation>
    </message>
    <message numerus="no" id="txt_loe_info_your_location_will_not_be_shared_by_d">
      <source>Your location will not be shared by default if you don’t respond</source>
      <translation variants="no">依預設，如您未回應，將不會分享您的方位。</translation>
    </message>
    <message numerus="no" id="txt_location_info_periodic_location_sharing_servic">
      <source>Periodic location sharing service has been activated. To terminate this service, Go to Control Panel-&gt;Positioning Settings-&gt;Advanced.</source>
      <translation variants="no">定期方位分享已啟動。若要關閉本服務，請前往控制台&gt;定位設定&gt;進階。</translation>
    </message>
  </context>
</TS>