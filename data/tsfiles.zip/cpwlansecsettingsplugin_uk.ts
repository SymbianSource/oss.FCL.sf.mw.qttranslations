<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_wep_key_4">
      <source>WEP key #4</source>
      <translation variants="no">uk ##WEP key #4</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_3">
      <source>WEP key #3</source>
      <translation variants="no">uk ##WEP key #3</translation>
    </message>
    <message numerus="no" id="txt_occ_preshared_key_format">
      <source>Pre-shared key format</source>
      <translation variants="no">uk ##Pre-shared key format</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_type">
      <source>EAP type</source>
      <translation variants="no">uk ##EAP type</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unencrypted_connection">
      <source>Unencrypted connection</source>
      <translation variants="no">uk ##Unencrypted connection</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_8021x">
      <source>802.1X</source>
      <translation variants="no">uk ##802.1X</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_authentication">
      <source>WAPI authentication</source>
      <translation variants="no">uk ##WAPI authentication</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2_val_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">uk ##Pre-shared key</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_2">
      <source>WEP key #2</source>
      <translation variants="no">uk ##WEP key #2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_1">
      <source>WEP key #1</source>
      <translation variants="no">uk ##WEP key #1</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_use">
      <source>WEP key in use</source>
      <translation variants="no">uk ##WEP key in use</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_root_cert_not_defined">
      <source>(not defined)</source>
      <translation variants="no">uk ##(not defined)</translation>
    </message>
    <message numerus="no" id="txt_occ_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">uk ##Pre-shared key</translation>
    </message>
    <message numerus="no" id="txt_occ_certificate">
      <source>Certificate</source>
      <translation variants="no">uk ##Certificate</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_root_certificate">
      <source>WAPI root certificate</source>
      <translation variants="no">uk ##WAPI root certificate</translation>
    </message>
    <message numerus="no" id="txt_occ_ascii">
      <source>ASCII</source>
      <translation variants="no">uk ##ASCII</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_unencrypted_connection_val_allowe">
      <source>Allowed</source>
      <translation variants="no">uk ##Allowed</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_3">
      <source>#3</source>
      <translation variants="no">uk ###3</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpawpa2">
      <source>WPA/WPA2</source>
      <translation variants="no">uk ##WPA/WPA2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_preshared_key_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">uk ##(not defined)</translation>
    </message>
    <message numerus="no" id="txt_occ_button_eap_type_settings">
      <source>EAP type settings</source>
      <translation variants="no">uk ##EAP type settings</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_client_cert_not_defined">
      <source>(not defined)</source>
      <translation variants="no">uk ##(not defined)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_2">
      <source>#2</source>
      <translation variants="no">uk ###2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_1">
      <source>#1</source>
      <translation variants="no">uk ###1</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpa2_only">
      <source>WPA2 only</source>
      <translation variants="no">uk ##WPA2 only</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wapi">
      <source>WAPI</source>
      <translation variants="no">uk ##WAPI</translation>
    </message>
    <message numerus="no" id="txt_occ_wapi_client_certificate">
      <source>WAPI client certificate</source>
      <translation variants="no">uk ##WAPI client certificate</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2">
      <source>Authentication mode</source>
      <translation variants="no">uk ##Authentication mode</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_preshared_key">
      <source>Pre-shared key</source>
      <translation variants="no">uk ##Pre-shared key</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_security_settings">
      <source>Security settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Security settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_hexadecimal">
      <source>Hexadecimal</source>
      <translation variants="no">uk ##Hexadecimal</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wpawpa2_val_eap">
      <source>EAP</source>
      <translation variants="no">uk ##EAP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wep">
      <source>WEP</source>
      <translation variants="no">uk ##WEP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wep_key_in_val_4">
      <source>#4</source>
      <translation variants="no">uk ###4</translation>
    </message>
  </context>
</TS>