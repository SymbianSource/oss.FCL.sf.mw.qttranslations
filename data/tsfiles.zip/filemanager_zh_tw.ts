<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_fmgr_opt_backup">
      <source>Backup</source>
      <translation variants="no">備份</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_change_password">
      <source>Change password</source>
      <translation variants="no">變更密碼</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_format">
      <source>Format</source>
      <translation variants="no">格式化</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_file_details">
      <source>File details:</source>
      <translation variants="yes">
        <lengthvariant priority="1">檔案詳細資訊：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_folder_details">
      <source>Folder details:</source>
      <translation variants="yes">
        <lengthvariant priority="1">資料夾詳細資訊：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_set_password">
      <source>Set password</source>
      <translation variants="no">設定密碼</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_name">
      <source>Name</source>
      <translation variants="no">名稱</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_type_file">
      <source>Type:</source>
      <translation variants="yes">
        <lengthvariant priority="1">類型：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="no">%1記憶卡</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_file_manager">
      <source>File Manager</source>
      <translation variants="yes">
        <lengthvariant priority="1">檔案管理</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_fmgr_dblist_val_size_l1_gb">
      <source>%Ln GB</source>
      <translation>
        <numerusform plurality="a">大小：%L1 GB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_view_details_memory">
      <source>View details</source>
      <translation variants="no">詳細資訊</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="no">%1記憶卡</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="no">%1大型記憶體</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_files">
      <source>Files:</source>
      <translation variants="yes">
        <lengthvariant priority="1">檔案：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_find">
      <source>Find</source>
      <translation variants="no">尋找</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_eject">
      <source>Eject</source>
      <translation variants="no">移除</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_free_memory">
      <source>Free:</source>
      <translation variants="yes">
        <lengthvariant priority="1">可用：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_remove_password">
      <source>Remove password</source>
      <translation variants="no">移除密碼</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_usb_memory">
      <source>%1 USB memory</source>
      <translation variants="no">%1大型記憶體</translation>
    </message>
    <message numerus="yes" id="txt_fmgr_dblist_val_size_l1_mb">
      <source>%Ln MB</source>
      <translation>
        <numerusform plurality="a">大小：%L1 MB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_memory_name">
      <source>Memory name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="no">%1大型記憶體</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_subfolders">
      <source>Subfolders:</source>
      <translation variants="yes">
        <lengthvariant priority="1">子資料夾：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="no">%1裝置記憶體</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="no">%1裝置記憶體</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dialog_entry_new_folder">
      <source>New folder</source>
      <translation variants="yes">
        <lengthvariant priority="1">新資料夾</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_backup_created_1">
      <source>Backup created %1</source>
      <translation variants="no">備份建立於%1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_completed">
      <source>Backup completed</source>
      <translation variants="no">備份已完成</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_scheduling">
      <source>Backup scheduling</source>
      <translation variants="no">備份排程</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_creating_backup">
      <source>Creating backup</source>
      <translation variants="no">正在建立備份</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpopinfo_saved_to_1_mass_storage">
      <source>Saved to %1 Mass storage</source>
      <translation variants="no">已儲存至%[13]1大型記憶體</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_contacts">
      <source>Contacts</source>
      <translation variants="no">連絡人</translation>
    </message>
    <message numerus="no" id="txt_file_manager_info_this_device_does_not_support">
      <source>This device does not support locked memory cards</source>
      <translation variants="no">不支援已鎖定的記憶卡</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_date">
      <source>Date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">日期：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_val_total_size">
      <source>Size: %1</source>
      <translation variants="no">大小：%1</translation>
    </message>
    <message numerus="no" id="txt_fmgr_info_backup_unavailable">
      <source>Unable to perform backup. %1 not available</source>
      <translation variants="no">無法執行備份。%[99]1無法使用。</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_scheduling_val_daily">
      <source>Daily</source>
      <translation variants="no">每日</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpopinfo_try_again">
      <source>Try again</source>
      <translation variants="no">請再試一次。</translation>
    </message>
    <message numerus="no" id="txt_fmgr_info_backup_locked">
      <source>Unable to perform backup. %1 locked</source>
      <translation variants="no">無法執行備份。%[99]1已鎖定。</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_sort_by_time">
      <source>Sort by time</source>
      <translation variants="no">依時間排序</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_delete_backup">
      <source>Delete backup</source>
      <translation variants="yes">
        <lengthvariant priority="1">刪除備份</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpopinfo_saved_to_1_memory_card">
      <source>Saved to %1 Memory card</source>
      <translation variants="no">已儲存至%[15]1記憶卡</translation>
    </message>
    <message numerus="no" id="txt_fmgr_info_folder_exsit">
      <source>This folder already contains a folder named 1%.Would you like to save this file as 2%？</source>
      <translation variants="no">"%[99]1"已存在。是否另存為"%[99]2"？</translation>
    </message>
    <message numerus="no" id="txt_fmgr_subhead_copy_to">
      <source>Copy to</source>
      <translation variants="yes">
        <lengthvariant priority="1">複製至：</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_fmgr_info_l1_kb">
      <source>%Ln kB</source>
      <translation>
        <numerusform plurality="a">zh_tw #%Ln kB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_button_restore">
      <source>Restore</source>
      <translation variants="yes">
        <lengthvariant priority="1">還原</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_subhead_save_to">
      <source>Save to</source>
      <translation variants="yes">
        <lengthvariant priority="1">儲存至：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_search_from">
      <source>Search from</source>
      <translation variants="no">從以下項目搜尋：</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_1_mass_storage">
      <source>%1 Mass storage</source>
      <translation variants="no">%[99]1大型記憶體</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpophead_passwords_do_not_match">
      <source>Passwords do not match</source>
      <translation variants="no">密碼不符。</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_bookmarks">
      <source>Bookmarks</source>
      <translation variants="yes">
        <lengthvariant priority="1">書籤</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpopinfo_saved_to_1_2">
      <source>Saved to %1 %2</source>
      <translation variants="no">已儲存至%[09]1%2</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_new_folder">
      <source>New folder</source>
      <translation variants="yes">
        <lengthvariant priority="1">新增資料夾</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_button_start_bakcup">
      <source>Start bakcup</source>
      <translation variants="yes">
        <lengthvariant priority="1">開始備份</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_info_backup_corrupted">
      <source>Unable to perform backup. %1 corrupted</source>
      <translation variants="no">無法執行備份。%[99]1已損毀。</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_backup">
      <source>Backup</source>
      <translation variants="yes">
        <lengthvariant priority="1">備份</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_new_folder">
      <source>New folder</source>
      <translation variants="no">新增資料夾</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_time">
      <source>Time:</source>
      <translation variants="yes">
        <lengthvariant priority="1">時間：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpophead_wrong_password">
      <source>Wrong password</source>
      <translation variants="no">密碼錯誤。</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_messages">
      <source>Messages</source>
      <translation variants="yes">
        <lengthvariant priority="1">訊息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_sort_by_name">
      <source>Sort by name</source>
      <translation variants="no">依名稱排序</translation>
    </message>
    <message numerus="yes" id="txt_fmgr_info_l1_mb">
      <source>%Ln MB</source>
      <translation>
        <numerusform plurality="a">zh_tw #%Ln MB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_file_manager">
      <source>File Manager</source>
      <translation variants="no">zh_tw #File manager</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_no_previous_backups_created">
      <source>No previous backups created</source>
      <translation variants="yes">
        <lengthvariant priority="1">沒有先前的備份可使用</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_delete_backup">
      <source>Delete backup</source>
      <translation variants="no">刪除備份</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_weekday">
      <source>Weekday</source>
      <translation variants="no">工作天</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_destination">
      <source>Backup destination</source>
      <translation variants="no">備份目的地</translation>
    </message>
    <message numerus="no" id="txt_fmgr_button_paste">
      <source>Paste</source>
      <translation variants="yes">
        <lengthvariant priority="1">貼上</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_settings">
      <source>Settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_scheduling_val_not_schedu">
      <source>Not scheduled</source>
      <translation variants="no">不要排程</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_sort_by_size">
      <source>Sort by size</source>
      <translation variants="no">依大小排序</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_1_memory_card">
      <source>%1 Memory card</source>
      <translation variants="no">%[99]1記憶卡</translation>
    </message>
    <message numerus="no" id="txt_fmgr_info_file_exsit">
      <source>This folder already contains a file named 1%.Would you like to save this file as 2%？</source>
      <translation variants="no">"%[99]1"已存在。是否另存為"%[99]2"？</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_messages">
      <source>Messages</source>
      <translation variants="no">訊息</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_destination_val_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[06]1%2</translation>
    </message>
    <message numerus="no" id="txt_file_info_other_functions_are_unavailable_duri">
      <source>Other functions are unavailable during the backup</source>
      <translation variants="no">正在復原資料。其他應用程式無法使用。</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_preparing_for_backup">
      <source>Preparing for backup</source>
      <translation variants="no">正在準備備份</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_reenter_memory_card_password">
      <source>Re-enter new memory card password</source>
      <translation variants="yes">
        <lengthvariant priority="1">確認新記憶卡密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_file_manager">
      <source>File Manager</source>
      <translation variants="no">檔案管理</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">連絡人</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_restore_data">
      <source>Restore data</source>
      <translation variants="no">還原資料</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">書籤</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_scheduling_val_weekly">
      <source>Weekly</source>
      <translation variants="no">每週</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_enter_new_memory_card_password">
      <source>Enter new memory card password</source>
      <translation variants="yes">
        <lengthvariant priority="1">輸入新記憶卡密碼：</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_fmgr_info_l1_gb">
      <source>%Ln GB</source>
      <translation>
        <numerusform plurality="a">zh_tw #%Ln GB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_calendar">
      <source>Calendar</source>
      <translation variants="no">行事曆</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_user_files">
      <source>User files</source>
      <translation variants="no">使用者檔案</translation>
    </message>
    <message numerus="yes" id="txt_fmgr_dblist_val_size_l1_kb">
      <source>%Ln kB</source>
      <translation>
        <numerusform plurality="a">zh_tw #%Ln kB</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_delete_backups">
      <source>Delete backups</source>
      <translation variants="no">zh_tw #Delete backup</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_val_free_size">
      <source>Free: %2</source>
      <translation variants="no">可用：%2</translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_start_bakcup">
      <source>Start bakcup</source>
      <translation variants="no">開始備份</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents">
      <source>Backup contents</source>
      <translation variants="no">備份內容</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_scheduling_val_never">
      <source>Never</source>
      <translation variants="no">永不</translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_sort_by_type">
      <source>Sort by type</source>
      <translation variants="no">依類型排序</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_size">
      <source>Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">大小：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">行事曆</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_name">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">名稱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_user_files">
      <source>User files</source>
      <translation variants="yes">
        <lengthvariant priority="1">使用者檔案</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_destination_val_1_memory">
      <source>%1 Memory card</source>
      <translation variants="no">%[08]1記憶卡</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_1_device_memory">
      <source>%1 Device memory</source>
      <translation variants="no">%[99]1裝置記憶體</translation>
    </message>
    <message numerus="no" id="txt_fmgr_menu_rename">
      <source>Rename</source>
      <translation variants="no">重新命名</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_memory_details">
      <source>Memory details:</source>
      <translation variants="yes">
        <lengthvariant priority="1">記憶體詳細資訊：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_restore">
      <source>Restore</source>
      <translation variants="no">還原</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[07]1 %2</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dblist_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[12]1 %2</translation>
    </message>
    <message numerus="no" id="txt_fmgr_dpopinfo_saved_to_1_device_memory">
      <source>Saved to %1 Device memory</source>
      <translation variants="no">已儲存至%[13]1裝置記憶體</translation>
    </message>
    <message numerus="no" id="txt_fmgr_opt_sort">
      <source>Sort</source>
      <translation variants="no">排序</translation>
    </message>
    <message numerus="no" id="txt_tws_caption_file_manager">
      <source>File Manager</source>
      <translation variants="yes">
        <lengthvariant priority="1">檔案管理</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_fmgr_info_l1_b">
      <source>%Ln B</source>
      <translation>
        <numerusform plurality="a">zh_tw #%Ln B</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_new_name_folder">
      <source>Rename:</source>
      <translation variants="yes">
        <lengthvariant priority="1">重新命名：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_setlabel_backup_contents_val_all">
      <source>All</source>
      <translation variants="no">全部</translation>
    </message>
    <message numerus="no" id="txt_fmgr_list_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[99]1%2</translation>
    </message>
    <message numerus="yes" id="txt_fmgr_dblist_val_size_l1_b">
      <source>%Ln B</source>
      <translation>
        <numerusform plurality="a">zh_tw #%Ln B</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_formlabel_time">
      <source>Time</source>
      <translation variants="no">時間</translation>
    </message>
    <message numerus="no" id="txt_fmgr_title_restore">
      <source>Restore</source>
      <translation variants="yes">
        <lengthvariant priority="1">還原</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_fmgr_subhead_copying_1">
      <source>Copying %1</source>
      <translation variants="no">正在複製"%[99]1"</translation>
    </message>
  </context>
</TS>