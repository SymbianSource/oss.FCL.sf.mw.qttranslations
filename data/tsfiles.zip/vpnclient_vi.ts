<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_incorrect_password">
      <source>Incorrect password</source>
      <translation variants="no">Mật khẩu sai.</translation>
    </message>
    <message numerus="no" id="txt_occ_info_delete_vpn_policy">
      <source>Delete VPN policy '%1'?</source>
      <translation variants="no">Xóa chính sách VPN?
%1</translation>
    </message>
    <message numerus="no" id="txt_occ_list_tap_on_a_policy_to_set_a_default">
      <source>Tap on a policy to set a default.</source>
      <translation variants="no">Chạm vào chính sách để đặt làm chính sách mặc định:</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_installing_vpn_policy">
      <source>Installing VPN policy</source>
      <translation variants="no">Đang cài đặt chính sách VPN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn_val_always">
      <source>Always</source>
      <translation variants="no">Luôn bật</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_pkcs12_password">
      <source>PKCS#12 password:</source>
      <translation variants="no">Mật khẩu PKCS#12:</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_service_not_available">
      <source>Policy server not available</source>
      <translation variants="no">Máy chủ chính sách ko có sẵn.</translation>
    </message>
    <message numerus="no" id="txt_occ_button_download">
      <source>Download</source>
      <translation variants="no">Tải về</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_policy_fi">
      <source>Policy installation failed. Policy file error.</source>
      <translation variants="no">Không cài đặt chính sách được. Tập tin chính sách bị lỗi.</translation>
    </message>
    <message numerus="no" id="txt_occ_list_no_vpn_policies_installed">
      <source>No VPN policies installed.</source>
      <translation variants="no">Chưa cài đặt chính sách VPN</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_vpn">
      <source>VPN</source>
      <translation variants="yes">
        <lengthvariant priority="1">VPN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_password">
      <source>Password:</source>
      <translation variants="no">Mật khẩu:</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_vpn_user_name">
      <source>VPN user name:</source>
      <translation variants="no">Tên người dùng VPN:</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed">
      <source>Policy installation failed</source>
      <translation variants="no">Không cài đặt chính sách được</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_download_failed">
      <source>Download failed</source>
      <translation variants="no">Không tải về được.</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_securid_pin">
      <source>SecurID PIN:</source>
      <translation variants="no">vi #SecurID PIN:</translation>
    </message>
    <message numerus="no" id="txt_vpn_button_disconnect_vpn">
      <source>Disconnect VPN</source>
      <translation variants="no">Ngắt kết nối VPN</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_vpn_policy_download">
      <source>VPN policy download</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tải về chính sách VPN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_ap">
      <source>Policy installation failed. Unable to create VPN access point.</source>
      <translation variants="no">Không cài đặt chính sách được. Không thể tạo điểm truy cập VPN.</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn_val_when_needed">
      <source>When needed</source>
      <translation variants="no">Khi cần</translation>
    </message>
    <message numerus="no" id="txt_occ_info_downloading_vpn_policy">
      <source>Downloading VPN policy</source>
      <translation variants="no">Đang tải về chính sách VPN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn">
      <source>VPN</source>
      <translation variants="no">VPN</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_delete_vp">
      <source>Policy installation failed. Delete VPN policies from settings and try again.</source>
      <translation variants="no">Không cài đặt chính sách được. Trước tiên xóa chính sách, sau đó thử lại.</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_cert">
      <source>Policy installation failed. Unable to store certificates.</source>
      <translation variants="no">Không cài đặt chính sách được. Không thể lưu trữ chứng chỉ.</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_policy_server_address">
      <source>Policy server address</source>
      <translation variants="no">Địa chỉ máy chủ chính sách:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_vpn_connection">
      <source>VPN connection</source>
      <translation variants="no">Kết nối VPN</translation>
    </message>
  </context>
</TS>