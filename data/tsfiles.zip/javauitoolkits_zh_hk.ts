<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_button_cmd_ok_1">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">確定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_options_2">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">選項</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_alert_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">確定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_cancel">
      <source>Cancel</source>
      <translation variants="no">取消</translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_cancel">
      <source>Cancel</source>
      <translation variants="no">取消</translation>
    </message>
    <message numerus="no" id="txt_java_title_select_bookmark">
      <source>Select bookmark</source>
      <translation variants="no">選擇書籤</translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_stop">
      <source>Stop</source>
      <translation variants="no">停止</translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_ok">
      <source>Ok</source>
      <translation variants="no">確定</translation>
    </message>
    <message numerus="no" id="txt_java_menu_alert_dismiss">
      <source>Ok</source>
      <translation variants="no">確定</translation>
    </message>
    <message numerus="no" id="txt_java_button_options_1">
      <source>Options</source>
      <translation variants="yes">
        <lengthvariant priority="1">選項</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_info_no_data">
      <source>No data</source>
      <translation variants="no">(沒有數據)</translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_ok">
      <source>Ok</source>
      <translation variants="no">確定</translation>
    </message>
    <message numerus="no" id="txt_java_menu_screen_cmd_select">
      <source>Select</source>
      <translation variants="no">選擇</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_close_2">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">關閉</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_close_1">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">關閉</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_back">
      <source>Back</source>
      <translation variants="no">返回</translation>
    </message>
    <message numerus="no" id="txt_java_opt_screen_cmd_select">
      <source>Select</source>
      <translation variants="no">選擇</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_cancel_1">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_cancel_2">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_opt_fetch">
      <source>Fetch</source>
      <translation variants="no">擷取</translation>
    </message>
    <message numerus="no" id="txt_java_button_screen_cmd_select_1">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_item_cmd_select">
      <source>Select</source>
      <translation variants="no">選擇</translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_back">
      <source>Back</source>
      <translation variants="no">返回</translation>
    </message>
    <message numerus="no" id="txt_java_button_item_cmd_select_2">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_screen_cmd_select_2">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_close">
      <source>Close</source>
      <translation variants="no">關閉</translation>
    </message>
    <message numerus="no" id="txt_java_menu_implicit_list_select">
      <source>Select</source>
      <translation variants="no">選擇</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_back_1">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">返回</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_menu_cmd_help">
      <source>Help</source>
      <translation variants="no">說明</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_help_2">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">說明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_stop_2">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">停止</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_item_cmd_select_1">
      <source>Select</source>
      <translation variants="yes">
        <lengthvariant priority="1">選擇</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_stop">
      <source>Stop</source>
      <translation variants="no">停止</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_ok_2">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">確定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_help_1">
      <source>Help</source>
      <translation variants="yes">
        <lengthvariant priority="1">說明</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_help">
      <source>Help</source>
      <translation variants="no">說明</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_stop_1">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">停止</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_opt_cmd_close">
      <source>Close</source>
      <translation variants="no">關閉</translation>
    </message>
    <message numerus="no" id="txt_java_opt_item_cmd_select">
      <source>Select</source>
      <translation variants="no">選擇</translation>
    </message>
    <message numerus="no" id="txt_java_button_cmd_back_2">
      <source>Back</source>
      <translation variants="yes">
        <lengthvariant priority="1">返回</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_info_alert">
      <source>Alert</source>
      <translation variants="no">提示</translation>
    </message>
    <message numerus="no" id="txt_java_info_alert_confirmation">
      <source>Confirmation</source>
      <translation variants="no">確認</translation>
    </message>
    <message numerus="no" id="txt_java_info_alert_error">
      <source>Error</source>
      <translation variants="no">錯誤</translation>
    </message>
    <message numerus="no" id="txt_java_info_alert_information">
      <source>Information</source>
      <translation variants="no">資訊</translation>
    </message>
    <message numerus="no" id="txt_java_info_alert_warning">
      <source>Warning</source>
      <translation variants="no">警告</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_backspace">
      <source>Qwerty: backspace</source>
      <translation variants="no">QWERTY：退格鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_clear">
      <source>Clear key</source>
      <translation variants="no">清除</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_delete">
      <source>Qwerty: delete</source>
      <translation variants="no">QWERTY：刪除鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_down">
      <source>Move down (arrow down)</source>
      <translation variants="no">向下移動(向下箭頭)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_end">
      <source>End key</source>
      <translation variants="no">結束</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_enter">
      <source>Qwerty: Enter key</source>
      <translation variants="no">QWERTY：Enter鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_escape">
      <source>Qwerty: escape</source>
      <translation variants="no">QWERTY：Esc鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_hash_key">
      <source>ITU-T: #</source>
      <translation variants="no">ITU-T：#鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_left">
      <source>Move left (arrow left)</source>
      <translation variants="no">向左移動(向左箭頭)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_lsk">
      <source>SK1, softkey 1, positive softkey</source>
      <translation variants="no">功能鍵1，確定功能鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_modifier">
      <source>All modifier keys (e.g. shift, Fn)</source>
      <translation variants="no">修改鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_right">
      <source>Move right (arrow right)</source>
      <translation variants="no">向右移動(向右箭頭)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_rsk">
      <source>SK2, softkey 2, negative softkey</source>
      <translation variants="no">功能鍵2，取消功能鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_selection_key">
      <source>Selection key (Select)</source>
      <translation variants="no">選擇</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_send">
      <source>Send key</source>
      <translation variants="no">傳送</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_space">
      <source>Qwerty: space</source>
      <translation variants="no">QWERTY：空白鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_star_key">
      <source>ITU-T: *</source>
      <translation variants="no">ITU-T：*鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_tab">
      <source>Qwerty: tab</source>
      <translation variants="no">QWERTY：Tab鍵</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_up">
      <source>Move up (arrow up)</source>
      <translation variants="no">向上移動(向上箭頭)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_voice">
      <source>Voice key</source>
      <translation variants="no">語音</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_next">
      <source>Media key: next (forward)</source>
      <translation variants="no">媒體：下一首(快轉)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_play">
      <source>Media key: play (pause)</source>
      <translation variants="no">媒體：播放(暫停)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_previous">
      <source>Media key: previous (rewind)</source>
      <translation variants="no">媒體：上一首(倒轉)</translation>
    </message>
    <message numerus="no" id="txt_java_canvas_media_key_stop">
      <source>Media key: stop</source>
      <translation variants="no">媒體：停止</translation>
    </message>
    <message numerus="no" id="txt_java_button_fetch">
      <source>Fetch</source>
      <translation variants="yes">
        <lengthvariant priority="1">擷取</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_info_alert_alarm">
      <source>Alarm</source>
      <translation variants="no">響鬧</translation>
    </message>
    <message numerus="no" id="txt_java_menu_call">
      <source>Call</source>
      <translation variants="no">撥號</translation>
    </message>
    <message numerus="no" id="txt_java_menu_fetch">
      <source>Fetch</source>
      <translation variants="no">擷取</translation>
    </message>
    <message numerus="no" id="txt_java_opt_call">
      <source>Call</source>
      <translation variants="no">撥號</translation>
    </message>
    <message numerus="no" id="txt_java_button_call">
      <source>Call</source>
      <translation variants="yes">
        <lengthvariant priority="1">撥號</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_java_canvas_key_apps">
      <source>Applications key</source>
      <translation variants="no">應用程式</translation>
    </message>
  </context>
</TS>