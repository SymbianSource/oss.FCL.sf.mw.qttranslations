<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phone_other_call_ln">
      <source>Call %L1</source>
      <translation variants="no">uk #Call %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_button_drop">
      <source>Drop</source>
      <translation variants="no">uk #Drop</translation>
    </message>
    <message numerus="no" id="txt_phone_other_attempting">
      <source>Attempting</source>
      <translation variants="no">uk #Attempting</translation>
    </message>
    <message numerus="no" id="txt_phone_other_on_hold">
      <source>On hold</source>
      <translation variants="no">uk #On hold</translation>
    </message>
    <message numerus="no" id="txt_phone_other_incoming_call">
      <source>Incoming call</source>
      <translation variants="no">uk #Incoming call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_swap">
      <source>Swap</source>
      <translation variants="no">uk #Swap</translation>
    </message>
    <message numerus="no" id="txt_phone_other_calling">
      <source>Calling</source>
      <translation variants="no">uk #Calling</translation>
    </message>
    <message numerus="no" id="txt_phone_other_waiting">
      <source>Waiting</source>
      <translation variants="no">uk #Waiting</translation>
    </message>
    <message numerus="no" id="txt_phone_other_swipe_down_to_answer">
      <source>Swipe down to answer</source>
      <translation variants="no">uk #Swipe down to answer</translation>
    </message>
    <message numerus="no" id="txt_long_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">Телефон</translation>
    </message>
    <message numerus="no" id="txt_phone_button_replace_active_call">
      <source>Replace active call</source>
      <translation variants="no">uk #Replace active call</translation>
    </message>
    <message numerus="no" id="txt_phone_other_private_number">
      <source>Private number</source>
      <translation variants="no">uk #Private number</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_transfer">
      <source>Transfer</source>
      <translation variants="no">Перевести</translation>
    </message>
    <message numerus="no" id="txt_phone_title_telephone">
      <source>Telephone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Телефон</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_opt_share_video">
      <source>Share video</source>
      <translation variants="no">Обмін відео</translation>
    </message>
    <message numerus="no" id="txt_phone_other_conference_call">
      <source>Conference call</source>
      <translation variants="no">uk #Conference call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_end_call">
      <source>End call</source>
      <translation variants="no">uk #End call</translation>
    </message>
    <message numerus="no" id="txt_phone_button_hold">
      <source>Hold</source>
      <translation variants="no">uk #Hold</translation>
    </message>
    <message numerus="no" id="txt_phone_button_send_message">
      <source>Send message</source>
      <translation variants="yes">
        <lengthvariant priority="1">Надіслати повідомлення</lengthvariant>
        <lengthvariant priority="2">Надіслати по­відомлення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_button_join">
      <source>Join</source>
      <translation variants="no">uk #Join</translation>
    </message>
    <message numerus="no" id="txt_phone_other_disconnected">
      <source>Disconnected</source>
      <translation variants="no">uk #Disconnected</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_ended">
      <source>Call ended</source>
      <translation variants="no">Дзвінок роз’єднано</translation>
    </message>
    <message numerus="no" id="txt_phone_info_called_number_has_barred_incoming">
      <source>Called number has barred incoming calls</source>
      <translation variants="no">Неможливо здійснити відеодзвінок. Вхідні дзвінки заборонені в іншому телефоні.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_use">
      <source>Number not in use</source>
      <translation variants="no">Номер не використовується</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_own_number_sending">
      <source>Check own number sending</source>
      <translation variants="no">Перевірте надсилання даних абонента</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_terminated">
      <source>Call Terminated</source>
      <translation variants="no">Резюме дзвінка</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_answer">
      <source>No answer</source>
      <translation variants="no">Немає відповіді</translation>
    </message>
    <message numerus="no" id="txt_phone_other_call">
      <source>Call</source>
      <translation variants="no">uk #Call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_send_string">
      <source>Send string:\n%L1</source>
      <translation variants="no">Надіслати DTMF: %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_barred_in_closed_group">
      <source>Call barred in closed group</source>
      <translation variants="no">Дзвінки за межі закритої групи користувачів заборонені</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending_file_to_1">
      <source>Sending file to %L1</source>
      <translation variants="no">Триває надсилання повідомлення до %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_barrings">
      <source>Note: you have active barrings</source>
      <translation variants="no">Увага: увімкнено заборону дзвінків</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_calls_only">
      <source>Emergency calls only</source>
      <translation variants="no">Лише екстрені дзвінки</translation>
    </message>
    <message numerus="no" id="txt_phone_info_network_busy">
      <source>Network busy</source>
      <translation variants="no">Мережа зайнята</translation>
    </message>
    <message numerus="no" id="txt_phone_info_unable_to_make_video_call_not_supp">
      <source>Unable to make video call. Not supported by other phone or network.</source>
      <translation variants="no">Неможливо здійснити відеодзвінок. Не підтримується іншим телефоном або мережею.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_transfer_in_progress">
      <source>Transfer in progress</source>
      <translation variants="no">Триває переведення</translation>
    </message>
    <message numerus="no" id="txt_phone_info_could_not_send_own_number">
      <source>Could not send own number</source>
      <translation variants="no">Не вдалося надіслати ваші дані абонента</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_rf_loopback_enabled">
      <source>Bluetooth RF loopback enabled</source>
      <translation variants="no">Тестовий режим Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_phone_info_closed_group_unknown">
      <source>Closed group unknown</source>
      <translation variants="no">Невідома закрита група користувачів</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected">
      <source>Connected</source>
      <translation variants="no">З’єднано</translation>
    </message>
    <message numerus="no" id="txt_phone_info_wlan_mac_address_1">
      <source>WLAN MAC address: %L1</source>
      <translation variants="no">MAC-адреса WLAN: %1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_select_closed_group">
      <source>Select closed group</source>
      <translation variants="no">Виберіть закриту групу користувачів</translation>
    </message>
    <message numerus="no" id="txt_phone_info_time">
      <source>Time</source>
      <translation variants="no">Тривалість:</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_you_have_active_diverts">
      <source>Note:  you have active diverts</source>
      <translation variants="no">Увага: увімкнено переадресації</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_not_allowed_during_resto">
      <source>Video call not allowed during restore</source>
      <translation variants="no">Неможливо здійснити відеодзвінок під час відновлення</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_network_services">
      <source>Check network services</source>
      <translation variants="no">Перевірте послуги мережі</translation>
    </message>
    <message numerus="no" id="txt_phone_info_transferred">
      <source>Transferred</source>
      <translation variants="no">Переведено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_sending">
      <source>Sending\n%L1</source>
      <translation variants="no">Триває надсилання
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_other_remote_sim">
      <source>Remote SIM</source>
      <translation variants="no">uk #Remote SIM</translation>
    </message>
    <message numerus="no" id="txt_phone_info_videocall_only_possible_under_3g">
      <source>Videocall only possible under 3G coverage</source>
      <translation variants="no">Відеодзвінки не підтримуються поза межами мережі 3G</translation>
    </message>
    <message numerus="no" id="txt_phone_info_invalid_phone_number">
      <source>Invalid phone number</source>
      <translation variants="no">Недійсний номер телефону</translation>
    </message>
    <message numerus="no" id="txt_phone_info_life_timer">
      <source>Life timer\n%L1</source>
      <translation variants="no">Загальний лічильник:
%L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_serial_no">
      <source>Serial No.\n%L1</source>
      <translation variants="no">Серійний номер:
%1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_rejected">
      <source>Call rejected</source>
      <translation variants="no">Дзвінок відхилено</translation>
    </message>
    <message numerus="no" id="txt_phone_info_closed_group_1_in_use">
      <source>Closed group %L1 in use</source>
      <translation variants="no">Використовується закрита група користувачів %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_number_stored_in_location_1">
      <source>No number stored in location %L1</source>
      <translation variants="no">На SIM-картці немає збереженого номера в позиції %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_not_allowed_fixed_dialling">
      <source>Call not allowed, fixed dialling active</source>
      <translation variants="no">Дзвінок не дозволено. Увімкнено фіксований набір.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_check_closed_user_group">
      <source>Check closed user group</source>
      <translation variants="no">Перевірте закриту групу користувачів</translation>
    </message>
    <message numerus="no" id="txt_phone_info_call_in_progress">
      <source>Call in progress</source>
      <translation variants="no">Триває дзвінок</translation>
    </message>
    <message numerus="no" id="txt_phone_info_emergency_call_failed">
      <source>Emergency call failed</source>
      <translation variants="no">Помилка з’єднання екстреного дзвінка</translation>
    </message>
    <message numerus="no" id="txt_phone_info_connected_to_1">
      <source>Connected to %L1</source>
      <translation variants="no">З’єднано з %L1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_didnt_succeed_to_called">
      <source>Video call didn't succeed to called end</source>
      <translation variants="no">Неможливо здійснити відеодзвінок. Не підтримується іншим телефоном або мережею.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_conference_call_active">
      <source>Conference call active</source>
      <translation variants="no">Конференц-дзвінок активний</translation>
    </message>
    <message numerus="no" id="txt_phone_info_no_network_support_for_video_call">
      <source>No network support for video call</source>
      <translation variants="no">Відеодзвінок не підтримується мережею</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_no_network_coverage">
      <source>No network coverage</source>
      <translation variants="no">uk #No network coverage</translation>
    </message>
    <message numerus="no" id="txt_phone_button_silence">
      <source>Silence</source>
      <translation variants="no">uk #Silence</translation>
    </message>
    <message numerus="no" id="txt_phone_opt_end_all_calls">
      <source>End all calls</source>
      <translation variants="no">Завершити всі дзвінки</translation>
    </message>
    <message numerus="no" id="txt_phone_title_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">Офлайн</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phone_info_phone_switched_off_or_out_of_3g">
      <source>Phone switched off or out of 3G coverage</source>
      <translation variants="no">Неможливо здійснити відеодзвінок. Інший телефон вимкнено або поза межами мережі 3G.</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_rf_loopback_disabled">
      <source>Bluetooth RF loopback disabled</source>
      <translation variants="no">Тестовий режим Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_phone_info_error_in_connection">
      <source>Error in connection</source>
      <translation variants="no">Помилка з’єднання</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_busy">
      <source>Number busy</source>
      <translation variants="no">Номер зайнятий</translation>
    </message>
    <message numerus="no" id="txt_short_caption_telephone">
      <source>Telephone</source>
      <translation variants="no">uk #Telephone</translation>
    </message>
    <message numerus="no" id="txt_phone_info_end_gprs_connection_first">
      <source>End GPRS connection first</source>
      <translation variants="no">Спочатку закрийте з’єднання пакетних даних</translation>
    </message>
    <message numerus="no" id="txt_phone_other_emergency_call">
      <source>Emergency call</source>
      <translation variants="no">uk #Emergency call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_video_call_setup_failed">
      <source>Video call setup failed</source>
      <translation variants="no">Неможливо здійснити відеодзвінок</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_barred">
      <source>Number barred</source>
      <translation variants="no">Номер заборонено</translation>
    </message>
    <message numerus="no" id="txt_phone_button_private">
      <source>Private</source>
      <translation variants="no">uk #Private</translation>
    </message>
    <message numerus="no" id="txt_phone_button_unlock">
      <source>Unlock</source>
      <translation variants="no">uk #Unlock</translation>
    </message>
    <message numerus="no" id="txt_phone_button_unhold">
      <source>Unhold</source>
      <translation variants="no">uk #Unhold</translation>
    </message>
    <message numerus="no" id="txt_phone_other_diverted_call">
      <source>Diverted call</source>
      <translation variants="no">uk #Diverted call</translation>
    </message>
    <message numerus="no" id="txt_phone_info_number_not_in_closed_group">
      <source>Number not in closed group</source>
      <translation variants="no">Номер не належить закритій групі користувачів</translation>
    </message>
    <message numerus="no" id="txt_phone_info_service_not_possible_in_this_group">
      <source>Service not possible in this group</source>
      <translation variants="no">Послугою неможливо користуватися в цій групі</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_note_all_incoming_calls_diver">
      <source>Note:  all incoming calls diverted</source>
      <translation variants="no">Увага: усі вхідні дзвінки переадресовуються</translation>
    </message>
    <message numerus="no" id="txt_phone_info_tty_call_active_volume_control_not">
      <source>TTY call active. Volume control not available</source>
      <translation variants="no">Регулювання гучності недоступне під час користування текстовим телефоном</translation>
    </message>
    <message numerus="no" id="txt_phone_info_bluetooth_device_address_1">
      <source>Bluetooth device address: %L1</source>
      <translation variants="no">Адреса пристрою Bluetooth: %1</translation>
    </message>
    <message numerus="no" id="txt_phone_info_activate_own_number_sending">
      <source>Activate own number sending</source>
      <translation variants="no">Увімкніть надсилання даних абонента</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_not_allowed">
      <source>Not allowed</source>
      <translation variants="no">uk #Not allowed</translation>
    </message>
    <message numerus="no" id="txt_phone_dpopinfo_diverting">
      <source>Diverting</source>
      <translation variants="no">Триває переадресація</translation>
    </message>
  </context>
</TS>