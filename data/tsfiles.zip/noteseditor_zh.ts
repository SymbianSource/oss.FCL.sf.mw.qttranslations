<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_notes_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">放弃所做更改</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="no">加至收藏夹</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_note">
      <source>Note</source>
      <translation variants="no">备忘</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="no">更改为待办事项</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_new_note">
      <source>New note</source>
      <translation variants="no">新建备忘</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">删除待办事项？</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">从收藏夹删除</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_saved">
      <source>Note saved</source>
      <translation variants="no">备忘已存</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_note">
      <source>Delete note?</source>
      <translation variants="no">删除备忘？</translation>
    </message>
  </context>
</TS>