<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_friend_widget_info_you_can_not_use_this_widge">
      <source>You can not use this  widget, because your phonebook is empty. Open Phonebook to add contacts?</source>
      <translation variants="no">zh_hk #You can not use this  widget, because your phonebook is empty. Open Phonebook to add contacts?</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget_val_quickly">
      <source>Quickly communicate with a contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Quickly communicate with a contact</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_friend_widget_title_select_contact">
      <source>Select contact:</source>
      <translation variants="no">zh_hk #Select contact:</translation>
    </message>
    <message numerus="no" id="txt_long_caption_friend">
      <source>Contact widget</source>
      <translation variants="no">zh_hk #Contact widget</translation>
    </message>
    <message numerus="no" id="txt_short_caption_friend">
      <source>Contact widget</source>
      <translation variants="no">zh_hk #Contact widget</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget">
      <source>Contact widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Contact widget</lengthvariant>
      </translation>
    </message>
  </context>
</TS>