<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_ts_title_task_switcher">
      <source>Recent applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ứng dụng gần đây</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ts_label_active">
      <source>Active</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Active</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_ts_info_no_recent_applications">
      <source>No recent applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #(no recent applications)</lengthvariant>
      </translation>
    </message>
  </context>
</TS>