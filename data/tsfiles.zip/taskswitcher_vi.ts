<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_ts_info_no_recent_applications">
      <source>No recent applications</source>
      <translation variants="no">vi #(no recent applications)</translation>
    </message>
    <message numerus="no" id="txt_ts_label_active">
      <source>Active</source>
      <translation variants="no">vi #Active</translation>
    </message>
    <message numerus="no" id="txt_ts_title_task_switcher">
      <source>Recent applications</source>
      <translation variants="no">vi #Recent applications</translation>
    </message>
  </context>
</TS>