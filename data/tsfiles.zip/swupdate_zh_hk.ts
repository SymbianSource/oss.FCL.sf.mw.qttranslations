<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_software_button_decline">
      <source>Decline</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Decline</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_later">
      <source>Later</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Later</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_update_results">
      <source>Update results</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Update results</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_recommended_kb">
      <source>Recommended (%1L kB)</source>
      <translation variants="no">zh_hk #Recommended (%1L kB)</translation>
    </message>
    <message numerus="no" id="txt_software_info_allow_automatic_update_checks">
      <source>Allow automatic update checks?</source>
      <translation variants="no">zh_hk #Allow automatic update checks?</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_installing_1">
      <source>Installing %1</source>
      <translation variants="no">zh_hk #Installing %1</translation>
    </message>
    <message numerus="no" id="txt_software_update_list_software_update">
      <source>Software update</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Software update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_title_dependencies">
      <source>Dependencies</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Dependencies</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_failed">
      <source>Failed</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Failed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_update_1_needs_this_update_fo">
      <source>Update "%1" needs this update for working</source>
      <translation variants="no">zh_hk #Update "%1" needs this update for working</translation>
    </message>
    <message numerus="no" id="txt_software_info_insufficient_memory_free_some_m">
      <source>Insufficient memory. Free some memory and try again.</source>
      <translation variants="no">zh_hk #Insufficient memory. Free some memory and try again.</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_required_kb">
      <source>Required (%1L kB)</source>
      <translation variants="no">zh_hk #Required (%1L kB)</translation>
    </message>
    <message numerus="no" id="txt_software_info_please_note_that_this_applicatio">
      <source>Please note that this application allows you to download, subscribe to, purchase and/or use applications and services provided by Nokia and its affiliates, or third parties. Before using any application or service, please read the applicable terms of use. You acknowledge and agree that Nokia has no control over any third party applications and services, and that Nokia will not assume any liability or responsibility for the availability or any other aspects thereof. Use of the application may involve data transfer charges. For further information, contact your service provider.Nokia does not collect personally identifiable information in connection with your use of the Software update. However, by using this application you acknowledge and agree that certain technical information, such as the type and version of the client and device software, unique identifiers of the client and the device, language, device model, amount of free storage on your device, information about your network operator, country and area as well

as application traffic and usage information is collected. Such information is processed only in order to

process and fulfill your order and to provide you with software updates that are suitable for your

device and to prevent fraud. Nokia deletes the above technical information after the transaction has been completed. Nokia does not use the collected technical information to identify you personally. Nokia may, however, create anonymous aggregate statistics based on such technical information. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THE APPLICATION IS PROVIDED ON AN \"AS IS\" BASIS WITHOUT WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, AND IN NO EVENT SHALL NOKIA, ITS EMPLOYEES, AFFILIATES OR LICENSORS BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, INCIDENTAL, PUNITIVE, OR CONSEQUENTIAL DAMAGE, COST OR EXPENSES

THAT MAY ARISE AS A RESULT OF THE USAGE OF THIS APPLICATION. Nothing herein shall prejudice the statutory rights of any party</source>
      <translation variants="no">zh_hk #Please note that this application allows you to download, subscribe to, purchase and/or use applications and services provided by Nokia and its affiliates, or third parties. Before using any application or service, please read the applicable terms of use. You acknowledge and agree that Nokia has no control over any third party applications and services, and that Nokia will not assume any liability or responsibility for the availability or any other aspects thereof. Use of the application may involve data transfer charges. For further information, contact your service provider.Nokia does not collect personally identifiable information in connection with your use of the Software update. However, by using this application you acknowledge and agree that certain technical information, such as the type and version of the client and device software, unique identifiers of the client and the device, language, device model, amount of free storage on your device, information about your network operator, country and area as well

as application traffic and usage information is collected. Such information is processed only in order to

process and fulfill your order and to provide you with software updates that are suitable for your

device and to prevent fraud. Nokia deletes the above technical information after the transaction has been completed. Nokia does not use the collected technical information to identify you personally. Nokia may, however, create anonymous aggregate statistics based on such technical information. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THE APPLICATION IS PROVIDED ON AN \"AS IS\" BASIS WITHOUT WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, AND IN NO EVENT SHALL NOKIA, ITS EMPLOYEES, AFFILIATES OR LICENSORS BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, INCIDENTAL, PUNITIVE, OR CONSEQUENTIAL DAMAGE, COST OR EXPENSES

THAT MAY ARISE AS A RESULT OF THE USAGE OF THIS APPLICATION. Nothing herein shall prejudice the statutory rights of any party</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_required_mb">
      <source>Required (%1L MB)</source>
      <translation variants="no">zh_hk #Required (%1L MB)</translation>
    </message>
    <message numerus="no" id="txt_software_title_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Details</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_val_on">
      <source>On</source>
      <translation variants="no">zh_hk #On</translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_successful">
      <source>%Ln updates successful</source>
      <translation>
        <numerusform plurality="a">zh_hk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_subhead_application_updates">
      <source>Application updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Application updates</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_name">
      <source>Name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Name:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_task_caption_software_update">
      <source>Software update</source>
      <translation variants="no">zh_hk #Software update</translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_update_available">
      <source>Update available</source>
      <translation variants="no">zh_hk #Update available</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_updates_available">
      <source>Updates available</source>
      <translation variants="no">zh_hk #Updates available</translation>
    </message>
    <message numerus="no" id="txt_software_opt_settings">
      <source>Settings</source>
      <translation variants="no">zh_hk #Settings</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_optional_kb">
      <source>Optional (%1L kB)</source>
      <translation variants="no">zh_hk #Optional (%1L kB)</translation>
    </message>
    <message numerus="no" id="txt_software_info_installing_1_1l_of_2l">
      <source>Installing 1% (%1L of %2L)</source>
      <translation variants="no">zh_hk #Installing 1% (%1L of %2L)</translation>
    </message>
    <message numerus="no" id="txt_software_info_please_use_your_pc_to_update_the">
      <source>Use your PC to update the device software ([version %L])  from address www.nokia.com/softwareupdate</source>
      <translation variants="no">zh_hk #Use your PC to update the device software ([version %L])  from address www.nokia.com/softwareupdate</translation>
    </message>
    <message numerus="no" id="txt_software_info_this_required_update_cannot_be_o">
      <source>This required update cannot be omitted.</source>
      <translation variants="no">zh_hk #This required update cannot be omitted.</translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_applications_are_up_to_date">
      <source>Applications are up to date</source>
      <translation variants="no">zh_hk #Applications are up to date</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_available">
      <source>Update available</source>
      <translation variants="no">zh_hk #Update available</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_device_software">
      <source>Device software</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Device software</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_failed">
      <source>%Ln updates failed</source>
      <translation>
        <numerusform plurality="a">zh_hk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_downloading_1">
      <source>Downloading %1</source>
      <translation variants="no">zh_hk #Downloading %1</translation>
    </message>
    <message numerus="no" id="txt_software_button_accept">
      <source>Accept</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Accept</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_subhead_selected_1l_2l_3l_kb">
      <source>Selected %1L/%2L (%3L kB)</source>
      <translation variants="no">zh_hk #Selected %1L/%2L (%3L kB)</translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">zh_hk #Off</translation>
    </message>
    <message numerus="yes" id="txt_software_info_ln_updates_cancelled">
      <source>%Ln updates cancelled</source>
      <translation>
        <numerusform plurality="a">zh_hk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_opt_cancel_update">
      <source>Cancel update</source>
      <translation variants="no">zh_hk #Cancel update</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_checking">
      <source>Update checking</source>
      <translation variants="no">zh_hk #Update checking</translation>
    </message>
    <message numerus="no" id="txt_software_title_disclaimer">
      <source>Disclaimer</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Disclaimer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_autocheck_for_updates">
      <source>Auto-check for updates</source>
      <translation variants="no">zh_hk #Auto-check for updates</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Description:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_opt_cancel">
      <source>Cancel</source>
      <translation variants="no">zh_hk #Cancel</translation>
    </message>
    <message numerus="no" id="txt_software_title_software_update">
      <source>Software update</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Software update</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_refreshing_updates_list">
      <source>Refreshing updates list</source>
      <translation variants="no">zh_hk #Refreshing updates list</translation>
    </message>
    <message numerus="no" id="txt_software_dpopinfo_tap_to_view">
      <source>Tap to view</source>
      <translation variants="no">zh_hk #Tap to view</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_device_software_available">
      <source>Device software available</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Device software available</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_software_dblist_1_val_ln_update">
      <source>%Ln updates</source>
      <translation>
        <numerusform plurality="a">zh_hk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_updates_available">
      <source>Updates available</source>
      <translation variants="no">zh_hk #Updates available</translation>
    </message>
    <message numerus="no" id="txt_software_info_updates_21_need_this_update_fo">
      <source>Updates "%1" need this update for working</source>
      <translation variants="no">zh_hk #Updates "%1" need this update for working</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_version">
      <source>Version:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Version:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_now">
      <source>Now</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Now</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_optional_mb">
      <source>Optional (%1L MB)</source>
      <translation variants="no">zh_hk #Optional (%1L MB)</translation>
    </message>
    <message numerus="no" id="txt_software_dpopinfo_not_activated">
      <source>Not activated</source>
      <translation variants="no">zh_hk #Not activated</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_updated">
      <source>Updated</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Updated</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_l_kb">
      <source>%L kB</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #%L kB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_important_kb">
      <source>Important (%1L kB)</source>
      <translation variants="no">zh_hk #Important (%1L kB)</translation>
    </message>
    <message numerus="no" id="txt_software_info_device_restart_is_needed_restar">
      <source>Device restart is needed. Restart now?</source>
      <translation variants="no">zh_hk #Device restart is needed. Restart now?</translation>
    </message>
    <message numerus="no" id="txt_software_dpophead_update_checking">
      <source>Update checking</source>
      <translation variants="no">zh_hk #Update checking</translation>
    </message>
    <message numerus="no" id="txt_software_setlabel_val_on_in_home_network">
      <source>On in home network</source>
      <translation variants="no">zh_hk #On in home network</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_settings">
      <source>Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_info_this_update_also_needs_1_for">
      <source>This update also needs "%1" for working</source>
      <translation variants="no">zh_hk #This update also needs "%1" for working</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_1_val_downloaded">
      <source>Downloaded</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Downloaded</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_opt_disclaimer">
      <source>Disclaimer</source>
      <translation variants="no">zh_hk #Disclaimer</translation>
    </message>
    <message numerus="no" id="txt_software_info_application_update_is_available">
      <source>Application update is available from Nokia. Update?</source>
      <translation variants="no">zh_hk #Application update is available from Nokia. Update?</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_recommended_mb">
      <source>Recommended (%1L MB)</source>
      <translation variants="no">zh_hk #Recommended (%1L MB)</translation>
    </message>
    <message numerus="no" id="txt_software_dialog_size">
      <source>Size:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Size:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_dialog_l_mb">
      <source>%L MB</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #%L MB</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_software_button_update">
      <source>Update</source>
      <translation variants="no">zh_hk #Update</translation>
    </message>
    <message numerus="no" id="txt_software_info_this_update_needs_also_updates">
      <source>This update needs also updates "%1" for working</source>
      <translation variants="no">zh_hk #This update needs also updates "%1" for working</translation>
    </message>
    <message numerus="no" id="txt_software_subhead_selected_1l_2l_3l_mb">
      <source>Selected %1L/%2L (%3L MB)</source>
      <translation variants="no">zh_hk #Selected %1L/%2L (%3L MB)</translation>
    </message>
    <message numerus="no" id="txt_software_formlabel_network_connection">
      <source>Network connection</source>
      <translation variants="no">zh_hk #Network connection</translation>
    </message>
    <message numerus="no" id="txt_software_dblist_update_1_val_important_mb">
      <source>Important (%1L MB)</source>
      <translation variants="no">zh_hk #Important (%1L MB)</translation>
    </message>
  </context>
</TS>