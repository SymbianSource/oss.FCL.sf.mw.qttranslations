<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Monthly</source>
      <translation variants="no">每月</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Yearly</source>
      <translation variants="no">每年</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Repeat</source>
      <translation variants="no">重複</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">移除內容說明</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Weekly</source>
      <translation variants="no">每週</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_description">
      <source>Description</source>
      <translation variants="no">內容說明</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">重複直至</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_meeting_saved">
      <source>New meeting saved</source>
      <translation variants="no">新會議已儲存</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>All day event</source>
      <translation variants="no">全天項目</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_end_time">
      <source>End time</source>
      <translation variants="no">結束時間：</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">加入內容說明</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">放棄變更</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Location</source>
      <translation variants="no">方位</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_fortnightly">
      <source>Fortnightly</source>
      <translation variants="no">每兩週</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_start_time">
      <source>Start time</source>
      <translation variants="no">開始時間：</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">主題</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Only once</source>
      <translation variants="no">不重複</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Daily</source>
      <translation variants="no">每天</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_meeting_updated">
      <source>Meeting updated</source>
      <translation variants="no">會議已更新</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_new_event">
      <source>New event</source>
      <translation variants="no">新項目</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Start date</source>
      <translation variants="no">開始日期</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Start time</source>
      <translation variants="no">開始時間</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>End date</source>
      <translation variants="no">結束日期</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">重複直至</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>End time</source>
      <translation variants="no">結束時間</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="no">日曆</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="no">待辦事項</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="no">會議</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">是否刪除會議？</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">刪除重複項目：</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">只限本次</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">修改重複項目：</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">每一次出現</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_off">
      <source>Off</source>
      <translation variants="no">關</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_all_day_event_updated">
      <source>All day event updated</source>
      <translation variants="no">全天項目已更新</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_hour_before">
      <source>1 hour before</source>
      <translation variants="no">1小時前</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_5_minutes_befor">
      <source>5 minutes before</source>
      <translation variants="no">5分鐘前</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_time">
      <source>Reminder time</source>
      <translation variants="no">響鬧時間：</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entry">
      <source>Delete entry?</source>
      <translation variants="no">是否刪除項目？</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_on_event_day">
      <source>On event day</source>
      <translation variants="no">在活動當天</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_location_updated_keep_existing">
      <source>Location updated. Keep existing location on map ?</source>
      <translation variants="no">位置已更新。是否保留地圖上現有的方位？</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_1_day_before">
      <source>1 day before</source>
      <translation variants="no">1天前</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_2_days_before">
      <source>2 days before</source>
      <translation variants="no">2天前</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_at_the_start">
      <source>At the start</source>
      <translation variants="no">在開始時</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_15_minutes_befo">
      <source>15 minutes before</source>
      <translation variants="no">15分鐘前</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Reminder</source>
      <translation variants="no">響鬧</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_30_minutes_befo">
      <source>30 minutes before</source>
      <translation variants="no">30分鐘前</translation>
    </message>
    <message numerus="no" id="txt_calendar_dpopinfo_new_all_day_event_saved">
      <source>New All day event saved</source>
      <translation variants="no">新的全天項目已儲存</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_workdays">
      <source>Workdays</source>
      <translation variants="no">工作日</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event ?</source>
      <translation variants="no">是否刪除全天項目？</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_all_day_event">
      <source>All day event</source>
      <translation variants="no">全天項目</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_db_conflict_info_delete">
      <source>This entry has been deleted by another application</source>
      <translation variants="no">zh_hk #This entry has been deleted by another application</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_db_conflict_info_modify">
      <source>This entry has been modified by another application</source>
      <translation variants="no">zh_hk #This entry has been modified by another application</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_database_conflict">
      <source>Database conflict</source>
      <translation variants="no">zh_hk #Calendar database conflict</translation>
    </message>
  </context>
</TS>