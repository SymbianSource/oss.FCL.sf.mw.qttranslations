<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_user_guide_opt_stop">
      <source>Stop</source>
      <translation variants="no">Ngừng</translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_clear">
      <source>Clear</source>
      <translation variants="no">Xóa</translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_expand_all">
      <source>Expand all</source>
      <translation variants="no">Mở rộng tất cả</translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_applications">
      <source>Applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ứng dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_user_guide">
      <source>User guide</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hướng dẫn sử dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_title_user_guide">
      <source>User guide</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hướng dẫn sử dụng</lengthvariant>
        <lengthvariant priority="2">H.dẫn sử dụng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_setlabel_search">
      <source>Search</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tìm kiếm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_setlabel_search_results">
      <source>Search results</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kết quả tìm kiếm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_button_link_to_nokiacomsupport">
      <source>Link to nokia.com/support</source>
      <translation variants="yes">
        <lengthvariant priority="1">Liên kết nokia.com/support</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_setlabel_searching">
      <source>Searching</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đang tìm kiếm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_user_guide_button_all">
      <source>All</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tất cả</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_user_guide">
      <source>User guide</source>
      <translation variants="no">vi ##User guide</translation>
    </message>
    <message numerus="no" id="txt_user_guide_list_no_match_found">
      <source>No Match found</source>
      <translation variants="no">vi ##No Match found</translation>
    </message>
    <message numerus="no" id="txt_user_guide_opt_collapse_all">
      <source>Collapse all</source>
      <translation variants="no">Thu hẹp tất cả</translation>
    </message>
    <message numerus="no" id="txt_short_caption_userguide">
      <source>User guide</source>
      <translation variants="no">vi ##User guide</translation>
    </message>
    <message numerus="no" id="txt_user_guide_dialog_search_device">
      <source>Search device</source>
      <translation variants="no">Tìm kiếm thiết bị</translation>
    </message>
  </context>
</TS>