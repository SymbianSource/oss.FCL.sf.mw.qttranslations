<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_caption_video_telephone">
      <source>Video telephone</source>
      <translation variants="no">zh_hk ##Video telephone</translation>
    </message>
    <message numerus="no" id="txt_long_caption_video_telephone">
      <source>Video telephone</source>
      <translation variants="no">視像通話</translation>
    </message>
    <message numerus="no" id="txt_vt_dblist_ongoing_video_call">
      <source>Ongoing video call</source>
      <translation variants="no">zh_hk #Ongoing video call</translation>
    </message>
    <message numerus="no" id="txt_vt_custom_unknown_number">
      <source>Unknown number</source>
      <translation variants="no">zh_hk #Unknown number</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_stop_sharing">
      <source>Stop sharing</source>
      <translation variants="no">停止分享</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_swap_views">
      <source>Swap views</source>
      <translation variants="no">切換檢視</translation>
    </message>
    <message numerus="no" id="txt_vt_title_video_call">
      <source>Video call</source>
      <translation variants="yes">
        <lengthvariant priority="1">視像通話</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vt_menu_disable_camera">
      <source>Disable camera</source>
      <translation variants="no">關閉相機</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_share_image">
      <source>Share image</source>
      <translation variants="no">分享圖像</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_zoom">
      <source>Zoom</source>
      <translation variants="no">縮放</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_swap_views">
      <source>Swap views</source>
      <translation variants="no">切換檢視</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_change_camera">
      <source>Change camera</source>
      <translation variants="no">更換使用中的相機</translation>
    </message>
    <message numerus="no" id="txt_vt_info_allow_own_image_to_be_sent">
      <source>Allow own image to be sent?</source>
      <translation variants="no">是否允許將視像圖像傳送給來電方？</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_zoom">
      <source>Zoom </source>
      <translation variants="no">縮放</translation>
    </message>
    <message numerus="no" id="txt_vt_custom_private_number">
      <source>Private number</source>
      <translation variants="no">zh_hk #Private number</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_open_keypad">
      <source>Open keypad</source>
      <translation variants="no">開啟鍵盤</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_enable_camera">
      <source>Enable camera</source>
      <translation variants="no">啟用相機</translation>
    </message>
    <message numerus="no" id="txt_vt_button_end_call">
      <source>End call</source>
      <translation variants="no">zh_hk #End call</translation>
    </message>
  </context>
</TS>