<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_vt_menu_stop_sharing">
      <source>Stop sharing</source>
      <translation variants="no">zh_hk #Stop sharing</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_swap_views">
      <source>Swap views</source>
      <translation variants="no">zh_hk #Swap views</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_share_image">
      <source>Share image</source>
      <translation variants="no">zh_hk #Share image</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_zoom">
      <source>Zoom</source>
      <translation variants="no">zh_hk #Zoom</translation>
    </message>
    <message numerus="no" id="txt_short_caption_video_call">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Not specified</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_swap_views">
      <source>Swap views</source>
      <translation variants="no">zh_hk #Swap views</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_change_camera">
      <source>Change camera</source>
      <translation variants="no">zh_hk #Change camera</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_switch_to_voice_call">
      <source>Not specified</source>
      <translation variants="no">zh_hk #Not specified</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_open_keypad">
      <source>Open keypad</source>
      <translation variants="no">zh_hk #Open keypad</translation>
    </message>
    <message numerus="no" id="txt_vt_menu_enable_camera">
      <source>Enable camera</source>
      <translation variants="no">zh_hk #Enable camera</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_video_telephone">
      <source>Video telephone</source>
      <translation variants="no">zh_hk #Video telephone</translation>
    </message>
    <message numerus="no" id="txt_long_caption_video_telephone">
      <source>Video telephone</source>
      <translation variants="no">zh_hk #Video telephone</translation>
    </message>
    <message numerus="no" id="txt_vt_button_end_call">
      <source>End call</source>
      <translation variants="no">zh_hk #End call</translation>
    </message>
    <message numerus="no" id="txt_long_caption_video_call">
      <source>Video call</source>
      <translation variants="no">zh_hk #Video call</translation>
    </message>
    <message numerus="no" id="txt_vt_list_video_telephone">
      <source>Video telephone</source>
      <translation variants="no">zh_hk #Video telephone</translation>
    </message>
    <message numerus="no" id="txt_vt_opt_zoom">
      <source>Zoom </source>
      <translation variants="no">zh_hk #Zoom </translation>
    </message>
    <message numerus="no" id="txt_vt_title_video_call">
      <source>Video call</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Video call</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vt_menu_disable_camera">
      <source>Disable camera</source>
      <translation variants="no">zh_hk #Disable camera</translation>
    </message>
    <message numerus="no" id="txt_vt_info_allow_own_image_to_be_sent">
      <source>Allow own image to be sent?</source>
      <translation variants="no">zh_hk #Allow own image to be sent?</translation>
    </message>
  </context>
</TS>