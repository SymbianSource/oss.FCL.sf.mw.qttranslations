<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ko">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Snooze</source>
      <translation variants="yes">
        <lengthvariant priority="1">다시 알람</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Clock alarm</source>
      <translation variants="no">시간 알람</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snoozed_for_ln_minute">
      <source>Alarm snoozed for %Ln minutes</source>
      <translation>
        <numerusform plurality="a">ko #Alarm snoozed for %Ln minute</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">무음</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Switch phone on ?</source>
      <translation variants="no">장치를 켜시겠습니까?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Calendar alarm</source>
      <translation variants="no">일정 알람</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_stop">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">ko #Stop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>To-do note</source>
      <translation variants="no">할 일 메모 알람</translation>
    </message>
  </context>
</TS>