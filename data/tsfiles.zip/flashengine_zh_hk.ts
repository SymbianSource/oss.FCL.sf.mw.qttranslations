<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="text_flite_error_insert_memory_card">
      <source>Not enough memory to play selected video. Insert memory card and play again</source>
      <translation variants="no">記憶體不足。請插入記憶卡。</translation>
    </message>
    <message numerus="no" id="text_flite_error_not_enough_memory_video_terminates">
      <source>Memory card full.Video will terminate.Delete some data and play again</source>
      <translation variants="no">無法播放短片。記憶卡已滿。</translation>
    </message>
    <message numerus="no" id="text_flite_error_video_too_large">
      <source>Video memory requirements exceed phone capacity. Video will terminate</source>
      <translation variants="no">記憶體不足，無法播放短片   </translation>
    </message>
    <message numerus="no" id="text_flite_mmc_access_error">
      <source>Memory card cannot be accessed. Operation will terminate</source>
      <translation variants="no">無法播放短片。記憶卡無法使用。</translation>
    </message>
    <message numerus="no" id="text_flite_note_insufficient_memory_mmc_needed">
      <source>Phone memory not sufficient, memory card required for optimal playback</source>
      <translation variants="no">裝置記憶體不足。請插入記憶卡。</translation>
    </message>
    <message numerus="no" id="text_flite_note_mmc_memory_low">
      <source>For optimal playback, delete some data from memory card</source>
      <translation variants="no">記憶體不足。請刪除一些數據。</translation>
    </message>
  </context>
</TS>