<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_2_minutes">
      <source>2 minutes</source>
      <translation variants="no">2分钟</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_locked_after">
      <source>Keys &amp; screen locked after</source>
      <translation variants="no">键和屏幕锁闭前等待时间：</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_15_seconds">
      <source>15 seconds</source>
      <translation variants="no">15秒</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">移动网络</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自动</translation>
    </message>
    <message numerus="no" id="txt_cp_title_control_panel">
      <source>Control Panel</source>
      <translation variants="yes">
        <lengthvariant priority="1">控制面板</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_touch_screen_vibra">
      <source>Touch screen vibra</source>
      <translation variants="no">振动</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_val_change_language">
      <source>Change language</source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑语言设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">按键和屏幕</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_music">
      <source>Choose from music</source>
      <translation variants="yes">
        <lengthvariant priority="1">音乐</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_select_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择主题模式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">重设设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_45_seconds">
      <source>45 seconds</source>
      <translation variants="no">45秒</translation>
    </message>
    <message numerus="no" id="txt_cp_title_setup">
      <source>Setup</source>
      <translation variants="no">设置</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_home_network">
      <source>Data usage in home network</source>
      <translation variants="no">注册网络内数据使用</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_1_minute">
      <source>1 minute</source>
      <translation variants="no">1分钟</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_primary_writing_language">
      <source>Primary writing language</source>
      <translation variants="no">主要编辑语言</translation>
    </message>
    <message numerus="no" id="txt_cp_list_tone">
      <source>Choose from tones</source>
      <translation variants="yes">
        <lengthvariant priority="1">铃声</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_wallpaper">
      <source>Wallpaper</source>
      <translation variants="yes">
        <lengthvariant priority="1">壁纸</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自动</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection_val_manual">
      <source>Manual</source>
      <translation variants="yes">
        <lengthvariant priority="1">手动</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_reset">
      <source>Reset</source>
      <translation variants="yes">
        <lengthvariant priority="1">重设设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_brightness">
      <source>Brightness</source>
      <translation variants="no">亮度</translation>
    </message>
    <message numerus="no" id="txt_cp_info_setup_is_not_completed_would_you_lik">
      <source>Setup is not completed. 
Would you like to complete it now?</source>
      <translation variants="no">设备安装尚未完成。现在完成？</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network">
      <source>Mobile network</source>
      <translation variants="yes">
        <lengthvariant priority="1">移动网络</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_keys_screen">
      <source>Keys &amp; screen</source>
      <translation variants="yes">
        <lengthvariant priority="1">按键和屏幕</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_dual_mode">
      <source>Dual mode</source>
      <translation variants="no">双模式</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">关于此程序</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_connectivity">
      <source>Connectivity</source>
      <translation variants="yes">
        <lengthvariant priority="1">连接功能</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device">
      <source>Device</source>
      <translation variants="yes">
        <lengthvariant priority="1">手机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_security">
      <source>Security</source>
      <translation variants="yes">
        <lengthvariant priority="1">安全</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language">
      <source>Secondary writing language</source>
      <translation variants="no">次要编辑语言</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_umts">
      <source>UMTS</source>
      <translation variants="no">3G</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reset_val_reset_your_device">
      <source>Reset your device</source>
      <translation variants="yes">
        <lengthvariant priority="1">恢复出厂设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode_val_gsm">
      <source>GSM</source>
      <translation variants="no">GSM</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_select_tone_type">
      <source>Change tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择铃声类型</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">标准</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">会议</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_in_offline_mode_all_wireless_communica">
      <source>In offline mode all wireless communication is turned off.</source>
      <translation variants="no">所有无线连接均关闭</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_theme">
      <source>Theme</source>
      <translation variants="yes">
        <lengthvariant priority="1">主题模式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_network_mode">
      <source>Network mode</source>
      <translation variants="no">网络模式</translation>
    </message>
    <message numerus="no" id="txt_cp_list_about">
      <source>About</source>
      <translation variants="yes">
        <lengthvariant priority="1">关于此程序</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_volume">
      <source>Volume</source>
      <translation variants="yes">
        <lengthvariant priority="1">音量</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_keys_screen_val_30_seconds">
      <source>30 seconds</source>
      <translation variants="no">30秒</translation>
    </message>
    <message numerus="no" id="txt_cp_list_no_tone">
      <source>Set no tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">无</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_key_and_touchscreen_tones">
      <source>Key and touchscreen tones</source>
      <translation variants="no">按键音量</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_automatic">
      <source>Automatic</source>
      <translation variants="no">自动</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_roaming">
      <source>Data usage when roaming</source>
      <translation variants="no">漫游时数据使用</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_operator_selection">
      <source>Operator selection</source>
      <translation variants="no">运营商选择</translation>
    </message>
    <message numerus="no" id="txt_cp_title_preview_1">
      <source>Preview: %1</source>
      <translation variants="no">预览：%[13]1</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_message_tone">
      <source>Message tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">信息提示音</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_email_tone">
      <source>E-mail tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">电子邮件提示音</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_autorotate_display">
      <source>Auto-rotate display</source>
      <translation variants="no">自动旋转显示</translation>
    </message>
    <message numerus="no" id="txt_cp_info_rotate_the_display_content_automatical">
      <source>Rotate the display content automatically when you turn the device on horizontal or back to a vertical position.</source>
      <translation variants="no">当设备方向改变时，自动旋转显示内容</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_reminder_tone">
      <source>Reminder tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">日历闹铃铃声</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_disabled">
      <source>Disabled</source>
      <translation variants="no">关闭</translation>
    </message>
    <message numerus="no" id="txt_cp_title_profile">
      <source>Profile</source>
      <translation variants="no">选择情景模式</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset">
      <source>Settings reset</source>
      <translation variants="no">设置已重置</translation>
    </message>
    <message numerus="no" id="txt_cp_general">
      <source>General</source>
      <translation variants="yes">
        <lengthvariant priority="1">标准</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_edit_name">
      <source>Edit name</source>
      <translation variants="no">编辑名称</translation>
    </message>
    <message numerus="no" id="txt_short_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">zh #Control panel</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active_val_clock_alarm">
      <source>Clock alarm at %1</source>
      <translation variants="no">时钟闹铃定在%1</translation>
    </message>
    <message numerus="no" id="txt_cp_button_regional_settings">
      <source>Regional settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">区域设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">高级设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">振动</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_tones_that_play_when_you_select">
      <source>Select tones that play when you select the profile named:</source>
      <translation variants="no">选择当此情景模式被选中时所使用的铃声：</translation>
    </message>
    <message numerus="no" id="txt_cp_info_data_encryption_ongoing_enryption_mus">
      <source>Data encryption ongoing. Enryption must be ended before reset.  End data enrcyption?</source>
      <translation variants="no">正在进行数据加密。加密结束后方能重置。结束数据加密？</translation>
    </message>
    <message numerus="no" id="txt_cp_info_delete_all_data_and_restore_original_s">
      <source>Delete all data and restore original settings? Ejectable memory card data is not deleted.</source>
      <translation variants="no">删除所有数据并恢复出厂设置？可移动存储卡上的数据不删除。</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_your_region">
      <source>Select your region:</source>
      <translation variants="no">选择区域：</translation>
    </message>
    <message numerus="no" id="txt_cp_button_end">
      <source>End</source>
      <translation variants="no">结束</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_display_language">
      <source>Display language</source>
      <translation variants="no">显示语言</translation>
    </message>
    <message numerus="no" id="txt_cp_list_notification_tones">
      <source>Notification tones</source>
      <translation variants="no">通知铃声</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_when_val_confirm">
      <source>Confirm</source>
      <translation variants="no">总是询问</translation>
    </message>
    <message numerus="no" id="txt_cp_info_restore_original_settings_no_data_wil">
      <source>Restore original settings? No data will be deleted.</source>
      <translation variants="no">恢复原始设置？将不会删除任何数据。</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_confirm">
      <source>Confirm</source>
      <translation variants="no">总是询问</translation>
    </message>
    <message numerus="no" id="txt_cp_info_active_calls_and_connections_must_be_d">
      <source>Active calls and connections must be disconnected before reset.</source>
      <translation variants="no">必须断开当前通话和连接才能重置</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">语言和区域</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">断开连接</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_ringtone">
      <source>Ringtone</source>
      <translation variants="yes">
        <lengthvariant priority="1">铃声</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_button_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">无声</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_silent_state_active">
      <source>Silent state active</source>
      <translation variants="no">无声状态启动</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_tones">
      <source>Get more from Ovi</source>
      <translation variants="yes">
        <lengthvariant priority="1">转至商店</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_original_settings_will_be_restored_no">
      <source>Original settings will be restored. No data will be deleted.</source>
      <translation variants="no">将恢复原始设置。不会删除任何数据。</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_language_and_region">
      <source>Language and region</source>
      <translation variants="yes">
        <lengthvariant priority="1">语言和区域</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset_val_reset_device">
      <source>Reset device</source>
      <translation variants="yes">
        <lengthvariant priority="1">重置设备</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_title_edit_name">
      <source>Edit name</source>
      <translation variants="no">编辑名称</translation>
    </message>
    <message numerus="no" id="txt_cp_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">会议</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_data_usage_in_val_disabled">
      <source>Disabled</source>
      <translation variants="no">关闭</translation>
    </message>
    <message numerus="no" id="txt_cp_title_end_encryption">
      <source>End encryption</source>
      <translation variants="no">结束加密</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_device_reset">
      <source>Device reset</source>
      <translation variants="no">设备重置</translation>
    </message>
    <message numerus="no" id="txt_cp_info_all_data_will_be_deleted_and_factory_s">
      <source>All data will be deleted and factory settings will be restored. Ejectable memory card data is not deleted.</source>
      <translation variants="no">所有数据将被删除，恢复出厂设置。可移动存储卡上的数据不删除。</translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_settings_reset_val_reset_settings">
      <source>Reset settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">重置设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">控制面板</translation>
    </message>
    <message numerus="no" id="txt_long_caption_control_panel">
      <source>Control Panel</source>
      <translation variants="no">控制面板</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_profile">
      <source>Profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">情景模式</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_secondary_writing_language_val_non">
      <source>None</source>
      <translation variants="no">无</translation>
    </message>
    <message numerus="no" id="txt_cp_button_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">高级设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_personalization">
      <source>Personalization</source>
      <translation variants="yes">
        <lengthvariant priority="1">个性化选择</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">铃声音量</translation>
    </message>
    <message numerus="no" id="txt_cp_heading_profile_name">
      <source>Profile name: </source>
      <translation variants="yes">
        <lengthvariant priority="1">情景模式名称：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_not_connected">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">未连接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_001">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_mobile_network_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">关</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_8">
      <source>Copyright (c) 1996-1998
Silicon Graphics Computer Systems, Inc.

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Silicon Graphics makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</source>
      <translation variants="no">Copyright (c) 1996-1998
Silicon Graphics Computer Systems, Inc.

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Silicon Graphics makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_software_version">
      <source>Software version</source>
      <translation variants="no">软件版本</translation>
    </message>
    <message numerus="no" id="txt_cp_list_get_more_themes">
      <source>Get more from Ovi</source>
      <translation variants="yes">
        <lengthvariant priority="1">获取更多</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_6">
      <source>Copyright (c) 2004, 2005 Apple Computer, Inc.
Copyright (c) 1997-2005 University of Cambridge
All rights reserved.
Copyright (c) 2005, Google Inc.
All rights reserved.
Copyright (c) 2006, Nokia Corporation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the University of Cambridge nor the name of Google
  Inc. nor the names of their contributors may be used to endorse or
  promote products derived from this software without specific prior
  written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Copyright (c) 2004, 2005 Apple Computer, Inc.
Copyright (c) 1997-2005 University of Cambridge
All rights reserved.
Copyright (c) 2005, Google Inc.
All rights reserved.
Copyright (c) 2006, Nokia Corporation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the University of Cambridge nor the name of Google
  Inc. nor the names of their contributors may be used to endorse or
  promote products derived from this software without specific prior
  written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_info_product_release">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_2">
      <source>This product includes API header files originally developed by Netscape Communications Corporation, modified by Nokia by changing certain variables for the  
purpose of porting the file to Symbian operating system on May 1st, 2004, and available in source code form under the Netscape Public License, v1.1 at  
http://www.forum.nokia.com/browserapi.</source>
      <translation variants="no">This product includes API header files originally developed by Netscape Communications Corporation, modified by Nokia by changing certain variables for the  
purpose of porting the file to Symbian operating system on May 1st, 2004, and available in source code form under the Netscape Public License, v1.1 at  
http://www.forum.nokia.com/browserapi.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_12">
      <source>Copyright (C) 2007 Apple Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
	1. Redistributions of source code must retain the above copyright
	   notice, this list of conditions and the following disclaimer.
	2. Redistributions in binary form must reproduce the above copyright
	   notice, this list of conditions and the following disclaimer in the
	   documentation and/or other materials provided with the distribution.
	3. Neither the name of Apple Computer, Inc. ("Apple") nor the names of
	   its contributors may be used to endorse or promote products derived
	   from this software without specific prior written permission. 
	
	THIS SOFTWARE IS PROVIDED BY APPLE COMPUTER, INC. ``AS IS'' AND ANY
	EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
	IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
	PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
	PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
	OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
	OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Copyright (C) 2007 Apple Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Apple Computer, Inc. ("Apple") nor the names of
   its contributors may be used to endorse or promote products derived
   from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE COMPUTER, INC. ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_info_when_selected_clock_is_displayed_when">
      <source>When selected, clock is displayed when in idle.</source>
      <translation variants="no">当屏幕一片空白时显示时钟</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_9">
      <source>Copyright (c) 1983, 1995, 1996 Eric P. Allman
Copyright (c) 1988, 1993
 The Regents of the University of California.  All rights reserved.
Copyright (C) 2007 Nokia Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of the University nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.</source>
      <translation variants="no">Copyright (c) 1983, 1995, 1996 Eric P. Allman
Copyright (c) 1988, 1993
 The Regents of the University of California.  All rights reserved.
Copyright (C) 2007 Nokia Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of the University nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_product_release">
      <source>Product Release</source>
      <translation variants="no">产品发布</translation>
    </message>
    <message numerus="no" id="txt_cp_list_screensaver">
      <source>Screensaver</source>
      <translation variants="no">时钟屏幕保护</translation>
    </message>
    <message numerus="no" id="txt_cp_info_processing">
      <source>Processing…</source>
      <translation variants="no">正在处理</translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices_1">
      <source>This product includes certain open source software. The exact terms of the licenses, disclaimers, acknowledgements and notices are provided below. Nokia offers to provide you with the source code as defined in the applicable license. 

Please send an e-mail to sourcecode.request@nokia.com or a written request to:

Source Code Requests
Nokia Corporation
P.O.Box 407
FI-00045 Nokia Group
Finland

This offer is valid for a period of three (3) years from the date of the distribution of this product by Nokia.</source>
      <translation variants="no">This product includes certain open source software. The exact terms of the licenses, disclaimers, acknowledgements and notices are provided below. Nokia offers to provide you with the source code as defined in the applicable license. 

Please send an e-mail to sourcecode.request@nokia.com or a written request to:

Source Code Requests
Nokia Corporation
P.O.Box 407
FI-00045 Nokia Group
Finland

This offer is valid for a period of three (3) years from the date of the distribution of this product by Nokia.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_4">
      <source>Copyright (C) 2004, Apple Computer, Inc. and The Mozilla Foundation. 
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. Neither the names of Apple Computer, Inc. ("Apple") or The Mozilla
Foundation ("Mozilla") nor the names of their contributors may be used
to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY APPLE, MOZILLA AND THEIR CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE, MOZILLA OR
THEIR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Copyright (C) 2004, Apple Computer, Inc. and The Mozilla Foundation. 
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. Neither the names of Apple Computer, Inc. ("Apple") or The Mozilla
Foundation ("Mozilla") nor the names of their contributors may be used
to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY APPLE, MOZILLA AND THEIR CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE, MOZILLA OR
THEIR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_button_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">离线</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_14">
      <source>Copyright (c) 1998 - 2008, Paul Johnston &amp; Contributors
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of the author nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Copyright (c) 1998 - 2008, Paul Johnston &amp; Contributors
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of the author nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_type">
      <source>Type</source>
      <translation variants="no">类型</translation>
    </message>
    <message numerus="no" id="txt_cp_open_source_software_notices">
      <source>Open source software notices</source>
      <translation variants="no">开放源码软件通知</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_7">
      <source>Copyright (c) 1994
Hewlett-Packard Company

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Hewlett-Packard Company makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</source>
      <translation variants="no">Copyright (c) 1994
Hewlett-Packard Company

Permission to use, copy, modify, distribute and sell this software
and its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice appear in all copies and
that both that copyright notice and this permission notice appear
in supporting documentation.  Hewlett-Packard Company makes no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied warranty.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_1">
      <source>Java and all Java-based marks are trademarks or registered trademarks of Sun Microsystems, Inc.
JavaTM ME environment: MIDP 2.1, CLDC 1.1.</source>
      <translation variants="no">Java和所有基于Java的标记是Sun Microsystems, 公司的商标或注册商标
JavaTM ME环境：MIDP 2.1，CLDC 1.1。</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_device_model">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_5">
      <source>The author of this software is David M. Gay.

Copyright (c) 1991, 2000, 2001 by Lucent Technologies.

Permission to use, copy, modify, and distribute this software for any
purpose without fee is hereby granted, provided that this entire notice
is included in all copies of any software which is or includes a copy
or modification of this software and in all copies of the supporting
documentation for such software.

THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY.  IN PARTICULAR, NEITHER THE AUTHOR NOR LUCENT MAKES ANY
REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.</source>
      <translation variants="no">The author of this software is David M. Gay.

Copyright (c) 1991, 2000, 2001 by Lucent Technologies.

Permission to use, copy, modify, and distribute this software for any
purpose without fee is hereby granted, provided that this entire notice
is included in all copies of any software which is or includes a copy
or modification of this software and in all copies of the supporting
documentation for such software.

THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY.  IN PARTICULAR, NEITHER THE AUTHOR NOR LUCENT MAKES ANY
REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices">
      <source>3rd party notices</source>
      <translation variants="no">第三方通知</translation>
    </message>
    <message numerus="no" id="txt_cp_info_type">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_terms_of_use">
      <source>Terms of Use</source>
      <translation variants="no">使用条款</translation>
    </message>
    <message numerus="no" id="txt_cp_info_1">
      <source>Nokia and Nokia Connecting People are trademarks or registered trademarks of Nokia Corporation.
 
Copyright 2011 Nokia. All rights reserved. 

This product is based on Symbian^4.

Other product and company names mentioned herein may be trademarks or tradenames of their respective owners. </source>
      <translation variants="no">Nokia和Nokia Connecting People是Nokia公司的商标或注册商标。
 
版权所有 2011 Nokia。保留所有权利。

此产品基于Symbian^4。

此处提及的其他产品和公司名称可能是其各自所有者的商标或商号。</translation>
    </message>
    <message numerus="no" id="txt_cp_info_software_vesion">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_10">
      <source>Copyright (c) 1995-2006 International Business Machines Corporation and others

All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, provided that the above copyright notice(s)
and this permission notice appear in all copies of the Software and that both the above
copyright notice(s) and this permission notice appear in supporting documentation.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 
Except as contained in this notice, the name of a copyright holder shall not be used in
advertising or otherwise to promote the sale, use or other dealings in this Software
without prior written authorization of the copyright holder.</source>
      <translation variants="no">Copyright (c) 1995-2006 International Business Machines Corporation and others

All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, provided that the above copyright notice(s)
and this permission notice appear in all copies of the Software and that both the above
copyright notice(s) and this permission notice appear in supporting documentation.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 
Except as contained in this notice, the name of a copyright holder shall not be used in
advertising or otherwise to promote the sale, use or other dealings in this Software
without prior written authorization of the copyright holder.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_open_source_software_notices">
      <source>Open source software notices</source>
      <translation variants="yes">
        <lengthvariant priority="1">开源软件通知</lengthvariant>
        <lengthvariant priority="2">zh #Open-source softw. notices</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_13">
      <source>Open Dynamics Engine
Copyright (c) 2001-2004, Russell L. Smith.
All rights reserved.

Redistribution and use in source and binary forms, 
with or without modification, are permitted provided
that the following conditions are met:

Redistributions of source code must retain the above 
copyright notice, this list of conditions and the 
following disclaimer.

Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or 
other materials provided with the distribution.

Neither the names of ODE's copyright owner nor the 
names of its contributors may be used to endorse or 
promote products derived from this software without 
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS 
AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.</source>
      <translation variants="no">Open Dynamics Engine
Copyright (c) 2001-2004, Russell L. Smith.
All rights reserved.

Redistribution and use in source and binary forms, 
with or without modification, are permitted provided
that the following conditions are met:

Redistributions of source code must retain the above 
copyright notice, this list of conditions and the 
following disclaimer.

Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or 
other materials provided with the distribution.

Neither the names of ODE's copyright owner nor the 
names of its contributors may be used to endorse or 
promote products derived from this software without 
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS 
AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_3rd_party_notices_3">
      <source>Copyright (C) 2005 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2007 Apple Inc.  All rights reserved.
Copyright (C) 2007 Nokia Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without

modification, are permitted provided that the following conditions
are met:

1.  Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer. 
2.  Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution. 
3.  Neither the name of Apple Computer, Inc. ("Apple") nor the names of
    its contributors may be used to endorse or promote products derived
    from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE AND ITS CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL APPLE OR ITS CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</source>
      <translation variants="no">Copyright (C) 2005 Apple Computer, Inc.  All rights reserved.
Copyright (C) 2007 Apple Inc.  All rights reserved.
Copyright (C) 2007 Nokia Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without

modification, are permitted provided that the following conditions
are met:

1.  Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer. 
2.  Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution. 
3.  Neither the name of Apple Computer, Inc. ("Apple") nor the names of
    its contributors may be used to endorse or promote products derived
    from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY APPLE AND ITS CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL APPLE OR ITS CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</translation>
    </message>
    <message numerus="no" id="txt_cp_subhead_3rd_party_notices">
      <source>3rd party notices</source>
      <translation variants="yes">
        <lengthvariant priority="1">第三方通知</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_info_closing_connections">
      <source>Closing connections</source>
      <translation variants="no">zh #Closing connections</translation>
    </message>
    <message numerus="no" id="txt_cp_text_edit_device_will_be_restarted_to_chang">
      <source>Device will be restarted to change display language. Continue?</source>
      <translation variants="no">zh #Changing the display language will require your device to restart. Continue?</translation>
    </message>
    <message numerus="no" id="txt_cp_info_select_graphical_style_of_the_device">
      <source>Select graphical style of the device</source>
      <translation variants="no">zh ##Select theme</translation>
    </message>
  </context>
</TS>