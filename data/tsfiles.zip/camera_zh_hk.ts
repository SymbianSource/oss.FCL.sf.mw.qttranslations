<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cam_list_night_portrait">
      <source>Night portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Night portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sports">
      <source>Sports</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Sport</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_portrait">
      <source>Portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer">
      <source>Self timer</source>
      <translation variants="no">自動計時器</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos">
      <source>Go to Photos</source>
      <translation variants="no">照片</translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode">
      <source>Camera in stand-by mode</source>
      <translation variants="no">相機待機中</translation>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">曝光補償</translation>
    </message>
    <message numerus="no" id="txt_cam_list_landscape">
      <source>Landscape</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Landscape</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings">
      <source>Camera settings</source>
      <translation variants="no">相機設定</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_stabilization">
      <source>Video stabilization</source>
      <translation variants="no">防止短片震動</translation>
    </message>
    <message numerus="no" id="txt_short_caption_camera">
      <source>Camera</source>
      <translation variants="no">zh_hk #Camera</translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">zh_hk #Exposure compensation</translation>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone">
      <source>Color tone</source>
      <translation variants="no">zh_hk #Colour tone</translation>
    </message>
    <message numerus="no" id="txt_cam_title_memory_in_use">
      <source>Memory in use</source>
      <translation variants="no">使用中的記憶體</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_video">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_video">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">夜間</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_43">
      <source>VGA 4:3</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA 4:3</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_memory_in_use">
      <source>Memory in use</source>
      <translation variants="no">使用中的記憶體</translation>
    </message>
    <message numerus="no" id="txt_cam_button_cancel">
      <source>Cancel</source>
      <translation variants="no">取消</translation>
    </message>
    <message numerus="no" id="txt_cam_other_please_type_here">
      <source>Please type here</source>
      <translation variants="no">在此處輸入</translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_image_name">
      <source>Default image name</source>
      <translation variants="no">預設圖像名稱</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_qcif_sharing">
      <source>QCIF Sharing</source>
      <translation variants="yes">
        <lengthvariant priority="1">QCIF分享</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_memory_card">
      <source>Memory card</source>
      <translation variants="yes">
        <lengthvariant priority="1">記憶卡</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_face">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶自定義</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_sound">
      <source>Video sound</source>
      <translation variants="no">短片音效</translation>
    </message>
    <message numerus="no" id="txt_cam_other_default_image_name">
      <source>Default image name</source>
      <translation variants="no">預設圖像名稱</translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">連續</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga">
      <source>VGA</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance">
      <source>White balance</source>
      <translation variants="no">zh_hk #White balance</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">顯示已拍攝圖像</translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image">
      <source>Delete image?</source>
      <translation variants="no">是否刪除圖像？</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_image">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_lightsens">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">顯示已拍攝短片</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_stabil">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus">
      <source>+%L1</source>
      <translation variants="no">+%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_list_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode">
      <source>Flash mode</source>
      <translation variants="no">閃光燈</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_video">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound">
      <source>Video sound</source>
      <translation variants="no">短片音效</translation>
    </message>
    <message numerus="no" id="txt_cam_title_change_mode">
      <source>Change mode</source>
      <translation variants="no">更換模式</translation>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camcorder">
      <source>Secondary camcorder</source>
      <translation variants="yes">
        <lengthvariant priority="1">副攝錄機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip">
      <source>Delete video clip?</source>
      <translation variants="no">是否刪除短片？</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_flash">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_flash">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds">
      <source>%Ln seconds</source>
      <translation>
        <numerusform plurality="a">%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_start">
      <source>Start</source>
      <translation variants="no">開始</translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_stabilization">
      <source>Video stabilization</source>
      <translation variants="no">防止短片震動</translation>
    </message>
    <message numerus="no" id="txt_cam_list_reduce_red_eye">
      <source>Reduce red eye</source>
      <translation variants="yes">
        <lengthvariant priority="1">消除紅眼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_set_as_default_scene_mode">
      <source>Set as default scene mode</source>
      <translation variants="no">設為預設場景模式</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_geotagging">
      <source>Geotagging</source>
      <translation variants="no">地理標籤</translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_rotation">
      <source>Image rotation</source>
      <translation variants="no">圖像旋轉</translation>
    </message>
    <message numerus="no" id="txt_cam_list_incandescent">
      <source>Incandescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">白熾光</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">連續</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_white">
      <source>Black and white</source>
      <translation variants="yes">
        <lengthvariant priority="1">黑白</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">相機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_contrast">
      <source>Contrast</source>
      <translation variants="no">zh_hk #Contrast</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_scene">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality">
      <source>Image quality</source>
      <translation variants="no">圖像質素</translation>
    </message>
    <message numerus="no" id="txt_cam_other_restore_settings">
      <source>Restore settings?</source>
      <translation variants="no">是否恢復設定？</translation>
    </message>
    <message numerus="no" id="txt_cam_button_geotagging">
      <source>Geotagging</source>
      <translation variants="no">zh_hk #Geotagging</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_rotation">
      <source>Image rotation</source>
      <translation variants="no">圖像旋轉</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">夜間</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left">
      <source>%Ln images left</source>
      <translation>
        <numerusform plurality="a">剩餘%Ln張圖像</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_low_light">
      <source>Low light</source>
      <translation variants="yes">
        <lengthvariant priority="1">低光源</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_video">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">是</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">拍攝聲</translation>
    </message>
    <message numerus="no" id="txt_long_caption_camera ">
      <source>Camera</source>
      <translation variants="no">相機</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_phone_memory">
      <source>Phone memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">手機記憶體</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_face_tracking">
      <source>Face tracking</source>
      <translation variants="no">臉部偵測</translation>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer">
      <source>Self timer</source>
      <translation variants="no">自動計時器</translation>
    </message>
    <message numerus="no" id="txt_cam_list_negative">
      <source>Negative</source>
      <translation variants="yes">
        <lengthvariant priority="1">負片</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_no_memory_card_in_device_please_inse">
      <source>No memory card in device. Please insert memory card in order to capture images.</source>
      <translation variants="no">未插入記憶卡。請插入記憶卡以拍攝圖像。</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings">
      <source>General settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_rotate">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">是</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_169_widescreen">
      <source>HD 720p 16:9 widescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">HD 720p 16:9闊屏幕</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity">
      <source>Light sensitivity</source>
      <translation variants="no">感光度</translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_video">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_yes_image">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">是</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_no_rotate">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_stabil">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_iso">
      <source>ISO</source>
      <translation variants="no">zh_hk #ISO</translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use">
      <source>Camera already in use</source>
      <translation variants="no">相機已由其他應用程式使用中</translation>
    </message>
    <message numerus="no" id="txt_cam_list_closeup">
      <source>Close-up</source>
      <translation variants="yes">
        <lengthvariant priority="1">特寫</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name">
      <source>Default video name</source>
      <translation variants="no">預設短片名稱</translation>
    </message>
    <message numerus="no" id="txt_cam_caption_camera">
      <source>Camera</source>
      <translation variants="no">zh_hk #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_face">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance">
      <source>White balance</source>
      <translation variants="no">白平衡</translation>
    </message>
    <message numerus="no" id="txt_cam_list_camcorder">
      <source>Camcorder</source>
      <translation variants="yes">
        <lengthvariant priority="1">攝錄機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_whitebal">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality">
      <source>Video quality</source>
      <translation variants="no">短片質素</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_timer">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality">
      <source>Video quality</source>
      <translation variants="no">短片質素</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_flash">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_settings">
      <source>Settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode">
      <source>Scene mode</source>
      <translation variants="no">場景模式</translation>
    </message>
    <message numerus="no" id="txt_cam_list_not">
      <source>Not specified</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_cam_info_error">
      <source>Unexpected error occurred. Power off the device and restart</source>
      <translation variants="no">發生未預期的錯誤。請重新啟動手機。</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_val_ln_recording_time_left">
      <source>Recording time left: %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">剩餘錄影時間：%L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_restore_settings">
      <source>Restore settings</source>
      <translation variants="no">恢復設定</translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined_scene">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶自定義</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">顯示已拍攝圖像</translation>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camera">
      <source>Secondary camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">副攝錄機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_fluorescent">
      <source>Fluorescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">螢光</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_white_balance">
      <source>White balance</source>
      <translation variants="no">白平衡</translation>
    </message>
    <message numerus="no" id="txt_cam_list_not_video">
      <source>Not</source>
      <translation variants="yes">
        <lengthvariant priority="1">否</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_captured_photos_and_videos_will_be_ta">
      <source>Captured photos and videos will be tagged with your location. If photos or videos are shared, the location data may also be visible to third parties. Phone will use network to get the location data. Data transfer charges may apply. Location recording can be disabled in settings.</source>
      <translation variants="no">拍攝的照片和短片將標記您的方位。如果您分享照片或短片，其他人可能也會看見此方位數據。手機將使用網絡來獲取方位數據。可能會產生數據傳送費用。您可以在設定中停用方位記錄功能。</translation>
    </message>
    <message numerus="no" id="txt_cam_title_contrast">
      <source>Contrast</source>
      <translation variants="no">對比</translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">顯示已拍攝短片</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_mass_memory">
      <source>Mass memory</source>
      <translation variants="yes">
        <lengthvariant priority="1">大型記憶體</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_scene">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking">
      <source>Face tracking</source>
      <translation variants="no">zh_hk #Face detection</translation>
    </message>
    <message numerus="no" id="txt_cam_list_vivid">
      <source>Vivid</source>
      <translation variants="yes">
        <lengthvariant priority="1">鮮豔</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus">
      <source>-%L1</source>
      <translation variants="no">-%L1</translation>
    </message>
    <message numerus="yes" id="txt_cam_other_delete_n_items">
      <source>Delete %Ln items?</source>
      <translation>
        <numerusform plurality="a">是否刪除%Ln個項目？</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_cloudy">
      <source>Cloudy</source>
      <translation variants="yes">
        <lengthvariant priority="1">陰天</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">拍攝聲</translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_video_name">
      <source>Default video name</source>
      <translation variants="no">預設短片名稱</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sunny">
      <source>Sunny</source>
      <translation variants="yes">
        <lengthvariant priority="1">晴天</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name">
      <source>Default image name</source>
      <translation variants="no">預設圖像名稱</translation>
    </message>
    <message numerus="no" id="txt_cam_title_set_as_default_scene_mode">
      <source>Set as default scene mode</source>
      <translation variants="no">設為預設場景模式</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality">
      <source>Image quality</source>
      <translation variants="no">圖像質素</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sepia">
      <source>Sepia</source>
      <translation variants="yes">
        <lengthvariant priority="1">褐色</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos">
      <source>Go to 'Videos'</source>
      <translation variants="no">短片</translation>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone">
      <source>Color tone</source>
      <translation variants="no">色調</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_upload_settings">
      <source>Upload settings</source>
      <translation variants="no">上載設定</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">相機</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix">
      <source>%Ln Mpix</source>
      <translation>
        <numerusform plurality="a">%Ln百萬像素</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">曝光補償</translation>
    </message>
    <message numerus="no" id="txt_cam_list_normal">
      <source>Normal</source>
      <translation variants="yes">
        <lengthvariant priority="1">標準</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix_widescreen">
      <source>%Ln Mpix widescreen</source>
      <translation>
        <numerusform plurality="a">%Ln百萬像素闊屏幕</numerusform>
      </translation>
    </message>
  </context>
</TS>