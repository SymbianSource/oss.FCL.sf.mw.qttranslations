<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_region_CA">
      <source>Canada</source>
      <translation variants="no">zh_hk #Canada</translation>
    </message>
    <message numerus="no" id="txt_region_VN">
      <source>Việt Nam</source>
      <translation variants="no">zh_hk #Việt Nam</translation>
    </message>
    <message numerus="no" id="txt_region_IS">
      <source>Ísland</source>
      <translation variants="no">zh_hk #Ísland</translation>
    </message>
    <message numerus="no" id="txt_region_RU">
      <source>Россия</source>
      <translation variants="no">zh_hk #Россия</translation>
    </message>
    <message numerus="no" id="txt_region_BG">
      <source>България</source>
      <translation variants="no">zh_hk #България</translation>
    </message>
    <message numerus="no" id="txt_region_IR">
      <source>ایران</source>
      <translation variants="no">zh_hk #ایران</translation>
    </message>
    <message numerus="no" id="txt_region_PK">
      <source>Pakistan</source>
      <translation variants="no">zh_hk #Pakistan</translation>
    </message>
    <message numerus="no" id="txt_region_FI">
      <source>Suomi</source>
      <translation variants="no">zh_hk #Suomi</translation>
    </message>
    <message numerus="no" id="txt_region_SK">
      <source>Slovensko</source>
      <translation variants="no">zh_hk #Slovensko</translation>
    </message>
    <message numerus="no" id="txt_region_BR">
      <source>Brasil</source>
      <translation variants="no">zh_hk #Brasil</translation>
    </message>
    <message numerus="no" id="txt_region_RS">
      <source>Srbija</source>
      <translation variants="no">zh_hk #Srbija</translation>
    </message>
    <message numerus="no" id="txt_region_NL">
      <source>Nederland</source>
      <translation variants="no">zh_hk #Nederland</translation>
    </message>
    <message numerus="no" id="txt_region_PT">
      <source>Portugal</source>
      <translation variants="no">zh_hk #Portugal</translation>
    </message>
    <message numerus="no" id="txt_region_JP">
      <source>日本</source>
      <translation variants="no">zh_hk #日本</translation>
    </message>
    <message numerus="no" id="txt_region_IN">
      <source>भारत</source>
      <translation variants="no">zh_hk #भारत</translation>
    </message>
    <message numerus="no" id="txt_region_US">
      <source>United States</source>
      <translation variants="no">zh_hk #United States</translation>
    </message>
    <message numerus="no" id="txt_region_RO">
      <source>România</source>
      <translation variants="no">zh_hk #România</translation>
    </message>
    <message numerus="no" id="txt_region_CZ">
      <source>Český</source>
      <translation variants="no">zh_hk #Český</translation>
    </message>
    <message numerus="no" id="txt_region_TR">
      <source>Türkiye</source>
      <translation variants="no">zh_hk #Türkiye</translation>
    </message>
    <message numerus="no" id="txt_region_HU">
      <source>Magyarország</source>
      <translation variants="no">zh_hk #Magyarország</translation>
    </message>
    <message numerus="no" id="txt_region_HR">
      <source>Hrvatska</source>
      <translation variants="no">zh_hk #Hrvatska</translation>
    </message>
    <message numerus="no" id="txt_region_EE">
      <source>Eesti</source>
      <translation variants="no">zh_hk #Eesti</translation>
    </message>
    <message numerus="no" id="txt_region_PH">
      <source>Pilipinas</source>
      <translation variants="no">zh_hk #Pilipinas</translation>
    </message>
    <message numerus="no" id="txt_region_ID">
      <source>Indonesia</source>
      <translation variants="no">zh_hk #Indonesia</translation>
    </message>
    <message numerus="no" id="txt_region_FR">
      <source>France</source>
      <translation variants="no">zh_hk #France</translation>
    </message>
    <message numerus="no" id="txt_region_TH">
      <source>ประเทศไทย</source>
      <translation variants="no">zh_hk #ประเทศไทย</translation>
    </message>
    <message numerus="no" id="txt_region_IL">
      <source>ישראל</source>
      <translation variants="no">zh_hk #ישראל</translation>
    </message>
    <message numerus="no" id="txt_region_DE">
      <source>Deutschland</source>
      <translation variants="no">zh_hk #Deutschland</translation>
    </message>
    <message numerus="no" id="txt_region_DK">
      <source>Danmark</source>
      <translation variants="no">zh_hk #Danmark</translation>
    </message>
    <message numerus="no" id="txt_region_SI">
      <source>Slovenija</source>
      <translation variants="no">zh_hk #Slovenija</translation>
    </message>
    <message numerus="no" id="txt_region_HK">
      <source>香港</source>
      <translation variants="no">zh_hk #香港</translation>
    </message>
    <message numerus="no" id="txt_region_LT">
      <source>Lietuva</source>
      <translation variants="no">zh_hk #Lietuva</translation>
    </message>
    <message numerus="no" id="txt_region_IT">
      <source>Italia</source>
      <translation variants="no">zh_hk #Italia</translation>
    </message>
    <message numerus="no" id="txt_region_KR">
      <source>한국</source>
      <translation variants="no">zh_hk #한국</translation>
    </message>
    <message numerus="no" id="txt_region_ES">
      <source>España</source>
      <translation variants="no">zh_hk #España</translation>
    </message>
    <message numerus="no" id="txt_region_SE">
      <source>Sverige</source>
      <translation variants="no">zh_hk #Sverige</translation>
    </message>
    <message numerus="no" id="txt_region_TW">
      <source>台灣</source>
      <translation variants="no">zh_hk #台灣</translation>
    </message>
    <message numerus="no" id="txt_region_CN">
      <source>中国</source>
      <translation variants="no">zh_hk #中国</translation>
    </message>
    <message numerus="no" id="txt_region_LV">
      <source>Latvija</source>
      <translation variants="no">zh_hk #Latvija</translation>
    </message>
    <message numerus="no" id="txt_region_MY">
      <source>Malaysia</source>
      <translation variants="no">zh_hk #Malaysia</translation>
    </message>
    <message numerus="no" id="txt_region_GB">
      <source>United Kingdom</source>
      <translation variants="no">zh_hk #United Kingdom</translation>
    </message>
    <message numerus="no" id="txt_region_AE">
      <source>الإمارات العربية المتحدة</source>
      <translation variants="no">zh_hk #الإمارات العربية المتحدة</translation>
    </message>
    <message numerus="no" id="txt_region_UA">
      <source>Україна</source>
      <translation variants="no">zh_hk #Україна</translation>
    </message>
    <message numerus="no" id="txt_region_PL">
      <source>Polska</source>
      <translation variants="no">zh_hk #Polska</translation>
    </message>
    <message numerus="no" id="txt_region_GR">
      <source>Ελλάδα</source>
      <translation variants="no">zh_hk #Ελλάδα</translation>
    </message>
    <message numerus="no" id="txt_region_NO">
      <source>Norge</source>
      <translation variants="no">zh_hk #Norge</translation>
    </message>
  </context>
</TS>