<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cam_title_geotagging">
      <source>Geotagging</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Geotagging</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_169_widescreen">
      <source>VGA 16:9 widescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #VGA 16:9 widescreen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode_video">
      <source>Scene mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Scene mode</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_geotagging_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene_video">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Automatic</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_camera">
      <source>Camera</source>
      <translation variants="no">uk #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_grid_sharpness">
      <source>Sharpness</source>
      <translation variants="no">uk #Sharpness</translation>
    </message>
    <message numerus="no" id="txt_cam_list_flash_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_flash_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #On</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_fullscreen_imagesleft">
      <source>%L1</source>
      <translation variants="no">uk #%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_title_sharpness">
      <source>Sharpness</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Sharpness</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_contrast">
      <source>Contrast</source>
      <translation variants="yes">
        <lengthvariant priority="1">Контрастність</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sports">
      <source>Sports</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Sport</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode">
      <source>Camera in stand-by mode</source>
      <translation variants="no">Камера в режимі очікування</translation>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="yes">
        <lengthvariant priority="1">Компенсація експозиції</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_landscape">
      <source>Landscape</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Landscape</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_never">
      <source>Never</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Never</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_portrait">
      <source>Portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings">
      <source>Camera settings</source>
      <translation variants="no">Установки камери</translation>
    </message>
    <message numerus="no" id="txt_short_caption_camera">
      <source>Camera</source>
      <translation variants="no">uk #Camera</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_video">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ніч</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Скасувати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">Визначає користувач</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">Безперервно</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds">
      <source>%Ln seconds</source>
      <translation>
        <numerusform plurality="a">%Ln секунда</numerusform>
        <numerusform plurality="b">%Ln секунди</numerusform>
        <numerusform plurality="c">%Ln секунд</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image">
      <source>Delete image?</source>
      <translation variants="no">Видалити зображення?</translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip">
      <source>Delete video clip?</source>
      <translation variants="no">Видалити відеокліп?</translation>
    </message>
    <message numerus="no" id="txt_cam_list_white">
      <source>Black and white</source>
      <translation variants="yes">
        <lengthvariant priority="1">Чорно-білий</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_night">
      <source>Night</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ніч</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left">
      <source>%Ln images left</source>
      <translation>
        <numerusform plurality="a">Залишилося %Ln зображення</numerusform>
        <numerusform plurality="b">Залишилося %Ln зображення</numerusform>
        <numerusform plurality="c">Залишилося %Ln зображень</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer">
      <source>Self timer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Автотаймер</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_whitebal">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Автоматично</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_start">
      <source>Start</source>
      <translation variants="yes">
        <lengthvariant priority="1">Почати</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings">
      <source>General settings</source>
      <translation variants="no">Установки</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_flash">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Автоматично</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_contrast">
      <source>Contrast</source>
      <translation variants="no">uk #Contrast</translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality">
      <source>Image quality</source>
      <translation variants="yes">
        <lengthvariant priority="1">Якість зображення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">Безперервно</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_negative">
      <source>Negative</source>
      <translation variants="yes">
        <lengthvariant priority="1">Негатив</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality">
      <source>Video quality</source>
      <translation variants="yes">
        <lengthvariant priority="1">Якість відео</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality">
      <source>Video quality</source>
      <translation variants="no">Якість відео</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_169_widescreen">
      <source>HD 720p 16:9 widescreen</source>
      <translation variants="yes">
        <lengthvariant priority="1">HD 720 п 16:9, широкий екран</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_val_ln_recording_time_left">
      <source>Recording time left: %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">Залишилося часу записув.: %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance">
      <source>White balance</source>
      <translation variants="yes">
        <lengthvariant priority="1">Баланс білого</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln секунду</numerusform>
        <numerusform plurality="b">%Ln секунди</numerusform>
        <numerusform plurality="c">%Ln секунд</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_not_video">
      <source>Not</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ні</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_incandescent">
      <source>Incandescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">Лампа розжарювання</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_geotagging">
      <source>Geotagging</source>
      <translation variants="no">uk #Geotagging</translation>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity">
      <source>Light sensitivity</source>
      <translation variants="yes">
        <lengthvariant priority="1">Світлочутливість</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_closeup">
      <source>Close-up</source>
      <translation variants="yes">
        <lengthvariant priority="1">Режим зблизька</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_sunny">
      <source>Sunny</source>
      <translation variants="yes">
        <lengthvariant priority="1">Сонячно</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln секунду</numerusform>
        <numerusform plurality="b">%Ln секунди</numerusform>
        <numerusform plurality="c">%Ln секунд</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">uk #Exposure compensation</translation>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone">
      <source>Color tone</source>
      <translation variants="no">uk #Colour tone</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_timer">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Вимкн.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name">
      <source>Default image name</source>
      <translation variants="no">Станд. назва зображення</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_43">
      <source>VGA 4:3</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA 4:3</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_qcif_sharing">
      <source>QCIF Sharing</source>
      <translation variants="yes">
        <lengthvariant priority="1">Обмін QCIF</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_fluorescent">
      <source>Fluorescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">Флуоресцентна лампа</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality">
      <source>Image quality</source>
      <translation variants="no">Якість зображення</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga">
      <source>VGA</source>
      <translation variants="yes">
        <lengthvariant priority="1">VGA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance">
      <source>White balance</source>
      <translation variants="no">uk #White balance</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sepia">
      <source>Sepia</source>
      <translation variants="yes">
        <lengthvariant priority="1">Сепія</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">Показувати зробл. фото</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos">
      <source>Go to 'Videos'</source>
      <translation variants="no">Відеокліпи</translation>
    </message>
    <message numerus="no" id="txt_cam_list_scene_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #On</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_lightsens">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Автоматично</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone">
      <source>Color tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Тон кольору</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_iso_l1">
      <source>ISO %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #ISO %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_cloudy">
      <source>Cloudy</source>
      <translation variants="yes">
        <lengthvariant priority="1">Хмарно</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video">
      <source>Show captured video</source>
      <translation variants="yes">
        <lengthvariant priority="1">Показувати створене відео</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking">
      <source>Face tracking</source>
      <translation variants="no">uk #Face detection</translation>
    </message>
    <message numerus="no" id="txt_cam_list_vivid">
      <source>Vivid</source>
      <translation variants="yes">
        <lengthvariant priority="1">Яскравий</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus">
      <source>-%L1</source>
      <translation variants="no">-%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_portrait">
      <source>Night portrait</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Night portrait</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">Показув. створене відео</translation>
    </message>
    <message numerus="no" id="txt_cam_list_reduce_red_eye">
      <source>Reduce red eye</source>
      <translation variants="yes">
        <lengthvariant priority="1">Усунення ефекту червоних очей</lengthvariant>
        <lengthvariant priority="2">Усун. ефекту черв. очей</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_camera">
      <source>Camera</source>
      <translation variants="no">Камера</translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode">
      <source>Scene mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">Режим зйомки</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image">
      <source>Show captured image</source>
      <translation variants="yes">
        <lengthvariant priority="1">Показув. створене зображення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_iso">
      <source>ISO</source>
      <translation variants="no">uk #ISO</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name">
      <source>Default video name</source>
      <translation variants="no">Стандартна назва відео</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Автоматично</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">Камера</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix">
      <source>%Ln Mpix</source>
      <translation>
        <numerusform plurality="a">%Ln Мп</numerusform>
        <numerusform plurality="b">%Ln Мп</numerusform>
        <numerusform plurality="c">%Ln Мп</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_set_as_default_scene_mode">
      <source>Set as default scene mode</source>
      <translation variants="no">Уст. як станд. реж. зйомки</translation>
    </message>
    <message numerus="no" id="txt_cam_list_normal">
      <source>Normal</source>
      <translation variants="yes">
        <lengthvariant priority="1">Звичайний</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix_widescreen">
      <source>%Ln Mpix widescreen</source>
      <translation>
        <numerusform plurality="a">%Ln Мп, широкий екран</numerusform>
        <numerusform plurality="b">%Ln Мп, широкий екран</numerusform>
        <numerusform plurality="c">%Ln Мп, широкий екран</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">Звук зйомки</translation>
    </message>
    <message numerus="no" id="txt_cam_list_geotagging_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #On</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer">
      <source>Self timer</source>
      <translation variants="no">Автотаймер</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos">
      <source>Go to Photos</source>
      <translation variants="no">Фотографії</translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus">
      <source>+%L1</source>
      <translation variants="no">+%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode">
      <source>Flash mode</source>
      <translation variants="yes">
        <lengthvariant priority="1">Спалах</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound">
      <source>Video sound</source>
      <translation variants="no">Звук відео</translation>
    </message>
    <message numerus="no" id="txt_cam_list_low_light">
      <source>Low light</source>
      <translation variants="yes">
        <lengthvariant priority="1">Слабке освітлення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use">
      <source>Camera already in use</source>
      <translation variants="no">Камера вже використовується іншою програмою</translation>
    </message>
    <message numerus="no" id="txt_cam_list_scene_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Off</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_error">
      <source>Unexpected error occurred. Power off the device and restart</source>
      <translation variants="no">Несподівана помилка. Перезапустіть телефон.</translation>
    </message>
  </context>
</TS>