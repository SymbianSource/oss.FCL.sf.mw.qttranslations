<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_notes_formlabel_val_description">
      <source>Description</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mô tả</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chủ đề</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_add_to_calendar">
      <source>Add to Calendar</source>
      <translation variants="no">vi #Add to Calendar</translation>
    </message>
    <message numerus="no" id="txt_notes_button_send">
      <source>Send</source>
      <translation variants="no">vi #Send</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_todo">
      <source>To-do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú công việc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_new_note">
      <source>New note</source>
      <translation variants="no">vi #New note</translation>
    </message>
    <message numerus="no" id="txt_notes_title_due_date">
      <source>Due date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày hết hạn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_note">
      <source>Note</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_low">
      <source>Low</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thấp</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_new_note_saved">
      <source>New note saved</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã lưu lại ghi chú mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thời gian phát âm báo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_due_date">
      <source>Due date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày kết thúc:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_description">
      <source>Remove description</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa mô tả</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_alarm_date">
      <source>%2</source>
      <translation variants="yes">
        <lengthvariant priority="1">%2</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày phát âm báo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Change to to-do note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Remove from favourites</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_new_note">
      <source>New note</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #New note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_saved">
      <source>Note saved</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã lưu lại ghi chú</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_new_todo">
      <source>New To-do</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú công việc mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Add to favourites</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày giờ phát âm báo:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_add_description">
      <source>Add description</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thêm mô tả:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_due_date">
      <source>%1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_alarm_time">
      <source>%1</source>
      <translation variants="yes">
        <lengthvariant priority="1">%1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_high">
      <source>High</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cao</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Discard changes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority">
      <source>Priority</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ưu tiên:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_new_todo_note_saved">
      <source>New To-do note saved</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã lưu lại ghi chú công việc mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_todo_note_saved">
      <source>To-do note saved</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã lưu lại ghi chú công việc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_dialog_delete">
      <source>Delete</source>
      <translation variants="no">vi #Delete</translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_normal">
      <source>Normal</source>
      <translation variants="yes">
        <lengthvariant priority="1">Bình thường</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_delete">
      <source>Delete</source>
      <translation variants="no">vi #Delete</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_note">
      <source>Delete note?</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa ghi chú?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_edit_time">
      <source>%1 %2</source>
      <translation variants="no">vi #%1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa ghi chú công việc?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">Âm báo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">vi #Open</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="no">vi #Cancel</translation>
    </message>
    <message numerus="no" id="txt_common_menu_send_item">
      <source>Send</source>
      <translation variants="no">vi #Send</translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">vi #Delete</translation>
    </message>
    <message numerus="no" id="txt_common_menu_edit">
      <source>Edit</source>
      <translation variants="no">vi #Edit</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="no">vi #Unnamed</translation>
    </message>
    <message numerus="no" id="txt_common_opt_send_item">
      <source>Send</source>
      <translation variants="no">vi #Send</translation>
    </message>
    <message numerus="no" id="txt_common_opt_delete">
      <source>Delete</source>
      <translation variants="no">vi #Delete</translation>
    </message>
  </context>
</TS>