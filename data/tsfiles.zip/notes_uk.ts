<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_notes_dblist_val_modified_on_1">
      <source>Modified on %1</source>
      <translation variants="no">uk #Modified on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_completed_on_1">
      <source>Completed on %1</source>
      <translation variants="no">uk #Completed on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_subtitle_date">
      <source>&lt;Date&gt;</source>
      <translation variants="no">uk #Select date</translation>
    </message>
    <message numerus="no" id="txt_notes_list_todos">
      <source>To-Do's</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #To-do notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subtitle_collections">
      <source>Collections</source>
      <translation variants="no">uk #Collections</translation>
    </message>
    <message numerus="no" id="txt_notes_subtitle_note">
      <source>Note</source>
      <translation variants="no">uk #Note</translation>
    </message>
    <message numerus="no" id="txt_notes_subtitle_all">
      <source>All</source>
      <translation variants="no">uk #All</translation>
    </message>
    <message numerus="no" id="txt_notes_list_ln">
      <source>%Ln</source>
      <translation variants="no">uk #%Ln</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_created_on_1">
      <source>Created on %1</source>
      <translation variants="no">uk #Created on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">uk #Mark as done</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_collections">
      <source>Not specified</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Folders</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="no">uk #Add to favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_list_favourites">
      <source>Favourites</source>
      <translation variants="no">uk #Favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_title_notes">
      <source>Notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_list_recent_notes">
      <source>Recent notes</source>
      <translation variants="no">uk #Recent notes</translation>
    </message>
    <message numerus="no" id="txt_notes_button_add_to_calendar">
      <source>Add to Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Save to Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_date">
      <source>Not specified</source>
      <translation variants="no">uk #Date</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">uk #Discard changes</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_share">
      <source>Share</source>
      <translation variants="no">uk #Share folders</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">uk #Remove from favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_add_attachment">
      <source>Add attachment</source>
      <translation variants="no">uk #Add attachment</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_favorite">
      <source>Mark as favorite</source>
      <translation variants="no">uk #Add to favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_subtitle_new_note">
      <source>New note</source>
      <translation variants="no">uk #New note</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">uk #Due on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="no">uk #Change to to-do note</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_refresh">
      <source>Not specified</source>
      <translation variants="no">uk #Refresh</translation>
    </message>
    <message numerus="no" id="txt_short_caption_notes">
      <source>Notes</source>
      <translation variants="no">uk #Notes</translation>
    </message>
    <message numerus="no" id="txt_long_caption_notes">
      <source>Notes</source>
      <translation variants="no">uk #Notes</translation>
    </message>
    <message numerus="no" id="txt_notes_title_alarm_time">
      <source>Alarm time</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Alarm time</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Completed date:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_alarm_date">
      <source>0.02</source>
      <translation variants="no">uk #0.02</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_notes">
      <source>Notes</source>
      <translation variants="no">uk #Notes</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Unnamed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_moved_to_todos">
      <source>Note moved to To-do's</source>
      <translation variants="no">uk #Note moved to To-do's</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_new_note">
      <source>New note</source>
      <translation variants="no">uk #New note</translation>
    </message>
    <message numerus="no" id="txt_notes_title_alarm_date">
      <source>Alarm date</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Alarm date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_completed_date_val_1">
      <source>0.01</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #0.01</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_on_date">
      <source>Created on %1</source>
      <translation variants="no">uk #Created on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_button_alarm_time">
      <source>0.01</source>
      <translation variants="no">uk #0.01</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_todo_note_saved">
      <source>To-do note saved</source>
      <translation variants="no">uk #To-do note saved</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_at_time">
      <source>Modified at %1</source>
      <translation variants="no">uk #Modified at %1</translation>
    </message>
    <message numerus="no" id="txt_notes_list_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Favorites</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_edit_time">
      <source>%1 %2</source>
      <translation variants="no">uk #%1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_list_alarm_date">
      <source>%1 %2</source>
      <translation variants="no">uk #%1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_title_due_date">
      <source>Due date</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Due date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_remove_description">
      <source>Remove description</source>
      <translation variants="no">uk #Remove description</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_note_saved">
      <source>Note saved</source>
      <translation variants="no">uk #Note saved</translation>
    </message>
    <message numerus="no" id="txt_notes_list_note_count">
      <source>[ %1 ]</source>
      <translation variants="no">uk #[ %1 ]</translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_high">
      <source>High</source>
      <translation variants="no">uk #High</translation>
    </message>
    <message numerus="no" id="txt_notes_button_collections">
      <source>Collections</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Collections</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority">
      <source>Priority</source>
      <translation variants="no">uk #Priority</translation>
    </message>
    <message numerus="yes" id="txt_notes_subhead_todos_ln_pending">
      <source>To-do's (%Ln Pending )</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_val_description">
      <source>Description</source>
      <translation variants="no">uk #Description</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">uk #Subject</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_created_at_time">
      <source>Created at %1</source>
      <translation variants="no">uk #Created at %1</translation>
    </message>
    <message numerus="yes" id="txt_notes_subhead_ln_notes">
      <source>%Ln Notes</source>
      <translation>
        <numerusform plurality="a">uk #MISSING</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_add_description">
      <source>Add description</source>
      <translation variants="no">uk #Add description</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">uk #Delete To-do note?</translation>
    </message>
    <message numerus="no" id="txt_notes_list_no_notes_available">
      <source>No notes available</source>
      <translation variants="no">uk #No notes available</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Unnamed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">uk #Mark as done</translation>
    </message>
    <message numerus="no" id="txt_notes_button_find">
      <source>Find</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Find</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_new_note">
      <source>New note</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #New note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_due_date">
      <source>0.01</source>
      <translation variants="no">uk #0.01</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_plain_notes">
      <source>Plain notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Plain notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_todo_notes">
      <source>Delete To-do notes?</source>
      <translation variants="no">uk #Delete To-do notes?</translation>
    </message>
    <message numerus="no" id="txt_notes_button_edit">
      <source>Edit</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Edit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_new_todo_note_saved">
      <source>New To-do note saved</source>
      <translation variants="no">uk #New To-do note saved</translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_created_on_1_2">
      <source>Created on %1 %2</source>
      <translation variants="no">uk #Created on %1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_due_date">
      <source>Due date</source>
      <translation variants="no">uk #Due date</translation>
    </message>
    <message numerus="no" id="txt_notes_opt_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">uk #Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_notes_dpopinfo_new_note_saved">
      <source>New note saved</source>
      <translation variants="no">uk #New note saved</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_new_todo">
      <source>New To-do</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #New To-do</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_note_modified_on_date">
      <source>Modified on %1</source>
      <translation variants="no">uk #Modified on %1</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_add_to_calendar">
      <source>Add to Calendar</source>
      <translation variants="no">uk #Add to Calendar</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_alarm">
      <source>Alarm</source>
      <translation variants="no">uk #Alarm</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_all">
      <source>Not specified</source>
      <translation variants="no">uk #All</translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_low">
      <source>Low</source>
      <translation variants="no">uk #Low</translation>
    </message>
    <message numerus="no" id="txt_notes_button_dialog_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_note">
      <source>Not specified</source>
      <translation variants="no">uk #Note</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_recent_notes">
      <source>Not specified</source>
      <translation variants="no">uk #Recent notes</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_todo">
      <source>To-do</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #To-do</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_val_modified_on_1_2">
      <source>Modified on %1 %2</source>
      <translation variants="no">uk #Modified on %1 %2</translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_note">
      <source>Delete note?</source>
      <translation variants="no">uk #Delete note?</translation>
    </message>
    <message numerus="no" id="txt_notes_setlabel_priority_val_normal">
      <source>Normal</source>
      <translation variants="no">uk #Normal</translation>
    </message>
    <message numerus="no" id="txt_notes_formlabel_alarm_date_and_time">
      <source>Alarm date and time</source>
      <translation variants="no">uk #Alarm date and time</translation>
    </message>
    <message numerus="no" id="txt_notes_subtitle_recent_notes">
      <source>Recent notes</source>
      <translation variants="no">uk #Recent notes</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_make_it_as_todo_note">
      <source>Make it as To-do note</source>
      <translation variants="no">uk #Change to to-do note</translation>
    </message>
    <message numerus="no" id="txt_notes_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">uk #Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_new_note">
      <source>Not specified</source>
      <translation variants="no">uk #New note</translation>
    </message>
    <message numerus="no" id="txt_notes_list_due_date">
      <source>0.01</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #0.01</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_new_todo">
      <source>New To-do </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #New To-do </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Description:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_dblist_subject">
      <source>Subject:</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Subject:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_button_all_notes">
      <source>All notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #All notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_list_plain_notes">
      <source>Plain notes</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Plain notes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_notes_info_delete_notes">
      <source>Delete notes?</source>
      <translation variants="no">uk #Delete notes?</translation>
    </message>
    <message numerus="no" id="txt_notes_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">uk #Remove from favourites</translation>
    </message>
    <message numerus="no" id="txt_notes_subhead_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Favorites</lengthvariant>
      </translation>
    </message>
  </context>
</TS>