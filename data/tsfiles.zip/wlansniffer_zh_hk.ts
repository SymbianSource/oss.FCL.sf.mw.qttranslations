<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_grid_not_connected">
      <source>Not connected</source>
      <translation variants="no">未連接</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_connected_to_1">
      <source>Connected to '%1'</source>
      <translation variants="no">已連接至"%[99]1"</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_connecting_to_1">
      <source>Connecting to '%1'</source>
      <translation variants="no">正在連接至"%[99]1"</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_opt_add_new_wlan">
      <source>Add new WLAN</source>
      <translation variants="no">新增WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_title_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_wlansniffer">
      <source>Wireless LAN</source>
      <translation variants="no">WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_info_activate_wlan_in_airplane_mode">
      <source>Allow WLAN connections during this offline session?</source>
      <translation variants="no">是否在此次離線期間允許WLAN連接？</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_wlan_is_switched_off">
      <source>WLAN is switched off</source>
      <translation variants="no">WLAN已關閉</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_switch_wlan_on">
      <source>Switch WLAN on</source>
      <translation variants="no">開啟WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_switch_wlan_off">
      <source>Switch WLAN off</source>
      <translation variants="no">關閉WLAN</translation>
    </message>
  </context>
</TS>