<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_opt_switch_wlan_on">
      <source>Switch WLAN on</source>
      <translation variants="no">zh_hk ##Switch WLAN on</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_switch_wlan_off">
      <source>Switch WLAN off</source>
      <translation variants="no">zh_hk ##Switch WLAN off</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Wireless LAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_title_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Wireless LAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_wlansniffer">
      <source>Wireless LAN</source>
      <translation variants="no">zh_hk ##Wireless LAN</translation>
    </message>
    <message numerus="no" id="txt_occ_menu_network_settings">
      <source>Network settings</source>
      <translation variants="no">網絡設定</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_connecting_to_1">
      <source>Connecting to '%1'</source>
      <translation variants="no">zh_hk ##Connecting to '%1'</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_not_connected">
      <source>Not connected</source>
      <translation variants="no">zh_hk ##Not connected</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_wlan_is_switched_off">
      <source>WLAN is switched off</source>
      <translation variants="no">zh_hk ##WLAN is switched off</translation>
    </message>
    <message numerus="no" id="txt_occ_menu_details">
      <source>Details</source>
      <translation variants="no">資料</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_add_new_wlan">
      <source>Add new WLAN</source>
      <translation variants="no">zh_hk ##Add new WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_grid_connected_to_1">
      <source>Connected to '%1'</source>
      <translation variants="no">zh_hk ##Connected to '%1'</translation>
    </message>
    <message numerus="no" id="txt_occ_menu_disable_network">
      <source>Disable network</source>
      <translation variants="no">停用網絡</translation>
    </message>
  </context>
</TS>