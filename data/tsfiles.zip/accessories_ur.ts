<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_accessories_dblist_menu_loopset">
      <source>Loopset</source>
      <translation variants="no">ur #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="no">۱۶:۹</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">ur #Wired car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headse">
      <source>Headset</source>
      <translation variants="no">ہیڈسیٹ</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">ur #Wireless car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">ur #Wireless car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">TV تاثر تناسب</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headset">
      <source>Headset</source>
      <translation variants="no">ur #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Wired car kit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_wired">
      <source>Wired carkit</source>
      <translation variants="no">ur #Wired car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_automatic">
      <source>Automatic</source>
      <translation variants="no">ur #Automatic</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_loopse">
      <source>Loopset</source>
      <translation variants="no">ur #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headphones">
      <source>Headphones</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Headphones</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headph">
      <source>Headphones</source>
      <translation variants="no">ur #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="yes">
        <lengthvariant priority="1">متنی فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہیڈسیٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Wireless car kit</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headphones">
      <source>Headphones</source>
      <translation variants="no">ur #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headset">
      <source>Headset</source>
      <translation variants="no">ur #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="no">۴:۳</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_on">
      <source>On</source>
      <translation variants="no">ur #On</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_music_stand">
      <source>Music stand</source>
      <translation variants="no">ur #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">اضافی آلات کی قسم</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_loopset">
      <source>Loopset</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Loopset</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_music">
      <source>Music stand</source>
      <translation variants="no">ur #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights">
      <source>Lights</source>
      <translation variants="no">ur #Lights</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_tty">
      <source>TTY</source>
      <translation variants="no">ur #Text phone</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_music_stand">
      <source>Music stand</source>
      <translation variants="no">ur #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_music_stand">
      <source>Music stand</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Music stand</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="no">متنی فون</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_loopset">
      <source>Loopset</source>
      <translation variants="no">ur #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_tty">
      <source>TTY</source>
      <translation variants="no">ur #Text phone</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Accessory</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">ur #Wired car kit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headphones">
      <source>Headphones</source>
      <translation variants="no">ur #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">اضافی آلات ترتیبات</lengthvariant>
        <lengthvariant priority="2">آل. ترتیبات</lengthvariant>
      </translation>
    </message>
  </context>
</TS>