<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="yes">
        <lengthvariant priority="1">۱۶:۹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">اضافی آلات کی قسم</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="yes">
        <lengthvariant priority="1">متنی فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">TV تاثر تناسب</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">اضافی آلہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_info_accessory_not_supported">
      <source>Accessory not supported.</source>
      <translation variants="no">اضافی آلہ تائید شدہ نہیں</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="yes">
        <lengthvariant priority="1">۴:۳</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headset">
      <source>Headset</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہیڈسیٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="yes">
        <lengthvariant priority="1">ہیڈسیٹ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="yes">
        <lengthvariant priority="1">متنی فون</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="yes">
        <lengthvariant priority="1">اضافی آلات ترتیبات</lengthvariant>
        <lengthvariant priority="2">آل. ترتیبات</lengthvariant>
      </translation>
    </message>
  </context>
</TS>