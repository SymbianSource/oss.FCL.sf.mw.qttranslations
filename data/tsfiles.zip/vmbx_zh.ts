<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_vmbx_dpopinfo_define_video_mailbox_number">
      <source>Define video mailbox number</source>
      <translation variants="no">定义视频信箱号码</translation>
    </message>
    <message numerus="no" id="txt_vmbx_title_video_mailbox_number">
      <source>Video mailbox number:</source>
      <translation variants="yes">
        <lengthvariant priority="1">视频信箱号码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_list_video_mailbox">
      <source>Video mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">视频信箱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_dpopinfo_video_mailbox_number_saved">
      <source>Video mailbox number saved</source>
      <translation variants="no">视频信箱号码已存</translation>
    </message>
    <message numerus="yes" id="txt_vmbx_dblist_ln_voice_messages">
      <source>%Ln voice messages</source>
      <translation>
        <numerusform plurality="a">%Ln条语音信息</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_list_voice_mailbox">
      <source>Voice mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">语音信箱</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_vmbx_dpopinfo_ln_voice_messages">
      <source>%Ln new voice messages</source>
      <translation>
        <numerusform plurality="a">%Ln条新语音信息</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_dpopinfo_voice_mailbox_number_saved">
      <source>Voice mailbox number saved</source>
      <translation variants="no">语音信箱号码已存</translation>
    </message>
    <message numerus="no" id="txt_vmbx_dpopinfo_define_voice_mailbox_number">
      <source>Define voice mailbox number</source>
      <translation variants="no">定义语音信箱号码 </translation>
    </message>
    <message numerus="no" id="txt_vmbx_title_select_mailbox">
      <source>Select mailbox:</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择信箱：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_title_voice_mailbox_number">
      <source>Voice mailbox number:</source>
      <translation variants="yes">
        <lengthvariant priority="1">语音信箱号码：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vmbx_dpopinfo_voice_mailbox_not_provisioned">
      <source>Voice mailbox not provisioned</source>
      <translation variants="no">未定义语音信箱号码</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_voice_mailbox">
      <source>Voice mailbox</source>
      <translation variants="no">zh ##Voice mailbox</translation>
    </message>
  </context>
</TS>