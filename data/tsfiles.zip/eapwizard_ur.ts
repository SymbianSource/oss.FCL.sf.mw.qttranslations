<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_new_pac_store_password">
      <source>New PAC store password:</source>
      <translation variants="no">نیا PAC اسٹور لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_provisioning_mode_for_eapfast">
      <source>EAP-FAST provisioning mode</source>
      <translation variants="no">EAP-FAST فراہمی وضع:</translation>
    </message>
    <message numerus="no" id="txt_occ_info_incorrect_password">
      <source>Incorrect password</source>
      <translation variants="no">غیر درست لفظ شناخت</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="no">PAC اسٹور کا لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_no_certificates_installed_wizard_c">
      <source>No certificates installed. Wizard cannot continue.</source>
      <translation variants="no">کسی سند کی تنصیب نہیں کی گئی۔ نظام کو جاری رکھنے سے قاصر۔</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_confirm_password">
      <source>Confirm password:</source>
      <translation variants="no">لفظ شناخت کی تصدیق کریں:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_password">
      <source>Password:</source>
      <translation variants="no">لفظ شناخت:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_for_1">
      <source>User name for '%1':</source>
      <translation variants="no">'%[91]1' کا صارف نام:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_realm">
      <source>Realm:</source>
      <translation variants="no">منطقہ:</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_provisioning_mode_for_val_unauthent">
      <source>Unauthenticated</source>
      <translation variants="no">غیر تصدیق شدہ</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_select_automatically">
      <source>Select automatically</source>
      <translation variants="no">خود کار طور پر منتخب</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_innear_eap_type_for_1">
      <source>Select inner EAP type for '%1':</source>
      <translation variants="no">'%[69]1' کے لیے داخلی EAP قسم منتخب کریں۔</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_eap_type">
      <source>Select EAP type:</source>
      <translation variants="no">EAP قسم متنخب کریں:</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_inner_eap">
      <source>Inner EAP</source>
      <translation variants="no">داخلیی EAP:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_generate_automatic">
      <source>Generate automatically</source>
      <translation variants="no">خود کاری طور پر ساخت</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_authority_certificate">
      <source>Select authority certificate:</source>
      <translation variants="no">تصدیقی سند منتخب کریں:</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_outer_eap">
      <source>Outer EAP</source>
      <translation variants="no">خارجی EAP:</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_user_certificate">
      <source>Select user certificate:</source>
      <translation variants="no">ذاتی سند منتخب کریں:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_check_sim">
      <source>%1 authentication failed. Check SIM card.</source>
      <translation variants="no">%[29]1 تصدیق کاری ناکام۔ SIM کارڈ کی جانچ کریں۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_auth_failed_user_cert_exp">
      <source>%1 authentication failed. User certificate has expired.</source>
      <translation variants="no">%[15]1 تصدیق کاری ناکام۔ ذاتی سند کی مدت ختم ہو چکی ہے۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_cipher_su">
      <source>%1 authentication failed. Cipher suite mismatch.</source>
      <translation variants="no">%[23]1 تصدیق کاری ناکام۔ Cipher suites میں مطابقت نہیں۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_server_ce">
      <source>%1 authentication failed. Server certificate has expired.</source>
      <translation variants="no">%[23]1 تصدیق کاری ناکام۔ سرور سند کی مدت ختم ہوگئی۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed">
      <source>%1 authentication failed</source>
      <translation variants="no">%[54]1 تصدیق کاری ناکام</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_auth_failed_user_cert_rej">
      <source>%1 authentication failed. User certificate not accepted.</source>
      <translation variants="no">%[23]1 تصدیق کاری ناکام۔ ذاتی سند قبول نہیں کی گئی۔</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_realm_val_generate_automatic">
      <source>Generate automatically</source>
      <translation variants="no">خود کاری طور پر ساخت</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_reset_pac">
      <source>%1 authentication failed. Reset PAC store.</source>
      <translation variants="no">%[35]1 تصدیق کاری ناکام۔ PAC اسٹور ہٹائیں۔</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_could_not">
      <source>%1 authentication failed. Could not verify server certificate.</source>
      <translation variants="no">%[15]1 تصدیق کاری ناکام۔ سرور سند کی تصدیق کرنے سے قاصر۔</translation>
    </message>
  </context>
</TS>