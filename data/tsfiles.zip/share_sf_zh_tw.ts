<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_shareui_no_files">
      <source>Unable to share. Selected content contains protected file(s)</source>
      <translation variants="no">zh_tw ##Unable to share. Selected content contains protected file(s)</translation>
    </message>
    <message numerus="no" id="txt_shareui_no_services">
      <source>No services found</source>
      <translation variants="no">zh_tw ##No services found</translation>
    </message>
    <message numerus="no" id="txt_share_dblist_message">
      <source>Message</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Message</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_share_dblist_email">
      <source>E-mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##E-mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_share_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_share_title_sharing_methods">
      <source>Sharing methods</source>
      <translation variants="no">zh_tw ##Sharing methods</translation>
    </message>
    <message numerus="no" id="txt_shareui_service_error">
      <source>Service error</source>
      <translation variants="no">zh_tw ##Service error</translation>
    </message>
    <message numerus="no" id="txt_share_dblist_nfc">
      <source>NFC</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw ##NFC</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_shareui_protected_content">
      <source>Unable to share protected file</source>
      <translation variants="no">zh_tw ##Unable to share protected file</translation>
    </message>
  </context>
</TS>