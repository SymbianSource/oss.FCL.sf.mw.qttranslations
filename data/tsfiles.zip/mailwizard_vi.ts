<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mail_wizard_setup_l_formlabel_outgoing_mail_serv">
      <source>Outgoing mail server</source>
      <translation variants="no">vi #Outgoing mail server</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_l_button_cancel">
      <source>Cancel</source>
      <translation variants="no">vi #Cancel</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_l_formlabel_server_port_val_de">
      <source>default</source>
      <translation variants="no">vi #default</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_incoming_mail_serv">
      <source>Incoming mail server</source>
      <translation variants="no">vi #Incoming mail server</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_button_previous">
      <source>Previous</source>
      <translation variants="no">vi #Previous</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_p_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_p_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_select_protocol_va">
      <source>IMAP4</source>
      <translation variants="no">vi #IMAP4</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_button_next">
      <source>Next</source>
      <translation variants="no">vi #Next</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_server_port">
      <source>Server port</source>
      <translation variants="no">vi #Server port</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_security_type_value">
      <source>TSL</source>
      <translation variants="no">vi #TSL</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_info_updating_mail_provider">
      <source>Updating mail provider list</source>
      <translation variants="no">vi #Updating mail provider list</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_button_cancel">
      <source>Cancel</source>
      <translation variants="no">vi #Cancel</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_security_type_val_none">
      <source>None</source>
      <translation variants="no">vi #None</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_info_please_wait">
      <source>Please wait</source>
      <translation variants="no">vi #Please wait</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_security_type_val_ssl">
      <source>SSL</source>
      <translation variants="no">vi #SSL</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_button_finish">
      <source>Finish</source>
      <translation variants="no">vi #Finish</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_button_finish">
      <source>Finish</source>
      <translation variants="no">vi #Finish</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_security_type">
      <source>Security type</source>
      <translation variants="no">vi #Security type</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_dialog_mail_address">
      <source>Mail address</source>
      <translation variants="no">vi #Mail address</translation>
    </message>
    <message numerus="no" id="txt_common_button_no">
      <source>No</source>
      <translation variants="no">vi #No</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_select_protocol_imap">
      <source>IMAP4</source>
      <translation variants="no">vi #IMAP4</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_select_protocol">
      <source>Select protocol</source>
      <translation variants="no">vi #Select protocol</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_dialog_your_ovi_password">
      <source>Your Ovi password</source>
      <translation variants="no">vi #Your Ovi password</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_title_username_needed">
      <source>Username needed</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Username needed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_l_formlabel_select_protocol">
      <source>Select protocol</source>
      <translation variants="no">vi #Select protocol</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mailwizard">
      <source>Mail Wizard</source>
      <translation variants="no">vi #Mail Wizard</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_button_cancel_setup">
      <source>Cancel setup</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Cancel setup</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_button_ok">
      <source>OK</source>
      <translation variants="no">vi #OK</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_dblist_val_sign_in">
      <source>Sign in</source>
      <translation variants="no">vi #Sign in</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_button_continue">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Continue</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_dblist_val_sign_in_for_ovi_u">
      <source>Sign in for Ovi users</source>
      <translation variants="no">vi #Sign in for Ovi users</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_dblist_val_sign_in_for_ovi_u">
      <source>Sign in for Ovi users</source>
      <translation variants="no">vi #Sign in for Ovi users</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_button_continue">
      <source>Continue</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Continue</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_security_type_ssl">
      <source>SSL</source>
      <translation variants="no">vi #SSL</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_server_port_val_de">
      <source>default</source>
      <translation variants="no">vi #default</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_dblist_other">
      <source>Other</source>
      <translation variants="no">vi #Other</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_dialog_username">
      <source>Username</source>
      <translation variants="no">vi #Username</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_dblist_add_mailbox_details">
      <source>Server, security and port</source>
      <translation variants="no">vi #Server, security and port</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_l_dialog_your_ovi_password">
      <source>Your Ovi password</source>
      <translation variants="no">vi #Your Ovi password</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_outgoing_mail_serv">
      <source>Outgoing mail server</source>
      <translation variants="no">vi #Outgoing mail server</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_select_protocol_pop">
      <source>POP3</source>
      <translation variants="no">vi #POP3</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_l_formlabel_select_protocol_va">
      <source>POP3</source>
      <translation variants="no">vi #POP3</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_l_formlabel_security_type">
      <source>Security type</source>
      <translation variants="no">vi #Security type</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_info_the_username_could_not">
      <source>The username could not be fetched automatically. Please, fill in the username to continue.</source>
      <translation variants="no">vi #The username could not be fetched automatically. Please, fill in the username to continue.</translation>
    </message>
    <message numerus="no" id="txt_common_button_yes">
      <source>Yes</source>
      <translation variants="no">vi #Yes</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_dblist_add_mailbox_details_v">
      <source>Mail address and password</source>
      <translation variants="no">vi #Mail address and password</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_formlabel_what_mail_address_do_y">
      <source>What mail address do you want?</source>
      <translation variants="no">vi #What mail address do you want?</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dpopinfo_the_username_could_not">
      <source>Cancel mail setup</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Cancel mail setup</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_list_by_selecting_next_you_agre">
      <source>By selecting Next, you agree to the service terms and privacy policy.</source>
      <translation variants="no">vi #By selecting Next, you agree to the service terms and privacy policy.</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dblist_password_recovery">
      <source>Password recovery</source>
      <translation variants="no">vi #Password recovery</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dpophead_username_needed">
      <source>Unable to setup mailbox</source>
      <translation variants="no">vi #Unable to setup mailbox</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_title_synchronizing">
      <source>If you cancel the mail setup the information you have filled will be lost. Are you sure you want to cancel?</source>
      <translation variants="no">vi #If you cancel the mail setup the information you have filled will be lost. Are you sure you want to cancel?</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_list_send_me_updates_about_ovi_s">
      <source>Send me updates about Ovi services</source>
      <translation variants="no">vi #Send me updates about Ovi services</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_setlabel_val_security_type">
      <source>Security type</source>
      <translation variants="no">vi #Security type</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_title_server_connection_error">
      <source>Username needed</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Username needed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dblist_add_mailbox_val_mail_add">
      <source>Mail address and password</source>
      <translation variants="no">vi #Mail address and password</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dblist_dont_have_mail_address">
      <source>Don't have mail address?</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Don't have mail address?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dialog_password">
      <source>Password</source>
      <translation variants="no">vi #Password</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dblist_get_your_free_val_please">
      <source>Please write the mail address you want and password.</source>
      <translation variants="no">vi #Please write the mail address you want and password.</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dblist_updating_mail_isp_list">
      <source>Updating mail provider list</source>
      <translation variants="no">vi #Updating mail provider list</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_info_it_is_recommended_not_to_us">
      <source>All mailboxes in use</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #All mailboxes in use</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailwiz_button_previous">
      <source>Previous</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Previous</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailwiz_formlabel_select_protocol_val_imap4">
      <source>IMAP4</source>
      <translation variants="no">vi #IMAP4</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dpophead_sim_card_required">
      <source>SIM card required</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #SIM card required</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_button_ok">
      <source>Not specified</source>
      <translation variants="no">vi #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dblist_ovicom_is_already_taken">
      <source>@ovi.com is already taken.</source>
      <translation variants="no">vi #@ovi.com is already taken.</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_title_is_the_mail_address_correc">
      <source>Verify the mail address</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Verify the mail address</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_setlabel_val_none">
      <source>None</source>
      <translation variants="no">vi #None</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dblist_server_port">
      <source>Server port</source>
      <translation variants="no">vi #Server port</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dpopinfo_unable_to_setup_mailbox">
      <source>Not specified</source>
      <translation variants="no">vi #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dpophead_cancel_mail_setup">
      <source>Not specified</source>
      <translation variants="no">vi #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_info_this_device_requires_a_sim">
      <source>This device requires a SIM card to setup mail. Please check the SIM card is in the device and try again.</source>
      <translation variants="no">vi #This device requires a SIM card to setup mail. Please check the SIM card is in the device and try again.</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dblist_password_recovery_val_the">
      <source>The password will be send to you via SMS in case you forgot it</source>
      <translation variants="no">vi #The password will be send to you via SMS in case you forgot it</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dblist_updating_mail_isp_va">
      <source>Please wait</source>
      <translation variants="no">vi #Please wait</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_formlabel_password_at_least_ln">
      <source>Password (at least Ln% characters)</source>
      <translation variants="no">vi #Password (at least Ln% characters)</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_formlabel_select_protocol">
      <source>Select protocol</source>
      <translation variants="no">vi #Select protocol</translation>
    </message>
    <message numerus="no" id="txt_common_button_finish">
      <source>Finish</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Finish</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_info_unable_to_connect_to_server">
      <source>The username could not be fetched automatically. Please, fill in the username to continue.</source>
      <translation variants="no">vi #The username could not be fetched automatically. Please, fill in the username to continue.</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dblist_add_mailbox_details">
      <source>Please add mailbox details</source>
      <translation variants="no">vi #Please add mailbox details</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dblist_server_port_val_default">
      <source>default</source>
      <translation variants="no">vi #default</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dblist_ovicom_is_already_val_h">
      <source>Here is a proposed mail address. If you prefer, you can change it.</source>
      <translation variants="no">vi #Here is a proposed mail address. If you prefer, you can change it.</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_info_you_have_reached_the_maximu">
      <source>You have reached the maximum limit of mailboxes. Please delete one of existing mailboxes to create new.</source>
      <translation variants="no">vi #You have reached the maximum limit of mailboxes. Please delete one of existing mailboxes to create new.</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_subtitle_select_mail_provider">
      <source>Select mail type</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Select mail type</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_title_all_mailboxes_in_use">
      <source>All mailboxes in use</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #All mailboxes in use</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailwiz_button_next">
      <source>Not specified</source>
      <translation variants="no">vi #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_by_selecting_ok_you_agree_to_t">
      <source>By selecting OK, you agree to the service terms and privacy policy.</source>
      <translation variants="no">vi #By selecting OK, you agree to the service terms and privacy policy.</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dpopinfo_if_you_cancel_the_mail">
      <source>Not specified</source>
      <translation variants="no">vi #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dialog_incoming_mail_server">
      <source>Server, security and port</source>
      <translation variants="no">vi #Server, security and port</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dblist_dont_have_mail_val_create_ovi">
      <source>Get OVI mail now!</source>
      <translation variants="no">vi #Get OVI mail now!</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dialog_mail_address">
      <source>Mail address</source>
      <translation variants="no">vi #Mail address</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dialog_if_the_address_entry_mail">
      <source>Not specified</source>
      <translation variants="no">vi #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_setup_dblist_creating_mailbox">
      <source>Creating mailbox</source>
      <translation variants="no">vi #Creating mailbox</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_setup_button_next">
      <source>Next</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Next</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_button_ok">
      <source>OK</source>
      <translation variants="no">vi #OK</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_setup_dblist_creating_mailbox_va">
      <source>Please wait</source>
      <translation variants="no">vi #Please wait</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_setup_subtitle_mail_setup">
      <source>Mail setup</source>
      <translation variants="no">vi #Mail setup</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_security_type_val">
      <source>None</source>
      <translation variants="no">vi #None</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_security_type_tsl">
      <source>TSL</source>
      <translation variants="no">vi #TSL</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_dialog_password">
      <source>Password</source>
      <translation variants="no">vi #Password</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_l_formlabel_server_port">
      <source>Server port</source>
      <translation variants="no">vi #Server port</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_l_dialog_username">
      <source>Username</source>
      <translation variants="no">vi #Username</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dpophead_unable_to_setup_mailbox">
      <source>You have reached the maximum limit of Mail for Exchange mailboxes. Please delete existing mailbox to create new.</source>
      <translation variants="no">vi #You have reached the maximum limit of Mail for Exchange mailboxes. Please delete existing mailbox to create new.</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_setlabel_val_tsl">
      <source>TSL</source>
      <translation variants="no">vi #TSL</translation>
    </message>
    <message numerus="no" id="txt_mail_wizard_setup_formlabel_incoming_mail_server">
      <source>Incoming mail server</source>
      <translation variants="no">vi #Incoming mail server</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_formlabel_username">
      <source>Username</source>
      <translation variants="no">vi #Username</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_formlabel_select_protocol_val_pop3">
      <source>POP3</source>
      <translation variants="no">vi #POP3</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dblist_get_your_free_ovi_mail_fr">
      <source>Get your free Ovi mail from Nokia today.</source>
      <translation variants="no">vi #Get your free Ovi mail from Nokia today.</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_dialog_if_the_address_is_incorre">
      <source>Mail address</source>
      <translation variants="no">vi #Mail address</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_setup_dpophead_unable_to_setup_m">
      <source>Unable to setup mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unable to setup mailbox</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dblist_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Other</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_button_cancel">
      <source>Not specified</source>
      <translation variants="no">vi #Not specified</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dblist_val_sign_in">
      <source>Sign in</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Sign in</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailwiz_title_setup">
      <source>Setup</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Setup</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailwiz_setlabel_val_ssl">
      <source>SSL</source>
      <translation variants="no">vi #SSL</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_formlabel_mobile_number_include">
      <source>Mobile number (include country code)</source>
      <translation variants="no">vi #Mobile number (include country code)</translation>
    </message>
    <message numerus="no" id="txt_mail_imappop_list_forgotten_the_password">
      <source>Forgotten the password?</source>
      <translation variants="no">vi #Forgotten the password?</translation>
    </message>
    <message numerus="no" id="txt_mailwiz_dialog_outgoing_mail_server">
      <source>Outgoing mail server</source>
      <translation variants="no">vi #Outgoing mail server</translation>
    </message>
    <message numerus="no" id="txt_common_button_cancel">
      <source>Cancel</source>
      <translation variants="no">vi #Cancel</translation>
    </message>
  </context>
</TS>