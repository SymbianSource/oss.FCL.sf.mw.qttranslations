<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>To-do note</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##To-do note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Switch phone on ?</source>
      <translation variants="no">zh_hk ##Switch phone on ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_time">
      <source>%2</source>
      <translation variants="no">zh_hk ##%2</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snooxed_for_ln_minute">
      <source>Alarm snooxed for %Ln minutes</source>
      <translation>
        <numerusform plurality="a">zh_hk ##Alarm snooxed for %Ln minutes</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_silence">
      <source>Silence</source>
      <translation variants="no">zh_hk ##Silence</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_date">
      <source>%1</source>
      <translation variants="no">zh_hk ##%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_date">
      <source>%1</source>
      <translation variants="no">zh_hk ##%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_dialog_snooze">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Stop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Snooze</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Snooze</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Clock alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Clock alarm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_slide_down_to_stop">
      <source>Slide down to stop</source>
      <translation variants="no">zh_hk ##Slide down to stop</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Calendar alarm</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Calendar alarm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk ##Silence</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_time">
      <source>%2</source>
      <translation variants="no">zh_hk ##%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_snooze">
      <source>Snooze</source>
      <translation variants="no">zh_hk ##Snooze</translation>
    </message>
  </context>
</TS>