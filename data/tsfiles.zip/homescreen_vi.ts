<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_homescreen_opt_add_page">
      <source>Add page</source>
      <translation variants="no">Thêm màn hình chính</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_remove_page">
      <source>Remove page</source>
      <translation variants="no">Xóa màn hình chính</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_change_wallpaper">
      <source>Change wallpaper</source>
      <translation variants="no">Thay đổi hình nền</translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">Offline</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_clean_up_page">
      <source>Clean up page</source>
      <translation variants="no">Tự động sắp xếp nội dung</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_task_switcher">
      <source>Task switcher</source>
      <translation variants="no">Chuyển đổi tác vụ</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_add_content">
      <source>Add content</source>
      <translation variants="no">Thêm nội dung</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_change_wallpaper">
      <source>Change wallpaper</source>
      <translation variants="no">Thay đổi hình nền</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_add_page">
      <source>Add page</source>
      <translation variants="no">Thêm Màn hình chính</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_home_screen_to_offline">
      <source>Home screen to offline</source>
      <translation variants="no">Nội dung cho c.độ offline</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_home_screen_to_online">
      <source>Home screen to online</source>
      <translation variants="no">N.dung cho c.độ tr.tuyến</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_refresh">
      <source>Refresh</source>
      <translation variants="no">Làm mới</translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_remove_page">
      <source>Remove page</source>
      <translation variants="no">Xóa Màn hình chính</translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_in_car_control">
      <source>In car control</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã kết nối phụ kiện trên xe</lengthvariant>
        <lengthvariant priority="2">Đã k.n p.k tr.xe</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_info_page_and_content_will_be_remov">
      <source>Page and content will be removed</source>
      <translation variants="no">Màn hình chính và nội dung trên màn hình chính sẽ bị xóa. Tiếp tục?</translation>
    </message>
    <message numerus="no" id="txt_homescreen_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hủy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_no_service">
      <source>No service</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có sẵn dịch vụ</lengthvariant>
        <lengthvariant priority="2">Ko có sẵn d.vụ</lengthvariant>
      </translation>
    </message>
  </context>
</TS>