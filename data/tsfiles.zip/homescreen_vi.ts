<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_homescreen_opt_change_wallpaper">
      <source>Change wallpaper</source>
      <translation variants="no">Thay đổi hình nền</translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">Màn hình chính offline</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_remove_page">
      <source>Remove page</source>
      <translation variants="no">Xóa màn hình chính</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_task_switcher">
      <source>Task switcher</source>
      <translation variants="no">Chuyển đổi tác vụ</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_home_screen_to_offline">
      <source>Home screen to offline</source>
      <translation variants="no">vi #Content to offline mode</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_add_content">
      <source>Add content</source>
      <translation variants="no">vi #Add content</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_add_page">
      <source>Add page</source>
      <translation variants="no">vi #Add Home screen</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_change_wallpaper">
      <source>Change wallpaper</source>
      <translation variants="no">vi #Change wallpaper</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_home_screen_to_online">
      <source>Home screen to online</source>
      <translation variants="no">vi #Content to online mode</translation>
    </message>
    <message numerus="no" id="txt_homescreen_info_page_and_content_will_be_remov">
      <source>Page and content will be removed</source>
      <translation variants="no">vi #Home screen and its contents will be deleted. Continue?</translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_remove_page">
      <source>Remove page</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Delete Home screen</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #OK</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_no_service">
      <source>No service</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #No service available</lengthvariant>
        <lengthvariant priority="2">vi #No service</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_add_page">
      <source>Add page</source>
      <translation variants="no">Thêm màn hình chính</translation>
    </message>
    <message numerus="no" id="txt_homescreen_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_refresh">
      <source>Refresh</source>
      <translation variants="no">vi #Refresh</translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_in_car_control">
      <source>In car control</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Car kit connected</lengthvariant>
        <lengthvariant priority="2">vi #Car kit conn.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_clean_up_page">
      <source>Clean up page</source>
      <translation variants="no">Tự động sắp xếp nội dung</translation>
    </message>
  </context>
</TS>