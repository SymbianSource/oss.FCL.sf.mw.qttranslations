<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en_us" language="fr_ca">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_info_delete_all_paired_devices_some_device">
      <source>Delete all paired devices? Some devices may be disconnected.</source>
      <translation variants="no">Supprimer tous les appareils jumelés? Certains pourraient être déconnectés.</translation>
    </message>
    <message numerus="no" id="txt_bt_title_unable_to_enter_sim_access_profile">
      <source>Unable to enter SIM access profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Activation du mode SIM distant impossible</lengthvariant>
        <lengthvariant priority="2">Act. mode SIM dist. imposs.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_connected">
      <source>Connected</source>
      <translation variants="no">Connecté à</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_devices_some_devices_may_b">
      <source>Delete all devices? Some devices may be disconnected.</source>
      <translation variants="no">Supprimer tous les appareils? Certains pourraient être déconnectés.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unsupported_device_1">
      <source>Unsupported device: %1</source>
      <translation variants="no">Appareil non pris en charge:
%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_waiting_the_other_device">
      <source>Waiting for the other device</source>
      <translation variants="no">En attente de l'autre appareil</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to">
      <source>Connect to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Connecter à:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_there_seems_to_be_a_lot_of_pairing_que">
      <source>There seems to be uncommonly lot of pairing queries. Turn Bluetooth off to protect your device?</source>
      <translation variants="no">Quantité inhabituelle de demandes de jume­lage détectée. Désac­tiver Bluetooth pour protéger l'appareil?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_other_files_received">
      <source>N other files received</source>
      <translation variants="no">fr_ca ##N other files received</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_on_ini_offline_mode">
      <source>Trun Bluetooth on in offline mode?</source>
      <translation variants="no">Activer Bluetooth en mode hors ligne?</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_with_1_failed_either_the_pas">
      <source>Pairing with %1 failed. Either the passcodes didn’t match or the other device is turned off.</source>
      <translation variants="no">Échec du jumelage à %[06]1. Codes de sécurité ne correspondent pas ou l'autre appareil est éteint.</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_use">
      <source>in use</source>
      <translation variants="no">actif</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_off">
      <source>is now off</source>
      <translation variants="no">est maintenant désactivé</translation>
    </message>
    <message numerus="no" id="txt_bt_info_enter_the_following_code_to_the_1">
      <source>Enter the following code to the %1:</source>
      <translation variants="no">Entrez le code de sécurité qui suit sur %[37]1:</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth_used">
      <source>Bluetooth used</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">Mode SIM distant</translation>
    </message>
    <message numerus="no" id="txt_bt_info_not_possible_during_a_call">
      <source>Not possible during a call</source>
      <translation variants="no">Création d'une connexion Bluetooth impossible en cours d'appel</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_paired_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dialog_please_enter_the_passcode_for_1">
      <source>Please enter the passcode for %1:</source>
      <translation variants="no">Entrez le code de sécurité de %[47]1:</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_on">
      <source>is now on</source>
      <translation variants="no">est maintenant activé</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pairing_with_1">
      <source>Pairing with %1</source>
      <translation variants="no">Jumelage à %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_failed_remote_device_is_pairi">
      <source>Pairing failed. Remote device is pairing with another device.</source>
      <translation variants="no">Échec du jumelage. L'appareil distant est jumelé à un autre appareil.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_blocked_devices">
      <source>Delete all blocked devices?</source>
      <translation variants="no">Supprimer tous les appareils bloqués?</translation>
    </message>
    <message numerus="no" id="txt_bt_button_more_devices">
      <source>More devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Autres appareils</lengthvariant>
        <lengthvariant priority="2">Autres appar.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_bluetooth_not_allowed_to_be_turned_on">
      <source>Bluetooth not allowed to be turned on in offline mode</source>
      <translation variants="no">Activation de Bluetooth impossible en mode hors ligne</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_cancelled_from_1">
      <source>from %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_connected_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_entering_sim_access_profile">
      <source>Entering SIM access profile</source>
      <translation variants="no">Activation du mode SIM distant en cours</translation>
    </message>
    <message numerus="no" id="txt_bt_title_received_from_1">
      <source>Received from %1</source>
      <translation variants="no">Reçu de %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_exited">
      <source>exited</source>
      <translation variants="no">inactif</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_disconnected">
      <source>Disconnected</source>
      <translation variants="no">Déconnecté de</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_unpaired">
      <source>Unpaired</source>
      <translation variants="no">Annuler jumelage à</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_receiving_failed">
      <source>Receiving failed</source>
      <translation variants="no">Échec de la réception</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from">
      <source>Receive messages from:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Recevoir des messages de:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_disconnected_from_1">
      <source>from %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_hidden">
      <source>is now hidden</source>
      <translation variants="no">est maintenant masqué</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_paired">
      <source>Paired</source>
      <translation variants="no">Jumelé avec</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sending_cancelled">
      <source>Sending cancelled</source>
      <translation variants="no">Envoi annulé</translation>
    </message>
    <message numerus="no" id="txt_bt_info_do_you_still_want_to_enable_sim_access">
      <source>Do you still want to enable SIM access profile?</source>
      <translation variants="no">Activer le mode SIM distant?</translation>
    </message>
    <message numerus="no" id="txt_bt_title_sending_file_l1l2_to_3">
      <source>Sending file %L1/%L2 to %3</source>
      <translation variants="no">Envoi du fichier %L1/%L2 à %3</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_off_there_is_an_active">
      <source>Trun Bluetooth off? There is an active connection.</source>
      <translation variants="no">Une connexion Bluetooth active existe. Activer la nouvelle connexion quand même?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_battery_low">
      <source>Battery low</source>
      <translation variants="no">Batterie faible</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pair_with">
      <source>Pair with:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Jumeler avec:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_try_again">
      <source>Try again</source>
      <translation variants="yes">
        <lengthvariant priority="1">Réessayer</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_disable_sim_access_profile">
      <source>Exit SIM access profile?</source>
      <translation variants="no">Désactiver le mode SIM distant?</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to_paired_device">
      <source>Connect to paired device:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Connecté à l'appareil jumelé</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_sim_access_profile_is_used_next_time_t">
      <source>SIM access profile is used next time the car kit connects to this device and the Bluetooth is turned on.</source>
      <translation variants="no">Le mode SIM distant sera activé la prochaine fois que l'ensemble pour voiture est connecté à cet appareil et que Bluetooth est activé</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_pair_with_1">
      <source>Unable to pair with %1</source>
      <translation variants="no">Jumelage à %1 impossible</translation>
    </message>
    <message numerus="no" id="txt_bt_info_bluetooth_device_address_1">
      <source>Bluetooth device address: %1</source>
      <translation variants="no">Adresse de l'appareil Bluetooth:
%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_perform_bluetooth_operation">
      <source>Unable to perform Bluetooth operation</source>
      <translation variants="no">Exécution de l'opération Bluetooth impossible</translation>
    </message>
    <message numerus="no" id="txt_bt_title_operation_not_possible_when_sim_acces">
      <source>Operation not possible when SIM access profile is in use</source>
      <translation variants="yes">
        <lengthvariant priority="1">Exécution de l'opération impossible</lengthvariant>
        <lengthvariant priority="2">Exécution de l'opér. imposs.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from_paired_device">
      <source>Receive messages from paired device:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Recevoir des messages de:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_connect_with_bluetooth">
      <source>Unable to connect with %1</source>
      <translation variants="no">Connexion à %1 impossible</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_all_files_sent">
      <source>All files sent</source>
      <translation variants="no">Ts fichiers envoyés à</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receiving_files_from_1">
      <source>Receiving from %1</source>
      <translation variants="no">Réception de %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_with_1">
      <source>with %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_title_send_to">
      <source>Send to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Envoyer à:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_does_this_code_match_the_code_on_1">
      <source>Does this code match the code on %1?</source>
      <translation variants="no">Le code de sécurité qui suit correspond-il au code de %[26]1?</translation>
    </message>
    <message numerus="no" id="txt_bt_list_dont_ask_again_with_this_device">
      <source>Don't ask again with this device</source>
      <translation variants="no">Ne plus demander avec cet appareil</translation>
    </message>
    <message numerus="no" id="txt_bt_title_no_sim_card_in_the_device">
      <source>No SIM card in the device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Aucune carte SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpinfo_as_web_connection">
      <source>as web connection</source>
      <translation variants="no">utilisé comme connexion Web</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_1">
      <source>in %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_to_connect_1_2_needs_to_be_disconnec">
      <source>To connect %1 %2 needs to be disconnected first.</source>
      <translation variants="no">Connexion à %[28]1 impossible. Déconnectez-vous d'abord de %[28]2.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_files_already_received">
      <source>N files already received</source>
      <translation variants="no">fr_ca ##N files already received</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_sent_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_try_entering_the_sim_access_profile_ag">
      <source>Try entering the SIM access profile again?</source>
      <translation variants="no">Tenter d'activer le mode SIM distant à nouveau?</translation>
    </message>
  </context>
</TS>