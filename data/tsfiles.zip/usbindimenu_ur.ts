<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dblist_usb_connected">
      <source>USB connected</source>
      <translation variants="no">USB متصل شدہ</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connecting">
      <source>USB connecting</source>
      <translation variants="no">USB اتصال تشکیل کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem">
      <source>USB problem</source>
      <translation variants="no">USB اتصال میں غلطی</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_phone_as_modem">
      <source>as web connection</source>
      <translation variants="no">PC انٹرنیٹ سے متصل کریں</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_click_to_eject">
      <source>Click to eject</source>
      <translation variants="no">USB آلہ ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem_val_not_enough_memory">
      <source>Not enough memory</source>
      <translation variants="no">حافظہ کافی نہیں</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_disconnecting">
      <source>USB disconnecting</source>
      <translation variants="no">USB اتصال منقطع کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_problem_val_connection_type_not">
      <source>Connection type not supported</source>
      <translation variants="no">اتصال کی قسم کی تائید نہیں</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_ovi_suite">
      <source>to OVI suite</source>
      <translation variants="no">Nokia Ovi Suite</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_media_transfer">
      <source>as media transfer</source>
      <translation variants="no">میڈیا منتقلی وضع</translation>
    </message>
    <message numerus="no" id="txt_usb_dblist_usb_connected_val_mass_storage">
      <source>as mass storage</source>
      <translation variants="no">وسیع ذخیرہ وضع</translation>
    </message>
  </context>
</TS>