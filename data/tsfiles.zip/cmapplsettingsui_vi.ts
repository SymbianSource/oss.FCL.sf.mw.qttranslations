<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_title_network_connection">
      <source>Network connection</source>
      <translation variants="no">Kết nối mạng:</translation>
    </message>
    <message numerus="no" id="txt_occ_title_access_point">
      <source>Access point</source>
      <translation variants="no">Điểm truy cập:</translation>
    </message>
    <message numerus="no" id="txt_occ_list_dedicated_access_point">
      <source>Dedicated access point</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điểm truy cập chuyên dụng</lengthvariant>
        <lengthvariant priority="2">Đ.tr.cập chuyên dụng</lengthvariant>
      </translation>
    </message>
  </context>
</TS>