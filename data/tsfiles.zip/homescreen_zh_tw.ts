<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_homescreen_opt_remove_page">
      <source>Remove page</source>
      <translation variants="no">刪除首頁畫面</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_clean_up_page">
      <source>Clean up page</source>
      <translation variants="no">自動排列內容</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_change_wallpaper">
      <source>Change wallpaper</source>
      <translation variants="no">變更桌面圖案</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_change_wallpaper">
      <source>Change wallpaper</source>
      <translation variants="no">變更桌面圖案</translation>
    </message>
    <message numerus="no" id="txt_homescreen_info_page_and_content_will_be_remov">
      <source>Page and content will be removed</source>
      <translation variants="no">將刪除首頁畫面和其內容。是否繼續？</translation>
    </message>
    <message numerus="no" id="txt_homescreen_button_ok">
      <source>OK</source>
      <translation variants="yes">
        <lengthvariant priority="1">確定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_no_service">
      <source>No service</source>
      <translation variants="yes">
        <lengthvariant priority="1">無法取得服務</lengthvariant>
        <lengthvariant priority="2">zh_tw #No service</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_add_page">
      <source>Add page</source>
      <translation variants="no">加入首頁畫面</translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_in_car_control">
      <source>In car control</source>
      <translation variants="yes">
        <lengthvariant priority="1">車用配件已連接</lengthvariant>
        <lengthvariant priority="2">車用配件已連</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_refresh">
      <source>Refresh</source>
      <translation variants="no">重新整理</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_add_content">
      <source>Add content</source>
      <translation variants="no">加入內容</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_home_screen_to_online">
      <source>Home screen to online</source>
      <translation variants="no">內容線上模式</translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_remove_page">
      <source>Remove page</source>
      <translation variants="yes">
        <lengthvariant priority="1">刪除首頁畫面</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_title_offline">
      <source>Offline</source>
      <translation variants="yes">
        <lengthvariant priority="1">離線</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_task_switcher">
      <source>Task switcher</source>
      <translation variants="no">工作切換器</translation>
    </message>
    <message numerus="no" id="txt_homescreen_list_add_page">
      <source>Add page</source>
      <translation variants="no">加入首頁畫面</translation>
    </message>
    <message numerus="no" id="txt_homescreen_opt_home_screen_to_offline">
      <source>Home screen to offline</source>
      <translation variants="no">內容離線模式</translation>
    </message>
  </context>
</TS>