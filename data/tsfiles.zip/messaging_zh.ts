<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="yes" id="txt_messaging_dpophead_ln_failed_messages">
      <source>%Ln Failed messages </source>
      <translation>
        <numerusform plurality="a">%Ln条失败信息</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_delete_message">
      <source>Delete message</source>
      <translation variants="no">删除信息</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_l1_of_l2">
      <source>Unable to attach %L1 of %L2 items. Maximum size exceeded  </source>
      <translation variants="no">zh #Unable to attach %L1 of %L2 items. Maximum attachment allowance reached.  </translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_landmarks">
      <source>Save to landmarks</source>
      <translation variants="no">存入标记</translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_bcc">
      <source>Bcc:</source>
      <translation variants="no">密送：</translation>
    </message>
    <message numerus="yes" id="txt_messaging_dpophead_ln_outgoing_messages">
      <source>%Ln Outgoing messages </source>
      <translation>
        <numerusform plurality="a">%Ln条传出信息</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_outgoing_message">
      <source>Outgoing message </source>
      <translation variants="yes">
        <lengthvariant priority="1">发送信息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_sound">
      <source>Sound </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Sound clip</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_cc">
      <source>Cc:</source>
      <translation variants="no">抄送： </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_business_card">
      <source>Bus. Card </source>
      <translation variants="no">zh #Business card</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_l1">
      <source>(%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_photo">
      <source>Photo </source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Image</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_to">
      <source>To: </source>
      <translation variants="no">收信人：</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_conversation">
      <source>Delete Conversation ? </source>
      <translation variants="no">删除会话?</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_send_selected_item">
      <source>Send selected item</source>
      <translation variants="no">zh ##Send selected item</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_copy_link">
      <source>Copy link</source>
      <translation variants="no">复制链接</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_attach">
      <source>Attach</source>
      <translation variants="yes">
        <lengthvariant priority="1">添加附件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_number_of_recipients_exceeded">
      <source>Number of recipients exceeded.Convert to multimedia message ? </source>
      <translation variants="no">超过最多收信人数。转换为彩信？</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_from">
      <source>From:</source>
      <translation variants="no">发信人：</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_calendar_event">
      <source>Calendar event </source>
      <translation variants="no">zh #Calendar entry</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_attach_to_new_message">
      <source>Attach to new message</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh ##Attach to new message</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_message">
      <source>Delete message ? </source>
      <translation variants="no">删除信息？</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_item_avai">
      <source>Unable to attach item. Available space is %L1kb</source>
      <translation variants="no">无法附加项目。可用空间：%L1 kB。</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_business_card">
      <source>Business Card </source>
      <translation variants="no">名片</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_invalid_recipient_found">
      <source>Invalid recipient found: </source>
      <translation variants="no">zh #Incorrect mail address found:</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_mms_retrieval_failed">
      <source>MMS retrieval failed</source>
      <translation variants="no">彩信提取失败</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_view">
      <source>View </source>
      <translation variants="no">查看</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_invalid_recipients_not_added">
      <source>Invalid recipients not added %1</source>
      <translation variants="no">zh #Invalid recipients not added %1</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_contact_saved">
      <source>Contact Saved</source>
      <translation variants="no">名片已存</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_type_changed_to_tex">
      <source>Message type changed to text message</source>
      <translation variants="no">信息类型已改为短信息</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_type_changed_to_mul">
      <source>Message type changed to multimedia </source>
      <translation variants="no">信息类型已改为彩信</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_cc">
      <source>Cc:</source>
      <translation variants="no">抄送： </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_full_support">
      <source>Full support </source>
      <translation variants="no">支持全部字符</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_subject">
      <source>Add Subject</source>
      <translation variants="no">增加主题栏</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">存入名片夹</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_reduced_support">
      <source>Reduced support </source>
      <translation variants="no">支持部分字符</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_subject">
      <source>Subject:</source>
      <translation variants="no">主题：</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_bcc">
      <source>Bcc:</source>
      <translation variants="no">密送：</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_access_point_in_use">
      <source>MMS access point in use </source>
      <translation variants="no">彩信接入点</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_add_new">
      <source>Add New </source>
      <translation variants="yes">
        <lengthvariant priority="1">新信息中心</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_settings">
      <source>Settings</source>
      <translation variants="no">设置</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_enter_message_here">
      <source>Enter message here </source>
      <translation variants="no">输入文字</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_message">
      <source>Allow anonymous MMS messages </source>
      <translation variants="no">匿名彩信</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_sms_message_centre_settings">
      <source>SMS message centre settings </source>
      <translation variants="yes">
        <lengthvariant priority="1">短信信息中心设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_message_centre_number">
      <source>Message centre number </source>
      <translation variants="no">信息中心号码</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach">
      <source>Attach</source>
      <translation variants="no">添加附件</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_messaging">
      <source>Messaging</source>
      <translation variants="yes">
        <lengthvariant priority="1">信息</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_download">
      <source>Download</source>
      <translation variants="no">下载</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_sound">
      <source>Sound</source>
      <translation variants="no">声音片段</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_val_yes">
      <source>Yes</source>
      <translation variants="no">允许</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_character_encoding">
      <source>Character encoding </source>
      <translation variants="no">字符编码方式</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_val_no">
      <source>No</source>
      <translation variants="no">不允许</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_auto_home_network">
      <source>Automatic in home network </source>
      <translation variants="no">在注册网络中自动提取</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_delete_conversation">
      <source>Delete Conversation</source>
      <translation variants="no">删除会话</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_business_card">
      <source>Business card </source>
      <translation variants="no">名片</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_message_centre_name">
      <source>Message centre name </source>
      <translation variants="no">信息中心名称</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receive_mms_adverts">
      <source>Receive MMS adverts </source>
      <translation variants="no">接收广告</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">关</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_mms_settings">
      <source>MMS settings </source>
      <translation variants="yes">
        <lengthvariant priority="1">彩信设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_delete_message_centre">
      <source>Delete message centre</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_select_attachment_type">
      <source>Select attachment type</source>
      <translation variants="no">选择附件类型：</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_sms_message_centre_in_use">
      <source>SMS message centre in use </source>
      <translation variants="no">短信信息中心</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_to">
      <source>To:</source>
      <translation variants="no">收信人：</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_add_to_bookmarks">
      <source>Add to bookmarks</source>
      <translation variants="no">存入书签</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_photo">
      <source>Photo</source>
      <translation variants="no">图像</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_invalid_recipient_not_added">
      <source>Invalid recipient not added %1</source>
      <translation variants="no">zh #Invalid recipient not added %1</translation>
    </message>
    <message numerus="no" id="txt_short_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">zh ##Messaging</translation>
    </message>
    <message numerus="no" id="txt_long_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">信息</translation>
    </message>
    <message numerus="yes" id="txt_messaging_list_ln_new_messages">
      <source>%Ln New Messages </source>
      <translation>
        <numerusform plurality="a">%Ln条新信息</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_deleting_will_remove_some_mul">
      <source>Deleting will remove some multimedia messages displayed in other conversations too. Delete conversation?</source>
      <translation variants="no">删除会话的同时还会删除其他会话中显示的一些多媒体信息。删除会话？</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">铃声</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_business_card">
      <source>Business Card</source>
      <translation variants="no">名片</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">zh #Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_priority">
      <source>Priority</source>
      <translation variants="no">优先级</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_informational">
      <source>Class: Informational</source>
      <translation variants="no">信息</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_message_centre_does_not_e">
      <source>SMS Message centre does not exist. Create New  ?</source>
      <translation variants="no">未定义信息中心。现在定义？</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_message_centre">
      <source>Delete message centre?</source>
      <translation variants="no">删除信息中心？</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_centre_saved">
      <source>Message centre saved</source>
      <translation variants="no">信息中心已存</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_loading">
      <source>Loading...</source>
      <translation variants="no">正在加载</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_add_more_recipien">
      <source>Unable to add more recipients. Maximum limit exceeded</source>
      <translation variants="no">无法添加收件人。超过最多数量。</translation>
    </message>
    <message numerus="no" id="txt_conversations_list_message_cannot_be_shown_exa">
      <source>Message cannot be shown exactly as the sender intended. Open to see included objects</source>
      <translation variants="no">不能完全按照发送者的意愿显示信息。打开并查看包括的对象。</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_re">
      <source>RE: </source>
      <translation variants="no">回复：</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_unable_to_delete_conversation">
      <source>Unable to delete conversation as it contains messages being sent. Try again later.  </source>
      <translation variants="no">无法删除会话，因为其中包含传出信息。稍后再试。</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_slide_l1l2">
      <source>Slide %L1/%L2</source>
      <translation variants="no">幻灯片%L1/%L2</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_unknown_bluetooth_device">
      <source>Unknown Bluetooth Device </source>
      <translation variants="no">zh #Unknown Bluetooth device</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_drafts">
      <source>Drafts</source>
      <translation variants="no">草稿</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_advertisement">
      <source>Class: Advertisement</source>
      <translation variants="no">广告</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_class">
      <source>Class: </source>
      <translation variants="no">zh ##Class: </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_business_card">
      <source>Business card</source>
      <translation variants="no">名片</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_personal">
      <source>Class: Personal</source>
      <translation variants="no">个人</translation>
    </message>
    <message numerus="no" id="txt_conversations_list_1_2">
      <source>%1 %2</source>
      <translation variants="no">%1 %2</translation>
    </message>
    <message numerus="yes" id="txt_messaging_title_ln_other_recipients">
      <source>%Ln Other recipients</source>
      <translation>
        <numerusform plurality="a">%Ln个其他收件人</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_manual">
      <source>Manual</source>
      <translation variants="no">手动</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_contact_info">
      <source>Contact info </source>
      <translation variants="no">名片信息</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_message_cannot_be_shown_ex">
      <source>Message cannot be shown exactly as the sender intended. Included objects shown as attachments:</source>
      <translation variants="no">无法完全按照发送者的意愿信息。包括的对象显示为附件：</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_message_sending_failed">
      <source>Message Sending failed %1</source>
      <translation variants="no">无法发送信息：%L1</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_expiry_date">
      <source>Expiry date: </source>
      <translation variants="no">zh ##Expiry date: </translation>
    </message>
    <message numerus="yes" id="txt_messaging_list_resend_at_time">
      <source>Resend at %Ln</source>
      <translation>
        <numerusform plurality="a">zh #Resend at %Ln</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_same_message_exists_in_multip">
      <source>Same message exists in multiple conversations. Delete all ? </source>
      <translation variants="no">在多个会话中找到同样的信息。删除全部信息？</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_attached_photo_size_is_l1">
      <source>Attached photo size is %L1 * %L2 pixels  </source>
      <translation variants="no">附加的照片大小为%L1 x %L2像素</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_add_more_content">
      <source>Unable to add more content. Maximum size exceeded</source>
      <translation variants="no">无法添加内容。超过最大尺寸。</translation>
    </message>
    <message numerus="yes" id="txt_messaging_list_listview_resend_at_time">
      <source>Resend at %Ln</source>
      <translation>
        <numerusform plurality="a">zh ##Resend at &lt;time&gt;</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_forward">
      <source>Forward</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Forward</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_listview_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="yes">
        <lengthvariant priority="1">信息类型不受支持</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_all_drafts">
      <source>Delete all drafts ?</source>
      <translation variants="no">删除所有草稿？</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">zh #Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_received_files">
      <source>Received files </source>
      <translation variants="yes">
        <lengthvariant priority="1">已收文件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_messaging_settings">
      <source>Messaging settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receiving_service_messages">
      <source>Receiving service messages</source>
      <translation variants="no">正在接收服务信息</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">zh #Messaging</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_conversations">
      <source>Conversations</source>
      <translation variants="yes">
        <lengthvariant priority="1">会话</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_conversations">
      <source>Conversations</source>
      <translation variants="no">会话</translation>
    </message>
    <message numerus="no" id="txt_conversations_dialog_save_ringing_tone">
      <source>%1 Save ringing tone ?</source>
      <translation variants="no">储存铃声？</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_received_files">
      <source>Received files</source>
      <translation variants="yes">
        <lengthvariant priority="1">已收文件</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_retrieval">
      <source>MMS retrieval </source>
      <translation variants="no">彩信提取</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_new_sms_message_centre">
      <source>New  SMS message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">新短信信息中心</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_group_title_ln_other_recipients">
      <source>Other recipients</source>
      <translation variants="no">其他收件人</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_on">
      <source>On</source>
      <translation variants="no">开</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_cc_bcc">
      <source>Add Cc / Bcc</source>
      <translation variants="no">增加抄送和密送栏</translation>
    </message>
    <message numerus="no" id="txt_wireframe_list_multimedia_message_waiting">
      <source>Multimedia message waiting…</source>
      <translation variants="no">彩信正在等待</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_create_mail">
      <source>Create mail </source>
      <translation variants="no">编写电子邮件</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_character_count_exceeded">
      <source>SMS character count exceeded. Convert to multimedia message?</source>
      <translation variants="no">超过最多字符数。转换为彩信？</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_open_link">
      <source>Open link</source>
      <translation variants="no">打开链接</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_character_count_excee">
      <source>SMS character count exceeded. Convert to multimedia message ? </source>
      <translation variants="no">字符太多。转换为彩信？</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_message_sending_failed">
      <source>Message sending failed </source>
      <translation variants="yes">
        <lengthvariant priority="1">信息发送失败</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_item_file">
      <source>Unable to attach item. File type not supported</source>
      <translation variants="no">无法添加附件。不支持此文件类型。</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_normal">
      <source>Normal </source>
      <translation variants="no">中</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_other_recipients">
      <source>Other recipients</source>
      <translation variants="no">zh #Other recipients</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_low">
      <source>Low </source>
      <translation variants="no">低</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">zh #Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_saved_to_drafts">
      <source>Saved to drafts</source>
      <translation variants="no">信息已存入草稿</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_size">
      <source>Size:  </source>
      <translation variants="no">zh ##Size:  </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_edit_sms_message_centre">
      <source>Edit SMS message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">编辑</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_always_automatic">
      <source>Always automatic </source>
      <translation variants="no">始终打开</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_recipients">
      <source>Add recipients</source>
      <translation variants="no">增加收件人</translation>
    </message>
    <message numerus="no" id="txt_conversations_list_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">zh #Ringtone</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_mms_access_point_not_defined">
      <source>MMS Access point not defined. Define now  ?</source>
      <translation variants="no">未定义多媒体接入点。现在定义？</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_high">
      <source>High </source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">铃声</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delate_all_drafts">
      <source>Delate all drafts ?</source>
      <translation variants="no">删除所有草稿？</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_fwd">
      <source>FWD: </source>
      <translation variants="no">转发：</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_drafts">
      <source>Drafts</source>
      <translation variants="yes">
        <lengthvariant priority="1">草稿</lengthvariant>
      </translation>
    </message>
  </context>
</TS>