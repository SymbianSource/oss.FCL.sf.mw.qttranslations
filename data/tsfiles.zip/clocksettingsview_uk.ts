<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_button_digital">
      <source>Digital</source>
      <translation variants="no">uk #Digital</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_format">
      <source>Date format</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Date format</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_use_network_date_time">
      <source>Use network date &amp; time</source>
      <translation variants="no">uk #Use network time and date</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time_separator">
      <source>Time separator</source>
      <translation variants="no">uk #Time separator</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour">
      <source>24 hour</source>
      <translation variants="no">uk #24-hour</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_sunday">
      <source>Sunday</source>
      <translation variants="no">uk #Sunday</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date">
      <source>Date</source>
      <translation variants="no">uk #Date</translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_date_time">
      <source>Date &amp; time</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Time and date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_friday">
      <source>Friday</source>
      <translation variants="no">uk #Friday</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy">
      <source>dd mm yyyy</source>
      <translation variants="no">uk #dd mm yyyy</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_week_starts_on">
      <source>Week starts on</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Week starts on</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time">
      <source>Time</source>
      <translation variants="no">uk #Time</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_clock_type">
      <source>Clock Type</source>
      <translation variants="no">uk #Clock type</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_info_date_info">
      <source>%1, %2</source>
      <translation variants="no">uk #%[12]1, %2</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_monday">
      <source>Monday</source>
      <translation variants="no">uk #Monday</translation>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date">
      <source>Time &amp; date</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Time and date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy">
      <source>mm dd yyyy</source>
      <translation variants="no">uk #mm dd yyyy</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_date_separator">
      <source>Date separator</source>
      <translation variants="no">uk #Date separator</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_workdays">
      <source>Workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Workdays</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_clock_list_ln_minutes">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">uk #%Ln minute</numerusform>
        <numerusform plurality="b">uk #%Ln minutes</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">uk #Wednesday</translation>
    </message>
    <message numerus="no" id="txt_clock_setlabel_time_format">
      <source>Time format</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Time format</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Regional time and date settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">uk #Tuesday</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour">
      <source>12 hour</source>
      <translation variants="no">uk #12-hour</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_thursday">
      <source>Thursday</source>
      <translation variants="no">uk #Thursday</translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_saturday">
      <source>Saturday</source>
      <translation variants="no">uk #Saturday</translation>
    </message>
    <message numerus="no" id="txt_clock_button_regional_date_time_settings">
      <source>Regional date &amp; time settings</source>
      <translation variants="no">uk #Regional time and date settings</translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_place">
      <source>Place</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Place</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd">
      <source>yyyy mm dd</source>
      <translation variants="no">uk #yyyy mm dd</translation>
    </message>
    <message numerus="no" id="txt_clock_button_analog">
      <source>Analog</source>
      <translation variants="no">uk #Analogue</translation>
    </message>
  </context>
</TS>