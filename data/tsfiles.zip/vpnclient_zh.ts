<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_incorrect_password">
      <source>Incorrect password</source>
      <translation variants="no">密码不正确。</translation>
    </message>
    <message numerus="no" id="txt_occ_info_delete_vpn_policy">
      <source>Delete VPN policy '%1'?</source>
      <translation variants="no">删除VPN策略？
%1</translation>
    </message>
    <message numerus="no" id="txt_occ_list_tap_on_a_policy_to_set_a_default">
      <source>Tap on a policy to set a default.</source>
      <translation variants="no">点击一个策略将其设置为预设策略：</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_installing_vpn_policy">
      <source>Installing VPN policy</source>
      <translation variants="no">正在安装VPN策略</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn_val_always">
      <source>Always</source>
      <translation variants="no">始终打开</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_pkcs12_password">
      <source>PKCS#12 password:</source>
      <translation variants="no">PKCS#12密码：</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_service_not_available">
      <source>Policy server not available</source>
      <translation variants="no">策略服务器不可用。</translation>
    </message>
    <message numerus="no" id="txt_occ_button_download">
      <source>Download</source>
      <translation variants="no">下载</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_policy_fi">
      <source>Policy installation failed. Policy file error.</source>
      <translation variants="no">策略安装失败。策略文件错误。</translation>
    </message>
    <message numerus="no" id="txt_occ_list_no_vpn_policies_installed">
      <source>No VPN policies installed.</source>
      <translation variants="no">未安装VPN策略</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_vpn">
      <source>VPN</source>
      <translation variants="yes">
        <lengthvariant priority="1">VPN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_password">
      <source>Password:</source>
      <translation variants="no">密码：</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_vpn_user_name">
      <source>VPN user name:</source>
      <translation variants="no">VPN用户名：</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed">
      <source>Policy installation failed</source>
      <translation variants="no">策略安装失败</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_download_failed">
      <source>Download failed</source>
      <translation variants="no">下载失败。</translation>
    </message>
    <message numerus="no" id="txt_vpn_dialog_securid_pin">
      <source>SecurID PIN:</source>
      <translation variants="no">zh #SecurID PIN:</translation>
    </message>
    <message numerus="no" id="txt_vpn_button_disconnect_vpn">
      <source>Disconnect VPN</source>
      <translation variants="no">断开VPN</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_vpn_policy_download">
      <source>VPN policy download</source>
      <translation variants="yes">
        <lengthvariant priority="1">VPN策略下载</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_ap">
      <source>Policy installation failed. Unable to create VPN access point.</source>
      <translation variants="no">策略安装失败。无法创建VPN接入点。</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn_val_when_needed">
      <source>When needed</source>
      <translation variants="no">需要时</translation>
    </message>
    <message numerus="no" id="txt_occ_info_downloading_vpn_policy">
      <source>Downloading VPN policy</source>
      <translation variants="no">正在下载VPN策略</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_vpn">
      <source>VPN</source>
      <translation variants="no">VPN</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_delete_vp">
      <source>Policy installation failed. Delete VPN policies from settings and try again.</source>
      <translation variants="no">策略安装失败。删除一条策略后再试。</translation>
    </message>
    <message numerus="no" id="txt_vpn_info_policy_installation_failed_cert">
      <source>Policy installation failed. Unable to store certificates.</source>
      <translation variants="no">策略安装失败。无法存储证书。</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_policy_server_address">
      <source>Policy server address</source>
      <translation variants="no">策略服务器地址：</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_vpn_connection">
      <source>VPN connection</source>
      <translation variants="no">VPN连接</translation>
    </message>
  </context>
</TS>