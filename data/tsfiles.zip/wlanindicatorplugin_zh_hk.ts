<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dblist_indi_menu_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="no">WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_wireless_lan_val_1_connected">
      <source>'%1' connected</source>
      <translation variants="no">zh_hk #'%1' connected</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_wireless_lan_val_not_connected">
      <source>Not connected</source>
      <translation variants="no">未連接</translation>
    </message>
  </context>
</TS>