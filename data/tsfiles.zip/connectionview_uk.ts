<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_list_name">
      <source>Name</source>
      <translation variants="no">uk ##Name</translation>
    </message>
    <message numerus="no" id="txt_occ_button_disconnect_all">
      <source>Disconnect all</source>
      <translation variants="yes">
        <lengthvariant priority="1">Роз’єднати всі</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_button_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Роз’єднати</translation>
    </message>
    <message numerus="no" id="txt_occ_info_no_active_connections">
      <source>No active connections</source>
      <translation variants="no">(немає активних з’єднань)</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_connection_details">
      <source>Connection details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Деталі з’єднання</lengthvariant>
      </translation>
    </message>
  </context>
</TS>