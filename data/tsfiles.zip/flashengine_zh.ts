<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="text_flite_note_insufficient_memory_mmc_needed">
      <source>Phone memory not sufficient, memory card required for optimal playback</source>
      <translation variants="no">手机存储不足。插入存储卡。</translation>
    </message>
    <message numerus="no" id="text_flite_note_mmc_memory_low">
      <source>For optimal playback, delete some data from memory card</source>
      <translation variants="no">存储不足。删除一些数据。</translation>
    </message>
    <message numerus="no" id="text_flite_error_video_too_large">
      <source>Video memory requirements exceed phone capacity. Video will terminate</source>
      <translation variants="no">存储不足，无法播放视频</translation>
    </message>
    <message numerus="no" id="text_flite_error_not_enough_memory_video_terminates">
      <source>Memory card full.Video will terminate.Delete some data and play again</source>
      <translation variants="no">无法播放视频。存储卡已满。</translation>
    </message>
    <message numerus="no" id="text_flite_error_insert_memory_card">
      <source>Not enough memory to play selected video. Insert memory card and play again</source>
      <translation variants="no">存储不足。插入存储卡。</translation>
    </message>
    <message numerus="no" id="text_flite_mmc_access_error">
      <source>Memory card cannot be accessed. Operation will terminate</source>
      <translation variants="no">无法播放视频。存储卡不可用。</translation>
    </message>
  </context>
</TS>