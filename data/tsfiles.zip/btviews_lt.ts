<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="lt">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_opt_show">
      <source>Show…</source>
      <translation variants="no">Rodyti</translation>
    </message>
    <message numerus="no" id="txt_bt_button_disconnect">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">lt #Disconnect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices">
      <source>No paired devices</source>
      <translation variants="no">Nėra suporuotų prietaisų</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_all_devices">
      <source>All devices</source>
      <translation variants="no">Visi prietaisai</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired">
      <source>Paired</source>
      <translation variants="yes">
        <lengthvariant priority="1">Suporuotas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_input_device">
      <source>Input device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Įvesties prietaisas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_international">
      <source>International US</source>
      <translation variants="no">JAV tarptautinis</translation>
    </message>
    <message numerus="no" id="txt_bt_list_computer">
      <source>Computer</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kompiuteris</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">Kitas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Išjungtas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">Užblokuotas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_connection">
      <source>Connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ryšys</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Prijungtas (aptinkamas)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">SIM prieigos profilis</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_enabled">
      <source>Enabled</source>
      <translation variants="no">Įjungtas</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Prijungtas (paslėptas)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trusted">
      <source>Paired, trusted</source>
      <translation variants="yes">
        <lengthvariant priority="1">Suporuotas, patikimas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_dutch">
      <source>Dutch</source>
      <translation variants="no">Olandų</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_pair">
      <source>Pair</source>
      <translation variants="no">lt #Pair</translation>
    </message>
    <message numerus="yes" id="txt_bt_setlabel_visibility_val_visible_for_l1_min">
      <source>Visible for %Ln min</source>
      <translation>
        <numerusform plurality="a">lt #Visible for %Ln minute</numerusform>
        <numerusform plurality="b">lt #Visible for %Ln minutes</numerusform>
        <numerusform plurality="c">lt #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices_of_selected_type">
      <source>No found devices of selected type</source>
      <translation variants="no">lt #No found devices of selected type</translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_found_devices">
      <source>No found devices</source>
      <translation variants="no">Prietaisų nerasta</translation>
    </message>
    <message numerus="no" id="txt_bt_button_connect">
      <source>Connect</source>
      <translation variants="yes">
        <lengthvariant priority="1">lt #Connect</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_1_details">
      <source>%1 details</source>
      <translation variants="no">%[13]1 informacija</translation>
    </message>
    <message numerus="no" id="txt_bt_list_1_connected">
      <source>%1 connected</source>
      <translation variants="no">%[15]1 prijungtas</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">„Bluetooth“</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_belgian">
      <source>Belgian</source>
      <translation variants="no">Belgijos prancūzų</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_always_ask">
      <source>Always ask</source>
      <translation variants="yes">
        <lengthvariant priority="1">Visada klausti</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_norwegian">
      <source>Norwegian</source>
      <translation variants="no">Norvegų</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout">
      <source>Keyboard layout</source>
      <translation variants="no">Klaviatūros išdėstymas</translation>
    </message>
    <message numerus="no" id="txt_bt_info_blocked">
      <source>Blocked</source>
      <translation variants="yes">
        <lengthvariant priority="1">Užblokuotas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_spanish">
      <source>Spanish</source>
      <translation variants="no">Ispanų</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_advanced_settings">
      <source>Bluetooth - Advanced settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">„Bluetooth“ - papildomi parametrai</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_connected">
      <source>Connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Prijungtas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_blocked_devices">
      <source>Blocked devices</source>
      <translation variants="no">Užblokuoti prietaisai</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect">
      <source>Connect</source>
      <translation variants="no">Prisijungti</translation>
    </message>
    <message numerus="no" id="txt_bt_button_device_settings">
      <source>Device details</source>
      <translation variants="no">lt #Device details</translation>
    </message>
    <message numerus="no" id="txt_bt_list_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Telefonas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect_audio">
      <source>Disconnect audio</source>
      <translation variants="no">lt #Disconnect audio</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_hidden">
      <source>Hidden</source>
      <translation variants="no">lt #Hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_found_devices">
      <source>Bluetooth - Found devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">lt #Bluetooth devices found</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_device">
      <source>Bluetooth device</source>
      <translation variants="yes">
        <lengthvariant priority="1">lt #Bluetooth device</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices_of_selected_type">
      <source>No devices of selected type</source>
      <translation variants="no">lt #No devices of selected type</translation>
    </message>
    <message numerus="no" id="txt_bt_button_unpair">
      <source>Unpair</source>
      <translation variants="yes">
        <lengthvariant priority="1">lt #Remove pairing</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_pair">
      <source>Pair</source>
      <translation variants="yes">
        <lengthvariant priority="1">lt #Pair</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_devices">
      <source>No devices</source>
      <translation variants="no">Nėra prietaisų</translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_trused_connected">
      <source>Paired, trusted, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Suporuotas, patikimas, prijungtas</lengthvariant>
        <lengthvariant priority="2">Supor., patikimas, prijungtas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_all_devices">
      <source>Bluetooth - All devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">„Bluetooth“ - visi prietaisai</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_danish">
      <source>Danish</source>
      <translation variants="no">Danų</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_sim_access_profile_val_disabled">
      <source>Disabled</source>
      <translation variants="no">Išjungtas</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Įjungtas (paslėptas)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_uk">
      <source>UK</source>
      <translation variants="no">Jungtinės Karalystės</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us_dvorak">
      <source>US Dvorak</source>
      <translation variants="no">JAV „Dvorak“</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_french">
      <source>French</source>
      <translation variants="no">Prancūzų</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove">
      <source>Remove</source>
      <translation variants="no">Pašalinti</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_russian">
      <source>Russian</source>
      <translation variants="no">Rusų</translation>
    </message>
    <message numerus="no" id="txt_cp_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Įjungtas (aptinkamas)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_bluetooth_paired_devices">
      <source>Bluetooth - Paired devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">„Bluetooth“ - suporuoti prietaisai</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">Papildomi parametrai</translation>
    </message>
    <message numerus="no" id="txt_bt_list_audio_device">
      <source>Audio device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Garso prietaisas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_menu_connect_audio">
      <source>Connect audio</source>
      <translation variants="no">lt #Connect audio</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_unpair">
      <source>Unpair</source>
      <translation variants="no">lt #Unpair</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_searching">
      <source>Searching…</source>
      <translation variants="yes">
        <lengthvariant priority="1">lt #Searching</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_list_no_paired_devices_of_selected_type">
      <source>No paired devices of selected type</source>
      <translation variants="no">lt #No paired devices of selected type</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_change_visibility_time">
      <source>Change visibility time</source>
      <translation variants="no">Pakeisti aptinkam. trukmę</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_italian">
      <source>Italian</source>
      <translation variants="no">Italų</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_bluetooth_val_automatic">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">Automatiškai</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_paired_connected">
      <source>Paired, connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Suporuotas, prijungtas</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_sub_paired_devices">
      <source>Paired devices</source>
      <translation variants="no">Suporuoti prietaisai</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_finnishswedi">
      <source>Finnish/Swedish</source>
      <translation variants="no">Suomių, švedų</translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_portuguese">
      <source>Portuguese</source>
      <translation variants="no">Portugalų</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_keyboard_settings">
      <source>Keyboard settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Klaviatūros parametrai</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_german">
      <source>German</source>
      <translation variants="no">Vokiečių</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_mouse_settings">
      <source>Mouse settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Pelės parametrai</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_formlabel_keyboard_layout_val_us">
      <source>US</source>
      <translation variants="no">JAV anglų</translation>
    </message>
    <message numerus="no" id="txt_bt_opt_remove_paired_devices">
      <source>Remove paired devices</source>
      <translation variants="no">Pašalinti supor. prietaisus</translation>
    </message>
    <message numerus="no" id="txt_bt_menu_disconnect">
      <source>Disconnect</source>
      <translation variants="no">Atsijungti</translation>
    </message>
    <message numerus="no" id="txt_bt_setlabel_visibility_val_visible">
      <source>Visible</source>
      <translation variants="no">lt #Shown to all</translation>
    </message>
    <message numerus="no" id="txt_bt_subhead_search_done">
      <source>Search done</source>
      <translation variants="yes">
        <lengthvariant priority="1">lt #Search completed</lengthvariant>
      </translation>
    </message>
  </context>
</TS>