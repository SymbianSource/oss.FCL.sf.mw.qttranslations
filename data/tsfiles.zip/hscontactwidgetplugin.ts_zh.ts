<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_friend_widget_info_you_can_not_use_this_widge">
      <source>You can not use this  widget, because your phonebook is empty. Open Phonebook to add contacts?</source>
      <translation variants="no">无法使用袖珍名片夹，因为名片夹应用程序中不含名片。打开名片夹应用程序？</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget_val_quickly">
      <source>Quickly communicate with a contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">与名片快速通讯</lengthvariant>
        <lengthvariant priority="2">zh #Quick communication</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_friend">
      <source>Contact widget</source>
      <translation variants="no">zh #Mini Contacts</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget">
      <source>Contact widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">袖珍名片夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_friend_widget_title_select_contact">
      <source>Select contact:</source>
      <translation variants="no">选择名片</translation>
    </message>
  </context>
</TS>