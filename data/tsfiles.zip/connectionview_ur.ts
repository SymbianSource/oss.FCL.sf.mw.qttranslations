<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_button_disconnect">
      <source>Disconnect</source>
      <translation variants="yes">
        <lengthvariant priority="1">غیر متصل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_list_name">
      <source>Name</source>
      <translation variants="no">نام:</translation>
    </message>
    <message numerus="no" id="txt_occ_button_disconnect_all">
      <source>Disconnect all</source>
      <translation variants="yes">
        <lengthvariant priority="1">سب کو غیر متصل کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_connection_details">
      <source>Connection details</source>
      <translation variants="yes">
        <lengthvariant priority="1">اتصال کی تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_info_no_active_connections">
      <source>No active connections</source>
      <translation variants="no">(کوئی کارآمد اتصالات نہیں)</translation>
    </message>
  </context>
</TS>