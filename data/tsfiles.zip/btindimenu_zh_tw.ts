<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_hidden_and_connected">
      <source>Source 0</source>
      <translation variants="no">zh_tw #Hidden and connected</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_hidden">
      <source>Source 1</source>
      <translation variants="no">zh_tw #On and hidden</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_sending_files">
      <source>Source 2</source>
      <translation variants="no">zh_tw #Sending files</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_off">
      <source>Source 3</source>
      <translation variants="no">zh_tw #Off</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_computer">
      <source>Source 4</source>
      <translation variants="no">zh_tw #Computer</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_receiving_files">
      <source>Source 5</source>
      <translation variants="no">zh_tw #Receiving files</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_connected">
      <source>Source 6</source>
      <translation variants="no">zh_tw #%1 connected</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_phone">
      <source>Source 7</source>
      <translation variants="no">zh_tw #Phone</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_paired">
      <source>Source 8</source>
      <translation variants="no">zh_tw #%1 paired</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_other_device">
      <source>Source 9</source>
      <translation variants="no">zh_tw #Other device</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_audio_device">
      <source>Source 10</source>
      <translation variants="no">zh_tw #Audio device</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_visible">
      <source>Source 11</source>
      <translation variants="no">zh_tw #On and visible</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_usign_sim_access_profi">
      <source>Source 12</source>
      <translation variants="no">zh_tw #usign SIM access profile</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_input_device">
      <source>Source 13</source>
      <translation variants="no">zh_tw #Input device</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth">
      <source>Source 14</source>
      <translation variants="no">zh_tw #Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_visible_and_connected">
      <source>Source 15</source>
      <translation variants="no">zh_tw #Visible and connected</translation>
    </message>
  </context>
</TS>