<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_dblist_val_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">未命名</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">是否刪除會議？</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_completed_date">
      <source>Completed date:</source>
      <translation variants="yes">
        <lengthvariant priority="1">完成日期：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">標記為已完成</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_event">
      <source>Event</source>
      <translation variants="yes">
        <lengthvariant priority="1">項目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_occasion">
      <source>Occasion:</source>
      <translation variants="yes">
        <lengthvariant priority="1">主題：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">只限本次</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_edit">
      <source>Edit</source>
      <translation variants="no">修改</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">是否刪除待辦事項？</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Delete anniversary?</source>
      <translation variants="no">是否刪除週年紀念日？</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_reminder_time">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_from_1">
      <source>From %1</source>
      <translation variants="no">從%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_meeting_date">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_not_done">
      <source>Mark as not done</source>
      <translation variants="no">標記為未完成</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily">
      <source>Repeats daily</source>
      <translation variants="yes">
        <lengthvariant priority="1">每天重複</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_anniversary">
      <source>Anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">週年紀念日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_daily_val_until_1">
      <source>Until %1</source>
      <translation variants="no">直至%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_description">
      <source>Description:</source>
      <translation variants="yes">
        <lengthvariant priority="1">內容說明：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_monthly">
      <source>Repeats monthly</source>
      <translation variants="yes">
        <lengthvariant priority="1">每月重複</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">修改：</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">每一次出現</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_reminder_time_date">
      <source>%1 %2</source>
      <translation variants="no">%[12]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_fortnightly">
      <source>Repeats fortnightly</source>
      <translation variants="yes">
        <lengthvariant priority="1">每兩週重複</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_subject">
      <source>Subject:</source>
      <translation variants="yes">
        <lengthvariant priority="1">主題：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">刪除重複項目：</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_workdays">
      <source>Repeats workdays</source>
      <translation variants="yes">
        <lengthvariant priority="1">在工作日重複</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_end_time_date">
      <source>- %1 %2</source>
      <translation variants="no">- %1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Delete</source>
      <translation variants="no">刪除</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_meeting">
      <source>Meeting</source>
      <translation variants="yes">
        <lengthvariant priority="1">會議</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_to_do">
      <source>To do</source>
      <translation variants="yes">
        <lengthvariant priority="1">待辦事項</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_send">
      <source>Send</source>
      <translation variants="no">傳送</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_yearly">
      <source>Repeats Yearly</source>
      <translation variants="yes">
        <lengthvariant priority="1">每年重複</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_save_to_calendar">
      <source>Save to calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">儲存至日曆</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Cancel</source>
      <translation variants="no">取消</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_start_end_time">
      <source>%1 - %2</source>
      <translation variants="no">%[11]1 - %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_delete">
      <source>Delete</source>
      <translation variants="no">刪除</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_start_time_date">
      <source>%1 %2</source>
      <translation variants="no">%[12]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_repeats_weekly">
      <source>Repeats weekly</source>
      <translation variants="yes">
        <lengthvariant priority="1">每週重複</lengthvariant>
      </translation>
    </message>
  </context>
</TS>