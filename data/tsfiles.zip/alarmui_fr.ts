<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="fr">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Snooze</source>
      <translation variants="yes">
        <lengthvariant priority="1">Répéter</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Clock alarm</source>
      <translation variants="no">Alarme de l'horloge</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snoozed_for_ln_minute">
      <source>Alarm snoozed for %Ln minutes</source>
      <translation>
        <numerusform plurality="a">L'alarme se déclenchera de nouveau dans %Ln minute</numerusform>
        <numerusform plurality="b">L'alarme se déclenchera de nouveau dans %Ln minutes</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Silence</source>
      <translation variants="yes">
        <lengthvariant priority="1">Silence</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Switch phone on ?</source>
      <translation variants="no">Allumer l'appareil?</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Calendar alarm</source>
      <translation variants="no">Alarme de l'agenda</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_stop">
      <source>Stop</source>
      <translation variants="yes">
        <lengthvariant priority="1">Arrêter</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>To-do note</source>
      <translation variants="no">Alarme des tâches</translation>
    </message>
  </context>
</TS>