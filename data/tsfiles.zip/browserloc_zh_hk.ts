<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_browser_network_switch_connection">
      <source>%1 is now in range.  Switch connection?</source>
      <translation variants="no">zh_hk #%1 is now in range.  Switch connection?</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_history">
      <source>History</source>
      <translation variants="no">zh_hk #History</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_cancel">
      <source>Cancel</source>
      <translation variants="no">zh_hk #Cancel</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_all">
      <source>Clear All</source>
      <translation variants="no">zh_hk #Clear All</translation>
    </message>
    <message numerus="no" id="txt_long_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">zh_hk #Web Browser</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_yes">
      <source>Yes</source>
      <translation variants="no">zh_hk #Yes</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_settings">
      <source>Settings</source>
      <translation variants="no">zh_hk #Settings</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_share">
      <source>Share</source>
      <translation variants="no">zh_hk #Share</translation>
    </message>
    <message numerus="no" id="txt_short_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">zh_hk #Web Browser</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_save_forms_passwords">
      <source>Save Forms/Passwords</source>
      <translation variants="no">zh_hk #Save Forms/Passwords</translation>
    </message>
    <message numerus="no" id="txt_browser_windows_windows">
      <source>Windows</source>
      <translation variants="no">zh_hk #Windows</translation>
    </message>
    <message numerus="no" id="txt_browser_history_this_month">
      <source>This Month</source>
      <translation variants="no">zh_hk #This Month</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_allow_popups">
      <source>Allow Pop-ups</source>
      <translation variants="no">zh_hk #Allow Pop-ups</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings">
      <source>General Settings</source>
      <translation variants="no">zh_hk #General Settings</translation>
    </message>
    <message numerus="no" id="txt_browser_history_history">
      <source>History</source>
      <translation variants="no">zh_hk #History</translation>
    </message>
    <message numerus="no" id="txt_browser_history_today">
      <source>Today</source>
      <translation variants="no">zh_hk #Today</translation>
    </message>
    <message numerus="no" id="txt_browser_tag_error_tag_file_could_not_be_downloaded">
      <source>Error: %1 could not be downloaded</source>
      <translation variants="no">zh_hk #Error: %1 could not be downloaded</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_settings">
      <source>Settings</source>
      <translation variants="no">zh_hk #Settings</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">zh_hk #Bookmarks</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_cache">
      <source>Cache</source>
      <translation variants="no">zh_hk #Cache</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding">
      <source>Character Encoding</source>
      <translation variants="no">zh_hk #Character Encoding</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_image_save_image">
      <source>Save Image</source>
      <translation variants="no">zh_hk #Save Image</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_browser">
      <source>Browser</source>
      <translation variants="no">zh_hk #Browser</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_exit">
      <source>Exit</source>
      <translation variants="no">zh_hk #Exit</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_save_browser_history">
      <source>Save Browser History</source>
      <translation variants="no">zh_hk #Save Browser History</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_done">
      <source>Done</source>
      <translation variants="no">zh_hk #Done</translation>
    </message>
    <message numerus="no" id="txt_browser_history_delete_are_you_sure">
      <source>Clear all history?</source>
      <translation variants="no">zh_hk #Clear all history?</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">zh_hk #Bookmarks</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding_unicode">
      <source>Unicode</source>
      <translation variants="no">zh_hk #Unicode</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_new_window">
      <source>New Window</source>
      <translation variants="no">zh_hk #New Window</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_navigation">
      <source>Navigation</source>
      <translation variants="no">zh_hk #Navigation</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_cookies">
      <source>Cookies</source>
      <translation variants="no">zh_hk #Cookies</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_link_share_link">
      <source>Share Link</source>
      <translation variants="no">zh_hk #Share Link</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_link_image">
      <source>Link/Image</source>
      <translation variants="no">zh_hk #Link/Image</translation>
    </message>
    <message numerus="no" id="txt_browser_history_yesterday">
      <source>Yesterday</source>
      <translation variants="no">zh_hk #Yesterday</translation>
    </message>
    <message numerus="no" id="txt_browser_input_dial_edit_bm">
      <source>Edit Bookmark</source>
      <translation variants="no">zh_hk #Edit Bookmark</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding_automatic">
      <source>Automatic</source>
      <translation variants="no">zh_hk #Automatic</translation>
    </message>
    <message numerus="no" id="txt_browser_history_this_week">
      <source>This Week</source>
      <translation variants="no">zh_hk #This Week</translation>
    </message>
    <message numerus="no" id="txt_browser_offline">
      <source>Offline</source>
      <translation variants="no">zh_hk #Offline</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_about">
      <source>About Browser</source>
      <translation variants="no">zh_hk #About Browser</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">zh_hk #Web Browser</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_form_data">
      <source>Form Data</source>
      <translation variants="no">zh_hk #Form Data</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">zh_hk #Bookmarks</translation>
    </message>
    <message numerus="no" id="txt_browser_error_generic_error_msg">
      <source>Network error</source>
      <translation variants="no">zh_hk #Network error</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_block_popups">
      <source>Block Popups</source>
      <translation variants="no">zh_hk #Block Popups</translation>
    </message>
    <message numerus="no" id="txt_browser_downloading_file">
      <source>Downloading %1</source>
      <translation variants="no">zh_hk #Downloading %1</translation>
    </message>
    <message numerus="no" id="txt_browser_windows_new_window">
      <source>New Window</source>
      <translation variants="no">zh_hk #New Window</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_link">
      <source>Link</source>
      <translation variants="no">zh_hk #Link</translation>
    </message>
    <message numerus="no" id="txt_browser_file_has_finished_downloading">
      <source>%1 has finished downloading</source>
      <translation variants="no">zh_hk #%1 has finished downloading</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_no">
      <source>No</source>
      <translation variants="no">zh_hk #No</translation>
    </message>
    <message numerus="no" id="txt_browser_error_page_load_failed">
      <source>Unable to load page</source>
      <translation variants="no">zh_hk #Unable to load page</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_page">
      <source>Page</source>
      <translation variants="no">zh_hk #Page</translation>
    </message>
    <message numerus="no" id="txt_browser_input_dial_add_bm">
      <source>Add Bookmark</source>
      <translation variants="no">zh_hk #Add Bookmark</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_link_open_link">
      <source>Open Link in New Window</source>
      <translation variants="no">zh_hk #Open Link in New Window</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_windows">
      <source>Windows</source>
      <translation variants="no">zh_hk #Windows</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_image">
      <source>Image</source>
      <translation variants="no">zh_hk #Image</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data">
      <source>Clear Data</source>
      <translation variants="no">zh_hk #Clear Data</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_history">
      <source>History</source>
      <translation variants="no">zh_hk #History</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_add_bookmark">
      <source>Add Bookmark</source>
      <translation variants="no">zh_hk #Add Bookmark</translation>
    </message>
    <message numerus="no" id="txt_browser_chrome_suggests_search_for">
      <source>Search for %1</source>
      <translation variants="no">zh_hk #Search for %1</translation>
    </message>
    <message numerus="no" id="txt_browser_most_visited_title">
      <source>Most Visited</source>
      <translation variants="no">zh_hk #Most Visited</translation>
    </message>
  </context>
</TS>