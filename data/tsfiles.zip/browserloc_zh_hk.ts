<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">瀏覽器</translation>
    </message>
    <message numerus="no" id="txt_short_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">瀏覽器</translation>
    </message>
    <message numerus="no" id="txt_long_caption_browser">
      <source>Web Browser</source>
      <translation variants="no">瀏覽器</translation>
    </message>
    <message numerus="no" id="txt_browser_windows_windows">
      <source>Windows</source>
      <translation variants="no">視窗</translation>
    </message>
    <message numerus="no" id="txt_browser_windows_new_window">
      <source>New Window</source>
      <translation variants="no">新視窗</translation>
    </message>
    <message numerus="no" id="txt_browser_tag_error_tag_file_could_not_be_downloaded">
      <source>Error: %1 could not be downloaded</source>
      <translation variants="no">無法下載"%[99]1"</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_settings">
      <source>Settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_yes">
      <source>Yes</source>
      <translation variants="no">是</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_save_forms_passwords">
      <source>Save Forms/Passwords</source>
      <translation variants="no">儲存表單和密碼</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_save_browser_history">
      <source>Save Browser History</source>
      <translation variants="no">儲存瀏覽記錄</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_no">
      <source>No</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding_unicode">
      <source>Unicode</source>
      <translation variants="no">Unicode</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding_automatic">
      <source>Automatic</source>
      <translation variants="no">自動</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_character_encoding">
      <source>Character Encoding</source>
      <translation variants="no">字符編碼</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings_about">
      <source>About Browser</source>
      <translation variants="no">關於瀏覽器</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_general_settings">
      <source>General Settings</source>
      <translation variants="no">一般設定</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_history">
      <source>History</source>
      <translation variants="no">瀏覽記錄</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_form_data">
      <source>Form Data</source>
      <translation variants="no">表單資料</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_cookies">
      <source>Cookies</source>
      <translation variants="no">Cookie</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_cache">
      <source>Cache</source>
      <translation variants="no">快取記憶</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">書籤</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data">
      <source>Clear Data</source>
      <translation variants="no">清除數據</translation>
    </message>
    <message numerus="no" id="txt_browser_offline">
      <source>Offline</source>
      <translation variants="no">離線</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection">
      <source>%1 is now in range.  Switch connection?</source>
      <translation variants="no">%[99]1現在已在範圍內。是否切換連接？</translation>
    </message>
    <message numerus="no" id="txt_browser_input_dial_edit_bm">
      <source>Edit Bookmark</source>
      <translation variants="no">修改書籤</translation>
    </message>
    <message numerus="no" id="txt_browser_input_dial_add_bm">
      <source>Add Bookmark</source>
      <translation variants="no">加入書籤</translation>
    </message>
    <message numerus="no" id="txt_browser_history_yesterday">
      <source>Yesterday</source>
      <translation variants="no">昨天</translation>
    </message>
    <message numerus="no" id="txt_browser_history_today">
      <source>Today</source>
      <translation variants="no">今天</translation>
    </message>
    <message numerus="no" id="txt_browser_history_this_week">
      <source>This Week</source>
      <translation variants="no">本週</translation>
    </message>
    <message numerus="no" id="txt_browser_history_this_month">
      <source>This Month</source>
      <translation variants="no">本月</translation>
    </message>
    <message numerus="no" id="txt_browser_history_history">
      <source>History</source>
      <translation variants="no">瀏覽記錄</translation>
    </message>
    <message numerus="no" id="txt_browser_history_delete_are_you_sure">
      <source>Are you sure you want to permanently delete your history?</source>
      <translation variants="no">是否永久刪除瀏覽記錄？</translation>
    </message>
    <message numerus="no" id="txt_browser_file_has_finished_downloading">
      <source>%1 has finished downloading</source>
      <translation variants="no">下載完成：%1</translation>
    </message>
    <message numerus="no" id="txt_browser_error_page_load_failed">
      <source>Unable to load page</source>
      <translation variants="no">無法載入頁面</translation>
    </message>
    <message numerus="no" id="txt_browser_error_generic_error_msg">
      <source>Network error</source>
      <translation variants="no">網絡錯誤</translation>
    </message>
    <message numerus="no" id="txt_browser_downloading_file">
      <source>Downloading %1</source>
      <translation variants="no">正在下載%1</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_new_window">
      <source>New Window</source>
      <translation variants="no">新視窗</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_page">
      <source>Page</source>
      <translation variants="no">網頁</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_link_image">
      <source>Link/Image</source>
      <translation variants="no">圖像連結</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_link">
      <source>Link</source>
      <translation variants="no">連結</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_image">
      <source>Image</source>
      <translation variants="no">圖像</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_block_popups">
      <source>Block Popups</source>
      <translation variants="no">封鎖彈出式視窗</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_allow_popups">
      <source>Allow Pop-ups</source>
      <translation variants="no">允許彈出式視窗</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_add_bookmark">
      <source>Add Bookmark</source>
      <translation variants="no">加入書籤</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_windows">
      <source>Windows</source>
      <translation variants="no">視窗</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_settings">
      <source>Settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_history">
      <source>History</source>
      <translation variants="no">瀏覽記錄</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_exit">
      <source>Exit Browser</source>
      <translation variants="no">退出瀏覽器</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_nav_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">書籤</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_link_open_link">
      <source>Open Link in New Window</source>
      <translation variants="no">在新視窗開啟連結</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_image_save_image">
      <source>Save Image</source>
      <translation variants="no">儲存圖像</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_browser">
      <source>Browser</source>
      <translation variants="no">瀏覽器</translation>
    </message>
    <message numerus="no" id="txt_browser_chrome_suggests_search_for">
      <source>Search for %1</source>
      <translation variants="no">尋找%1</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_done">
      <source>Done</source>
      <translation variants="no">完成</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_cancel">
      <source>Cancel</source>
      <translation variants="no">取消</translation>
    </message>
    <message numerus="no" id="txt_browser_bookmarks_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">書籤</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection_yes">
      <source>Yes</source>
      <translation variants="no">是</translation>
    </message>
    <message numerus="no" id="txt_browser_network_switch_connection_no">
      <source>No</source>
      <translation variants="no">否</translation>
    </message>
    <message numerus="no" id="txt_browser_most_visited_title_most_visited">
      <source>Most Visited</source>
      <translation variants="no">最常瀏覽</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_tab_navigation">
      <source>Navigation</source>
      <translation variants="no">瀏覽</translation>
    </message>
    <message numerus="no" id="txt_browser_error_dialog_close_some">
      <source>Close some browser windows or applications.</source>
      <translation variants="no">請關閉一些瀏覽器視窗或應用程式。</translation>
    </message>
    <message numerus="no" id="txt_browser_error_dialog_device_low">
      <source>Device Low On Memory</source>
      <translation variants="no">裝置記憶體不足。</translation>
    </message>
    <message numerus="no" id="txt_browser_settings_clear_data_all">
      <source>Clear All</source>
      <translation variants="no">全部清除</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_link_share_link">
      <source>Share Link</source>
      <translation variants="no">分享連結</translation>
    </message>
    <message numerus="no" id="txt_browser_content_view_menu_page_share">
      <source>Share</source>
      <translation variants="no">分享</translation>
    </message>
  </context>
</TS>