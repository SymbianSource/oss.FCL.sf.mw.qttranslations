<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_usb_dpinfo_headset_in_use">
      <source>headset in use</source>
      <translation variants="no">ہیڈسیٹ زیر استعمال</translation>
    </message>
    <message numerus="no" id="txt_usb_info_hubs_are_not_supported_disconnect_us">
      <source>Hubs are not supported. Disconnect device.</source>
      <translation variants="no">ہبز تائید شدہ نہیں۔ آلے کو منقطع کریں۔</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_ovi_suite">
      <source>to OVI suite</source>
      <translation variants="no">Nokia Ovi Suite</translation>
    </message>
    <message numerus="no" id="txt_usb_info_disk_full_remove_some_files_and_try">
      <source>Disk full. Remove some files and try connect USB cable again</source>
      <translation variants="no">ڈسک بھری ہوئی ہے۔ کچھ فائلوں کو ہٹائیں اور USB کیبل دوبارہ متصل کریں۔</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_use_file_system_in_device">
      <source>Unable to use file system in device. Disconnect device.</source>
      <translation variants="no">آلے میں فائل نظام استعمال کرنے سے قاصر۔ کیبل کو منقطع کریں۔</translation>
    </message>
    <message numerus="no" id="txt_usb_info_memory_full_close_some_applications">
      <source>Memory full. Close some applications and try to connect USB cable again.</source>
      <translation variants="no">حافظہ بھرا ہوا ہے۔ کچھ پروگراموں کو بند کریں اور USB کیبل دوبارہ متصل کریں۔</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_safe_to_remove">
      <source>Safe to remove</source>
      <translation variants="no">ہٹانے کے لیے محفوظ</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_mass_storage">
      <source>as mass storage</source>
      <translation variants="no">وسیع ذخیرہ وضع</translation>
    </message>
    <message numerus="no" id="txt_usb_info_error_in_usb_connection_disconnect_d">
      <source>Error in USB connection. Disconnect device.</source>
      <translation variants="no">USB اتصال میں غلطی۔ آلے کو منقطع کریں۔</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unsupported_usb_device_disconnect_de">
      <source>Unsupported USB device. Disconnect device.</source>
      <translation variants="no">غیر تائید شدہ USB آلہ۔ آلہ منقطع کریں۔</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_media_transfer">
      <source>as media transfer</source>
      <translation variants="no">میڈیا منتقلی وضع</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_eject_the_usb_device_some">
      <source>Unable to eject the USB device. Some of the applications may still be using it.</source>
      <translation variants="no">USB آلے کو خارج کرنے سے قاصر۔ کچھ پروگرام شاید اب بھی اسے استعمال کر رہے ہیں۔</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unknown_file_system_disconnect_devic">
      <source>Unknown file system. Disconnect device.</source>
      <translation variants="no">نامعلوم فائل نظام۔ آلہ منقطع کریں۔</translation>
    </message>
    <message numerus="no" id="txt_usb_dpophead_usb_connected">
      <source>USB connected</source>
      <translation variants="no">USB متصل</translation>
    </message>
    <message numerus="no" id="txt_usb_info_remove_usb_cable_or_connect_a_device">
      <source>Remove USB cable or connect a device.</source>
      <translation variants="no">USB کیبل ہٹائیں یا آلہ متصل کریں۔</translation>
    </message>
    <message numerus="no" id="txt_usb_dpinfo_phone_as_modem">
      <source>as web connection</source>
      <translation variants="no">PC کو انٹرنیٹ وضع سے متصل کریں</translation>
    </message>
    <message numerus="no" id="txt_usb_info_partially_supported_usb_device_connec">
      <source>Partially supported USB device connected. All functionality might not work.</source>
      <translation variants="no">چزوی طور پر تائید شدہ USB آلہ متصل کیا گیا۔ تمام آلے شاید کام نہ کریں۔</translation>
    </message>
    <message numerus="no" id="txt_usb_dpophead_usb_disconnected">
      <source>USB disconnected</source>
      <translation variants="no">USB غیر متصل</translation>
    </message>
    <message numerus="no" id="txt_usb_info_unable_to_show_a_memory_to_other_devi">
      <source>Unable to show a memory to other device.</source>
      <translation variants="no">دوسرے آلے کو حافطہ دکھانے سے قاصر</translation>
    </message>
  </context>
</TS>