<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_long_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">Lịch</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_before_date">
      <source>Before date</source>
      <translation variants="no">Trước ngày được chọn</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_unnamed">
      <source>Unnamed</source>
      <translation variants="no">(chưa đặt tên)</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_mo">
      <source>Mo</source>
      <translation variants="no">T2</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[28]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_date">
      <source>Go to date</source>
      <translation variants="no">Chuyển đến ngày</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_fr">
      <source>Fr</source>
      <translation variants="no">T6</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_event">
      <source>New event</source>
      <translation variants="no">Mục lịch mới</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_all_entries">
      <source>All entries</source>
      <translation variants="no">Tất cả mục lịch</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_entries">
      <source>Delete entries</source>
      <translation variants="no">Xóa mục lịch</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_settings">
      <source>Settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_main_view">
      <source>Calendar main view</source>
      <translation variants="no">Ch.đến g.diện Lịch chính</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">Ngày kết thúc: %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_su">
      <source>Su</source>
      <translation variants="no">CN</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_th">
      <source>Th</source>
      <translation variants="no">T5</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">Xóa cuộc họp?</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">Xóa ghi chú công việc?</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_sa">
      <source>Sa</source>
      <translation variants="no">T7</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">Chỉ sự kiện này</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_week_numbers">
      <source>Show week numbers</source>
      <translation variants="no">Hiển thị số tuần</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_no_entries">
      <source>No entries</source>
      <translation variants="no">Không có mục lịch cho ngày hôm nay</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="no">(chưa đặt tên)</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="no">Xóa mục lịch lặp lại:</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_yes">
      <source>Yes</source>
      <translation variants="no">Có</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_set_date">
      <source>Set date</source>
      <translation variants="no">Đặt ngày</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">Đánh dấu xong</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="no">Lịch</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_start_end_time">
      <source>%1 -%2</source>
      <translation variants="no">%[08]1 - %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_switch_to_agenda_view">
      <source>Switch to Agenda view</source>
      <translation variants="no">Ch.sang chế độ xem c.việc</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_lunar_calendar">
      <source>Show lunar calendar</source>
      <translation variants="no">Hiển thị âm lịch</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_allday_event">
      <source>Delete All-day event?</source>
      <translation variants="no">Xóa mục lịch của cả ngày?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_friday">
      <source>Friday</source>
      <translation variants="no">Thứ Sáu</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time">
      <source>Reminder snooze time</source>
      <translation variants="no">Thời gian báo lại âm báo</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_tu">
      <source>Tu</source>
      <translation variants="no">T3</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_today">
      <source>Go to today</source>
      <translation variants="no">Ch.đến ngày hôm nay</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">Tất cả sự kiện</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_thursday">
      <source>Thursday</source>
      <translation variants="no">Thứ Năm</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_tuesday">
      <source>Tuesday</source>
      <translation variants="no">Thứ Ba</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_15">
      <source>15 minutes</source>
      <translation variants="no">15 phút</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_buddhist_year">
      <source>Show buddhist year</source>
      <translation variants="no">Hiển thị năm Phật giáo</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_5_m">
      <source>5 minutes</source>
      <translation variants="no">5 phút</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_saturday">
      <source>Saturday</source>
      <translation variants="no">Thứ Bảy</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_we">
      <source>We</source>
      <translation variants="no">T4</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_30">
      <source>30 minutes</source>
      <translation variants="no">30 phút</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on">
      <source>Week starts on</source>
      <translation variants="no">Tuần bắt đầu vào</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_sunday">
      <source>Sunday</source>
      <translation variants="no">Chủ Nhật</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_10">
      <source>10 minutes</source>
      <translation variants="no">10 phút</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_show_lunar_data">
      <source>Show lunar data</source>
      <translation variants="no">Hiển thị dữ liệu âm lịch</translation>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_snooze_time_val_ln">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">%Ln phút</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_wednesday">
      <source>Wednesday</source>
      <translation variants="no">Thứ Tư</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_switch_to_day_view">
      <source>Switch to Day view</source>
      <translation variants="no">Ch.sang chế độ xem ngày</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_week_starts_on_val_monday">
      <source>Monday</source>
      <translation variants="no">Thứ Hai</translation>
    </message>
    <message numerus="no" id="txt_calendar_empty_list_no_entries">
      <source>No entries for today</source>
      <translation variants="no">Không có mục lịch cho ngày hôm nay</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_all_calendar_entries">
      <source>Delete all calendar entries?</source>
      <translation variants="no">Xóa tất cả mục lịch?</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_wk">
      <source>Wk</source>
      <translation variants="no">Tuần</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_yes">
      <source>Yes</source>
      <translation variants="no">Có</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_yes">
      <source>Yes</source>
      <translation variants="no">Có</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_settings">
      <source>Settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_no">
      <source>No</source>
      <translation variants="no">Không</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="no">Chỉnh sửa mục lịch lặp lại:</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_no">
      <source>No</source>
      <translation variants="no">Không</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_no">
      <source>No</source>
      <translation variants="no">Không</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">Lịch</translation>
    </message>
  </context>
</TS>