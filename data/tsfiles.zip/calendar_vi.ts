<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unnamed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_event">
      <source>Event</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Entry</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_delete_repeated_entry">
      <source>Delete repeated entry :</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Delete repeated entry :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_anniversary">
      <source>New anniversary</source>
      <translation variants="no">vi #New anniversary</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_we">
      <source>We</source>
      <translation variants="no">vi ##We</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_meeting">
      <source>Delete meeting?</source>
      <translation variants="no">vi #Delete meeting?</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_meeting">
      <source>New meeting</source>
      <translation variants="no">vi #New meeting</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_15">
      <source>15 minutes</source>
      <translation variants="no">vi #15 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_30">
      <source>30 minutes</source>
      <translation variants="no">vi #30 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_regional_information">
      <source>Regional information</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Regional information</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_10">
      <source>10 minutes</source>
      <translation variants="no">vi #10 minutes</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">vi #%[28]1 %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_entries">
      <source>Delete entries ?</source>
      <translation variants="no">vi #Delete entries?</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_15_min">
      <source>15 minutes</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_set_date">
      <source>Set date</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Set date</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_softkey1_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Cancel</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_yes">
      <source>Yes</source>
      <translation variants="no">vi #Yes</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_sa">
      <source>Sa</source>
      <translation variants="no">vi ##Sa</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_edit">
      <source>Edit :</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Edit :</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_today">
      <source>Go to today</source>
      <translation variants="no">vi #Go to today</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_su">
      <source>Su</source>
      <translation variants="no">vi ##Su</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_30_min">
      <source>30 minutes</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_this_occurrence_only">
      <source>This occurrence only</source>
      <translation variants="no">vi #This occurrence only</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_yes">
      <source>Yes</source>
      <translation variants="no">vi #Yes</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_all_calendar_entries">
      <source>Delete all calendar entries?</source>
      <translation variants="no">vi #Delete all calendar entries?</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_yes">
      <source>Yes</source>
      <translation variants="no">vi #Yes</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time_val_5_m">
      <source>5 minutes</source>
      <translation variants="no">vi #5 minutes</translation>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_snooze_time_val_ln">
      <source>%Ln minutes</source>
      <translation>
        <numerusform plurality="a">vi #%Ln minutes</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_anniversary">
      <source>Delete anniversary?</source>
      <translation variants="no">vi #Delete anniversary?</translation>
    </message>
    <message numerus="no" id="txt_calendar_month_label_title_12">
      <source>%1%2</source>
      <translation variants="no">vi ##%1%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_dialog_delete">
      <source>Delete</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Delete</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_tu">
      <source>Tu</source>
      <translation variants="no">vi ##Tu</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_lunar_no">
      <source>No</source>
      <translation variants="no">vi #No</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">vi ##Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_lunar_calendar">
      <source>Show lunar calendar</source>
      <translation variants="no">vi #Show lunar calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_thai_no">
      <source>No</source>
      <translation variants="no">vi #No</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_delete_todo_note">
      <source>Delete To-do note?</source>
      <translation variants="no">vi #Delete to-do note?</translation>
    </message>
    <message numerus="no" id="txt_task_switcher_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_main_view">
      <source>Calendar main view</source>
      <translation variants="no">vi #Go to Calendar main view</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_settings">
      <source>Settings</source>
      <translation variants="no">vi #Settings</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_unnamed">
      <source>Unnamed</source>
      <translation variants="no">vi ##Unnamed</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_1_2">
      <source>%1 -%2</source>
      <translation variants="no">vi #%[20]1 - %2</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_no_entries">
      <source>No entries for today</source>
      <translation variants="no">vi ##No entries for today</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_ln_mi">
      <source>%Ln minutes</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_new_event">
      <source>New event</source>
      <translation variants="no">vi #New calendar entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_biweekly">
      <source>Bi-weekly</source>
      <translation variants="no">vi #Fortnightly</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat">
      <source>Repeat</source>
      <translation variants="no">vi #Repeat</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_from">
      <source>From</source>
      <translation variants="no">vi #From</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location">
      <source>Location</source>
      <translation variants="no">vi #Location</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_minu">
      <source>Before %Ln minutes</source>
      <translation variants="no">vi #%Ln minute before</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_daydate">
      <source>&lt;Day&gt;&lt;Date&gt;</source>
      <translation variants="no">vi #Day date</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event">
      <source>All day event</source>
      <translation variants="no">vi #All-day entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description">
      <source>Add description</source>
      <translation variants="no">vi #Add description</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_before_date">
      <source>Before date</source>
      <translation variants="no">vi #Before selected date</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date">
      <source>Start date</source>
      <translation variants="no">vi #Start date</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_new_event">
      <source>New event</source>
      <translation variants="no">vi #New entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_description">
      <source>Description</source>
      <translation variants="no">vi #Description</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date">
      <source>End date</source>
      <translation variants="no">vi #End date</translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_calendar_settings">
      <source>Calendar settings</source>
      <translation variants="no">vi #Settings</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once">
      <source>Only once</source>
      <translation variants="no">vi #Not repeated</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily">
      <source>Daily</source>
      <translation variants="no">vi #Daily</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time">
      <source>End time</source>
      <translation variants="no">vi #End time</translation>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject">
      <source>Subject</source>
      <translation variants="no">vi #Subject</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time">
      <source>Alarm snooze time</source>
      <translation variants="no">vi #Alarm snooze time</translation>
    </message>
    <message numerus="no" id="txt_common_opt_help">
      <source>Not specified</source>
      <translation variants="no">vi #Help</translation>
    </message>
    <message numerus="no" id="txt_calendar_toggle_no">
      <source>No</source>
      <translation variants="no">vi #Hidden</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_settings">
      <source>Calendar settings</source>
      <translation variants="no">vi #Settings</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_val_ln_minutes">
      <source>%Ln minutes</source>
      <translation variants="no">vi #%Ln minute</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_undone">
      <source>Mark as undone</source>
      <translation variants="no">vi #Mark as not done</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done">
      <source>Mark as done</source>
      <translation variants="no">vi #Mark as done</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_all_entries">
      <source>All entries</source>
      <translation variants="no">vi #All entries</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly">
      <source>Yearly</source>
      <translation variants="no">vi #Yearly</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_days">
      <source>Before %Ln days</source>
      <translation variants="no">vi #%Ln day before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly">
      <source>Weekly</source>
      <translation variants="no">vi #Weekly</translation>
    </message>
    <message numerus="no" id="txt_calendar_preview_daydate">
      <source>&lt;Day&gt;&lt;Date&gt;</source>
      <translation variants="no">vi #Day date</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_entries">
      <source>Delete entries</source>
      <translation variants="no">vi #Delete entries</translation>
    </message>
    <message numerus="no" id="txt_calendar_toggle_yes">
      <source>Yes</source>
      <translation variants="no">vi #Shown</translation>
    </message>
    <message numerus="no" id="txt_short_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">vi #Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_th">
      <source>Th</source>
      <translation variants="no">vi ##Th</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_buddhist_year">
      <source>Show buddhist year</source>
      <translation variants="no">vi #Show Buddhist year</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_10_min">
      <source>10 minutes</source>
      <translation variants="no">vi ##</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Close</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_monthyear">
      <source>&lt;Month&gt;&lt;Year&gt;</source>
      <translation variants="no">vi #Month year</translation>
    </message>
    <message numerus="no" id="txt_calendar_menu_send">
      <source>Send</source>
      <translation variants="no">vi #Send</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar">
      <source>Calendar</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Calendar</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_to">
      <source>To</source>
      <translation variants="no">vi #To</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_week">
      <source>Before %Ln weeks</source>
      <translation variants="no">vi #%Ln week before</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_week_numbers">
      <source>Show week numbers</source>
      <translation variants="no">vi #Week numbers</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar">
      <source>Calendar</source>
      <translation variants="no">vi #Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_empty_list_no_entries">
      <source>No entries for today</source>
      <translation variants="no">vi ##No entries for today</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_fr">
      <source>Fr</source>
      <translation variants="no">vi ##Fr</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_no">
      <source>No</source>
      <translation variants="no">vi #No</translation>
    </message>
    <message numerus="no" id="txt_calendar_dblist_val_due_on_1">
      <source>Due on %1</source>
      <translation variants="no">vi #Due date: %1</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time">
      <source>Start time</source>
      <translation variants="no">vi #Start time</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_wk">
      <source>Wk</source>
      <translation variants="no">vi ##Wk</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_event">
      <source>Delete event</source>
      <translation variants="no">vi #Delete entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly">
      <source>Monthly</source>
      <translation variants="no">vi #Monthly</translation>
    </message>
    <message numerus="no" id="txt_calendar_grid_day_mo">
      <source>Mo</source>
      <translation variants="no">vi ##Mo</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_time">
      <source>&lt;Time&gt;</source>
      <translation variants="no">vi #Time</translation>
    </message>
    <message numerus="no" id="txt_calendar_subhead_calendar_settings">
      <source>Calendar settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_info_all_occurences">
      <source>All occurences</source>
      <translation variants="no">vi #All occurences</translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Not specified</source>
      <translation variants="no">vi #Delete</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_attachment">
      <source>Add attachment</source>
      <translation variants="no">vi #Add attachment</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until">
      <source>Repeat until</source>
      <translation variants="no">vi #Repeat until</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_val_before_ln_hour">
      <source>Before %Ln hours</source>
      <translation variants="no">vi #%Ln hour before</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_event">
      <source>New event</source>
      <translation variants="no">vi #New entry</translation>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_date">
      <source>Go to date</source>
      <translation variants="no">vi #Go to date</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder_snooze_time">
      <source>Reminder snooze time</source>
      <translation variants="no">vi #Alarm snooze time</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder">
      <source>Reminder</source>
      <translation variants="no">vi #Alarm</translation>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time_val_5_minu">
      <source>5 minutes</source>
      <translation variants="no">vi ##</translation>
    </message>
  </context>
</TS>