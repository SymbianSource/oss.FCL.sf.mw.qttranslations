<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="tl">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_info_delete_all_paired_devices_some_device">
      <source>Delete all paired devices? Some devices may be disconnected.</source>
      <translation variants="no">Tanggalin ang lahat ng naipares na aparato? Maaaring madiskonekta ang ilang mga aparato.</translation>
    </message>
    <message numerus="no" id="txt_bt_title_unable_to_enter_sim_access_profile">
      <source>Unable to enter SIM access profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Di maaktiba mode na remote SIM</lengthvariant>
        <lengthvariant priority="2">Di mktiba mode na rem. SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_connected">
      <source>Connected</source>
      <translation variants="no">Nakakonekta sa</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_devices_some_devices_may_b">
      <source>Delete all devices? Some devices may be disconnected.</source>
      <translation variants="no">Tanggalin ang lahat ng aparato? Maaaring madiskonekta ang ilang aparato.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unsupported_device_1">
      <source>Unsupported device: %1</source>
      <translation variants="no">Hindi sinusuportahang aparato:
%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_waiting_the_other_device">
      <source>Waiting for the other device</source>
      <translation variants="no">Naghihintay sa kabilang aparato</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to">
      <source>Connect to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ikonekta sa:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_there_seems_to_be_a_lot_of_pairing_que">
      <source>There seems to be uncommonly lot of pairing queries. Turn Bluetooth off to protect your device?</source>
      <translation variants="no">Na-detect di karani­wang dami ng tanong sa pagpapares. Deakti­bahin Bluetooth para prtktahan aparato mo?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_other_files_received">
      <source>N other files received</source>
      <translation variants="no">tl ##N other files received</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_on_ini_offline_mode">
      <source>Trun Bluetooth on in offline mode?</source>
      <translation variants="no">Aktibahin ang Bluetooth sa mode na offline?</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_with_1_failed_either_the_pas">
      <source>Pairing with %1 failed. Either the passcodes didn’t match or the other device is turned off.</source>
      <translation variants="no">Nabigo ang pagpapa­res sa %[06]1. Alinma'y di tumugma ang mga passcodes o naka-off ang kabilang aparato.</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_use">
      <source>in use</source>
      <translation variants="no">aktibahin</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_off">
      <source>is now off</source>
      <translation variants="no">ay naka-off na</translation>
    </message>
    <message numerus="no" id="txt_bt_info_enter_the_following_code_to_the_1">
      <source>Enter the following code to the %1:</source>
      <translation variants="no">Ipasok ang sumusunod na passcode sa %[36]1:</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_bluetooth_used">
      <source>Bluetooth used</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sim_access_profile">
      <source>SIM access profile</source>
      <translation variants="no">Mode na remote SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_info_not_possible_during_a_call">
      <source>Not possible during a call</source>
      <translation variants="no">Hindi makalikha ng koneksyong Bluetooth habang tumatawag</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_paired_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dialog_please_enter_the_passcode_for_1">
      <source>Please enter the passcode for %1:</source>
      <translation variants="no">Ipasok ang passcode para sa %[46]1:</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_on">
      <source>is now on</source>
      <translation variants="no">ay naka-on na</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pairing_with_1">
      <source>Pairing with %1</source>
      <translation variants="no">Ipinapares sa %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_pairing_failed_remote_device_is_pairi">
      <source>Pairing failed. Remote device is pairing with another device.</source>
      <translation variants="no">Nabigo ang pagpapares. Pumapares ang remote na aparato sa isa pang aparato.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_delete_all_blocked_devices">
      <source>Delete all blocked devices?</source>
      <translation variants="no">Tanggalin ang lahat ng naka-block na aparato?</translation>
    </message>
    <message numerus="no" id="txt_bt_button_more_devices">
      <source>More devices</source>
      <translation variants="yes">
        <lengthvariant priority="1">Aparato pa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_bluetooth_not_allowed_to_be_turned_on">
      <source>Bluetooth not allowed to be turned on in offline mode</source>
      <translation variants="no">Hindi maaktiba ang Bluetooth sa mode na offline</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_cancelled_from_1">
      <source>from %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_connected_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_entering_sim_access_profile">
      <source>Entering SIM access profile</source>
      <translation variants="no">Inaaktiba ang mode na remote SIM</translation>
    </message>
    <message numerus="no" id="txt_bt_title_received_from_1">
      <source>Received from %1</source>
      <translation variants="no">Tinatanggap mula sa %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_exited">
      <source>exited</source>
      <translation variants="no">hindi aktibo</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_disconnected">
      <source>Disconnected</source>
      <translation variants="no">Nadiskonekta sa</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_unpaired">
      <source>Unpaired</source>
      <translation variants="no">Inalis pagpapares sa</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_receiving_failed">
      <source>Receiving failed</source>
      <translation variants="no">Bigo ang pagtanggap</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from">
      <source>Receive messages from:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tumanggap ng mensahe mula sa:</lengthvariant>
        <lengthvariant priority="2">Tmanggap ng msh. mula sa:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_disconnected_from_1">
      <source>from %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_is_now_hidden">
      <source>is now hidden</source>
      <translation variants="no">ay nakatago na</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_paired">
      <source>Paired</source>
      <translation variants="no">Naka-pares sa</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_sending_cancelled">
      <source>Sending cancelled</source>
      <translation variants="no">Kinansela pgppadala</translation>
    </message>
    <message numerus="no" id="txt_bt_info_do_you_still_want_to_enable_sim_access">
      <source>Do you still want to enable SIM access profile?</source>
      <translation variants="no">Aktibahin ang mode na remote SIM?</translation>
    </message>
    <message numerus="no" id="txt_bt_title_sending_file_l1l2_to_3">
      <source>Sending file %L1/%L2 to %3</source>
      <translation variants="no">Ipinapadala %L1/%L2 sa %3</translation>
    </message>
    <message numerus="no" id="txt_bt_info_trun_bluetooth_off_there_is_an_active">
      <source>Trun Bluetooth off? There is an active connection.</source>
      <translation variants="no">Umiiral ang aktibong koneksyon ng Bluetooth. Aktibahin pa rin ang bagong koneksyon?</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_battery_low">
      <source>Battery low</source>
      <translation variants="no">Mhina ang baterya sa</translation>
    </message>
    <message numerus="no" id="txt_bt_title_pair_with">
      <source>Pair with:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ipares sa:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_button_try_again">
      <source>Try again</source>
      <translation variants="yes">
        <lengthvariant priority="1">Subukan muli</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_disable_sim_access_profile">
      <source>Exit SIM access profile?</source>
      <translation variants="no">Deaktibahin ang mode na remote SIM?</translation>
    </message>
    <message numerus="no" id="txt_bt_title_connect_to_paired_device">
      <source>Connect to paired device:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ikonekta sa aparatong naipares:</lengthvariant>
        <lengthvariant priority="2">Iknekta sa apar. naipares:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_sim_access_profile_is_used_next_time_t">
      <source>SIM access profile is used next time the car kit connects to this device and the Bluetooth is turned on.</source>
      <translation variants="no">Inaaktiba ang mode na remote SIM sa susunod kapag ikinonekta ang car kit sa aparatong ito at naka-on ang Bluetooth.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_pair_with_1">
      <source>Unable to pair with %1</source>
      <translation variants="no">Hindi maipares sa %1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_bluetooth_device_address_1">
      <source>Bluetooth device address: %1</source>
      <translation variants="no">Address ng aparatong Bluetooth:
%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_perform_bluetooth_operation">
      <source>Unable to perform Bluetooth operation</source>
      <translation variants="no">Hindi makapagsagawa ng operasyong Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_title_operation_not_possible_when_sim_acces">
      <source>Operation not possible when SIM access profile is in use</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hindi maisagawa ang operasyon</lengthvariant>
        <lengthvariant priority="2">tl #Operation not possible in remote SIM mode</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_title_receive_messages_from_paired_device">
      <source>Receive messages from paired device:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tumanggap ng mensahe mula sa:</lengthvariant>
        <lengthvariant priority="2">Tmanggap ng msh. mula sa:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_unable_to_connect_with_bluetooth">
      <source>Unable to connect with %1</source>
      <translation variants="no">Hindi makakonekta sa %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpophead_all_files_sent">
      <source>All files sent</source>
      <translation variants="no">Pndala lhat ng file sa</translation>
    </message>
    <message numerus="no" id="txt_bt_title_receiving_files_from_1">
      <source>Receiving from %1</source>
      <translation variants="no">Tintanggap mula sa %1</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_with_1">
      <source>with %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_title_send_to">
      <source>Send to:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ipadala kay:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_info_does_this_code_match_the_code_on_1">
      <source>Does this code match the code on %1?</source>
      <translation variants="no">Tumutugma ba ang sumusunod na passcode sa code sa %[16]1?</translation>
    </message>
    <message numerus="no" id="txt_bt_list_dont_ask_again_with_this_device">
      <source>Don't ask again with this device</source>
      <translation variants="no">Huwag na muling tanungin sa aparatong ito</translation>
    </message>
    <message numerus="no" id="txt_bt_title_no_sim_card_in_the_device">
      <source>No SIM card in the device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Walang SIM card</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_bt_dpinfo_as_web_connection">
      <source>as web connection</source>
      <translation variants="no">ay ginagamit bilang koneksyon sa web</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_in_1">
      <source>in %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_to_connect_1_2_needs_to_be_disconnec">
      <source>To connect %1 %2 needs to be disconnected first.</source>
      <translation variants="no">Hindi makakonekta sa %[42]1. Magdiskonekta muna sa %[41]2.</translation>
    </message>
    <message numerus="no" id="txt_bt_info_n_files_already_received">
      <source>N files already received</source>
      <translation variants="no">tl ##N files already received</translation>
    </message>
    <message numerus="no" id="txt_bt_dpopinfo_sent_to_1">
      <source>to %1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_bt_info_try_entering_the_sim_access_profile_ag">
      <source>Try entering the SIM access profile again?</source>
      <translation variants="no">Subukan muling aktibahin ang mode na remote SIM?</translation>
    </message>
  </context>
</TS>