<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dblist_wireless_lan_val_wlan_is_on">
      <source>Not connected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chưa được kết nối</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_wireless_lan_val_off">
      <source>WLAN is off</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tắt WLAN</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_wireless_lan_val_connected_to_1">
      <source>'%1' connected</source>
      <translation variants="no">vi #'%1' connected</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_wireless_lan">
      <source>Wireless LAN</source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN</lengthvariant>
      </translation>
    </message>
  </context>
</TS>