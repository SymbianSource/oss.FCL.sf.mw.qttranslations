<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_title_task_switcher">
      <source>Recent applications</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Recent applications</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_info_no_recent_applications">
      <source>No recent applications</source>
      <translation variants="no">zh ##No recent applications</translation>
    </message>
    <message numerus="no" id="txt_tsw_label_active">
      <source>Active</source>
      <translation variants="no">zh ##Active</translation>
    </message>
  </context>
</TS>