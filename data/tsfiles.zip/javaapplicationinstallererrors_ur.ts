<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_inst_info_uninst_blocked">
      <source>Uninstallation is blocked by an attribute in application.</source>
      <translation variants="no">ur #Uninstallation is blocked by an attribute in application.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_uninst_cancel">
      <source>Uninstallation cancelled.</source>
      <translation variants="no">ur #Uninstallation cancelled.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_mem_detail">
      <source>Application requires %1 kB of memory. You have to remove other applications or data from the device to install the application</source>
      <translation variants="no">ur #Application requires %1 kB of memory. You have to remove other applications or data from the device to install the application</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_net_detail">
      <source>Cannot download installation package from URL %1.</source>
      <translation variants="no">ur #Cannot download installation package from URL %1.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_cancel">
      <source>Installation cancelled.</source>
      <translation variants="no">ur #Installation cancelled.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_mismatch">
      <source>Attritbute %1 is different in JAD and JAR files.</source>
      <translation variants="no">ur #Attritbute %1 is different in JAD and JAR files.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_push_reg">
      <source>Push registration failed.</source>
      <translation variants="no">ur #Push registration failed.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_different_signers">
      <source>The signers of the update and the already installed applications do not match.</source>
      <translation variants="no">ur #The signers of the update and the already installed applications do not match.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_authentication">
      <source>Application authentication failed.</source>
      <translation variants="no">ur #Application authentication failed.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_pkg_misuse">
      <source>Package %1 is protected and can not be used.</source>
      <translation variants="no">ur #Package %1 is protected and can not be used.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_mem_detail_mb">
      <source>Application requires %1 MB of memory. You have to remove other applications or data from the device to install the application</source>
      <translation variants="no">ur #Application requires %1 MB of memory. You have to remove other applications or data from the device to install the application</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_authorization">
      <source>Application authorization failed.</source>
      <translation variants="no">ur #Application authorization failed.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_internal_error">
      <source>Internal error: %1</source>
      <translation variants="no">ur #Internal error: %1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_missing">
      <source>Mandatory attribute %1 is missing.</source>
      <translation variants="no">ur #Mandatory attribute %1 is missing.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_uninst_unexpected">
      <source>Unable to uninstall. Unexpected error.</source>
      <translation variants="no">ur #Unable to uninstall. Unexpected error.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_unsupported_value">
      <source>Attribute %1 has unsupported value.</source>
      <translation variants="no">ur #Attribute %1 has unsupported value.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_handling_failed">
      <source>Attribute %1 handling failed.</source>
      <translation variants="no">ur #Attribute %1 handling failed.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_bad_syntax">
      <source>Attribute %1 has bad syntax.</source>
      <translation variants="no">ur #Attribute %1 has bad syntax.</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_cert_unsupported">
      <source>Application has been signed with a certificate that is not supported in this device.</source>
      <translation variants="no">ur #Application has been signed with a certificate that is not supported in this device.</translation>
    </message>
  </context>
</TS>