<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_java_inst_info_uninst_blocked">
      <source>Uninstallation is blocked by an attribute in application.</source>
      <translation variants="no">سافٹ ویئر کا ہٹانا پروگرام کی ایک خاصیت کے ذریعے روک دیا گیا ہے۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_authorization">
      <source>Application authorization failed.</source>
      <translation variants="no">پروگرام کی منظوری ناکام۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_mismatch">
      <source>Attritbute %1 is different in JAD and JAR files.</source>
      <translation variants="no">خاصیت '%[98]1' JADاور JAR فائلوں میں مختلف ہے۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_uninst_unexpected">
      <source>Unable to uninstall. Unexpected error.</source>
      <translation variants="no">سافٹ ویئر کو ہٹانے سے قاصر۔ غیر متوقع غلطی۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_push_reg">
      <source>Push registration failed.</source>
      <translation variants="no">اندراج ناکام۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_net_detail">
      <source>Cannot download installation package from URL %1.</source>
      <translation variants="no">ویب پتے سے تنصیبی مجموعہ ڈاؤن لوڈ کرنے سے قاصر:
%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_pkg_misuse">
      <source>Package %1 is protected and can not be used.</source>
      <translation variants="no">مجموعہ '%[98]1' تحفظ شدہ ہے اور استعمال نہیں کیا جا سکتا۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_mem_detail_mb">
      <source>Application requires %L1 MB of memory. You have to remove other applications or data from the device to install the application</source>
      <translation variants="no">حافظہ کافی نہیں ہے۔ پروگرام کو %L1 م ب درکار ہے۔ کچھ دیگر پروگرام یا ڈیٹا ہٹائیں اور دوبارہ کوشش کریں۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_bad_syntax">
      <source>Attribute %1 has bad syntax.</source>
      <translation variants="no">غلط خاصیت '%[98]1'۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_cert_unsupported">
      <source>Application has been signed with a certificate that is not supported in this device.</source>
      <translation variants="no">پروگرام ایسی سند کے ساتھ سائن کیا گیا ہے جو اس آلے سے تائید شدہ نہیں ہے۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_unsupported_value">
      <source>Attribute %1 has unsupported value.</source>
      <translation variants="no">خاصیت '%[98]1' میں غلط قدر۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_different_signers">
      <source>The signers of the update and the already installed applications do not match.</source>
      <translation variants="no">حالیہ تنصیب شدہ پروگرام سے مختلف سند کے ساتھ تجدید کو سائن کیا گیا ہے۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_cancel">
      <source>Installation cancelled.</source>
      <translation variants="no">تنصیب منسوخ۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_authentication">
      <source>Application authentication failed.</source>
      <translation variants="no">پروگرام کی تصدیق کاری ناکام۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_handling_failed">
      <source>Attribute %1 handling failed.</source>
      <translation variants="no">خاصیت '%[98]1' پر عمل درآمد ناکام۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_uninst_cancel">
      <source>Uninstallation cancelled.</source>
      <translation variants="no">سافٹ ویئر ہٹانا منسوخ کیا گیا۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_internal_error">
      <source>Internal error: %1</source>
      <translation variants="no">داخلی غلطی:
%1</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_no_mem_detail">
      <source>Application requires %L1 kB of memory. You have to remove other applications or data from the device to install the application</source>
      <translation variants="no">حافظہ کافی نہیں ہے۔ پروگرام کو %L1 ک ب درکار ہے۔ کچھ دیگر پروگرام یا ڈیٹا ہٹائیں اور دوبارہ کوشش کریں۔</translation>
    </message>
    <message numerus="no" id="txt_java_inst_info_error_attr_missing">
      <source>Mandatory attribute %1 is missing.</source>
      <translation variants="no">لازمی خاصیت '%[98]1' مفقود۔</translation>
    </message>
  </context>
</TS>