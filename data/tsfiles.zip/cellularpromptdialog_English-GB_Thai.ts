<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="en_x_th">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_button_cellular_cancel">
      <source>Source 0</source>
      <translation variants="no">Cancel</translation>
    </message>
    <message numerus="no" id="txt_occ_button_connect_this_time">
      <source>Source 1</source>
      <translation variants="no">Connect this time</translation>
    </message>
    <message numerus="no" id="txt_occ_title_connect_to_internet_using_cellular_d">
      <source>Source 2</source>
      <translation variants="no">Connect to Internet using cellular data? Data costs may apply.</translation>
    </message>
    <message numerus="no" id="txt_occ_button_connect_automatically">
      <source>Source 3</source>
      <translation variants="no">Connect automatically</translation>
    </message>
    <message numerus="no" id="txt_occ_title_connect_to_internet_in_this_country">
      <source>Source 4</source>
      <translation variants="no">Connect to Internet using cellular data? Phone is outside of home network, and data costs may increase considerably. To allow connecting automatically, adjust the Connection settings.</translation>
    </message>
  </context>
</TS>