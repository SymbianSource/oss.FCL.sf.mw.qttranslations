<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_cam_list_night_portrait">
      <source>Night portrait</source>
      <translation variants="no">夜間肖像</translation>
    </message>
    <message numerus="no" id="txt_cam_list_portrait">
      <source>Portrait</source>
      <translation variants="no">肖像</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sports">
      <source>Sports</source>
      <translation variants="no">運動</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer">
      <source>Self timer</source>
      <translation variants="no">自動計時器</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos">
      <source>Go to Photos</source>
      <translation variants="no">相片</translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode">
      <source>Camera in stand-by mode</source>
      <translation variants="no">攝影機待機中</translation>
    </message>
    <message numerus="no" id="txt_cam_list_landscape">
      <source>Landscape</source>
      <translation variants="no">風景</translation>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">曝光補償</translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip">
      <source>Delete video clip?</source>
      <translation variants="no">是否刪除影片？</translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus">
      <source>+%L1</source>
      <translation variants="no">+%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">顯示已拍攝影片</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings">
      <source>Camera settings</source>
      <translation variants="no">相機設定</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene">
      <source>Automatic</source>
      <translation variants="no">自動</translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds">
      <source>%Ln seconds</source>
      <translation>
        <numerusform plurality="a">%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">攝影機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_start">
      <source>Start</source>
      <translation variants="no">開始</translation>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode">
      <source>Flash mode</source>
      <translation variants="no">閃光燈</translation>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation">
      <source>Exposure compensation</source>
      <translation variants="no">曝光補償</translation>
    </message>
    <message numerus="no" id="txt_cam_list_reduce_red_eye">
      <source>Reduce red eye</source>
      <translation variants="yes">
        <lengthvariant priority="1">消除紅眼</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone">
      <source>Color tone</source>
      <translation variants="no">色調</translation>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left">
      <source>%Ln images left</source>
      <translation>
        <numerusform plurality="a">剩餘%Ln張影像</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_camera">
      <source>Camera</source>
      <translation variants="no">攝影機</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound">
      <source>Video sound</source>
      <translation variants="no">影片聲音</translation>
    </message>
    <message numerus="no" id="txt_cam_list_incandescent">
      <source>Incandescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">白熾光</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_ln_mpix">
      <source>%L1 Mpix</source>
      <translation variants="no">%L1百萬像素</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sunny">
      <source>Sunny</source>
      <translation variants="yes">
        <lengthvariant priority="1">晴天</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_white">
      <source>Black and white</source>
      <translation variants="yes">
        <lengthvariant priority="1">黑白</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_camera">
      <source>Camera</source>
      <translation variants="no">相機</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_43">
      <source>VGA 4:3</source>
      <translation variants="no">VGA 4:3</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night">
      <source>Night</source>
      <translation variants="no">夜間</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name">
      <source>Default image name</source>
      <translation variants="no">預設影像名稱</translation>
    </message>
    <message numerus="no" id="txt_cam_list_night_video">
      <source>Night</source>
      <translation variants="no">夜間</translation>
    </message>
    <message numerus="no" id="txt_cam_button_contrast">
      <source>Contrast</source>
      <translation variants="no">對比</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings">
      <source>General settings</source>
      <translation variants="no">設定</translation>
    </message>
    <message numerus="no" id="txt_cam_button_cancel">
      <source>Cancel</source>
      <translation variants="no">取消</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality">
      <source>Image quality</source>
      <translation variants="no">影像品質</translation>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer">
      <source>Self timer</source>
      <translation variants="no">自動計時器</translation>
    </message>
    <message numerus="no" id="txt_cam_list_sepia">
      <source>Sepia</source>
      <translation variants="yes">
        <lengthvariant priority="1">褐色</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity">
      <source>Light sensitivity</source>
      <translation variants="no">感光度</translation>
    </message>
    <message numerus="no" id="txt_cam_list_closeup">
      <source>Close-up</source>
      <translation variants="no">近拍</translation>
    </message>
    <message numerus="no" id="txt_cam_list_low_light">
      <source>Low light</source>
      <translation variants="no">低光源</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_qcif_sharing">
      <source>QCIF Sharing</source>
      <translation variants="no">QCIF分享</translation>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking">
      <source>Face tracking</source>
      <translation variants="no">臉部偵測</translation>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality">
      <source>Image quality</source>
      <translation variants="no">影像品質</translation>
    </message>
    <message numerus="no" id="txt_cam_button_iso">
      <source>ISO</source>
      <translation variants="no">ISO</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos">
      <source>Go to 'Videos'</source>
      <translation variants="no">影片</translation>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone">
      <source>Color tone</source>
      <translation variants="no">色調</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name">
      <source>Default video name</source>
      <translation variants="no">預設影片名稱</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">拍攝聲</translation>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">使用者自訂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality">
      <source>Video quality</source>
      <translation variants="no">影片品質</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality">
      <source>Video quality</source>
      <translation variants="no">影片品質</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga">
      <source>VGA</source>
      <translation variants="no">VGA</translation>
    </message>
    <message numerus="no" id="txt_cam_list_cloudy">
      <source>Cloudy</source>
      <translation variants="yes">
        <lengthvariant priority="1">陰天</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_timer">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use">
      <source>Camera already in use</source>
      <translation variants="no">攝影機已由其他應用程式使用中</translation>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus">
      <source>-%L1</source>
      <translation variants="no">-%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_whitebal">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_error">
      <source>Unexpected error. Please re-start camera.
If re-start doesn't help, please reboot the device</source>
      <translation variants="no">發生未預期的錯誤。請重新啟動裝置。</translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">連續</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode">
      <source>Scene mode</source>
      <translation variants="no">場景模式</translation>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance">
      <source>White balance</source>
      <translation variants="no">白平衡</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_val_ln_recording_time_left">
      <source>Recording time left: %L1</source>
      <translation variants="no">剩餘錄影時間：%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">顯示已拍攝影像</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_169_widescreen">
      <source>HD 720p 16:9 widescreen</source>
      <translation variants="no">HD 720p 16:9寬螢幕</translation>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image">
      <source>Delete image?</source>
      <translation variants="no">是否刪除影像？</translation>
    </message>
    <message numerus="no" id="txt_cam_list_normal">
      <source>Normal</source>
      <translation variants="yes">
        <lengthvariant priority="1">標準</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_flash">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_ln_mpix_widescreen">
      <source>%L1 Mpix widescreen</source>
      <translation variants="no">%L1百萬像素寬螢幕</translation>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance">
      <source>White balance</source>
      <translation variants="no">白平衡</translation>
    </message>
    <message numerus="no" id="txt_cam_list_vivid">
      <source>Vivid</source>
      <translation variants="yes">
        <lengthvariant priority="1">鮮豔</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_lightsens">
      <source>Automatic</source>
      <translation variants="yes">
        <lengthvariant priority="1">自動</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image">
      <source>Show captured image</source>
      <translation variants="no">顯示已拍攝影像</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video">
      <source>Show captured video</source>
      <translation variants="no">顯示已拍攝影片</translation>
    </message>
    <message numerus="no" id="txt_cam_list_fluorescent">
      <source>Fluorescent</source>
      <translation variants="yes">
        <lengthvariant priority="1">螢光</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video">
      <source>%Ln sec</source>
      <translation>
        <numerusform plurality="a">%Ln秒</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_contrast">
      <source>Contrast</source>
      <translation variants="no">對比</translation>
    </message>
    <message numerus="no" id="txt_cam_list_not_video">
      <source>Never</source>
      <translation variants="yes">
        <lengthvariant priority="1">永不</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video">
      <source>Continuous</source>
      <translation variants="yes">
        <lengthvariant priority="1">連續</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_sharpness">
      <source>Sharpness</source>
      <translation variants="no">清晰度</translation>
    </message>
    <message numerus="no" id="txt_cam_list_never">
      <source>Never</source>
      <translation variants="yes">
        <lengthvariant priority="1">永不</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_geotagging_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode_video">
      <source>Scene mode</source>
      <translation variants="no">場景模式</translation>
    </message>
    <message numerus="no" id="txt_cam_list_flash_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_camera">
      <source>Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">攝影機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_grid_sharpness">
      <source>Sharpness</source>
      <translation variants="no">清晰度</translation>
    </message>
    <message numerus="no" id="txt_cam_list_flash_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_iso_l1">
      <source>ISO %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">ISO %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene_video">
      <source>Automatic</source>
      <translation variants="no">自動</translation>
    </message>
    <message numerus="no" id="txt_cam_fullscreen_imagesleft">
      <source>%L1</source>
      <translation variants="no">zh_tw #%L1</translation>
    </message>
    <message numerus="no" id="txt_cam_title_geotagging">
      <source>Geotagging</source>
      <translation variants="no">位置標籤</translation>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_169_widescreen">
      <source>VGA 16:9 widescreen</source>
      <translation variants="no">VGA 16:9寬螢幕</translation>
    </message>
    <message numerus="no" id="txt_cam_list_geotagging_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">日期</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_video">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_opt_video_stabilization">
      <source>Video stabilization</source>
      <translation variants="no">防手震</translation>
    </message>
    <message numerus="no" id="txt_cam_list_facetracking_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_stabilization">
      <source>Video stabilization</source>
      <translation variants="no">防手震</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_geotagging">
      <source>Geotagging</source>
      <translation variants="no">位置標籤</translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_video">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_capture_tone">
      <source>Capture tone</source>
      <translation variants="no">拍攝聲</translation>
    </message>
    <message numerus="no" id="txt_cam_other_please_type_here">
      <source>Please type here</source>
      <translation variants="yes">
        <lengthvariant priority="1">輸入文字</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_error_usb_disconnected">
      <source>Memory not accessible and Camera cannot be used. Unplug USB cable to use camera</source>
      <translation variants="no">攝影機無法使用。請拔除USB傳輸線並再試一次。</translation>
    </message>
    <message numerus="no" id="txt_cam_info_error_ram_full">
      <source>Out of memory. Please close appliactions to use camera.</source>
      <translation variants="no">記憶體不足。請關閉部分應用程式並再試一次。</translation>
    </message>
    <message numerus="no" id="txt_cam_info_memory_full">
      <source>Memory full.  Please delete some data or lower the  quality of image or video and try again.</source>
      <translation variants="no">記憶體已滿。請刪除一些資料或降低影像品質並再試一次。</translation>
    </message>
    <message numerus="no" id="txt_cam_title_default_image_name">
      <source>Default image name</source>
      <translation variants="no">預設影像名稱</translation>
    </message>
    <message numerus="no" id="txt_cam_info_captured_photos_and_videos_will_be_ta">
      <source>Captured photos and videos will be tagged with your location. If photos or videos are shared, the location data may also be visible to third parties. Phone will use network to get the location data. Data transfer charges may apply. Location recording can be disabled in settings.</source>
      <translation variants="no">若找到GPS座標，便會將位置資訊記錄至每張影像或每個影片。位於遠離高樓的開放區域時最適合GPS運作，且找到您的位置可能需要幾分鐘的時間。如果您接著分享相片或影片，其他人可能也會看見此位置資訊。位置標籤功能可以在相機設定中關閉。</translation>
    </message>
    <message numerus="no" id="txt_cam_opt_color_tone">
      <source>Color tone</source>
      <translation variants="no">色調</translation>
    </message>
    <message numerus="no" id="txt_cam_list_facetracking_on">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_other_default_image_name">
      <source>Default image name</source>
      <translation variants="no">預設影像名稱</translation>
    </message>
    <message numerus="no" id="txt_cam_info_geotagging_ftu_note_settings_button">
      <source>Setting</source>
      <translation variants="yes">
        <lengthvariant priority="1">設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_error_usb_disconnected_button">
      <source>Close camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">關閉攝影機</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_title_facetracking">
      <source>Face tracking</source>
      <translation variants="no">臉部偵測</translation>
    </message>
    <message numerus="no" id="txt_cam_title_video_sound">
      <source>Video sound</source>
      <translation variants="no">影片聲音</translation>
    </message>
    <message numerus="no" id="txt_cam_list_on_stabil">
      <source>On</source>
      <translation variants="yes">
        <lengthvariant priority="1">開</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_off_stabil">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_list_video_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">使用者自訂</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_scene_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">取消</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_button_scene_ok">
      <source>Ok</source>
      <translation variants="yes">
        <lengthvariant priority="1">確定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_cam_info_recording_time">
      <source>%1/%2</source>
      <translation variants="no">%[98]1/%2</translation>
    </message>
  </context>
</TS>