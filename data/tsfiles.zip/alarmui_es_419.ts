<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en_us" language="es_419">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_button_alarm_dialog_snooze">
      <source>Source 0</source>
      <translation variants="yes">
        <lengthvariant priority="1">es_419 #Stop</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_slide_down_to_stop">
      <source>Source 1</source>
      <translation variants="no">es_419 #Slide down to stop</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_switch_phone_on">
      <source>Source 2</source>
      <translation variants="no">es_419 #Switch phone on ?</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_time">
      <source>Source 3</source>
      <translation variants="no">es_419 #%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_snooze">
      <source>Source 4</source>
      <translation variants="no">es_419 #Snooze</translation>
    </message>
    <message numerus="no" id="txt_calendar_button_silence">
      <source>Source 5</source>
      <translation variants="no">es_419 #Silence</translation>
    </message>
    <message numerus="yes" id="txt_calendar_dpopinfo_alarm_snooxed_for_ln_minute">
      <source>Source 6</source>
      <translation>
        <numerusform plurality="a">es_419 #MISSING</numerusform>
        <numerusform plurality="b">es_419 #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_silence">
      <source>Source 7</source>
      <translation variants="yes">
        <lengthvariant priority="1">es_419 #Silence</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_button_alarm_snooze">
      <source>Source 8</source>
      <translation variants="yes">
        <lengthvariant priority="1">es_419 #Snooze</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_date">
      <source>Source 9</source>
      <translation variants="no">es_419 #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_list_alarm_dialog_time">
      <source>Source 10</source>
      <translation variants="no">es_419 #%2</translation>
    </message>
    <message numerus="no" id="txt_calendar_info_alarm_start_date">
      <source>Source 11</source>
      <translation variants="no">es_419 #%1</translation>
    </message>
    <message numerus="no" id="txt_calendar_title_todo_note_alarm">
      <source>Source 12</source>
      <translation variants="yes">
        <lengthvariant priority="1">es_419 #To-do note</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar_alarm">
      <source>Source 13</source>
      <translation variants="yes">
        <lengthvariant priority="1">es_419 #Calendar alarm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_calendar_title_clock_alarm">
      <source>Source 14</source>
      <translation variants="yes">
        <lengthvariant priority="1">es_419 #Clock alarm</lengthvariant>
      </translation>
    </message>
  </context>
</TS>