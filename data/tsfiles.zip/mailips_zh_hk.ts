<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_save_energy">
      <source>Save energy</source>
      <translation variants="no">節能</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_wed">
      <source>Wed</source>
      <translation variants="yes">
        <lengthvariant priority="1">星期三</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_show_mail_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="no">在收件匣中顯示電郵</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode">
      <source>Selected mode</source>
      <translation variants="no">使用中的重新整理選項</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_username">
      <source>Username</source>
      <translation variants="no">用戶名稱：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_day_start_time">
      <source>Day start time</source>
      <translation variants="no">白天開始時間：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_tue">
      <source>Tue</source>
      <translation variants="yes">
        <lengthvariant priority="1">星期二</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_only_by">
      <source>The mailbox is refreshed only by user request</source>
      <translation variants="no">郵箱內容只會在用戶自行啟動時重新整理</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_sun">
      <source>Sun</source>
      <translation variants="yes">
        <lengthvariant priority="1">星期日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_mail_server">
      <source>Outgoing mail server</source>
      <translation variants="no">外發電郵伺服器</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_reply_to_address">
      <source>Reply to address</source>
      <translation variants="no">回覆地址：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port">
      <source>Incoming port</source>
      <translation variants="no">接收端口</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_receiving_schedule">
      <source>Receiving Schedule</source>
      <translation variants="yes">
        <lengthvariant priority="1">擷取排程</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_user_info">
      <source>User info</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶資料</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_receiving_weekdays">
      <source>Receiving days</source>
      <translation variants="no">擷取日</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_user_define">
      <source>User defined</source>
      <translation variants="no">用戶自定義</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_on_ssltls">
      <source>On (SLL/TLS)</source>
      <translation variants="yes">
        <lengthvariant priority="1">開(SSL/TLS)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_thu">
      <source>Thu</source>
      <translation variants="yes">
        <lengthvariant priority="1">星期四</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_mail_server">
      <source>Incoming mail server</source>
      <translation variants="no">接收電郵伺服器</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_keep_uptodate">
      <source>Keep up-to-date</source>
      <translation variants="yes">
        <lengthvariant priority="1">保持最新狀態</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_fri">
      <source>Fri</source>
      <translation variants="yes">
        <lengthvariant priority="1">星期五</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_fetch_manua">
      <source>Fetch manually</source>
      <translation variants="no">手動擷取電郵</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_day_end_time">
      <source>Day end time</source>
      <translation variants="no">白天結束時間：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_mail_address">
      <source>Mail address</source>
      <translation variants="no">電郵地址：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_connection">
      <source>Connection</source>
      <translation variants="no">連接</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_uptodate_during">
      <source>The mailbox is up-to-date during daytime</source>
      <translation variants="no">郵箱內容在白天會保持最新狀態</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_preferences">
      <source>Preferences</source>
      <translation variants="yes">
        <lengthvariant priority="1">喜好設定</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="no">重新整理郵箱</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_version_l1">
      <source>Version: %[]1</source>
      <translation variants="no">版本：%1</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_every_15">
      <source>The mailbox is refreshed every hour during daytime</source>
      <translation variants="no">郵箱內容在白天會每小時重新整理一次</translation>
    </message>
    <message numerus="no" id="txt_mailips_button_delete_mailbox">
      <source>Delete mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">刪除郵箱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_the_mailbox_is_refreshed_as_defin">
      <source>The mailbox is refreshed as defined by the user</source>
      <translation variants="no">郵箱內容會依照用戶的定義重新整理</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_all">
      <source>All</source>
      <translation variants="yes">
        <lengthvariant priority="1">全部</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_every_day">
      <source>Every day</source>
      <translation variants="yes">
        <lengthvariant priority="1">每天</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_sat">
      <source>Sat</source>
      <translation variants="yes">
        <lengthvariant priority="1">星期六</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_when_i_open_mailbox">
      <source>When I open mailbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">當我開啟郵箱時</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_mailbox_name">
      <source>Mailbox name</source>
      <translation variants="no">郵箱名稱</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_password">
      <source>Password</source>
      <translation variants="no">密碼：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_selected_mode_val_keep_upto">
      <source>Keep up-to-date</source>
      <translation variants="no">保持最新狀態</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_start_time">
      <source>Day start time</source>
      <translation variants="yes">
        <lengthvariant priority="1">白天開始時間：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_none">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">無</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_all">
      <source>All</source>
      <translation variants="yes">
        <lengthvariant priority="1">全部</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_folder_path_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶自定義</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_saturday">
      <source>Sat</source>
      <translation variants="yes">
        <lengthvariant priority="1">六</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_folder_path">
      <source>Folder path</source>
      <translation variants="yes">
        <lengthvariant priority="1">資料夾路徑</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_receiving_days">
      <source>Receiving days</source>
      <translation variants="yes">
        <lengthvariant priority="1">擷取日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_none">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">無</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶自定義</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_same_as_for_incoming">
      <source>Same as for incoming</source>
      <translation variants="yes">
        <lengthvariant priority="1">與接收電郵相同</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_security">
      <source>Outgoing secure connection</source>
      <translation variants="no">外發電郵安全連接</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_sunday">
      <source>Sun</source>
      <translation variants="yes">
        <lengthvariant priority="1">日</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_refresh_mail">
      <source>Refresh mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">重新整理郵箱</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_keep_up_to_date">
      <source>Keep up-to-date</source>
      <translation variants="yes">
        <lengthvariant priority="1">保持最新狀態</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_connection">
      <source>Connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_user">
      <source>User authentication</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶認證</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_wednesday">
      <source>Wed</source>
      <translation variants="yes">
        <lengthvariant priority="1">三</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_monday">
      <source>Mon</source>
      <translation variants="yes">
        <lengthvariant priority="1">一</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">每15分鐘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_user_authentication">
      <source>User authentication</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶認證</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_no_authentication">
      <source>No authentication</source>
      <translation variants="yes">
        <lengthvariant priority="1">無</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_mailips">
      <source>Mail</source>
      <translation variants="no">電郵</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_folder_path_val_default">
      <source>Default</source>
      <translation variants="yes">
        <lengthvariant priority="1">預設</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_outgoing_authentication">
      <source>Outgoing mail authentication</source>
      <translation variants="yes">
        <lengthvariant priority="1">外發電郵認證</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_show_in_folders">
      <source>Show mail in other folders</source>
      <translation variants="yes">
        <lengthvariant priority="1">在其他資料夾中顯示電郵</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_incoming_connection">
      <source>Incoming secure connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">接收電郵安全連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dpopinfo_saving_settings">
      <source>Saving settings</source>
      <translation variants="no">zh_hk #Saving settings</translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_on_ssltls">
      <source>On (SSL/TLS)</source>
      <translation variants="yes">
        <lengthvariant priority="1">開(SSL/TLS)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_every_hour">
      <source>Every hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">每小時</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_on_starttls">
      <source>On (StartTLS)</source>
      <translation variants="yes">
        <lengthvariant priority="1">開(StartTLS)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path_user_defined">
      <source>User defined</source>
      <translation variants="yes">
        <lengthvariant priority="1">用戶自定義</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_show_in_inbox">
      <source>Show mail in inbox</source>
      <translation variants="yes">
        <lengthvariant priority="1">在收件匣中顯示電郵</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_authentication_same">
      <source>Same as for incoming</source>
      <translation variants="yes">
        <lengthvariant priority="1">與接收電郵相同</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_port">
      <source>Outgoing port</source>
      <translation variants="no">外發端口</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path">
      <source>Folder path</source>
      <translation variants="no">資料夾路徑</translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_outgoing_connection">
      <source>Outgoing secure connection</source>
      <translation variants="yes">
        <lengthvariant priority="1">外發電郵安全連接</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_port_default">
      <source>Default</source>
      <translation variants="yes">
        <lengthvariant priority="1">預設</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_folder_path_val_default">
      <source>Default</source>
      <translation variants="yes">
        <lengthvariant priority="1">預設</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_thursday">
      <source>Thu</source>
      <translation variants="yes">
        <lengthvariant priority="1">四</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_friday">
      <source>Fri</source>
      <translation variants="yes">
        <lengthvariant priority="1">五</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_my_name">
      <source>My name</source>
      <translation variants="no">我的名稱：</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_security_val_on_starttls">
      <source>On (StartTLS)</source>
      <translation variants="yes">
        <lengthvariant priority="1">開(StartTLS)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_download_images_val_mon">
      <source>Mon</source>
      <translation variants="yes">
        <lengthvariant priority="1">星期一</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="yes">
        <lengthvariant priority="1">每4小時</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_outgoing_mail_authentication">
      <source>Outgoing mail authentication</source>
      <translation variants="no">外發電郵認證</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_1_hour">
      <source>Every hour</source>
      <translation variants="yes">
        <lengthvariant priority="1">每小時</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_val_every_15_minutes">
      <source>Every 15 minutes</source>
      <translation variants="yes">
        <lengthvariant priority="1">每15分鐘</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_incoming_security">
      <source>Incoming secure connection</source>
      <translation variants="no">接收電郵安全連接</translation>
    </message>
    <message numerus="no" id="txt_mailips_setlabel_show_mail_in_other_folders">
      <source>Show mail in other folders</source>
      <translation variants="no">在其他資料夾中顯示電郵</translation>
    </message>
    <message numerus="no" id="txt_mailips_subhead_server_info">
      <source>Server info</source>
      <translation variants="yes">
        <lengthvariant priority="1">伺服器資料</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_off">
      <source>Off</source>
      <translation variants="yes">
        <lengthvariant priority="1">關</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_tuesday">
      <source>Tue</source>
      <translation variants="yes">
        <lengthvariant priority="1">二</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_dialog_heading_end_time">
      <source>Day end time</source>
      <translation variants="yes">
        <lengthvariant priority="1">白天結束時間：</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mailips_list_popup_sec_every_4_hours">
      <source>Every 4 hours</source>
      <translation variants="yes">
        <lengthvariant priority="1">每4小時</lengthvariant>
      </translation>
    </message>
  </context>
</TS>