<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_photos_formlabel_location_tag">
      <source>Location tag</source>
      <translation variants="no">مقام کا ٹیگ</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_fast">
      <source>Fast</source>
      <translation variants="no">تیز</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_comments">
      <source>Not specified</source>
      <translation variants="no">تبصرے</translation>
    </message>
    <message numerus="no" id="txt_photos_title_photos">
      <source>Photos</source>
      <translation variants="yes">
        <lengthvariant priority="1">تصاویر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_places_ln">
      <source>Places (%ln)</source>
      <translation variants="no">ur #Locations (%L1)</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_slideshow">
      <source>Slideshow</source>
      <translation variants="no">سلائڈ شو</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_slow">
      <source>Slow</source>
      <translation variants="no">سست</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay">
      <source>Transistion delay</source>
      <translation variants="no">رفتار</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_smooth">
      <source>Smooth Fade</source>
      <translation variants="no">بتدریج مٹنا</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_add_to_album">
      <source>Add to album</source>
      <translation variants="no">البم میں شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_mark_all">
      <source>Mark all</source>
      <translation variants="no">سب کو نشان زد کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_share">
      <source>Share</source>
      <translation variants="no">شرکت کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_view_releated_items">
      <source>View releated items</source>
      <translation variants="no">منظر متعلق شبیہات</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_play">
      <source>Play</source>
      <translation variants="no">چلائیں</translation>
    </message>
    <message numerus="yes" id="txt_photos_subtitle_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">%Ln شبیہ</numerusform>
        <numerusform plurality="b">%Ln شبیہات</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھینچی گئی شبیہات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_shared_with">
      <source>Shared with</source>
      <translation variants="no">مشترک</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">سب کو نشان رد کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_share">
      <source>Share</source>
      <translation variants="no">شرکت کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_slideshow">
      <source>Slideshow</source>
      <translation variants="no">سلائڈ شو</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_places_l1">
      <source>Not specified</source>
      <translation variants="no">مقامات (%L1)</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_val_ln_items">
      <source>%Ln items</source>
      <translation variants="no">%Ln شبیہ</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect">
      <source>Transistion effect</source>
      <translation variants="no">عبوری اثر</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_settings">
      <source>Settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">پسندیدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_medium">
      <source>Medium</source>
      <translation variants="no">متوسط</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_remove_from_album">
      <source>Remove from album</source>
      <translation variants="no">البم سے ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_short_caption_photos">
      <source>photos</source>
      <translation variants="no">ur #Photos</translation>
    </message>
    <message numerus="no" id="txt_long_caption_photos">
      <source>photos</source>
      <translation variants="no">تصاویر</translation>
    </message>
    <message numerus="no" id="txt_photos_info_delete_l1_the_files_will_not_be">
      <source>Delete %1? (The files will not be deleted.)</source>
      <translation variants="no">%[06]1 مٹائیں؟ آئیٹم مٹائے نہیں جائیں گے۔</translation>
    </message>
    <message numerus="no" id="txt_photos_info_remove_l1_from_album_the_file_w">
      <source>Remove %1 from album? (The file will not be deleted.)</source>
      <translation variants="no">%[22]1 کو البم سے مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_use_image">
      <source>Use image</source>
      <translation variants="no">شبیہ استعمال کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album">
      <source>Album</source>
      <translation variants="no">البم</translation>
    </message>
    <message numerus="no" id="txt_photos_info_deleting_1">
      <source>Deleting %1?</source>
      <translation variants="no">%[27]1 آئیٹم مٹا رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_description">
      <source>Description</source>
      <translation variants="yes">
        <lengthvariant priority="1">وضاحت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_drm_license_info">
      <source>DRM License Info</source>
      <translation variants="no">ur #License details</translation>
    </message>
    <message numerus="no" id="txt_photos_info_no_images_to_play_slideshow">
      <source>No images to play slideshow</source>
      <translation variants="no">ur #No images to play slideshow</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album_ln">
      <source>Album (%Ln)</source>
      <translation variants="no">ur #Album (%Ln)</translation>
    </message>
    <message numerus="no" id="txt_photos_info_unable_to_open_image">
      <source>Unable to open image</source>
      <translation variants="no">ur #Unable to open image</translation>
    </message>
    <message numerus="no" id="txt_photos_grid_no_images">
      <source>No images</source>
      <translation variants="no">ur #No images</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_val_view_details">
      <source>View Details</source>
      <translation variants="no">ur #View Details</translation>
    </message>
    <message numerus="no" id="txt_photos_list_size_1">
      <source>Size: %Ln </source>
      <translation variants="no">ur #Size: %Ln </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_kb">
      <source>Size: %Ln kB</source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_grid">
      <source>Grid</source>
      <translation variants="no">ur #Grid</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album_l1">
      <source>Album (%L1)</source>
      <translation variants="no">ur #Album (%L1)</translation>
    </message>
    <message numerus="yes" id="txt_photos_dblist_my_camera_val_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_list_date_1">
      <source>Date: %1</source>
      <translation variants="no">ur #Date: %1</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_no_image_or_videos_to_display">
      <source>Not specified</source>
      <translation variants="no">(شبیہات یا ویڈیو کلپس نہیں)</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view">
      <source>View</source>
      <translation variants="no">ur #View</translation>
    </message>
    <message numerus="no" id="txt_photos_title_enter_name">
      <source>Enter name :</source>
      <translation variants="yes">
        <lengthvariant priority="1">البم کا نام داخل کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_menu_add_to_album">
      <source>Add to album</source>
      <translation variants="no">البم میں شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھینچی گئی شبیہات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_list_time_1">
      <source>Time: %1</source>
      <translation variants="no">ur #Time: %1</translation>
    </message>
    <message numerus="yes" id="txt_photos_info_delete_ln_items">
      <source>Delete %Ln items?</source>
      <translation>
        <numerusform plurality="a">%Ln آئیٹم مٹائیں؟</numerusform>
        <numerusform plurality="b">%Ln آئیٹمز مٹائیں؟</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_media_wall">
      <source>Media wall</source>
      <translation variants="no">ur #Media wall</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">پسندیدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_photos">
      <source>Photos</source>
      <translation variants="no">ur #Photos</translation>
    </message>
    <message numerus="yes" id="txt_photos_info_remove_ln_items_from_album_the">
      <source>Remove %Ln items from album? (The files will not be deleted.)</source>
      <translation>
        <numerusform plurality="a">البم سے %Ln آئیٹم ہٹائیں؟ آئیٹم فون سے نہیں مٹائے جائیں گے۔</numerusform>
        <numerusform plurality="b">البم سے %Ln آئیٹمز ہٹائیں؟ آئیٹمز فون سے نہیں مٹائے جائیں گے۔</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_gb">
      <source>Size: %Ln Gb </source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_mb">
      <source>Size: %Ln Mb</source>
      <translation>
        <numerusform plurality="a">ur #MISSING</numerusform>
        <numerusform plurality="b">ur #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_rotate">
      <source>Rotate</source>
      <translation variants="no">ur #Rotate</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_wave">
      <source>Wave</source>
      <translation variants="no">لہریں</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_new_album">
      <source>New album</source>
      <translation variants="no">نئی البم</translation>
    </message>
  </context>
</TS>