<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_fast">
      <source>Fast</source>
      <translation variants="no">تیز</translation>
    </message>
    <message numerus="no" id="txt_photos_title_photos">
      <source>Photos</source>
      <translation variants="yes">
        <lengthvariant priority="1">تصاویر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_slideshow">
      <source>Slideshow</source>
      <translation variants="no">سلائڈ شو</translation>
    </message>
    <message numerus="yes" id="txt_photos_subtitle_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">%Ln شبیہ</numerusform>
        <numerusform plurality="b">%Ln شبیہات</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_unmark_all">
      <source>Unmark all</source>
      <translation variants="no">سب کو نشان رد کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_share">
      <source>Share</source>
      <translation variants="no">شرکت کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">پسندیدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_play">
      <source>Play</source>
      <translation variants="no">چلائیں</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_share">
      <source>Share</source>
      <translation variants="no">شرکت کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect">
      <source>Transistion effect</source>
      <translation variants="no">عبوری اثر</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_sub_settings">
      <source>Settings</source>
      <translation variants="no">ترتیبات</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_favorites">
      <source>My favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">پسندیدہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_medium">
      <source>Medium</source>
      <translation variants="no">متوسط</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_remove_from_album">
      <source>Remove from album</source>
      <translation variants="no">البم سے ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay">
      <source>Transistion delay</source>
      <translation variants="no">رفتار</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_smooth">
      <source>Smooth Fade</source>
      <translation variants="no">بتدریج مٹنا</translation>
    </message>
    <message numerus="no" id="txt_long_caption_photos">
      <source>photos</source>
      <translation variants="no">تصاویر</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_add_to_album">
      <source>Add to album</source>
      <translation variants="no">البم میں شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_slideshow">
      <source>Slideshow</source>
      <translation variants="no">سلائڈ شو</translation>
    </message>
    <message numerus="no" id="txt_photos_info_delete_l1_the_files_will_not_be">
      <source>Delete %1? (The files will not be deleted.)</source>
      <translation variants="no">%[05]1 مٹائیں؟ ذخیرہ آ. مٹائے نہیں جائیںگے۔</translation>
    </message>
    <message numerus="no" id="txt_photos_info_remove_l1_from_album_the_file_w">
      <source>Remove %1 from album? (The file will not be deleted.)</source>
      <translation variants="no">%[22]1 کو البم سے ہٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_photos_info_unable_to_open_image">
      <source>Unable to open image</source>
      <translation variants="no">شبیہ کھولنے سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_photos_grid_no_images">
      <source>No images</source>
      <translation variants="no">ur #(no images)</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_photos">
      <source>Photos</source>
      <translation variants="no">ur #Photos</translation>
    </message>
    <message numerus="yes" id="txt_photos_info_remove_ln_items_from_album_the">
      <source>Remove %Ln items from album? (The files will not be deleted.)</source>
      <translation>
        <numerusform plurality="a">البم سے %Ln آئیٹم ہٹائیں؟ آئیٹم فون سے نہیں مٹائے جائیں گے۔</numerusform>
        <numerusform plurality="b">البم سے %Ln آئیٹمز ہٹائیں؟ آئیٹمز فون سے نہیں مٹائے جائیں گے۔</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_info_deleting_1">
      <source>Deleting %1?</source>
      <translation variants="no">%1 مٹا رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_photos_formlabel_description">
      <source>Description</source>
      <translation variants="yes">
        <lengthvariant priority="1">وضاحت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_use_image">
      <source>Use image</source>
      <translation variants="no">شبیہ استعمال کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album">
      <source>Album</source>
      <translation variants="no">البم</translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_gb">
      <source>Size: %Ln Gb </source>
      <translation>
        <numerusform plurality="a">سائز: %Ln گ بائٹس</numerusform>
        <numerusform plurality="b">سائز: %Ln گ بائٹ</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_mb">
      <source>Size: %Ln Mb</source>
      <translation>
        <numerusform plurality="a">سائز: %Ln م بائٹس</numerusform>
        <numerusform plurality="b">سائز: %Ln م بائٹ</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_grid">
      <source>Grid</source>
      <translation variants="no">گرڈ</translation>
    </message>
    <message numerus="no" id="txt_photos_dialog_enter_name_entry_album_l1">
      <source>Album (%L1)</source>
      <translation variants="no">البم (%L1)</translation>
    </message>
    <message numerus="no" id="txt_photos_list_date_1">
      <source>Date: %1</source>
      <translation variants="no">تاریخ: %1</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_rotate">
      <source>Rotate</source>
      <translation variants="no">گھمائیں</translation>
    </message>
    <message numerus="no" id="txt_photos_title_enter_name">
      <source>Enter name :</source>
      <translation variants="yes">
        <lengthvariant priority="1">البم کا نام داخل کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view">
      <source>View</source>
      <translation variants="no">منظر</translation>
    </message>
    <message numerus="no" id="txt_photos_list_time_1">
      <source>Time: %1</source>
      <translation variants="no">وقت: %1</translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_effect_val_wave">
      <source>Wave</source>
      <translation variants="no">لہریں</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_new_album">
      <source>New album</source>
      <translation variants="no">نئی البم</translation>
    </message>
    <message numerus="no" id="txt_photos_dblist_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھینچی گئی شبیہات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_setlabel_transistion_delay_val_slow">
      <source>Slow</source>
      <translation variants="no">سست</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_mark_all">
      <source>Mark all</source>
      <translation variants="no">سب کو نشان زد کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_subtitle_my_camera">
      <source>My Camera</source>
      <translation variants="yes">
        <lengthvariant priority="1">کھینچی گئی شبیہات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_photos_info_no_images_to_play_slideshow">
      <source>No images to play slideshow</source>
      <translation variants="no">سلائڈ شو چلانے سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_photos_menu_add_to_album">
      <source>Add to album</source>
      <translation variants="no">البم میں شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_photos_opt_view_sub_media_wall">
      <source>Media wall</source>
      <translation variants="no">میڈیا وال</translation>
    </message>
    <message numerus="yes" id="txt_photos_list_ln_kb">
      <source>Size: %Ln kB</source>
      <translation>
        <numerusform plurality="a">سائز: %Ln ک بائٹس</numerusform>
        <numerusform plurality="b">سائز: %Ln ک بائٹ</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_dblist_my_camera_val_ln_items">
      <source>%Ln items</source>
      <translation>
        <numerusform plurality="a">%Ln آئیٹمز</numerusform>
        <numerusform plurality="b">%Ln آئیٹم</numerusform>
      </translation>
    </message>
    <message numerus="yes" id="txt_photos_info_delete_ln_items">
      <source>Delete %Ln items?</source>
      <translation>
        <numerusform plurality="a">%Ln آئیٹم مٹائیں؟</numerusform>
        <numerusform plurality="b">%Ln آئیٹمز مٹائیں؟</numerusform>
      </translation>
    </message>
  </context>
</TS>