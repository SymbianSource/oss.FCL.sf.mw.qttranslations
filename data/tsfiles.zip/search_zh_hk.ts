<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_tsw_caption_search">
      <source>Search</source>
      <translation variants="no">zh_hk #Search</translation>
    </message>
    <message numerus="no" id="txt_search_list_media">
      <source>Media</source>
      <translation variants="no">zh_hk #Media</translation>
    </message>
    <message numerus="no" id="txt_short_caption_search">
      <source>Search</source>
      <translation variants="no">zh_hk #Search</translation>
    </message>
    <message numerus="no" id="txt_search_info_select_search_scope">
      <source>Select search scope:</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Select search scope:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_select_all">
      <source>Select all</source>
      <translation variants="no">zh_hk #Select all</translation>
    </message>
    <message numerus="no" id="txt_search_list_calendarnotes">
      <source>Calendar &amp; Notes</source>
      <translation variants="no">zh_hk #Calendar &amp; Notes</translation>
    </message>
    <message numerus="no" id="txt_search_title_search">
      <source>Search</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #Search</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_search_list_all_other_files">
      <source>All other files</source>
      <translation variants="no">zh_hk #All other files</translation>
    </message>
    <message numerus="no" id="txt_search_list_contatcs">
      <source>Contacts</source>
      <translation variants="no">zh_hk #Contacts</translation>
    </message>
    <message numerus="no" id="txt_long_caption_search">
      <source>Search</source>
      <translation variants="no">zh_hk #Search</translation>
    </message>
    <message numerus="no" id="txt_search_list_bookmarks">
      <source>Bookmarks</source>
      <translation variants="no">zh_hk #Bookmarks</translation>
    </message>
    <message numerus="no" id="txt_search_list_device">
      <source>Device</source>
      <translation variants="no">zh_hk #Device</translation>
    </message>
    <message numerus="no" id="txt_search_title_search_scope">
      <source>Search scope</source>
      <translation variants="no">zh_hk #Search scope</translation>
    </message>
    <message numerus="no" id="txt_search_dialog_search_internet">
      <source>Search internet</source>
      <translation variants="no">zh_hk #Search internet</translation>
    </message>
    <message numerus="no" id="txt_search_dialog_search_device">
      <source>Search device</source>
      <translation variants="no">zh_hk #Search device</translation>
    </message>
    <message numerus="no" id="txt_search_list_internet">
      <source>Internet</source>
      <translation variants="no">zh_hk #Internet</translation>
    </message>
    <message numerus="no" id="txt_search_list_search_for_1">
      <source>Search for "%1" </source>
      <translation variants="no">zh_hk #Search for "%1" </translation>
    </message>
    <message numerus="no" id="txt_search_list_messagemail">
      <source>Message &amp; Mail</source>
      <translation variants="no">zh_hk #Message &amp; Mail</translation>
    </message>
    <message numerus="no" id="txt_search_list_applications">
      <source>Applications</source>
      <translation variants="no">zh_hk #Applications</translation>
    </message>
    <message numerus="no" id="txt_search_list_no_match_found">
      <source>No Match Found</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_hk #No Match Found</lengthvariant>
      </translation>
    </message>
  </context>
</TS>