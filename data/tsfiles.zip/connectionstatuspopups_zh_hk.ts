<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dpopinfo_authentication_unsuccessful">
      <source>Authentication unsuccessful</source>
      <translation variants="no">認證失敗。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_connecting">
      <source>Connecting</source>
      <translation variants="no">連接中</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_signal_too_weak">
      <source>Signal too weak </source>
      <translation variants="no">訊號太弱。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_connection_already_active">
      <source>Connection already active</source>
      <translation variants="no">連接已經啟動。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_permission_denied">
      <source>Permission denied </source>
      <translation variants="no">沒有使用權限。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_service_unreachable">
      <source>Service unreachable</source>
      <translation variants="no">無法進入服務。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_check_security_key">
      <source>Check security key</source>
      <translation variants="no">請檢查安全金鑰。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_configuration_failed">
      <source>Configuration failed</source>
      <translation variants="no">配置失敗。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_internal_error">
      <source>Internal error </source>
      <translation variants="no">內部錯誤。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_check_connection_settings">
      <source>Check connection settings</source>
      <translation variants="no">請檢查連接設定。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_sim_card_missing">
      <source>SIM card missing </source>
      <translation variants="no">缺少SIM卡。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_please_try_again">
      <source>Please try again </source>
      <translation variants="no">請重試。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_connection_failed">
      <source>Connection failed</source>
      <translation variants="no">連接失敗。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_wlan_network_not_found">
      <source>WLAN network not found</source>
      <translation variants="no">找不到WLAN網絡。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_connection_unavailable">
      <source>Connection unavailable</source>
      <translation variants="no">連接無法使用。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpopinfo_select_to_manage">
      <source>Select to manage</source>
      <translation variants="no">選擇以進行管理。</translation>
    </message>
    <message numerus="no" id="txt_occ_dpophead_maximum_connections_in_use">
      <source>Maximum connections in use</source>
      <translation variants="no">所有連接已在使用中。</translation>
    </message>
  </context>
</TS>