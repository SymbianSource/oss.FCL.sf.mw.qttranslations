<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_messaging_list_time">
      <source>&lt;time&gt;</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_delete_message">
      <source>Delete message</source>
      <translation variants="no">Видалити повідомлення</translation>
    </message>
    <message numerus="yes" id="txt_messaging_dpophead_ln_outgoing_messages">
      <source>%Ln Outgoing messages </source>
      <translation>
        <numerusform plurality="a">uk ##%Ln Outgoing messages </numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_outgoing_message">
      <source>Outgoing message </source>
      <translation variants="yes">
        <lengthvariant priority="1">Триває надсилання повідомлення</lengthvariant>
        <lengthvariant priority="2">Надсилання повідомлення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add">
      <source>Add   </source>
      <translation variants="no">Додати</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_sound">
      <source>Sound </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Sound </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_open_link">
      <source>Open link</source>
      <translation variants="no">Відкрити посилання</translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_cc">
      <source>Cc:</source>
      <translation variants="no">Копія:</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_business_card">
      <source>Business Card </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Business Card </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_more">
      <source>More...</source>
      <translation variants="no">Інший</translation>
    </message>
    <message numerus="yes" id="txt_messaging_dpophead_ln_failed_messages">
      <source>%Ln Failed messages </source>
      <translation>
        <numerusform plurality="a">uk ##%Ln Failed messages </numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority_val_normal">
      <source>Normal </source>
      <translation variants="no">Звичайний</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_new_message">
      <source>New Message </source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_message_sending_failed">
      <source>Message sending failed </source>
      <translation variants="yes">
        <lengthvariant priority="1">Помилка надсилання повідомлення</lengthvariant>
        <lengthvariant priority="2">Помилка надсилання повід.</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_item_file">
      <source>Unable to attach item! File type not supported </source>
      <translation variants="no">Неможл. додати вклад. Тип файлу не підтрим.</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_conversation">
      <source>Delete Conversation ? </source>
      <translation variants="no">Видалити розмову?</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_landmarks">
      <source>Save to landmarks</source>
      <translation variants="no">Зберегти в Орієнтирах</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_copy_link">
      <source>Copy link</source>
      <translation variants="no">Копіювати посилання</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_receive_read_report">
      <source>Receive read report </source>
      <translation variants="no">Отримувати звіт про читання</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_attach">
      <source>Attach</source>
      <translation variants="no">Додати вкладення</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_ringing_tone">
      <source>Ringing tone </source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_deleted">
      <source>Message deleted </source>
      <translation variants="no">Повідомлення видалено</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority_val_high">
      <source>High </source>
      <translation variants="no">Високий</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_l1">
      <source>(%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_photo">
      <source>Photo </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Photo </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_conversation_deleted">
      <source>Conversation Deleted</source>
      <translation variants="no">Розмову видалено</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_video">
      <source>Video </source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority_val_low">
      <source>Low </source>
      <translation variants="no">Низький</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_l1_of_l2">
      <source>Unable to attach %L1 of %L2 items ! Maximum size exceeded  </source>
      <translation variants="no">uk ##Unable to attach %L1 of %L2 items. Maximum size exceeded  </translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_bcc">
      <source>Bcc:</source>
      <translation variants="no">Схована копія:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_message_date">
      <source>&lt;message date&gt;</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_receive_delivery_report">
      <source>Receive delivery report</source>
      <translation variants="no">Отримувати звіт про доставку</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_subject">
      <source>Subject</source>
      <translation variants="no">Тема</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_from">
      <source>From:</source>
      <translation variants="no">Від:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_calendar_event">
      <source>Calendar event </source>
      <translation variants="no">uk ##Calendar event </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_more">
      <source>More...</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##More...</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_attach_to_new_message">
      <source>Attach to new message</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Attach to new message</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_cc_bcc">
      <source>Cc / Bcc</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_sending_options_for_this_messa">
      <source>Sending Options for this message</source>
      <translation variants="no">Опції надсилання для цього повідомлення</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_message_time">
      <source>&lt;message time&gt;</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_business_card">
      <source>Business Card </source>
      <translation variants="no">Візитка</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_high">
      <source>High </source>
      <translation variants="no">uk ##High </translation>
    </message>
    <message numerus="yes" id="txt_messaging_list_ln_new_messages">
      <source>%Ln New Messages </source>
      <translation>
        <numerusform plurality="a">uk ##%Ln New Messages </numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_deleting_will_remove_some_mul">
      <source>Deleting will remove some multimedia messages displayed in other conversations too. Delete conversation?</source>
      <translation variants="no">uk ##Deleting will remove some multimedia messages displayed in other conversations too. Delete conversation?</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">uk ##Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_business_card">
      <source>Ringing tone</source>
      <translation variants="no">uk ##Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">uk ##Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delate_all_drafts">
      <source>Delate all drafts ?</source>
      <translation variants="no">uk ##Delate all drafts ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_fwd">
      <source>FWD: </source>
      <translation variants="no">uk ##FWD: </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_drafts">
      <source>Drafts</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Drafts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_same_message_exists_in_multip">
      <source>Same message exists in multiple conversations. Delete all ? </source>
      <translation variants="no">uk ##Same message exists in multiple conversations. Delete all ? </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_attached_photo_size_is_l1">
      <source>Attached photo size is %L1 * %L2 pixels  </source>
      <translation variants="no">uk ##Attached photo size is %L1 * %L2 pixels  </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_listview_resend_at_time">
      <source>Resend at &lt;time&gt;</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Resend at &lt;time&gt;</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_forward">
      <source>Forward</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Forward</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_all_drafts">
      <source>Delete all drafts ?</source>
      <translation variants="no">uk ##Delete all drafts ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">uk ##Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_priority">
      <source>Priority</source>
      <translation variants="no">uk ##Priority</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_message_centre_does_not_e">
      <source>SMS Message centre does not exist. Create New  ?</source>
      <translation variants="no">uk ##SMS Message centre does not exist. Create New  ?</translation>
    </message>
    <message numerus="no" id="txt_conversations_list_message_cannot_be_shown_exa">
      <source>Message cannot be shown exactly as the sender intended. Open to see included objects</source>
      <translation variants="no">uk ##Message cannot be shown exactly as the sender intended. Open to see included objects</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_unable_to_delete_conversation">
      <source>Unable to delete conversation as it contains messages being sent. Try again later.  </source>
      <translation variants="no">uk ##Unable to delete conversation as it contains messages being sent. Try again later.  </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_advertisement">
      <source>Advertisement</source>
      <translation variants="no">uk ##Advertisement</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_class">
      <source>Class: </source>
      <translation variants="no">uk ##Class: </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_personal">
      <source>Personal</source>
      <translation variants="no">uk ##Personal</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_message_centre">
      <source>Delete message centre?</source>
      <translation variants="no">uk ##Delete message centre?</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_loading">
      <source>Loading...</source>
      <translation variants="no">uk ##Loading...</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_re">
      <source>RE: </source>
      <translation variants="no">uk ##RE: </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_slide_l1l2">
      <source>Slide %L1/%L2</source>
      <translation variants="no">uk ##Slide %L1/%L2</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_unknown_bluetooth_device">
      <source>Unknown Bluetooth Device </source>
      <translation variants="no">uk ##Unknown Bluetooth Device </translation>
    </message>
    <message numerus="no" id="txt_conversations_list_1_2">
      <source>%1 %2</source>
      <translation variants="no">uk ##%1 %2</translation>
    </message>
    <message numerus="yes" id="txt_messaging_title_ln_other_recipients">
      <source>%Ln Other recipients</source>
      <translation>
        <numerusform plurality="a">uk ##%Ln Other recipients</numerusform>
        <numerusform plurality="b">uk #MISSING</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_manual">
      <source>Manual</source>
      <translation variants="no">uk ##Manual</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_contact_info">
      <source>Contact info </source>
      <translation variants="no">uk ##Contact info </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_message_cannot_be_shown_ex">
      <source>Message cannot be shown exactly as the sender intended. Included objects shown as attachments:</source>
      <translation variants="no">uk ##Message cannot be shown exactly as the sender intended. Included objects shown as attachments:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_expiry_date">
      <source>Expiry date: </source>
      <translation variants="no">uk ##Expiry date: </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_resend_at_time">
      <source>Resend at &lt;time&gt;</source>
      <translation variants="no">uk ##Resend at &lt;time&gt;</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_messaging_settings">
      <source>Messaging settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Messaging settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receiving_service_messages">
      <source>Receiving service messages</source>
      <translation variants="no">uk ##Receiving service messages</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">uk ##Messaging</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_conversations">
      <source>Conversations</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Conversations</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_conversations">
      <source>Conversations</source>
      <translation variants="no">uk ##Conversations</translation>
    </message>
    <message numerus="no" id="txt_conversations_dialog_save_ringing_tone">
      <source>Save ringing tone ?</source>
      <translation variants="no">uk ##Save ringing tone ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_delete_all">
      <source>Delete all </source>
      <translation variants="no">uk ##Delete all </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_received_files">
      <source>Received files</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Received files</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_pending">
      <source>(Pending)</source>
      <translation variants="no">(очікування)</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sending_options">
      <source>Sending options </source>
      <translation variants="no">Опції надсилання</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_others">
      <source>Not specified</source>
      <translation variants="no">uk #Other</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receive_service_messages">
      <source>Not specified</source>
      <translation variants="no">uk #Receive service messages</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_enter_message_here">
      <source>Enter message here </source>
      <translation variants="no">Ввести текст</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_message_centre_number">
      <source>Message centre number </source>
      <translation variants="no">Номер центру повідомлень</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_contacts_sub_add_to_exi">
      <source>Add to Existing </source>
      <translation variants="no">Оновити існуючий</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_from">
      <source>Not specified</source>
      <translation variants="no">uk #From:</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_download">
      <source>Download</source>
      <translation variants="no">Завантажити</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_sound">
      <source>Sound</source>
      <translation variants="no">Аудіокліп</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_advanced">
      <source>Advanced</source>
      <translation variants="no">Додаткові установки</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_edit_sms_message_centre">
      <source>Edit SMS message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">Редагування</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_sms_email_settings">
      <source>Not specified</source>
      <translation variants="no">uk #SMS mail settings</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_free">
      <source>Free</source>
      <translation variants="no">Вільний</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_mannual">
      <source>Mannual</source>
      <translation variants="no">Вручну</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_always_automatic">
      <source>Always automatic </source>
      <translation variants="no">Завжди ввімкнено</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_open_contact_info">
      <source>Open contact info </source>
      <translation variants="no">Деталі контакту</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority_sub_normal">
      <source>Not specified</source>
      <translation variants="no">uk #Normal</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_subject">
      <source>Subject:</source>
      <translation variants="no">Тема:</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_creation_mode">
      <source>MMS creation mode </source>
      <translation variants="no">Режим створення MMS</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority_sub_high">
      <source>Not specified</source>
      <translation variants="no">uk #High</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_ln">
      <source>(%Ln )</source>
      <translation variants="no">uk #(%Ln)</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_settings">
      <source>Settings</source>
      <translation variants="no">Установки</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_advanced_settings_messaging">
      <source>Advanced settings : Messaging </source>
      <translation variants="no">Додаткові установки</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_sms_message_centre_settings">
      <source>SMS message centre settings </source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки центру SMS-повідомлень</lengthvariant>
        <lengthvariant priority="2">Установки центру SMS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_val_yes">
      <source>Yes</source>
      <translation variants="no">Дозволено</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_type_changed_to_tex">
      <source>Message type changed to text message</source>
      <translation variants="no">Тип повідомлення змінено на текстове</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_type_changed_to_mul">
      <source>Message type changed to multimedia </source>
      <translation variants="no">Тип повідомлення змі­нено на мультимедійне</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_message">
      <source>Allow anonymous MMS messages </source>
      <translation variants="no">Анонімні мультимед. повід.</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_remove_attachment">
      <source>Remove attachment</source>
      <translation variants="no">uk #Remove attachment</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_cc">
      <source>Cc:</source>
      <translation variants="no">Копія:</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_full_support">
      <source>Full support </source>
      <translation variants="no">Повна підтримка</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">Зберегти в Контактах</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_messaging">
      <source>Messaging</source>
      <translation variants="yes">
        <lengthvariant priority="1">Повідомлення</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_bcc">
      <source>Bcc: </source>
      <translation variants="no">Схована копія:</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_access_point_in_use">
      <source>MMS access point in use </source>
      <translation variants="no">Точка доступу до мультим.</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_delete_conversation">
      <source>Delete Conversation</source>
      <translation variants="no">Видалити розмову</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_email_gateway">
      <source>Not specified</source>
      <translation variants="no">uk #Mail gateway</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_character_encoding">
      <source>Character encoding </source>
      <translation variants="no">Кодування символів</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receive_mms_adverts">
      <source>Receive MMS adverts </source>
      <translation variants="no">Отримувати рекламу</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">Вимкн.</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_auto_home_network">
      <source>Automatic in home network </source>
      <translation variants="no">Автоматично в домашній мережі</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_mms_settings">
      <source>MMS settings </source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки MMS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_delete_message_centre">
      <source>Delete message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">Видалити</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_select_attachment_type">
      <source>Select attachment type</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #Select attachment type:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority">
      <source>Not specified</source>
      <translation variants="no">uk #Message priority</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_photo">
      <source>Photo</source>
      <translation variants="no">Зображення</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_sms_message_centre_in_use">
      <source>SMS message centre in use </source>
      <translation variants="no">Центр SMS-повідомлень</translation>
    </message>
    <message numerus="no" id="txt_common_opt_ln_new_messages">
      <source>%Ln New Messages </source>
      <translation variants="no">uk #%Ln new message</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_add_to_bookmarks">
      <source>Add to bookmarks</source>
      <translation variants="no">Зберегти в закладках</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority_sub_low">
      <source>Not specified</source>
      <translation variants="no">uk #Low</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_others">
      <source>Not specified</source>
      <translation variants="no">uk #Other</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_play_message">
      <source>Not specified</source>
      <translation variants="no">uk #Play</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_location">
      <source>Not specified</source>
      <translation variants="no">uk #Location</translation>
    </message>
    <message numerus="no" id="txt_short_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">uk ##Messaging</translation>
    </message>
    <message numerus="no" id="txt_long_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">Повідомлення</translation>
    </message>
    <message numerus="no" id="txt_task_switcher_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_sending_failed">
      <source>Sending Failed</source>
      <translation variants="no">uk ##Sending Failed</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_informational">
      <source>Informational</source>
      <translation variants="no">uk ##Informational</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_send_selected_item">
      <source>Send selected item </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Send selected item</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_create_mail">
      <source>Create mail </source>
      <translation variants="no">Створити електр. лист</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_character_count_excee">
      <source>SMS character count exceeded. Convert to multimedia message ? </source>
      <translation variants="no">Забагато символів. Конвертувати в MMS?</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_recipients">
      <source>Recipients</source>
      <translation variants="no">Одержувач</translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_to">
      <source>To:  </source>
      <translation variants="no">Кому:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_received_files">
      <source>Received files </source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Received files </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_reduced_support">
      <source>Reduced support </source>
      <translation variants="no">Зменшена підтримка</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_mms_access_point_not_defined">
      <source>MMS Access point not defined. Define now  ?</source>
      <translation variants="no">uk ##MMS Access point not defined. Define now  ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_drafts">
      <source>Drafts</source>
      <translation variants="no">uk ##Drafts</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_note_as_attachment">
      <source>Not specified</source>
      <translation variants="no">uk #Note (as attachment)</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_email_service_centre_numbe">
      <source>Not specified</source>
      <translation variants="no">uk #Mail message centre number</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach">
      <source>Attach</source>
      <translation variants="no">Додати вкладення</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_business_card">
      <source>Business card</source>
      <translation variants="no">uk ##Business card</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_delivery_failed">
      <source>(Delivery Failed !)</source>
      <translation variants="no">(помилка доставки)</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_message">
      <source>Delete message ? </source>
      <translation variants="no">Видалити повідомлення?</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_item_avai">
      <source>Unable to attach item! Available space is %L1kb</source>
      <translation variants="no">uk ##Unable to attach item. Available space is %L1kb</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_invalid_recipient_found">
      <source>Invalid recipient found: </source>
      <translation variants="no">uk ##Invalid recipient found: </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority">
      <source>Priority</source>
      <translation variants="no">Пріоритет</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">uk ##Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_number_of_recipients_exceeded">
      <source>Number of recipients exceeded.Convert to multimedia message ? </source>
      <translation variants="no">Перевищ. макс. кільк. одерж. Конверт. в MMS?</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_val_no">
      <source>No</source>
      <translation variants="no">Не дозволено</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_delivered_date_time">
      <source>(Delivered &lt;date&gt; &lt;time&gt;) </source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_wireframe_list_multimedia_message_waiting">
      <source>Multimedia message waiting...</source>
      <translation variants="no">uk ##Multimedia message waiting…</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_character_count_exceeded">
      <source>SMS character count exceeded. Convert to multimedia message?</source>
      <translation variants="no">Перевищ. макс. кільк. симв. Конвертув. в MMS?</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_merge_contacts">
      <source>Merge Contacts </source>
      <translation variants="no">Об’єднати контакти</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_to">
      <source>To: </source>
      <translation variants="no">Кому:</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_subject">
      <source>Not specified</source>
      <translation variants="no">uk #Add Subject field</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_recipients">
      <source>Add recipients</source>
      <translation variants="no">uk ##Add recipients</translation>
    </message>
    <message numerus="no" id="txt_conversations_list_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">uk ##Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_message_sending_failed">
      <source>Message Sending failed !</source>
      <translation variants="no">uk ##Message Sending failed !</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_add_more_content">
      <source>Unable to add more content. Maximum size exceeded</source>
      <translation variants="no">uk ##Unable to add more content. Maximum size exceeded</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_listview_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk ##Unsupported message type</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_add_more_recipien">
      <source>Unable to add more recipients. Maximum limit exceeded</source>
      <translation variants="no">uk ##Unable to add more recipients. Maximum limit exceeded</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_message_centre_name">
      <source>Message centre name </source>
      <translation variants="no">Назва центру повідомлень</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_add_new">
      <source>Add New </source>
      <translation variants="yes">
        <lengthvariant priority="1">Новий центр повідомлень</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_centre_saved">
      <source>Message centre saved</source>
      <translation variants="no">uk ##Message centre saved</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_contacts_sub_create_new">
      <source>Create New </source>
      <translation variants="no">Створити новий</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_guided">
      <source>Guided</source>
      <translation variants="no">З підказками</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_delivery_reports">
      <source>Delivery reports</source>
      <translation variants="no">Звіти про доставку</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_restricted">
      <source>Restricted </source>
      <translation variants="no">Обмежений</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_business_card">
      <source>Business card </source>
      <translation variants="no">uk #Business card</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_normal">
      <source>Normal </source>
      <translation variants="no">uk ##Normal </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_other_recipients">
      <source>Other recipients</source>
      <translation variants="no">uk ##Other recipients</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_resend_at_time">
      <source>Resend at &lt;time&gt;</source>
      <translation variants="no">uk ##Resend at &lt;time&gt;</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_saved_to_drafts">
      <source>Saved to drafts</source>
      <translation variants="no">uk ##Saved to drafts</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_size">
      <source>Size:  </source>
      <translation variants="no">uk ##Size:  </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_clear_conversation">
      <source>Not specified</source>
      <translation variants="no">uk #Remove messages</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_retrieval">
      <source>MMS retrieval </source>
      <translation variants="no">Завантаження MMS</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_update">
      <source>Update </source>
      <translation variants="no">Редагувати</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_new_sms_message_centre">
      <source>New  SMS message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">Новий центр SMS-повідомлень</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_full_screen">
      <source>Full screen </source>
      <translation variants="no">Повний екран</translation>
    </message>
    <message numerus="yes" id="txt_messaging_group_title_ln_other_recipients">
      <source>%Ln Other recipients</source>
      <translation>
        <numerusform plurality="a">uk #%Ln other recipient</numerusform>
        <numerusform plurality="b">uk #%Ln other recipients</numerusform>
        <numerusform plurality="c">uk #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_on">
      <source>On</source>
      <translation variants="no">Увімкн.</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">uk ##Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_video">
      <source>Video</source>
      <translation variants="no">Відеокліп</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_cc_bcc">
      <source>Not specified</source>
      <translation variants="no">uk #Add Cc and Bcc fields</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_date_time">
      <source>&lt;date&gt; &lt;time&gt;</source>
      <translation variants="no">uk ##</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_low">
      <source>Low </source>
      <translation variants="no">uk ##Low </translation>
    </message>
  </context>
</TS>