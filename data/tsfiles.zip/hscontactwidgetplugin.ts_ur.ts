<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_friend_widget_info_you_can_not_use_this_widge">
      <source>You can not use this  widget, because your phonebook is empty. Open Phonebook to add contacts?</source>
      <translation variants="no">مختصر روابط استعمال نہیں کیے جا سکتے کیونکہ روابط پروگرام میں کوئی رابطہ نہیں ہے۔ روابط پروگرام کھولیں؟</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget_val_quickly">
      <source>Quickly communicate with a contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">رابطے سے فوری مواصلت</lengthvariant>
        <lengthvariant priority="2">ur #Quick communication</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_friend_widget_dblist_friend_widget">
      <source>Contact widget</source>
      <translation variants="yes">
        <lengthvariant priority="1">مختصر روابط</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_friend">
      <source>Contact widget</source>
      <translation variants="no">ur #Mini Contacts</translation>
    </message>
    <message numerus="no" id="txt_long_caption_friend">
      <source>Contact widget</source>
      <translation variants="no">ur #Mini Contacts</translation>
    </message>
    <message numerus="no" id="txt_friend_widget_title_select_contact">
      <source>Select contact:</source>
      <translation variants="no">رابطہ منتخب کریں</translation>
    </message>
  </context>
</TS>