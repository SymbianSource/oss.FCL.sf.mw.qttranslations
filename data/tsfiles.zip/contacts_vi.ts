<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">Điện thoại internet</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">Điện thoại internet (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_pobox">
      <source>P.O.Box</source>
      <translation variants="no">Hộp thư Bưu điện</translation>
    </message>
    <message numerus="no" id="txt_phob_button_cancel">
      <source>Cancel</source>
      <translation variants="yes">
        <lengthvariant priority="1">Hủy</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email">
      <source>Email</source>
      <translation variants="no">Địa chỉ e-mail</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_status_update">
      <source>Status update</source>
      <translation variants="no">Trạng thái</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_home">
      <source>URL (home)</source>
      <translation variants="no">Địa chỉ web (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_work">
      <source>Fax (work)</source>
      <translation variants="no">Fax (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_work">
      <source>Call Phone (work)</source>
      <translation variants="no">Gọi điện thoại (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_home">
      <source>Email (home)</source>
      <translation variants="no">Địa chỉ e-mail (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_only_group_will_be_removed_contac">
      <source>Only group will be removed. Contacts can be found from all contacts list.</source>
      <translation variants="no">vi #Only group will be deleted. Contacts can be found from all contact lists.</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_countryregion">
      <source>Country/Region</source>
      <translation variants="no">Quốc gia/Vùng</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_stateprovince">
      <source>State/Province</source>
      <translation variants="no">Tiểu bang/Tình</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_services">
      <source>Manage services</source>
      <translation variants="no">Quản lý dịch vụ</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_matching_contacts">
      <source>(no matching contacts)</source>
      <translation variants="no">vi #(no matches)</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_delete_1_group">
      <source>Delete %1 group?</source>
      <translation variants="no">Xóa nhóm %[14]1?</translation>
    </message>
    <message numerus="no" id="txt_phob_title_import_contacts">
      <source>Import contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhập số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_image">
      <source>Remove image</source>
      <translation variants="no">Xóa hình ảnh</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_image_not_added">
      <source>Image not included.</source>
      <translation variants="no">Hình ảnh không được bao gồm</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_history_with_1">
      <source>History with %1</source>
      <translation variants="no">Cuộc trò chuyện với %1</translation>
    </message>
    <message numerus="no" id="txt_phob_list_received">
      <source>Received call</source>
      <translation variants="no">vi #Received call</translation>
    </message>
    <message numerus="no" id="txt_phob_title_manage_services">
      <source>Manage services</source>
      <translation variants="yes">
        <lengthvariant priority="1">Quản lý dịch vụ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_you_can_restore_linking_at_any_tim">
      <source>You can restore linking at any time by `Link profile´ or in Service view.</source>
      <translation variants="no">Có thể khôi phục liên kết bất kỳ lúc nào bằng cách chọn 'Liên kết profile' hoặc trong giao diện dịch vụ.</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">vi #Contacts</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url">
      <source>URL</source>
      <translation variants="no">Địa chỉ web</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_unnamed">
      <source>Unnamed</source>
      <translation variants="yes">
        <lengthvariant priority="1">(chưa đặt tên)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_search_for_matched_contacts">
      <source>Search for matched contacts</source>
      <translation variants="no">Tìm kiếm số l.lạc phù hợp</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_group">
      <source>New group</source>
      <translation variants="no">Nhóm mới</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message_val_members">
      <source>Members</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thành viên</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_extension">
      <source>Extension</source>
      <translation variants="no">Phần mở rộng</translation>
    </message>
    <message numerus="no" id="txt_phob_list_missed_call">
      <source>Missed call</source>
      <translation variants="no">vi #Missed call</translation>
    </message>
    <message numerus="no" id="txt_phob_list_fetch_from_1">
      <source>Fetch from %1</source>
      <translation variants="no">Tải từ %1</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile">
      <source>Call Mobile</source>
      <translation variants="no">Gọi di động</translation>
    </message>
    <message numerus="no" id="txt_phob_button_choose_from_my_contacts">
      <source>Choose from my contacts</source>
      <translation variants="no">Chọn từ các số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_work">
      <source>Call Fax (work)</source>
      <translation variants="no">Gửi fax (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_last_name">
      <source>Last name</source>
      <translation variants="no">Họ</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone">
      <source>Phone</source>
      <translation variants="no">Điện thoại</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_conference_number">
      <source>Conference number</source>
      <translation variants="no">Số hội nghị</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_send_message">
      <source>Send message</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gửi tin nhắn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_pager">
      <source>Call Pager</source>
      <translation variants="no">Gọi nhắn tin</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites_val_no_favorites_selecte">
      <source>No favorites selected</source>
      <translation variants="no">Không có số liên lạc ưa thích</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_updated_1">
      <source>Updated %L1</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đã cập nhật: %L1</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number">
      <source>Video call</source>
      <translation variants="no">Thực hiện c.gọi video</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ web</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_work">
      <source>Email (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ e-mail (công việc)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_clear_communications_history_with_1">
      <source>Delete communications history with %1?</source>
      <translation variants="no">Xóa lịch sử liên lạc cùng với %[71]1?</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_work">
      <source>Address (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ (công việc)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_email_address">
      <source>Email address</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ e-mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_job_title">
      <source>Job title</source>
      <translation variants="no">Chức vụ</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_groups">
      <source>Delete groups</source>
      <translation variants="no">Xóa (các) nhóm</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_home">
      <source>URL (home)</source>
      <translation variants="no">Ch.đến đ.chỉ web (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email">
      <source>Send email</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gửi e-mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_long_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="no">Gọi di động (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_note">
      <source>Note</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ghi chú</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile">
      <source>Mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Di động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_short_caption_contacts">
      <source>Contacts</source>
      <translation variants="no">vi ##Contacts</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name_separator">
      <source>Last name, First name</source>
      <translation variants="no">Họ, Tên</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_birthday">
      <source>Birthday</source>
      <translation variants="no">Sinh nhật</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile">
      <source>Mobile</source>
      <translation variants="no">Di động</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_conference_call">
      <source>Conference call</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cuộc gọi hội nghị</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_my_card">
      <source>Save My card</source>
      <translation variants="no">Lưu lại thẻ của tôi</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_discard_changes">
      <source>Discard changes</source>
      <translation variants="no">Loại bỏ thay đổi</translation>
    </message>
    <message numerus="no" id="txt_phob_button_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">Nhập số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order">
      <source>Name display order</source>
      <translation variants="no">Hiển thị tên</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gọi điện thoại trên xe</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">Xóa khỏi mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_date">
      <source>Edit date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa ngày</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone">
      <source>Phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_dialled_call">
      <source>Dialled call</source>
      <translation variants="no">vi #Dialled call</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_assistant">
      <source>Assistant</source>
      <translation variants="no">Số của người trợ lý</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_your_own_card">
      <source>Create your own card</source>
      <translation variants="no">Tạo thẻ của tôi</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_all_contacts">
      <source>Find: All contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tìm kiếm: Tất cả số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_home">
      <source>Call Fax (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gửi fax (nhà)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_home">
      <source>Phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại (nhà)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_your_phonebook_is_empty_you_can_ch">
      <source>Your Phonebook is empty</source>
      <translation variants="no">Không có số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_phob_list_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">Tạo thẻ của tôi</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_family_details">
      <source>Edit family details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa chi tiết gia đình</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_last_name">
      <source>Last name First name</source>
      <translation variants="no">Họ Tên</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_from_group">
      <source>Remove from group</source>
      <translation variants="no">Xóa khỏi nhóm</translation>
    </message>
    <message numerus="no" id="txt_phob_info_create_own_card_to_share_it_with_fri">
      <source>Create own card to share it with friends</source>
      <translation variants="no">Tạo thẻ của tôi bằng chi tiết của chính bạn và chia sẻ thẻ với bạn bè</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url_work">
      <source>URL (work)</source>
      <translation variants="no">Ch.đến đ.chỉ web (c.v)</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_new_group_1_created">
      <source>New group %1 created</source>
      <translation variants="no">Đã tạo nhóm mới %[20]1</translation>
    </message>
    <message numerus="no" id="txt_phob_list_yesterday_1">
      <source>yesterday %L1</source>
      <translation variants="no">vi #Yesterday %L1</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_address">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_as_a_business_card">
      <source>Send as a business card</source>
      <translation variants="no">Gửi dạng danh thiếp</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_url">
      <source>URL</source>
      <translation variants="no">Chuyển đến địa chỉ web</translation>
    </message>
    <message numerus="no" id="txt_phob_list_chooce_from_gallery">
      <source>Chooce from gallery</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn từ Hình ảnh</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_children">
      <source>Children</source>
      <translation variants="no">Con</translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_to_contacts">
      <source>Add to contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thêm vào Danh bạ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">Trò chuyện (%[08]1)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_work">
      <source>Phone (work)</source>
      <translation variants="no">Điện thoại (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_work">
      <source>Email (work)</source>
      <translation variants="no">Gửi e-mail (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_first_name">
      <source>First name</source>
      <translation variants="no">Tên</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_url_address">
      <source>Url address</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ web</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_car">
      <source>Car</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại trên xe</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">Nhạc chuông</translation>
    </message>
    <message numerus="yes" id="txt_phob_dblist_val_ln_numbers">
      <source>%Ln numbers</source>
      <translation>
        <numerusform plurality="a">vi #%Ln number</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_personal_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhạc chuông</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_number">
      <source>Set as default number</source>
      <translation variants="no">Đặt làm số mặc định</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_address_home">
      <source>Address (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ (nhà)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_nick_name">
      <source>Nick name</source>
      <translation variants="no">Bí danh</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_pager">
      <source>Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhắn tin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_create">
      <source>Create</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tạo</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_take_a_new_photo">
      <source>Take a new photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chụp hình mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_home">
      <source>Video call (home)</source>
      <translation variants="no">T.hiện c.gọi video (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_message">
      <source>Send message</source>
      <translation variants="no">Gửi tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_phob_list_company_details">
      <source>Company details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết công ty</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone">
      <source>Call phone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gọi điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_send_to_homescreen">
      <source>Send to homescreen</source>
      <translation variants="no">Thêm vào M.hình chính</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_favorites">
      <source>Favorites</source>
      <translation variants="no">Số liên lạc ưa thích</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_details">
      <source>Details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_assistant">
      <source>Call assistant</source>
      <translation variants="no">Gọi người trợ lý</translation>
    </message>
    <message numerus="no" id="txt_phob_list_family">
      <source>Family details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chi tiết gia đình</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_new_group_name">
      <source>New group name:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên nhóm:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_group_details">
      <source>Edit group details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa chi tiết nhóm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_pager">
      <source>Call Pager</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gọi nhắn tin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address">
      <source>Address</source>
      <translation variants="no">Địa chỉ</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_import_contacts">
      <source>Import contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhập số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sufix">
      <source>Suffix</source>
      <translation variants="no">Chức vị</translation>
    </message>
    <message numerus="no" id="txt_phob_list_address">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ e-mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email_home">
      <source>Email (home)</source>
      <translation variants="no">Gửi e-mail (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_favorites">
      <source>Favorites</source>
      <translation variants="no">Số liên lạc ưa thích</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_change_picture">
      <source>Change picture</source>
      <translation variants="no">Thay đổi hình ảnh</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_work">
      <source>Call Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gọi di động (công việc)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_work">
      <source>URL (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ web (công việc)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_group_name">
      <source>Group name</source>
      <translation variants="no">Tên nhóm</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show">
      <source>Show</source>
      <translation variants="no">Hiển thị</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_name">
      <source>Enter name</source>
      <translation variants="no">vi #Name</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số liên lạc ưa thích</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_unknown">
      <source>Unknown</source>
      <translation variants="no">vi #Unknown</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax_home">
      <source>Call Fax (home)</source>
      <translation variants="no">Gửi fax (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_history">
      <source>Delete history</source>
      <translation variants="no">Xóa lịch sử</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_set_as_default_email">
      <source>Set as default email</source>
      <translation variants="no">Đặt làm e-mail mặc định</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_video_number_work">
      <source>Video call (work)</source>
      <translation variants="no">T.hiện c.gọi vid. (c.việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_fax">
      <source>Call Fax</source>
      <translation variants="no">Gửi fax</translation>
    </message>
    <message numerus="no" id="txt_phob_subhead_presentation_settings">
      <source>Presentation settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gọi di động (nhà)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_chat_1">
      <source>Chat (%1)</source>
      <translation variants="no">Trò chuyện (%[10]1)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_work">
      <source>Send mail (Work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gửi e-mail (công việc)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_assistant">
      <source>Call assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gọi người trợ lý</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_phone_home">
      <source>Phone (home)</source>
      <translation variants="no">Điện thoại (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_new">
      <source>Create new</source>
      <translation variants="no">Tạo mới</translation>
    </message>
    <message numerus="yes" id="txt_phob_list_ln_numbers">
      <source>%Ln number</source>
      <translation>
        <numerusform plurality="a">%Ln số</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_prefix">
      <source>Prefix</source>
      <translation variants="no">Tiêu đề</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_email">
      <source>Email</source>
      <translation variants="no">Gửi e-mail</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_note">
      <source>Note</source>
      <translation variants="no">Ghi chú</translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_mycard_image_to_business_card">
      <source>Add MyCard image to Business card?</source>
      <translation variants="no">Cũng bao gồm hình ảnh thẻ của tôi?</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_web_address">
      <source>Edit web address</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa địa chỉ web</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">Xóa số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_remove_from_favorites">
      <source>Remove from favorites</source>
      <translation variants="no">Xóa khỏi mục ưa thích</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_save_contact">
      <source>Save contact</source>
      <translation variants="no">Lưu lại số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_email_address">
      <source>Edit email address</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa địa chỉ e-mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_manage_favorites">
      <source>Manage favorites</source>
      <translation variants="no">Quản lý số l.lạc ưa thích</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_1_val_no_sim_contacts">
      <source>No SIM contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có số liên lạc SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_number">
      <source>Add number</source>
      <translation variants="no">Thêm số</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">Điện thoại internet (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_bluetooth">
      <source>Bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">Qua Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_link_profiles">
      <source>Link profiles</source>
      <translation variants="yes">
        <lengthvariant priority="1">Liên kết profile</lengthvariant>
        <lengthvariant priority="2">L.kết profile</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_message">
      <source>Send message</source>
      <translation variants="no">Gửi tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_phob_title_select_contact">
      <source>Select contact</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_url_work">
      <source>URL (work)</source>
      <translation variants="no">Địa chỉ web (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts2">
      <source>All contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tất cả số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mail for Exchange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_mail_for_exchange">
      <source>Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">Mail for Exchange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_email">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ e-mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_link_in_1">
      <source>Link in %1</source>
      <translation variants="no">Liên kết đến %1</translation>
    </message>
    <message numerus="no" id="txt_phob_list_url">
      <source>URL</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ web</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_detail">
      <source>Add detail</source>
      <translation variants="no">Thêm chi tiết</translation>
    </message>
    <message numerus="no" id="txt_phob_button_unlink">
      <source>Unlink</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa liên kết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_service">
      <source>Select service</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chọn dịch vụ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_remove_link">
      <source>Remove link? </source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa liên kết?</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_unnamed">
      <source>Unnamed</source>
      <translation variants="no">vi #(unnamed)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_contacts">
      <source>Delete contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_home">
      <source>Internet telephone (home)</source>
      <translation variants="no">Điện thoại internet (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_unable_to_access_contacts_in_memory">
      <source>Unable to access contacts in memory: %1</source>
      <translation variants="no">Không thể truy cập các số liên lạc được lưu vào %1</translation>
    </message>
    <message numerus="no" id="txt_phob_list_conference_call">
      <source>Conference call</source>
      <translation variants="no">Cuộc gọi hội nghị</translation>
    </message>
    <message numerus="no" id="txt_phob_list_send_mail">
      <source>Send mail</source>
      <translation variants="no">Gửi e-mail</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_note">
      <source>Edit note</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa ghi chú</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_add_contact_card_image_to_business_c">
      <source>Add contact card image to Business card?</source>
      <translation variants="no">Cũng bao gồm hình ảnh thẻ liên lạc của tôi?</translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_select_method">
      <source>Select method</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gửi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_find_from">
      <source>Find from:</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tìm kiếm từ:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_sign_in_to_res">
      <source>Sign in to OVI</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đăng nhập vào tài khoản Nokia của bạn</lengthvariant>
        <lengthvariant priority="2">Đ.nhập vào t.k Nokia của bạn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_delete_groups">
      <source>Delete groups</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa các nhóm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_searching_1">
      <source>Searching %1</source>
      <translation variants="no">Đang tìm kiếm '%[50]1'</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_ringing_tone_val_default">
      <source>Default</source>
      <translation variants="no">Nhạc chuông mặc định</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_and_phonenumber">
      <source>Name and phonenumber</source>
      <translation variants="no">Tên và số điện thoại</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contacts_1_updated">
      <source>Contact %1 updated</source>
      <translation variants="no">Đã cập nhật số liên lạc %[15]1</translation>
    </message>
    <message numerus="no" id="txt_phob_button_manage_services">
      <source>Manage services</source>
      <translation variants="no">Quản lý dịch vụ</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi">
      <source>OVI contacts sync</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đồng bộ với Danh bạ Ovi</lengthvariant>
        <lengthvariant priority="2">vi #Sync with Ovi Contacts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_number">
      <source>Add Number</source>
      <translation variants="no">Thêm số điện thoại</translation>
    </message>
    <message numerus="no" id="txt_phob_title_anniversary">
      <source>Anniversary</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày kỷ niệm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_home">
      <source>Delete Internet telephone (home)</source>
      <translation variants="no">Xóa đ.thoại net (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_note">
      <source>Delete Note</source>
      <translation variants="no">Xóa ghi chú</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_formlabel_val_no_date_set">
      <source>No date set</source>
      <translation variants="no">(chưa đặt ngày)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile">
      <source>Delete Mobile</source>
      <translation variants="no">Xóa di động</translation>
    </message>
    <message numerus="no" id="txt_phob_title_favorite_contacts">
      <source>Favorite contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số liên lạc ưa thích</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone">
      <source>Delete Phone</source>
      <translation variants="no">Xóa điện thoại</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone_work">
      <source>Internet telephone (work)</source>
      <translation variants="no">Điện thoại internet (c.việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_find_mail_for_exchange">
      <source>Find: Mail for Exchange</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tìm kiếm: Mail for Exchange</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_email2">
      <source>Email</source>
      <translation variants="yes">
        <lengthvariant priority="1">Qua e-mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_pager">
      <source>Delete Pager</source>
      <translation variants="no">Xóa nhắn tin</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_sim">
      <source>Import from SIM</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhập từ thẻ SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_home">
      <source>Delete Email (home)</source>
      <translation variants="no">Xóa địa chỉ e-mail (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax">
      <source>Delete Fax</source>
      <translation variants="no">Xóa fax</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_ringing_tone">
      <source>Delete Ringing tone</source>
      <translation variants="no">Xóa nhạc chuông</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_home">
      <source>Delete Fax (home)</source>
      <translation variants="no">Xóa fax (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_home">
      <source>Call phone (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gọi điện thoại (nhà)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_sip">
      <source>Delete SIP</source>
      <translation variants="no">Xóa SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_company_details">
      <source>Add Company details</source>
      <translation variants="no">Thêm chi tiết công ty</translation>
    </message>
    <message numerus="no" id="txt_phob_list_business_card">
      <source>Business card</source>
      <translation variants="no">vi #Business card</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_phone_work">
      <source>Call phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gọi điện thoại (công việc)</lengthvariant>
        <lengthvariant priority="2">Gọi điện thoại (c.việc)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_car">
      <source>Delete Car</source>
      <translation variants="no">Xóa điện thoại trên xe</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_spouse">
      <source>Delete Spouse details</source>
      <translation variants="no">Xóa tên chồng/vợ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_date">
      <source>Add Date</source>
      <translation variants="no">Thêm ngày</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_work">
      <source>Delete Phone (work)</source>
      <translation variants="no">Xóa điện thoại (c.việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_sync_with_ovi">
      <source>Sync with OVI</source>
      <translation variants="no">Đồng bộ với Danh bạ Ovi</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_assistant">
      <source>Delete Assistant number</source>
      <translation variants="no">Xóa số của người trợ lý</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_family_details">
      <source>Add Family details</source>
      <translation variants="no">Thêm chi tiết gia đình</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_device">
      <source>Importing contacts from Device</source>
      <translation variants="no">Nhập số liên lạc từ điện thoại</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_work">
      <source>Delete Mobile (work)</source>
      <translation variants="no">Xóa di động (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_title_select_location">
      <source>Select location</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Select location</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_no_members_selected">
      <source>No members selected</source>
      <translation variants="no">vi #No members selected</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_home">
      <source>Address (home)</source>
      <translation variants="no">Địa chỉ (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_company_details">
      <source>Edit company details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa chi tiết công ty</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts_sync">
      <source>Contacts sync</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đồng bộ Danh bạ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_no_sim_card">
      <source>No SIM card</source>
      <translation variants="yes">
        <lengthvariant priority="1">Không có thẻ SIM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_sign_out">
      <source>Sign out</source>
      <translation variants="no">Đăng xuất</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_company_details">
      <source>Delete Company Details</source>
      <translation variants="no">Xóa chi tiết công ty</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_email">
      <source>Add Email</source>
      <translation variants="no">Thêm địa chỉ e-mail</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_change_image">
      <source>Change image</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thay đổi hình ảnh</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_children">
      <source>Delete Children details</source>
      <translation variants="no">Xóa tên con</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_birthday">
      <source>Delete Birthday</source>
      <translation variants="no">Xóa ngày sinh</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_link_to_phonebook">
      <source>Link to phonebook</source>
      <translation variants="no">Liên kết đến Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_phob_list_mycard">
      <source>MyCard</source>
      <translation variants="no">Thẻ của tôi</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_street">
      <source>Street</source>
      <translation variants="no">Đường</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_delete_contact">
      <source>Delete contact</source>
      <translation variants="no">Xóa số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_clear_my_card">
      <source>Clear My card</source>
      <translation variants="no">Xóa thẻ của tôi</translation>
    </message>
    <message numerus="no" id="txt_phob_title_members_of_1_group">
      <source>%1 members</source>
      <translation variants="no">%[14]1 thành viên</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_pager">
      <source>Pager</source>
      <translation variants="no">Nhắn tin</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_middle_name">
      <source>Middle name</source>
      <translation variants="no">Tên lót</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_phone_work">
      <source>Phone (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Điện thoại (công việc)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="no">Di động (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_remove_image">
      <source>Remove image</source>
      <translation variants="no">Xóa hình ảnh</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard_val_create_my_identity">
      <source>Create my identity</source>
      <translation variants="no">vi #Create my card</translation>
    </message>
    <message numerus="no" id="txt_phob_list_number">
      <source>Number</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_manage_services">
      <source>Manage services</source>
      <translation variants="yes">
        <lengthvariant priority="1">Quản lý dịch vụ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_set_as_favorite">
      <source>Set as favorite</source>
      <translation variants="no">Thêm vào s.l.lạc ư.thích</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_device">
      <source>Import from Device</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhập từ điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_my_details">
      <source>Edit My details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa chi tiết thẻ của tôi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_add_favorites">
      <source>Add favorites</source>
      <translation variants="no">Thêm số liên lạc ưa thích</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_email_home">
      <source>Email (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ e-mail (nhà)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dialog_remove_all_personal_data_from_my_c">
      <source>Remove all personal data from My card?</source>
      <translation variants="no">Xóa tất cả dữ liệu cá nhân khỏi thẻ của tôi?</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_fax_work">
      <source>Delete Fax (work)</source>
      <translation variants="no">Xóa fax (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_phone_home">
      <source>Delete Phone (home)</source>
      <translation variants="no">Xóa điện thoại (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_my_card">
      <source>My card</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thẻ của tôi</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_contacts">
      <source>Contacts</source>
      <translation variants="yes">
        <lengthvariant priority="1">Danh bạ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_email">
      <source>Add email</source>
      <translation variants="no">Thêm địa chỉ e-mail</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Di động (nhà)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_formlabel_val_formlabel_v">
      <source>Find location</source>
      <translation variants="no">vi #Find location</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_val_no_members_selected">
      <source>No members selected</source>
      <translation variants="no">vi #No members selected</translation>
    </message>
    <message numerus="no" id="txt_phob_button_create_a_new_contact">
      <source>Create a new contact</source>
      <translation variants="no">Tạo số liên lạc mới</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mycard">
      <source>MyCard</source>
      <translation variants="no">vi #My card</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_city">
      <source>City</source>
      <translation variants="no">Thành phố</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_address_details">
      <source>Edit address details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa chi tiết địa chỉ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_mobile_home">
      <source>Mobile (home)</source>
      <translation variants="no">Di động (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_date">
      <source>Date</source>
      <translation variants="yes">
        <lengthvariant priority="1">Ngày</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_groups">
      <source>Groups</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhóm</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_department">
      <source>Department</source>
      <translation variants="no">Bộ phận</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_postal_codezip_code">
      <source>Postal code/ZIP code</source>
      <translation variants="no">Mã bưu điện/Zip</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_mobile_home">
      <source>Call Mobile (home)</source>
      <translation variants="no">Gọi di động (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_list_no_favorites_selected">
      <source>No favorites selected</source>
      <translation variants="no">Không có số liên lạc ưa thích</translation>
    </message>
    <message numerus="no" id="txt_phob_list_enter_your_name">
      <source>Enter your name</source>
      <translation variants="no">vi #Your name</translation>
    </message>
    <message numerus="no" id="txt_phob_info_keep_existing_map_location">
      <source>Keep existing location on Map </source>
      <translation variants="no">vi #Keep existing location on Map </translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_contact_1_saved">
      <source>Contact %1 created</source>
      <translation variants="no">Đã tạo số liên lạc %[21]1</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_import_contacts">
      <source>Import contacts</source>
      <translation variants="no">Nhập số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sync_with_ovi_contacts">
      <source>Sync with OVI contacts</source>
      <translation variants="no">Đang đồng bộ Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_url_home">
      <source>URL (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ web (nhà)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax">
      <source>Call Fax</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gửi fax</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_email_home">
      <source>Send mail (home)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gửi e-mail (nhà)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_home">
      <source>Delete Address (home)</source>
      <translation variants="no">Xóa địa chỉ (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone_work">
      <source>Delete Internet telephone (work)</source>
      <translation variants="no">Xóa đ.thoại net (c.việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address">
      <source>Delete Address</source>
      <translation variants="no">Xóa địa chỉ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone_home">
      <source>Call Phone (home)</source>
      <translation variants="no">Gọi điện thoại (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax">
      <source>Fax</source>
      <translation variants="no">Fax</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_send_to_homescreen_as_widget">
      <source>Send to homescreen</source>
      <translation variants="no">Thêm vào M.h.chính</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_edit_group_details">
      <source>Edit group details</source>
      <translation variants="no">Chỉnh sửa chi tiết nhóm</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_province">
      <source>Province</source>
      <translation variants="no">Tỉnh</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company">
      <source>Company</source>
      <translation variants="no">Công ty</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_internet_number">
      <source>Edit internet number</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa chi tiết điện thoại internet</lengthvariant>
        <lengthvariant priority="2">C.sửa chi tiết điện thoại internet</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_with_ovi_by_nokia_you_can_access_you">
      <source>With Ovi by Nokia you can access your favourite social networks and make your Contacts social. Sign in with your Nokia account to get started.</source>
      <translation variants="no">Với Ovi by Nokia, bạn có thể truy cập vào các mạng xã hội ưa thích và làm cho Danh bạ của bạn có tính xã hội. Đăng nhập vào tài khoản Nokia của bạn để bắt đầu.</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_address">
      <source>Add Address</source>
      <translation variants="no">Thêm dịa chỉ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_sign_in">
      <source>Sign in</source>
      <translation variants="no">Đăng nhập</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_home">
      <source>Delete URL (home)</source>
      <translation variants="no">Xóa địa chỉ web (nhà)</translation>
    </message>
    <message numerus="yes" id="txt_phob_dpophead_ln_contacts_linked">
      <source>%Ln contacts linked</source>
      <translation>
        <numerusform plurality="a">Đã liên kết %Ln số liên lạc</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_button_save_as_a_new_contact">
      <source>Save as a new contact</source>
      <translation variants="no">vi #Create new contact</translation>
    </message>
    <message numerus="no" id="txt_phob_button_delete_selected">
      <source>Delete selected</source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa</lengthvariant>
        <lengthvariant priority="2">Xóa nh. đ.chọn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_val_not_logged_in">
      <source>Not logged in</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chưa đăng nhập</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_birthday">
      <source>Birthday</source>
      <translation variants="yes">
        <lengthvariant priority="1">Sinh nhật</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_phone_number_for_1">
      <source>No phone number for %1</source>
      <translation variants="no">Chưa xác định số điện thoại cho %1</translation>
    </message>
    <message numerus="no" id="txt_phob_list_address2">
      <source>Address</source>
      <translation variants="yes">
        <lengthvariant priority="1">Địa chỉ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_mobile_home">
      <source>Delete Mobile (home)</source>
      <translation variants="no">Xóa di động (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email">
      <source>Delete Email</source>
      <translation variants="no">Xóa địa chỉ e-mail</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_email_work">
      <source>Delete Email (work)</source>
      <translation variants="no">Xóa địa chỉ e-mail (c.việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_info_importing_contacts_from_sim">
      <source>Importing contacts from SIM</source>
      <translation variants="no">Nhập số liên lạc từ SIM</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_address_work">
      <source>Delete Address (work)</source>
      <translation variants="no">Xóa địa chỉ (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_sip">
      <source>SIP</source>
      <translation variants="no">SIP</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_details">
      <source>Edit contact details</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa chi tiết số liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url_work">
      <source>Delete URL (work)</source>
      <translation variants="no">Xóa địa chỉ web (c.việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_1_group">
      <source>%1 group</source>
      <translation variants="no">Nhóm %1</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_fax_home">
      <source>Fax (home)</source>
      <translation variants="no">Fax (nhà)</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_internet_telephone">
      <source>Internet telephone</source>
      <translation variants="no">Điện thoại internet</translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_phone_number">
      <source>Edit phone number</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa số điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_assistant">
      <source>Assistant</source>
      <translation variants="no">Tên của người trợ lý</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_mobile_work">
      <source>Mobile (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Di động (công việc)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_call_mobile">
      <source>Call mobile</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gọi di động</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_car">
      <source>Car</source>
      <translation variants="no">Điện thoại trên xe</translation>
    </message>
    <message numerus="no" id="txt_phob_info_delete_1">
      <source>Delete %1?</source>
      <translation variants="no">Xóa
%[79]1?</translation>
    </message>
    <message numerus="no" id="txt_phob_title_add_field">
      <source>Add detail</source>
      <translation variants="yes">
        <lengthvariant priority="1">Thêm chi tiết</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_company_details">
      <source>Company Details</source>
      <translation variants="no">Chi tiết công ty</translation>
    </message>
    <message numerus="no" id="txt_phob_list_add_phone_number">
      <source>Phone number</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số điện thoại</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_subtitle_edit_contact_name">
      <source>Edit name</source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa tên liên lạc</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_fax_work">
      <source>Call Fax (work)</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gửi fax (công việc)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_group">
      <source>Delete group</source>
      <translation variants="no">Xóa nhóm</translation>
    </message>
    <message numerus="no" id="txt_phob_dpophead_ln_contacts_imported">
      <source>%L1 / %L2 contacts imported</source>
      <translation variants="no">Đã nhập %L1/%L2 số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_spouse">
      <source>Spouse</source>
      <translation variants="no">Vợ/chồng</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_anniversary">
      <source>Anniversary</source>
      <translation variants="no">Ngày kỷ niệm</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_new_contact">
      <source>New contact</source>
      <translation variants="no">Số liên lạc mới</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_name_display_order_val_first_nam">
      <source>First name Last name</source>
      <translation variants="no">Tên Họ</translation>
    </message>
    <message numerus="no" id="txt_phob_button_select_location">
      <source>Select location</source>
      <translation variants="no">vi #Select location</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_phone">
      <source>Call Phone</source>
      <translation variants="no">Gọi điện thoại</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_import_from_ovi_val_transfer_via_b">
      <source>Transfer via bluetooth</source>
      <translation variants="yes">
        <lengthvariant priority="1">Gửi qua Bluetooth</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_title_address_changed">
      <source>Address changed</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Address changed</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_favorites_selected_select_your_p">
      <source>No favorites selected, select your preferrred contacts</source>
      <translation variants="no">Chưa đánh dấu số liên lạc ưa thích. Thêm số liên lạc ưa thích của bạn vào số liên lạc ưa thích.</translation>
    </message>
    <message numerus="no" id="txt_phob_button_update_existing_contact">
      <source>Update existing contact</source>
      <translation variants="no">vi #Update existing contact</translation>
    </message>
    <message numerus="no" id="txt_phob_button_close">
      <source>Close</source>
      <translation variants="yes">
        <lengthvariant priority="1">Đóng</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_list_message">
      <source>Message</source>
      <translation variants="yes">
        <lengthvariant priority="1">Qua tin nhắn</lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_phob_title_l1_matches_found">
      <source>%Ln Matches found</source>
      <translation>
        <numerusform plurality="a">Tìm thấy %Ln phù hợp</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_url">
      <source>Add Url</source>
      <translation variants="no">Thêm địa chỉ web</translation>
    </message>
    <message numerus="no" id="txt_phob_info_sim_card_error">
      <source>SIM card error </source>
      <translation variants="no">Lỗi thẻ SIM</translation>
    </message>
    <message numerus="no" id="txt_phob_setlabel_show_val_name_only">
      <source>Name only</source>
      <translation variants="no">Chỉ tên</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_address_work">
      <source>Address (work)</source>
      <translation variants="no">Địa chỉ (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_add_url">
      <source>Add URL</source>
      <translation variants="no">Thêm địa chỉ web</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_url">
      <source>Delete URL</source>
      <translation variants="no">Xóa địa chỉ web</translation>
    </message>
    <message numerus="no" id="txt_phob_list_all_contacts">
      <source>All contacts</source>
      <translation variants="no">Tất cả số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_services_activated">
      <source>No services activated.</source>
      <translation variants="no">Chưa kích hoạt dịch vụ</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_internet_telephone">
      <source>Delete Internet telephone</source>
      <translation variants="no">Xóa điện thoại internet</translation>
    </message>
    <message numerus="no" id="txt_phob_info_no_services_activated_would_you_lik">
      <source>No services activated, would you like to do it now?</source>
      <translation variants="no">Chưa kích hoạt dịch vụ. Kích hoạt ngay bây giờ?</translation>
    </message>
    <message numerus="no" id="txt_phob_opt_add_note">
      <source>Add note</source>
      <translation variants="no">vi #Add note</translation>
    </message>
    <message numerus="no" id="txt_phob_list_search_results">
      <source>Show results</source>
      <translation variants="no">vi #Show results</translation>
    </message>
    <message numerus="no" id="txt_phob_formlabel_val_email_work">
      <source>Email (work)</source>
      <translation variants="no">Địa chỉ e-mail (công việc)</translation>
    </message>
    <message numerus="no" id="txt_phob_dblist_assistant">
      <source>Assistant</source>
      <translation variants="yes">
        <lengthvariant priority="1">Số của người trợ lý</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_phob_menu_call_car_phone">
      <source>Call Car phone</source>
      <translation variants="no">Gọi điện thoại trên xe</translation>
    </message>
    <message numerus="no" id="txt_phob_list_creating_1_group">
      <source>Creating %1 group</source>
      <translation variants="no">Đg tạo nhóm %1</translation>
    </message>
    <message numerus="no" id="txt_phob_menu_delete_anniversary">
      <source>Delete Anniversary</source>
      <translation variants="no">Xóa ngày kỷ niệm</translation>
    </message>
  </context>
</TS>