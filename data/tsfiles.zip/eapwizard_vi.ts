<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_confirm_password">
      <source>Confirm password:</source>
      <translation variants="no">Xác minh mật khẩu:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_no_certificates_installed_wizard_c">
      <source>No certificates installed. Wizard cannot continue.</source>
      <translation variants="no">Chưa cài đặt chứng chỉ. Không thể tiếp tục thiết lập.</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_provisioning_mode_for_eapfast">
      <source>EAP-FAST provisioning mode</source>
      <translation variants="no">Chế độ cung cấp EAP-FAST:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_realm">
      <source>Realm:</source>
      <translation variants="no">Địa hạt:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_new_pac_store_password">
      <source>New PAC store password:</source>
      <translation variants="no">Mật khẩu lưu trữ PAC mới:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_for_1">
      <source>User name for '%1':</source>
      <translation variants="no">Tên người dùng cho '%[85]1':</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_generate_automatic">
      <source>Generate automatically</source>
      <translation variants="no">Phát tự động</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_authority_certificate">
      <source>Select authority certificate:</source>
      <translation variants="no">Chọn chứng chỉ ủy quyền:</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_user_certificate">
      <source>Select user certificate:</source>
      <translation variants="no">Chọn chứng chỉ cá nhân:</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_inner_eap">
      <source>Inner EAP</source>
      <translation variants="no">EAP nội bộ:</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_innear_eap_type_for_1">
      <source>Select inner EAP type for '%1':</source>
      <translation variants="no">Chọn loại EAP nội bộ cho '%[82]1':</translation>
    </message>
    <message numerus="no" id="txt_occ_info_incorrect_password">
      <source>Incorrect password</source>
      <translation variants="no">Mật khẩu sai</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_select_automatically">
      <source>Select automatically</source>
      <translation variants="no">Chọn tự động</translation>
    </message>
    <message numerus="no" id="txt_occ_title_select_eap_type">
      <source>Select EAP type:</source>
      <translation variants="no">Chọn loại EAP:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_pac_store_password">
      <source>PAC store password:</source>
      <translation variants="no">Mật khẩu lưu trữ PAC:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_cipher_su">
      <source>%1 authentication failed. Cipher suite mismatch.</source>
      <translation variants="no">Không xác thực %[76]1 được. Bộ mật mã không khớp.</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_auth_failed_user_cert_rej">
      <source>%1 authentication failed. User certificate not accepted.</source>
      <translation variants="no">Không xác thực %[60]1 được. Chứng chỉ cá nhân không được chấp nhận.</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_server_ce">
      <source>%1 authentication failed. Server certificate has expired.</source>
      <translation variants="no">Không xác thực %[70]1 được. Chứng chỉ máy chủ đã hết hạn.</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_realm_val_generate_automatic">
      <source>Generate automatically</source>
      <translation variants="no">Phát tự động</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_auth_failed_user_cert_exp">
      <source>%1 authentication failed. User certificate has expired.</source>
      <translation variants="no">Không xác thực %[70]1 được. Chứng chỉ cá nhân đã hết hạn.</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_check_sim">
      <source>%1 authentication failed. Check SIM card.</source>
      <translation variants="no">Không xác thực %[86]1 được. Kiểm tra thẻ SIM.</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_reset_pac">
      <source>%1 authentication failed. Reset PAC store.</source>
      <translation variants="no">Không xác thực %[87]1 được. Xóa lưu trữ PAC.</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed_could_not">
      <source>%1 authentication failed. Could not verify server certificate.</source>
      <translation variants="no">Không xác thực %[67]1 được. Không thể xác minh chứng chỉ máy chủ.</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_provisioning_mode_for_val_unauthent">
      <source>Unauthenticated</source>
      <translation variants="no">Chưa được xác thực</translation>
    </message>
    <message numerus="no" id="txt_occ_dblist_outer_eap">
      <source>Outer EAP</source>
      <translation variants="no">EAP ngoại vi:</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_eap_password">
      <source>Password:</source>
      <translation variants="no">Mật khẩu:</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_1_authentication_failed">
      <source>%1 authentication failed</source>
      <translation variants="no">Không xác thực %[99]1 được</translation>
    </message>
  </context>
</TS>