<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dblist_network_settings">
      <source>Network settings</source>
      <translation variants="no">Cài đặt mạng</translation>
    </message>
  </context>
</TS>