<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_messaging_opt_attach_sub_others">
      <source>Not specified</source>
      <translation variants="no">vi #Other</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receive_service_messages">
      <source>Not specified</source>
      <translation variants="no">vi #Receive service messages</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_enter_message_here">
      <source>Enter message here </source>
      <translation variants="no">Nhập văn bản</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_message_centre_number">
      <source>Message centre number </source>
      <translation variants="no">Số trung tâm tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_contacts_sub_add_to_exi">
      <source>Add to Existing </source>
      <translation variants="no">Cập nhật hện tại</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_from">
      <source>Not specified</source>
      <translation variants="no">vi #From:</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_clear_conversation">
      <source>Not specified</source>
      <translation variants="no">vi #Remove messages</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_download">
      <source>Download</source>
      <translation variants="no">Tải về</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_message">
      <source>Allow anonymous MMS messages </source>
      <translation variants="no">Tin nhắn đa ph.tiện vô danh</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_retrieval">
      <source>MMS retrieval </source>
      <translation variants="no">Tải tin nhắn đa phương tiện</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_update">
      <source>Update </source>
      <translation variants="no">Chỉnh sửa</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_sms_message_centre_in_use">
      <source>SMS message centre in use </source>
      <translation variants="no">Trung tập tin nhắn văn bản</translation>
    </message>
    <message numerus="no" id="txt_common_opt_ln_new_messages">
      <source>%Ln New Messages </source>
      <translation variants="no">vi #%Ln new message</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_sound">
      <source>Sound</source>
      <translation variants="no">Tập tin âm thanh</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_new_sms_message_centre">
      <source>New  SMS message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">Trung tâm tin nhắn văn bản mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_contacts_sub_create_new">
      <source>Create New </source>
      <translation variants="no">Tạo mới</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_remove_attachment">
      <source>Remove attachment</source>
      <translation variants="no">vi #Remove attachment</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_add_to_bookmarks">
      <source>Add to bookmarks</source>
      <translation variants="no">Lưu vào bookmark</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority_sub_low">
      <source>Not specified</source>
      <translation variants="no">vi #Low</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_others">
      <source>Not specified</source>
      <translation variants="no">vi #Other</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_play_message">
      <source>Not specified</source>
      <translation variants="no">vi #Play</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_full_screen">
      <source>Full screen </source>
      <translation variants="no">Toàn màn hình</translation>
    </message>
    <message numerus="yes" id="txt_messaging_group_title_ln_other_recipients">
      <source>%Ln Other recipients</source>
      <translation>
        <numerusform plurality="a">vi #%Ln other recipient</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_advanced">
      <source>Advanced</source>
      <translation variants="no">Cài đặt nâng cao</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_delivery_reports">
      <source>Delivery reports</source>
      <translation variants="no">Báo kết quả</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_location">
      <source>Not specified</source>
      <translation variants="no">vi #Location</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_subject">
      <source>Subject:</source>
      <translation variants="no">Chủ đề:</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_on">
      <source>On</source>
      <translation variants="no">Bật</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_creation_mode">
      <source>MMS creation mode </source>
      <translation variants="no">Chế độ tạo t.hắn đa ph.tiện</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority_sub_high">
      <source>Not specified</source>
      <translation variants="no">vi #High</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_ln">
      <source>(%Ln )</source>
      <translation variants="no">vi #(%Ln)</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_messaging">
      <source>Messaging</source>
      <translation variants="yes">
        <lengthvariant priority="1">Nhắn tin</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_edit_sms_message_centre">
      <source>Edit SMS message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">Chỉnh sửa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_sms_email_settings">
      <source>Not specified</source>
      <translation variants="no">vi #SMS mail settings</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_free">
      <source>Free</source>
      <translation variants="no">Không hạn chế</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_add_new">
      <source>Add New </source>
      <translation variants="yes">
        <lengthvariant priority="1">Trung tâm tin nhắn mới</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_mannual">
      <source>Mannual</source>
      <translation variants="no">Thủ công</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_type_changed_to_tex">
      <source>Message type changed to text message</source>
      <translation variants="no">Đã đổi loại tin nhắn thành tin nhắn văn bản</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_character_encoding">
      <source>Character encoding </source>
      <translation variants="no">Mã hóa ký tự</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_auto_home_network">
      <source>Automatic in home network </source>
      <translation variants="no">Tự động trong mạng chủ</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_settings">
      <source>Settings</source>
      <translation variants="no">Cài đặt</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_advanced_settings_messaging">
      <source>Advanced settings : Messaging </source>
      <translation variants="no">Cài đặt nâng cao</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_guided">
      <source>Guided</source>
      <translation variants="no">Hướng dẫn</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_always_automatic">
      <source>Always automatic </source>
      <translation variants="no">Luôn bật</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_open_contact_info">
      <source>Open contact info </source>
      <translation variants="no">Chi tiết số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority_sub_normal">
      <source>Not specified</source>
      <translation variants="no">vi #Normal</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_type_changed_to_mul">
      <source>Message type changed to multimedia </source>
      <translation variants="no">Đã đổi loại tin nhắn thành tin nhắn đa phương tiện</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_sms_message_centre_settings">
      <source>SMS message centre settings </source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt trung tâm tin nhắn văn bản</lengthvariant>
        <lengthvariant priority="2">Cài đặt t.tâm t.nhắn văn bản</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_val_yes">
      <source>Yes</source>
      <translation variants="no">Được phép</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_cc">
      <source>Cc:</source>
      <translation variants="no">Cc:</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_full_support">
      <source>Full support </source>
      <translation variants="no">Hỗ trợ hoàn toàn</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_subject">
      <source>Not specified</source>
      <translation variants="no">vi #Add Subject field</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_contacts">
      <source>Save to Contacts</source>
      <translation variants="no">Lưu vào Danh bạ</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_bcc">
      <source>Bcc: </source>
      <translation variants="no">Bcc:</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_mms_access_point_in_use">
      <source>MMS access point in use </source>
      <translation variants="no">Điểm t.cập t.nhắn đa ph.tiện</translation>
    </message>
    <message numerus="no" id="txt_long_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">Nhắn tin</translation>
    </message>
    <message numerus="no" id="txt_short_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">vi #Messaging</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_messaging_settings">
      <source>Messaging settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Messaging settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receiving_service_messages">
      <source>Receiving service messages</source>
      <translation variants="no">vi #Receiving service messages</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">vi #Messaging</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_conversations">
      <source>Conversations</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Conversations</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_conversations">
      <source>Conversations</source>
      <translation variants="no">vi #Conversations</translation>
    </message>
    <message numerus="no" id="txt_conversations_dialog_save_ringing_tone">
      <source>Save ringing tone ?</source>
      <translation variants="no">vi #Save ringing tone ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_delete_all">
      <source>Delete all </source>
      <translation variants="no">vi #Delete all </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_received_files">
      <source>Received files</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Received files</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_time">
      <source>&lt;time&gt;</source>
      <translation variants="no">vi #&lt;time&gt;</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_delete_message">
      <source>Delete message</source>
      <translation variants="no">Xóa tin nhắn</translation>
    </message>
    <message numerus="yes" id="txt_messaging_dpophead_ln_outgoing_messages">
      <source>%Ln Outgoing messages </source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_outgoing_message">
      <source>Outgoing message </source>
      <translation variants="yes">
        <lengthvariant priority="1">Đang gửi tin nhắn</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add">
      <source>Add   </source>
      <translation variants="no">Thêm</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_sound">
      <source>Sound </source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Sound </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_cc">
      <source>Cc:</source>
      <translation variants="no">Cc:</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_business_card">
      <source>Business Card </source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Business Card </lengthvariant>
      </translation>
    </message>
    <message numerus="yes" id="txt_messaging_list_ln_new_messages">
      <source>%Ln New Messages </source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_deleting_will_remove_some_mul">
      <source>Deleting will remove some multimedia messages displayed in other conversations too. Delete conversation?</source>
      <translation variants="no">vi #Deleting will remove some multimedia messages displayed in other conversations too. Delete conversation?</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">vi #Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_business_card">
      <source>Ringing tone</source>
      <translation variants="no">vi #Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">vi #Unsupported message type</translation>
    </message>
    <message numerus="yes" id="txt_messaging_dpophead_ln_failed_messages">
      <source>%Ln Failed messages </source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority_val_normal">
      <source>Normal </source>
      <translation variants="no">Bình thường</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_new_message">
      <source>New Message </source>
      <translation variants="no">vi #New Message </translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_save_to_landmarks">
      <source>Save to landmarks</source>
      <translation variants="no">Lưu vào Cột mốc</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_message_centre">
      <source>Delete message centre?</source>
      <translation variants="no">vi #Delete message centre?</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_loading">
      <source>Loading...</source>
      <translation variants="no">vi #Loading...</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_add_more_recipien">
      <source>Unable to add more recipients. Maximum limit exceeded</source>
      <translation variants="no">vi #Unable to add more recipients. Maximum limit exceeded</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_re">
      <source>RE: </source>
      <translation variants="no">vi #RE: </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_slide_l1l2">
      <source>Slide %L1/%L2</source>
      <translation variants="no">vi #Slide %L1/%L2</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_unknown_bluetooth_device">
      <source>Unknown Bluetooth Device </source>
      <translation variants="no">vi #Unknown Bluetooth Device </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_receive_read_report">
      <source>Receive read report </source>
      <translation variants="no">Nhận báo đã đọc</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_conversation_deleted">
      <source>Conversation Deleted</source>
      <translation variants="no">Đã xóa cuộc trò chuyện</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_deleted">
      <source>Message deleted </source>
      <translation variants="no">Đã xóa tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_delivered_date_time">
      <source>(Delivered &lt;date&gt; &lt;time&gt;) </source>
      <translation variants="no">vi #(Delivered &lt;date&gt; &lt;time&gt;) </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority_val_high">
      <source>High </source>
      <translation variants="no">Cao</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_l1">
      <source>(%L1)</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #(%L1)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_photo">
      <source>Photo </source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Photo </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_priority">
      <source>Priority</source>
      <translation variants="no">vi #Priority</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_message_centre_does_not_e">
      <source>SMS Message centre does not exist. Create New  ?</source>
      <translation variants="no">vi #SMS Message centre does not exist. Create New  ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_message_centre_saved">
      <source>Message centre saved</source>
      <translation variants="no">vi #Message centre saved</translation>
    </message>
    <message numerus="no" id="txt_conversations_list_message_cannot_be_shown_exa">
      <source>Message cannot be shown exactly as the sender intended. Open to see included objects</source>
      <translation variants="no">vi #Message cannot be shown exactly as the sender intended. Open to see included objects</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_unable_to_delete_conversation">
      <source>Unable to delete conversation as it contains messages being sent. Try again later.  </source>
      <translation variants="no">vi #Unable to delete conversation as it contains messages being sent. Try again later.  </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_advertisement">
      <source>Advertisement</source>
      <translation variants="no">vi #Advertisement</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_class">
      <source>Class: </source>
      <translation variants="no">vi #Class: </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_personal">
      <source>Personal</source>
      <translation variants="no">vi #Personal</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_video">
      <source>Video </source>
      <translation variants="no">vi #Video </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority_val_low">
      <source>Low </source>
      <translation variants="no">Thấp</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_l1_of_l2">
      <source>Unable to attach %L1 of %L2 items ! Maximum size exceeded  </source>
      <translation variants="no">vi #Unable to attach %L1 of %L2 items ! Maximum size exceeded  </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_receive_delivery_report">
      <source>Receive delivery report</source>
      <translation variants="no">Nhận báo kết quả</translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_bcc">
      <source>Bcc:</source>
      <translation variants="no">Bcc:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_message_date">
      <source>&lt;message date&gt;</source>
      <translation variants="no">vi #&lt;message date&gt;</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_subject">
      <source>Subject</source>
      <translation variants="no">Chủ đề</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_recipients">
      <source>Add recipients</source>
      <translation variants="no">vi #Add recipients</translation>
    </message>
    <message numerus="no" id="txt_conversations_list_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">vi #Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_high">
      <source>High </source>
      <translation variants="no">vi #High </translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_ringing_tone">
      <source>Ringing tone</source>
      <translation variants="no">vi #Ringing tone</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delate_all_drafts">
      <source>Delate all drafts ?</source>
      <translation variants="no">vi #Delate all drafts ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_fwd">
      <source>FWD: </source>
      <translation variants="no">vi #FWD: </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_drafts">
      <source>Drafts</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Drafts</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_wireframe_list_multimedia_message_waiting">
      <source>Multimedia message waiting...</source>
      <translation variants="no">vi #Multimedia message waiting...</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_character_count_exceeded">
      <source>SMS character count exceeded. Convert to multimedia message?</source>
      <translation variants="no">Đã vượt quá số ký tự t.đa. Ch.sang t.nhắn đ.ph.tiện?</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_open_link">
      <source>Open link</source>
      <translation variants="no">Mở liên kết</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_more">
      <source>More...</source>
      <translation variants="no">Khác</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_message_sending_failed">
      <source>Message sending failed </source>
      <translation variants="yes">
        <lengthvariant priority="1">Không gửi tin nhắn được</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_item_file">
      <source>Unable to attach item! File type not supported </source>
      <translation variants="no">Ko thể thêm phần đ.kèm. Loại t.tin ko được hỗ trợ.</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_normal">
      <source>Normal </source>
      <translation variants="no">vi #Normal </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_other_recipients">
      <source>Other recipients</source>
      <translation variants="no">vi #Other recipients</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_low">
      <source>Low </source>
      <translation variants="no">vi #Low </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_resend_at_time">
      <source>Resend at &lt;time&gt;</source>
      <translation variants="no">vi #Resend at &lt;time&gt;</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_saved_to_drafts">
      <source>Saved to drafts</source>
      <translation variants="no">vi #Saved to drafts</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_size">
      <source>Size:  </source>
      <translation variants="no">vi #Size:  </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_cc_bcc">
      <source>Cc / Bcc</source>
      <translation variants="no">vi #Cc / Bcc</translation>
    </message>
    <message numerus="no" id="txt_messaging_title_sending_options_for_this_messa">
      <source>Sending Options for this message</source>
      <translation variants="no">Tùy chọn gửi cho tin nhắn này</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_message_time">
      <source>&lt;message time&gt;</source>
      <translation variants="no">vi #&lt;message time&gt;</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_business_card">
      <source>Business Card </source>
      <translation variants="no">Danh thiếp</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_date_time">
      <source>&lt;date&gt; &lt;time&gt;</source>
      <translation variants="no">vi #&lt;date&gt; &lt;time&gt;</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_same_message_exists_in_multip">
      <source>Same message exists in multiple conversations. Delete all ? </source>
      <translation variants="no">vi #Same message exists in multiple conversations. Delete all ? </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_attached_photo_size_is_l1">
      <source>Attached photo size is %L1 * %L2 pixels  </source>
      <translation variants="no">vi #Attached photo size is %L1 * %L2 pixels  </translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_add_more_content">
      <source>Unable to add more content. Maximum size exceeded</source>
      <translation variants="no">vi #Unable to add more content. Maximum size exceeded</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_listview_resend_at_time">
      <source>Resend at &lt;time&gt;</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Resend at &lt;time&gt;</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_forward">
      <source>Forward</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Forward</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_listview_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Unsupported message type</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_all_drafts">
      <source>Delete all drafts ?</source>
      <translation variants="no">vi #Delete all drafts ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">vi #Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_pending">
      <source>(Pending)</source>
      <translation variants="no">(đang chờ xử lý)</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sending_options">
      <source>Sending options </source>
      <translation variants="no">Tùy chọn gửi</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_conversation">
      <source>Delete Conversation ? </source>
      <translation variants="no">Xóa cuộc trò chuyện?</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_copy_link">
      <source>Copy link</source>
      <translation variants="no">Sao chép liên kết</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_attach">
      <source>Attach</source>
      <translation variants="no">Thêm phần đính kèm</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_priority">
      <source>Priority</source>
      <translation variants="no">Ưu tiên</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_ringing_tone">
      <source>Ringing tone </source>
      <translation variants="no">vi #Ringing tone </translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_number_of_recipients_exceeded">
      <source>Number of recipients exceeded.Convert to multimedia message ? </source>
      <translation variants="no">Đã v.quá sô n.nhận tối đa. Ch.sang t.nhắn đ.ph.tiện?</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_merge_contacts">
      <source>Merge Contacts </source>
      <translation variants="no">Kết hợp các số liên lạc</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_to">
      <source>To: </source>
      <translation variants="no">Đến:</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_allow_anonymous_mms_val_no">
      <source>No</source>
      <translation variants="no">Không được phép</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach">
      <source>Attach</source>
      <translation variants="no">Thêm phần đính kèm</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_email_service_centre_numbe">
      <source>Not specified</source>
      <translation variants="no">vi #Mail message centre number</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_reduced_support">
      <source>Reduced support </source>
      <translation variants="no">Hỗ trợ một phần</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_video">
      <source>Video</source>
      <translation variants="no">Video clip</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_cc_bcc">
      <source>Not specified</source>
      <translation variants="no">vi #Add Cc and Bcc fields</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_note_as_attachment">
      <source>Not specified</source>
      <translation variants="no">vi #Note (as attachment)</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_business_card">
      <source>Business card</source>
      <translation variants="no">vi #Business card</translation>
    </message>
    <message numerus="no" id="txt_messaging_button_drafts">
      <source>Drafts</source>
      <translation variants="no">vi #Drafts</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_sub_recipients">
      <source>Recipients</source>
      <translation variants="no">Người nhận</translation>
    </message>
    <message numerus="no" id="txt_messaging_viewer_formlabel_to">
      <source>To:  </source>
      <translation variants="no">Đến:</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_sending_failed">
      <source>Sending Failed</source>
      <translation variants="no">vi #Sending Failed</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_informational">
      <source>Informational</source>
      <translation variants="no">vi #Informational</translation>
    </message>
    <message numerus="no" id="txt_task_switcher_caption_messaging">
      <source>Messaging</source>
      <translation variants="no">vi #Messaging</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_mms_access_point_not_defined">
      <source>MMS Access point not defined. Define now  ?</source>
      <translation variants="no">vi #MMS Access point not defined. Define now  ?</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_create_mail">
      <source>Create mail </source>
      <translation variants="no">Tạo e-mail</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_sms_character_count_excee">
      <source>SMS character count exceeded. Convert to multimedia message ? </source>
      <translation variants="no">Quá nhiều ký tự. Chuyển sang tin nhắn đa phương tiện?</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unsupported_message_type">
      <source>Unsupported message type</source>
      <translation variants="no">vi #Unsupported message type</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_received_files">
      <source>Received files </source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Received files </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_send_selected_item">
      <source>Send selected item </source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Send selected item </lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_delete_conversation">
      <source>Delete Conversation</source>
      <translation variants="no">Xóa cuộc trò chuyện</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_email_gateway">
      <source>Not specified</source>
      <translation variants="no">vi #Mail gateway</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_restricted">
      <source>Restricted </source>
      <translation variants="no">Bị hạn chế</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_business_card">
      <source>Business card </source>
      <translation variants="no">vi #Business card</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_receive_mms_adverts">
      <source>Receive MMS adverts </source>
      <translation variants="no">Nhận tin quảng cáo</translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_messaging_subhead_mms_settings">
      <source>MMS settings </source>
      <translation variants="yes">
        <lengthvariant priority="1">Cài đặt tin nhắn đa phương tiện</lengthvariant>
        <lengthvariant priority="2">Cài đặt tin nhắn đa ph.tiện</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_delete_message_centre">
      <source>Delete message centre </source>
      <translation variants="yes">
        <lengthvariant priority="1">Xóa</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_title_select_attachment_type">
      <source>Select attachment type</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Select attachment type:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_add_priority">
      <source>Not specified</source>
      <translation variants="no">vi #Message priority</translation>
    </message>
    <message numerus="no" id="txt_messaging_opt_attach_sub_photo">
      <source>Photo</source>
      <translation variants="no">Hình ảnh</translation>
    </message>
    <message numerus="no" id="txt_conversations_list_1_2">
      <source>%1 %2</source>
      <translation variants="no">vi #%1 %2</translation>
    </message>
    <message numerus="yes" id="txt_messaging_title_ln_other_recipients">
      <source>%Ln Other recipients</source>
      <translation>
        <numerusform plurality="a">vi #MISSING</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_val_manual">
      <source>Manual</source>
      <translation variants="no">vi #Manual</translation>
    </message>
    <message numerus="no" id="txt_messaging_menu_contact_info">
      <source>Contact info </source>
      <translation variants="no">vi #Contact info </translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_message_cannot_be_shown_ex">
      <source>Message cannot be shown exactly as the sender intended. Included objects shown as attachments:</source>
      <translation variants="no">vi #Message cannot be shown exactly as the sender intended. Included objects shown as attachments:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_expiry_date">
      <source>Expiry date: </source>
      <translation variants="no">vi #Expiry date: </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_resend_at_time">
      <source>Resend at &lt;time&gt;</source>
      <translation variants="no">vi #Resend at &lt;time&gt;</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_from">
      <source>From:</source>
      <translation variants="no">Từ:</translation>
    </message>
    <message numerus="no" id="txt_messaging_list_calendar_event">
      <source>Calendar event </source>
      <translation variants="no">vi #Calendar event </translation>
    </message>
    <message numerus="no" id="txt_messaging_button_more">
      <source>More...</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #More...</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_list_attach_to_new_message">
      <source>Attach to new message</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Attach to new message</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_messaging_setlabel_message_centre_name">
      <source>Message centre name </source>
      <translation variants="no">Tên trung tâm tin nhắn</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_message_sending_failed">
      <source>Message Sending failed !</source>
      <translation variants="no">vi #Message Sending failed !</translation>
    </message>
    <message numerus="no" id="txt_messaging_formlabel_delivery_failed">
      <source>(Delivery Failed !)</source>
      <translation variants="no">(không gửi được)</translation>
    </message>
    <message numerus="no" id="txt_messaging_dialog_delete_message">
      <source>Delete message ? </source>
      <translation variants="no">Xóa tin nhắn?</translation>
    </message>
    <message numerus="no" id="txt_messaging_dpopinfo_unable_to_attach_item_avai">
      <source>Unable to attach item! Available space is %L1kb</source>
      <translation variants="no">vi #Unable to attach item! Available space is %L1kb</translation>
    </message>
  </context>
</TS>