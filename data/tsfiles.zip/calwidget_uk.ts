<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_l1_events">
      <source>L%1 events overlapping</source>
      <translation variants="no">uk #L%1 overlapping calendar entries</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_no_events_ox">
      <source>No events in next 7 days</source>
      <translation variants="no">uk #No calendar entries today or for next 7 days</translation>
    </message>
    <message numerus="no" id="txt_short_caption_calendar_widget">
      <source>Calendar widget</source>
      <translation variants="no">uk #Calendar</translation>
    </message>
    <message numerus="no" id="txt_long_caption_calendar_widget">
      <source>Calendar widget</source>
      <translation variants="no">uk #Calendar</translation>
    </message>
    <message numerus="no" id="txt_calendar_widget_v_dblist_val_no_events_tod">
      <source>No events today</source>
      <translation variants="no">uk #No calendar entries today</translation>
    </message>
  </context>
</TS>