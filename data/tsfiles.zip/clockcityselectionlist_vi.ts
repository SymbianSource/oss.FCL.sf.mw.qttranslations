<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_clock_formlabel_city_name">
      <source>City name</source>
      <translation variants="yes">
        <lengthvariant priority="1">Tên thành phố</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_timezone">
      <source>Timezone</source>
      <translation variants="yes">
        <lengthvariant priority="1">Múi giờ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_formlabel_country">
      <source>Country</source>
      <translation variants="yes">
        <lengthvariant priority="1">Quốc gia/Khu vực</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clock_subhead_city_list">
      <source>City list</source>
      <translation variants="yes">
        <lengthvariant priority="1">Danh sách thành phố</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_clk_opt_add_own_city">
      <source>Add own city</source>
      <translation variants="no">Thêm thành phố</translation>
    </message>
    <message numerus="no" id="txt_clock_title_clock">
      <source>Clock</source>
      <translation variants="yes">
        <lengthvariant priority="1">vi #Clock</lengthvariant>
      </translation>
    </message>
  </context>
</TS>