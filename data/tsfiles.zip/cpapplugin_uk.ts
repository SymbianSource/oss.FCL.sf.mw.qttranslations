<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="uk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_setlabel_user_name_val_none">
      <source>None</source>
      <translation variants="no">uk #None</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password_val_none">
      <source>None</source>
      <translation variants="no">uk #None</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password_val_prompt">
      <source>Prompt</source>
      <translation variants="no">uk #Prompt</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ip_settings">
      <source>IP settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #IP settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ipv6_settings">
      <source>IPv6 settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #IPv6 settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_ipv4_settings">
      <source>IPv4 settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">uk #IPv4 settings</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_user_name">
      <source>User name</source>
      <translation variants="no">uk #User name</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_primary_name_server">
      <source>Primary name server</source>
      <translation variants="no">Основна адреса DNS</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_secondary_name_server">
      <source>Secondary name server</source>
      <translation variants="no">Додаткова адреса DNS</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_secondary_name_server_val_automat">
      <source>Automatic</source>
      <translation variants="no">Автоматично</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_port_number_val_not_define">
      <source>(not defined)</source>
      <translation variants="no">(не визначено)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_subnet_mask_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">(не визначено)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status_val_hidden">
      <source>Hidden</source>
      <translation variants="no">Прихована</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_open">
      <source>Open</source>
      <translation variants="no">Відкрити</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_primary_name_server_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Автоматично</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_homepage_val_none">
      <source>None</source>
      <translation variants="no">uk #None</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode">
      <source>WLAN network mode</source>
      <translation variants="no">Режим WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_base_station_val_stay_in_fir">
      <source>Stay in first</source>
      <translation variants="no">Викор. першу знайдену</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode_val_infrastruct">
      <source>Infrastructure</source>
      <translation variants="no">Інфраструктура</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_default_gateway_val_not_defined">
      <source>(not defined)</source>
      <translation variants="no">(не визначено)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wapi">
      <source>WAPI</source>
      <translation variants="no">WAPI</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpawpa2">
      <source>WPA/WPA2</source>
      <translation variants="no">WPA/WPA2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Автоматично</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_name">
      <source>WLAN network name</source>
      <translation variants="no">Назва мережі WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_wellknown">
      <source>Well-known</source>
      <translation variants="no">Звичні</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_proxy_settings">
      <source>Proxy settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки проксі-сервера</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name_val_vpn">
      <source>VPN</source>
      <translation variants="no">uk #VPN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_server_address">
      <source>Proxy server address</source>
      <translation variants="no">Адреса проксі-сервера</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_port_number">
      <source>Proxy port number</source>
      <translation variants="no">Номер порту проксі-сервера</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode">
      <source>WLAN security mode</source>
      <translation variants="no">Режим захисту WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_subnet_mask">
      <source>Subnet mask</source>
      <translation variants="no">Маска підмережі</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_base_station_selection">
      <source>WLAN base station selection</source>
      <translation variants="no">Вибір точки доступу WLAN</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_network_mode_val_adhoc">
      <source>Ad-hoc</source>
      <translation variants="no">Ad-hoc</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_adhoc_channel">
      <source>Ad-hoc channel</source>
      <translation variants="no">Канал Ad-hoc</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_base_station_val_roam_to_bes">
      <source>Roam to best</source>
      <translation variants="no">Шукати найкращу</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status">
      <source>Network status</source>
      <translation variants="no">Стан мережі</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_default_gateway">
      <source>Default gateway</source>
      <translation variants="no">Стандартний шлюз</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Автоматично</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wep">
      <source>WEP</source>
      <translation variants="no">WEP</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_homepage">
      <source>Homepage</source>
      <translation variants="no">Домашня сторінка</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses">
      <source>DNS addresses</source>
      <translation variants="no">Адреси DNS</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_proxy_server_address_val_not_def">
      <source>(not defined)</source>
      <translation variants="no">(не визначено)</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_password">
      <source>Password</source>
      <translation variants="no">uk #Password</translation>
    </message>
    <message numerus="no" id="txt_occ_opt_advanced_settings">
      <source>Advanced settings</source>
      <translation variants="no">uk #Advanced settings</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication_val_normal">
      <source>Normal</source>
      <translation variants="no">uk #Normal</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication_val_secure">
      <source>Secure</source>
      <translation variants="no">uk #Secure</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_authentication">
      <source>Authentication</source>
      <translation variants="no">uk #Authentication</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_phone_ip_address">
      <source>Phone IP address</source>
      <translation variants="no">IP-адреса телефону</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_network_status_val_public">
      <source>Public</source>
      <translation variants="no">Публічна</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_access_point_name">
      <source>Access point name</source>
      <translation variants="no">uk #Access point name</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name">
      <source>Connection name</source>
      <translation variants="no">Назва з’єднання</translation>
    </message>
    <message numerus="no" id="txt_occ_subhead_access_point_settings">
      <source>Access point settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">Установки точки доступу</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name_val_connection">
      <source>Connection</source>
      <translation variants="no">uk #Connection</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_adhoc_channel_val_automatic">
      <source>Automatic</source>
      <translation variants="no">Автоматично</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_wpa2_only">
      <source>WPA2 only</source>
      <translation variants="no">Лише WPA2</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_wlan_security_mode_val_8021x">
      <source>802.1X</source>
      <translation variants="no">802.1X</translation>
    </message>
    <message numerus="no" id="txt_occ_setlabel_dns_addresses_val_user_defined">
      <source>User defined</source>
      <translation variants="no">Визначає користувач</translation>
    </message>
  </context>
</TS>