<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_device_update_dblist_type">
      <source>Type</source>
      <translation variants="yes">
        <lengthvariant priority="1">قسم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_custom_version">
      <source>Custom version</source>
      <translation variants="yes">
        <lengthvariant priority="1">کسٹم ورژن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_popup_device_update">
      <source>Device Update</source>
      <translation variants="no">آلے کی تجدید</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_install_to_val_1_2_Mb">
      <source>%1: ( %L2) Mb</source>
      <translation variants="no">%[08]1: (%L2 م ب)</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_install_to">
      <source>Install to:</source>
      <translation variants="no">میں تنصیب کریں:</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_details_not_available">
      <source>Details not available</source>
      <translation variants="no">تفصیلات دستیاب نہیں</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading_of_1_Gb_failed">
      <source>Downloading of %1 %L2 Gb failed</source>
      <translation variants="no">%[55]1 (%L2 گ ب) کا ڈاؤن لوڈ ناکام</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_downloading_failed">
      <source>Downloading failed</source>
      <translation variants="no">ڈاؤن لوڈ ناکام</translation>
    </message>
    <message numerus="no" id="txt_device_update_dpophead_trust_established">
      <source>Trust Established with server %1</source>
      <translation variants="no">اعتبار قائم کیا گیا</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_server_id">
      <source>Server ID *</source>
      <translation variants="no">سرور ID*</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_language_set">
      <source>Language set</source>
      <translation variants="yes">
        <lengthvariant priority="1">زبان کا مجموعہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_1_2">
      <source>%1 %2</source>
      <translation variants="no">%[15]1 %2</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code">
      <source>Product code</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروڈکٹ کوڈ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_1_recommends_a_service_for">
      <source>%1 recommends a service for your phone. It requires connection to the internet.</source>
      <translation variants="no">%[16]1 نے آپ کے آلے کے لیے ایک خدمت کی سفارش کی ہے۔ انٹرنیٹ اتصال درکار ہے۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_1_server_wants_to_contro">
      <source>%1 server wants to control data on your device. Accept control?</source>
      <translation variants="no">%[28]1 سرور آپکے آلے پر ڈیٹا کنٹرول کرنا چاہتا ہے۔ کنٹرول قبول کریں؟</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_size_1_kb">
      <source>Size: %L1 Kb</source>
      <translation variants="no">سائز: %[62]1 ک ب</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_bt_mac_address">
      <source>BT MAC address </source>
      <translation variants="yes">
        <lengthvariant priority="1">BT MAC پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_device_memory_is_busy_try">
      <source>Device memory is busy.You will be notified once the installation can resume.</source>
      <translation variants="no">آلے کا حافظہ مصروف ہے۔ بعد میں تنصیب کی کوشش کریں۔</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__800BA">
      <source>800MHz on Band A</source>
      <translation variants="yes">
        <lengthvariant priority="1">بینڈ A پر ۸۰۰ میگاہٹرز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_unable_to_open_message_f">
      <source> "Unable to open. Message format not supported" </source>
      <translation variants="no">کھولنے سے قاصر۔ پیغام فارمیٹ کی تائید نہیں۔ اپنے خدمت کے فراہم کار سے رابطہ کریں۔</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val_unknown">
      <source>Band Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم بینڈ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_gprs">
      <source>GPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">GPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_Uninstallation_failed">
      <source>Unistallation/Removing failed</source>
      <translation variants="no">سافٹ ویئر کی تنصیب رد کرنے یا ہٹانے میں ناکام</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_Unknow">
      <source>Unknown</source>
      <translation variants="yes">
        <lengthvariant priority="1">نامعلوم</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_configuration_message">
      <source>Configuration Message  </source>
      <translation variants="yes">
        <lengthvariant priority="1">تشکیلاتی پیغام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_list_from_l2">
      <source>From: %2</source>
      <translation variants="no">سے: %2</translation>
    </message>
    <message numerus="no" id="txt_device_update_menu_set_as_default">
      <source>Set as default</source>
      <translation variants="no">بطور آغازی مرتب کریں</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_EGPRS">
      <source>EGPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">EGPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_WCDMA">
      <source>WCDMA</source>
      <translation variants="yes">
        <lengthvariant priority="1">WCDMA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_user_name">
      <source>User name*</source>
      <translation variants="no">صارف نام*</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__800BC">
      <source>800MHz on Band C</source>
      <translation variants="yes">
        <lengthvariant priority="1">بینڈ C پر ۸۰۰ میگاہٹرز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_your_phone_is_now_updated_w">
      <source>Your phone is now updated with the latest device software</source>
      <translation variants="no">تجدید کامیاب۔ اب آپ کے آلے میں جدید ترین سافٹ ویئر ہے۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_duplicate_server_id">
      <source>Duplicate server Id.
</source>
      <translation variants="no">سرور ID پہلے سے موجود</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_device_updates">
      <source>Device updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلے کی تجدید</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_update_incomplete_dwnld_kb">
      <source>The last update %1 (%2),%L3 kb was not completed. You can download it now </source>
      <translation variants="no">%[99]1 (%[99]2),%L3 ک ب گزشتہ نامکمل تجدید کے لیے اب ڈاؤن لوڈ دستیاب ہے۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_removing">
      <source>Uninstalling/Removing</source>
      <translation variants="no">تنصیب رد/ہٹائی جا رہی</translation>
    </message>
    <message numerus="no" id="txt_device_update_dpophead_device_update">
      <source>Device Update</source>
      <translation variants="no">آلے کی تجدید</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_device_updates_val_not_con">
      <source>Not configured</source>
      <translation variants="yes">
        <lengthvariant priority="1">تشکیل نہیں ہوئی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_verification_failed_and_mes">
      <source>Verification failed and message was deleted. Contact your service provider</source>
      <translation variants="no">تصدیق ناکام اور پیغام مٹا دیا گیا۔ اپنے خدمت کے فراہم کار سے رابطہ کریں۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_multimedia_access_pts">
      <source>Multimedia access pts</source>
      <translation variants="yes">
        <lengthvariant priority="1">ملٹیمیڈیا نقاط رسائی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_application_1">
      <source>Application: %1</source>
      <translation variants="no">پروگرام: %1</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_HSDPA">
      <source>HSDPA</source>
      <translation variants="yes">
        <lengthvariant priority="1">HSDPA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_network_band_supported">
      <source>Network Band supported</source>
      <translation variants="yes">
        <lengthvariant priority="1">تائید شدہ نیٹ ورک بینڈ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_you_will_be_notified_once_t">
      <source>Connect the charger.You will be notified once the charging level reaches acceptable level.</source>
      <translation variants="no">چارجر متصل کریں۔ آپ کو اطلاع دی جائے گی کہ آپ کب چارجر الگ کر سکتے ہیں۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_server_message">
      <source>Server Message</source>
      <translation variants="no">سرور پیغام</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_size_1_Gb">
      <source>Size: %L1 Gb</source>
      <translation variants="no">سائز: %L1 گ ب</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_change_the_id_to_save_the_p">
      <source>Change the ID to save the profile.</source>
      <translation variants="no">پروفائل حفظ کرنے کے لیے کوئی مختلف ID استعمال کریں</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_session_mode">
      <source>Session mode</source>
      <translation variants="no">نشستی وضع</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_file1_2">
      <source>File:%1 (%2)</source>
      <translation variants="no">فائل: %[61]1 (%[60]2)</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_the_last_update_1_2_mb">
      <source> The last update %1 %2 %L3 Mb was not completed. </source>
      <translation variants="no">پچھلی تجدید %[21]1 %[21]2 %L3 م ب مکمل نہیں</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_access_point_val_default">
      <source>Default</source>
      <translation variants="no">آغازی</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BC">
      <source>1900MHz on Band C</source>
      <translation variants="yes">
        <lengthvariant priority="1">بینڈ C پر ۱۹۰۰میگاہٹرز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_enter_first_4_characters_of">
      <source>Enter first 4 characters of the %1 PIN code </source>
      <translation variants="no">%1 کے لیے PIN کے پہلے ۴ حروف داخل کریں</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_streaming_settings">
      <source>Streaming settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">اسٹریمنگ ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_unable_to_add_access_point">
      <source>Unable to add access point to protected access point settings</source>
      <translation variants="no">تحفظ شدہ نقطۂ رسائی ترتیبات میں نقطۂ رسائی شامل کرنے سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_new_server_profile">
      <source>New server profile</source>
      <translation variants="yes">
        <lengthvariant priority="1">نئی سرور پروفائل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_sw_version_date">
      <source>SW version date</source>
      <translation variants="yes">
        <lengthvariant priority="1">سافٹ ویئر ورژن کی تاریخ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_configuration_message">
      <source>Configuration Settings</source>
      <translation variants="no">تشکیلاتی پیغام</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_custom_version_date">
      <source>Custom version date</source>
      <translation variants="yes">
        <lengthvariant priority="1">کسٹم ورژن کی تاریخ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_service_supported">
      <source>Data service supported</source>
      <translation variants="yes">
        <lengthvariant priority="1">تائید شدہ ڈیٹا سروس</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wap_access_point">
      <source>WAP access point</source>
      <translation variants="yes">
        <lengthvariant priority="1">WAP نقطۂ رسائی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_server_password">
      <source>Server Password </source>
      <translation variants="no">سرور کا لفظ شناخت</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_update_incomp_instal_kb">
      <source>The last update %1 (%2),%L3 kb was not completed. You can install it now </source>
      <translation variants="no">%[21]1 (%[21]2),%L3 ک ب گزشتہ نامکمل تجدید کی تنصیب کے لیے اب ڈاؤن لوڈ تیار ہے۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_updating_phone">
      <source>Updating phone</source>
      <translation variants="no">آلے کی تجدید ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_an_error_occurred_during_do">
      <source>An error occurred during download. Device will try resuming the download after some time.</source>
      <translation variants="no">غلطی واقع ہوئی۔ آلہ بعد میں ڈاؤن لوڈ کو بحال کرنے کی کوشش کرے گا۔</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_updating_device_from_server">
      <source>Updating device from server %1  </source>
      <translation variants="no">سرور سے آلے کی تجدید ہو رہی ہے:
%1</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BB">
      <source>1900MHz on Band B</source>
      <translation variants="yes">
        <lengthvariant priority="1">بینڈ B پر ۱۹۰۰میگاہٹرز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_server_profile_not_created">
      <source>Mandatory fields missing</source>
      <translation variants="no">لازمی فیلڈز نامکمل</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_uninstalling_application">
      <source>Uninstalling application</source>
      <translation variants="no">پروگرام تنصیب رد ہو رہی</translation>
    </message>
    <message numerus="no" id="txt_device_update_dpopinfo_your_phone_is_already_u">
      <source>Your phone is already updated with the latest Nokia OS</source>
      <translation variants="no">آپ کے آلے میں پہلے سے جدید ترین Nokia آپریٹنگ سسٹم سافٹ ویئر موجود ہے</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_messaging">
      <source>Messaging</source>
      <translation variants="yes">
        <lengthvariant priority="1">پیغام رسانی جاری</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_other_details">
      <source>Other details</source>
      <translation variants="yes">
        <lengthvariant priority="1">دیگر تفصیلات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BF">
      <source>1900MHz on Band F</source>
      <translation variants="yes">
        <lengthvariant priority="1">بینڈ F پر ۱۹۰۰میگاہٹرز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_network_password">
      <source>network password</source>
      <translation variants="no">نیٹ ورک لفظ شناخت</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_security_information">
      <source>Security Information</source>
      <translation variants="no">حفاظتی معلومات</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_install_to_val_1_2_kb">
      <source>%1: ( %L2) Kb</source>
      <translation variants="no">%[07]1: (%L2 ک ب)</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_save_to">
      <source>Save to configure the settings  </source>
      <translation variants="no">ترتیبات استعمال کرنے کے لیے یہ پیغام حفظ کریں</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_mandatory_fields_not_filled">
      <source>Mandatory fields not filled, server profile will not be created, exit anyway?</source>
      <translation variants="no">سرور پروفائل کی تشکیل نہیں ہوگی کیونکہ معلومات مفقود ہے۔ بہرحال باہر نکلیں؟</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_browser_settings">
      <source>Browser settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">براؤزر ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_de_info_l1_Mb_free_memory_needed_for_update">
      <source>%L1 MB free memory needed for update. Delete some data now or update later </source>
      <translation variants="no">تجدید کے لیے کافی حافظہ نہیں ہے۔ %L1 م ب درکار۔ کچھ ڈیٹا مٹائیں اور دوبارہ کوشش کریں۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_001">
      <source>%1</source>
      <translation variants="no">%1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_phone_was_not_updated">
      <source>The phone was not updated. The update package was not compatible with the phone. Please contact your service provider.</source>
      <translation variants="no">تجدید ناکام۔ تجدیدی مجموعہ آپ کے آلے سے مطابقت پذیر نہیں۔ اپنے خدمت کے فراہم کار سے رابطہ کریں۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_install">
      <source>Install?</source>
      <translation variants="no">تنصیب کریں</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_title_delete">
      <source>Delete?</source>
      <translation variants="no">مٹائیں؟</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_host_address">
      <source>Host address*</source>
      <translation variants="no">میزبان کا پتہ*</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_no_access_points_found_in_t">
      <source>No access points found in the message. Settings cannot be saved." </source>
      <translation variants="no">تشکیلی پیغام میں کوئی نقطۂ رسائی نہیں ملا۔ ترتیبات حفظ نہیں کی جا سکتیں۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading_of_1_Mb_failed">
      <source>Downloading of %1 %L2 Mb failed</source>
      <translation variants="no">%[55]1 (%L2 م ب)  کا ڈاؤن لوڈ ناکام</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_destination_networks">
      <source>Destination networks</source>
      <translation variants="yes">
        <lengthvariant priority="1">منزل کے نیٹ ورکس</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_flash_version">
      <source>Flash version </source>
      <translation variants="yes">
        <lengthvariant priority="1">فلیش ورژن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wireless_village_settings">
      <source>Wireless Village settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">فوری پیغام رسانی ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_bookmark">
      <source>Bookmark</source>
      <translation variants="yes">
        <lengthvariant priority="1">نشانی کتاب</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_uninstallation_complete">
      <source>Uninstallation complete</source>
      <translation variants="no">سافٹ ویئر تنصیب رد</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BA">
      <source>1900MHz on Band A</source>
      <translation variants="yes">
        <lengthvariant priority="1">بینڈ A پر ۱۹۰۰میگاہٹرز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wcdma_bands">
      <source>WCDMA bands </source>
      <translation variants="yes">
        <lengthvariant priority="1">WCDMA بینڈز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_download_complete">
      <source>Download complete</source>
      <translation variants="no">ڈاؤن لوڈ مکمل</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_settings_could_not_be_saved">
      <source>Settings could not be saved properly. Configuration might not be usable. Contact service provider</source>
      <translation variants="no">ترتیبات حفظ نہیں کی جا سکیں اور تشکیل شاید قابل استعمال نہ ہو۔ مفقود ترتیبات کے لیے خدمت کے فراہم کار سے رابطہ کریں۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_device_updated">
      <source>Device updated</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلے کی تجدید کی گئی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_network_authentication">
      <source>Network authentication</source>
      <translation variants="no">نیٹ ورک تصدیق کاری</translation>
    </message>
    <message numerus="no" id="txt_device_update_menu_connect">
      <source>Connect </source>
      <translation variants="no">متصل کریں</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_update_available">
      <source>Update available</source>
      <translation variants="no">تجدید دستیاب</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_after_the_installation_the">
      <source>After the installation the phone will restart.</source>
      <translation variants="no">تنصیب ختم ہو جانے کے بعد آپ کا آلہ دوبارہ چالو ہو جائے گا۔</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_none">
      <source>None</source>
      <translation variants="yes">
        <lengthvariant priority="1">کوئی نہیں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_menu_delete">
      <source>Delete</source>
      <translation variants="no">مٹائیں</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_phone_uptodate">
      <source>Phone Up-to-date</source>
      <translation variants="no">آلہ تجدید شدہ</translation>
    </message>
    <message numerus="no" id="txt_device_update_list_from_1_2">
      <source>From: %1</source>
      <translation variants="no">سے: %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_port">
      <source>Port</source>
      <translation variants="no">پورٹ</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_GPRS">
      <source>GPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">GPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_updte_incomp_dwnld_Mb">
      <source>The last update %1 (%2),%L3 Mb was not completed. You can download it now </source>
      <translation variants="no">%[22]1 (%[21]2),%L3 م ب گزشتہ نامکمل تجدید کی تنصیب کے لیے اب ڈاؤن لوڈ تیار ہے۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_recommended_update_is_avail">
      <source>Recommended update is available from %1.  Downloading requires connection to the internet</source>
      <translation variants="no">%[99]1 سے سفارش شدہ تجدید دستیاب ہے۔ ڈاؤن لوڈ کے لیے انٹر نیٹ سے اتصال درکار ہوگا۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wlan_mac_address">
      <source>WLAN MAC address </source>
      <translation variants="yes">
        <lengthvariant priority="1">WLAN MAC پتہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_server_not_responding">
      <source>Server not responding </source>
      <translation variants="no">سرور جواب نہیں دے رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_during_the_installation_the">
      <source>During the installation the phone can not be used even for emergency.</source>
      <translation variants="no">تنصیب کے دوران آپ کا آلہ ہنگامی کالیں بھی نہیں کر سکے گا۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_software_version">
      <source>Software version</source>
      <translation variants="yes">
        <lengthvariant priority="1">سافٹ ویئر ورژن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_invalid_host_address">
      <source>Invalid host address </source>
      <translation variants="no">غیرکارآمد میزبان پتہ</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_model">
      <source>Model</source>
      <translation variants="yes">
        <lengthvariant priority="1">ماڈل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_dtm_mscs">
      <source>DTM MSCs</source>
      <translation variants="yes">
        <lengthvariant priority="1">DTM MSCs</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_install_to_val_1_2_Gb">
      <source>%1: ( %L2) Gb</source>
      <translation variants="no">%[07]1: (%L2 گ ب)</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_connection_lost_while_do">
      <source>Internet connection lost.Device will try resuming the download once the connection is available</source>
      <translation variants="no">انٹرنیٹ اتصال ضائع ہوگیا۔ جب اتصال دوبارہ دستیاب ہوگا تو آلہ ڈاؤن لوڈ کو جاری رکھنے کی کوشش کرے گا۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_the_last_update_incomp_instal_Mb">
      <source>The last update %1 (%2),%L3 Mb was not completed. You can install it now </source>
      <translation variants="no">%[22]1 (%[21]2),%L3 م ب گزشتہ نامکمل تجدید کی تنصیب کے لیے اب ڈاؤن لوڈ تیار ہے۔</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_are_you_sure_you_want_to_del">
      <source>Are you sure you want to delete %1</source>
      <translation variants="no">کیا آپ واقعی سرور کو مٹانا چاہتے ہیں؟
%1</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_device_update_services">
      <source>Device update services</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلے کی تجدید کی خدمات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_server_name">
      <source>Server name *</source>
      <translation variants="no">سرور کا نام*</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading_of_1_Kb_failed">
      <source>Downloading of %1 %L2 Kb failed</source>
      <translation variants="no">%[55]1 (%L2 ک ب) کا ڈاؤن لوڈ ناکام</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__800BB">
      <source>800MHz on Band B</source>
      <translation variants="yes">
        <lengthvariant priority="1">بینڈ B پر ۸۰۰ میگاہٹرز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_set_the_received_settings">
      <source> "Set the received settings as default?</source>
      <translation variants="no">موصولہ ترتیبات کو بطور آغازی ترتیبات مرتب کریں؟</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_downloading">
      <source>Downloading</source>
      <translation variants="no">ڈاؤن لوڈ ہو رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_access_point">
      <source>Access point</source>
      <translation variants="no">نقطۂ رسائی</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_imei">
      <source>IMEI</source>
      <translation variants="yes">
        <lengthvariant priority="1">IMEI</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_data_srvce_suppo_val_HSUPA">
      <source>HSUPA</source>
      <translation variants="yes">
        <lengthvariant priority="1">HSUPA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BD">
      <source>1900MHz on Band D</source>
      <translation variants="yes">
        <lengthvariant priority="1">بینڈ D پر ۱۹۰۰میگاہٹرز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_it_is_recommended_to_connec">
      <source>It is recommended to connect to the charger.</source>
      <translation variants="no">تنصیب کے دوران آپ کے آلے کی چارجنگ کی سفارش کی جاتی ہے۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_settings_are_already_saved">
      <source>Settings are already saved. Save again?" </source>
      <translation variants="no">ترتیبات پہلے ہی حفظ کی گئیں۔ دوبارہ حفظ کریں؟</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_phone_uptodate_popup">
      <source>Phone Up-to-date</source>
      <translation variants="no">آلہ تجدید شدہ</translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_network_username">
      <source>network username</source>
      <translation variants="no">نیٹ ورک صارف نام</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_authentication_failed_chec">
      <source>Authentication failed, check server ID and password </source>
      <translation variants="no">تصدیق کاری ناکام۔ سرور ID اور لفظ شناخت کی جانچ کریں۔</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_GSM">
      <source>GSM</source>
      <translation variants="yes">
        <lengthvariant priority="1">GSM</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_download">
      <source>Download?</source>
      <translation variants="no">ڈاؤن لوڈ</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_wcdma_cipherings">
      <source>WCDMA cipherings </source>
      <translation variants="yes">
        <lengthvariant priority="1">WCDMA رمز بندی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_ntwrk_secu_lvl_val_CDMA">
      <source>CDMA</source>
      <translation variants="yes">
        <lengthvariant priority="1">CDMA</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_download_and_install">
      <source>Download and install?</source>
      <translation variants="no">ڈاؤن لوڈ و تنصیب کریں؟</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_service_recomended">
      <source>Service recomended</source>
      <translation variants="no">خدمت کی سفارش کی گئی</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_error_in_communication_with">
      <source>Error in communication with the server, try again later" </source>
      <translation variants="no">سرور سے مواصلت میں غلطی۔ بعد میں دوبارہ کوشش کریں۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_download">
      <source>Downloading %1</source>
      <translation variants="no">ڈاؤن لوڈنگ %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_security_info_access_denied">
      <source>Security Information did not match. Access denied </source>
      <translation variants="no">رسائی سے انکار۔ حفاظتی معلومات مطابقت پذیر نہیں۔</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_size_1_mb">
      <source>Size: %L1 Mb</source>
      <translation variants="no">سائز: %[62]1 م ب</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_ready">
      <source>Ready</source>
      <translation variants="no">تیار</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_the_last_update_1_2_kb">
      <source> The last update %1 %2 %L3 kb was not completed. </source>
      <translation variants="no">پچھلی تجدید %[21]1 %[20]2 %L3 ک ب مکمل نہیں</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_netwrk_bnd_spp_val__1900BE">
      <source>1900MHz on Band E</source>
      <translation variants="yes">
        <lengthvariant priority="1">بینڈ E پر ۱۹۰۰میگاہٹرز</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_installation_complete">
      <source>Installation complete</source>
      <translation variants="no">تنصیب مکمل</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_installing">
      <source>Installing</source>
      <translation variants="no">تنصیب جاری</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_access_points">
      <source>Access Points</source>
      <translation variants="yes">
        <lengthvariant priority="1">نقاط رسائی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_an_error_occurred_update_stop">
      <source>Phone can not be updated due to unknown error.</source>
      <translation variants="no">نامعلوم غلطی۔ آلے کی تجدید نہیں کی جا سکتی۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_device_update">
      <source>Device Update</source>
      <translation variants="no">آلے کی تجدید</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_uninstalling_of_1_Mb_failed">
      <source>Uninstalling of %1 failed</source>
      <translation variants="no">%1 کی تنصیب رد کرنے میں ناکام</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_installation_of_1_kb_failed">
      <source>Installation of %1 failed.</source>
      <translation variants="no">%1 تنصیب کرنے سے قاصر</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_8pskul">
      <source>8PSK-UL</source>
      <translation variants="yes">
        <lengthvariant priority="1">۸PSK-UL</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_installation_failed">
      <source>Installation failed</source>
      <translation variants="no">تنصیب ناکام</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_network_security_level">
      <source>Network security level</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیٹ ورک حفاظتی سطح</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_language_variant_version">
      <source>Language variant version</source>
      <translation variants="yes">
        <lengthvariant priority="1">زبان کے تغیر کا ورژن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_formlabel_password">
      <source>Password</source>
      <translation variants="no">لفظ شناخت</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_invalid_user_name_or_passwo">
      <source>Invalid user name or password  </source>
      <translation variants="no">غیرکارآمد صارف نام یا لفظ شناخت</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_release">
      <source>Product Release</source>
      <translation variants="yes">
        <lengthvariant priority="1">پروڈکٹ کا اجراء</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_mailbox_settings">
      <source>Mailbox Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل باکس ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_java_version">
      <source>Java version</source>
      <translation variants="yes">
        <lengthvariant priority="1">جاوا ورژن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_connecting">
      <source>connecting</source>
      <translation variants="no">متصل کر رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_file_1_2">
      <source>file: %1 </source>
      <translation variants="no">فائل: %1</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_uninstall_app1_2">
      <source>Application:%1 (%2)</source>
      <translation variants="no">پروگرام: %[31]1 (%[31]2)</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_browser_version">
      <source>Browser version </source>
      <translation variants="yes">
        <lengthvariant priority="1">براؤزر ورژن</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_egprs">
      <source>EGPRS</source>
      <translation variants="yes">
        <lengthvariant priority="1">EGPRS</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_firmware_update">
      <source>Firmware Update</source>
      <translation variants="no">آلے کی تجدید</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_wlan">
      <source>WLAN</source>
      <translation variants="no">WLAN</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_camera">
      <source>Camera</source>
      <translation variants="no">کیمرا</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_desktop_sync">
      <source>Desktop Sync</source>
      <translation variants="no">ہمزمانگی</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_external_memory_card">
      <source>External Memory card</source>
      <translation variants="no">خارجی حافظہ کارڈ</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_system_error_try_again_l">
      <source> System Error . Try again later </source>
      <translation variants="no">سسٹم کی غلطی۔ بعد میں دوبارہ کوشش کریں۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_later">
      <source>Later</source>
      <translation variants="yes">
        <lengthvariant priority="1">بعد میں تجدید</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dialog_enter_the_configuration_p">
      <source>Enter the Configuration Pin </source>
      <translation variants="yes">
        <lengthvariant priority="1">تشکیلی PIN داخل کریں:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_device_updates">
      <source>Device updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلے کی تجدید</lengthvariant>
        <lengthvariant priority="2">آلہ کی تجدید</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_update">
      <source>Update</source>
      <translation variants="yes">
        <lengthvariant priority="1">اب تجدید کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_resume_later">
      <source>Resume later</source>
      <translation variants="yes">
        <lengthvariant priority="1">بعد میں جاری رکھیں</lengthvariant>
        <lengthvariant priority="2">بعد میں جاری</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_config_set">
      <source>Configuration Settings</source>
      <translation variants="yes">
        <lengthvariant priority="1">تشکیلی ترتیب</lengthvariant>
        <lengthvariant priority="2">ت</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_set_as_default">
      <source>Set as default</source>
      <translation variants="yes">
        <lengthvariant priority="1">بطور آغازی مرتب کریں</lengthvariant>
        <lengthvariant priority="2">بطور آغازی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_install_later">
      <source>Install later</source>
      <translation variants="yes">
        <lengthvariant priority="1">بعد میں نصب</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_button_advanced">
      <source>Advanced</source>
      <translation variants="no">برتر</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_resume_update">
      <source>Resume update</source>
      <translation variants="no">تجدید بحال کریں</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_update_cmd">
      <source>Update</source>
      <translation variants="no">تجدید کریں</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_connecti">
      <source>connecting</source>
      <translation variants="yes">
        <lengthvariant priority="1">اتصال جاری</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_installa_comple">
      <source>Installation %1 Complete</source>
      <translation variants="no">تنصیب مکمل: %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_installi">
      <source>Installing %1</source>
      <translation variants="no">تنصیب جاری: %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_uninstall">
      <source>Uninstalling %1</source>
      <translation variants="no">تنصیب رد کی جا رہی ہے: %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_uninstalla_comple">
      <source>Removed %1 </source>
      <translation variants="no">تنصیب رد کی گئی: %1</translation>
    </message>
    <message numerus="yes" id="txt_device_update_dialog_enter_the_config_trial">
      <source>Incorrect Pin. &lt;%Ln&gt; tries left.</source>
      <translation>
        <numerusform plurality="a">تشکیلی PIN داخل کریں۔ %Ln کوشش باقی۔
تشکیلی PIN داخل کریں۔ %Ln کوششیں باقی۔</numerusform>
        <numerusform plurality="b">تشکیلی PIN داخل کریں۔ %Ln کوشش باقی۔
تشکیلی PIN داخل کریں۔ %Ln کوششیں باقی۔</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_download_complete">
      <source>Download complete!</source>
      <translation variants="no">ڈاؤن لوڈ مکمل</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_installation_will_proceed_n">
      <source>Installation will proceed now</source>
      <translation variants="no">تنصیب شروع ہو رہی ہے</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_no_server_configured_to_get">
      <source>No server configured to get the updates. Please call customer care</source>
      <translation variants="no">سرور کی تشکیل درکار۔ نگہداشت صارفین کو کال کریں۔</translation>
    </message>
    <message numerus="yes" id="txt_device_update_info_security_information_did_no">
      <source>Security Information did not Match . %Ln tries left.
Enter first 4 characters of the %1 PIN code </source>
      <translation>
        <numerusform plurality="a">حفاظتی معلومات کی مطابقت نہیں ہوئی۔
%Ln کوشش باقی۔
'%[99]1' کے لیے PIN کے پہلے ۴ حروف داخل کریں</numerusform>
        <numerusform plurality="b">حفاظتی معلومات کی مطابقت نہیں ہوئی۔
%Ln کوشش باقی۔
'%[99]1' کے لیے PIN کے پہلے ۴ حروف داخل کریں</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_to_proceed_with_installatio">
      <source>To proceed with installation connect to the charger now</source>
      <translation variants="no">تنصیب جاری رکھنے کے لیے چارجر متصل کریں</translation>
    </message>
    <message numerus="no" id="txt_device_update_setlabel_to_update_your_device_s">
      <source>To update your device software to the latest available device software</source>
      <translation variants="no">اپنے آلے کے لیے جدید ترین سافٹ ویئر حاصل کریں</translation>
    </message>
    <message numerus="no" id="txt_device_update_subhead_advanced_device_updates">
      <source>Advanced: Device updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلے کی تجدید - برتر ترتیبات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_title_disabled_by_the_system_adm">
      <source>Disabled by the system admin</source>
      <translation variants="no">سسٹم ایڈمنسٹریٹر نے غیر فعال کر دیا</translation>
    </message>
    <message numerus="no" id="txt_device_update_title_enabled_by_the_system_admi">
      <source>Enabled by the system admin</source>
      <translation variants="no">سسٹم ایڈمنسٹریٹر نے فعال کر دیا</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_config_set_val_saving">
      <source>Saving</source>
      <translation variants="yes">
        <lengthvariant priority="1">حفظ کررہا ہے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_dblist_device_updates_val_connect_fota">
      <source>connecting</source>
      <translation variants="yes">
        <lengthvariant priority="1">اتصال جاری</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_info_new_device_software_availabl">
      <source>New device software available</source>
      <translation variants="no">نیا آلہ سافٹ ویئر دستیاب</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_to_update_your_val_bluet">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_to_update_your_val_inter">
      <source>Internet</source>
      <translation variants="no">انٹرنیٹ</translation>
    </message>
    <message numerus="no" id="txt_de_info_l1_kb_free_memory_needed_for_update_">
      <source>%L1 kB free memory needed for update. Delete some data now or update later </source>
      <translation variants="no">تجدید کے لیے کافی حافظہ نہیں۔ %[99]L1 ک ب درکار۔ کچھ ڈیٹا مٹائیں اور دوبارہ کوشش کریں۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_product_code_val_download_comple">
      <source>Download %1 Complete</source>
      <translation variants="no">ڈاؤن لوڈ مکمل: %1</translation>
    </message>
    <message numerus="no" id="txt_device_update_button_new_server_profile">
      <source>New server profile</source>
      <translation variants="no">نئی سرور پروفائل</translation>
    </message>
    <message numerus="no" id="txt_device_update_dblist_device_updates_fota">
      <source>Device updates</source>
      <translation variants="yes">
        <lengthvariant priority="1">آلے کی تجدیدات</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_device_update_info_downloading">
      <source>Downloading</source>
      <translation variants="no">ڈاؤن لوڈنگ جاری</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_its_recommended_to_connec">
      <source>It is recommended to connect to the charger</source>
      <translation variants="no">تنصیب کے دوران آپ کے آلے کی چارجنگ کی سفارش کی جاتی ہے۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_warning_device_memory_is_b">
      <source>Warning! Device memory is busy. Try installation later.</source>
      <translation variants="no">آلہ حافظہ مصروف۔ بعد میں تنصیب کی کوشش کریں۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_during_the_installation_the">
      <source>During the installation the phone can not be used even for emergency.</source>
      <translation variants="no">تنصیب کے دوران آپ کا آلہ ہنگامی کالیں کرنے کے بھی قابل نہیں رہے گا۔</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_new_device_software_availab_Kb">
      <source>New device software available %1 %2 %L3 Kb</source>
      <translation variants="no">نئے آلہ سافٹ ویئر دستیاب: %[99]1 %[99]2 %L3 ک ب</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_new_device_software_availab_Mb">
      <source>New device software available %1 %2 %L3 Mb</source>
      <translation variants="no">نئے آلہ سافٹ ویئر دستیاب: %[99]1 %[99]2 %L3 م ب</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_FS_after_the_installation_the">
      <source>After the installation the phone will restart.</source>
      <translation variants="no">تنصیب مکمل ہونے جانے پر آپ کا آلہ دوبارہ چالو ہو  جائے گا۔</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_network_auth_val_yes">
      <source>Yes</source>
      <translation variants="no">ہاں</translation>
    </message>
    <message numerus="no" id="txt_deviceupdate_setlabel_network_auth_val_no">
      <source>No</source>
      <translation variants="no">نہیں</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_rebooting">
      <source>Rebooting</source>
      <translation variants="no">دوبارہ شروع ہو رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_installing">
      <source>Installing </source>
      <translation variants="no">تنصیب جاری</translation>
    </message>
    <message numerus="no" id="txt_device_update_info_sender_of_the_message_is_unt">
      <source>Sender of the message is untrusted. Continue?"</source>
      <translation variants="no">پیغام بھیجنے والا معتبر نہیں۔ جاری رکھیں؟</translation>
    </message>
  </context>
</TS>