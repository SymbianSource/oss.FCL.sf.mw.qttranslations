<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="vi">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_bt_dblist_sending_files">
      <source>Sending files</source>
      <translation variants="no">Đang gửi tập tin</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_phone">
      <source>Phone</source>
      <translation variants="no">Điện thoại</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_paired">
      <source>%1 paired</source>
      <translation variants="no">Đã ghép nối %[10]1</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_other_device">
      <source>Other device</source>
      <translation variants="no">Thiết bị kia</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_audio_device">
      <source>Audio device</source>
      <translation variants="no">Thiết bị âm thanh</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_usign_sim_access_profi">
      <source>usign SIM access profile</source>
      <translation variants="no">Chế độ SIM từ xa</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_input_device">
      <source>Input device</source>
      <translation variants="no">Thiết bị nhập</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth">
      <source>Bluetooth</source>
      <translation variants="no">Bluetooth</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_hidden_and_connected">
      <source>Connected (hidden)</source>
      <translation variants="no">Đã kết nối (ẩn)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_off">
      <source>Off</source>
      <translation variants="no">Tắt</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_hidden">
      <source>On (hidden)</source>
      <translation variants="no">Bật (ẩn)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_on_and_visible">
      <source>On (visible)</source>
      <translation variants="no">Bật (hiển thị)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_bluetooth_val_visible_and_connected">
      <source>Connected (visible)</source>
      <translation variants="no">Đã kết nối (hiển thị)</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_device_val_1_connected">
      <source>%1 connected</source>
      <translation variants="no">Đã kết nối %[11]1</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_val_computer">
      <source>Computer</source>
      <translation variants="no">Máy vi tính</translation>
    </message>
    <message numerus="no" id="txt_bt_dblist_receiving_files">
      <source>Receiving files</source>
      <translation variants="no">Đang nhận tập tin</translation>
    </message>
  </context>
</TS>