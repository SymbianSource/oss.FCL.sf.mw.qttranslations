<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_hk">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_occ_dialog_selected_network_supports_wifi_pro">
      <source>Selected network supports Wi-Fi Protected Setup™ for receiving settings automatically.</source>
      <translation variants="no">選擇的網絡支援可自動接收設定的Wi-Fi保護設定。</translation>
    </message>
    <message numerus="no" id="txt_occ_list_use_pushbutton">
      <source>Use push-button</source>
      <translation variants="no">使用Psuh按鈕</translation>
    </message>
    <message numerus="no" id="txt_occ_list_use_pin_code">
      <source>Use PIN code</source>
      <translation variants="no">使用PIN碼</translation>
    </message>
    <message numerus="no" id="txt_occ_list_configure_manually">
      <source>Configure manually</source>
      <translation variants="no">手動定義</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_first_press_button_on_the_wireless">
      <source>First, press button on the wireless station to initiate the setup process, then select 'Next'.</source>
      <translation variants="no">首先按無線基地台上的按鈕以啟動設定程序，然後選擇"下一步"。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_settings_received_for_multiple_wlan">
      <source>Settings received for multiple WLAN networks. Select the network to use:</source>
      <translation variants="no">已收到多個WLAN網絡的設定。選擇要使用的網絡：</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_enter_1_on_the_wireless_station_t">
      <source>Enter '%1' on the wireless station then select 'Next'.</source>
      <translation variants="no">在無線基地台上輸入"%[37]1"，然後選擇"下一步"。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_negotiating">
      <source>Negotiating</source>
      <translation variants="no">設定檢查中</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_configuration_failed_please_try_ag">
      <source>Configuration failed. Please try again.</source>
      <translation variants="no">配置失敗。請重試。</translation>
    </message>
    <message numerus="no" id="txt_occ_dialog_configuration_failed_authenticatio">
      <source>Configuration failed. Authentication unsuccessful.</source>
      <translation variants="no">配置失敗。驗證不成功。</translation>
    </message>
  </context>
</TS>