<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_irad_opt_go_to_station">
      <source>Go to station</source>
      <translation variants="no">转至频道</translation>
    </message>
    <message numerus="no" id="txt_irad_info_connecting_timout">
      <source>Connecting timeout</source>
      <translation variants="no">连接超时</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_search_in_music_store">
      <source>Search in music store</source>
      <translation variants="no">在音乐商店搜索</translation>
    </message>
    <message numerus="no" id="txt_irad_title_internet_radio">
      <source>Internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">互联网收音机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_favorite_updated">
      <source>Favorite updated</source>
      <translation variants="no">频道已加至收藏夹</translation>
    </message>
    <message numerus="no" id="txt_long_caption_internetradio">
      <source>Internet Radio</source>
      <translation variants="no">互联网收音机</translation>
    </message>
    <message numerus="no" id="txt_irad_info_downloading_logos">
      <source>Downloading logos</source>
      <translation variants="no">正在下载标志</translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_language">
      <source>Stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">按语言显示电台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_standard">
      <source>Standard</source>
      <translation variants="no">标准</translation>
    </message>
    <message numerus="no" id="txt_irad_menu_share">
      <source>Share</source>
      <translation variants="no">共享</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_country_region">
      <source>Stations by country/region</source>
      <translation variants="yes">
        <lengthvariant priority="1">按国家/地区显示电台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_by_language">
      <source>Stations by language</source>
      <translation variants="yes">
        <lengthvariant priority="1">按语言显示电台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_station_name">
      <source>Station name</source>
      <translation variants="no">频道名称</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_songs">
      <source>Songs played</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_by_country_region">
      <source>Stations by country/region</source>
      <translation variants="yes">
        <lengthvariant priority="1">按国家/地区显示电台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality">
      <source>Download quality</source>
      <translation variants="no">下载质量</translation>
    </message>
    <message numerus="no" id="txt_irad_info_music_store_not_available">
      <source>Music store not available</source>
      <translation variants="no">音乐商店不可用</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_stations_from_play_list">
      <source>Stations from play list</source>
      <translation variants="yes">
        <lengthvariant priority="1">播放列表中的电台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_download_quality_val_high">
      <source>High</source>
      <translation variants="no">高</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_network_setting">
      <source>Network setting</source>
      <translation variants="yes">
        <lengthvariant priority="1">网络设置</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_recently_played_stations">
      <source>Stations played</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放的电台</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_share">
      <source>Share</source>
      <translation variants="no">共享</translation>
    </message>
    <message numerus="no" id="txt_irad_info_song_recognition_not_available">
      <source>Song recognition not available</source>
      <translation variants="no">歌曲识别不可用</translation>
    </message>
    <message numerus="no" id="txt_irad_info_failed_to_connect">
      <source>Connecting failed</source>
      <translation variants="no">无法连接</translation>
    </message>
    <message numerus="no" id="txt_irad_info_share_not_available">
      <source>Share not available</source>
      <translation variants="no">共享频道不可用</translation>
    </message>
    <message numerus="no" id="txt_irad_info_details_not_available">
      <source>Details not available</source>
      <translation variants="no">无歌曲详情可用</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_disclaimer_and_liability">
      <source>DISCLAIMER AND LIABILITY</source>
      <translation variants="no">免责和责任</translation>
    </message>
    <message numerus="no" id="txt_irad_info_unnamed_station">
      <source>Unnamed station</source>
      <translation variants="no">未命名</translation>
    </message>
    <message numerus="no" id="txt_irad_info_policy_copyright_content">
      <source>If you believe that your copyrighted work has been handled in a way that constitutes copyright infringement, you may notify Nokia by providing a notification including the following:\n\n(1) A physical or electronic signature of a person authorised to act on behalf of the owner of the exclusive right that is allegedly infringed;\n\n(2) Identification or description of the copyrighted work claimed to have been infringed;\n\n(3) Identification or description of the material that is claimed to be infringing and information reasonably sufficient to locate the material;\n\n(4) Your name, address, telephone number, e-mail address and any other information that will permit Nokia to contact you;\n\n(5) A statement that you believe, in good faith, that use of the material in the manner on which this complaint is based is not authorised by the copyright owner, its agent or the law; and\n\n(6) A statement that the information in the notification is accurate and, under penalty of perjury, that you are authorised to act on behalf of the owner of an exclusive right that is allegedly infringed.\n\nThe notification must be sent to our Designated Agent address at:\n\nCopyright.Notices@nokia.com
</source>
      <translation variants="no">如果您认为对待您的版权作品的方式构成版权侵害，可以通知诺基亚，通知的内容包括：

(1) 据称专有权受到侵害的所有者的授权代表的物理或电子签名；

(2) 声称受到侵害的版权作品的鉴定或说明；

(3) 声称正在受到侵害的材料的鉴定或说明，以及合理的足够找到此材料的信息；

(4) 您的姓名、地址、电话号码、电子邮件地址，以及任何其他允许诺基亚联系您的信息；

(5) 声明您真诚地相信，使用此材料的方式(此宗投诉的基础)未经版权所有人、其代理人或法律授权；以及

(6) 声明此通知中的信息准确无误，如所言不实愿受处罚，以及您被授权作为据称专有权受到侵害的所有者的代表。

必须将通知发送至我们的指定代理人，地址是：

Copyright.Notices@nokia.com
</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_delete_stations">
      <source>Remove stations</source>
      <translation variants="no">删除频道</translation>
    </message>
    <message numerus="no" id="txt_irad_info_disclaimer_and_liability_content_1">
      <source>For your ease of accessibility, Nokia may include links to Internet radio stations that are owned or operated by third parties. Nokia does not guarantee that the links to Internet radio stations will be operational. In addition, the content that is not related to Nokia does not imply whatsoever that Nokia endorses the content as such or the products or services referenced in such content.\n\nYou must review and agree to each station's rules of use, if any, before accessing it. You also agree that Nokia has no control over the content of third-party services and cannot assume any responsibility for the content provided by Internet radio stations.\n\nAccessing the content of Internet radio stations using the Service may involve the transmission of large amounts of data through your service provider's network. Contact your service provider for information about data transmission charges. Note that using the Service with Internet radio stations that are delivering higher bit rate streams to you may incur higher costs associated with data traffic.\n\nThe data traffic associated with the usage of the Service may include the following at least: updating the content of the stations’ directory, streaming data from the Internet radio station, collecting statistical data and upgrading the Internet radio application.\n\nNokia is not liable for the costs of data traffic associated with your use of the Service.\n\n</source>
      <translation variants="no">为便于您访问，Nokia可能包括为第三方所拥有或运营的互联网收音机频道链接。Nokia不保证这些互联网收音机频道一定可用。此外，与Nokia无关的内容不代表Nokia绝对赞成这些内容，以及内容中提到的产品或服务。

您必须仔细阅读并同意每个频道的使用规则（如有），然后才能访问。您还须同意，Nokia无义务控制第三方服务的内容，因此对于互联网收音机频道提供的内容不承担任何责任。

使用此服务访问互联网收音机频道的内容可能涉及通过您的服务提供商网络传输大量数据。请咨询您的服务提供商，了解有关数据传输费用的信息。请注意，对于向您提供较高比特率流的互联网收音机频道，使用此服务可能产生与数据通信量关联的较高费用。

与使用此服务关联的数据通讯量至少包括：更新频道目录的内容，从互联网收音机频道传送数据，收集统计数据，升级互联网收音机应用程序。

Nokia不负责与您使用此服务相关的数据通信费用。

</translation>
    </message>
    <message numerus="no" id="txt_irad_info_governing_law_content">
      <source>As used in these terms and conditions, "Nokia" means Nokia Corporation. Nokia operates and controls the Service from locations within Finland. As such, the information contained on the Service hereby is deemed to be provided in Finland.\n\nExcept where prohibited by applicable law, these terms and conditions shall be governed by the laws of Finland without regard to conflict of law provisions. For US residents: These terms and conditions shall be governed by the laws of Texas.\n\nCopyright © Nokia Corporation 2006. All rights reserved.
</source>
      <translation variants="no">当在这些条款和条件中使用时，"诺基亚"指诺基亚公司。诺基亚从芬兰国内运营和控制此服务。同样，所包含的有关此处所指的服务的信息也被视为在芬兰国内提供。

适用法律禁止者除外，这些条款和条件应受芬兰法律管辖，且不考虑法律冲突。对于美国居民，这些条款和条件应受得克萨斯州法律管辖。

版权所有 © 诺基亚公司 2006。保留所有权利。
</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_identify_song">
      <source>Identify song</source>
      <translation variants="no">识别歌曲</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_l">
      <source>Unknown artist - %1</source>
      <translation variants="no">未知艺术家 - %1</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_search_results">
      <source>Search results</source>
      <translation variants="yes">
        <lengthvariant priority="1">搜索结果</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_opt_settings">
      <source>Settings</source>
      <translation variants="no">设置</translation>
    </message>
    <message numerus="no" id="txt_irad_info_delete_station">
      <source>Remove station?</source>
      <translation variants="yes">
        <lengthvariant priority="1">删除频道？</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_station_not_find">
      <source>Station not found</source>
      <translation variants="no">未找到频道</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_definitions">
      <source>DEFINITIONS</source>
      <translation variants="no">定义</translation>
    </message>
    <message numerus="no" id="txt_irad_info_definitions_content">
      <source>Internet radio stations are entities that generally produce and distribute audio content and related metadata over the Internet in a stream.\n\nThe link to the Internet radio station is a resource locator or a set of resource locators that enable the user to access the content streamed by the Internet radio station.
</source>
      <translation variants="no">互联网收音机频道指通常通过互联网，连续产生和分发音频内容及相关元数据的实体。

指向互联网收音机频道的链接为一个或一组资源定位器，这些资源定位器允许用户通过互联网收音机频道访问内容流。
</translation>
    </message>
    <message numerus="no" id="txt_irad_list_songs_recently_played">
      <source>Songs played</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放的歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by_val_custom">
      <source>Custom</source>
      <translation variants="no">自定义</translation>
    </message>
    <message numerus="no" id="txt_irad_info_disclaimer_and_liability_content_2">
      <source>NO WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF TITLE OR NON-INFRINGEMENT OR IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, IS MADE IN RELATION TO THE AVAILABILITY, ACCURACY, RELIABILITY OR CONTENT OF THE SERVICE. NOKIA SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR FOR BUSINESS INTERRUPTION ARISING OUT OF THE USE OF OR INABILITY TO USE THE SERVICE, EVEN IF NOKIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. SOME JURISDICTIONS DO NOT ALLOW EXCLUSION OF CERTAIN WARRANTIES OR LIMITATIONS OF LIABILITY, SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. THE LIABILITY OF NOKIA WOULD IN SUCH CASE BE LIMITED TO THE GREATEST EXTENT PERMITTED BY LAW.\n\nNothing contained herein shall prejudice the statutory rights of any party dealing as a consumer. Nothing contained herein limits Nokia's liability in the event of death or personal injury resulting from Nokia's negligence.</source>
      <translation variants="no">就此服务的可用性、准确性、可靠性或满意度，Nokia不作任何类型的担保，无论明示或暗示，包括但不限于所有权或非侵权担保，以及针对特定用途的适销性或适用性的暗示担保。对于因用户使用或不当使用此服务而引起的任何直接、间接、附带、特殊或后果性损害、利润损失或业务中断，即使Nokia已被告知发生此类损害的可能性，Nokia亦不承担任何责任。某些司法辖区不允许排除特定保证或责任限制，因此上述限制或排除可能不适用于您。在此情况下，Nokia的责任仅限于法律所允许的最大范围内。

此处包含的内容不得损害任何消费者方的法定权利，亦不得限制Nokia在因自身疏忽所造成的死亡或人身伤害事件中承担的责任。</translation>
    </message>
    <message numerus="no" id="txt_irad_info_search">
      <source>Search</source>
      <translation variants="no">输入搜索文本</translation>
    </message>
    <message numerus="no" id="txt_irad_info_clear_song_list">
      <source>Clear song list?</source>
      <translation variants="yes">
        <lengthvariant priority="1">清除歌曲列表？将删除所有歌曲。</lengthvariant>
        <lengthvariant priority="2">清除列表？将全部删除。</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_song_p">
      <source>Unknown song</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知歌曲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_nokia_internet_radio">
      <source>Nokia Internet Radio service (“Service”) enables you to discover and experience the content of Internet radio stations. YOU AGREE THAT YOUR USE OF THE SERVICE ACKNOWLEDGES THAT YOU HAVE READ THIS AGREEMENT, YOU HAVE UNDERSTOOD IT AND YOU AGREE TO BE BOUND BY ITS TERMS AND CONDITIONS. If you do not agree, please note that you will not be allowed to use the Service.</source>
      <translation variants="no">诺基亚互联网收音机服务(“服务”)帮您发现和体验互联网收音机频道的内容。您确认在使用此服务时已经阅读了本协议。您已充分理解本协议，并愿意严格遵守各条款和条件。如果您不同意，则将无法使用此服务。</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_visualization">
      <source>Visualization</source>
      <translation variants="no">可视效果</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_use_of_the_service">
      <source>USE OF THE SERVICE</source>
      <translation variants="no">使用此服务</translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_rename">
      <source>Rename</source>
      <translation variants="yes">
        <lengthvariant priority="1">重命名</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by">
      <source>Sort by</source>
      <translation variants="no">排序方式</translation>
    </message>
    <message numerus="no" id="txt_irad_info_service_availability_content">
      <source>The Service is provided as a convenience to you. It is provided "as is" and on an "as available" basis. Nokia does not guarantee that the Service shall be uninterrupted or error-free. Nokia reserves the right to revise the Service or withdraw access to it at any time.\n\nNokia may provide upgrades for software applications related to the Service at its sole discretion.
</source>
      <translation variants="no">此服务可为您带来便利，它按"原样"和"可用"方式提供。诺基亚不保证此服务不出现任何中断或错误。诺基亚有权随时修改此服务，或终止服务访问权。

诺基亚可以自行决定向与此服务相关的软件应用程序提供升级。
</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_privacy">
      <source>PRIVACY</source>
      <translation variants="no">隐私</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_service_availability">
      <source>SERVICE AVAILABILITY</source>
      <translation variants="no">服务连接状态</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_unknown_song">
      <source>Unknown artist - Unknown song</source>
      <translation variants="no">未知歌曲和艺术家</translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_artist_p">
      <source>Unknown artist</source>
      <translation variants="yes">
        <lengthvariant priority="1">未知艺术家</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_menu_add_to_favorites">
      <source>Add to favorites</source>
      <translation variants="no">加至收藏夹</translation>
    </message>
    <message numerus="no" id="txt_irad_info_privacy_content">
      <source>Nokia is committed to protecting user privacy, and thus implements strict confidentiality policies.\n\n In order to monitor the use of and to improve the Service, Nokia may collect usage data including, but not limited to, information about the Internet radio stations accessed, the time spent on each station and the items rated as favourites.\n\nNokia does not collect any information that allows identification of the user of the Service.
</source>
      <translation variants="no">诺基亚承诺保护用户的隐私，并因此执行严格的保密策略。n
为监控对此服务的使用情况和完善此服务，诺基亚可能收集使用数据，包括但不限于被访问互联网收音机频道的信息，花在每个频道上的时间，被放入收藏夹的项目。

诺基亚不收集任何允许识别此服务用户身份的信息。
</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by_val_ascending">
      <source>Ascending </source>
      <translation variants="no">升序</translation>
    </message>
    <message numerus="no" id="txt_irad_info_clear_station_list">
      <source>Clear station list?</source>
      <translation variants="yes">
        <lengthvariant priority="1">清除频道列表？将删除所有频道。</lengthvariant>
        <lengthvariant priority="2">清除列表？将全部删除。</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_matching_station_found">
      <source>No matching station found</source>
      <translation variants="no">未找到匹配频道</translation>
    </message>
    <message numerus="no" id="txt_irad_info_max_reached_delete_station_before_adding_new_favorite">
      <source>Max reached. Remove station before adding new favorite</source>
      <translation variants="no">收藏夹列表已满。删除一个频道后再试。</translation>
    </message>
    <message numerus="no" id="txt_irad_list_stations_recently_played">
      <source>Stations played</source>
      <translation variants="yes">
        <lengthvariant priority="1">最近播放的频道</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_stations_found">
      <source>No stations found</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #No stations found</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_button_decline">
      <source>Decline</source>
      <translation variants="no">拒绝</translation>
    </message>
    <message numerus="no" id="txt_tsw_caption_internet_radio">
      <source>Internet radio</source>
      <translation variants="yes">
        <lengthvariant priority="1">互联网收音机</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_go_to_station">
      <source>Go to station</source>
      <translation variants="yes">
        <lengthvariant priority="1">转至频道</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_max_limit_reached">
      <source>Max limit reached</source>
      <translation variants="no">已达到最多字符数</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_governing_law">
      <source>GOVERNING LAW</source>
      <translation variants="no">管辖法律</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_terms_conditions">
      <source>Terms &amp; Conditions</source>
      <translation variants="no">条款和条件</translation>
    </message>
    <message numerus="no" id="txt_irad_info_the_service_content">
      <source>The Service enables the following:\n\n1. browsing of links to Internet radio stations;\n\n2. accessing the content of Internet radio stations;
</source>
      <translation variants="no">此服务允许：

1. 浏览指向互联网收音机频道的链接；

2. 访问互联网收音机频道的内容；
</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_favorites">
      <source>Favorites</source>
      <translation variants="yes">
        <lengthvariant priority="1">收藏夹</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_use_of_the_service_content">
      <source>Use of the Service is only permitted for your private and non-commercial use. Nokia shall own all intellectual property rights relating to the Service.\n\nNokia reserves the right to change these terms and conditions by informing you of such change.
</source>
      <translation variants="no">使用此服务仅限于出自您的私人和非商业目的。诺基亚拥有与此服务相关的所有知识产权。

诺基亚有权通过通知您来更改这些条款和条件。
</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_content">
      <source>No content</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #No content</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_station_with_new_name_exists">
      <source>Station with new name exists</source>
      <translation variants="no">具有此名称的频道已存在</translation>
    </message>
    <message numerus="no" id="txt_irad_info_insufficient_disk_space">
      <source>Insufficient disk space  </source>
      <translation variants="no">存储空间不足</translation>
    </message>
    <message numerus="no" id="txt_irad_button_accept">
      <source>Accept</source>
      <translation variants="no">接受</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_select_items_to_delete">
      <source>Select items to remove</source>
      <translation variants="yes">
        <lengthvariant priority="1">选择要删除的项目</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_click_the_song_and_find_it_in_music_store">
      <source>Click the song and find it in music store</source>
      <translation variants="no">点击歌曲以从音乐商店查找</translation>
    </message>
    <message numerus="no" id="txt_irad_info_operation_failed">
      <source>Operation failed</source>
      <translation variants="no">无法执行操作</translation>
    </message>
    <message numerus="no" id="txt_irad_setlabel_sorted_by_val_descending">
      <source>Descending</source>
      <translation variants="no">降序</translation>
    </message>
    <message numerus="yes" id="txt_irad_subtitle_stations">
      <source>%Ln stations</source>
      <translation>
        <numerusform plurality="a">%Ln个频道</numerusform>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_info_not_allowed_by_this_station">
      <source>Not allowed by this station</source>
      <translation variants="no">此频道不允许搜索</translation>
    </message>
    <message numerus="no" id="txt_irad_formlabel_station_address">
      <source>Station web address</source>
      <translation variants="no">频道网址</translation>
    </message>
    <message numerus="no" id="txt_irad_info_added_to_favorites">
      <source>Added to Favorites</source>
      <translation variants="no">已加至收藏夹</translation>
    </message>
    <message numerus="no" id="txt_irad_info_hi_these_are_my_favorite_stations_hope_you_like_them">
      <source>Hi, these are my favorite stations. Hope you like them</source>
      <translation variants="no">嗨，这些都是我喜欢的电台。希望你也喜欢！</translation>
    </message>
    <message numerus="no" id="txt_irad_info_invalid_station_address">
      <source>Invalid station address</source>
      <translation variants="no">互联网频道地址</translation>
    </message>
    <message numerus="no" id="txt_irad_info_hi_this_is_my_favorite_station_hope_you_like_it">
      <source>Hi, this is my favorite station. Hope you like it</source>
      <translation variants="no">嗨，这是我喜欢的频道，希望您也喜欢！</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_policy_copyright">
      <source>POLICY REGARDING ALLEGATIONS OF COPYRIGHT INFRINGEMENT</source>
      <translation variants="no">关于版权侵权指控的策略</translation>
    </message>
    <message numerus="no" id="txt_irad_connecting_failed_try_next_address">
      <source>Connecting failed, try next address</source>
      <translation variants="no">无法连接。尝试下一个地址。</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_the_services">
      <source>THE SERVICE</source>
      <translation variants="no">此服务</translation>
    </message>
    <message numerus="no" id="txt_irad_subtitle_genre">
      <source>Genre</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh #Genre</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_irad_list_unknown_song_l">
      <source>%1 - Unknown song</source>
      <translation variants="no">%[15]1 - 未知歌曲</translation>
    </message>
    <message numerus="no" id="txt_irad_opt_clear_list">
      <source>Clear list</source>
      <translation variants="no">清除列表</translation>
    </message>
    <message numerus="no" id="txt_irad_info_no_network_connection">
      <source>No network connection</source>
      <translation variants="no">(无网络连接)</translation>
    </message>
  </context>
</TS>