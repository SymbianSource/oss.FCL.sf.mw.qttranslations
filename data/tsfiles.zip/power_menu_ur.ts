<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_pm_button_power_off">
      <source>Power Off</source>
      <translation variants="no">سوئچ
بند!</translation>
    </message>
    <message numerus="no" id="txt_pm_button_silence">
      <source>Silence</source>
      <translation variants="no">خاموش</translation>
    </message>
    <message numerus="no" id="txt_pm_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">ٹچ اسکرین ارتعاش</translation>
    </message>
    <message numerus="no" id="txt_pm_list_offline_airplane_mode">
      <source>Offline (Airplane Mode)</source>
      <translation variants="no">آف لائن وضع</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">ur ##Ringing volume</translation>
    </message>
  </context>
</TS>