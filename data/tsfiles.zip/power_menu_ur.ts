<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_accessories_dblist_menu_headset">
      <source>Headset</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_tty">
      <source>TTY</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_loopse">
      <source>Loopset</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_music_stand">
      <source>Music stand</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_music_stand">
      <source>Music stand</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_loopset">
      <source>Loopset</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_button_silence">
      <source>Silence</source>
      <translation variants="no">خاموش</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_loopset">
      <source>Loopset</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_music">
      <source>Music stand</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headse">
      <source>Headset</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_wired">
      <source>Wired carkit</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">ٹچ اسکرین ارتعاش</translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_loopset">
      <source>Loopset</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights">
      <source>Lights</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_on">
      <source>On</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume">
      <source>Volume</source>
      <translation variants="no">ur #Volume</translation>
    </message>
    <message numerus="no" id="txt_pm_button_power_off">
      <source>Power Off</source>
      <translation variants="no">سوئچ
بند!</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">ur ##Ringing volume</translation>
    </message>
    <message numerus="no" id="txt_pm_list_meeting">
      <source>Meeting</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_list_general">
      <source>General</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_list_switch_off">
      <source>Switch off</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_list_lock_device">
      <source>Lock device</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_automatic">
      <source>Automatic</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headphones">
      <source>Headphones</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headphones">
      <source>Headphones</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_list_change_profile">
      <source>Change profile</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_list_go_to_online">
      <source>Go to online</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume_val_loud">
      <source>Loud</source>
      <translation variants="no">ur #Loud</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_tty">
      <source>TTY</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_music_stand">
      <source>Music stand</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_list_silent">
      <source>Silent</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headset">
      <source>Headset</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_list_offline_airplane_mode">
      <source>Offline (Airplane Mode)</source>
      <translation variants="no">آف لائن وضع</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headphones">
      <source>Headphones</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume_val_med">
      <source>Med</source>
      <translation variants="no">ur #Medium</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume_val_soft">
      <source>Soft</source>
      <translation variants="no">ur #Soft</translation>
    </message>
    <message numerus="no" id="txt_pm_list_go_to_offline">
      <source>Go to offline</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headph">
      <source>Headphones</source>
      <translation variants="no">ur ##</translation>
    </message>
  </context>
</TS>