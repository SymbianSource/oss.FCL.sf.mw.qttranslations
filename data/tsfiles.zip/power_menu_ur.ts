<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_pm_setlabel_ringing_volume">
      <source>Ringing volume</source>
      <translation variants="no">ur #Ringing volume</translation>
    </message>
    <message numerus="no" id="txt_pm_list_meeting">
      <source>Meeting</source>
      <translation variants="no">ur #Meeting</translation>
    </message>
    <message numerus="no" id="txt_pm_list_general">
      <source>General</source>
      <translation variants="no">ur #General</translation>
    </message>
    <message numerus="no" id="txt_pm_list_switch_off">
      <source>Switch off</source>
      <translation variants="no">ur #Switch off</translation>
    </message>
    <message numerus="no" id="txt_pm_list_change_profile">
      <source>Change profile</source>
      <translation variants="no">ur #Change profile</translation>
    </message>
    <message numerus="no" id="txt_pm_list_go_to_online">
      <source>Go to online</source>
      <translation variants="no">ur #Go to online</translation>
    </message>
    <message numerus="no" id="txt_pm_list_lock_device">
      <source>Lock device</source>
      <translation variants="no">ur #Lock device</translation>
    </message>
    <message numerus="no" id="txt_pm_list_go_to_offline">
      <source>Go to offline</source>
      <translation variants="no">ur #Go to offline</translation>
    </message>
    <message numerus="no" id="txt_accessories_title_accessory">
      <source>Accessory</source>
      <translation variants="no">ur #Accessory</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">ur #Wired carkit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_loopset">
      <source>Loopset</source>
      <translation variants="no">ur #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type">
      <source>Accessory type</source>
      <translation variants="no">ur #Accessory type</translation>
    </message>
    <message numerus="no" id="txt_pm_button_power_off">
      <source>Power Off</source>
      <translation variants="no">ur #Switch
off!</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headphones">
      <source>Headphones</source>
      <translation variants="no">ur #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">ur #Wired carkit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights">
      <source>Lights</source>
      <translation variants="no">ur #Lights</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_on">
      <source>On</source>
      <translation variants="no">ur #On</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_169">
      <source>16:9</source>
      <translation variants="no">ur #16:9</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_loopse">
      <source>Loopset</source>
      <translation variants="no">ur #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_music_stand">
      <source>Music stand</source>
      <translation variants="no">ur #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_music_stand">
      <source>Music stand</source>
      <translation variants="no">ur #Music stand</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume">
      <source>Volume</source>
      <translation variants="no">ur #Volume</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume_val_med">
      <source>Med</source>
      <translation variants="no">ur #Medium</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headset">
      <source>Headset</source>
      <translation variants="no">ur #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_tty">
      <source>TTY</source>
      <translation variants="no">ur #TTY</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">ur #Wireless carkit</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_tty">
      <source>TTY</source>
      <translation variants="no">ur #TTY</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_loopset">
      <source>Loopset</source>
      <translation variants="no">ur #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio_val_43">
      <source>4:3</source>
      <translation variants="no">ur #4:3</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wired_carkit">
      <source>Wired carkit</source>
      <translation variants="no">ur #Wired carkit</translation>
    </message>
    <message numerus="no" id="txt_pm_button_silence">
      <source>Silence</source>
      <translation variants="no">ur #Silence</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume_val_soft">
      <source>Soft</source>
      <translation variants="no">ur #Soft</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_lights_val_automatic">
      <source>Automatic</source>
      <translation variants="no">ur #Automatic</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headphones">
      <source>Headphones</source>
      <translation variants="no">ur #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_headphones">
      <source>Headphones</source>
      <translation variants="no">ur #Headphones</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">ur #Wireless carkit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headph">
      <source>Headphones</source>
      <translation variants="no">ur #Headphones</translation>
    </message>
    <message numerus="no" id="txt_pm_setlabel_volume_val_loud">
      <source>Loud</source>
      <translation variants="no">ur #Loud</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_headse">
      <source>Headset</source>
      <translation variants="no">ur #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_wireless_carkit">
      <source>Wireless carkit</source>
      <translation variants="no">ur #Wireless carkit</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_wired">
      <source>Wired carkit</source>
      <translation variants="no">ur #Wired carkit</translation>
    </message>
    <message numerus="no" id="txt_pm_list_offline_airplane_mode">
      <source>Offline (Airplane Mode)</source>
      <translation variants="no">ur #Offline mode</translation>
    </message>
    <message numerus="no" id="txt_pm_list_silent">
      <source>Silent</source>
      <translation variants="no">ur #Silent</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_tty">
      <source>TTY</source>
      <translation variants="no">ur #TTY</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_menu_music_stand">
      <source>Music stand</source>
      <translation variants="no">ur #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_headset">
      <source>Headset</source>
      <translation variants="no">ur #Headset</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_tty">
      <source>TTY</source>
      <translation variants="no">ur #TTY</translation>
    </message>
    <message numerus="no" id="txt_accessories_dblist_loopset">
      <source>Loopset</source>
      <translation variants="no">ur #Loopset</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_accessory_type_val_music">
      <source>Music stand</source>
      <translation variants="no">ur #Music stand</translation>
    </message>
    <message numerus="no" id="txt_accessories_setlabel_tv_aspect_ratio">
      <source>TV aspect ratio</source>
      <translation variants="no">ur #TV aspect ratio</translation>
    </message>
    <message numerus="no" id="txt_pm_list_vibrate">
      <source>Vibrate</source>
      <translation variants="no">ur #Touch screen vibration</translation>
    </message>
    <message numerus="no" id="txt_accessories_dpophead_headset">
      <source>Headset</source>
      <translation variants="no">ur #Headset</translation>
    </message>
  </context>
</TS>