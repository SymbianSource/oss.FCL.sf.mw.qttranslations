<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_power_setlabel_val_off">
      <source>Off</source>
      <translation variants="no">بند</translation>
    </message>
    <message numerus="no" id="txt_power_list_activate_power_save_mode_automatica">
      <source>Activate power save mode automatically when low power. Turns off automatically when charger is connected.</source>
      <translation variants="no">بیٹری کمزور ہونے پر پاور بچت وضع کو خودکار طور پر کارآمد کریں؟ آلے کی چارچنک خودکار طور پر اس وضع کو غیر فعال کر دے گی۔</translation>
    </message>
    <message numerus="no" id="txt_power_list_activating_power_save_mode_will_con">
      <source>Activating power save mode will consumes minimal power. Turns off all power consuming operations/features like Bluetooth, WLAN, Vibra, Tactile feedback, Key tones, Screensaver, Wallpapers and also dimming screen brightness, Switching Network from 3G to 2G.Turns off automatically when charger is connected.</source>
      <translation variants="no">پاور بچت وضع کی فعال کاری سے بیٹری زیادہ عرصے تک چلےگی۔ یہ تمام غیر ضروری خصوصیات کو بند کردے گی مثلاً Bluetooth، WLAN، ٹچ اسکرین ارتعاش اور لمسی فیڈ بیک، بٹن پیڈ ٹونزاوراسکرین سیورز۔ یہ ڈسپلے کی روشنی بھی کم کرے گی اور یہ آلے کو2Gنیٹ ورک استعمال کرنےکے قابل بنائے گا۔ آلے کی چارچنگ خودکار طور پر اس وضع کو غیر فعال کر دے گی۔</translation>
    </message>
    <message numerus="no" id="txt_power_setlabel_val_on">
      <source>On</source>
      <translation variants="no">چالو</translation>
    </message>
    <message numerus="no" id="txt_power_management_dpopinfo_low_battery">
      <source>Low Battery</source>
      <translation variants="no">بیٹری کم ہے</translation>
    </message>
    <message numerus="no" id="txt_power_management_subhead_power_management">
      <source>Power Management</source>
      <translation variants="yes">
        <lengthvariant priority="1">پاور کا انتظام</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_power_dpopinfo_unplug_charger_to_save_energy">
      <source>Unplug charger to save energy</source>
      <translation variants="no">چارجر کا پلگ نکال دیں</translation>
    </message>
    <message numerus="no" id="txt_power_management_dblist_charging">
      <source>Charging</source>
      <translation variants="no">چارچنگ جاری</translation>
    </message>
    <message numerus="no" id="txt_power_management_dpophead_100_full">
      <source>100% Full</source>
      <translation variants="no">۱۰۰% بھری ہوئی</translation>
    </message>
    <message numerus="no" id="txt_power_management_dpopinfo_psm_activated_automa">
      <source>PSM activated automatically</source>
      <translation variants="no">پاور بچت وضع چالو</translation>
    </message>
    <message numerus="no" id="txt_power_list_power_save_mode">
      <source>Power Save Mode</source>
      <translation variants="no">پاور بچت وضع</translation>
    </message>
  </context>
</TS>