<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="zh_tw">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_applib_subtitle_office">
      <source>Office</source>
      <translation variants="yes">
        <lengthvariant priority="1">辦公室</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_games">
      <source>Games</source>
      <translation variants="yes">
        <lengthvariant priority="1">遊戲</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_downloads">
      <source>Recently added</source>
      <translation variants="yes">
        <lengthvariant priority="1">下載</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_subtitle_essentials">
      <source>Essentials</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Essentials</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_essentials">
      <source>Essentials</source>
      <translation variants="yes">
        <lengthvariant priority="1">zh_tw #Essentials</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_office">
      <source>Office</source>
      <translation variants="yes">
        <lengthvariant priority="1">辦公室</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_applib_dblist_games">
      <source>Games</source>
      <translation variants="yes">
        <lengthvariant priority="1">遊戲</lengthvariant>
      </translation>
    </message>
  </context>
</TS>