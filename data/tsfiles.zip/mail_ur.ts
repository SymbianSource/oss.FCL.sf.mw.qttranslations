<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ur">
  <context>
    <name>nString</name>
    <message numerus="no" id="txt_common_button_send">
      <source>Send</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur ##Send</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_music">
      <source>Music</source>
      <translation variants="yes">
        <lengthvariant priority="1">موسیقی</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_new_video">
      <source>New video</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا ویڈیو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_do_you_want_to_delete_the_mailbox">
      <source>Do you want to delete the mailbox and all mail messages?</source>
      <translation variants="no">ur #Delete mailbox and all of its messages?</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_do_you_want_to_delete_mfe">
      <source>Do you want to delete all mail, calendar, contacts and tasks data related to this account?</source>
      <translation variants="no">ur #Delete all mail, calendar, contacts and tasks data related to this account?</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_show_cc_bcc">
      <source>Show cc / bcc</source>
      <translation variants="no">cc / bcc دکھائیں</translation>
    </message>
    <message numerus="no" id="txt_mail_list_photo">
      <source>Photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">شبیہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_deleting_mailbox">
      <source>Deleting mailbox</source>
      <translation variants="no">میل باکس مٹا رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_menu_remove">
      <source>Remove</source>
      <translation variants="no">ur ##Remove</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_hide_cc_bcc">
      <source>Hide cc / bcc</source>
      <translation variants="no">cc / bcc چھپائیں</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_1_deleted">
      <source>%[]1 deleted.</source>
      <translation variants="no">ur #Deleted:
%1</translation>
    </message>
    <message numerus="no" id="txt_mail_list_other">
      <source>Other</source>
      <translation variants="yes">
        <lengthvariant priority="1">دیگر</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_new_photo">
      <source>New photo</source>
      <translation variants="yes">
        <lengthvariant priority="1">نئی شبیہ</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_menu_remove_all">
      <source>Remove all</source>
      <translation variants="no">سب کو ہٹائیں</translation>
    </message>
    <message numerus="no" id="txt_mail_list_cc">
      <source>Cc:</source>
      <translation variants="no">ur #Cc:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_you_can_not_send_more_than_l1_att">
      <source>You can not send more than %L1 attachments at a time </source>
      <translation variants="no">ur #Unable to send more than %L1 attachments at a time</translation>
    </message>
    <message numerus="no" id="txt_common_menu_delete">
      <source>Delete</source>
      <translation variants="no">ur ##Delete</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_attachments_should_be_smaller_than">
      <source>Attachments should be smaller than %L1 Mb</source>
      <translation variants="no">ur #Attachments should be smaller than %L1 MB</translation>
    </message>
    <message numerus="no" id="txt_mail_list_to">
      <source>To:</source>
      <translation variants="no">ur #To:</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_bcc">
      <source>Bcc:</source>
      <translation variants="no">ur ##Bcc:</translation>
    </message>
    <message numerus="no" id="txt_mail_title_mail">
      <source>Mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_no_subject">
      <source>(No Subject)</source>
      <translation variants="yes">
        <lengthvariant priority="1">(کوئی موضوع نہیں)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_cannot_download_attachment_1">
      <source>Cannot download attachment: %[]1 </source>
      <translation variants="no">ur #Unable to download attachment: %1 </translation>
    </message>
    <message numerus="no" id="txt_mail_button_new_mail">
      <source>New</source>
      <translation variants="yes">
        <lengthvariant priority="1">نیا</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_title_control_panel">
      <source>Mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">میل</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_reply_all">
      <source>Reply all</source>
      <translation variants="no">ur #Reply to all</translation>
    </message>
    <message numerus="no" id="txt_mail_status_menu_new_mail">
      <source>New Mail</source>
      <translation variants="no">ur #New Mail</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_mail_connection_error">
      <source>Mail connection error.</source>
      <translation variants="no">ur #Mail connection error</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority">
      <source>Add priority</source>
      <translation variants="no">ترجیح شامل کریں</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_to">
      <source>To:</source>
      <translation variants="no">ur ##To:</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_cc">
      <source>Cc:</source>
      <translation variants="no">ur ##Cc:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_sending_mail">
      <source>Sending mail</source>
      <translation variants="no">میل بھیجا جا رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_address_or_password_incorrect">
      <source>Mail address or password is incorrect. Do you want to check the settings?</source>
      <translation variants="no">ur #Incorrect mail address or password. Check settings?</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_you_can_not_send_more_than_l1_kb">
      <source>You can not send more than %L1 Mb as attachments </source>
      <translation variants="no">ur #Unable to send more than %L1 MB worth of attachments</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_subject">
      <source>Subject:</source>
      <translation variants="no">ur ##Subject:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_sending_failed">
      <source>Sending mail %[]1 failed. Try to send it again or press back to cancel</source>
      <translation variants="no">ur #Failed to send:
%[52]1.
Try to send again or press 'Back' to cancel.</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_opening_mail_editor">
      <source>Opening mail editor</source>
      <translation variants="no">میل ایڈیٹر کھول رہا ہے</translation>
    </message>
    <message numerus="no" id="txt_common_menu_open">
      <source>Open</source>
      <translation variants="no">ur ##Open</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_send_and_receive_now">
      <source>Refresh</source>
      <translation variants="no">دوبارہ تازہ کریں</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_low">
      <source>Low</source>
      <translation variants="no">کم</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_add_attachment">
      <source>Unable to add attachment </source>
      <translation variants="no">ur #Unable to add attachment</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_mark_as_unread">
      <source>Mark as unread</source>
      <translation variants="no">بطور نہ پڑھا نشانزد</translation>
    </message>
    <message numerus="no" id="txt_mail_shareui_send_as_mail">
      <source>Send as new mail</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Send as new mail</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_downloading_canceled">
      <source>Not enough memory - downloading canceled</source>
      <translation variants="no">ur #Downloading cancelled. Not enough memory.</translation>
    </message>
    <message numerus="no" id="txt_nmailui_forward_subject_prefix">
      <source>Fw:</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Fw:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_deleted">
      <source>Deleted items</source>
      <translation variants="no">ur #Deleted items</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no_mailboxes_defined">
      <source>No mailboxes defined</source>
      <translation variants="no">ur ##</translation>
    </message>
    <message numerus="no" id="txt_mail_menu_mark_as_read">
      <source>Mark as read</source>
      <translation variants="no">بطور پڑھا گیا نشان زد</translation>
    </message>
    <message numerus="no" id="txt_short_caption_mail">
      <source>Mail</source>
      <translation variants="no">ur ##Mail</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_open_attachment_file_ty">
      <source>Unable to open. Attachment file type not supported</source>
      <translation variants="no">ur #Unable to open. Attachment file type not supported.</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_val_no_subject">
      <source>(No Subject)</source>
      <translation variants="no">ur ##(No Subject)</translation>
    </message>
    <message numerus="no" id="txt_mail_shareui_sending_please_wait">
      <source>Sending, please wait</source>
      <translation variants="no">ur #Sending</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_sent">
      <source>Sent:</source>
      <translation variants="no">ur #Sent:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_loading_mail_content">
      <source>Loading mail content</source>
      <translation variants="no">ur #Loading mail content</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance">
      <source>Importance:</source>
      <translation variants="no">ur #Importance:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_server_settings_incorrect">
      <source>Server settings are incorrect. Do you want to check the settings?</source>
      <translation variants="no">ur #Incorrect server settings. Check settings?</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no">
      <source>No</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #No</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_drafts">
      <source>Drafts</source>
      <translation variants="no">ur #Drafts</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_reply">
      <source>Reply</source>
      <translation variants="no">ur #Reply</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_inbox">
      <source>Inbox </source>
      <translation variants="no">ur #Inbox</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_yes">
      <source>Yes</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Yes</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_status_menu_waiting_to_send">
      <source>Waiting to send (%L1)</source>
      <translation variants="no">ur #Waiting to send (%L1)</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_subject">
      <source>Subject:</source>
      <translation variants="no">ur #Subject:</translation>
    </message>
    <message numerus="no" id="txt_mail_subhead_inbox">
      <source>Inbox </source>
      <translation variants="no">ur ##Inbox </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_still_sending">
      <source>Still sending mail %[]1. Please wait operation to complete</source>
      <translation variants="no">ur #Still sending mail %[88]1. Wait for operation to complete.</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance_low">
      <source>Low</source>
      <translation variants="no">ur #Low</translation>
    </message>
    <message numerus="no" id="txt_nmailui_reply_subject_prefix">
      <source>Re:</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #Re:</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_from">
      <source>From:</source>
      <translation variants="no">ur #From:</translation>
    </message>
    <message numerus="no" id="txt_mail_list_searching">
      <source>Seaching</source>
      <translation variants="no">ur #Seaching</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_cc">
      <source>Cc:</source>
      <translation variants="no">ur #Cc:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_send_via">
      <source>Send via</source>
      <translation variants="yes">
        <lengthvariant priority="1">ارسال کریں بذریعے</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dpophead_1_deleted">
      <source>Mailbox deleted. </source>
      <translation variants="no">ur #Mailbox deleted</translation>
    </message>
    <message numerus="no" id="txt_mail_button_attach">
      <source>Attach</source>
      <translation variants="yes">
        <lengthvariant priority="1">منسلک کریں</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_unable_to_complete_command">
      <source>Unable to complete the command</source>
      <translation variants="no">ur #Unable to perform operation</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_sent">
      <source>Sent</source>
      <translation variants="no">ur #Sent</translation>
    </message>
    <message numerus="no" id="txt_mail_dpophead_loading_mail_content">
      <source>Loading mail content</source>
      <translation variants="no">میل مشمولات لوڈ کیے جا رہے ہیں</translation>
    </message>
    <message numerus="no" id="txt_mail_list_video">
      <source>Video</source>
      <translation variants="yes">
        <lengthvariant priority="1">ویڈیو</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_common_opt_settings">
      <source>Settings</source>
      <translation variants="no">ur ##Settings</translation>
    </message>
    <message numerus="no" id="txt_mail_list_l1_mb">
      <source>(%L1 Mb)</source>
      <translation variants="yes">
        <lengthvariant priority="1">ur #(%L1 MB)</lengthvariant>
      </translation>
    </message>
    <message numerus="no" id="txt_mail_list_from">
      <source>From:</source>
      <translation variants="no">ur #From:</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_delete_mail">
      <source>Delete mail?</source>
      <translation variants="no">ur #Delete mail?</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_forward">
      <source>Forward</source>
      <translation variants="no">ur #Forward</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_no_messages_matched_your_search">
      <source>No messages matched your search. Try another search term. </source>
      <translation variants="no">ur #No messages matched your search. Try another search term. </translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_invalid_mail_address_send">
      <source>Invalid mail address: %[]1. Send anyway?</source>
      <translation variants="no">ur #Invalid mail address:
%[78]1.
Send anyway?</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_original_msg">
      <source>---- Original message ----</source>
      <translation variants="no">ur #---- Original message ----</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_invalid_mail_address">
      <source>Invalid mail address: %[]1</source>
      <translation variants="no">ur #Invalid mail address:
%1</translation>
    </message>
    <message numerus="no" id="txt_mail_dialog_no_mailboxes_create_new">
      <source>No mailboxes have been defined. Would you like to create a new mailbox?</source>
      <translation variants="no">ur #No mailboxes have been defined. Create new mailbox?</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_normal">
      <source>Normal</source>
      <translation variants="no">عام</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_add_priority_sub_high">
      <source>High</source>
      <translation variants="no">زیادہ</translation>
    </message>
    <message numerus="no" id="txt_long_caption_mail">
      <source>Mail</source>
      <translation variants="no">میل</translation>
    </message>
    <message numerus="no" id="txt_mail_viewer_opt_delete">
      <source>Delete</source>
      <translation variants="no">ur #Delete</translation>
    </message>
    <message numerus="no" id="txt_mail_opt_folder_sub_outbox">
      <source>Outbox</source>
      <translation variants="no">ur #Outbox</translation>
    </message>
    <message numerus="no" id="txt_mail_list_search_results">
      <source>%L1 results</source>
      <translation variants="no">ur #%L1 results</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_to">
      <source>To:</source>
      <translation variants="no">ur #To:</translation>
    </message>
    <message numerus="no" id="txt_mail_editor_reply_importance_high">
      <source>High</source>
      <translation variants="no">ur #High</translation>
    </message>
    <message numerus="no" id="txt_mail_dblist_no_messages">
      <source>(No messages)</source>
      <translation variants="no">ur #(no messages)</translation>
    </message>
  </context>
</TS>